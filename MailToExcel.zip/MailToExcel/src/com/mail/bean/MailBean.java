package com.mail.bean;

public class MailBean {

	private String from;
	private String to;
	private String subject;
	private String contentType;
	private String bodyContent;
	private String sendDate;
	private String receiveDate;
	private String unreadCount;
	private String ssoId;
	private String trNo;
	private String approveReject;
	private String approveKey;
	private String rejectKey;
	private String infoKey;
	private String mailerKey;
	
	public String getApproveKey() {
		return approveKey;
	}
	public void setApproveKey(String approveKey) {
		this.approveKey = approveKey;
	}
	public String getRejectKey() {
		return rejectKey;
	}
	public void setRejectKey(String rejectKey) {
		this.rejectKey = rejectKey;
	}
	public String getInfoKey() {
		return infoKey;
	}
	public void setInfoKey(String infoKey) {
		this.infoKey = infoKey;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getSsoId() {
		return ssoId;
	}
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	public String getTrNo() {
		return trNo;
	}
	public void setTrNo(String trNo) {
		this.trNo = trNo;
	}
	public String getSendDate() {
		return sendDate;
	}
	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}
	public String getReceiveDate() {
		return receiveDate;
	}
	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getBodyContent() {
		return bodyContent;
	}
	public void setBodyContent(String bodyContent) {
		this.bodyContent = bodyContent;
	}
	public String getUnreadCount() {
		return unreadCount;
	}
	public void setUnreadCount(String unreadCount) {
		this.unreadCount = unreadCount;
	}
	public String getApproveReject() {
		return approveReject;
	}
	public void setApproveReject(String approveReject) {
		this.approveReject = approveReject;
	}
	
	public String toString() {
		return "MailBean [from=" + from + ", to=" + to + ", subject=" + subject + ", contentType=" + contentType
				+ ", sendDate=" + sendDate + ", receiveDate=" + receiveDate + ", unreadCount=" + unreadCount
				+ ", ssoId=" + ssoId + ", trNo=" + trNo + ", approveReject=" + approveReject + "]";
	}
	public String getMailerKey() {
		return mailerKey;
	}
	public void setMailerKey(String mailerKey) {
		this.mailerKey = mailerKey;
	}
}
