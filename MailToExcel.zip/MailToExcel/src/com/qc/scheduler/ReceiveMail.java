package com.qc.scheduler;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.search.FlagTerm;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.mail.bean.MailBean;
import com.sun.mail.imap.IMAPStore;

public class ReceiveMail{

	private static Logger logger = LogManager.getLogger(ReceiveMail.class);

	static ResourceBundle  rs = ResourceBundle.getBundle("com.qc.scheduler.application");
	//static String MailTo = rs.getString("com.max.filePath");*/


	public static List<MailBean> receiveEmail(String pop3Host, String storeType, String user, String password, String MailTo) {	
		logger.info("Call Mathod receiveEmail():: START");
		ResourceBundle  rb = ResourceBundle.getBundle("com.qc.scheduler.application");
		String filePathYTD = rb.getString("com.max.filePathYTD");
		String filePathMTD = rb.getString("com.max.filePathMTD");
		String fileNameYTD = rb.getString("com.max.fileNameYTD");
		String fileNameMTD = rb.getString("com.max.fileNameMTD");
		StringBuilder dakshmailcontentYTD=new StringBuilder(); 
		StringBuilder dakshmailcontentMTD=new StringBuilder(); 
		int countYTD=0;
		int countMTD=0;  

		List<MailBean> list = new ArrayList<MailBean>();
		try {
			Properties properties = new Properties();
			properties.put("mail.imap.host", pop3Host);
			properties.put("mail.imap.port", 993);
			properties.put("mail.imap.timeout", "158000");
			properties.setProperty("mail.store.protocol","imaps");


			Session emailSession = Session.getInstance(properties);
			// Store emailStore = (Store) emailSession.getStore(storeType);
			IMAPStore emailStore = (IMAPStore) emailSession.getStore();
			emailStore.connect(pop3Host,user, password);

			Folder emailFolder = emailStore.getFolder("INBOX");
			emailFolder.open(Folder.READ_WRITE);

			Flags seen = new Flags(Flags.Flag.SEEN);
			FlagTerm unseenFlagTerm = new FlagTerm(seen, false);

			/********GET UNREAD MAILS ONLY **********/
			Message[] messages = emailFolder.search(unseenFlagTerm);

			/********GET ALL MAILS **********/
			// Message[] messages = emailFolder.getMessages();
			logger.info("In receiveEmail() get total unread Mail::"+messages.length); 

			for (int i = 0; i<messages.length; i++) {
				MailBean mailBean = new MailBean();
				Message message = messages[i];

				/**** CHECK UNREAD MAILS ONLY  ***/
				/*if(message.isSet(Flag.SEEN)){
					 continue;
				 }*/
				/**** CHECK MAIL'S SUBJECT CONTAINS SSO ID ?***/
				/*if(getSSOID(message.getSubject()) == null || getSSOID(message.getSubject()).isEmpty()){
					 continue;
				 }*/

				/**** CHECK MAIL'S SUBJECT CONTAINS TRNO ID ? ***/
				if(getTRNO(message.getSubject()) == null || getTRNO(message.getSubject()).isEmpty()){
					System.out.println(message.getSubject()); 
					logger.info("-----Daksh Mail Subject------->"+message.getSubject());
					continue;
				}
				if(getTRNOYTD(message.getSubject()).contains("YTD")){
					countYTD++;
					if(countYTD==1){
						String valueforYTD=null;
						valueforYTD=message.getContent().toString();
						valueforYTD=valueforYTD.replaceAll("\r\n"," ").replaceAll("&AMP;","").replaceAll("&amp;","").replaceAll("&nbsp;"," ").replaceAll("&NBSP;"," ").replaceAll("&LT;","").replaceAll("&lt;","").replaceAll("&gt;","").replaceAll("&GT;","");
						valueforYTD=valueforYTD.replaceAll("\\<.*?\\>", "");
						valueforYTD=valueforYTD.replaceAll("Actual", "\nActual");
						valueforYTD=valueforYTD.replaceFirst("\n", "");
						dakshmailcontentYTD.append(valueforYTD);
						System.out.println("------------>"+message.getSubject());
						logger.info("-----Daksh Mail Subject------->"+message.getSubject());
					}else{
						String valueforYTD=null;
						valueforYTD=message.getContent().toString();
						valueforYTD=valueforYTD.replaceAll("\r\n"," ").replaceAll("&AMP;","").replaceAll("&amp;","").replaceAll("&nbsp;"," ").replaceAll("&NBSP;"," ").replaceAll("&LT;","").replaceAll("&lt;","").replaceAll("&gt;","").replaceAll("&GT;","");
						valueforYTD=valueforYTD.replaceAll("\\<.*?\\>", "");
						valueforYTD=valueforYTD.replaceAll("Actual", "\nActual");
						valueforYTD=valueforYTD.replaceFirst("\n", "");
						System.out.println("------------>"+message.getSubject());
						logger.info("-----Daksh Mail Subject------->"+message.getSubject());
						try{

							String array[]=valueforYTD.split("\n");
							for(int j=0;j<array.length;j++){
								if(j>0){
									dakshmailcontentYTD.append("\n"+array[j]);  
								}}
						}catch(Exception e){
							logger.info("In receiveEmail() for YTD second mail read and write::"+e); 	
						} 
					}

				}
				if(getTRNOMTD(message.getSubject()).contains("MTD")){
					countMTD++;
					if(countMTD==1){
						String valueforMTD=null;
						valueforMTD=message.getContent().toString();	 
						valueforMTD=valueforMTD.replaceAll("\r\n"," ").replaceAll("&AMP;","").replaceAll("&amp;","").replaceAll("&nbsp;"," ").replaceAll("&NBSP;"," ").replaceAll("&LT;","").replaceAll("&lt;","").replaceAll("&gt;","").replaceAll("&GT;","");
						valueforMTD=valueforMTD.replaceAll("\\<.*?\\>", "");
						valueforMTD=valueforMTD.replaceAll("Actual", "\nActual");
						valueforMTD=valueforMTD.replaceFirst("\n", "");
						dakshmailcontentMTD.append(valueforMTD);
						logger.info("-----Daksh Mail Subject------->"+message.getSubject());
						System.out.println("------------>"+message.getSubject());
					}else{
						String valueforMTD=null;
						valueforMTD=message.getContent().toString();	 
						valueforMTD=valueforMTD.replaceAll("\r\n"," ").replaceAll("&AMP;","").replaceAll("&amp;","").replaceAll("&nbsp;"," ").replaceAll("&NBSP;"," ").replaceAll("&LT;","").replaceAll("&lt;","").replaceAll("&gt;","").replaceAll("&GT;","");
						valueforMTD=valueforMTD.replaceAll("\\<.*?\\>", "");
						valueforMTD=valueforMTD.replaceAll("Actual", "\nActual");
						valueforMTD=valueforMTD.replaceFirst("\n", "");
						logger.info("-----Daksh Mail Subject------->"+message.getSubject());
						System.out.println("-----Daksh Mail Subject------->"+message.getSubject());

						try{

							String array[]=valueforMTD.split("\n");
							for(int j=0;j<array.length;j++){
								if(j>0){
									dakshmailcontentMTD.append("\n"+array[j]); 
								}

							}
						}catch(Exception e) {

							logger.info("In receiveEmail() for MTD second mail read and write::"+e); 						 }

					}

				}

				//mailBean.setFrom(getMailId(message.getFrom()[0].toString()));
				mailBean.setSubject(message.getSubject());
				mailBean.setSendDate(message.getSentDate().toString());
				mailBean.setReceiveDate(message.getReceivedDate().toString());
				//mailBean.setSsoId(getSSOID(message.getSubject()));
				// mailBean.setTrNo(getTRNO(message.getSubject()));
				mailBean.setTo(getMailId(message.getAllRecipients()[0].toString()));

				message.setFlag(Flag.SEEN, false);

				//logger.info("In receiveEmail() get unread Mail's data for TR.No::"+mailBean.getTrNo()+" ");


				list.add(mailBean);
			}


			if(dakshmailcontentYTD!=null && !dakshmailcontentYTD.toString().isEmpty()){
				WriteTextFile(filePathYTD,fileNameYTD,dakshmailcontentYTD.toString());
			}
			if(dakshmailcontentMTD!=null && !dakshmailcontentMTD.toString().isEmpty()){
				WriteTextFile(filePathMTD,fileNameMTD,dakshmailcontentMTD.toString());
			}

			emailFolder.close(false);
			emailStore.close();
		} catch (NoSuchProviderException e) {
			logger.error("Exception in Mathod receiveEmail():: "+e);
		} catch (MessagingException e) {
			logger.error("Exception in Mathod receiveEmail():: "+e);
		}catch (IOException e) {
			logger.error("Exception in Mathod receiveEmail():: "+e);
		}
		logger.info("Call Mathod receiveEmail():: END");
		return list;
	}

	private static String getMailId(String to) {
		logger.info("Call Mathod getMailId():: START");
		String mailId = to;

		try{
			mailId = mailId.substring(mailId.indexOf("<")+1, mailId.indexOf(">"));
		}catch(Exception e){
			logger.info("Exception in Mathod getMailId():"+e);
		} 

		logger.info("Call Mathod getMailId():: END");
		return mailId !=null ? mailId : "";
	}

	public static void main(String[] args) {

		// String host = "pop-mail.outlook.com"; //For POP3
		// String host = "imap-mail.outlook.com";//For IMAP
		//String host = "outlook.office365.com";//For IMAP
		String host ="imap.gmail.com";
		String mailStoreType = "imap";
		// String username= "priyanka.mittal@maxlifeinsurance.com"; //naveen.bhati@maxlifeinsurance.com
		//String username=rs.getString("manishnegilspl@gmail.com");
		String username="manishnegilspl@gmail.com";
		String password="";
		String to="";
		try{
			List<MailBean> list = receiveEmail(host, mailStoreType, username, password,to);

			if(list.isEmpty()){
				System.out.println("You don't have any unread mail till now  :"); 
				logger.info("You don't have any unread mail till now  :");
			}else{
				int i=0;

				for(MailBean temp : list){  
					System.out.println("---------------------------------");
					System.out.println("SSO ID		: " + temp.getSsoId());  
					System.out.println("TR No		: " + temp.getTrNo());
					System.out.println("Email Number : " + (i++));
					System.out.println("Subject      : " + temp.getSubject());
					System.out.println("From			: " + temp.getFrom());
					System.out.println("Send date	: " + temp.getSendDate());
					System.out.println("Received date: " + temp.getReceiveDate());

				}
			}}catch(Exception e){

				logger.info("Exception in Mathod getMailId():"+e);


			}
	}
	public static String getSSOID(String input){

		try{
			String s= input.substring(input.indexOf("(")+1, input.indexOf(")"));
			//return s.contains("HOM")? s : "";
			return s;
		}catch(Exception e){			
			return "";
		}	
	}

	public static String getTRNO(String input){

		try{
			if(input.contains("YTD")||input.contains("MTD")){
				return input.trim();
			}else{
				return "";
			}
		}catch(Exception e){			
			return "";
		}	
	}

	public static String getTRNOYTD(String input){

		try{
			if(input.contains("YTD")){
				return input.trim();
			}else{
				return "";
			}
		}catch(Exception e){			
			return "";
		}	
	}
	public static String getTRNOMTD(String input){

		try{
			if(input.contains("MTD")){
				return input.trim();
			}else{
				return "";
			}
		}catch(Exception e){			
			return "";
		}	
	}
	public static void WriteTextFile(String path,String fileName,String data){
		logger.info("Start: Inside the WriteTextFile()");
		SimpleDateFormat sdf2=new SimpleDateFormat("dd-MMM-yyyy");
		//SimpleDateFormat sdf2=new SimpleDateFormat("YYYYMMDD");
		String reportName=""; 

		try{   
			reportName=path+fileName+"-"+sdf2.format(new Date())+".txt";
			System.out.println("ReportName---->   "+reportName);
			logger.info("Start: Inside the WriteTextFile() reportName   "+reportName);
			PrintWriter writer = new PrintWriter(reportName,"UTF-8");
			writer.println(data);

			writer.close();
		} catch (IOException e) {
			// do something
			//System.out.println("In Exception"+e);
			logger.info("Start: Inside the WriteTextFile() reportName   "+e);
		}

	}




}