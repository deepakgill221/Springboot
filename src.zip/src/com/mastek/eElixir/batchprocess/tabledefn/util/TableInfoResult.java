package com.mastek.eElixir.batchprocess.tabledefn.util;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

public class TableInfoResult implements Serializable
{
  public TableInfoResult()
  {
  }

  /**
   * Sets the XMLString.
   * @param a_strXMLString String
   */
  public void setXMLString(String a_strXMLString)
  {
      this._strXMLString = a_strXMLString;
  }

  public String getXMLString()
  {
      return this._strXMLString;
  }
  public void setBatchPrcSeq(Long a_lBatchPrcSeq)
  {
      this._lBatchPrcSeq = a_lBatchPrcSeq;
  }

  public void setTableName(String a_strTableName)
  {
      this._strTableName = a_strTableName;
  }

  public void setTableDesc(String a_strTableDesc)
  {
      this._strTableDesc = a_strTableDesc;
  }

  public void setBatchPrcURL(String a_strBatchPrcURL)
  {
      this._strBatchPrcURL = a_strBatchPrcURL;
  }

  public Long getBatchPrcSeq()
  {
      return this._lBatchPrcSeq;
  }

  public String getTableName()
  {
      return this._strTableName;
  }

  public String getTableDesc()
  {
      return this._strTableDesc;
  }

  public String getBatchPrcURL()
  {
      return this._strBatchPrcURL;
  }

  public Short getNIsMapped() 
  {
      return this._nIsMapped;
  }
  
  public void setNIsMapped(Short a_nIsMapped) 
  {
      this._nIsMapped = a_nIsMapped;
  }

  public Short getIsUploadPrc() 
  {
      return this._nIsUploadPrc;
  }
  
  public void setIsUploadPrc(Short a_nIsUploadPrc) 
  {
      this._nIsUploadPrc = a_nIsUploadPrc;
  }

  public void setStatus(String a_strStatus)
  {
    this._strStatus = a_strStatus;
  }

  public String getStatus()
  {
    return this._strStatus;
  }

 /**
  * returns the Created By
  * @return _strCreatedBy String
  */
  public String getCreatedBy()
   {
     return this._strCreatedBy;
   }

 /**
  * sets the Created By
  * @param a_strCreatedBy String
  */
  public void setCreatedBy(String a_strCreatedBy)
   {
     this._strCreatedBy = a_strCreatedBy;
    }

 /**
  * returns the Updated By
  * @return _strUpdatedBy String
  */
  public String getUpdatedBy()
   {
     return this._strUpdatedBy;
   }

 /**
  * sets the Updated By
  * @param a_strUpdatedBy String
  */
  public void setUpdatedBy(String a_strUpdatedBy)
   {
     this._strUpdatedBy = a_strUpdatedBy;
    }

 /**
  * returns the Created Date
  * @return _dtCreated Date
  */
  public Date getCreated()
   {
     return this._dtCreated;
   }

 /**
  * sets the Created Date
  * @param a_dtCreated Date
  */
  public void setCreated(Date a_dtCreated)
   {
     this._dtCreated = a_dtCreated;
    }

 /**
  * returns the Updated Timestamp
  * @return _tsUpdated Timestamp
  */
  public Timestamp getUpdated()
   {
     return this._tsUpdated;
   }

 /**
  * sets the Updated Timestamp
  * @param a_tsUpdated Timestamp
  */
  public void setUpdated(Timestamp a_tsUpdated)
   {
     this._tsUpdated = a_tsUpdated;
    }


  private Long _lBatchPrcSeq;
  private String _strTableName;
  private String _strTableDesc;
  private String _strBatchPrcURL;
  private String _strXMLString;
  private Short _nIsMapped;
  private Short _nIsUploadPrc;
  private String _strStatus;
  private String _strCreatedBy;
  private Date _dtCreated;
  private String _strUpdatedBy;
  private Timestamp _tsUpdated;  
}