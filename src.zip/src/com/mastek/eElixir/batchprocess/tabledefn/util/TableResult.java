package com.mastek.eElixir.batchprocess.tabledefn.util;

import java.io.Serializable;
import java.util.Collection;

public class TableResult implements Serializable
{
  public TableResult()
  {
  }

  public TableInfoResult getTableHdr()
  {
	return this._oTblInfoResult;
  }

  public void setTableHdr(TableInfoResult a_oTblInfoResult)
  {
	this._oTblInfoResult = a_oTblInfoResult;
  }

  public Collection getTableDtls()
  {
	return this._oTblDefResult;
  }

  public void setTableDtls(Collection a_oTblDefResult)
  {
	this._oTblDefResult = a_oTblDefResult;
  }


  private Collection _oTblDefResult;
  private TableInfoResult _oTblInfoResult;
}