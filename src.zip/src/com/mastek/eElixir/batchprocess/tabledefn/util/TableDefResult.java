package com.mastek.eElixir.batchprocess.tabledefn.util;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

public class TableDefResult implements Serializable
{
    public void setColumnName(String strColumnName)
    {
        this.strColumnName = strColumnName;
    }

    public void setColumnWidth(String strColumnWidth)
    {
        this.strColumnWidth = strColumnWidth;
    }

    public void setDataType(String strDataType)
    {
        this.strDataType = strDataType;
    }

    public void setIsPrimaryKey(Short isPrimaryKey)
    {
        this.isPrimaryKey = isPrimaryKey;
    }

    public void setFromDataValue(Integer iFromDataValue)
    {
        this.iFromDataValue = iFromDataValue;
    }

    public void setToDataValue(Integer iToDataValue)
    {
        this.iToDataValue = iToDataValue;
    }
    public String getColumnName()
    {
        return this.strColumnName;
    }

    public String getColumnWidth()
    {
        return this.strColumnWidth;
    }

    public String getDataType()
    {
        return this.strDataType;
    }

    public Short getIsPrimaryKey()
    {
        return this.isPrimaryKey;
    }

    public Integer getFromDataValue()
    {
        return this.iFromDataValue;
    }

    public Integer getToDataValue()
    {
        return this.iToDataValue;
    }

 /**
  * returns the Created By
  * @return _strCreatedBy String
  */
  public String getCreatedBy()
   {
     return this._strCreatedBy;
   }

 /**
  * sets the Created By
  * @param a_strCreatedBy String
  */
  public void setCreatedBy(String a_strCreatedBy)
   {
     this._strCreatedBy = a_strCreatedBy;
    }

 /**
  * returns the Updated By
  * @return _strUpdatedBy String
  */
  public String getUpdatedBy()
   {
     return this._strUpdatedBy;
   }

 /**
  * sets the Updated By
  * @param a_strUpdatedBy String
  */
  public void setUpdatedBy(String a_strUpdatedBy)
   {
     this._strUpdatedBy = a_strUpdatedBy;
    }

 /**
  * returns the Created Date
  * @return _dtCreated Date
  */
  public Date getCreated()
   {
     return this._dtCreated;
   }

 /**
  * sets the Created Date
  * @param a_dtCreated Date
  */
  public void setCreated(Date a_dtCreated)
   {
     this._dtCreated = a_dtCreated;
    }

 /**
  * returns the Updated Timestamp
  * @return _tsUpdated Timestamp
  */
  public Timestamp getUpdated()
   {
     return this._tsUpdated;
   }

 /**
  * sets the Updated Timestamp
  * @param a_tsUpdated Timestamp
  */
  public void setUpdated(Timestamp a_tsUpdated)
   {
     this._tsUpdated = a_tsUpdated;
    }
    
    
	public void setComments(String a_strComments)
	{
		this.strComments = a_strComments;    
	}
	
	public String getComments()
	{
		return strComments;
	}
       
    
	private String strComments;
    private String strColumnName;
    private String strColumnWidth;
    private String strDataType;
    private Short isPrimaryKey;
    private Integer iFromDataValue;
    private Integer iToDataValue;
    private String _strCreatedBy;
    private Date _dtCreated;
    private String _strUpdatedBy;
    private Timestamp _tsUpdated;
}