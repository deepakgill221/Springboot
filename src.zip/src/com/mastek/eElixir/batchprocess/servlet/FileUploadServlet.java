package com.mastek.eElixir.batchprocess.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspsmart.upload.Files;
import com.jspsmart.upload.Request;
import com.jspsmart.upload.SmartUpload;
import com.mastek.eElixir.batchprocess.tabledefn.util.TableDefResult;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.upload.util.FileDataMap;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FileUploadServlet extends HttpServlet
{
    private static Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

	private ServletConfig config;
    /**
     * Makes a call to its super class init method
     * Sets the document object from the Action Repository
     * @param config
     * @throws ServletException
     */
    public void init    (ServletConfig config) throws ServletException
    {
        this.config = config;
    }

    final public ServletConfig getServletConfig() {
        return config;
    }

    protected void doGet(HttpServletRequest a_oRequest, HttpServletResponse response)
            throws ServletException, IOException
    {
        log.debug("In do get ---");
        doPost(a_oRequest,response);
    }

	protected void doPost(HttpServletRequest a_oRequest, HttpServletResponse response)
            throws ServletException, IOException
    {
       // try
        //{
        log.entry("UploadFile","process","start-------"+a_oRequest);

        // Variables
        int count=0;
        SmartUpload mySmartUpload = new SmartUpload();

        try {
            // Initialization
            mySmartUpload.initialize(config,a_oRequest,null);

            // Upload
            mySmartUpload.upload();

            log.debug("strBatchPrcURL test ---"+mySmartUpload.getRequest().getParameter("strBatchPrcURL"));
            // Save the file with the original name
            // in a virtual path of the web server
            count = mySmartUpload.save(mySmartUpload.getRequest().getParameter("strBatchPrcURL"));

            // Display the result
            log.debug(count + " file uploaded.");

        } catch (Exception e){
            log.debug("Unable to upload the file.<br>");
            log.debug("Error : " + e.toString());
        }

        DataResult oDataResult = fetchUploadData(mySmartUpload.getRequest());
        Files ofile = mySmartUpload.getFiles();
        oDataResult.setStrDataFile(ofile.getFile(0).getFileName());
        a_oRequest.setAttribute("calledFor",mySmartUpload.getRequest().getParameter("calledFor"));
		a_oRequest.setAttribute("strTableDescription",mySmartUpload.getRequest().getParameter("strTableNameDesc"));

        this.forward(a_oRequest, response,oDataResult, "/batchprocess/upload/jsp/DataUpload.jsp");
    }
    /**
     * Forward it to correct page
     */
    private void forward(HttpServletRequest a_oRequest,
        HttpServletResponse a_oResponse,Object a_oResult, String a_strActionJsp)
    {

         try{
             RequestDispatcher rd=getServletConfig().getServletContext().
                                   getRequestDispatcher(a_strActionJsp);
             a_oRequest.setAttribute("ResultObject",a_oResult);
             rd.forward(a_oRequest,a_oResponse);
         }
         catch(Exception e){
             System.out.println("Exception in Controller - Inside Forward...."+
                                                            e.getMessage());
         }
    }

    public DataResult fetchUploadData(Request a_oRequest)
        {
            DataResult oDataResult = new DataResult() ;

            log.entry("FetchData","fetchUploadData","Start----");
            String strTableName = a_oRequest.getParameter("strTableName");
            String strBatchPrcURL = a_oRequest.getParameter("strBatchPrcURL");
            String nIsMapped = a_oRequest.getParameter("nIsMapped");
            String lBatchPrcSeq = a_oRequest.getParameter("lBatchPrcSeq");
			String strTableNameDesc = a_oRequest.getParameter("strTableNameDesc");
			String strMainProc = a_oRequest.getParameter("strMainProc").trim();
			String strMessDelOption = a_oRequest.getParameter("strMessDelOption").trim();
			
			log.debug("strMessDelOption-------->"+strMessDelOption);
            log.debug("strTableName --"+strTableName);
            log.debug("strBatchPrcURL --"+strBatchPrcURL);
            log.debug("nIsMapped --"+nIsMapped);
            log.debug("strTableNameDesc --"+strTableNameDesc);
			log.debug("strMainProc --"+strMainProc);
			

            oDataResult.setStrTableName(strTableName);
            oDataResult.setStrBatchPrcUrl(strBatchPrcURL);
            oDataResult.setLBatchPrcSeq(new Long(lBatchPrcSeq));
			oDataResult.setMainProcName(strMainProc);
			
			if(strMessDelOption != null && (!strMessDelOption.equals("")))
				oDataResult.setMessDelOption(new Short(strMessDelOption));
			else
				oDataResult.setMessDelOption(null);
			
			

            if(nIsMapped != null && (!nIsMapped.equals("")))
                oDataResult.setNIsMapped(new Short(nIsMapped));
            else
                oDataResult.setNIsMapped(null);

            
            ArrayList alFileDataMap = getFileDataMap(a_oRequest);
            ArrayList alTableDefResult = getTableDef(a_oRequest);

            oDataResult.setAlFileDataMap(alFileDataMap);
            oDataResult.setAlTableDefResult(alTableDefResult);

            return oDataResult;
        }

        private ArrayList getFileDataMap(Request a_oRequest)
        {
            ArrayList alFileDatMap = new ArrayList();

            log.entry("FetchData","getFileDataMap","Start");

            log.debug("called for--"+a_oRequest.getParameter("calledFor"));
            int index = Integer.parseInt(a_oRequest.getParameter("NoOfRows"));

            for(int count=0; count<index; count++)
            {
                FileDataMap oFileDataMap = new FileDataMap();

                oFileDataMap.setStrColName(a_oRequest.getParameter("strColumnName"+count));

                String strDataFrom = a_oRequest.getParameter("nDataFrom"+count);

                if(strDataFrom != null && (!strDataFrom.equals("")))
                    oFileDataMap.setLFromDataValue(new Long(strDataFrom));
                else
                    oFileDataMap.setLFromDataValue(null);

                String strDataTo = a_oRequest.getParameter("nDataTo"+count);

                if(strDataTo != null && (!strDataTo.equals("")))
                    oFileDataMap.setLToDataValue(new Long(strDataTo));
                else
                    oFileDataMap.setLToDataValue(null);

                alFileDatMap.add(oFileDataMap);
            }
            log.exit("FetchData","getFileDataMap","End--  alFileDatMap.size() ---"+alFileDatMap.size());
            return alFileDatMap;
        }// end of getFileDataMap

        private ArrayList getTableDef(Request a_oRequest)
        {
            ArrayList alTableDefResult = new ArrayList();

            log.entry("FetchData","getTableDef","Start");

            int index = Integer.parseInt(a_oRequest.getParameter("NoOfRows"));
            log.debug("NoOfRows : "+index);

            for(int count=0; count<index; count++)
            {
                TableDefResult oTableDefResult = new TableDefResult();

                oTableDefResult.setColumnName(a_oRequest.getParameter("strColumnName"+count));
                oTableDefResult.setComments(a_oRequest.getParameter("strComments"+count));
				

                oTableDefResult.setColumnWidth(a_oRequest.getParameter("nColumnWidth"+count));
                oTableDefResult.setDataType(a_oRequest.getParameter("strDataType"+count));

                alTableDefResult.add(oTableDefResult);
            }
            log.exit("FetchData","getTableDef","End--alTableDefResult.size()--"+alTableDefResult.size());
            return alTableDefResult;
    }// end of getTableDef
}