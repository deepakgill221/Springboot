package com.mastek.eElixir.batchprocess.servlet;


import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.batchprocess.util.BatchProcessActionFactory;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.servlet.Controller;
import com.mastek.eElixir.common.util.ActionFactory;
import com.mastek.eElixir.common.util.ActionIF;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This servlet is  inherited from the Controller servlet.Its main
 * function is load the respective action class and makes a call to the process method
 * of that action </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Diptik
 * @version 1.0
 */

public class BatchProcessController extends Controller
{
	private static Logger logger = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

    /**
     * Makes a call to its super class init method
     * Sets the document object from the Action Repository
     * @param config
     * @throws ServletException
     */
    public void init    (ServletConfig config) throws ServletException
    {
      super.init(config);
      setDocument(Constants.BATCH_PROCESS);
    }

    /**
     * Method to instantiate/invoke the action factory and pass the class to be instantiated
     * @param strActionClass
     * @param request
     * @return Object
     * @throws EElixirException
     */

    public Object process ( String strActionClass , HttpServletRequest request) throws EElixirException
    {
        logger.debug("Batch Process Controller -----Process begins ");
		Object objObjectResult = null;
		try
		{
			logger.debug("Batch Process --ActionFactory Instantiation in progress");
			ActionFactory objBatchProcessActionFactory = BatchProcessActionFactory.getActionFactory();

			logger.debug("Batch Process --ActionFactory Creating Action class Instance "+strActionClass);
			ActionIF objActionClass = objBatchProcessActionFactory.createAction(strActionClass);
			logger.debug("Batch Process --objActionClass "+objActionClass);
			logger.debug("Batch Process --Calling Pocess method on Action class ");
			objActionClass.process(request);

			logger.debug("Batch Process--Obtaining Resut Object from Action class ");
			objObjectResult = objActionClass.getResult();

			logger.debug("Batch Process--ResultObject is " + objObjectResult);
		}
		catch (EElixirException eex)
		{
			logger.debug("Batch Process --Error :: " + eex);
			eex.printStackTrace();
            throw eex;
		}
		return objObjectResult;
   }
}