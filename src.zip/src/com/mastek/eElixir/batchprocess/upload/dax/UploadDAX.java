/********************************************************************
 *
 *  PROJECT			: AMAL

 *  MODULE NAME		: Batch Process
 *  FILENAME		: UploadDAX.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 05/06/2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1      14/06/2003    Heena Jain    Change in the return type of the
 *                                      createPrcResult, also the seq no
 *                                      for com_prc_result is craeted in
 *                                      first in the craeteDataForUpload
 *                                      instead of createPrcResult.
 *                                      Also added the timestamp in the
 *                                      creation of the log file name
 * 1.2      17/06/2003    Heena Jain    Modified createBatchPrcDataMap()
 * 1.3      19/06/2003    Heena Jain    Modified downloadData() to add column
 *                                      headers for the csv file created.
 *                                      Modified createBatchPrcD() for updating
 *                                      the header com_batch_prc_m
 * 1.4      20/06/2003    Heena Jain    Modified getUploadTables(), added the
 *                                      % for the Like search and converted
 *                                      the string to upper case
 *                                      
 *1.5        05-01-2011    Shrikrishna     Rel. Q2 (Feb 2011) (Location wise restriction of instrument collection entryv1.4.DOC)                                      
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.batchprocess.upload.dax;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.CallableStatement;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import oracle.jdbc.driver.OracleTypes;


import au.com.bytecode.opencsv.CSVWriter;

import com.mastek.eElixir.batchprocess.tabledefn.util.TableDefResult;
import com.mastek.eElixir.batchprocess.tabledefn.util.TableInfoResult;
import com.mastek.eElixir.batchprocess.upload.util.DataLoader;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.upload.util.DownloadCriteria;
import com.mastek.eElixir.batchprocess.upload.util.FileDataMap;
import com.mastek.eElixir.batchprocess.upload.util.LogDataValue;
import com.mastek.eElixir.batchprocess.upload.util.Parser;
import com.mastek.eElixir.batchprocess.util.BPConstants;
import com.mastek.eElixir.batchprocess.util.BatchProcessSqlRepository;
import com.mastek.eElixir.common.exception.EElixirDAXException;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.PropertyUtil;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;



/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the Upload object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 */

public class UploadDAX extends DAX
{
   private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

   private final String ELAPSED_TIME = "Elapsed time was:";
   private final String RUN_ENDED = "Run ended on";
   private final String RECORDS_DISCARDED = "Total logical records discarded:";
   private final String RECORDS_REJECTED = "Total logical records rejected:";
   private final String RECORDS_READ = "Total logical records read:";
   private final String RECORDS_SKIPPED ="Total logical records skipped:";
   private final String LOG_FILE_EXTN = "log";
   private final String DOWNLOAD_FILE_EXTN = ".csv";

  /**
   * Constructor
   */
  public UploadDAX()
  {
  }

  /**
   * This method get the column names which are selected for the download.
   * A select query is formed and the query is fired.
   * The result is iterated to form a file with comma separators (csv) with
   * ".csv" extension in the temporary directory.
   * @param a_oDataResult
   * @return
   * @throws EElixirException
   */
  public DataResult downloadData(DataResult a_oDataResult)
          throws EElixirException
  {
      PreparedStatement oPreparedStatement = null;
      ResultSet rsSelect = null;
      try
      {
          String strTableName = a_oDataResult.getStrTableName();
          String strBatchPrcUrl = a_oDataResult.getStrBatchPrcUrl();
          long lBatchPrcSeq = a_oDataResult.getLBatchPrcSeq().longValue();

          ArrayList alDownloadCriteria = a_oDataResult.getAlDownloadCriteria();

          StringBuffer strSelect = new StringBuffer();
          strSelect.append("SELECT");
          String strFrom = " FROM "+strTableName;

          for(int i=0; i<alDownloadCriteria.size(); i++)
          {
              DownloadCriteria odc = (DownloadCriteria)alDownloadCriteria.get(i);
              String colName = odc.getStrColumnName();
              colName = colName.toUpperCase();
              // check if the column is a date column, then set
              // the date format
              if(colName.startsWith("DT"))
              {
                  // set the format for date and also a alias so that
                  //the column remains the same as in the object and in the
                  // select clause
                 colName = "to_char( "+colName+",'DD/MM/YYYY') "+colName;
                 log.debug("Column for Date ---"+colName);
              }

              if(i != (alDownloadCriteria.size() -1))
                  strSelect.append(" "+colName+" , ");
              else
                  strSelect.append(" "+colName);
          }

          String strQuery = strSelect.toString()+strFrom;
          log.debug("Final Query Formed is "+strQuery);


          oPreparedStatement =
                            this.getPreparedStatement(strQuery, null,null);

          rsSelect = executeQuery(oPreparedStatement);
          log.debug("After executing the query......");

          SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyykkmmss");
          String strDate = sdf.format(new java.util.Date());

          String strFileName = strTableName + strDate + DOWNLOAD_FILE_EXTN;
          log.debug("Download File Name "+strFileName);

          String finalFileName = strBatchPrcUrl + strFileName;
          log.debug("finalFileName formed is ------"+finalFileName);
          // set the file name in the data result
          a_oDataResult.setStrDataFile(finalFileName);

          // create a random access file object
          RandomAccessFile raf = new RandomAccessFile(finalFileName,"rw");

          String colHeader="";
          // write the column headers
          for(int i=0; i<alDownloadCriteria.size(); i++)
          {
              DownloadCriteria odc = (DownloadCriteria)alDownloadCriteria.get(i);
              String colName = odc.getStrColumnName();
              colName = colName.toUpperCase();

              if(i != (alDownloadCriteria.size() -1))
                  colHeader += colName+",";
              else
                  colHeader += colName;
          }
          raf.writeBytes(colHeader +"\n");

          // write the data for the columns
          while(rsSelect.next())
          {
              String strRow = "";

              // get the column names from the download criteria object
              for(int i=0; i<alDownloadCriteria.size(); i++)
              {
                  DownloadCriteria odc = (DownloadCriteria)alDownloadCriteria.get(i);
                  // get the column
                  String colName = odc.getStrColumnName();
                  // get the value of the column
                  String colValue = rsSelect.getString(colName);

                  if(rsSelect.wasNull())
                      colValue = "";

                  if(i != (alDownloadCriteria.size() - 1 ))
                      strRow += colValue + ",";
                  else
                      strRow += colValue;
              }
              raf.writeBytes(strRow + "\n");
          }// end of while
          // close the file object
          raf.close();
      }
      catch(Exception sqlex)
      {
          //BP1020=Error while creating the file to download
          log.fatal("UploadDAX","downloadData",sqlex.getMessage());
          throw new EElixirException(sqlex, "BP1020");
      }
      finally
      {
          try
          {
            if(rsSelect != null)
              rsSelect.close();


            if(oPreparedStatement != null)
              oPreparedStatement.close();

          }
          catch(SQLException sqlex)
          {
            log.debug(sqlex.getMessage());
            throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
          }

      }
      log.entry("UploadDAX","downloadData","End---");
      return a_oDataResult;

  }// end of downloadData

  /**
   * This method initiates the upload process which spawns another thread and
   * returns the status as "Process Started"
   * @param a_oDataResult
   * @return
   * @throws EElixirException
   */
  public DataResult createDataForUpload(DataResult a_oDataResult)
          throws EElixirException
  {
  	/*  Variables for calling stored procedures  
  	
	 PropertyUtil oPropertyUtil = new PropertyUtil(Constants.SETUP_FILE);
	 String strDirectoryPath = oPropertyUtil.getProperty("upload.dir.i");  	
  	 String strUserId = null;
  	 long lPrcResultSeq = 0;
  	 long lCashBankSeqNbr = 0;
  	 Date dtStatement = null;
	 String strProcedure = null;  	 
	 CallableStatement oCallableStatement1 = null;
	 CallableStatement oCallableStatement2 = null;
	 CallableStatement oCallableStatement3 = null;  	  	  
  	
	  Variables for calling stored procedures  */  	
	String strResult ="";
  	
      try
      {
          log.entry("UploadDAX","createDataForUpload","Start---");

          /* If nIsMapped == 0 then insert a record in COM_PRC_DATA_MAP
           with the mappings as specified by the user */
          short nIsMapped = a_oDataResult.getNIsMapped().shortValue();
          log.debug("Values of isMapped :"+nIsMapped);
          int iFormat = a_oDataResult.getFormat().intValue();
		  
		  String strMainProc = a_oDataResult.getMainProcName();
		  
          
          if(nIsMapped == 0 && iFormat == BPConstants.BATCH_PROCESS_FIXED)
          {
              createBatchPrcDataMap(a_oDataResult);
          }

          String strBatchPrcUrl = a_oDataResult.getStrBatchPrcUrl();
          log.debug("strBatchPrcUrl--"+strBatchPrcUrl);

          String strDataFileName = a_oDataResult.getStrDataFile();
          log.debug("dataFileName--"+strDataFileName);
          
		  a_oDataResult.setDataFileWithoutPath(a_oDataResult.getStrDataFile());

          String finalFileName = strBatchPrcUrl+getFileName(strDataFileName);
          log.debug("Final File Name Formed is :--"+finalFileName);

          String fileNameWithoutExtn = getFileNameWithoutExtn(getFileName(finalFileName));
          log.debug("fileNameWithoutExtn ---"+fileNameWithoutExtn);

          String ctlFileName = createControlFile(fileNameWithoutExtn, a_oDataResult);
          String dataFileName = finalFileName;

          SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyykkmmss");
          String strDate = sdf.format(new java.util.Date());
			
          String logFileName = strBatchPrcUrl+fileNameWithoutExtn+strDate+"."+LOG_FILE_EXTN;

          log.debug("Control File Name"+ctlFileName);
          log.debug("Data File Name"+dataFileName);
          log.debug("Log File Name"+logFileName);

          a_oDataResult.setStrControlFile(ctlFileName);
          a_oDataResult.setStrLogFile(logFileName);

          /**
           * Get the d=squence no of the com_prc_result table before starting the
           * process.
           * Set the sequence no in the  Data Result object
           */
          long seqNo = getNextBatchPrcResultNbr();
          a_oDataResult.setLPrcResultSeq(new Long(seqNo));

          DataLoader dl = new DataLoader(ctlFileName,dataFileName,
                  logFileName,a_oDataResult);
    
/*This code differentiate between the Email or Email and Messages */		
    	
		log.debug("nMessDelOption from Dax-------->"+a_oDataResult.getMessDelOption());   	
            
		if(a_oDataResult.getMessDelOption()!= null && a_oDataResult.getMessDelOption().intValue() == BPConstants.FLAG_FOR_EMAIL_MESSAGES)
		{
			boolean bIsProcExec =dl.getIsProcExec();
					boolean bIsSuccessful =dl.getIsSuccessful();					
    
				   if(!bIsProcExec)
				  {
					strResult = new String(Constants.RESULT_XML);
					a_oDataResult.setErrorCount(new Integer(BPConstants.FLAG_FOR_SQLLODER_NOTSUCCESS));
					a_oDataResult.setErrorLog(strResult);
				  }
				  else if(bIsProcExec && !bIsSuccessful)
				  {
					strResult = new String(Constants.RESULT_XML);
					a_oDataResult.setErrorCount(new Integer(BPConstants.FLAG_FOR_PROC_NOTSUCCESS));
					a_oDataResult.setErrorLog(strResult);
				  }		
				  else if(bIsProcExec && bIsSuccessful)
				  {
					Integer iErrorCount =getErrorCount(a_oDataResult);
					a_oDataResult.setErrorCount(iErrorCount);
					strResult = getErrorLogs(a_oDataResult);
					a_oDataResult.setErrorLog(strResult);
					// Added by Manisha on 28-Jan-2015 for FIN816 - START
					if(iErrorCount > 0 && ("MM_SP_INSTR_UPLD".equals(strMainProc.trim().toUpperCase()) || "MM_SP_CRDRCARDSI_STMT_UPLD".equals(strMainProc.trim().toUpperCase())
							|| "MM_SP_INSTR_NONHYBRID_MAIN".equals(strMainProc.trim().toUpperCase()) || "MM_SP_CCS_NONHYBRID_MAIN".equals(strMainProc.trim().toUpperCase())))
					{
						getFlagForSucc(a_oDataResult);
					}
					// Added by Manisha on 28-Jan-2015 for FIN816 - END
				  }

		}
		else
		{
			
			a_oDataResult.setIProcessStartStatus(new Integer(BPConstants.BP_EXC_STATUS_STARTED));
						strResult = new String(Constants.RESULT_XML);
						a_oDataResult.setErrorLog(strResult);
						
						
		}
            
/*End of the code*/
        
        
	      
	      
	      
          
          
		  
		  
	         
          /**** Preparing to call the required procedures ****
          log.debug("Preparing to call the procedures........ ########################");
          strUserId = a_oDataResult.getStrUserId();
		  lPrcResultSeq = seqNo;
		  
		  Thread.sleep(10000);
		  
		   strProcedure = getSQLString("Select",BPConstants.PROC_BANK_STMT_UPLOAD_TEMP);		  
		   oCallableStatement1 = getCallableStatement(strProcedure);
		   log.debug("the procedure is -> " + strProcedure);
		   oCallableStatement1.setString(1,strUserId);
		  // oCallableStatement.setString(2,a_oManualMatchBookResult.getInstrNbr());
		  // oCallableStatement.setInt(3,MMDataConstants.PROC_CALL_FROM_JAVA);		
		   oCallableStatement1.registerOutParameter(2,Types.INTEGER); 
		   oCallableStatement1.registerOutParameter(3,Types.VARCHAR); 
    		oCallableStatement1.execute(); 		   
		  
		  
		    Thread.sleep(10000); 		   
		   
			strProcedure = getSQLString("Select",BPConstants.PROC_BANK_STMT_UPLOAD);		  
			oCallableStatement2 = getCallableStatement(strProcedure);
			log.debug("the procedure is -> " + strProcedure);
			oCallableStatement2.setString(1,strUserId);
		    oCallableStatement2.setLong(2,lPrcResultSeq);
		    oCallableStatement2.setString(3,strDirectoryPath);		
			oCallableStatement2.registerOutParameter(4,Types.DATE); 
			oCallableStatement2.registerOutParameter(5,Types.BIGINT); 		   
		    oCallableStatement2.registerOutParameter(6,Types.INTEGER); 
		    oCallableStatement2.registerOutParameter(7,Types.VARCHAR);
			oCallableStatement2.execute(); 
		    if(oCallableStatement2.getObject(4)!=null) 
			   dtStatement = oCallableStatement2.getDate(4); 
		    if(oCallableStatement2.getObject(5)!=null) 
		   	   lCashBankSeqNbr = oCallableStatement2.getLong(5); 
		   	   
		Thread.sleep(10000);
		   	   
			strProcedure = getSQLString("Select",BPConstants.PROC_BANK_RECONCILIATION);		  
			oCallableStatement3 = getCallableStatement(strProcedure);
			log.debug("the procedure is -> " + strProcedure);
			oCallableStatement3.setString(1,strUserId);
		    oCallableStatement3.setLong(2,lCashBankSeqNbr);		
			oCallableStatement3.setDate(3,dtStatement);
			oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
			oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
			oCallableStatement3.execute(); 		   	   			   			
		   */
	          
          }
          catch(Exception sqlex)
          {
              //BP1019=Error while Uploading the Data
              log.fatal("UploadDAX","createBatchPrcDataMap",sqlex.getMessage());
              throw new EElixirException(sqlex, "BP1019");
          }
          
		finally
		{
		/*  try
		  {
			if(oCallableStatement1 != null)
			oCallableStatement1.close();
			
			if(oCallableStatement2 != null)
			oCallableStatement2.close();
			
			if(oCallableStatement3 != null)
			oCallableStatement3.close(); 
			
		  }
		  catch(SQLException sqlex)
		  {
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, "MM902");
		  }
		  */
		}	          
          
          log.entry("UploadDAX","createDataForUpload","End---");
    return a_oDataResult;
  }// end of createDataForUpload

  /**
   * This method parses the data file according to the mapping and returns the
   * mapped object
   * @param a_oDataResult
   * @return
   * @throws EElixirException
   */
    public DataResult getPreviewData(DataResult a_oDataResult)
          throws EElixirException
  {
      try
      {
          log.entry("UploadDAX","getPreviewData","Start----");
          String strBatchPrcUrl = a_oDataResult.getStrBatchPrcUrl();
          log.debug("strBatchPrcUrl--"+strBatchPrcUrl);
          String dataFileName = a_oDataResult.getStrDataFile();

          String finalFileName = strBatchPrcUrl+getFileName(dataFileName);
          log.debug("Final File Name Formed is :--"+finalFileName);

          ArrayList alFileDataMap = a_oDataResult.getAlFileDataMap();
          int sizeofFileDataMap = alFileDataMap.size();
          log.debug("sizeofFileDataMap :--"+sizeofFileDataMap);

          int from[] = new int[sizeofFileDataMap];
          int to[] = new int[sizeofFileDataMap];

          for(int i=0; i<sizeofFileDataMap; i++)
          {
              FileDataMap oFileMap = (FileDataMap)alFileDataMap.get(i);
              int fromVal = oFileMap.getLFromDataValue().intValue();
              int toVal = oFileMap.getLToDataValue().intValue();
              from[i] = fromVal;
              to[i] = toVal;
          }// end of for

		  String strDelimiter = a_oDataResult.getDelimiter();
		  if(strDelimiter == null)
		  {
		  	strDelimiter = "";
		  }
          Parser oParser = new Parser(finalFileName,from,to,strDelimiter);
          log.debug("Parser ---"+oParser);
          ArrayList alRowData = oParser.parseFile();

          log.debug("Row Data Size ::"+alRowData.size());

          a_oDataResult.setAlPreviewRowData(alRowData);
      }
      catch(EElixirException eex)
      {
          throw eex;
      }
      return a_oDataResult;
  }// end of getPreviewData

  /**
     *  gets the Table Column Defintion
     * @return DataResult
     * @param long LPRCRESULTSEQ -- Result Seq no
     * @param long LBATCHPRCSEQ --- Batch Process master seq no
     * @param short NTYPE --- Type identifies the tpe of process
     * @throws EElixirException
     */
   public DataResult getTableColDefn(long lBatchPrcSeq,String strTableName, short nIsMapped)
            throws EElixirException
    {
      ResultSet rsSearch = null, rsMap = null;
      PreparedStatement pstmtSearch = null, pstmtMap = null;
      DataResult oDataResult = new DataResult();
	  PropertyUtil oPropertyUtil = new PropertyUtil(Constants.SETUP_FILE);
	  String strOWNER = oPropertyUtil.getProperty("db.owner");      

      try
      {
          log.entry("UploadDAX","getTableColDefn","Values --lBatchPrcSeq"+lBatchPrcSeq
                    +"--strTableName--"+"--nIsMapped--"+nIsMapped);

              String strSelectJobQuery =
                      getSQLString("Select", BPConstants.SELECT_ALL_TAB);

              log.debug("Query String for select : "+strSelectJobQuery);

              pstmtSearch = getPreparedStatement(strSelectJobQuery);
              pstmtSearch.setString(1,strTableName.toUpperCase());
		      pstmtSearch.setLong(2,lBatchPrcSeq);
		      //pstmtSearch.setString(3,strOWNER);
		      rsSearch = executeQuery(pstmtSearch);
              log.debug("After Query execution");

              // Array List which contains the definition for the table
              ArrayList alTableDefResult = new ArrayList();

              while(rsSearch.next())
              {
                  log.debug("While of Data Dictionary for the table");
                  // stores the table column data
                  TableDefResult oTableDefResult = new TableDefResult();

                  oTableDefResult.setColumnName(rsSearch.getString("COLUMN_NAME"));
				  oTableDefResult.setComments(rsSearch.getString("COMMENTS"));
				  log.debug(" ******* Comments = " + rsSearch.getString("COMMENTS"));
                  String strDataType = rsSearch.getString("DATA_TYPE");
                  oTableDefResult.setDataType(strDataType);

                  if(strDataType.equals(BPConstants.DATA_TYPE_NUMBER))
                  {
                      // then it's numeric type
                      // get the data precision and the data scale
                      int dataPrecision = rsSearch.getInt("DATA_PRECISION");
                      log.debug("dataPrecision -- "+dataPrecision);

                      int dataScale = rsSearch.getInt("DATA_SCALE");
                      log.debug("dataScale"+dataScale);

                      String datalength = "";
                      if(dataScale != 0)
                          datalength = dataPrecision+","+dataScale;
                      else
                          datalength = dataPrecision+"";

                      oTableDefResult.setColumnWidth(datalength);
                  }
                  else
                  {
                      // else the dattype is not numeric
                      oTableDefResult.setColumnWidth(rsSearch.getString("DATA_LENGTH"));
                  }
                  alTableDefResult.add(oTableDefResult);
              }// end of while
              log.debug("Size of Array for Table Defn :--"+alTableDefResult.size());

              // Get the mapping data for the table from COM_PRC_DATA_MAP SELECT_DATA_MAP
              String strSelectDataMapQuery =
                    getSQLString("Select", BPConstants.SELECT_DATA_MAP);

              log.debug("Query String for select of data mapping : "+strSelectDataMapQuery);

              pstmtMap = getPreparedStatement(strSelectDataMapQuery);
              pstmtMap.setLong(1,lBatchPrcSeq);
              rsMap = executeQuery(pstmtMap);
              log.debug("After Data Map Query execution");

              // Array List which contains the definition for the table
              ArrayList alFileDataMap = new ArrayList();

              while(rsMap.next())
              {
                  FileDataMap oFileDataMap = new FileDataMap();

                  oFileDataMap.setStrColName(rsMap.getString("STRCOLNAME"));
                  oFileDataMap.setLFromDataValue(new Long(rsMap.getLong("LFROMDATAVAL")));
                  oFileDataMap.setLToDataValue(new Long(rsMap.getLong("LTODATAVAL")));
                  alFileDataMap.add(oFileDataMap);
              }

              log.debug("Size of File Data Map Arraylist :-----"+alFileDataMap.size());

              // set the arraylist of tableDefResult and the FileDataMap in the
              // DataResult object

              oDataResult.setAlTableDefResult(alTableDefResult);
              oDataResult.setAlFileDataMap(alFileDataMap);
              oDataResult.setLBatchPrcSeq(new Long(lBatchPrcSeq));

        return oDataResult;
      }
      catch(SQLException sqlex){
          //BP1007=Unable to retrieve the data for upload of Data File
        log.debug(sqlex.getMessage());
        throw new EElixirDAXException(sqlex, "BP1007");
      }
      finally
      {
        try
        {
          if(rsSearch != null)
            rsSearch.close();

          if(rsMap != null)
              rsMap.close();

          if(pstmtSearch != null)
            pstmtSearch.close();

          if(pstmtMap != null)
              pstmtMap.close();
        }
        catch(SQLException sqlex)
        {
          log.debug(sqlex.getMessage());
          throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
    }

  /**
   * Populates the resultset into XML string object
   * @param a_oResultObject Object
   * @return XML string object
   * @throws EElixirException
   */

  public String getUploadTables(TableInfoResult oTableInfoResult) throws EElixirException
  {
    log.debug("UploadDAX--Inside getUploadTables of DAX");
    PreparedStatement pstmtSearchJob = null;
    Statement st = null ;
    StringBuffer sb = new StringBuffer();
    HashMap hmQueryMap = new HashMap();

    log.debug("UploadDAX--Search Data" + oTableInfoResult);
    try
    {
      log.debug("UploadDAX--TRY" );
      String strTableName = oTableInfoResult.getTableName();
      String strTableDesc = oTableInfoResult.getTableDesc();
      Short nIsUploadPrc = oTableInfoResult.getIsUploadPrc();

      String strSearchJobQuery = getSQLString("Select",
              BPConstants.UPLOAD_LIST_SEARCH);
      log.debug("strSearchJobQuery--"+strSearchJobQuery);

      hmQueryMap.put("Main",strSearchJobQuery);

      strSearchJobQuery = " AND UPPER(bt.STRTABLENAME) LIKE UPPER(?) " ;
      hmQueryMap.put("STRTABLENAME",strSearchJobQuery);

      strSearchJobQuery = " AND UPPER(bt.STRTABLEDESC) LIKE UPPER(?) " ;
      hmQueryMap.put("STRTABLEDESC",strSearchJobQuery);

      String strQuery = (String)hmQueryMap.get("Main");
      log.debug("UploadDAX--Strquery =" + strQuery);

      if (strTableName != null)
      {
        strQuery += (String)hmQueryMap.get("STRTABLENAME");
      }
      if (strTableDesc!= null )
      {
        strQuery += (String)hmQueryMap.get("STRTABLEDESC");
      }

      strQuery = strQuery + " order by bt.STRTABLEDESC";
      log.debug("UploadDAX--FINAL FORMED Strquery =" + strQuery);

      pstmtSearchJob = getPreparedStatement(strQuery);
      int iPosition = 0 ;

      // set the porcess type
      pstmtSearchJob.setShort(++iPosition, nIsUploadPrc.shortValue());

      if (strTableName!= null )
      {
        log.debug("UploadDAX--Adding strTableName " );
        pstmtSearchJob.setString(++iPosition, "%"+strTableName+"%");
      }
      if (strTableDesc != null )
      {
        log.debug("UploadDAX--Adding strTableDesc" );
        pstmtSearchJob.setString(++iPosition, "%"+strTableDesc+"%");
      }

      ResultSet rsSearch = executeQuery(pstmtSearchJob);
      return XMLConverter.getXMLString(rsSearch);
    }
    catch(SQLException sqlex)
    {
        //BP1006=The system was unable to search uploads based on the search criteria.
      log.debug(sqlex.getMessage());
      throw new EElixirDAXException(sqlex, "BP1006");
    }
    finally
    {
      try
      {
        if(pstmtSearchJob != null)
          pstmtSearchJob.close();
      }
      catch(SQLException sqlex)
      {
        log.debug(sqlex.getMessage());
        throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }


  /**
    * Description getSQLString takes querytype and key and returns query
    * @return query string
    * @param a_strSQLType SQL Type i.e Select , Insert , Delete , Update
    * @param a_strKey String
    * @throws EElixirException
    */
   private String getSQLString(String a_strSQLType,String a_strKey)
           throws EElixirException
   {
     log.debug("UploadDAX--getSQLString" );
     SqlRepositoryIF sqlRFIF = null;
     String strSql = "";
     try
     {
       sqlRFIF = BatchProcessSqlRepository.getSqlRepository();
       log.debug("UploadDAX--getSQLString---sqlRFIF" +sqlRFIF);
	   log.debug("UploadDAX--getSQLString---a_strSQLType " +a_strSQLType);
	   log.debug("UploadDAX--getSQLString---a_strKey " +a_strKey);
       strSql=sqlRFIF.getSQLString(a_strKey,a_strSQLType);
       log.debug("UploadDAX--getSQLString---" +strSql);
     }
     catch(EElixirException eex)
     {
//        BP1002=Could not Get SQL String
       log.debug("UploadDAX--sql ex"+ eex);
       log.debug(eex.getMessage());
       throw new EElixirException(eex,"BP1002"); // could not get sql string
     }
     return strSql;
   }

   /**
    * This method returns file name
    * @param a_strFileName
    * @return
    */
   private String getFileName(String a_strFileName)
   {
       String finalFileName="";

       String separator = java.io.File.separator;
       log.debug("separator : "+separator);
       
       /* Added on 15/8/03 Start*/
       if(!separator.equals("/"))
       	separator = "/";
	/* Added on 15/8/03 End*/

       int index = a_strFileName.lastIndexOf(separator);
       log.debug("Index of File Separator : "+index);

       String fileName = a_strFileName.substring(index+1);
       log.debug("File Name :-- "+fileName);

       finalFileName = fileName;
       return finalFileName;
   }

   /**
    * This method returns the filename without any extension
    * @param a_oFileName
    * @return
    */
   private String getFileNameWithoutExtn(String a_oFileName)
   {
       String fileNameWithoutExtn ="";

       int index = a_oFileName.indexOf(".");
       log.debug("Index of . "+index);

       fileNameWithoutExtn = a_oFileName.substring(0,index);
       return fileNameWithoutExtn;
   }// end of getFileNameWithoutExtn

   /**
    * It craetes a control file definition for the sql loader
    * @param fileNameWithoutExtn
    * @param oDataResult
    * @return
    * @throws EElixirException
    */
   private String createControlFile(String fileNameWithoutExtn, DataResult oDataResult)
           throws EElixirException
   {
       String ctlFileName="";
	   String strStart = "";
	   String strSTART_BRACKET= "(";
	   String strEnd = "";
	   String strFinal = "";
	   String strDelimiter = "";
	   String strInsertForDelimiter = "";
	   ArrayList alFileMap = new ArrayList();
	   //FileDataMap oFileMapTemp1 = null;
	   //FileDataMap oFileMapTemp2 = null;
	   int iColumnSeq1 = 0;
	   int iColumnSeq2 = 0;

       log.entry("UploadDAX","createControlFile","Entry---");
       String strTableName = oDataResult.getStrTableName();
       String strBatchPrcUrl = oDataResult.getStrBatchPrcUrl();
       int iFormat = oDataResult.getFormat().intValue();
       log.debug("FILE FORMAT---------------- "+iFormat);
       
       //ArrayList alTableDef = oDataResult.getAlTableDefResult();

       /*strStart = "LOAD DATA \n " +
                         "REPLACE INTO TABLE "+strTableName+ "\n"+
                         "(";
*/
		strStart = "LOAD DATA \n " +
					 "REPLACE INTO TABLE "+strTableName+ "\n";
       
       strEnd = ")";
	   
       StringBuffer strCol= new StringBuffer();

	   if(iFormat == BPConstants.BATCH_PROCESS_FIXED)
	   {		  
		   alFileMap = oDataResult.getAlFileDataMap();
	       log.debug("alFileMap.size() "+alFileMap.size());
	       
	       for(int i=0; i < alFileMap.size(); i++)
	       {
	           //TableDefResult oTableDef = (TableDefResult)alTableDef.get(i);
	           FileDataMap oFileMap = (FileDataMap)alFileMap.get(i);
	
	           String strColName = oFileMap.getStrColName();
	           int iFromVal = oFileMap.getLFromDataValue().intValue();
	           int iToVal = oFileMap.getLToDataValue().intValue();
	
	           strCol.append(strColName +" " + " Position("+ iFromVal+ ":"+iToVal+")");
	
	           if(i != (alFileMap.size()-1))
	               strCol.append(", \n");
	
	       }// end of for
	   } // end of 'if'
	   else //for iFormat 'delimited-type'
	   {
		 if(iFormat == BPConstants.BATCH_PROCESS_DELIMITED)
		 {
		 	log.debug("DELIMITED FORMAT --------------");
			strDelimiter = oDataResult.getDelimiter();
			alFileMap = oDataResult.getAlFileDataMap();
			ArrayList alTableDefResult = oDataResult.getAlTableDefResult();
			log.debug("alFileMap.size() "+alFileMap.size());
			strInsertForDelimiter = " FIELDS TERMINATED BY \"" + strDelimiter + 
              "\"  OPTIONALLY ENCLOSED BY '\"' trailing nullcols "+ "\n";
			log.debug("strInsertForDelimiter-----------------"+strInsertForDelimiter);
			
			// code for sorting the FileDataMap on the basis of the column sequence.
			for(int i=0;i < alFileMap.size()-1; i++)
			{
			  FileDataMap oFileMapTemp1 = (FileDataMap)(alFileMap.get(i));
			  log.debug("oFileMapTemp1 5555555555555555555555 :::  " + oFileMapTemp1 + 
                        "alFileMap.size(): " + alFileMap.size());
              
              log.debug("oFileMapTemp1.getColumnSequence()= " + oFileMapTemp1.getColumnSequence());
			  iColumnSeq1 = oFileMapTemp1.getColumnSequence().intValue();
			  int iMin = i;
			  
			  log.debug("alFileMap.size()=======================" + alFileMap.size());
		 	  for(int j=i+1; j < alFileMap.size(); j++)
		 	  {
				log.debug("alFileMap.size() :: " +alFileMap.size());
				FileDataMap oFileMapTemp2 = (FileDataMap)(alFileMap.get(j));
				log.debug("############################ oFileMapTemp2 :: " +oFileMapTemp2 + 
				          "%%%%%%%%%%%%%%%%%% colSeq" + oFileMapTemp2.getColumnSequence());
				iColumnSeq2 = oFileMapTemp2.getColumnSequence().intValue();	
				
				
				if(iColumnSeq1 > iColumnSeq2)
				{
				  iMin = j;		  
				}
		 	  }	// end of 'inner-for'	
		 	  
		 	  if(iMin != i) // swap the FileDataMap objects if required.
		 	  {
		 	  	log.debug("$$$$$$$$$$  iMin " +iMin);
		 	  	FileDataMap oFDM = oFileMapTemp1;
				alFileMap.set(i,alFileMap.get(iMin));
				alFileMap.set(iMin,oFDM);	
				log.debug("Sorted the FileDataMap");
				
				TableDefResult tempTableDef = (TableDefResult)alTableDefResult.get(i);
				alTableDefResult.set(i,alTableDefResult.get(iMin));
				alTableDefResult.set(iMin,tempTableDef);
				log.debug("Sorted Table Def Result");
		 	  }
				
			} // end of 'outer-for'
	       log.debug("alFileMap.size() ***************** " + alFileMap.size());
	       //code for inserting the individual column structure into the Control-file :
			for(int i=0; i < alFileMap.size(); i++)
			{			
				log.debug("1 .in loop ******** " + alFileMap.size());
				FileDataMap oFileMap = (FileDataMap)(alFileMap.get(i));
				log.debug("2 ******** " + alFileMap.size());				
				TableDefResult oTableDefResult = (TableDefResult)alTableDefResult.get(i);
				log.debug("3. ******** " + alFileMap.size());				
	
				String strColName = oFileMap.getStrColName();
				log.debug("Column Name ---"+strColName);
				String strDataType = oTableDefResult.getDataType();
				log.debug("########  Data Type --"+strDataType); 
				
				if(strDataType.equalsIgnoreCase("DATE"))
				{
					strDataType = strDataType + " " + "'dd/mm/rrrr'";				
					log.debug("Data Type ************** ---"+strDataType);
				}
				else
				{
					strDataType = "";
				}
	
				strCol.append(strColName + " " + strDataType ); 
//				strCol.append(strColName + " " );	//TEMPORARILY COMMENTED
	
				if(i != (alFileMap.size()-1))
					strCol.append(", \n");
	
			}// end of for		 	
		 }
	   }

       strFinal = strStart + strInsertForDelimiter + strSTART_BRACKET + strCol + strEnd;
       log.debug("strFinal : --"+strFinal);

       ctlFileName = strBatchPrcUrl + fileNameWithoutExtn + ".ctl";
       log.debug("CTL file Name :--"+ctlFileName);

       try
       {

		   File fr = new File(ctlFileName);
				  if(fr.exists())
				  {
				  	fr.delete();
				  }
				
            RandomAccessFile raf = new RandomAccessFile(ctlFileName,"rw");

           raf.writeBytes(strFinal);
           raf.close();
       }
       catch(IOException ioe)
       {
           //BP1013=Error while creating the Control File for SQL Loader Process
           throw new EElixirException(ioe,"Error while creating the ctl file","BP1013");
       }
       
      
       log.exit("UploadDAX","createControlFile","End---");
       return ctlFileName;

   }// end of createControlFile

   /**
    * This method inserts a record in COM_PRC_DATA_MAP when nIsMapped = 0, so as
    * to store the mapping values specified by the user and updates the
    * COM_BATCH_PRC_M 's nIsMapped = 1 as the mapping is a already specified
    * @param oDataResult
    * @return the value of execution
    * @throws EElixirException
    */
   private int createBatchPrcDataMap(DataResult oDataResult) throws EElixirException
   {
       PreparedStatement oPreparedStatement = null, oPreparedStatement1 = null;
       String strInsertSql = null;
       String strUpdateSql = null;
       int result=0;
	   int iFormat = oDataResult.getFormat().intValue();
       try
       {
           log.entry("UploadDAX","createBatchPrcDataMap","Begin--" );
		   
           strInsertSql = getSQLString("Insert",BPConstants.INSERT_BATCH_PRC_DATA_MAP);
           log.debug("UploadDAX","createBatchPrcDataMap"," strInsertSql : "+ strInsertSql);

           Collection clFileDataMap = oDataResult.getAlFileDataMap();
           log.debug("clFileDataMap --"+clFileDataMap);
           Iterator itFileDataMap = clFileDataMap.iterator();
           log.debug("itFileDataMap --"+itFileDataMap);

           log.debug("Batch Prc Seq No --"+oDataResult.getLBatchPrcSeq());

           while(itFileDataMap.hasNext())
           {
               log.debug("Inside While ---");
               FileDataMap oFileDataMap = (FileDataMap)itFileDataMap.next();
			
			 
               Object[] oArr =
               {
                   oDataResult.getLBatchPrcSeq(),
                   oFileDataMap.getStrColName(),
                   oFileDataMap.getLFromDataValue(),
                   oFileDataMap.getLToDataValue(),
                   oDataResult.getStrUserId(),
                   oDataResult.getStrUserId()
               };

               int[] iArr =
               {
                   Types.NUMERIC,
                   Types.VARCHAR,
                   Types.NUMERIC,
                   Types.NUMERIC,
                   Types.VARCHAR,
                   Types.VARCHAR
               };

               oPreparedStatement =
                       this.getPreparedStatement(strInsertSql, oArr, iArr);
               log.debug("Before execute update--"+oPreparedStatement);
               result = executeUpdate(oPreparedStatement);
               log.debug("result of insert in the detail......"+result);

           }// end of while

           log.debug("Before Upadting the  header com_batch_prc_m @@@@@@@@@@@@@@");
           // Update the com_batch_prc_m for nIsMapped = 1, as the mapping record
           // is inerted
           strUpdateSql = getSQLString("Update",BPConstants.UPDATE_BATCH_PRC_HDR);
           log.debug("UploadDAX","update Header"," strUpdateSql : "+ strUpdateSql);

           Object[] oArr1 =
           {
               new Short("1"),
               oDataResult.getStrUserId(),
               oDataResult.getLBatchPrcSeq()
           };

           int[] iArr1 =
           {
               Types.NUMERIC,
               Types.VARCHAR,
               Types.NUMERIC,
           };

           log.debug("Value of isMapped in Array ---------"+oArr1[0]);
           oPreparedStatement1 =
                   this.getPreparedStatement(strUpdateSql, oArr1, iArr1);
           log.debug("Before execute update--"+oPreparedStatement1);
           result = executeUpdate(oPreparedStatement1);
           log.debug("Result of Updating the Header for nIsMapped --- "+result);

           log.exit("UploadDAX","createBatchPrcDataMap","oJobViewResult : " );
           return result;
       }// end try
       catch(SQLException sqlex)
       {
           //BP1018=Error while inserting the record for the Data Column Mapping
           log.fatal("UploadDAX","createBatchPrcDataMap",
                     sqlex.getMessage());
           throw new EElixirDAXException(sqlex, "BP1018");
       }
       finally
       {
           try
           {
               if(oPreparedStatement != null)
                   oPreparedStatement.close();
           }
           catch(SQLException sqlex)
           {
               log.fatal("UploadDAX","createBatchPrcDataMap",
                         sqlex.getMessage());
               throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
           }
       }
   }// end of createBatchPrcDataMap

   /**
    * This method inserts a record in the com_prc_result table before the
    * upload process begins with the status as Started.
    * @param con Connection Object
    */
   public int createPrcResult(DataResult oDataResult) throws EElixirException
   {
       PreparedStatement oPreparedStatement = null;
       String strInsertSql = null;

       try
       {
           log.entry("UploadDAX","createPrcResult","Begin--" );
           /**
            * The job id i.e. the sequence no in com_prc_result is
            * craeted before the process is started, so in this method the
            * DataResult will have this value set in this object.
            * As this id is required to be shown to the user indicating the
            * process has started with a unique id and it can be futher used for
            * viweing the result of the upload process.
            * */
           //long seqNo = getNextBatchPrcResultNbr();
           long seqNo = oDataResult.getLPrcResultSeq().longValue();
           log.debug("After getting the seq no ");

           strInsertSql = getSQLString("Insert",BPConstants.INSERT_BATCH_PRC_RESULT);
           log.debug("UploadDAX","createPrcResult"," strInsertSql : "+ strInsertSql);

           Object[] oArr =
           {
               new Long(seqNo),
               new Integer(BPConstants.BP_TYPE_UPLOAD),
               oDataResult.getLBatchPrcSeq(),
               new Integer(BPConstants.BP_EXC_STATUS_STARTED),
               oDataResult.getStrUserId(),
               oDataResult.getStrUserId()
           };

           int[] iArr =
           {
               Types.NUMERIC,
               Types.NUMERIC,
               Types.NUMERIC,
               Types.NUMERIC,
               Types.VARCHAR,
               Types.VARCHAR
           };

           oPreparedStatement =
                   this.getPreparedStatement(strInsertSql, oArr, iArr);

           int result = executeUpdate(oPreparedStatement);
           log.debug("result of insert......"+result);

           log.exit("UploadDAX","createPrcResult","oJobViewResult : " );

           return result;
       }// end try
       catch(SQLException sqlex)
       {
           //BP1015=Error while inserting the record in the process result
           //with the status as Started
           log.fatal("UploadDAX","createPrcResult",
                     sqlex.getMessage());
           throw new EElixirDAXException(sqlex, "BP1015");
       }
       finally
       {
           try
           {
               if(oPreparedStatement != null)
                   oPreparedStatement.close();
           }
           catch(SQLException sqlex)
           {
               log.fatal("UploadDAX","createPrcResult",
                         sqlex.getMessage());
               throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
           }
       }

   }// end of createPrcResult

   /**
    * This method updates the com_prc_result table after the upload process has
    * completed.
    * @param oDataResult
    * @param a_oLogDataVal
    */
   public int updatePrcResult(DataResult oDataResult, LogDataValue a_oLogDataVal)
           throws EElixirException
   {
       PreparedStatement oPreparedStatement = null;
       String strUpdateSql = null;
	long lRecordsDiscarded = 0;
	long lRecordsRead =0;
	long lRecordsRejected = 0;
	long lRecordsSkipped =0;

       try
       {
           log.entry("UploadDAX","updatePrcResult","Begin--" );

           log.debug("Get the parsed values ");
           
           

           String strElapsedTime = a_oLogDataVal.getStrElapsedTime();
         
           String strEndTime = a_oLogDataVal.getStrEndTime();
           

		if(a_oLogDataVal.getLRecordsDiscarded() != null)
		{
			lRecordsDiscarded = a_oLogDataVal.getLRecordsDiscarded().longValue();	 
		}
            
		if(a_oLogDataVal.getLRecordsRead() != null)
		{
			lRecordsRead = a_oLogDataVal.getLRecordsRead().longValue();
		}

			if(a_oLogDataVal.getLRecordsRejected() != null)
			{
				lRecordsRejected = a_oLogDataVal.getLRecordsRejected().longValue();
			}

		if(a_oLogDataVal.getLRecordsSkipped() != null)
		{
			lRecordsSkipped = a_oLogDataVal.getLRecordsSkipped().longValue();
		}
         
           
log.debug("After Getting all the values");
           // endtime conversion

           // get the total no of rows

           long lTotalRows = lRecordsRead +
                             lRecordsDiscarded +
                             lRecordsRejected +
                             lRecordsSkipped;

           log.debug("Total NO Of Rows "+lTotalRows);

           // get the no of rows inserted
           long lRowsInserted = lRecordsRead;
           log.debug("Rows Inserted "+lRowsInserted);

           // get the no of rows rejected
           long lRowsRejected = lTotalRows - lRowsInserted;
           log.debug("Rows Rejected "+lRowsRejected);

           int statusOfCompletion= -1;
           /**
            * The status of the upload process is determined as follows
            * lTotalRows == lRowsInserted , status --> Successfully Completed
            * lRowsRejected != 0 , status --> completed with errors
            * else status --> terminated due to some exception or error
            * */
           if(lTotalRows == lRowsInserted)
               statusOfCompletion = BPConstants.BP_EXC_STATUS_COMPLETED;
           else if(lRowsRejected != 0)
               statusOfCompletion = BPConstants.BP_EXC_STATUS_COMPLETED_WITH_ERRORS;
           else
               statusOfCompletion = BPConstants.BP_EXC_STATUS_TERMINATED;

           strUpdateSql = getSQLString("Update",BPConstants.UPDATE_BATCH_PRC_RESULT);
           log.debug("UploadDAX","updatePrcResult"," strUpdateSql : "+ strUpdateSql);

           log.debug("Process Result Seq No "+oDataResult.getLPrcResultSeq().longValue());

           Object[] oArr =
           {
               new Long(lTotalRows),
               new Long(lRowsInserted),
               new Long(lRowsRejected),
               strElapsedTime,
               new Integer(statusOfCompletion),
               oDataResult.getStrLogFile(),
               oDataResult.getStrUserId(),
               oDataResult.getLPrcResultSeq()
           };

           int[] iArr =
           {
               Types.NUMERIC,
               Types.NUMERIC,
               Types.NUMERIC,
               Types.VARCHAR,
               Types.NUMERIC,
               Types.VARCHAR,
               Types.VARCHAR,
               Types.NUMERIC
           };

           log.debug("Log File "+oDataResult.getStrLogFile());
           log.debug("User Id"+oDataResult.getStrUserId());
           log.debug("Pr Result Seq"+oDataResult.getLPrcResultSeq());

           oPreparedStatement =
                   this.getPreparedStatement(strUpdateSql, oArr, iArr);

           int result = executeUpdate(oPreparedStatement);
           log.debug("result of update......"+result);

           log.exit("UploadDAX","updatePrcResult","Exit" );
           EElixirUtils.reloadMaster("AccountCode");

           return result;
       }// end try
       catch(SQLException sqlex)
       {
           //BP1016=Error while updating the record in the process result.
           log.fatal("UploadDAX","updatePrcResult",
                     sqlex.getMessage());
           throw new EElixirDAXException(sqlex, "BP1016");
       }
       finally
       {
           try
           {
               if(oPreparedStatement != null)
                   oPreparedStatement.close();
           }
           catch(SQLException sqlex)
           {
               log.fatal("UploadDAX","updatePrcResult",
                         sqlex.getMessage());
               throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
           }
       }

   }// end of updatePrcResult

   /**
    * Method will read the log file created by the SQL Loader and read the file
    * get the end time, no of records inserted, rejected from the log file
    */
   public LogDataValue parseLogFile(DataResult a_oDataResult) throws EElixirException
   {
       String strElapsedTime="", strEndTime="";
       String strRecordsRead="", strRecordsSkipped="";
       String strRecordsRejected="",strRecordsDiscarded="";

       LogDataValue oLogDataVal = new LogDataValue();
       FileReader fr =null;
       BufferedReader br =null;
       try
       {
           log.entry("UploadDAX","parseLogFile","Entry-----");
           
           
          String strLogFileNames = a_oDataResult.getStrLogFile();
           log.debug("Log File Name ---"+strLogFileNames);

           // create a file reader
            fr = new FileReader(new File(strLogFileNames));
           // create a buffered reader
            br = new BufferedReader(fr);

           String s,s2 = new String();

           while((s = br.readLine())!= null)
           {
                s2=s;

                if(s2 != null && (!s2.equals("")))
               {
                    /**
                     * Check if the string contains the string for elapsed time
                     * */
                    if((s2.indexOf(ELAPSED_TIME)) != -1)
                   {
                        int startIndex = s2.indexOf(ELAPSED_TIME) +ELAPSED_TIME.length();
                        //log.debug("startIndex -- "+startIndex);

                        String s3 = s2.substring(startIndex, s2.length());
                        log.debug("EQUALS ELAPSED_TIME---"+s3);
                        strElapsedTime = parseValue(s3);
                        log.debug("strRecordsDiscarded --"+strRecordsDiscarded);
                        oLogDataVal.setStrElapsedTime(strElapsedTime);
                   }
                   /**
                    * Check if the string contains the string for rum ended
                    * */
                   if((s2.indexOf(RUN_ENDED)) != -1)
                  {
                       int startIndex = s2.indexOf(RUN_ENDED) +RUN_ENDED.length();
                       //log.debug("startIndex -- "+startIndex);

                       String s3 = s2.substring(startIndex, s2.length());
                       log.debug("EQUALS RUN_ENDED---"+s3);
                       strEndTime = parseValue(s3);
                       log.debug("strEndTime --"+strEndTime);
                       oLogDataVal.setStrEndTime(strEndTime);
                  }
                  /**
                   * Check if the string contains the string for records discarded
                   * */
                  if((s2.indexOf(RECORDS_DISCARDED)) != -1)
                 {
                      int startIndex = s2.indexOf(RECORDS_DISCARDED) +RECORDS_DISCARDED.length();
                      //log.debug("startIndex -- "+startIndex);

                      String s3 = s2.substring(startIndex, s2.length());
                      log.debug("EQUALS RECORDS_DISCARDED---"+s3);
                      strRecordsDiscarded = parseValue(s3);
                      log.debug("strRecordsDiscarded ---"+strRecordsDiscarded);

                      if(strRecordsDiscarded != null &&
                         (!strRecordsDiscarded.equals("")))
                      {
                          oLogDataVal.setLRecordsDiscarded(new Long(strRecordsDiscarded));
                      }
                      else
                          oLogDataVal.setLRecordsDiscarded(null);
                 }
                 /**
                  * Check if the string contains the string for records read
                  * */
                 if((s2.indexOf(RECORDS_READ)) != -1)
                {
                     int startIndex = s2.indexOf(RECORDS_READ) +RECORDS_READ.length();
                     //log.debug("startIndex -- "+startIndex);

                     String s3 = s2.substring(startIndex, s2.length());
                     log.debug("EQUALS RECORDS_READ---"+s3);
                     strRecordsRead = parseValue(s3);
                     log.debug("strRecordsRead --"+strRecordsRead);

                     if(strRecordsRead != null &&
                        (!strRecordsRead.equals("")))
                     {
                         oLogDataVal.setLRecordsRead(new Long(strRecordsRead));
                     }
                     else
                         oLogDataVal.setLRecordsRead(null);
                }

                /**
                 * Check if the string contains the string for records rejected
                 * */
                if((s2.indexOf(RECORDS_REJECTED)) != -1)
               {
                    int startIndex = s2.indexOf(RECORDS_REJECTED) +RECORDS_REJECTED.length();
                    //log.debug("startIndex -- "+startIndex);

                    String s3 = s2.substring(startIndex, s2.length());
                    log.debug("EQUALS RECORDS_REJECTED---"+s3);
                    strRecordsRejected = parseValue(s3);
                    log.debug("strRecordsRejected --"+strRecordsRejected);

                    if(strRecordsRejected != null &&
                       (!strRecordsRejected.equals("")))
                    {
                        oLogDataVal.setLRecordsRejected(new Long(strRecordsRejected));
                    }
                    else
                        oLogDataVal.setLRecordsRejected(null);
               }
               /**
                * Check if the string contains the string for records skipped
                * */
               if((s2.indexOf(RECORDS_SKIPPED)) != -1)
              {
                   int startIndex = s2.indexOf(RECORDS_SKIPPED) +RECORDS_SKIPPED .length();
                   //log.debug("startIndex -- "+startIndex);

                   String s3 = s2.substring(startIndex, s2.length());
                   log.debug("EQUALS RECORDS_SKIPPED---"+s3);
                   strRecordsSkipped = parseValue(s3);
                   log.debug("strRecordsSkipped--"+strRecordsSkipped);

                   if(strRecordsSkipped != null &&
                      (!strRecordsSkipped.equals("")))
                   {
                       oLogDataVal.setLRecordsSkipped(new Long(strRecordsSkipped));
                   }
                   else
                       oLogDataVal.setLRecordsSkipped(null);
              }

               }// end of if

           }// end of while
      }
       catch(Exception eex)
       {
           log.debug("Exception in parseLogFile"+eex);
           throw new EElixirException(eex,"Error in parseLogFile");
       }
//     FindBug_Fix_SUNAINA_STARTS
       finally
       {
    	   try {
			fr.close();
			 br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    	   
       }
//     FindBug_Fix_SUNAINA_ENDS
       return oLogDataVal;
   }// end of parseLogFile

   /**
   *
   *	This method parses the value obtained for that particular key.
   *	It removes white spaces and any other junk characters from value and returns absolute string.
   *	@param value - String value which is to be parsed.
   *	@return String - Parsed value.
   */

   public String parseValue(String value)
   {
       char [] arr = value.toCharArray();
       String finalValue = "";
           for (int i=0;i<arr.length ;i++ )
           {
               if ( !Character.isSpaceChar(arr[i]) )
               {
                   if ( Character.isLetter(arr[i]) || Character.isDigit(arr[i])  )
                   {
                       finalValue = finalValue + String.copyValueOf(arr,i,arr.length-i);
                       break;
                   }
               }
           }
           log.debug("Parsed value is "+finalValue);
           return finalValue;
	}// end of parseValue


  public Short getProcedureSeqNbr(DataResult a_oDataResult) throws EElixirException
  {
  	 Short nProcSeqNbr = null;
	log.entry("UploadDAX","getProcedureSeqNbr","Entered **********");  	
	ResultSet rsSeqNbr = null;
	String strQuery = getSQLString("Select",BPConstants.SEARCH_PROC_SEQ_NBR);
	long lBatchPrcSeq = a_oDataResult.getLBatchPrcSeq().longValue();
	PreparedStatement pstmtSearch = getPreparedStatement(strQuery);	
	try
	{	
		pstmtSearch.setLong(1,lBatchPrcSeq);
		rsSeqNbr = pstmtSearch.executeQuery();
		if(rsSeqNbr.next())
		{
			nProcSeqNbr = new Short(rsSeqNbr.getShort("nProcSeq"));
			if(rsSeqNbr.wasNull())
			{
				nProcSeqNbr = null;	
			}		
		}
	}
	catch(SQLException sqlex)
	{
	   log.debug("In  getProcedureSeqNbr :: In sqlexception ::: " + sqlex);	 	
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex, "MM902");
	} 
  	 
	log.exit("UploadDAX","getProcedureSeqNbr","exiting **********" + nProcSeqNbr);  	  	 
  	return nProcSeqNbr;
  }


  /**
   * This method first looks into the com_batch_prc_m for a sequence number against 
   * lBatchPrcSeq.Once it gets this sequence number it calls the required 
   * procedures depending upon this sequence number
   * @param a_oDataResult
   * @return boolean 
   */
   public boolean callProceduresAfterUpload(DataResult a_oDataResult) throws EElixirException
   {
	log.entry("UploadDAX","callProceduresAfterUpload","Entered ");   	
	 boolean bIsSuccessful = true;	 
	 short nProcSeq = 0;
	 String strDataFile = null;
	
	 long lBatchPrcSeq = a_oDataResult.getLBatchPrcSeq().longValue();
	 
	 strDataFile = a_oDataResult.getStrDataFile();	 
	 String strLocationCd= a_oDataResult.getLocationCd();
 	 log.debug("IN Upload DAX :: callProceduresAfterUpload :: lBatchPrcSeq= "+
	  lBatchPrcSeq + "## strLocationCd ::: " + strLocationCd+
	  "## strDataFile  :::"+strDataFile );	
	   
	 int iErrorCode1 = BPConstants.FLAG_FOR_PROC_SUCCESS;
	 int iErrorCode2 = BPConstants.FLAG_FOR_PROC_SUCCESS;
	 int iErrorCode3 = BPConstants.FLAG_FOR_PROC_SUCCESS;
	 
	 
	/*  Variables for calling stored procedures  */
  	
	 PropertyUtil oPropertyUtil = new PropertyUtil(Constants.SETUP_FILE);
	 String strDirectoryPath = oPropertyUtil.getProperty("upload.dir.in");
	 String strOracleDirectoryPath = oPropertyUtil.getProperty("download.oracle.dir");
	 String strMoveDirectoryPath = oPropertyUtil.getProperty("move.dir.in"); 
	 String strUserId = a_oDataResult.getStrUserId();
log.debug("user id from callProceduresAfterUpload " + strUserId);
log.debug("strDirectoryPath from callProceduresAfterUpload " + strDirectoryPath);
log.debug("strOracleDirectoryPath from callProceduresAfterUpload " + strOracleDirectoryPath);
log.debug("strMoveDirectoryPath from callProceduresAfterUpload " + strMoveDirectoryPath);
	 long lPrcResultSeq = 0;
	 if(a_oDataResult.getLPrcResultSeq() != null)
	 {
		lPrcResultSeq = a_oDataResult.getLPrcResultSeq().longValue();
	 }
	 long lCashBankSeqNbr = 0;
	 Date dtStatement = null;
	 String strProcedure = null;  	 
	 CallableStatement oCallableStatement1 = null;
	 CallableStatement oCallableStatement2 = null;
	 CallableStatement oCallableStatement3 = null;  	  	  
  	
	/*  Variables for calling stored procedures  */  	 
	  
	 try
	 {
/*		pstmtSearch.setLong(1,lBatchPrcSeq);
		rsSeqNbr = pstmtSearch.executeQuery();
		
		if(rsSeqNbr.next())
		{
			nProcSeq = rsSeqNbr.getShort("nProcSeq");
			log.debug("******************************  nProcSeq " +nProcSeq);
		}
*/		
		if(a_oDataResult.getProcSeqNbr() != null)
		{		
			nProcSeq = a_oDataResult.getProcSeqNbr().shortValue();
log.debug("nProcSeq from upload dax-------------->"+nProcSeq);			
		}
		else
		{
			nProcSeq = getProcedureSeqNbr(a_oDataResult).shortValue();
		}
		
		int i =9;
		
		switch(nProcSeq)
		{
			case BPConstants.PROC_SEQ_FOR_BANK_STMT_UPLOAD :
			
log.debug("Bank Statement Upload:  Preparing to call the procedures");		 
			  
				 strProcedure = getSQLString("Select",BPConstants.PROC_BANK_STMT_UPLOAD_TEMP);
log.debug("Bank Statement Upload First Proc :"+ strProcedure);				 		  
				 oCallableStatement1 = getCallableStatement(strProcedure);
				 log.debug("the procedure is -> " + strProcedure);
				 oCallableStatement1.setString(1,strUserId);
				 oCallableStatement1.setString(2,strDataFile);
				 oCallableStatement1.registerOutParameter(3,Types.INTEGER);  
				 oCallableStatement1.registerOutParameter(4,Types.VARCHAR); 
				 oCallableStatement1.execute();
				 if(oCallableStatement1.getObject(3) != null)
				 {
					iErrorCode1 = oCallableStatement1.getInt(3);
log.debug("Bank Statement Upload Error code 1 :"+ iErrorCode1);
log.debug("Bank Statement Upload Error Desc 1 :"+ oCallableStatement1.getString(4));					  	
				 }
			     if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
			     {
			     	
				    strProcedure = getSQLString("Select",BPConstants.PROC_BANK_STMT_UPLOAD);		  
log.debug("Bank Statement Upload Second Proc :"+ strProcedure);
					oCallableStatement2 = getCallableStatement(strProcedure);
					oCallableStatement2.setString(1,strUserId);
					oCallableStatement2.setLong(2,lPrcResultSeq);
					oCallableStatement2.setString(3,strOracleDirectoryPath);		
					oCallableStatement2.setString(4,strDataFile);
					oCallableStatement2.registerOutParameter(5,Types.DATE); 
					oCallableStatement2.registerOutParameter(6,Types.BIGINT); 		   
					oCallableStatement2.registerOutParameter(7,Types.INTEGER); 
					oCallableStatement2.registerOutParameter(8,Types.VARCHAR);
					oCallableStatement2.execute(); 
					if(oCallableStatement2.getObject(5)!=null) 
					dtStatement = oCallableStatement2.getDate(5); 
					if(oCallableStatement2.getObject(6)!=null) 
					lCashBankSeqNbr = oCallableStatement2.getLong(6); 
				  	if(oCallableStatement2.getObject(7) != null)
					{
					  iErrorCode2 = oCallableStatement2.getInt(7);  
log.debug("Bank Statement Upload Error code 2 :"+ iErrorCode2);
log.debug("Bank Statement Upload Error Desc 2 :"+ oCallableStatement2.getString(8));		
					  
					}					 
				   	if(iErrorCode2 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{				   	   
					  strProcedure = getSQLString("Select",BPConstants.PROC_BANK_RECONCILIATION);
log.debug("Bank Statement Upload third Proc :"+ strProcedure);
					  oCallableStatement3 = getCallableStatement(strProcedure);
					  oCallableStatement3.setString(1,strUserId);				  				 
					  oCallableStatement3.setLong(2,lCashBankSeqNbr);		
					  oCallableStatement3.setDate(3,dtStatement);
					  oCallableStatement3.setString(4,strOracleDirectoryPath);
					  oCallableStatement3.setString(5,strDataFile);
					  oCallableStatement3.registerOutParameter(6,Types.INTEGER); 
					  oCallableStatement3.registerOutParameter(7,Types.VARCHAR); 
					  oCallableStatement3.execute(); 	
					  if(oCallableStatement3.getObject(6) != null)
					  {
					 	iErrorCode3 = oCallableStatement3.getInt(6);
log.debug("Bank Statement Upload Error code 3 :"+ iErrorCode3);	
log.debug("Bank Statement Upload Error Desc 3 :"+ oCallableStatement3.getString(7));						 	  	
					  }	
					}
			      }
			      break;
		
			case BPConstants.PROC_SEQ_FOR_INSTR_UPLOAD : 
log.debug("Instrument Upload:  Preparing to call the procedures");		 
				  strProcedure = getSQLString("Select",BPConstants.PROC_INSTRUMENT_UPLOAD_TEMP);		  
log.debug("Instrument Upload first Proc :"+ strProcedure);				 
				  oCallableStatement1 = getCallableStatement(strProcedure);
				  oCallableStatement1.setString(1,strUserId);	
			      oCallableStatement1.setInt(2,BPConstants.FOR_INSTRUMENT_UPLOAD);
			      oCallableStatement1.setString(3,strDataFile);
				  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
			      oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				  oCallableStatement1.execute(); 	
				  if(oCallableStatement1.getObject(4) != null)
				  {
				    iErrorCode1 = oCallableStatement1.getInt(4);  
log.debug("Instrument Upload Error code 1 :"+ iErrorCode1);	
log.debug("Instrument Upload Error Desc 1 :"+ oCallableStatement1.getString(5));				    
				  }					  
				  
				  if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				  {				  
					  strProcedure = getSQLString("Select",BPConstants.PROC_INSTRUMENT_UPLOAD);
log.debug("Instrument Upload second Proc :"+ strProcedure);
					  oCallableStatement3 = getCallableStatement(strProcedure);
					  oCallableStatement3.setString(1,strUserId);
					  oCallableStatement3.setString(2,strOracleDirectoryPath);
					  oCallableStatement3.setString(3,strDataFile);
					  oCallableStatement3.setString(4,strLocationCd);
					  oCallableStatement3.registerOutParameter(5,Types.INTEGER); 
					  oCallableStatement3.registerOutParameter(6,Types.VARCHAR); 
					  oCallableStatement3.execute(); 
					  if(oCallableStatement3.getObject(5) != null)
					  {
					    iErrorCode2 = oCallableStatement3.getInt(5);  
log.debug("Instrument Upload Error code 2 :"+ iErrorCode2);
log.debug("Instrument Upload Error Desc 2 :"+ oCallableStatement3.getString(6) );
					  }	
				  }
				  break;
				  case BPConstants.PROC_SEQ_FOR_ECS_UPLOAD :
log.debug("ECS Upload:  Preparing to call the procedures");
	
				  strProcedure = getSQLString("Select",BPConstants.PROC_INSTRUMENT_UPLOAD_TEMP);		  
log.debug("ECS Upload first Proc :"+ strProcedure);

				  oCallableStatement1 = getCallableStatement(strProcedure);
				  log.debug("the procedure is -> " + strProcedure);
				  oCallableStatement1.setString(1,strUserId);
			      oCallableStatement1.setInt(2,BPConstants.FOR_ECS_AND_CR_DR_UPLOAD);	
				  oCallableStatement1.setString(3,strDataFile);			  	
				  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				  oCallableStatement1.execute();
				  if(oCallableStatement1.getObject(4) != null)
				  {
				    iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("ECS Upload Error code 1 :"+ iErrorCode1);
log.debug("ECS Upload Error Desc 1 :"+ oCallableStatement1.getString(5));	
				  }	
				  
				  if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
			      {				  
					  strProcedure = getSQLString("Select",BPConstants.PROC_ECS_STMT_UPLOAD);
log.debug("ECS Upload second Proc :"+ strProcedure);

					  oCallableStatement3 = getCallableStatement(strProcedure);
					  log.debug("the procedure is -> " + strProcedure);
					  oCallableStatement3.setString(1,strUserId);
				      oCallableStatement3.setString(2,strOracleDirectoryPath);
				      oCallableStatement3.setString(3,strLocationCd);
				      oCallableStatement3.setShort(4,BPConstants.INSTRUMENT_TYPE_CD_FOR_ECS);
					  oCallableStatement3.setString(5,strDataFile);						  
					  oCallableStatement3.registerOutParameter(6,Types.INTEGER); 
					  oCallableStatement3.registerOutParameter(7,Types.VARCHAR); 
					  oCallableStatement3.execute(); 	
					  if(oCallableStatement3.getObject(6) != null)
					  {
					    iErrorCode2 = oCallableStatement3.getInt(6);
log.debug("Ecs Upload Error code 2 :"+ iErrorCode2);
log.debug("Ecs Upload Error Desc 2 :"+ oCallableStatement3.getString(7));
					  }	
			      }
				  break;
				  
			//case BPConstants.PROC_SEQ_FOR_DR_UPLOAD : 
		
			case BPConstants.PROC_SEQ_FOR_CR_DR_UPLOAD :
log.debug("CRDR Upload:  Preparing to call the procedures");
				  strProcedure = getSQLString("Select",BPConstants.PROC_INSTRUMENT_UPLOAD_TEMP);		  
				  oCallableStatement1 = getCallableStatement(strProcedure);
log.debug("CRDR Upload first Proc :"+ strProcedure);
				  oCallableStatement1.setString(1,strUserId);	
			      oCallableStatement1.setInt(2,BPConstants.FOR_ECS_AND_CR_DR_UPLOAD);
			      oCallableStatement1.setString(3,strDataFile);		
				  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				  oCallableStatement1.execute();		
				  if(oCallableStatement1.getObject(4) != null)
				  {
			  	    iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("CRDR Upload Error code 1 :"+ iErrorCode1);
log.debug("CRDR Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
			      }					  
				  if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				  {				  
					  strProcedure = getSQLString("Select",BPConstants.PROC_CRDR_CARD_SI_UPLOAD);		  
log.debug("CRDR Upload second Proc :"+ strProcedure);

					  oCallableStatement3 = getCallableStatement(strProcedure);
					  oCallableStatement3.setString(1,strUserId);
					  oCallableStatement3.setString(2,strOracleDirectoryPath);
				      oCallableStatement3.setString(3,strLocationCd);
					  oCallableStatement3.setString(4,strDataFile);		
				      oCallableStatement3.registerOutParameter(5,Types.INTEGER);  
					  oCallableStatement3.registerOutParameter(6,Types.VARCHAR); 
					  oCallableStatement3.execute(); 	
					  if(oCallableStatement3.getObject(5) != null)
					  {
					    iErrorCode2 = oCallableStatement3.getInt(5);
log.debug("CRDR Upload Error code 2 :"+ iErrorCode2);
log.debug("CRDR Upload Error Desc 2 :"+ oCallableStatement3.getString(6));
					  }	
				  }
				  break;	
				  
			case BPConstants.PROC_SEQ_FOR_JV_OTHER_UPLOAD:
log.debug("jv other Upload:  Preparing to call the procedures");
				  strProcedure = getSQLString("Select",BPConstants.PROC_JV_TEMP_UPLOAD);
log.debug("jv other Upload first Proc :"+ strProcedure);
				  oCallableStatement1 = getCallableStatement(strProcedure);
				  oCallableStatement1.setString(1,strUserId);	
				  oCallableStatement1.setString(2,strOracleDirectoryPath);
			      oCallableStatement1.setString(3,strDataFile);		
				  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				  oCallableStatement1.execute(); 	
				  if(oCallableStatement1.getObject(4) != null)
				  {
					iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("jv other Upload Error code 1 :"+ iErrorCode1);
log.debug("jv other Upload Error Desc 1 :"+ oCallableStatement1.getString(5));	
				  }					  
				  
				  if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				  {				  
					  strProcedure = getSQLString("Select",BPConstants.PROC_JV_OTHER_UPLOAD);		  
log.debug("jv other Upload second Proc :"+ strProcedure);
					  oCallableStatement3 = getCallableStatement(strProcedure);
					  oCallableStatement3.setString(1,strUserId);
					  oCallableStatement3.setString(2,strOracleDirectoryPath);
					  oCallableStatement3.setString(3,strDataFile);		
					  oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
					  oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
					  oCallableStatement3.execute(); 
					  if(oCallableStatement3.getObject(4) != null)
					  {
						iErrorCode2 = oCallableStatement3.getInt(4);
log.debug("jv Upload Error code 2 :"+ iErrorCode2);
log.debug("jv Upload Error Desc 2 :"+ oCallableStatement3.getString(5));
					  }	
				  }
				  break;
				  
			case BPConstants.PROC_SEQ_FOR_JV_POLICY_UPLOAD: 
log.debug("Jv Policy Upload:  Preparing to call the procedures");
				  strProcedure = getSQLString("Select",BPConstants.PROC_JV_TEMP_UPLOAD);		  
log.debug("Jv Policy Upload first Proc :"+ strProcedure);
				  oCallableStatement1 = getCallableStatement(strProcedure);
				  oCallableStatement1.setString(1,strUserId);	
				  oCallableStatement1.setString(2,strOracleDirectoryPath);
				  oCallableStatement1.setString(3,strDataFile);	
				  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				  oCallableStatement1.execute(); 	
				  if(oCallableStatement1.getObject(4) != null)
				  {
					iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("Jv Policy Upload Error code 1 :"+ iErrorCode1);
log.debug("Jv Policy Upload Error Desc 1 :"+ oCallableStatement1.getString(5));	
				  }					  
				  if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				  {				  
					  strProcedure = getSQLString("Select",BPConstants.PROC_JV_POLICY_UPLOAD);
log.debug("Jv Policy Upload second Proc :"+ strProcedure);
					  oCallableStatement3 = getCallableStatement(strProcedure);
					  oCallableStatement3.setString(1,strUserId);
					  oCallableStatement3.setString(2,strOracleDirectoryPath);
					  oCallableStatement3.setString(3,strDataFile);
					  oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
					  oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
					  oCallableStatement3.execute(); 
					  if(oCallableStatement3.getObject(4) != null)
					  {
						iErrorCode2 = oCallableStatement3.getInt(4);
log.debug("Jv Policy Error code 2 :"+ iErrorCode2);
log.debug("Jv Policy Error Desc 2 :"+ oCallableStatement3.getString(5));						  	
					  }	
				  }
				  break;				 
			  case BPConstants.PROC_SEQ_FOR_ACCOUNT_UPLOAD: 
log.debug("Account Upload:  Preparing to call the procedures");

					  strProcedure = getSQLString("Select",BPConstants.PROC_ACCOUNT_CODE_UPLOAD);
log.debug("Account Upload first Proc :"+ strProcedure);

					  oCallableStatement1 = getCallableStatement(strProcedure);
					  oCallableStatement1.setString(1,strUserId);
					  oCallableStatement1.setString(2,strOracleDirectoryPath);
					  oCallableStatement1.setString(3,strDataFile);
					  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					  oCallableStatement1.execute(); 
					  if(oCallableStatement1.getObject(4) != null)
					  {
						iErrorCode2 = oCallableStatement1.getInt(4);
log.debug("Account Upload Error code 1 :"+ iErrorCode2);
log.debug("Account Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

				    
					  }	
				break;
				
 			  case BPConstants.PROC_SEQ_FOR_STARTEK_POL_UPLOAD: 
					  strProcedure = getSQLString("Select",BPConstants.PROC_STARTEK_POL_UPLOAD);		  
log.debug("Account Upload second Proc :"+ strProcedure);
					  oCallableStatement1 = getCallableStatement(strProcedure);
					  oCallableStatement1.setString(1,strUserId);	
					  oCallableStatement1.setString(2,strOracleDirectoryPath);
					  oCallableStatement1.setString(3,strDataFile);
					  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					  oCallableStatement1.execute();
					  if(oCallableStatement1.getObject(4) != null)
					  {
						iErrorCode2 = oCallableStatement1.getInt(4);  	
log.debug("Account Error code 2 :"+ iErrorCode2);
log.debug("Account Error Desc 2 :"+ oCallableStatement1.getString(5));
					  }	 	
				break;
			
				case BPConstants.PROC_SEQ_FOR_FUTURE_CRDR_UPLOAD:
log.debug("Future CRDR Upload:  Preparing to call the procedures");
			 
					  strProcedure = getSQLString("Select",BPConstants.PROC_FUTURE_CRDR_UPLOAD);		  
log.debug("Future CRDR Upload first Proc :"+ strProcedure);
					  oCallableStatement1 = getCallableStatement(strProcedure);
					  oCallableStatement1.setString(1,strUserId);	
					  oCallableStatement1.setString(2,strOracleDirectoryPath);
			          oCallableStatement1.setString(3,strDataFile);	
					  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					  oCallableStatement1.execute();
					  if(oCallableStatement1.getObject(4) != null)
					  {
						iErrorCode2 = oCallableStatement1.getInt(4);
log.debug("Future CRDR Error code 1:"+ iErrorCode2);
log.debug("Future CRDR Error Desc 1:"+ oCallableStatement1.getString(5));								  	
					  }	 	
			  	  break;
				case BPConstants.PROC_SEQ_FOR_SUN_CHQ_UPLOAD: 
log.debug("Sun CHQ Upload:  Preparing to call the procedures");
				  	  strProcedure = getSQLString("Select",BPConstants.PROC_SUN_CHQ_UPLOAD);		  
log.debug("Sun CHQ Upload first Proc :"+ strProcedure);
				  	  oCallableStatement1 = getCallableStatement(strProcedure);
				  	  oCallableStatement1.setString(1,strUserId);	
					  oCallableStatement1.setString(2,strOracleDirectoryPath);
					  oCallableStatement1.setString(3,strDataFile);	
				  	  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				  	  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				  	  oCallableStatement1.execute();
				  	  if(oCallableStatement1.getObject(4) != null)
				  	  {
						iErrorCode2 = oCallableStatement1.getInt(4);
log.debug("Sun CHQ Upload Error code 1 :"+ iErrorCode2);
log.debug("Sun CHQ Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
									  	
				  	  }	 	
			  	break;	
				
//Add By jayasimha for uploads

  				case BPConstants.PROC_SEQ_FOR_COMM_RULE_UPLOAD:
log.debug("COMM RULE Upload:  Preparing to call the procedures");
				strProcedure = getSQLString("Select",BPConstants.PROC_COMM_RULE_TEMP_UPLOAD);		  
log.debug("COMM RULE Upload first Proc :"+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1,strUserId);	
			    oCallableStatement1.setString(2,strOracleDirectoryPath);
				oCallableStatement1.setString(3,strDataFile);
				oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				oCallableStatement1.execute(); 	
				if(oCallableStatement1.getObject(4) != null)
				{
				  iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("COMM RULE  Upload Error code 1 :"+ iErrorCode1);
log.debug("COMM RULE  Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
				}					  
				  
				if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				{				  
					strProcedure = getSQLString("Select",BPConstants.PROC_COMM_RULE_MAIN_UPLOAD);
log.debug("COMM RULE  Upload second Proc :"+ strProcedure);
					oCallableStatement3 = getCallableStatement(strProcedure);
					oCallableStatement3.setString(1,strUserId);
					oCallableStatement3.setString(2,strOracleDirectoryPath);
					oCallableStatement3.setString(3,strDataFile);
					oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement3.execute(); 
					if(oCallableStatement3.getObject(4) != null)
					{
					  iErrorCode2 = oCallableStatement3.getInt(4);
  log.debug("COMM RULE  Error code 2 :"+ iErrorCode2);		
  log.debug("COMM RULE  Error Desc 2:"+ oCallableStatement3.getString(5));					  		 
					}	
				}
				break;		
				
//Start FSD_551 Automation of manual upload Sagar 31-oct-2012

				case BPConstants.PROC_SEQ_FOR_MANUAL_MATCH_UPLOAD:
log.debug("Manual Match Upload:  Preparing to call the procedures");
				  strProcedure = getSQLString("Select",BPConstants.PROC_MANUAL_MATCH_UPLOAD_TEMP);
log.debug("Manual Match Upload first Proc :"+ strProcedure);
				  oCallableStatement1 = getCallableStatement(strProcedure);
				   log.debug("tempafter strUserId :"+ strUserId);
				  oCallableStatement1.setString(1,strUserId);
				   log.debug("tempafter strOracleDirectoryPath :"+ strOracleDirectoryPath);
				  oCallableStatement1.setString(2,strOracleDirectoryPath);
				   log.debug("tempafter strDataFile :"+ strDataFile);
			      oCallableStatement1.setString(3,strDataFile);		
				  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				  oCallableStatement1.execute(); 	
				  if(oCallableStatement1.getObject(4) != null)
				  {
					iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("Manual Match Upload Error code 1 :"+ iErrorCode1);
log.debug("Manual Match Upload Error Desc 1 :"+ oCallableStatement1.getString(5));	
				  }					  
				  if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{				  
						strProcedure = getSQLString("Select",BPConstants.PROC_MANUAL_MATCH_UPLOAD_MAIN);
	log.debug("COMM RULE  Upload second Proc :"+ strProcedure);
						oCallableStatement3 = getCallableStatement(strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
						  iErrorCode2 = oCallableStatement3.getInt(4);
	  log.debug("COMM RULE  Error code 2 :"+ iErrorCode2);		
	  log.debug("COMM RULE  Error Desc 2:"+ oCallableStatement3.getString(5));					  		 
						}	
					}

				  break;

//End FSD_551 Automation of manual upload Sagar 31-oct-2012

			case BPConstants.PROC_SEQ_FOR_CHM_AGENT_PAYMENT_UPLOAD: 
log.debug("CHM AGENT PAYMENT Upload:  Preparing to call the procedures");
							strProcedure = getSQLString("Select",BPConstants.PROC_BANK_TEMP_UPLOAD);		  
log.debug("CHM AGENT PAYMENT Upload first Proc :"+ strProcedure);
							oCallableStatement1 = getCallableStatement(strProcedure);
							log.debug("the procedure is -> " + strProcedure);
							oCallableStatement1.setString(1,strUserId);
							oCallableStatement1.setString(2,strOracleDirectoryPath);
							oCallableStatement1.setString(3,strDataFile);	
							oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
							oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
							
							oCallableStatement1.execute(); 	
							if(oCallableStatement1.getObject(4) != null)
							{
							  iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("CHM AGENT PAYMENT  Upload Error code 1 :"+ iErrorCode1);
log.debug("CHM AGENT PAYMENT  Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
							}					  
				  
							if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
							{				  
								strProcedure = getSQLString("Select",BPConstants.PROC_BANK_MAIN_UPLOAD);		  
log.debug("CHM AGENT PAYMENT  Upload second Proc :"+ strProcedure);
								oCallableStatement3 = getCallableStatement(strProcedure);
								oCallableStatement3.setString(1,strUserId);
								oCallableStatement3.setString(2,strOracleDirectoryPath);
								oCallableStatement3.setString(3,strDataFile);
								oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
								oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
								oCallableStatement3.execute(); 
								if(oCallableStatement3.getObject(4) != null)
								{
								  iErrorCode2 = oCallableStatement3.getInt(4);
log.debug("CHM AGENT PAYMENT  Error code 2 :"+ iErrorCode2);
log.debug("CHM AGENT PAYMENT  Error Desc 2:"+ oCallableStatement3.getString(5));								    	
								}	
							}
							break;		
							
							
							case BPConstants.PROC_SEQ_FOR_CHM_EMAIL_UPLOAD: 
log.debug("CHM EMAIL Upload:  Preparing to call the procedures");
							strProcedure = getSQLString("Select",BPConstants.PROC_EMAIL_TEMP_UPLOAD);		  
log.debug("CHM EMAIL Upload first Proc :"+ strProcedure);
							oCallableStatement1 = getCallableStatement(strProcedure);
							oCallableStatement1.setString(1,strUserId);	
							oCallableStatement1.setString(2,strOracleDirectoryPath);
							oCallableStatement1.setString(3,strDataFile);	
							oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
							oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
							oCallableStatement1.execute(); 	
							
							if(oCallableStatement1.getObject(4) != null)
							{
							  iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("CHM EMAIL Upload Error code 1 :"+ iErrorCode1);
log.debug("CHM EMAIL Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
							}					  
				  
							if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
							{				  
								
								strProcedure = getSQLString("Select",BPConstants.PROC_EMAIL_MAIN_UPLOAD);
log.debug("CHM EMAIL Upload second Proc :"+ strProcedure);
								oCallableStatement3 = getCallableStatement(strProcedure);
								oCallableStatement3.setString(1,strUserId);
								oCallableStatement3.setString(2,strOracleDirectoryPath);
								oCallableStatement3.setString(3,strDataFile);
								oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
								oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
								oCallableStatement3.execute(); 
								if(oCallableStatement3.getObject(4) != null)
								{
								  iErrorCode2 = oCallableStatement3.getInt(4);
log.debug("CHM EMAIL Error code 2 :"+ iErrorCode2);							
log.debug("CHM EMAIL Error Desc 2 :"+ oCallableStatement3.getString(5));																		    	
								}	
							}
							break;		
							
							case BPConstants.PROC_SEQ_FOR_CHM_POL_TRF_UPLOAD:
log.debug("CHM Policy Transfer Upload:  Preparing to call the procedures");
							strProcedure = getSQLString("Select",BPConstants.PROC_POLTRF_TEMP_UPLOAD);		  
log.debug("CHM Policy Transfer Upload first Proc :"+ strProcedure);
							oCallableStatement1 = getCallableStatement(strProcedure);
							oCallableStatement1.setString(1,strUserId);	
							oCallableStatement1.setString(2,strOracleDirectoryPath);
							oCallableStatement1.setString(3,strDataFile);
							oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
							oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
							oCallableStatement1.execute(); 	
							if(oCallableStatement1.getObject(4) != null)
							{
							  iErrorCode1 = oCallableStatement1.getInt(4);
log.debug("CHM Policy Transfer Upload Error code 1 :"+ iErrorCode1);
log.debug("CHM Policy Transfer Upload Error Desc 1 :"+ oCallableStatement1.getString(5) );
							}					  
				  
							if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
							{				  
								strProcedure = getSQLString("Select",BPConstants.PROC_POLTRF_MAIN_UPLOAD);
log.debug("CHM Policy Transfer Upload second Proc :"+ strProcedure);
								oCallableStatement3 = getCallableStatement(strProcedure);
								oCallableStatement3.setString(1,strUserId);
								oCallableStatement3.setString(2,strOracleDirectoryPath);
								oCallableStatement3.setString(3,strDataFile);
								oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
								oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
								oCallableStatement3.execute(); 
								if(oCallableStatement3.getObject(4) != null)
								{
								  iErrorCode2 = oCallableStatement3.getInt(4);
log.debug("CHM Policy Transfer Error code 2 :"+ iErrorCode2);							
log.debug("CHM Policy Transfer Error Desc 2 :"+ oCallableStatement3.getString(5));									    	
								}	
							}
							break;
							
								case BPConstants.PROC_SEQ_FOR_CHM_COMM_MAP_RULE_UPLOAD: 
log.debug("Chm Comm Map Rule Upload:  Preparing to call the procedures");
										strProcedure = getSQLString("Select",BPConstants.PROC_COMM_MAP_RULE_TEMP_UPLOAD);		  
log.debug("Chm Comm Map Rule Upload first Proc :"+ strProcedure);
										oCallableStatement1 = getCallableStatement(strProcedure);
										oCallableStatement1.setString(1,strUserId);	
										oCallableStatement1.setString(2,strOracleDirectoryPath);
										oCallableStatement1.setString(3,strDataFile);
										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
										oCallableStatement1.execute(); 	
										if(oCallableStatement1.getObject(4) != null)
										{
										  iErrorCode1 = oCallableStatement1.getInt(4);  
log.debug("Chm Comm Map Rule Upload Error code 1 :"+ iErrorCode1);
log.debug("Chm Comm Map Rule Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
			
										}					  
				  
										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
										{				  
											strProcedure = getSQLString("Select",BPConstants.PROC_COMM_MAP_RULE_MAIN_UPLOAD);		  
											oCallableStatement3 = getCallableStatement(strProcedure);
											log.debug("the procedure is -> " + strProcedure);
											oCallableStatement3.setString(1,strUserId);
											oCallableStatement3.setString(2,strOracleDirectoryPath);
											oCallableStatement3.setString(3,strDataFile);
											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
											oCallableStatement3.execute(); 
											if(oCallableStatement3.getObject(4) != null)
											{
											  iErrorCode2 = oCallableStatement3.getInt(4);
 log.debug("Chm Comm Map Rule Error code 2 :"+ iErrorCode2);
 log.debug("Chm Comm Map Rule Error Desc 2 :"+ oCallableStatement3.getString(5));							
														    	
											}	
										}
										break;
							

//End of the code Added by jayasimha 									
//<!-- ANUP_Everest Distritbution FS_Phase_II_REL9.0 Starts -->
			case BPConstants.PROC_SEQ_FOR_CHM_PLAN_SETUP_UPLOAD:
				log.debug("PLAN Set UP Upload:  Preparing to call the procedures");
							 
									  strProcedure = getSQLString("Select",BPConstants.PROC_PLAN_SETUP_UPLOAD);		  
				log.debug("PLAN Set UP Upload first Proc :"+ strProcedure);
									  oCallableStatement1 = getCallableStatement(strProcedure);
									  oCallableStatement1.setString(1,strUserId);	
									  oCallableStatement1.setString(2,strOracleDirectoryPath);
							          oCallableStatement1.setString(3,strDataFile);	
									  oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
									  oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
									  oCallableStatement1.execute();
									  if(oCallableStatement1.getObject(4) != null)
									  {
										iErrorCode2 = oCallableStatement1.getInt(4);
				log.debug("PLAN Set UP Upload Error code 1:"+ iErrorCode2);
				log.debug("PLAN Set UP Upload Error Desc 1:"+ oCallableStatement1.getString(5));								  	
									  }	 	
							  	  break;
											
//<!-- ANUP_Everest Distritbution FS_Phase_II_REL9.0 Ends -->
							
			 //<!-- ANUP_AGN17_REL9.0 Starts-->				  	  
			  case BPConstants.PROC_SEQ_FOR_BULK_TERMINATION_AGN_UPLOAD: 
				log.debug("Bulk Termination for Agent Upload:  Preparing to call the procedures");
				strProcedure = getSQLString("Select",BPConstants.PROC_BULK_TERMINATION_AGN_TEMP_UPLOAD);		  
				log.debug("Bulk Termination for Agent Upload first Proc :"+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1,strUserId);	
				oCallableStatement1.setString(2,strOracleDirectoryPath);
				oCallableStatement1.setString(3,strDataFile);
				oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				oCallableStatement1.execute(); 	
				if(oCallableStatement1.getObject(4) != null)
				{
				  iErrorCode1 = oCallableStatement1.getInt(4);  
				  log.debug("Bulk Termination for Agent Upload Error code 1 :"+ iErrorCode1);
				  log.debug("Bulk Termination for Agent Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

						}					  
  
						if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
						{				  
							strProcedure = getSQLString("Select",BPConstants.PROC_BULK_TERMINATION_AGN_MAIN_UPLOAD);		  
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1,strUserId);
					oCallableStatement3.setString(2,strOracleDirectoryPath);
					oCallableStatement3.setString(3,strDataFile);
					oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement3.execute(); 
					if(oCallableStatement3.getObject(4) != null)
					{
					  iErrorCode2 = oCallableStatement3.getInt(4);
					  log.debug("Bulk Termination for Agent Error code 2 :"+ iErrorCode2);
					  log.debug("Bulk Termination for Agent Error Desc 2 :"+ oCallableStatement3.getString(5));							
								    	
					}	
				}
				break;
				//<!-- ANUP_AGN17_REL9.0 Ends -->	
				
				// Added by Manisha on 4-May-2016 for MACH17.0 AGN902 - START
			  	case BPConstants.PROC_SEQ_FOR_BULK_SUSPENSION_AGN_UPLOAD: 
					log.debug("Bulk Suspension for Agent Upload :  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_BULK_SUSPENSION_AGN_TEMP_UPLOAD);		  
					log.debug("Bulk Suspension for Agent Upload first Proc :"+ strProcedure);
					oCallableStatement1 = getCallableStatement(strProcedure);
					oCallableStatement1.setString(1,strUserId);	
					oCallableStatement1.setString(2,strOracleDirectoryPath);
					oCallableStatement1.setString(3,strDataFile);
					oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement1.execute(); 	
					if(oCallableStatement1.getObject(4) != null)
					{
					  iErrorCode1 = oCallableStatement1.getInt(4);  
					  log.debug("Bulk Suspension for Agent Upload Error code 1 :"+ iErrorCode1);
					  log.debug("Bulk Suspension for Agent Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
					}					  
	  
					if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{				  
						strProcedure = getSQLString("Select",BPConstants.PROC_BULK_SUSPENSION_AGN_MAIN_UPLOAD);		  
						oCallableStatement3 = getCallableStatement(strProcedure);
						log.debug("the procedure is -> " + strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
						  iErrorCode2 = oCallableStatement3.getInt(4);
						  log.debug("Bulk Suspension for Agent Error code 2 :"+ iErrorCode2);
						  log.debug("Bulk Suspension for Agent Error Desc 2 :"+ oCallableStatement3.getString(5));							
									    	
						}	
					}
					break;
					
			  	case BPConstants.PROC_SEQ_FOR_BULK_WITHDRAW_AGN_UPLOAD: 
					log.debug("Bulk Withdraw for Agent Upload :  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_BULK_WITHDRAW_AGN_TEMP_UPLOAD);		  
					log.debug("Bulk Withdraw for Agent Upload first Proc :"+ strProcedure);
					oCallableStatement1 = getCallableStatement(strProcedure);
					oCallableStatement1.setString(1,strUserId);	
					oCallableStatement1.setString(2,strOracleDirectoryPath);
					oCallableStatement1.setString(3,strDataFile);
					oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement1.execute(); 	
					if(oCallableStatement1.getObject(4) != null)
					{
					  iErrorCode1 = oCallableStatement1.getInt(4);  
					  log.debug("Bulk Withdraw for Agent Upload Error code 1 :"+ iErrorCode1);
					  log.debug("Bulk Withdraw for Agent Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
					}					  
	  
					if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{				  
						strProcedure = getSQLString("Select",BPConstants.PROC_BULK_WITHDRAW_AGN_MAIN_UPLOAD);		  
						oCallableStatement3 = getCallableStatement(strProcedure);
						log.debug("the procedure is -> " + strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
						  iErrorCode2 = oCallableStatement3.getInt(4);
						  log.debug("Bulk Withdraw for Agent Error code 2 :"+ iErrorCode2);
						  log.debug("Bulk Withdraw for Agent Error Desc 2 :"+ oCallableStatement3.getString(5));							
									    	
						}	
					}
					break;
				// Added by Manisha on 4-May-2016 for MACH17.0 AGN902 - END
				//<!-- //ANUP_AGN74_REL9.0 Starts -->			  	  
			   case BPConstants.PROC_SEQ_FOR_BULK_REASSIGN_AGN_UPLOAD: 
				log.debug("Bulk Reassignment for agent Upload:  Preparing to call the procedures");
				strProcedure = getSQLString("Select",BPConstants.PROC_BULK_REASSIGN_AGN_TEMP_UPLOAD);		  
				log.debug("Bulk Reassignment for agent first Proc :"+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1,strUserId);	
				oCallableStatement1.setString(2,strOracleDirectoryPath);
				oCallableStatement1.setString(3,strDataFile);
				oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				oCallableStatement1.execute(); 	
				if(oCallableStatement1.getObject(4) != null)
				{
				  iErrorCode1 = oCallableStatement1.getInt(4);  
				  log.debug("Bulk Reassignment for agent Upload Error code 1 :"+ iErrorCode1);
				  log.debug("Bulk Reassignment for agent Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

						}					  
  
						if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
						{				  
							strProcedure = getSQLString("Select",BPConstants.PROC_BULK_REASSIGN_AGN_MAIN_UPLOAD);		  
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1,strUserId);
					oCallableStatement3.setString(2,strOracleDirectoryPath);
					oCallableStatement3.setString(3,strDataFile);
					oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement3.execute(); 
					if(oCallableStatement3.getObject(4) != null)
					{
					  iErrorCode2 = oCallableStatement3.getInt(4);
					  log.debug("Bulk Reassignment for agent Error code 2 :"+ iErrorCode2);
					  log.debug("Bulk Reassignment for agent Error Desc 2 :"+ oCallableStatement3.getString(5));							
								    	
					}	
				}
				break;
				//<!-- //ANUP_AGN74_REL9.0 Ends -->	
			 //START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0
			   case BPConstants.PROC_SEQ_FOR_CONTACT_SERVICE_REQQUEST_UPLOAD: 
					log.debug("Contact Details for Service Request Upload:  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_CONTACT_SERVICE_REQUEST_TEMP_UPLOAD);		  
					log.debug("Contact Details for Service Request Upload first Proc :"+ strProcedure);
					oCallableStatement1 = getCallableStatement(strProcedure);
					oCallableStatement1.setString(1,strUserId);	
					oCallableStatement1.setString(2,strOracleDirectoryPath);
					oCallableStatement1.setString(3,strDataFile);
					oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement1.execute(); 	
					if(oCallableStatement1.getObject(4) != null)
					{
					  iErrorCode1 = oCallableStatement1.getInt(4);  
					  log.debug("Contact Details for Service Request Upload Error code 1 :"+ iErrorCode1);
					  log.debug("Contact Details for Service Request Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

					}					  
	  
							if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
							{				  
								strProcedure = getSQLString("Select",BPConstants.PROC_CONTACT_SERVICE_REQUEST_MAIN_UPLOAD);		  
						oCallableStatement3 = getCallableStatement(strProcedure);
						log.debug("the procedure is -> " + strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
						  iErrorCode2 = oCallableStatement3.getInt(4);
						  log.debug("Contact Details for Service Request Error code 2 :"+ iErrorCode2);
						  log.debug("Contact Details for Service Request Error Desc 2 :"+ oCallableStatement3.getString(5));							
									    	
						}	
					}
					break;
					
					
			   case BPConstants.PROC_SEQ_FOR_PAN_SERVICE_REQQUEST_UPLOAD: 
					log.debug("PAN for Service Request Upload:  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_PAN_SERVICE_REQUEST_TEMP_UPLOAD);		  
					log.debug("PAN for Service Request Upload first Proc :"+ strProcedure);
					oCallableStatement1 = getCallableStatement(strProcedure);
					oCallableStatement1.setString(1,strUserId);	
					oCallableStatement1.setString(2,strOracleDirectoryPath);
					oCallableStatement1.setString(3,strDataFile);
					oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement1.execute(); 	
					if(oCallableStatement1.getObject(4) != null)
					{
					  iErrorCode1 = oCallableStatement1.getInt(4);  
					  log.debug("PAN for Service Request Upload Error code 1 :"+ iErrorCode1);
					  log.debug("PAN for Service Request Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

					}					  
	  
					if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{				  
						strProcedure = getSQLString("Select",BPConstants.PROC_PAN_SERVICE_REQUEST_MAIN_UPLOAD);		  
						oCallableStatement3 = getCallableStatement(strProcedure);
						log.debug("the procedure is -> " + strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
						  iErrorCode2 = oCallableStatement3.getInt(4);
						  log.debug("PAN for Service Request Upload Error code 2 :"+ iErrorCode2);
						  log.debug("PAN for Service Request Upload Desc 2 :"+ oCallableStatement3.getString(5));							
									    	
						}	
					}
					break;
					
					
			   case BPConstants.PROC_SEQ_FOR_ADDRESS_SERVICE_REQQUEST_UPLOAD: 
					log.debug("Address for Service Request Upload:  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_ADDRESS_SERVICE_REQUEST_TEMP_UPLOAD);		  
					log.debug("Address for Service Request Upload Upload first Proc :"+ strProcedure);
					oCallableStatement1 = getCallableStatement(strProcedure);
					oCallableStatement1.setString(1,strUserId);	
					oCallableStatement1.setString(2,strOracleDirectoryPath);
					oCallableStatement1.setString(3,strDataFile);
					oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement1.execute(); 	
					if(oCallableStatement1.getObject(4) != null)
					{
					  iErrorCode1 = oCallableStatement1.getInt(4);  
					  log.debug("Address for Service Request Upload Error code 1 :"+ iErrorCode1);
					  log.debug("Address for Service Request Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

					}					  
	  
					if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{				  
						strProcedure = getSQLString("Select",BPConstants.PROC_ADDRESS_SERVICE_REQUEST_MAIN_UPLOAD);		  
						oCallableStatement3 = getCallableStatement(strProcedure);
						log.debug("the procedure is -> " + strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
						  iErrorCode2 = oCallableStatement3.getInt(4);
						  log.debug("Address for Service Request Upload Error code 2 :"+ iErrorCode2);
						  log.debug("Address for Service Request Upload Error Desc 2 :"+ oCallableStatement3.getString(5));							
									    	
						}	
					}
					break;
					

				//ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0
				//Added by Srikanth CTS for Bulk Agent Movement Upload
				case BPConstants.PROC_SEQ_FOR_BULK_PROMOTION_AGN_UPLOAD: 
				log.debug("Bulk Promotion for Agent Upload:  Preparing to call the procedures");
				strProcedure = getSQLString("Select",BPConstants.PROC_BULK_PROMOTION_AGN_TEMP_UPLOAD);		  
				log.debug("Bulk Promotion for Agent Upload first Proc :"+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1,strUserId);	
				oCallableStatement1.setString(2,strOracleDirectoryPath);
				oCallableStatement1.setString(3,strDataFile);
				oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				oCallableStatement1.execute(); 	
				if(oCallableStatement1.getObject(4) != null)
				{
				  iErrorCode1 = oCallableStatement1.getInt(4);  
				  log.debug("Bulk Promotion for Agent Upload Error code 1 :"+ iErrorCode1);
				  log.debug("Bulk Promotion for Agent Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

				}					  
  
						if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
						{				  
							strProcedure = getSQLString("Select",BPConstants.PROC_BULK_PROMOTION_AGN_MAIN_UPLOAD);		  
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1,strUserId);
					oCallableStatement3.setString(2,strOracleDirectoryPath);
					oCallableStatement3.setString(3,strDataFile);
					oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement3.execute(); 
					if(oCallableStatement3.getObject(4) != null)
					{
					  iErrorCode2 = oCallableStatement3.getInt(4);
					  log.debug("Bulk Termination for Agent Error code 2 :"+ iErrorCode2);
					  log.debug("Bulk Termination for Agent Error Desc 2 :"+ oCallableStatement3.getString(5));							
								    	
					}	
				}
				break;
				
				//Parent_Branch_Code_Change_AGN430_Rohit Starts		
				case BPConstants.PROC_SEQ_FOR_BULK_TRANSFER_AGNCY_UPLOAD: 
					log.debug("Bulk Transfer for Agency Upload:  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_BULK_TRANSFER_AGNCY_TEMP_UPLOAD);		  
					log.debug("Bulk Transfer for Agency Upload first Proc :"+ strProcedure);
					oCallableStatement1 = getCallableStatement(strProcedure);
					oCallableStatement1.setString(1,strUserId);	
					oCallableStatement1.setString(2,strOracleDirectoryPath);
					oCallableStatement1.setString(3,strDataFile);
					oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement1.execute(); 	
					if(oCallableStatement1.getObject(4) != null)
					{
					  iErrorCode1 = oCallableStatement1.getInt(4);  
					  log.debug("Bulk Transfer for Agency Upload Error code 1 :"+ iErrorCode1);
					  log.debug("Bulk Transfer for Agency Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

					}					  
	  
					if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{				  
						strProcedure = getSQLString("Select",BPConstants.PROC_BULK_TRANSFER_AGNCY_MAIN_UPLOAD);		  
						oCallableStatement3 = getCallableStatement(strProcedure);
						log.debug("the procedure is -> " + strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
						  iErrorCode2 = oCallableStatement3.getInt(4);
						  log.debug("Bulk Transfer for Agency Upload Error code 2 :"+ iErrorCode2);
						  log.debug("Bulk Transfer for Agency Upload Error Desc 2 :"+ oCallableStatement3.getString(5));							
									    	
						}	
					}
					break;
				//Parent_Branch_Code_Change_AGN430_Rohit Ends	
					
					
				//<Code Tag: Added By Himanshu for Bulk Upload Prohibit JV posting Start		
				case BPConstants.PROC_SEQ_FOR_BULK_UPLOAD_PROHIBIT_JV_POSTING: 				
			log.debug("@@@@Bulk Upload for Prohibit JV Posting:  Preparing to call the procedures");
			strProcedure = getSQLString("Select",BPConstants.PROC_BULK_UPLOAD_PROHIBIT_JV_POSTING_TEMP);		  
			log.debug("@@@@Bulk Upload for Prohibit JV Posting:"+ strProcedure);
			oCallableStatement1 = getCallableStatement(strProcedure);
			oCallableStatement1.setString(1,strUserId);	
			oCallableStatement1.setString(2,strOracleDirectoryPath);
			oCallableStatement1.setString(3,strDataFile);
			oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
			oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
			oCallableStatement1.execute(); 	
			if(oCallableStatement1.getObject(4) != null)
			{
				log.debug("Inside getObject(4)");
			  iErrorCode1 = oCallableStatement1.getInt(4);  
			  log.debug("Bulk Transfer for Agency Upload Error code 1 :"+ iErrorCode1);
			  log.debug("Bulk Transfer for Agency Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

				}					  
  
				if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				{	
					log.debug("Inside FLAG FOR SUCCESS..");
					strProcedure = getSQLString("Select",BPConstants.PROC_BULK_UPLOAD_PROHIBIT_JV_POSTING_MAIN);		  
				oCallableStatement3 = getCallableStatement(strProcedure);
				log.debug("the procedure is -> " + strProcedure);
				oCallableStatement3.setString(1,strUserId);
				oCallableStatement3.setString(2,strOracleDirectoryPath);
				oCallableStatement3.setString(3,strDataFile);
				oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				oCallableStatement3.execute(); 
				if(oCallableStatement3.getObject(4) != null)
				{
				  iErrorCode2 = oCallableStatement3.getInt(4);
				  log.debug("Bulk Transfer for Agency Upload Error code 2 :"+ iErrorCode2);
				  log.debug("Bulk Transfer for Agency Upload Error Desc 2 :"+ oCallableStatement3.getString(5));							
							    	
				}	
			}
			break;
		//<Added By Himanshu for prohibit JV Posting Ends here
			
			
			// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 - START
				case BPConstants.PROC_SEQ_COLLECTION_ACHV_UPLD: 				
					log.debug("@@@@Collection Achievement Upload :  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_COLLECTION_ACHV_UPLD_TEMP);		  
					log.debug("@@@@Collection Achievement Upload:"+ strProcedure);
					oCallableStatement1 = getCallableStatement(strProcedure);
					oCallableStatement1.setString(1,strUserId);	
					oCallableStatement1.setString(2,strOracleDirectoryPath);
					oCallableStatement1.setString(3,strDataFile);
					oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement1.execute(); 	
					if(oCallableStatement1.getObject(4) != null)
					{
						log.debug("Inside getObject(4)");
						iErrorCode1 = oCallableStatement1.getInt(4);  
						log.debug("Collection Achievement Upload Temp Proc Error code 1 :"+ iErrorCode1);
						log.debug("Collection Achievement Upload Temp Proc Error Desc 1 :"+ oCallableStatement1.getString(5));
					}					  
		  
					if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{
						log.debug("Inside FLAG FOR SUCCESS..");
						strProcedure = getSQLString("Select",BPConstants.PROC_COLLECTION_ACHV_UPLD_MAIN);		  
						oCallableStatement3 = getCallableStatement(strProcedure);
						log.debug("the procedure is -> " + strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
							iErrorCode2 = oCallableStatement3.getInt(4);
							log.debug("Collection Achievement Upload Main Error code 2 :"+ iErrorCode2);
							log.debug("Collection Achievement Upload Main Error Desc 2 :"+ oCallableStatement3.getString(5));							
						}	
					}
					break;
					// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 - END
			// - END

			// Added by Varun on 09-Jun-2014 for Rel 15.1 FSD_POS989 - Starts
			case BPConstants.PROC_SEQ_NONHYBRID_INSTR_UPLD:
				log
						.debug("@@@@Non Hybrid Instrument Upload :  Preparing to call the procedure");
				strProcedure = getSQLString("Select",
						BPConstants.PROC_NONHYBRID_INSTR_UPLD_TEMP);
				log.debug("@@@@Non Hybrid Instrument Upload Procedure: "
						+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1, strUserId);
				oCallableStatement1.setInt(2, BPConstants.FOR_INSTRUMENT_UPLOAD );
				oCallableStatement1.setString(3, strDataFile);
				oCallableStatement1.registerOutParameter(4, Types.INTEGER);
				oCallableStatement1.registerOutParameter(5, Types.VARCHAR);
				oCallableStatement1.execute();
				if (oCallableStatement1.getObject(4) != null) {
					log.debug("Inside getObject(4)");
					iErrorCode1 = oCallableStatement1.getInt(4);
					log
							.debug("Non Hybrid Instrument Upload Temp Proc Error code 1 :"
									+ iErrorCode1);
					log
							.debug("Non Hybrid Instrument Upload Temp Proc Error Desc 1 :"
									+ oCallableStatement1.getString(5));
				}

				if (iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS) {
					log.debug("Inside FLAG FOR SUCCESS..");
					strProcedure = getSQLString("Select",
							BPConstants.PROC_NONHYBRID_INSTR_UPLD_MAIN);
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1, strUserId);
					oCallableStatement3.setString(2, strOracleDirectoryPath);
					oCallableStatement3.setString(3, strDataFile);
					oCallableStatement3.setString(4, strLocationCd);
					oCallableStatement3.registerOutParameter(5, Types.INTEGER);
					oCallableStatement3.registerOutParameter(6, Types.VARCHAR);
					oCallableStatement3.execute();
					if (oCallableStatement3.getObject(5) != null) {
						iErrorCode2 = oCallableStatement3.getInt(5);
						log
								.debug("Non Hybrid Instrument Upload Main Error code 2 :"
										+ iErrorCode2);
						log
								.debug("Non Hybrid Instrument Upload Main Error Desc 2 :"
										+ oCallableStatement3.getString(6));
					}
				}
				break;

			case BPConstants.PROC_SEQ_NONHYBRID_ECS_UPLD:
				log
						.debug("@@@@Non Hybrid ECS Upload :  Preparing to call the procedure");
				strProcedure = getSQLString("Select",
						BPConstants.PROC_NONHYBRID_INSTR_UPLD_TEMP);
				log.debug("@@@@Non Hybrid ECS Upload Procedure: "
						+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1, strUserId);
				oCallableStatement1.setInt(2, BPConstants.FOR_ECS_AND_CR_DR_UPLOAD);
				oCallableStatement1.setString(3, strDataFile);
				oCallableStatement1.registerOutParameter(4, Types.INTEGER);
				oCallableStatement1.registerOutParameter(5, Types.VARCHAR);
				oCallableStatement1.execute();
				if (oCallableStatement1.getObject(4) != null) {
					log.debug("Inside getObject(4)");
					iErrorCode1 = oCallableStatement1.getInt(4);
					log.debug("Non Hybrid ECS Upload Temp Proc Error code 1 :"
							+ iErrorCode1);
					log.debug("Non Hybrid ECS Upload Temp Proc Error Desc 1 :"
							+ oCallableStatement1.getString(5));
				}

				if (iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS) {
					log.debug("Inside FLAG FOR SUCCESS..");
					strProcedure = getSQLString("Select",
							BPConstants.PROC_NONHYBRID_ECS_UPLD_MAIN);
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1, strUserId);
					oCallableStatement3.setString(2, strOracleDirectoryPath);
					oCallableStatement3.setString(3, strDataFile);
					oCallableStatement3.setString(4, strLocationCd);
					oCallableStatement3.registerOutParameter(5, Types.INTEGER);
					oCallableStatement3.registerOutParameter(6, Types.VARCHAR);
					oCallableStatement3.execute();
					if (oCallableStatement3.getObject(5) != null) {
						iErrorCode2 = oCallableStatement3.getInt(5);
						log.debug("Non Hybrid ECS Upload Main Error code 2 :"
								+ iErrorCode2);
						log.debug("Non Hybrid ECS Upload Main Error Desc 2 :"
								+ oCallableStatement3.getString(6));
					}
				}
				break;

			case BPConstants.PROC_SEQ_NONHYBRID_CCS_UPLD:
				log
						.debug("@@@@Non Hybrid CCS Upload :  Preparing to call the procedure");
				strProcedure = getSQLString("Select",
						BPConstants.PROC_NONHYBRID_INSTR_UPLD_TEMP);
				log.debug("@@@@Non Hybrid CCS Upload Procedure: "
						+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1, strUserId);
				oCallableStatement1.setInt(2, BPConstants.FOR_ECS_AND_CR_DR_UPLOAD);
				oCallableStatement1.setString(3, strDataFile);
				oCallableStatement1.registerOutParameter(4, Types.INTEGER);
				oCallableStatement1.registerOutParameter(5, Types.VARCHAR);
				oCallableStatement1.execute();
				if (oCallableStatement1.getObject(4) != null) {
					log.debug("Inside getObject(4)");
					iErrorCode1 = oCallableStatement1.getInt(4);
					log.debug("Non Hybrid CCS Upload Temp Proc Error code 1 :"
							+ iErrorCode1);
					log.debug("Non Hybrid CCS Upload Temp Proc Error Desc 1 :"
							+ oCallableStatement1.getString(5));
				}

				if (iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS) {
					log.debug("Inside FLAG FOR SUCCESS..");
					strProcedure = getSQLString("Select",
							BPConstants.PROC_NONHYBRID_CCS_UPLD_MAIN);
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1, strUserId);
					oCallableStatement3.setString(2, strOracleDirectoryPath);
					oCallableStatement3.setString(3, strDataFile);
					oCallableStatement3.setString(4, strLocationCd);
					oCallableStatement3.registerOutParameter(5, Types.INTEGER);
					oCallableStatement3.registerOutParameter(6, Types.VARCHAR);
					oCallableStatement3.execute();
					if (oCallableStatement3.getObject(5) != null) {
						iErrorCode2 = oCallableStatement3.getInt(5);
						log.debug("Non Hybrid CCS Upload Main Error code 2 :"
								+ iErrorCode2);
						log.debug("Non Hybrid CCS Upload Main Error Desc 2 :"
								+ oCallableStatement3.getString(6));
					}
				}
				break;
			// Added by Varun on 09-Jun-2014 for Rel 15.1 FSD_POS989 - Ends

				// Added by Manisha on 7-Aug-2013 for MACH-17 - START
				case BPConstants.PROC_SEQ_SUSP_FROM_NB: 				
					log.debug("@@@@Suspension From NB Upload :  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_SUSP_FROM_NB_TEMP);		  
					log.debug("@@@@Suspension From NB Upload:"+ strProcedure);
					oCallableStatement1 = getCallableStatement(strProcedure);
					oCallableStatement1.setString(1,strUserId);	
					oCallableStatement1.setString(2,strOracleDirectoryPath);
					oCallableStatement1.setString(3,strDataFile);
					oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement1.execute(); 	
					if(oCallableStatement1.getObject(4) != null)
					{
						log.debug("Inside getObject(4)");
						iErrorCode1 = oCallableStatement1.getInt(4);  
						log.debug("Suspension From NB Upload Error code 1 :"+ iErrorCode1);
						log.debug("Suspension From NB Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
					}					  
		  
					if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					{
						log.debug("Inside FLAG FOR SUCCESS..");
						strProcedure = getSQLString("Select",BPConstants.PROC_SUSP_FROM_NB_MAIN);		  
						oCallableStatement3 = getCallableStatement(strProcedure);
						log.debug("the procedure is -> " + strProcedure);
						oCallableStatement3.setString(1,strUserId);
						oCallableStatement3.setString(2,strOracleDirectoryPath);
						oCallableStatement3.setString(3,strDataFile);
						oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
						oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
						oCallableStatement3.execute(); 
						if(oCallableStatement3.getObject(4) != null)
						{
							iErrorCode2 = oCallableStatement3.getInt(4);
							log.debug("Suspension From NB Upload Error code 2 :"+ iErrorCode2);
							log.debug("Suspension From NB Upload Error Desc 2 :"+ oCallableStatement3.getString(5));							
						}	
					}
					break;
					// Added by Manisha on 7-Aug-2013 for MACH-17 - END
					
					// Added by Manisha on 5-Nov-2015 for Rel 16.1 FIN896 - START
				case BPConstants.PROC_SEQ_COMMENTS_UPLD: 				
					log.debug("@@@@Comments Upload :  Preparing to call the procedures");
					strProcedure = getSQLString("Select",BPConstants.PROC_SEQ_COMMENTS_UPLD_MAIN);		  
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1,strUserId);
					//oCallableStatement3.setString(2,strOracleDirectoryPath);
					//oCallableStatement3.setString(3,strDataFile);
					oCallableStatement3.registerOutParameter(2,Types.INTEGER); 
					oCallableStatement3.registerOutParameter(3,Types.VARCHAR); 
					oCallableStatement3.execute(); 
					if(oCallableStatement3.getObject(2) != null)
					{
						iErrorCode1 = oCallableStatement3.getInt(2);
						log.debug("Comments Upload Error code  :"+ iErrorCode1);
						log.debug("Comments Upload Error Desc :"+ oCallableStatement3.getString(3));							
					}	
					
					break;
					// Added by Manisha on 5-Nov-2015 for Rel 16.1 FIN896 - END
					

				case BPConstants.PROC_SEQ_FOR_BULK_DEMOTION_AGN_UPLOAD: 
				log.debug("Bulk Demotion for Agent Upload:  Preparing to call the procedures");
				strProcedure = getSQLString("Select",BPConstants.PROC_BULK_DEMOTION_AGN_TEMP_UPLOAD);		  
				log.debug("Bulk Demotion for Agent Upload first Proc :"+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1,strUserId);	
				oCallableStatement1.setString(2,strOracleDirectoryPath);
				oCallableStatement1.setString(3,strDataFile);
				oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				oCallableStatement1.execute(); 	
				if(oCallableStatement1.getObject(4) != null)
				{
				  iErrorCode1 = oCallableStatement1.getInt(4);  
				  log.debug("Bulk Demotion for Agent Upload Error code 1 :"+ iErrorCode1);
				  log.debug("Bulk Demotion for Agent Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

				}					  
  
				if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				{				  
					strProcedure = getSQLString("Select",BPConstants.PROC_BULK_DEMOTION_AGN_MAIN_UPLOAD);		  
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1,strUserId);
					oCallableStatement3.setString(2,strOracleDirectoryPath);
					oCallableStatement3.setString(3,strDataFile);
					oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement3.execute(); 
					if(oCallableStatement3.getObject(4) != null)
					{
					  iErrorCode2 = oCallableStatement3.getInt(4);
					  log.debug("Bulk Demotion for Agent Error code 2 :"+ iErrorCode2);
					  log.debug("Bulk Demotion for Agent Error Desc 2 :"+ oCallableStatement3.getString(5));							
								    	
					}	
				}
				break;
				
							
				case BPConstants.PROC_SEQ_FOR_BULK_TRANSFER_AGN_UPLOAD: 
				log.debug("Bulk Demotion for Agent Upload:  Preparing to call the procedures");
				strProcedure = getSQLString("Select",BPConstants.PROC_BULK_TRANSFER_AGN_TEMP_UPLOAD);		  
				log.debug("Bulk Demotion for Agent Upload first Proc :"+ strProcedure);
				oCallableStatement1 = getCallableStatement(strProcedure);
				oCallableStatement1.setString(1,strUserId);	
				oCallableStatement1.setString(2,strOracleDirectoryPath);
				oCallableStatement1.setString(3,strDataFile);
				oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				oCallableStatement1.execute(); 	
				if(oCallableStatement1.getObject(4) != null)
				{
				  iErrorCode1 = oCallableStatement1.getInt(4);  
				  log.debug("Bulk Demotion for Agent Upload Error code 1 :"+ iErrorCode1);
				  log.debug("Bulk Demotion for Agent Upload Error Desc 1 :"+ oCallableStatement1.getString(5));

				}					  
  
				if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				{				  
					strProcedure = getSQLString("Select",BPConstants.PROC_BULK_TRANSFER_AGN_MAIN_UPLOAD);		  
					oCallableStatement3 = getCallableStatement(strProcedure);
					log.debug("the procedure is -> " + strProcedure);
					oCallableStatement3.setString(1,strUserId);
					oCallableStatement3.setString(2,strOracleDirectoryPath);
					oCallableStatement3.setString(3,strDataFile);
					oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
					oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
					oCallableStatement3.execute(); 
					if(oCallableStatement3.getObject(4) != null)
					{
					  iErrorCode2 = oCallableStatement3.getInt(4);
					  log.debug("Bulk Demotion for Agent Error code 2 :"+ iErrorCode2);
					  log.debug("Bulk Demotion for Agent Error Desc 2 :"+ oCallableStatement3.getString(5));							
								    	
					}	
				}
				break;
				//Ended by Srikanth  CTS for Bulk Agent Movement Upload
				//<!-- //Anup_Everest_Upload_Actuarial_Persistancy_Starts -->
			   case BPConstants.PROC_SEQ_FOR_CHM_ACTURIAL_PERSIST_UPLOAD: 
				   log.debug("Upload_Actuarial_Persistancy:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_ACTURIAL_PERSIST_TEMP_UPLOAD);		  
				   log.debug("Upload_Actuarial_Persistancy first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("Upload_Actuarial_Persistancy Error code 1 :"+ iErrorCode1);
				   log.debug("Upload_Actuarial_Persistancy Error Desc 1 :"+ oCallableStatement1.getString(5));
				   			
				   										}					  
				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_ACTURIAL_PERSIST_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("Upload_Actuarial_Persistancy Error code 2 :"+ iErrorCode2);
				    log.debug("Upload_Actuarial_Persistancy Error Desc 2 :"+ oCallableStatement3.getString(5));							
				   														    	
				   											}	
				   										}
				   										break;
              //	<!-- //Anup_Everest_Upload_Actuarial_Persistancy_Ends -->
				   							
             //	<!-- //Anup_Everest_Upload_GO_Association_Starts-->
			   case BPConstants.PROC_SEQ_FOR_CHM_GO_ASSOCIATION_UPLOAD: 
				   log.debug("GO_Association Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_GO_ASSOCIATION_TEMP_UPLOAD);		  
				   log.debug("GO_Association Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("GO_Association Upload Error code 1 :"+ iErrorCode1);
				   log.debug("GO_Association Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
				   			
				   										}					  
				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_GO_ASSOCIATION_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("GO_Association Error code 2 :"+ iErrorCode2);
				    log.debug("GO_Association Error Desc 2 :"+ oCallableStatement3.getString(5));							
				   														    	
				   											}	
				   										}
				   										break;
//<!-- //Anup_Everest_Upload_GO_Association_Ends-->   	
//				   										Adjusted_paid_case_setup_Anup_Starts
			   case BPConstants.PROC_SEQ_FOR_ADJ_PAID_CASE_UPLOAD: 
				   log.debug("Adj Paid Case setup Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_ADJ_PAID_CASE_TEMP_UPLOAD);		  
				   log.debug("Adj Paid Case setup  Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("Adj Paid Case setup  Upload Error code 1 :"+ iErrorCode1);
				   log.debug("Adj Paid Case setup  Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
				   			
				   										}					  
				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_ADJ_PAID_CASE_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("Adj Paid Case setup  Error code 2 :"+ iErrorCode2);
				    log.debug("Adj Paid Case setup  Error Desc 2 :"+ oCallableStatement3.getString(5));							
				   														    	
				   											}	
				   										}
				   										break;
//				   										Adjusted_paid_case_setup_Anup_Ends
				   										
//				   									<!--Anup_Upload_Commision_Dispatch_Details_Starts-->
			   case BPConstants.PROC_SEQ_FOR_CHM_COMMISION_DISPATCH_UPLOAD: 
				   log.debug("Commision Dispatch Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_COMMISION_DISPATCH_TEMP_UPLOAD);		  
				   log.debug("Commision Dispatch Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("Commision Dispatch Upload Error code 1 :"+ iErrorCode1);
				   log.debug("Commision Dispatch Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
				   			
				   										}					  
				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_COMMISION_DISPATCH_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("Commision Dispatch Error code 2 :"+ iErrorCode2);
				    log.debug("Commision Dispatch Error Desc 2 :"+ oCallableStatement3.getString(5));							
				   														    	
				   											}	
				   										}
				   										break;
				   										//<!-- Anup_Upload_Commision_Dispatch_Details_Ends -->		   										
					   																		
						   								//<!--Anup_Upload_GO_Override_APR_REL_Starts-->
			   case BPConstants.PROC_SEQ_FOR_GOOVERRIDE_UPLOAD: 
				   log.debug("GO_Override Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_GOOVERRIDE_TEMP_UPLOAD);		  
				   log.debug("GO_Override Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("GO_Override Upload Error code 1 :"+ iErrorCode1);
				   log.debug("GO_Override Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
				   			
				   										}					  
				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_GOOVERRIDE_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("GO_Override Error code 2 :"+ iErrorCode2);
				    log.debug("GO_Override Error Desc 2 :"+ oCallableStatement3.getString(5));							
				   														    	
				   											}	
				   										}
				   										break;
//				   									<!--Anup_Upload_GO_Override_APR_REL_Ends-->										
						   								//<!--Anup_Upload_MPP_APR_REL_Starts-->
			   case BPConstants.PROC_SEQ_FOR_MPP_UPLOAD: 
				   log.debug("MPP Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_GO_GLP_TEMP_UPLOAD);		  
				   log.debug("MPP Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("MPP Upload Error code 1 :"+ iErrorCode1);
				   log.debug("MPP Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
				   			
				   										}					  
				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_GO_GLP_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("MPP Error code 2 :"+ iErrorCode2);
				    log.debug("MPP Error Desc 2 :"+ oCallableStatement3.getString(5));							
				   														    	
				   											}	
				   										}
				   										break;
//				   									<!--Anup_Upload_MPP_APR_REL_Ends-->	
				   										
//				   									<!--Anup_Upload_Bancassurance_Starts-->
			   case BPConstants.PROC_SEQ_FOR_BANCASSURANCE_UPLOAD: 
				   log.debug("Bancassurance Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_BANCASSURANCE_TEMP_UPLOAD);		  
				   log.debug("Bancassurance Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("Bancassurance Upload Error code 1 :"+ iErrorCode1);
				   log.debug("Bancassurance Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
				   			
				   										}					  
				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_BANCASSURANCE_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("Bancassurance Error code 2 :"+ iErrorCode2);
				    log.debug("Bancassurance Error Desc 2 :"+ oCallableStatement3.getString(5));							
				   														    	
				   											}	
				   										}
				   										break;
//				   									<!--Anup_Upload_Bancassurance_Ends-->   
//	 FIN_71-74_Success or Bounce statements upload facility_APR_REL_Anup_Starts
			   case BPConstants.PROC_SEQ_FOR_CREDITCARD_STMT_UPLOAD: 
					 log.debug("Credit Card Statement Upload:  Preparing to call the procedures");
					 strProcedure = getSQLString("Select",BPConstants.PROC_CREDITCARD_STMT_TEMP_UPLOAD);
					 log.debug("Credit Card Statement Upload First Proc :"+ strProcedure);				 		  
					 oCallableStatement1 = getCallableStatement(strProcedure);
					 log.debug("the procedure is -> " + strProcedure);
					 oCallableStatement1.setString(1,strUserId);
					 oCallableStatement1.setString(2,strDataFile);
					 oCallableStatement1.registerOutParameter(3,Types.INTEGER);  
					 oCallableStatement1.registerOutParameter(4,Types.VARCHAR); 
					 oCallableStatement1.execute();
					 if(oCallableStatement1.getObject(3) != null)
					 {
						iErrorCode1 = oCallableStatement1.getInt(3);
	log.debug("Credit Card Statement Upload Error code 1 :"+ iErrorCode1);
	log.debug("Credit Card Statement Upload Error Desc 1 :"+ oCallableStatement1.getString(4));					  	
					 }
				     if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				     {
					    strProcedure = getSQLString("Select",BPConstants.PROC_CREDITCARD_STMT_MAIN_UPLOAD);		  
	log.debug("Credit Card Statement Upload Second Proc :"+ strProcedure);
						oCallableStatement2 = getCallableStatement(strProcedure);
						oCallableStatement2.setString(1,strUserId);
						//Anantha_SuccessBounce_Upload_FS commented code as proc has been changed start
						//<!-- Rel.Q2 Starts Added by Alexpandiyan Dated: 7 Mar 2011 -->
						oCallableStatement2.setString(2, strLocationCd);						
						oCallableStatement2.registerOutParameter(3,Types.DOUBLE); 
						oCallableStatement2.registerOutParameter(4,Types.INTEGER);
						oCallableStatement2.registerOutParameter(5,Types.INTEGER); 
						oCallableStatement2.registerOutParameter(6,Types.INTEGER);
						oCallableStatement2.registerOutParameter(7,Types.INTEGER); 
						oCallableStatement2.registerOutParameter(8,Types.INTEGER);
						oCallableStatement2.registerOutParameter(9,Types.VARCHAR); 
						
						
						oCallableStatement2.execute(); 
						
						if(oCallableStatement2.getObject(3)!=null) 
						{
							double dSumGrossAmt=oCallableStatement2.getDouble(3);
							a_oDataResult.setSumGrossAmt(new Double(dSumGrossAmt));
							
						}
						
						if(oCallableStatement2.getObject(4)!=null) 
						{
							double dSumBankCharges=oCallableStatement2.getDouble(4);
							a_oDataResult.setSumBankCharges(new Double(dSumBankCharges));
							
						}
						
						if(oCallableStatement2.getObject(5)!=null) 
						{
							double dSumServiceTax=oCallableStatement2.getDouble(5);							
							a_oDataResult.setSumServiceTax(new Double(dSumServiceTax));
						}
						
						if(oCallableStatement2.getObject(6)!=null) 
						{
							double dSumNetAmnt=oCallableStatement2.getDouble(6);
							a_oDataResult.setSumNetAmnt(new Double(dSumNetAmnt));
							
						}
							
						if(oCallableStatement2.getObject(7)!=null) 
						{														
							long lCCCtrlStmtSeqNbr = oCallableStatement2.getLong(7); 	
							a_oDataResult.setCCORECSCtrlStmtSeqNbr(new Long(lCCCtrlStmtSeqNbr));
						}
						
					  	if(oCallableStatement2.getObject(8) != null)
						{
						  iErrorCode2 = oCallableStatement2.getInt(8);  
							log.debug("Credit Card Statement Upload Error code 2 :"+ iErrorCode2);
							log.debug("Credit Card Statement Upload Error Desc 2 :"+ oCallableStatement2.getString(9));		
						 }
					  	//<!-- Rel.Q2 Ends Added by Alexpandiyan Dated: 7 Mar 2011 -->
				     }
				     log.debug(" Data Inputted CC from Proc PROC_CREDITCARD_STMT_MAIN_UPLOAD, a_oDataResult >> "+a_oDataResult.toString());
				   //Anantha_SuccessBounce_Upload_FS CC 2nd proc modifications ends
				break;				
				
			   case BPConstants.PROC_SEQ_FOR_ECS_STMT_UPLOAD: 				 
				   		 log.debug("ECS Statement Upload:  Preparing to call the procedures");
						 strProcedure = getSQLString("Select",BPConstants.PROC_ECS_STMT_TEMP_UPLOAD);
						 log.debug("ECS Statement Upload First Proc :"+ strProcedure);				 		  
						 oCallableStatement1 = getCallableStatement(strProcedure);
						 log.debug("the procedure is -> " + strProcedure);
						 oCallableStatement1.setString(1,strUserId);
						 oCallableStatement1.setString(2,strDataFile);
						 oCallableStatement1.registerOutParameter(3,Types.INTEGER);  
						 oCallableStatement1.registerOutParameter(4,Types.VARCHAR); 
						 
						 oCallableStatement1.execute();
						 
						 if(oCallableStatement1.getObject(3) != null)
						 {
							iErrorCode1 = oCallableStatement1.getInt(3);
		                 log.debug("ECS Statement Upload Error code 1 :"+ iErrorCode1);
		                 log.debug("ECS Statement Upload Error Desc 1 :"+ oCallableStatement1.getString(4));					  	
						 }
					     if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
					     {
						    strProcedure = getSQLString("Select",BPConstants.PROC_ECS_STMT_MAIN_UPLOAD);		  
						    log.debug(" ECS Statement Upload Second Proc : "+ strProcedure);
							oCallableStatement2 = getCallableStatement(strProcedure);
							oCallableStatement2.setString(1,strUserId);
							//Anantha_SuccessBounce_Upload_FS commented code as proc has been changed start
							//<!-- Rel.Q2 Starts Added by Alexpandiyan Dated: 7 Mar 2011 -->
							oCallableStatement2.setString(2,strLocationCd);														   
							oCallableStatement2.registerOutParameter(3,Types.DOUBLE); 
							oCallableStatement2.registerOutParameter(4,Types.INTEGER);
							oCallableStatement2.registerOutParameter(5,Types.INTEGER); 
							oCallableStatement2.registerOutParameter(6,Types.INTEGER);
							oCallableStatement2.registerOutParameter(7,Types.INTEGER); 
							oCallableStatement2.registerOutParameter(8,Types.INTEGER);
							oCallableStatement2.registerOutParameter(9,Types.VARCHAR); 
							
							
							oCallableStatement2.execute(); 
							
							if(oCallableStatement2.getObject(3)!=null) 
							{
								double dSumGrossAmt=oCallableStatement2.getDouble(3);
								a_oDataResult.setSumGrossAmt(new Double(dSumGrossAmt));
								
							}
							
							if(oCallableStatement2.getObject(4)!=null) 
							{
								double dSumBankCharges=oCallableStatement2.getDouble(4);
								a_oDataResult.setSumBankCharges(new Double(dSumBankCharges));
								
							}
							
							if(oCallableStatement2.getObject(5)!=null) 
							{
								double dSumServiceTax=oCallableStatement2.getDouble(5);							
								a_oDataResult.setSumServiceTax(new Double(dSumServiceTax));
							}
							
							if(oCallableStatement2.getObject(6)!=null) 
							{
								double dSumNetAmnt=oCallableStatement2.getDouble(6);
								a_oDataResult.setSumNetAmnt(new Double(dSumNetAmnt));
								
							}
								
							if(oCallableStatement2.getObject(7)!=null) 
							{														
								long lCCCtrlStmtSeqNbr = oCallableStatement2.getLong(7); 	
								a_oDataResult.setCCORECSCtrlStmtSeqNbr(new Long(lCCCtrlStmtSeqNbr));
							}
//Added by Rajeev Upload move not working - JAN Release 2011 Start
							
						  	if(oCallableStatement2.getObject(8) != null)
							{
							  iErrorCode2 = oCallableStatement2.getInt(8);  
							  log.debug("ECS Statement Upload Error code 2 :"+ iErrorCode2);
							  log.debug("ECS Statement Upload Error Desc 2 :"+ oCallableStatement2.getString(9));		
							 }					 
//Added by Rajeev Upload move not working - JAN Release 2011 End
						  //<!-- Rel.Q2 Ends Added by Alexpandiyan Dated: 7 Mar 2011 -->
					     }
					     log.debug(" Data Inputted ECS from Proc PROC_ECS_STMT_MAIN_UPLOAD, a_oDataResult >> "+a_oDataResult.toString());
					     
					     //Anantha_SuccessBounce_Upload_FS ECS 2nd proc modifications ends
					break;			   
// FIN_71-74_Success or Bounce statements upload facility_APR_REL_Anup_Ends
					
//					<!--AGN98_Anup_Uploads_Bonus/Product_Persistency_Designation_JUL_REL_Starts-->					
			   case BPConstants.PROC_SEQ_FOR_DESGN_UPLOAD: 
				   log.debug("Designation setup Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_DESGN_TEMP_UPLOAD);		  
				   log.debug("Designation setup  Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("Designation Upload Error code 1 :"+ iErrorCode1);
				   log.debug("Designation Upload Error Desc 1 :"+ oCallableStatement1.getString(5));				   			
				   										}				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_DESGN_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("Designation   Error code 2 :"+ iErrorCode2);
				    log.debug("Designation   Error Desc 2 :"+ oCallableStatement3.getString(5));
				   											}	
				   										}
				   										break;
				   										
			   case BPConstants.PROC_SEQ_FOR_BONUS_PRD_UPLOAD: 
				   log.debug("Bonus/Product setup Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_BONUS_PRD_TEMP_UPLOAD);		  
				   log.debug("Bonus/Product  Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("Bonus/Product Upload Error code 1 :"+ iErrorCode1);
				   log.debug("Bonus/Product Upload Error Desc 1 :"+ oCallableStatement1.getString(5));				   			
				   										}				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_BONUS_PRD_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("Bonus/Product   Error code 2 :"+ iErrorCode2);
				    log.debug("Bonus/Product   Error Desc 2 :"+ oCallableStatement3.getString(5));
				   											}	
				   										}
				   										break;
				   										
			   case BPConstants.PROC_SEQ_FOR_PERST_PRD_UPLOAD: 
				   log.debug("Bonus/Product setup Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_CHM_PERST_PRD_TEMP_UPLOAD);		  
				   log.debug("Bonus/Product  Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("Bonus/Product Upload Error code 1 :"+ iErrorCode1);
				   log.debug("Bonus/Product Upload Error Desc 1 :"+ oCallableStatement1.getString(5));				   			
				   										}				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_CHM_PERST_PRD_MAIN_UPLOAD);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("Bonus/Product   Error code 2 :"+ iErrorCode2);
				    log.debug("Bonus/Product   Error Desc 2 :"+ oCallableStatement3.getString(5));
				   											}	
				   										}
				   										break;
				   		//	<!--AGN98_Anup_Uploads_Bonus/Product_Persistency_Designation_JUL_REL_Ends-->

//Added by Srikanth CTS for MPS
			   case BPConstants.PROC_SEQ_FOR_AGENT_MPS_CALCULATION: 
				   log.debug("Agent MPS setup Upload:  Preparing to call the procedures");
				   										strProcedure = getSQLString("Select",BPConstants.PROC_AGENT_MPS_CALCULATION_TEMP);		  
				   log.debug("MPS  Upload first Proc :"+ strProcedure);
				   										oCallableStatement1 = getCallableStatement(strProcedure);
				   										oCallableStatement1.setString(1,strUserId);	
				   										oCallableStatement1.setString(2,strOracleDirectoryPath);
				   										oCallableStatement1.setString(3,strDataFile);
				   										oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   										oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   										oCallableStatement1.execute(); 	
				   										if(oCallableStatement1.getObject(4) != null)
				   										{
				   										  iErrorCode1 = oCallableStatement1.getInt(4);  
				   log.debug("MPS Upload Error code 1 :"+ iErrorCode1);
				   log.debug("MPS Upload Error Desc 1 :"+ oCallableStatement1.getString(5));				   			
				   										}				   				  
				   										if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   										{				  
				   											strProcedure = getSQLString("Select",BPConstants.PROC_AGENT_MPS_CALCULATION_MAIN);		  
				   											oCallableStatement3 = getCallableStatement(strProcedure);
				   											log.debug("the procedure is -> " + strProcedure);
				   											oCallableStatement3.setString(1,strUserId);
				   											oCallableStatement3.setString(2,strOracleDirectoryPath);
				   											oCallableStatement3.setString(3,strDataFile);
				   											oCallableStatement3.registerOutParameter(4,Types.INTEGER); 
				   											oCallableStatement3.registerOutParameter(5,Types.VARCHAR); 
				   											oCallableStatement3.execute(); 
				   											if(oCallableStatement3.getObject(4) != null)
				   											{
				   											  iErrorCode2 = oCallableStatement3.getInt(4);
				    log.debug("MPS Error code 2 :"+ iErrorCode2);
				    log.debug("MPS Error Desc 2 :"+ oCallableStatement3.getString(5));
				   											}	
				   										}
				   										break;
               //End by Srikanth CTS
			//ALEX_FSD_Pending_Agents_Reject_Upload Starts
			   case BPConstants.PROC_SEQ_FOR_PENDING_REJECT_UPLD:
				  
				   log.debug("Pending Agent Reject Upload:  Preparing to call the procedures");
				   strProcedure = getSQLString("Select",BPConstants.PROC_PENDING_AGENT_REJECT_TEMP);
				   log.debug("Pending Agent Reject Upload Proc 1:"+  strProcedure);
				   //All input params should added first & make sure number of input params
				  
				   ArrayList<String> parametersIN=new ArrayList<String>();
				   ArrayList<Integer> parametersOUT=new ArrayList<Integer>();
				   parametersIN.add(0, strUserId);				 
				   parametersIN.add(1, strOracleDirectoryPath);
				   parametersIN.add(2, strDataFile);
				   parametersOUT.add(0, Types.INTEGER);
				   parametersOUT.add(1, Types.VARCHAR);
								  
				   oCallableStatement1=uploadProcExec(parametersIN,parametersOUT,strProcedure);
				   if(oCallableStatement1.getObject(4) != null)
				   {
						  iErrorCode1 = oCallableStatement1.getInt(4);  
						  log.debug("Pending Agent Reject Upload I:ErrorCode-"+ iErrorCode1);
						  log.debug("Pending Agent Reject Upload I:ErrorDesc-"+ oCallableStatement1.getString(5));				   			
				   }		
				   if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   {		
					  log.debug("Pending Agent Reject Upload:  Preparing to call the procedures");
					  strProcedure = getSQLString("Select",BPConstants.PROC_PENDING_AGENT_REJECT_MAIN);	
					  log.debug("Pending Agent Reject Upload Proc 2:"+  strProcedure);
					  oCallableStatement2 = uploadProcExec(parametersIN,parametersOUT,strProcedure);
					  if(oCallableStatement2.getObject(4) != null){
							iErrorCode2 = oCallableStatement2.getInt(4);
							log.debug("Pending Agent Reject Upload II:ErrorCode-"+ iErrorCode2);
							log.debug("Pending Agent Reject Upload II:ErrorDesc-"+ oCallableStatement2.getString(5));
					  }	
				   }
				   break;
    		 //ALEX_FSD_Pending_Agents_Reject_Upload Starts
			//<Rel. Q2 (Feb 2011) - Start : Added by  Shrikrishna on 05-01-2011 FOR CR:Location wise restriction of instrument collection entryv1.4.DOC 	   
			   case BPConstants.PROC_SEQ_FOR_LOCATIONWISE_RESTRICTION_UPLOAD:
					  
				   log.debug("Location wise restriction Upload:  Preparing to call the procedures");
				   strProcedure = getSQLString("Select",BPConstants.PROC_LOCATIONWISE_RESTRICTION_TEMP);
				   log.debug("Location wise restriction Upload proc:"+  strProcedure);
				   
				  
					  oCallableStatement1 = getCallableStatement(strProcedure);
					
						oCallableStatement1.setString(1,strUserId);	
					
						oCallableStatement1.registerOutParameter(2,Types.INTEGER); 
						oCallableStatement1.registerOutParameter(3,Types.VARCHAR); 
						oCallableStatement1.execute(); 	
						
				   if(oCallableStatement1.getObject(2) != null)
				   {
						  iErrorCode1 = oCallableStatement1.getInt(2);  
						  log.debug("Location wise restriction Upload I:ErrorCode-"+ iErrorCode1);
						  log.debug("Location wise restriction Upload I:ErrorDesc-"+ oCallableStatement1.getString(3));				   			
				   }		
				   if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS)
				   {		
					  log.debug("Location wise restriction Upload:  Preparing to call the procedures");
					  strProcedure = getSQLString("Select",BPConstants.PROC_LOCATIONWISE_RESTRICTION_UPLD);	
					  log.debug("Location wise restriction Upload Proc 2:"+  strProcedure);

					  oCallableStatement2 = getCallableStatement(strProcedure);
						
					  oCallableStatement2.setString(1,strUserId);	
					  oCallableStatement2.setString(2,strOracleDirectoryPath);
					  oCallableStatement2.setString(3,strDataFile);
					  oCallableStatement2.registerOutParameter(4,Types.INTEGER); 
					  oCallableStatement2.registerOutParameter(5,Types.VARCHAR);
					  
					  oCallableStatement2.execute(); 	
					 
					  if(oCallableStatement2.getObject(4) != null){
							iErrorCode2 = oCallableStatement2.getInt(4);
							log.debug("Location wise restriction Upload II:ErrorCode-"+ iErrorCode2);
							log.debug("Location wise restriction Upload II:ErrorDesc-"+ oCallableStatement2.getString(5));
					  }	
				   }
				   break;
		// <Rel. Q2 (Feb 2011) - End : Added by  Shrikrishna on 05-01-2011 FOR CR:Location wise restriction of instrument collection entryv1.4.DOC 
				   
			// AGN929: AML & ULIP upload:: Added by Aradhana Pandey: 5_Jul_2017::**START**
			   case BPConstants.PROC_SEQ_AML_ULIP_TRNG_UPLD: 
				   log.debug("AML_ULIP_TRAINING Upload:  Preparing to call the procedures");
				   strProcedure = getSQLString("Select",BPConstants.PROC_AML_ULIP_TRNG_UPLD_MAIN);		  
				   log.debug("AML_ULIP_TRAINING Upload first Proc :"+ strProcedure);
				   oCallableStatement1 = getCallableStatement(strProcedure);
				   oCallableStatement1.setString(1,strUserId);	
				   oCallableStatement1.setString(2,strOracleDirectoryPath);
				   oCallableStatement1.setString(3,strDataFile);
				   oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   oCallableStatement1.execute(); 	
				   if(oCallableStatement1.getObject(4) != null)
				   {
					   iErrorCode1 = oCallableStatement1.getInt(4);  
					   log.debug("AML_ULIP_TRAINING Upload Error code 1 :"+ iErrorCode1);
					   log.debug("AML_ULIP_TRAINING Upload Error Desc 1 :"+ oCallableStatement1.getString(5));
					}					  
				   break;
               // AGN929: AML & ULIP upload:: Added by Aradhana Pandey: 5_Jul_2017::**ENDS**
			   // AGN946: Added by Aradhana Pandey: 13_Nov_2017::**START**
			   case BPConstants.PROC_SEQ_AGENT_REGISTRATION_UPLD: 
				   log.debug("Upload of Agent Registration Entry:  Preparing to call the procedures");
				   strProcedure = getSQLString("Select",BPConstants.PROC_AGENT_REGISTRATION_UPLD_MAIN);		  
				   log.debug("Upload of Agent Registration Entry Proc :"+ strProcedure);
				   oCallableStatement1 = getCallableStatement(strProcedure);
				   oCallableStatement1.setString(1,strUserId);	
				   oCallableStatement1.setString(2,strOracleDirectoryPath);
				   oCallableStatement1.setString(3,strDataFile);
				   oCallableStatement1.registerOutParameter(4,Types.INTEGER); 
				   oCallableStatement1.registerOutParameter(5,Types.VARCHAR); 
				   oCallableStatement1.execute(); 	
				   if(oCallableStatement1.getObject(4) != null)
				   {
					   iErrorCode1 = oCallableStatement1.getInt(4);  
					   log.debug("Upload of Agent Registration Entry Error code 1 :"+ iErrorCode1);
					   log.debug("Upload of Agent Registration Entry Error Desc 1 :"+ oCallableStatement1.getString(5));
					}					  
				   break;
                //AGN946: Added by Aradhana Pandey: 13_Nov_2017::**END**
		};
		
		if(iErrorCode1 == BPConstants.FLAG_FOR_PROC_SUCCESS && iErrorCode2 == BPConstants.FLAG_FOR_PROC_SUCCESS
		   && iErrorCode3 == BPConstants.FLAG_FOR_PROC_SUCCESS)
		{
			
			log.debug("FromFile Name = " + (strDirectoryPath + a_oDataResult.getDataFileWithoutPath()));
			log.debug("ToFile Name = " + (strMoveDirectoryPath + a_oDataResult.getDataFileWithoutPath()));
			
			File oFromFile = new File(strDirectoryPath + a_oDataResult.getDataFileWithoutPath());
			File oToFile = new File(strMoveDirectoryPath + a_oDataResult.getDataFileWithoutPath());
			copyFile(oFromFile,oToFile);
			oFromFile.delete();
			

		}		
		else if(iErrorCode1 != BPConstants.FLAG_FOR_PROC_SUCCESS)
		{
			bIsSuccessful = false;
		}
	 }
	 catch(SQLException sqlex)
	 {
		log.exception("callProceduresAfterUpload upload dax"+sqlex.getMessage());
		throw new EElixirException(sqlex, "MM902");
	 }
	 catch(Exception ex)
	 {
		throw new EElixirException(ex, "MM902");
	 }
	finally
	{
	  try
	  {
		if(oCallableStatement1 != null)
		oCallableStatement1.close();
			
		if(oCallableStatement2 != null)
		oCallableStatement2.close();
			
		if(oCallableStatement3 != null)
		oCallableStatement3.close();
			
	  }
	  catch(SQLException sqlex)
	  {
	  	log.debug("callProceduresAfterUpload upload dax 2" + sqlex);
		log.exception(sqlex.getMessage());
		throw new EElixirException(sqlex, "MM902");
	  }
	}		 
	 
	 log.exit("UploadDAX","callProceduresAfterUpload","bIsSuccessful=" + bIsSuccessful);
	 return bIsSuccessful;   	
   }
   /**
    * Created by AlexPandiyan | Date: 24-Sep-2010 
    * This reusable method used for executing procedure for upload functionality.
    * Ref:ALEX_FSD_Pending_Agents_Reject_Upload Starts
    */
   public CallableStatement uploadProcExec(ArrayList paramIn,ArrayList paramOut, String strProcedureName)throws EElixirException{
	   int iErrorCode = BPConstants.FLAG_FOR_PROC_SUCCESS;	  
	   CallableStatement oCallableStatement = null;	  
	   try{
		   int in=0;
		   oCallableStatement = getCallableStatement(strProcedureName);
		   if(paramIn!=null){
			   System.out.println("Size of Param..."+paramIn.size());
			   for(;in<paramIn.size();in++){
				   System.out.println("i....."+in);
				   System.out.println("InParam:"+paramIn.get(in).toString());
				   oCallableStatement.setString((in+1),paramIn.get(in).toString());	
			   }  
		   }
		   log.debug("IN Last Data==>"+in);
		   if(paramOut!=null){
			   for(int out=0;out<paramOut.size();out++){
				   log.debug("i....."+out);
				   log.debug("OutParam:-"+Integer.parseInt(paramOut.get(out).toString()));
				   if(paramOut.get(out).toString().equals(""+Types.INTEGER))
					   oCallableStatement.registerOutParameter((++in),Types.INTEGER); 
				   else if(paramOut.get(out).toString().equals(""+Types.VARCHAR))
					   oCallableStatement.registerOutParameter((++in),Types.VARCHAR); 
				   else
					   log.debug("Invalid Out Param Type");  
			   }
		   }
		   oCallableStatement.execute();	
		   if(oCallableStatement.getObject(4) != null)
		   {		  
				  iErrorCode = oCallableStatement.getInt(4);  
				  log.debug("Pending Agent Reject Upload:ErrorCode-@@@@"+ iErrorCode);
				  log.debug("Pending Agent Reject Upload:ErrorDesc-@@@@"+ oCallableStatement.getString(5));				   			
		   }		
	   }catch(SQLException sqlex){
			log.debug("Call Stack : uploadProcExec | Main Method Name : callProceduresAfterUpload | Class Name:UploadDAX |@try block "+sqlex.getMessage());
			throw new EElixirException(sqlex, "MM902");
	   }catch(Exception ex){
			throw new EElixirException(ex, "MM902");
	   }
	   return oCallableStatement;
   }
   
   /*** AALEX_FSD_Pending_Agents_Reject_Upload Ends  */
   public void copyFile(File argHere, File argThere) throws Exception
   {              
	 try 
	 {          
	 	log.debug("In copyFile() method &&&&&&&&&&&&&&&&&&&&&&&777");
	   FileInputStream fis = new FileInputStream(argHere);      
	   FileOutputStream fos = new FileOutputStream(argThere);  
	   int iDataSize = fis.available();                 
	   byte[] buffer = new byte[iDataSize];          
	   fis.read(buffer, 0, iDataSize);                    
	   fos.write(buffer, 0, buffer.length);                  
	   fis.close();                   
	   fos.close();          
	  } 
	   catch (IOException ioex)
	  {   
		  ioex.printStackTrace(); 
		  throw ioex;   
	  }    
   }



   public String getEMailAddress(String a_strUserId) throws EElixirException
   {
	 String strEMailAddress = null;
	 PreparedStatement pstmt = null;
	 ResultSet rsEMailAddress = null;
	 String strQuery ;
	 if(a_strUserId == null || a_strUserId.equals(""))
	 {
		 log.debug("User Id is null " + a_strUserId);
		 throw new EElixirException("UserIdisnull");
	 }
	 try
	 {  	
		  strQuery = getSQLString("Select",BPConstants.GET_EMAIL_ADDRESS);
		 pstmt = getPreparedStatement(strQuery);
		
		 pstmt.setString(1,a_strUserId);
		 rsEMailAddress = pstmt.executeQuery();
		 log.debug("after execute *******************************************");
		 if(rsEMailAddress.next())
		 {
			strEMailAddress = rsEMailAddress.getString("StrEmailAddr");
			log.debug("999999999999999 strEMailAddress = " + strEMailAddress);
		 }
		 /**Code changed for SSO userid since SSO ID not present in chm_sec_user_m.
			 * for new user we need to fetch from chm_sec_user_Sso_map
			 * Code changed by suma on 06-Aug_2013 Start
			 */
		 else
		 {
			 String strSSOQuery ="Select strssoid From   chm_sec_user_Sso_map Where " +
			 		     " upper(struserid) = UPPER(?)";
			 pstmt = getPreparedStatement(strSSOQuery);
			 
			 pstmt.setString(1,a_strUserId);
			 
			 ResultSet rsMap = pstmt.executeQuery();
				
				
				if (rsMap.next())
				{
					a_strUserId = rsMap.getString("strssoid");
				}
				
				 strQuery = getSQLString("Select",BPConstants.GET_EMAIL_ADDRESS);
				 pstmt = getPreparedStatement(strQuery);
				
				 pstmt.setString(1,a_strUserId);
				 rsEMailAddress = pstmt.executeQuery();
				 log.debug("SSO execute *******************************************");
				 if(rsEMailAddress.next())
				 {
					strEMailAddress = rsEMailAddress.getString("StrEmailAddr");
					log.debug(" SSO 999999999999999 strEMailAddress = " + strEMailAddress);
				 }
			 
		 }
		 
		// Code changed by suma on 06-Aug_2013 End
	 }
	 catch(SQLException sqlex)
	 {
		log.debug("1111111111  In sqlexception of getEMailAddress::: " + sqlex);	 	
		log.exception(sqlex.getMessage());
		throw new EElixirException(sqlex, "MM902");
	 }
	 catch(Exception ex)
	 {
		throw new EElixirException(ex, "MM902");
	 }
	finally
	{
	  try
	  {
		if(pstmt != null)
		   pstmt.close();			
	  }
	  catch(SQLException sqlex)
	  {
		log.debug("2222222222222  In sqlexception :: strEMailAddress::: " + sqlex);
		log.exception(sqlex.getMessage());
		throw new EElixirException(sqlex, "MM902");
	  }  	
	} 	
	 return strEMailAddress;
   }  
  
  
  public String[] getIPAddress() throws EElixirException
  {
  	String strIPAddress[] = new String[2];
  	PreparedStatement pstmt = null;
  	ResultSet rsIPAddress = null;

  	try
  	{  	
  		String strQuery = getSQLString("Select",BPConstants.GET_IP_ADDRESS);
		pstmt = getPreparedStatement(strQuery);	

		rsIPAddress = pstmt.executeQuery();
		log.debug("aaaaaaaaaaaaaaaaaa  :: after execute");		
		
		if(rsIPAddress.next())
		{
			strIPAddress[0] = rsIPAddress.getString("StrCDDesc");
			strIPAddress[1] = rsIPAddress.getString("StrSender");
			log.debug("0000000000000000000000:: strIPAddress = " +strIPAddress + ":: strIPAddress[1]" + strIPAddress[1]);
		}
  	}
	catch(SQLException sqlex)
	{
	   log.debug("1111111111  In sqlexception of getIPAddress::: " + sqlex);	 	
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex, "MM902");
	}
	catch(Exception ex)
	{
	   throw new EElixirException(ex, "MM902");
	}
   finally
   {
	 try
	 {
	   if(pstmt != null)
	   	  pstmt.close();			
	 }
	 catch(SQLException sqlex)
	 {
	   log.debug("2222222222222  In sqlexception 1111::: " + sqlex);
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex, "MM902");
	 }  	
   } 	
  	return strIPAddress;
  }



	public void sendErrorMail(DataResult a_oDataResult) throws EElixirException
	{
		 log.debug("@@@@@@@@@@@@@ in sendErrorMail::filename.csv= " + a_oDataResult.getDataFileWithoutPath()+"::"+
		     a_oDataResult.getStrLogFile() + ":::getStrDataFile = " + a_oDataResult.getStrDataFile());
		String strIPAddress[] = getIPAddress();
		String strEMailAddress = getEMailAddress(a_oDataResult.getStrUserId());
		
		boolean debug=false;
		Properties props=new Properties();
		props.put("mail.smtp.host",strIPAddress[0]);//CHANGE THE SMTP SERVER'S IN THE BRACKET
	
		Session session=Session.getDefaultInstance(props,null);
		session.setDebug(debug);
		log.debug("@@@@@@@@@@@@@ 1");
		Message msg=new MimeMessage(session);
		try
		{			
		
			String attFileName = a_oDataResult.getStrLogFile();		
			log.debug("@@@@@@@@@@@@@ 2: after attFileName = " + attFileName);			
			InternetAddress addressfrom=new InternetAddress(strIPAddress[1]); //put from address here
			msg.setFrom(addressfrom);
			log.debug("@@@@@@@@@@@@@ 3: after msg.setFrom :: addressfrom " + addressfrom);
			//InternetAddress addressto=new InternetAddress("@mastek.com");
			msg.setRecipients(Message.RecipientType.TO, new InternetAddress[] { new InternetAddress(strEMailAddress)}); //put to address here
						
			msg.setSubject(BPConstants.SUBJECT_MATTER);
			
			log.debug("@@@@@@@@@@@@@ 4");
			
			/**********************/
			/** set the sentDate */
			 msg.setSentDate(EElixirUtils.getSystemDate());
						System.out.println("AFTER DATE");			
			log.debug("@@@@@@@@@@@@@ 5::EElixirUtils.getSystemDate() " + EElixirUtils.getSystemDate());
			/** create the bodypart for the content */
			MimeBodyPart mbpContent = new MimeBodyPart();

			mbpContent.setText("");
			System.out.println("AFTER TEXT");

			

			/** create the bodypart for the attachment */
			MimeBodyPart mbpAttach = null;
			if(attFileName != null && (!(attFileName.equals(""))))
			{
				mbpAttach = new MimeBodyPart();
				log.debug("@@@@@@@@@@@@@ 6");
				/** attach the file to the Message */
				FileDataSource fds = new FileDataSource(attFileName);
				mbpAttach.setDataHandler(new DataHandler(fds));
				mbpAttach.setFileName(fds.getName());
				log.debug("@@@@@@@@@@@@@ 7 ******");				
				System.out.println("ATTACHMENT ADDED..");
			}

			Multipart mp = new MimeMultipart();

			/** add the bodypart of the content to the multipart */
			mp.addBodyPart(mbpContent);

			/** add the bodypart of the attachment to the multipart */
			if(mbpAttach != null)
				mp.addBodyPart(mbpAttach);
		
			log.debug("*************		8 *****************");

			/** set the multipart to the message */
			msg.setContent(mp);
			System.out.println("CONTENT ADDED..");
											
						
			/***********************/
			log.debug("*************		9 *****************");			
			Transport.send(msg);
			
			System.out.println(" message sent");
		}
		catch(MessagingException msgex)
		{
			throw new EElixirException(msgex,"MM902");
		}
		
	}




   /**
    * This function generates a new Seq no, on which the new record is inserted.
    * @return long Returns the next seq no generated for the benefit details
    * @throws EElixirException
    */
   public long getNextBatchPrcResultNbr() throws EElixirException
   {
       Statement oStmtNextSeq = null;
       long lSeqNo;
       Long lBenAdvSeqNo = null;
       String strNextSeqQuery = null;
       ResultSet oRsSeqNo = null;

       try
       {
           log.entry("UploadDAX","getNextBatchPrcResultNbr","void");
           strNextSeqQuery = getSQLString("Select",
                   BPConstants.BP_RESULT_SEQUENCE);

           oStmtNextSeq = getStatement();
           oRsSeqNo = oStmtNextSeq.executeQuery(strNextSeqQuery);
           oRsSeqNo.next();
           lSeqNo = oRsSeqNo.getLong(1);

           log.debug("Sequence No generated is --"+lSeqNo);

          return lSeqNo;
       }
       catch(SQLException sqlex)
       {
           //BP1014=Error while geenrating the sequence no for the batch process result table
           log.fatal("UploadDAX","getNextBatchPrcResultNbr",
                     "SQLException" + sqlex.getMessage());
           throw new EElixirDAXException(sqlex, "BP1014");
       }
       finally
       {
           try
           {
               if(oStmtNextSeq != null)
                   oStmtNextSeq.close();
           }
           catch(SQLException sqlex)
           {
               log.fatal("UploadDAX","getNextBatchPrcResultNbr",
                         "SQLException" + sqlex.getMessage());
               throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
           }
       }
   }// end of seq
   
   
   
   
   /**
	   *  gets the Error LOgs For the procedures
	   * @return DataResult
	   * @param DataResult
	   * @throws EElixirException
	   */
//	FindBug_Fix_SUNAINA_STARTED
	 public String getErrorLogs(DataResult _oDataResult)
			  throws EElixirException
//	FindBug_Fix_SUNAINA_ENDED
	  {
		ResultSet rsSearch = null;
		PreparedStatement pstmtSearch = null;
		String strQuery ="";
		String strMainProc="";
		String strResult = "";
		try
		{
			
			strQuery = getSQLString("Select",BPConstants.UPLOAD_ERROR_LIST);
			
			strMainProc = _oDataResult.getMainProcName();
			pstmtSearch = getPreparedStatement(strQuery);
			pstmtSearch.setString(1,strMainProc.trim().toUpperCase());	
			rsSearch = pstmtSearch.executeQuery();
			strResult = XMLConverter.getXMLString(rsSearch);
			
			
		  return strResult;
		  
		}
		catch(SQLException sqlex){
			//BP1007=Unable to retrieve the data for upload of Data File
		  log.debug(sqlex.getMessage());
		  throw new EElixirDAXException(sqlex, "BP1007");
		}
		finally
		{
		  try
		  {
			if(rsSearch != null)
			  rsSearch.close();
		  }
		  catch(SQLException sqlex)
		  {
			log.debug(sqlex.getMessage());
			throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
		  }
		}
	  }
	  
	  // Added by Manisha on 28-Jan-2015 for FIN816 - START
 	  public DataResult getFlagForSucc(DataResult _oDataResult) throws EElixirException
	  {
		  ResultSet rsSearch = null;
		  ResultSet rsSearchI = null;
		  PreparedStatement pstmtSearch = null;
		  PreparedStatement pstmtSearchI = null;
		  String strQuery ="";
		  String strQueryI ="";
		  String strMainProc="";
		  try
		  {
			  strQuery = getSQLString("Select",BPConstants.CHECK_FLAG_FOR_SUCC);
			  strMainProc = _oDataResult.getMainProcName();
			  pstmtSearch = getPreparedStatement(strQuery);
			  pstmtSearch.setString(1,strMainProc.trim().toUpperCase());	
			  rsSearch = pstmtSearch.executeQuery();
			  while(rsSearch.next())
			  {
				  if(rsSearch.getInt(1) == 1)
				  {
					  strQueryI = getSQLString("Select",BPConstants.CHECK_FLAG_FOR_SUCC_I);
					  pstmtSearchI = getPreparedStatement(strQueryI);
					  pstmtSearchI.setString(1,strMainProc.trim().toUpperCase());
					  rsSearchI = pstmtSearchI.executeQuery();
					  while(rsSearchI.next())
					  {
						  if(rsSearchI.getInt(1) == 9999)
						  {
							  _oDataResult.setBFlagSucc(true);
						  }
					  }
				  }
			  }
			  return _oDataResult;
		 }
		 catch(SQLException sqlex){
		   log.debug(sqlex.getMessage());
		   throw new EElixirDAXException(sqlex, "BP1007");
		 }
		 finally
		 {
		   try
		   {
			 if(rsSearch != null)
			   rsSearch.close();
		   }
		   catch(SQLException sqlex)
		   {
			 log.debug(sqlex.getMessage());
			 throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
		   }
		 }
	   }
 	   // Added by Manisha on 28-Jan-2015 for FIN816 - END
	  
	  public Integer getErrorCount(DataResult _oDataResult)
			   throws EElixirException
	   {
		 ResultSet rsSearch = null;
		 PreparedStatement pstmtSearch = null;
		 String strQuery ="";
		 String strMainProc="";
		 String strResult = "";
		 int icount =0;
		 try
		 {
			
			 strQuery = getSQLString("Select",BPConstants.UPLOAD_ERROR_LIST);
			
			 strMainProc = _oDataResult.getMainProcName();
			
 			 pstmtSearch = getPreparedStatement(strQuery);
			 pstmtSearch.setString(1,strMainProc.trim().toUpperCase());	
			 rsSearch = pstmtSearch.executeQuery();
		
			 while(rsSearch.next())
			 {
				icount++;
				
			 }

			 //oDataResult.setErrorLog(UploadErrorLogArray);
			
			 
			// strResult = XMLConverter.getXMLString(rsSearch);
			
			
		   return new Integer(icount);
		  
		 }
		 catch(SQLException sqlex){
			 //BP1007=Unable to retrieve the data for upload of Data File
		   log.debug(sqlex.getMessage());
		   throw new EElixirDAXException(sqlex, "BP1007");
		 }
		 finally
		 {
		   try
		   {
			 if(rsSearch != null)
			   rsSearch.close();
		   }
		   catch(SQLException sqlex)
		   {
			 log.debug(sqlex.getMessage());
			 throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
		   }
		 }
	   }
	  

	//Anantha_SuccessBounce_Upload_FS starts
	  //updateCCORECSCntrlStmt(a_oDataResult,BPConstants.PROC_SEQ_FOR_ECS_BANK_STMT_UPLD_NEW);
	  
	  /**
	    * This method updates a record in mms_credit_card_ctrlstmt when nSeqCCORECS = 35 or, 
	    * updates a record in mms_ecs_ctrl_stmt when nSeqCCORECS = 36
	    * @param oDataResult
	    * @param nSeqCCORECS
	    * @return the value of execution
	    * @throws EElixirException
	    */
	   private int updateCCORECSCntrlStmt(DataResult oDataResult, short nSeqCCORECS) throws EElixirException
	   {
		  PreparedStatement oPreparedStatement =null;
		  String strUpdateSql=null;
		  
		  
		   try{
			   
			   log.debug(" updateCCORECSCntrlStmt >> Data Inputted ECS OR CC >> "+oDataResult.toString());
			   
			   if(nSeqCCORECS==BPConstants.PROC_SEQ_FOR_CC_BANK_STMT_UPLD_NEW)
			   {
				   log.debug(" In PROC_SEQ_FOR_CC_BANK_STMT_UPLD_NEW ");

				 strUpdateSql = getSQLString("Update",BPConstants.UPDATE_CC_BNKSTMT_UPLOAD);
				log.debug(" Update Query : "+strUpdateSql);
		
				Object[] oArr =
			               {
			                   oDataResult.getSumGrossAmt(),
			                   oDataResult.getSumBankCharges(),//discount amount
			                   oDataResult.getSumServiceTax(),
			                   oDataResult.getSumNetAmnt(),
			                   oDataResult.getCCORECSRemarks(),
			                   oDataResult.getCCORECSCtrlStmtSeqNbr()	              
			               };
		
			   int[] iArr =
			               {
			                   Types.DOUBLE,
			                   Types.DOUBLE,
			                   Types.DOUBLE,
			                   Types.DOUBLE,
			                   Types.VARCHAR,
			                   Types.BIGINT
			                 
			               };
			   
			    oPreparedStatement =this.getPreparedStatement(strUpdateSql, oArr, iArr);
              	log.debug("Before execute update--"+oPreparedStatement);
              	
			   }
			   else if(nSeqCCORECS==BPConstants.PROC_SEQ_FOR_ECS_BANK_STMT_UPLD_NEW)
			   {
				   log.debug(" In PROC_SEQ_FOR_ECS_BANK_STMT_UPLD_NEW ");
				    strUpdateSql = getSQLString("Update",BPConstants.UPDATE_ECS_BNKSTMT_UPLOAD);
				   log.debug(" Update Query : "+strUpdateSql);
				   
				 //<!-- Rel.Q2 Starts Added by Alexpandiyan Dated: 7 Mar 2011 -->
					Object [] oArr =
				               {
							   oDataResult.getSumGrossAmt(),
			                   oDataResult.getSumBankCharges(),//discount amount
			                   oDataResult.getSumServiceTax(),
			                   oDataResult.getSumNetAmnt(),
			                   oDataResult.getCCORECSRemarks(),
			                   oDataResult.getCCORECSCtrlStmtSeqNbr()	                  
				               };
			
				   int [] iArr=
				               {
								   Types.DOUBLE,
				                   Types.DOUBLE,
				                   Types.DOUBLE,
				                   Types.DOUBLE,
				                   Types.VARCHAR,
				                   Types.BIGINT
				                 
				               };
				 //<!-- Rel.Q2 Ends Added by Alexpandiyan Dated: 7 Mar 2011 -->
				   oPreparedStatement =this.getPreparedStatement(strUpdateSql, oArr, iArr);
	               log.debug("Before execute update--"+oPreparedStatement);
				   
			   }

	                
	               	
	               	int  result = executeUpdate(oPreparedStatement);
	                log.debug("result of update in the detail......"+result);

	               
	               log.debug("UploadDAX >> updateCCORECSCntrlStmt");
	           
	           return result;
	           
	       }// end try
	       catch(SQLException sqlex)
	       {
	           log.fatal("UploadDAX","updateCCORECSCntrlStmt",sqlex.getMessage());
	           throw new EElixirDAXException(sqlex);
	       }
	       finally
	       {
	           try
	           {
	               if(oPreparedStatement != null)
	                   oPreparedStatement.close();
	           }
	           catch(SQLException sqlex)
	           {
	               log.fatal("UploadDAX","updateCCORECSCntrlStmt",
	                         sqlex.getMessage());
	               throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
	           }
	       }
	   }// end of updateCCORECSCntrlStmt
	  

	//Anantha_SuccessBounce_Upload_FS ends
	//Code added by Anup_Success_Bounce_Starts   
	   /**
	    * This method initiates the upload process which spawns another thread and
	    * returns the status as "Process Started"
	    * @param a_oDataResult
	    * @return
	    * @throws EElixirException
	    * @codeTag Code added by Anup_Success_Bounce_Starts
	    */
	   public DataResult createUploadSuccessBounce(DataResult a_oDataResult)
	           throws EElixirException
	   {
			String strResult ="";		  	
		      try
		      {
	    	  			callProceduresAfterUploadSuccessBounce(a_oDataResult);							 
						Integer iErrorCount =getErrorCount(a_oDataResult);
						a_oDataResult.setErrorCount(iErrorCount);
						strResult = getErrorLogs(a_oDataResult);
						a_oDataResult.setErrorLog(strResult);	
						a_oDataResult.setChekedFlag(true);
		          }
		          catch(Exception sqlex)
		          {
		              //BP1019=Error while Uploading the Data
		              log.fatal("UploadDAX","createBatchPrcDataMap",sqlex.getMessage());
		              throw new EElixirException(sqlex, "BP1019");
		          }
		          
				finally
				{
					 log.fatal("UploadDAX","createBatchPrcDataMap -->> Inside Finally","");
				}	          
		          
		          log.entry("UploadDAX","createDataForUpload","End---");
		    return a_oDataResult;
		  }
  
	   /**
	    * Code added by Anup_Success_Bounce_Starts
	    * @param a_oDataResult
	    * @return boolean 
	    */
	    public boolean callProceduresAfterUploadSuccessBounce(DataResult a_oDataResult) throws EElixirException
	    {
	 	log.entry("UploadDAX","callProceduresAfterUploadSuccessBounce","Entered ");   	
	 	 boolean bIsSuccessful = true;	 
	 	 short nProcSeq = 0;
	 	 String strDataFile = null;	 	
	 	 long lBatchPrcSeq = a_oDataResult.getLBatchPrcSeq().longValue();	 	 
	 	 strDataFile = a_oDataResult.getStrDataFile();	 
	 	 String strLocationCd= a_oDataResult.getLocationCd();
	  	 log.debug("IN Upload DAX :: callProceduresAfterUploadSuccessBounce :: lBatchPrcSeq= "+
	 	  lBatchPrcSeq + "## strLocationCd ::: " + strLocationCd+
	 	  "## strDataFile  :::"+strDataFile );		 	   
	 	 int iErrorCode1 = BPConstants.FLAG_FOR_PROC_SUCCESS;		   	
	 	 PropertyUtil oPropertyUtil = new PropertyUtil(Constants.SETUP_FILE);	
	 	 String strOracleDirectoryPath = oPropertyUtil.getProperty("download.oracle.dir");	
	 	 String strUserId = a_oDataResult.getStrUserId();	
	 		 	
	 	 String strProcedure = null; 	 	 
	 	 CallableStatement oCallableStatement = null; 	 
	 	 
	 	 try
	 	 {		log.debug(" a_oDataResult data : "+a_oDataResult.toString());
	 		
	 		if(a_oDataResult.getProcSeqNbr().shortValue()==BPConstants.PROC_SEQ_FOR_ECS_BANK_STMT_UPLD_NEW)
	 		{
		    log.debug(" Updating Table ..ECS");
			updateCCORECSCntrlStmt(a_oDataResult,BPConstants.PROC_SEQ_FOR_ECS_BANK_STMT_UPLD_NEW);
		   
		    strProcedure = getSQLString("Select",BPConstants.PROC_ECS_STMT_UPLOAD_NEW);		  
		    log.debug("ECS Statement Upload Third proc  :"+ strProcedure);
			oCallableStatement = getCallableStatement(strProcedure);
			oCallableStatement.setString(1,strUserId);
			oCallableStatement.setString(2,strOracleDirectoryPath);		
			oCallableStatement.setString(3,strDataFile);
			oCallableStatement.setLong(4,a_oDataResult.getCCORECSCtrlStmtSeqNbr().longValue());
			
			oCallableStatement.registerOutParameter(5,Types.INTEGER);
			oCallableStatement.registerOutParameter(6,Types.VARCHAR);
	 		}
	 		else if(a_oDataResult.getProcSeqNbr().shortValue()==BPConstants.PROC_SEQ_FOR_CC_BANK_STMT_UPLD_NEW)
	 		{
	 			log.debug(" Updating Table ..Credit Card");
				  updateCCORECSCntrlStmt(a_oDataResult,BPConstants.PROC_SEQ_FOR_CC_BANK_STMT_UPLD_NEW);
				  
				  strProcedure = getSQLString("Select",BPConstants.PROC_CREDITCARD_STMT_UPLOAD_NEW);		  
					log.debug("Credit Card Statement Upload Third and new Proc :"+ strProcedure);
										oCallableStatement = getCallableStatement(strProcedure);
										oCallableStatement.setString(1,strUserId);
										//Anantha_SuccessBounce_Upload_FS commented code as proc has been changed start
										oCallableStatement.setString(2,strOracleDirectoryPath);	
										oCallableStatement.setString(3,strDataFile);
										oCallableStatement.setLong(4,a_oDataResult.getCCORECSCtrlStmtSeqNbr().longValue());
										
										oCallableStatement.registerOutParameter(5,Types.INTEGER); 
										oCallableStatement.registerOutParameter(6,Types.VARCHAR); 
														 
	 			
	 		}
	 		
			oCallableStatement.execute(); 
			
								
			if(oCallableStatement.getObject(5) != null)
			{
			  iErrorCode1 = oCallableStatement.getInt(5);  
			  log.debug("ECS Statement Third proc Upload Error code 2 :"+ iErrorCode1);
			  log.debug("ECS Statement Third proc Upload Error Desc 2 :"+ oCallableStatement.getString(6));		
			 }				
	 		else if(iErrorCode1 != BPConstants.FLAG_FOR_PROC_SUCCESS)
	 		{
	 			bIsSuccessful = false;
	 		}
	 	 }
	 	 catch(SQLException sqlex)
	 	 {
	 		log.exception("callProceduresAfterUpload upload dax"+sqlex.getMessage());
	 		throw new EElixirException(sqlex, "MM902");
	 	 }
	 	 catch(Exception ex)
	 	 {
	 		throw new EElixirException(ex, "MM902");
	 	 }
	 	finally
	 	{
	 	  try
	 	  {
	 		if(oCallableStatement != null)
	 		oCallableStatement.close();		
	 			
	 	  }
	 	  catch(SQLException sqlex)
	 	  {
	 	  	log.debug("callProceduresAfterUpload upload dax 2" + sqlex);
	 		log.exception(sqlex.getMessage());
	 		throw new EElixirException(sqlex, "MM902");
	 	  }
	 	}		 	 
	 	 log.exit("UploadDAX","callProceduresAfterUpload","bIsSuccessful=" + bIsSuccessful);
	 	 return bIsSuccessful;   	
	    }//Code added by Anup_Success_Bounce_Ends
	//cols
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Starts> -->
	public boolean findMatchingRecordForSuccessBounce(int nProcSeq,
			long ctrlSeqNum, double dSumNetAmnt, String strCCORECSRemarks)
			throws EElixirException {
		String strResult = "";
		PreparedStatement pstmtQuery = null;
		long lSeqNo;
		String strNumberQuery = null;
		ResultSet oRsResult = null;
		ResultSet oRsResult1 = null;
		long lCashSeq = 0;
		short sStatus = 0;
		try {
			log.debug("Proc Seq No  is --" + nProcSeq);
			if (nProcSeq == BPConstants.PROC_SEQ_FOR_ECS_BANK_STMT_UPLD_NEW) {
				strNumberQuery = getSQLString("Select",
						BPConstants.SELECT_ECSLCASHSEQNO);
			} else if (nProcSeq == BPConstants.PROC_SEQ_FOR_CC_BANK_STMT_UPLD_NEW) {
				strNumberQuery = getSQLString("Select",
						BPConstants.SELECT_CCLCASHSEQNO);
			}
			log.debug("Selected Query Is ---->" + strNumberQuery);
			pstmtQuery = getPreparedStatement(strNumberQuery);
			pstmtQuery.setLong(1, ctrlSeqNum);
			log.debug("Parameter | Ctrl_Seq_No: --->" + ctrlSeqNum);
			oRsResult = pstmtQuery.executeQuery();
			log.debug("Query Executed Successfully" + strNumberQuery);
			if (oRsResult.next()) {
				lCashSeq = oRsResult.getLong(1);
			}
			log.debug("Parameter | Cash_Seq_No: --->" + lCashSeq);
			try {
				if (pstmtQuery != null)
					pstmtQuery.close();
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
			log.debug("Conection Closed Successfully");
			strNumberQuery = "";
			strNumberQuery = getSQLString("Select", BPConstants.SELECT_RESULT);
			log.debug("Query Is ---->" + strNumberQuery);
			pstmtQuery = getPreparedStatement(strNumberQuery);
			log.debug("Conection Established Successfully");
			pstmtQuery.setLong(1, lCashSeq);
			pstmtQuery.setString(2, strCCORECSRemarks);
			pstmtQuery.setDouble(3, dSumNetAmnt);
			oRsResult1 = pstmtQuery.executeQuery();
			log.debug("Query Executed Successfully" + strNumberQuery);
			if (oRsResult1.next()) {
				sStatus = oRsResult1.getShort(1);
			}
			log.debug("Query Executed Successfully" + strNumberQuery);
			log.debug("lcashbankseqnbr  --" + lCashSeq + "strnarration  --"
					+ strCCORECSRemarks + "dtAmnt  --" + dSumNetAmnt);
			if (sStatus == 1) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			log.debug("Exception Occured" + e.getMessage());
			throw new EElixirException(e, "BP1019");
		} finally {
			try {
				if (pstmtQuery != null)
					pstmtQuery.close();
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "mm902");
			}
		}
	}
	public int exitSuccessBounceUploadECSCCS(int nProcSeq,long ctrlSeqNum,String strUpdatedBy)
			throws EElixirException {
		int strResult = 0;
		PreparedStatement pstmtQuery = null;
		String uploadQuery = null;
		ResultSet oRsResult = null;
		try {
			// Rajeev_Success/Bounce_statements_upload_facility_09032011 Start
			log.debug("Proc Seq No  is --" + nProcSeq);
			if (nProcSeq == BPConstants.PROC_SEQ_FOR_ECS_BANK_STMT_UPLD_NEW) {
				uploadQuery = getSQLString("Update",BPConstants.UPDATE_ECS_EXIT);
			} else if (nProcSeq == BPConstants.PROC_SEQ_FOR_CC_BANK_STMT_UPLD_NEW) {
				uploadQuery = getSQLString("Update",BPConstants.UPDATE_CCS_EXIT);
			}
			log.debug("Selected Query Is ---->" + uploadQuery);
			pstmtQuery = getPreparedStatement(uploadQuery);
			pstmtQuery.setString(1, strUpdatedBy);
			pstmtQuery.setLong(2, ctrlSeqNum);
			log.debug("Parameter | Ctrl_Seq_No: --->" + ctrlSeqNum);
			strResult = pstmtQuery.executeUpdate();
			log.debug("Query Executed Successfully" + uploadQuery);			
			log.debug("Update Result: --->" + strResult);			
		} catch (Exception e) {
			log.debug("Exception Occured" + e.getMessage());
			 throw new EElixirException(e, "BP1019");
		} finally {
			try {
				if (pstmtQuery != null)
					pstmtQuery.close();
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "mm902");
			}
		}
		return strResult;
	}
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Ends> 
	// Added by Varun: Release 15.1 POS 989 For collection Upload start
	public String getCSVDataForNH(String userId,String uploadFile) throws EElixirException{		
		//PreparedStatement pstmtQuery = null;
		CallableStatement cstmtQuery = null;
		String nonHybdCollectionQuery = null;
		ResultSet oRsResult = null;
		String fileName = null;
		try {
			nonHybdCollectionQuery = getSQLString("Select",BPConstants.NONHYBRID_COLN);
			cstmtQuery = getCallableStatement(nonHybdCollectionQuery);
			 log.debug("the procedure is -> " + nonHybdCollectionQuery);
			 cstmtQuery.setString(1,userId);
			 cstmtQuery.registerOutParameter(2,OracleTypes.CURSOR);
			 cstmtQuery.registerOutParameter(3,Types.INTEGER);
			 cstmtQuery.registerOutParameter(4,Types.INTEGER); 
			 cstmtQuery.registerOutParameter(5,Types.VARCHAR);
			 cstmtQuery.execute();
			 if(cstmtQuery.getObject(4) != null)
			 {
				 log.debug(cstmtQuery.getString(5));
				 throw new EElixirException(cstmtQuery.getString(5));
			 }
			 if(cstmtQuery.getInt(3)> 0)
			 {
				 if(cstmtQuery.getObject(2) != null)
				 {
					 oRsResult = (ResultSet)cstmtQuery.getObject(2);		
				 }
				 
				 if (oRsResult != null)
				 {
					 //create file with resultset
					 try{
						PropertyUtil oPropertyUtil = new PropertyUtil(Constants.SETUP_FILE);
						String strDirectoryPath = oPropertyUtil.getProperty("upload.dir.in");
						fileName = "NH_"+uploadFile;
						log.debug("UploadDax.getCSVDataForNH csvFilePath: "+fileName);
						fileName  = fileName.substring(0,fileName.indexOf("."))+BPConstants.CSV_EXT;
						log.debug("UploadDax.getCSVDataForNH csvFilePath After: "+fileName);
						CSVWriter writer = new CSVWriter(new FileWriter(strDirectoryPath+"\\"+fileName));
						writer.writeAll(oRsResult, true);
						writer.close();
					 }
					 catch(IOException e)
					 {
						 log.debug(e.getMessage());
						 fileName = null;
					 }
			     }
			}else{
				log.debug("UploadDax.getCSVDataForNH csvFilePath: No data returned");
			}			
		}catch(SQLException e){
			log.debug(e.getMessage());			
			log.debug("UploadDax.getCSVDataForNH csvFilePath: No data returned");		
			throw new EElixirException(e, "mm902");
		}		
		return fileName;
	}
	// Added by Varun: Release 15.1 POS 989 For collection Upload end
	// AGN946: Added by Aradhana Pandey: 15_Nov_2017::**START**
	public String getCSVDataForAgentRegUpload(String userId,String uploadFile) throws EElixirException{		
		CallableStatement cstmtQuery = null;
		String agentRegUploadQuery = null;
		ResultSet oRsResult = null;
		String fileName = null;
		try {
			agentRegUploadQuery = getSQLString("Select",BPConstants.PROC_AGENT_REGISTRATION_UPLD_CSV);
			cstmtQuery = getCallableStatement(agentRegUploadQuery);
			 log.debug("Upload of Agent Registration Entry procedure -> " + agentRegUploadQuery);
			 cstmtQuery.setString(1,userId);
			 cstmtQuery.registerOutParameter(2,OracleTypes.CURSOR);
			 cstmtQuery.registerOutParameter(3,Types.INTEGER);
			 cstmtQuery.registerOutParameter(4,Types.INTEGER); 
			 cstmtQuery.registerOutParameter(5,Types.VARCHAR);
			 cstmtQuery.execute();
			 if(cstmtQuery.getObject(4) != null)
			 {
				 log.debug(cstmtQuery.getString(5));
				 throw new EElixirException(cstmtQuery.getString(5));
			 }
			 if(cstmtQuery.getInt(3)> 0)
			 {
				 if(cstmtQuery.getObject(2) != null)
				 {
					 oRsResult = (ResultSet)cstmtQuery.getObject(2);		
				 }
				 
				 if (oRsResult != null)
				 {
					 //create file with resultset
					 try{
						PropertyUtil oPropertyUtil = new PropertyUtil(Constants.SETUP_FILE);
						String strDirectoryPath = oPropertyUtil.getProperty("upload.dir.in");
						fileName = "ARE_"+uploadFile;
						log.debug("UploadDax.getCSVDataForAgentRegUpload csvFilePath: "+fileName);
						fileName  = fileName.substring(0,fileName.indexOf("."))+BPConstants.CSV_EXT;
						log.debug("UploadDax.getCSVDataForAgentRegUpload csvFilePath After: "+fileName);
						CSVWriter writer = new CSVWriter(new FileWriter(strDirectoryPath+"\\"+fileName));
						writer.writeAll(oRsResult, true);
						writer.close();
					 }
					 catch(IOException e)
					 {
						 log.debug("Upload of Agent Registration Entry: "+e.getMessage());
						 fileName = null;
					 }
			     }
			}else{
				log.debug("UploadDax.getCSVDataForAgentRegUpload csvFilePath: No data returned");
			}			
		}catch(SQLException e){
			log.debug(e.getMessage());			
			log.debug("UploadDax.getCSVDataForAgentRegUpload csvFilePath: No data returned");		
			throw new EElixirException(e, "mm902");
		}		
		return fileName;
	}
	// AGN946: Added by Aradhana Pandey: 15_Nov_2017::**START**
}// end of class

