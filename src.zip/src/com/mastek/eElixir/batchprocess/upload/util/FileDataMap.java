package com.mastek.eElixir.batchprocess.upload.util;
/**
 * <p>Title: FileMapper.java</p>
 * <p>Description:This class contains the data mapped according to the specified
 *  'To' and 'From' value for a row.Each column is a element of the Arraylist.
 *  </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 *
 *	Modified On      Modified By          Reason
 *	
 *	18/8/2003			Amit Nigam		Added iColumnSequence 
 *
 * */

import java.io.Serializable;

public class FileDataMap implements Serializable
{
    private Long lBatchPrcSeq;
    private String strColName;
    private Long lFromDataValue;
    private Long lToDataValue;
    private Integer iColumnSequence;
    

    public Long getLBatchPrcSeq() {
        return lBatchPrcSeq;
    }
    public void setLBatchPrcSeq(Long lBatchPrcSeq) {
        this.lBatchPrcSeq = lBatchPrcSeq;
    }
    public Long getLFromDataValue() {
        return lFromDataValue;
    }
    public void setLFromDataValue(Long lFromDataValue) {
        this.lFromDataValue = lFromDataValue;
    }
    public Long getLToDataValue() {
        return lToDataValue;
    }
    public void setLToDataValue(Long lToDataValue) {
        this.lToDataValue = lToDataValue;
    }
    public String getStrColName() {
        return strColName;
    }
    public void setStrColName(String strColName) {
        this.strColName = strColName;
    }
  
    public void setColumnSequence(Integer a_iColumnSequence)
    {
    	this.iColumnSequence = a_iColumnSequence;
    }

	public Integer getColumnSequence()
	{
		return iColumnSequence;
	}

}// end of class