/********************************************************************
*
*  PROJECT						: AMAL
*  MODULE NAME					: BATCH PROCESS
*  FILENAME						: DataLoader
*  AUTHOR						: Heena Jain
*  VERSION						: 1.0
*  CREATION DATE				: June 10,2003
*  COMPANY						: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.0      11/06/2003     Heena Jain    Change in loadProperties, removed
*                                       the file protocol
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.batchprocess.upload.util;

import java.io.File;
import java.util.Properties;

import com.mastek.eElixir.batchprocess.util.BPConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.PropertyUtil;
import com.mastek.eElixir.common.util.EncryptionDecryptionUtil;//	Ananth_FSEncDcr_REL8.0 
import com.mastek.eElixir.common.util.PasswordBasedEncryptor;//	Ananth_FSEncDcr_REL8.0

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class DataLoader
{
    private static Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
    private Properties _oProps = null;
    private LoaderEnv _oLoaderEnv = null;
    private DataResult _oDataResult = null;
	private boolean bIsProcExec = true;
	private boolean bIsSuccessful= true;
	

    /**
     *
     * @param controlFile
     * @param dataFile
     * @param logFile
     * @param a_oDataResult
     */
    public DataLoader(String controlFile, String dataFile,
                      String logFile, DataResult a_oDataResult)
    {
        log.entry("DataLoader", "Constructor", "Begin--------");
        // set the data result object
        this._oDataResult = a_oDataResult;

        // set the names of the control, data and the log file
        _oLoaderEnv = new LoaderEnv();
        _oLoaderEnv.setControlFile(controlFile);
        _oLoaderEnv.setDataFile(dataFile);
        _oLoaderEnv.setLogFile(logFile);

        log.debug("Before loading the properties");
        // get the values for the the command line
        loadProperties();

        log.debug("Before call to uploadData");
        // call the upload data process
        uploadData();
    }

    /**
     * DEPRECATED
     * Method will load all external properties to set up DataLoader to execute SQL Loader program
     * @return HashMap hash will contain all key values
     */
    public void loadProperties()
    {
        log.entry("DataLoader","loadProperties","Begin---");
        try
        {
            String strFileSeparator = File.separator;
            PropertyUtil oPropertyUtil  = new PropertyUtil(Constants.SETUP_FILE);
            //("/com/mastek/eElixir/properties/application.properties");

            String strCmd = oPropertyUtil.getProperty("run.env.shell");
            String host = oPropertyUtil.getProperty("db.host");
			
			//	Ananth_FSEncDcr_REL8.0 Starts
			String strIsEncryptedPWD= oPropertyUtil.getProperty("db.pwd.isEncrypted") ;
		            String strDBPasssword=null;
            		
					  if(strIsEncryptedPWD!=null&&!strIsEncryptedPWD.trim().equals(""))
					  {
							  strDBPasssword=oPropertyUtil.getProperty("db.pwd");
							  //Fetching Actuval DB Password
							  strDBPasssword=EncryptionDecryptionUtil.getDBPassword(strIsEncryptedPWD,strDBPasssword);
	
					  }
					  else
						  {
							  log.debug(" db.pwd.isEncrypted attribute value is not set in application.properties file ");
						  }
	 		
				  //Ananth_FSEncDcr_REL8.0 Ends
            
            String usr = oPropertyUtil.getProperty("db.user"); 
			

            log.debug("strCmd : "+strCmd);
            log.debug("host : "+host);
            log.debug("usr : "+usr);

            _oLoaderEnv.setCmd(strCmd);
            _oLoaderEnv.setDBSchema(host);
            _oLoaderEnv.setPassword(strDBPasssword);
            _oLoaderEnv.setUser(usr);

            log.exit("DataLoader","loadProperties","End --");

        }
        catch (Exception ex){
            log.debug("DataLoader--Loading Parameters Failed  " +ex);
            ex.printStackTrace();
        }
        log.debug("DataLoader--loadProperties--End");
    }

    /**
     * Method will build commandline parameters to pass for SQL Loader
     *
     * @return String
     */
    public String generateCommandLine()
    {
        log.debug("DataLoader--generateCommandLine--Begin");

        String strCommandLine = _oLoaderEnv.getCmd() +  " userid=" + _oLoaderEnv.getUser() + "/" + _oLoaderEnv.getPassword() +
                                "@" + _oLoaderEnv.getDBSchema() + " control=" + _oLoaderEnv.getControlFile() +
                                " data=" + _oLoaderEnv.getDataFile() + " log=" + _oLoaderEnv.getLogFile() ;

        log.debug("DataLoader--generateCommandLine--CMD Line : " + strCommandLine );

        log.debug("DataLoader--generateCommandLine--End");
        return strCommandLine;
    }


    /**
    * Method will Upload Data for Bank, Address or Other Life Insurance
    * @param int
    * @return int execution status indicates Success if O, failure other wise
    */
    public void uploadData()
    {
    	
log.debug("nMessDelOption from DataResult-------->"+_oDataResult.getMessDelOption());  


if(_oDataResult.getMessDelOption()!= null && _oDataResult.getMessDelOption().intValue() == BPConstants.FLAG_FOR_EMAIL_MESSAGES)
{
	/*This code is for generating the error messages on the screen*/
		String strCmdLine = generateCommandLine();
		UploadProcess sup = new UploadProcess(_oDataResult, strCmdLine);
		bIsProcExec =sup.upload();
		bIsSuccessful=sup.getIsSuccessful();
}
else
{ 
	/*This code is to generate the mail*/
		String strCmdLine = generateCommandLine();
		StartUploadProcess sup = new StartUploadProcess(_oDataResult, strCmdLine);
		sup.start();
}

        log.debug("DataLoader--upLoadData--End");

    }
    
	public boolean getIsProcExec()
	{
		return this.bIsProcExec;
	}    
	
	public boolean getIsSuccessful()
	{
		return this.bIsSuccessful;
	}  


}// end of class
