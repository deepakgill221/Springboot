/********************************************************************
*
*  PROJECT						: AMAL
*  MODULE NAME					: BATCH PROCESS
*  FILENAME						: Parser
*  AUTHOR						: Heena Jain
*  VERSION						: 1.0
*  CREATION DATE				: June 5,2003
*  COMPANY						: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1       10/6/2003     Heena Jain    Changed the parse method
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.batchprocess.upload.util;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */



public class LoaderEnv
{
    private String _strUser ;
    private String _strPassword ;
    private String _strDBSchema;
    private String _strCmd;

    private String _strControlFile ;
    private String _strDataFile;
    private String _strLogFile;


    public void setCmd(String a_strCmd )
    {
        this._strCmd = a_strCmd;
    }

    public String getCmd()
    {
        return 	this._strCmd;
    }


    public void setLogFile(String a_strLog )
    {
        this._strLogFile = a_strLog;
    }

    public String getLogFile()
    {
        return 	this._strLogFile;
    }

    public void setUser(String a_strUser )
    {
        this._strUser = a_strUser;
    }

    public String getUser()
    {
        return 	this._strUser;
    }

    public void setPassword(String a_strPassword)
    {
        this._strPassword = a_strPassword;
    }

    public String getPassword()
    {
        return 	this._strPassword;
    }

    public void setDBSchema(String a_strDBSchema)
    {
        this._strDBSchema = a_strDBSchema;
    }

    public String getDBSchema()
    {
        return 	this._strDBSchema;
    }


    public void setControlFile(String a_strControlFile )
    {
        this._strControlFile = a_strControlFile ;
    }

    public String getControlFile()
    {
        return this._strControlFile;
    }

    public void setDataFile(String a_strDataFile )
    {
        this._strDataFile = a_strDataFile ;
    }

    public String getDataFile()
    {
        return this._strDataFile;
    }

/*    public void setExitState(Short a_nExitState)
    {
        this._nExitState = a_nExitState;
    }

    public Short getExitState()
    {
        if (this._nExitState.intValue() > 0)
        {
            //set the state as Error
            this._nExitState = new Short("1");
        }

        return this._nExitState ;
    }
*/



    public String toString()
    {
        return "LoaderEnv:: ControlFile: " + _strControlFile + " DataFile: "  + _strDataFile +
                " User " + _strUser + " DBSchema: " + _strDBSchema ;
    }
}

