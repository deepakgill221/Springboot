/********************************************************************
*
*  PROJECT						: AMAL
*  MODULE NAME					: BATCH PROCESS
*  FILENAME						: StartUploadProcess
*  AUTHOR						: Heena Jain
*  VERSION						: 1.0
*  CREATION DATE				: June 10,2003
*  COMPANY						: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1      14/6/2003      Heena Jain    Change in the return type of the
*                                       createPrcResult
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.batchprocess.upload.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;

import com.mastek.eElixir.batchprocess.upload.dax.UploadDAX;
import com.mastek.eElixir.batchprocess.util.BPConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author Heena Jain
 * @version 1.0
 */

public class StartUploadProcess extends Thread
{
    private static Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

    private Connection _oConn = null;
    private String strCmdLine;
    private DataResult oDataResult = null;


    public StartUploadProcess(DataResult a_oDataResult, String strCmdLine)
    {
        log.entry("StartUploadProcess","Constructor","Start----");
        this.oDataResult = a_oDataResult;
        this.strCmdLine = strCmdLine;
    }

    public void run()
    {
        log.entry("StartUploadProcess","run","Begin----");
        try
        {
            UploadDAX oUploadDax = getDAX();
            log.debug("After getting the dax instance");
            /* insert a record with the batch process master id in
            * com_prc_result with the status as STARTED,
            * ntype as 1 -- Upload, start time - systime,
            * dtCreated - sysdate, STRCREATEDBY -- logged user
            * STRUSERID -- logged user
            */
            log.debug("Before creating a record in the log history");
            int createResult = oUploadDax.createPrcResult(oDataResult);

            /**
             * Call the sql loader to upload the data to the table
             */
            log.debug("Before executeSQLLoader");
            executeSQLLoader(strCmdLine);

        /**
         * Parse the log file and the get the appropriate values
         */
            log.debug("Before parseLogFile ---");
            LogDataValue oLogDataVal = oUploadDax.parseLogFile(oDataResult);
            log.debug("Log File Parsed ---");

        /**
         * Update com_prc_result with the status of the upload
         */
            int result = oUploadDax.updatePrcResult(oDataResult, oLogDataVal);
            
            // if the upload to the temp table is successful i.e. all the records inserted
            // then only call the process to put the data from the temp table
           // to production table 
            // initiate the process depending on the batch process id
            short nProcSeqNbr = -1;
            long lSumOfRecordsNotInserted = 0;
            if(oLogDataVal != null)
            {
            	 lSumOfRecordsNotInserted = (oLogDataVal.getLRecordsDiscarded().longValue() +
											 oLogDataVal.getLRecordsRejected().longValue() +
											 oLogDataVal.getLRecordsSkipped().longValue());
											 
				oDataResult.setProcSeqNbr(oUploadDax.getProcedureSeqNbr(oDataResult));	
				if(oDataResult.getProcSeqNbr() != null)
				{
				  nProcSeqNbr = oDataResult.getProcSeqNbr().shortValue();
				}						 
            	 
            	if(lSumOfRecordsNotInserted <= 1 || (nProcSeqNbr == 
            	    BPConstants.PROC_SEQ_FOR_BANK_STMT_UPLOAD && 
            	    oLogDataVal.getLRecordsRejected().longValue() == 1))
            	{
				  oUploadDax.callProceduresAfterUpload(oDataResult);
            	}
            	else
            	{
					oUploadDax.sendErrorMail(oDataResult);
            	}
            }
            
        }     
        catch(Exception e)
        {
            log.debug("Error in the run method"+e.getMessage());
        }
        finally
        {
            try
            {
                if(_oConn != null)
                    _oConn.close();
            }
            catch(SQLException sqlex)
            {
              log.debug("Error while closing the Connection "+sqlex.getMessage());
            }
        }
    }

    /**
    * Method will spawn a process for execution of SQL Loader
    * @param String a_strLoaderParam the parameters to fire SQL Loader with
    * @return int execution status indicates Success if O, failure other wise
    */
    public int executeSQLLoader(String a_strLoaderParam) throws EElixirException
    {
        log.entry("StartUploadProcess","executeSQLLoader","Begin"+a_strLoaderParam);
        Process p = null;
        BufferedReader err =null;
        try
        {
            p = Runtime.getRuntime().exec(a_strLoaderParam);
            log.debug("Process Object ");
            //p.waitFor();
            err	= new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = err.readLine()) != null)	System.out.println(line);

        }
        catch (Exception ex)
        {
            log.debug("DataLoader--Execution Halted Midway. ");
            log.debug("DataLoader--Cause : " + ex);
            ex.printStackTrace();
            new EElixirException(ex, "P9505");

        }
//      FindBug_Fix_SUNAINA_STARTS
        finally{
        	try {
				err.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
//      FindBug_Fix_SUNAINA_ENDED
        log.exit("StartUploadProcess","executeSQLLoader"," Exit with "  + p.exitValue());
        return p.exitValue();
    }

    /**
       * Gets the Dax object and sets the connection on it.
       * @return UploadDAX
       * @throws EElixirException
       */
      private UploadDAX getDAX() throws EElixirException
      {
          UploadDAX _oUploadDAX = null;
          try
          {
              if(_oConn == null || _oConn.isClosed()){
                  _oConn = DBConnection.getConnection();
//                  _oConn.setAutoCommit(false);
              }
              _oUploadDAX = new UploadDAX();
              _oUploadDAX.setConnection(_oConn);
          }
          catch(SQLException sqlEx)
          {
              throw new EElixirException(sqlEx, sqlEx.getMessage());
          }
          return _oUploadDAX;
    }

}
