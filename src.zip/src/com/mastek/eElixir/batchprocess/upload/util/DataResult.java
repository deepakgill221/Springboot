/********************************************************************
*
*  PROJECT						: AMAL
*  MODULE NAME					: BATCH PROCESS
*  FILENAME						: DataResult
*  AUTHOR						: Heena Jain
*  VERSION						: 1.0
*  CREATION DATE				: June 5,2003
*  COMPANY						: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1       10/6/2003    Heena Jain     Added strDataFile,alPreviewRowData, lBatchPrcSeq
* 1.2       11/6/2003    Heena Jain     Added iProcessStartStatus, strUserId
* 1.3       12/6/2003    Heena Jain     Added lPrcResultSeq, strLogFile and strControlFile
* 1.4       17/6/2003    Heena Jain     Added alDownloadCriteria
* 1.5   	18/8/2003	 Amit Nigam		Added iFormat and iDelimiter
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.batchprocess.upload.util;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author Heena Jain
 * @version 1.0
 */
public class DataResult implements Serializable
{
    private ArrayList alFileDataMap;
    private ArrayList alTableDefResult;
    private ArrayList alPreviewRowData;
    private ArrayList alDownloadCriteria;

    private Short nIsMapped;
    private Long lBatchPrcSeq;
    private Long lPrcResultSeq;
    private Integer iProcessStartStatus;

    private String strTableName;
    private String strBatchPrcUrl;
    private String strUserId;
    private String strDataFile;
	private String strDataFileWithoutPath;
    private String strControlFile;
    private String strLogFile;
    
	private Integer iFormat;
	private String strDelimiter;
	private String strLocationCd;
	private Short nProcSeqNbr;
	private String strResult;
	private String strMainProcName;
	private Integer iErrorCount;
	private Short nMessDelOption;
	//Added by Srikanth CTS for Bulk Agent Movement Upload
	private Short nMovementType;
	private String strActionID;
	
	// Added by Manisha on 28-Jan-2015 for FIN816 - START
	private boolean bFlagSucc;
	
	public boolean isBFlagSucc() {
		return bFlagSucc;
	}

	public void setBFlagSucc(boolean bFlagSucc) {
		this.bFlagSucc = bFlagSucc;
	}
	// Added by Manisha on 28-Jan-2015 for FIN816 - END
	
	//Anantha_SuccessBounce_Upload_FS starts
	private Double dSumGrossAmt;
	private Double dSumBankCharges;
	private Double dSumServiceTax;
	private Double dSumNetAmnt;
	private Long lCCORECSCtrlStmtSeqNbr;
	private String strCCORECSRemarks;
	private boolean bChekedFlag;
	
	 /** State of object
     *   @return State of the object instance
     */
    public String toString() 
    {
    	return " dSumGrossAmt : " + dSumGrossAmt+" dSumBankCharges : " + dSumBankCharges+
        " dSumServiceTax : " + dSumServiceTax+" dSumNetAmnt : " + dSumNetAmnt+
        " lCCORECSCtrlStmtSeqNbr : " + lCCORECSCtrlStmtSeqNbr+
        " strCCORECSRemarks : " + strCCORECSRemarks +" bChekedFlag : "+bChekedFlag+" lPrcResultSeq : "+lPrcResultSeq + 
        " bFlagSucc: " + bFlagSucc;
    }
	
	public Double getSumGrossAmt() {
		return dSumGrossAmt;
	}

	public void setSumGrossAmt(Double dSumGrossAmt) {
		this.dSumGrossAmt = dSumGrossAmt;
	}

	public Double getSumBankCharges() {
		return dSumBankCharges;
	}

	public void setSumBankCharges(Double dSumBankCharges) {
		this.dSumBankCharges = dSumBankCharges;
	}

	public Double getSumServiceTax() {
		return dSumServiceTax;
	}

	public void setSumServiceTax(Double dSumServiceTax) {
		this.dSumServiceTax = dSumServiceTax;
	}

	public Double getSumNetAmnt() {
		return dSumNetAmnt;
	}

	public void setSumNetAmnt(Double dSumNetAmnt) {
		this.dSumNetAmnt = dSumNetAmnt;
	}

	public Long getCCORECSCtrlStmtSeqNbr() {
		return lCCORECSCtrlStmtSeqNbr;
	}

	public void setCCORECSCtrlStmtSeqNbr(Long lCCORECSCtrlStmtSeqNbr) {
		this.lCCORECSCtrlStmtSeqNbr = lCCORECSCtrlStmtSeqNbr;
	}

	public String getCCORECSRemarks() {
		return strCCORECSRemarks;
	}

	public void setCCORECSRemarks(String strCCORECSRemarks) {
		this.strCCORECSRemarks = strCCORECSRemarks;
	}

	
	public boolean getChekedFlag() {
		return bChekedFlag;
	}

	public void setChekedFlag(boolean chekedFlag) {
		bChekedFlag = chekedFlag;
	}

	//Anantha_SuccessBounce_Upload_FS ends
	
		
		

    public DataResult()
    {
    }
    
	public void setErrorCount(Integer _iErrorCount )
	{
		this.iErrorCount = _iErrorCount;		
	}

	public Integer getErrorCount()
	{
		return this.iErrorCount;
	}
	
	public void setMessDelOption(Short _nMessDelOption)
	{
		this.nMessDelOption = _nMessDelOption;		
	}

	public Short getMessDelOption()
	{
		return this.nMessDelOption;
	}
			
	public void setMainProcName(String a_strMainProcName)
	{
		this.strMainProcName = a_strMainProcName;		
	}
	
	public String getMainProcName()
	{
		return this.strMainProcName;
	}
	public void setProcSeqNbr(Short a_nProcSeqNbr)
	{
		this.nProcSeqNbr = a_nProcSeqNbr;		
	}
	
	public Short getProcSeqNbr()
	{
		return this.nProcSeqNbr;
	}

    public String getLocationCd()
    {
    	return strLocationCd;
    }

	public void setLocationCd(String a_strLocationCd)
	{
	    strLocationCd = a_strLocationCd;
	}

    public ArrayList getAlFileDataMap() {
        return alFileDataMap;
    }
    public void setAlFileDataMap(ArrayList alFileDataMap) {
        this.alFileDataMap = alFileDataMap;
    }
    public ArrayList getAlTableDefResult() {
        return alTableDefResult;
    }
    public void setAlTableDefResult(ArrayList alTableDefResult) {
        this.alTableDefResult = alTableDefResult;
    }
    public Short getNIsMapped() {
        return nIsMapped;
    }
    public void setNIsMapped(Short nIsMapped) {
        this.nIsMapped = nIsMapped;
    }
    public String getStrTableName() {
        return strTableName;
    }
    public void setStrTableName(String strTableName) {
        this.strTableName = strTableName;
    }
    public String getStrBatchPrcUrl() {
        return strBatchPrcUrl;
    }
    public void setStrBatchPrcUrl(String strBatchPrcUrl) {
        this.strBatchPrcUrl = strBatchPrcUrl;
    }
    public String getStrDataFile() {
        return strDataFile;
    }
    public void setStrDataFile(String strDataFile) {
        this.strDataFile = strDataFile;
    }
    
	public String getDataFileWithoutPath() {
		return strDataFileWithoutPath;
	}
	public void setDataFileWithoutPath(String strDataFileWithoutPath) {
		this.strDataFileWithoutPath = strDataFileWithoutPath;
	}    
    
    public ArrayList getAlPreviewRowData() {
        return alPreviewRowData;
    }
    public void setAlPreviewRowData(ArrayList alPreviewRowData) {
        this.alPreviewRowData = alPreviewRowData;
    }
    public Long getLBatchPrcSeq() {
        return lBatchPrcSeq;
    }
    public void setLBatchPrcSeq(Long lBatchPrcSeq) {
        this.lBatchPrcSeq = lBatchPrcSeq;
    }
    public Integer getIProcessStartStatus() {
        return iProcessStartStatus;
    }
    public void setIProcessStartStatus(Integer iProcessStartStatus) {
        this.iProcessStartStatus = iProcessStartStatus;
    }
    public String getStrUserId() {
        return strUserId;
    }
    public void setStrUserId(String strUserId) {
        this.strUserId = strUserId;
    }
    public Long getLPrcResultSeq() {
        return lPrcResultSeq;
    }
    public void setLPrcResultSeq(Long lPrcResultSeq) {
        this.lPrcResultSeq = lPrcResultSeq;
    }
    public String getStrLogFile() {
        return strLogFile;
    }
    public void setStrLogFile(String strLogFile) {
        this.strLogFile = strLogFile;
    }
    public String getStrControlFile() {
        return strControlFile;
    }
    public void setStrControlFile(String strControlFile) {
        this.strControlFile = strControlFile;
    }
    public ArrayList getAlDownloadCriteria() {
        return alDownloadCriteria;
    }
    public void setAlDownloadCriteria(ArrayList alDownloadCriteria) {
        this.alDownloadCriteria = alDownloadCriteria;
    }
    
    public void setDelimiter(String a_strDelimiter)
    {
    	this.strDelimiter = a_strDelimiter;
    }
    
    public String getDelimiter()
    {
    	return strDelimiter;
    }
    
	public void setFormat(Integer a_iFormat)
	{
		this.iFormat = a_iFormat;
	}
    
	public Integer getFormat()
	{
		return iFormat;
	}
	
    
	public void setErrorLog(String _strResult)
	{
		this.strResult = _strResult;
	}    
	
	public String getErrorLog()
	 {
			return this.strResult;
	}
	//Added by Srikanth CTs
	public void setMovementType(Short _nMovementType)
	{
		this.nMovementType = _nMovementType;
	}    
	
	public Short getMovementType()
	 {
			return this.nMovementType;
	}
	
	public void setActionID(String _strActionID)
	{
		this.strActionID = _strActionID;
	}    
	
	public String getActionID()
	 {
			return this.strActionID;
	}
	private Short serviceRequest;

	public Short getServiceRequest() {
		return serviceRequest;
	}

	public void setServiceRequest(Short serviceRequest) {
		this.serviceRequest = serviceRequest;
	}
	

	
	
	//End by Srikanth CTs

}