/********************************************************************
*
*  PROJECT						: AMAL
*  MODULE NAME					: BATCH PROCESS
*  FILENAME						: LogDataValue
*  AUTHOR						: Heena Jain
*  VERSION						: 1.0
*  CREATION DATE				: June 12,2003
*  COMPANY						: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.batchprocess.upload.util;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author Heena Jain
 * @version 1.0
 */

public class LogDataValue {

    private String strElapsedTime;
    private String strEndTime;
    private Long lRecordsRead;
    private Long lRecordsSkipped;
    private Long lRecordsRejected;
    private Long lRecordsDiscarded;

    public LogDataValue() {
    }
    public Long getLRecordsDiscarded() {
        return lRecordsDiscarded;
    }
    public void setLRecordsDiscarded(Long lRecordsDiscarded) {
        this.lRecordsDiscarded = lRecordsDiscarded;
    }
    public Long getLRecordsRead() {
        return lRecordsRead;
    }
    public void setLRecordsRead(Long lRecordsRead) {
        this.lRecordsRead = lRecordsRead;
    }
    public Long getLRecordsRejected() {
        return lRecordsRejected;
    }
    public void setLRecordsRejected(Long lRecordsRejected) {
        this.lRecordsRejected = lRecordsRejected;
    }
    public Long getLRecordsSkipped() {
        return lRecordsSkipped;
    }
    public void setLRecordsSkipped(Long lRecordsSkipped) {
        this.lRecordsSkipped = lRecordsSkipped;
    }
    public String getStrElapsedTime() {
        return strElapsedTime;
    }
    public void setStrElapsedTime(String strElapsedTime) {
        this.strElapsedTime = strElapsedTime;
    }
    public String getStrEndTime() {
        return strEndTime;
    }
    public void setStrEndTime(String strEndTime) {
        this.strEndTime = strEndTime;
    }
}