/********************************************************************
*
*  PROJECT						: AMAL
*  MODULE NAME					: BATCH PROCESS
*  FILENAME						: Parser
*  AUTHOR						: Heena Jain
*  VERSION						: 1.0
*  CREATION DATE				: June 5,2003
*  COMPANY						: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1       10/6/2003     Heena Jain    Changed the parse method
* 1.2       11/6/2003     Heena Jain    Changed the logic for the start index and
*                                       end Index
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.batchprocess.upload.util;

/**
 * <p>Title: Parser.java</p>
 * <p>Description:This class parses each row of the data file according to the
 * specified column width.
 * </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 * */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class Parser
{
    private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

    private String fileName= null;
    int[] from;
    int[] to;
    private String strDelimiter = "";

    public Parser(String fileName, int[] from, int[] to, String a_strDelimiter)
    {
        this.fileName = fileName;
        log.debug("Parser.fileName:"+fileName);
        this.from = from;
        this.to = to;
        this.strDelimiter = a_strDelimiter;
    }

    /** This method is called when the data file needs to be parsed according the
     *  column mapping provided in the array of the From and To. It returns a Araylist
     * which contains the mapped data. Currently this method parses the first 10 lines of
     * the data file which can be showed for the previous purpose.
     *
     * @return ArrayList  The mapped data in the form of a arraylist
     **/
    public ArrayList parseFile() throws EElixirException
    {
        ArrayList rowData = null;
        try
        {
            log.entry("Parser","parseFile","Start of ParserFile()");
            // create a file reader
            FileReader fr = new FileReader(new File(fileName));
            log.debug("After File Reader object"+fr);
            // create a buffered reader
            BufferedReader br = new BufferedReader(fr);
            log.debug("After Buffered Reader object "+br);

//            int from[] ={0,5,8,15};
//            int to[] = {4,7,14,21};

            String s,s2 = new String();
            rowData = new ArrayList();
            int rowCount=1;
            while((s = br.readLine())!= null)
            {
                s2=s;
                log.debug("Line Read is :"+s2);
                // Curently the parse function is called for the first 10 lines of a
                //the data file
                if(rowCount==10)
                    break;
                else
                {
					ArrayList colData = null;
					log.debug("In Parser.java :: in parseFile() method:: rowcount < 10");
					if(strDelimiter.equals(""))
					{					
                    	//(For FIXED FORMAT) call the method to parse the string which contains one row from the data file
                    	colData = parse(s2);
					}
					else
					{
						log.debug("going inside parseForDelimited() method:: just before calling parseForDelimited()");
						//(For DELIMITED FORMAT) call the method to parse the string which contains one row from the data file
						colData = parseForDelimited(s2);						
					}
                    // set the row data to the arraylist
                    rowData.add(colData);
                }
                rowCount++;
                log.debug("Rows Read :"+rowCount);
            }
        }
        catch(Exception e)
        {
            //BP1012=Error while Parsing the Data File.
            rowData = null;
            log.debug("Error while parsing the file");
            throw new EElixirException(e,"BP1012");
        }
        // return the arraylist which contains the data for the rows
        return rowData;
    }// end of parseFile

    /** This method takes in the string which is a row from the data file,according
     * to the values as specified in the'From' and 'To' array the contents of the
     * string are tokenized and added to the arraylist.
     *
     * @return ArrayList  The column data
     **/
    private ArrayList parse(String s) throws EElixirException
    {
        ArrayList colData= null;
        try
        {
            log.entry("Parser","parse","Start---");
            colData = new ArrayList(from.length);

            for(int i=0; i<from.length; i++)
            {
                String colValue ="";
                int startIndex = from[i]-1;
                log.debug("startIndex------"+startIndex);
                int endIndex = to[i];
                log.debug("endIndex------"+endIndex);

/*                if(from[i] ==1)
                {
                    endIndex = endIndex-1;
                    log.debug("CHANGED endIndex------"+endIndex);
                }
*/
                colValue = s.substring(startIndex,endIndex);
                log.debug("Col["+i+"] :-----"+colValue);
                colData.add(colValue);
            }
        }
        catch(IndexOutOfBoundsException iobe)
        {
            //BP1012=Error while Parsing the Data File.
            colData = null;
            log.debug("Exception in parse-----"+iobe);
            throw new EElixirException(iobe,"Error while Parsing","BP1012");
        }
        catch(Exception e)
        {
            //BP1012=Error while Parsing the Data File.
            colData = null;
            log.debug("Exception in parse-----"+e);
            throw new EElixirException(e,"Error while Parsing","BP1012");
        }
        return colData;
    }// end of parse

/**
 * This method parses the string on the basis of the delimiter
 * @param a_strLine String
 * @return ArrayList alDataInRequiredSequence
 */
	private ArrayList parseForDelimited(String a_strLine)
	{
		 log.debug("In Parser.java :: parseForDelimited() just entered");
		ArrayList alDataInRequiredSequence = null;
		String strTempData = null;
		StringTokenizer stTokenizer = new StringTokenizer(a_strLine,strDelimiter);		
		
		int iNumberOfTokens = stTokenizer.countTokens();
		String strTokens[] = new String[iNumberOfTokens];
		
		log.debug("@@@@@@@@@@@  iNumberOfTokens = "+iNumberOfTokens);		
		
		int iCount = 0;
		int iNumberOfColumns = from.length;
		int iSequence = 0;
		
		while(stTokenizer.hasMoreTokens())
		{			
			strTokens[iCount] = stTokenizer.nextToken();
			iCount++;
		}
		
		alDataInRequiredSequence = new ArrayList();
		for(iCount = 0; iCount < iNumberOfColumns; iCount++)
		{
			log.debug("iCount ************************** " + iCount);
			iSequence = from[iCount];
			strTempData = strTokens[iSequence - 1];
			log.debug("iCount 1************************** " + strTempData);	
			if(strTempData == null || strTempData.equals(""))
			{
				strTempData = "";		
			}
			log.debug("iCount 2************************** " + strTempData);
			alDataInRequiredSequence.add(strTempData);
			log.debug("#########  strTokens[iSequence - 1]  :: " + strTokens[iSequence - 1]);
		}
		
		log.debug("$$$$$$$$$$$$$$$$$ alDataInRequiredSequence :: " + alDataInRequiredSequence);
		return alDataInRequiredSequence;
	} // end of method 'parseForDelimited()'

    public String toString()
    {
        return "FileName --"+fileName + "From Length--"+from.length+ "To Length--"+ to.length;
    }

}// end of class
