/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch process
*  FILENAME			: UploadSLLocalHome.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 05/06/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.batchprocess.upload.ejb.sessionbean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

import com.mastek.eElixir.common.exception.EElixirException;
/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This UploadSLLocalHome home interface provides one create method  </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 */
public interface UploadSLLocalHome extends EJBHome
{

    /**
     * Called by the client to create an EJB bean instance.
     *  It requires a matching pair in
     * the bean class, i.e. ejbCreate().
     * @throws javax.ejb.CreateException
     * @throws javax.ejb.RemoteException
     * return BenefitSL
     */
    public UploadSLLocal create()
            throws RemoteException, CreateException,  EElixirException;
}