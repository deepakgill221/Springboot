/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME		: Batch Process
 *  FILENAME		: UploadSLEJB.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 05/06/2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.0      09/06/2003    Heena Jain   Added getPreviewData(), createDataForUpload()
 * 1.1      17/06/2003    Heena Jain   Added downloadData(DataResult a_oDataResult)
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.batchprocess.upload.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.batchprocess.tabledefn.util.TableInfoResult;
import com.mastek.eElixir.batchprocess.upload.dax.UploadDAX;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: eElixir</p>
 * <p>Description: This UploadSLEJB session bean acts as an interface for the
 *  JobView Entity bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 */

public class UploadSLEJB implements SessionBean
{

    /**
     * Constructor of the UploadSLEJB class
     */
    public UploadSLEJB    ()
    {

    }

    /**
     * Called by the container to create a session bean instance. Its parameters typically
     * contain the information the client uses to customize the bean instance for its use.
     * It requires a matching pair in the bean class and its home interface.
     * @throws EElixirException
     * @throws CreateException
     */
    public void ejbCreate    () throws RemoteException, CreateException,  EElixirException
    {

    }

    /**
     * A container invokes this method before it ends the life of the session object. This
     * happens as a result of a client's invoking a remove operation, or when a container
     * decides to terminate the session object after a timeout. This method is called with
     * no transaction context.
     */
    public void ejbRemove    ()
    {

    }

    /**
     * The activate method is called when the instance is activated from its 'passive' state.
     * The instance should acquire any resource that it has released earlier in the ejbPassivate()
     * method. This method is called with no transaction context.
     */
    public void ejbActivate    ()
    {

    }

    /**
     * The passivate method is called before the instance enters the 'passive' state. The
     * instance should release any resources that it can re-acquire later in the ejbActivate()
     * method. After the passivate method completes, the instance must be in a state that
     * allows the container to use the Java Serialization protocol to externalize and store
     * away the instance's state. This method is called with no transaction context.
     */
    public void ejbPassivate    ()
    {

    }

    /**
     * Set the associated session context. The container calls this method after the instance
     * creation. The enterprise Bean instance should store the reference to the context
     * object in an instance variable. This method is called with no transaction context.
     * @param sc SessionContext
     */

    public void setSessionContext    (SessionContext sc)
    {
        this._EJBContext = sc;
    }

    /**
     * This method calls the DAX download Data
     * @param a_oDataResult
     * @return
     * @throws EElixirException
     */
    public DataResult downloadData(DataResult a_oDataResult)
            throws RemoteException, EElixirException
    {
        DataResult oDataResult = null;
        log.entry("UploadSLEJB","downloadData","Start ..");
        try
          {
            _oUploadDAX = getDAX();

            oDataResult = _oUploadDAX.downloadData(a_oDataResult);
             log.debug("UploadSLEJB--Result Obtained"+ oDataResult);
            }
            catch(EElixirException eex)
            {
                _EJBContext.setRollbackOnly();
                log.debug("UploadSLEJB--EElixirException -- downloadData " + eex);
                throw eex;
            }
            finally
            {
                try
                {
                    if(_oConnection != null)
                        DBConnection.closeConnection(_oConnection);
                }
                catch(EElixirException eex)
                {
                    throw new EJBException(eex);
                }
            }
        return oDataResult;

    }// end of downloadData

    /**
     *  This method calls the dax method which in turn uploads the data file
     * @param a_oDataResult
     * @return
     * @throws EElixirException
     * 
     */

    public DataResult createDataForUpload(DataResult a_oDataResult)
            throws RemoteException, EElixirException
    {
        DataResult oDataResult = null;
        log.entry("UploadSLEJB","createDataForUpload","Start ..");
        try
          {
            _oUploadDAX = getDAX();

            oDataResult = _oUploadDAX.createDataForUpload(a_oDataResult) ;
             log.debug("UploadSLEJB--Result Obtained"+ oDataResult);
            }
            catch(EElixirException eex)
            {
                _EJBContext.setRollbackOnly();
                log.debug("UploadSLEJB--EElixirException " + eex);
                throw eex;
            }
            finally
            {
                try
                {
                    if(_oConnection != null)
                        DBConnection.closeConnection(_oConnection);
                }
                catch(EElixirException eex)
                {
                    throw new EJBException(eex);
                }
            }
        return oDataResult;

    }// end of createDataForUpload

    /**
     * This method is used for getting the display for the preview of the mapped
     * data file.
     * @param a_oDataResult
     * @return
     * @throws EElixirException
     */
    public DataResult getPreviewData(DataResult a_oDataResult)
            throws RemoteException, EElixirException
    {
        DataResult oDataResult = null;
        log.entry("UploadSLEJB","getPreviewData","Start ..");
        try
          {
            _oUploadDAX = getDAX();

            oDataResult = _oUploadDAX.getPreviewData(a_oDataResult) ;
             log.debug("UploadSLEJB--Result Obtained"+ oDataResult);
            }
            catch(EElixirException eex)
            {
                _EJBContext.setRollbackOnly();
                log.debug("UploadSLEJB--EElixirException " + eex);
                throw eex;
            }
            finally
            {
                try
                {
                    if(_oConnection != null)
                        DBConnection.closeConnection(_oConnection);
                }
                catch(EElixirException eex)
                {
                    throw new EJBException(eex);
                }
            }
        return oDataResult;
    }

    /**
     * This method get the columns and the attributes defined for the column for
     * the selected table.
     * @param lBatchPrcSeq
     * @param strTableName
     * @param nIsMapped
     * @return
     * @throws EElixirException
     */
    public DataResult searchTableColDefn(long lBatchPrcSeq,String strTableName
            , short nIsMapped) throws RemoteException, EElixirException
    {
        DataResult oDataResult = null;
        log.entry("UploadSLEJB","searchTableColDefn","Start .."+lBatchPrcSeq);
        try
          {
            _oUploadDAX = getDAX();

            oDataResult = _oUploadDAX.getTableColDefn(lBatchPrcSeq,
                      strTableName, nIsMapped) ;
             log.debug("UploadSLEJB--Result Obtained"+ oDataResult);
            }
            catch(EElixirException eex)
            {
                _EJBContext.setRollbackOnly();
                log.debug("UploadSLEJB--EElixirException " + eex);
                throw eex;
            }
            finally
            {
                try
                {
                    if(_oConnection != null)
                        DBConnection.closeConnection(_oConnection);
                }
                catch(EElixirException eex)
                {
                    throw new EJBException(eex);
                }
            }
        return oDataResult;
    }
    /**
     * Gets the data based on the parameter of DVO
     * @param a_oResultObject Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     */
    public String searchUploadTables(TableInfoResult a_oTableInfoResult)
            throws  RemoteException, EElixirException
    {
        try
        {
            log.entry("UPLOADSLEJB","searchUploadTables","Start");
            _oUploadDAX = getDAX();
            log.debug("UploadSLEJB--After Lookup");
            _strXML = _oUploadDAX.getUploadTables(a_oTableInfoResult);
        }
        catch(EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            Exception e= ejbex.getCausedByException();
            if (e instanceof EElixirException)
            {
                throw (EElixirException)e;
            }
            else
            {
                throw ejbex;
            }
        }
        catch(EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }
        finally
        {
            try
            {
                if(_oConnection != null)
                    DBConnection.closeConnection(_oConnection);
            }
            catch(EElixirException eex)
            {
                throw new EJBException(eex);
            }
        }
        log.debug(_strXML);
        return _strXML;
    }


	/**
		 * This method get the Error Logs for Executed Procedure
		 * @param _oDataResult
		 * @return DataResult
		 * @throws EElixirException
		 */
//  FindBug_Fix_SUNAINA_STARTS
		public String getErrorLogs(DataResult _oDataResult) throws RemoteException, EElixirException
		{

			String strResult= null;
			
		
			
			try
			  {
				_oUploadDAX = getDAX();

				strResult = _oUploadDAX.getErrorLogs(_oDataResult) ;
//				FindBug_Fix_SUNAINA_ENDED
				 log.debug("UploadSLEJB--Result Obtained"+ strResult);
				}
				catch(EElixirException eex)
				{
					_EJBContext.setRollbackOnly();
					log.debug("UploadSLEJB--EElixirException " + eex);
					throw eex;
				}
				finally
				{
					try
					{
						if(_oConnection != null)
							DBConnection.closeConnection(_oConnection);
					}
					catch(EElixirException eex)
					{
						throw new EJBException(eex);
					}
				}
			return strResult;
		}
		
		

    /**
     * Gets the Dax object and sets the connection on it.
     * @return UploadDAX
     * @throws EElixirException
     */
    private UploadDAX getDAX() throws EElixirException
    {
        UploadDAX _oUploadDAX = null;
        try
        {
            if(_oConnection == null || _oConnection.isClosed())
            {
                _oConnection = DBConnection.getConnection();
            }
            _oUploadDAX = new UploadDAX();
            _oUploadDAX.setConnection(_oConnection);
        }
        catch(SQLException sqlEx)
        {
            throw new EElixirException(sqlEx, sqlEx.getMessage());
        }
        return _oUploadDAX;
    }
    /**
     *  This method calls the dax method which in turn uploads the data file
     * @param a_oDataResult
     * @return
     * @throws EElixirException
     * Code added by Anup_Success_Bounce_Starts
     */

    public DataResult createUploadSuccessBounce(DataResult a_oDataResult)
            throws RemoteException, EElixirException
    {
        DataResult oDataResult = null;
        log.entry("UploadSLEJB","createDataForUpload","Start ..");
        try
          {
            _oUploadDAX = getDAX();

            oDataResult = _oUploadDAX.createUploadSuccessBounce(a_oDataResult) ;
             log.debug("UploadSLEJB--Result Obtained"+ oDataResult);
            }
            catch(EElixirException eex)
            {
                _EJBContext.setRollbackOnly();
                log.debug("UploadSLEJB--EElixirException " + eex);
                throw eex;
            }
            finally
            {
                try
                {
                    if(_oConnection != null)
                        DBConnection.closeConnection(_oConnection);
                }
                catch(EElixirException eex)
                {
                    throw new EJBException(eex);
                }
            }
        return oDataResult;

    }//Code added by Anup_Success_Bounce_Ends
    
	// <CODE_TAG:
	// Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5
	// Dated: 14/03/2011 Added By: Alexpandiyan Starts>
	public boolean findMatchingRecordsForSuccessBounce(int nProcSeq,
			long ctrlSeqNum, double dSumNetAmnt, String strCCORECSRemarks)
			throws RemoteException, EElixirException {
		boolean result = false;

		log.entry("UploadSLEJB", "createDataForUpload", "Start ..");
		try {
			_oUploadDAX = getDAX();

			result = _oUploadDAX.findMatchingRecordForSuccessBounce(nProcSeq,
					ctrlSeqNum, dSumNetAmnt, strCCORECSRemarks);
			log.debug("UploadSLEJB--Result Obtained" + result);
		} catch (EElixirException eex) {
			_EJBContext.setRollbackOnly();
			log.debug("UploadSLEJB--EElixirException " + eex);
			throw eex;
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eex) {
				throw new EJBException(eex);
			}
		}
		return result;

	}
	public int exitSuccessBounceUploadECSCCS(int nProcSeq,long ctrlSeqNum,String strUpdatedBy)
			throws RemoteException, EElixirException {
		int result = 0;
		log.entry("UploadSLEJB", "createDataForUpload", "Start ..");
		try {
			_oUploadDAX = getDAX();
			result = _oUploadDAX.exitSuccessBounceUploadECSCCS(nProcSeq,ctrlSeqNum, strUpdatedBy);
			log.debug("UploadSLEJB--Result Obtained" + result);
		} catch (EElixirException eex) {
			_EJBContext.setRollbackOnly();
			log.debug("UploadSLEJB--EElixirException " + eex);
			throw eex;
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eex) {
				throw new EJBException(eex);
			}
		}
		return result;
	}

	//Added  by Varun: Release 15.1 For POS 989 Non Hybrid COllection Upload start
	public String getCSVDataForNH(String strUserId,String uploadFile) throws RemoteException, EElixirException {
		String fileName = null;
		log.entry("UploadSLEJB", "getCSVDataForNH", "Start ..");
		try {
			_oUploadDAX = getDAX();
			fileName = _oUploadDAX.getCSVDataForNH(strUserId,uploadFile);
			log.debug("UploadSLEJB--Result Obtained" + fileName);
		} catch (EElixirException eex) {
			_EJBContext.setRollbackOnly();
			log.debug("UploadSLEJB--EElixirException " + eex);
			throw eex;
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eex) {
				throw new EJBException(eex);
			}
		}
		return fileName;
	}
	//Added  by Varun: Release 15.1 For POS 989 Non Hybrid COllection Upload end
    
	//AGN946: Added by Aradhana Pandey: 15_Nov_2017::**START**
	public String getCSVDataForAgentRegUpload(String userId,String uploadFile) throws EElixirException,RemoteException
	{
    String fileName = null;
		log.entry("UploadSLEJB", "getCSVDataForAgentRegUpload", "START ..");
		try {
			_oUploadDAX = getDAX();
			fileName = _oUploadDAX.getCSVDataForAgentRegUpload(userId,uploadFile);
			log.debug("UploadSLEJB-Upload of Agent Registration Entry-Result Obtained" + fileName);
		} catch (EElixirException eex) {
			_EJBContext.setRollbackOnly();
			log.debug("UploadSLEJB--EElixirException " + eex);
			throw eex;
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eex) {
				throw new EJBException(eex);
			}
		}
		log.entry("UploadSLEJB", "getCSVDataForAgentRegUpload", "END ..");
		return fileName;
	}
	//AGN946: Added by Aradhana Pandey: 15_Nov_2017::**END**
	
    /**
     * Attributes declaration
     */
    private Connection _oConnection = null;
    private String _strXML;
    public SessionContext _EJBContext = null;

    private UploadDAX _oUploadDAX;

    private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
}