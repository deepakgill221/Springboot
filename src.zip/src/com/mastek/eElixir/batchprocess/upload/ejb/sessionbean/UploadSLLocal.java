/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME	    : Batch Process
 *  FILENAME		: UploadSLLocal.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 05/06/2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1      09/06/2003    Heena Jain   Added getPreviewData(), createDataForUpload()
 * 1.2      17/06/2003    Heena Jain   Added downloadData(DataResult oDataResult)
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.batchprocess.upload.ejb.sessionbean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.batchprocess.tabledefn.util.TableInfoResult;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This JobViewSL Local interface provides method for getting the
 *  data from JobView bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface UploadSLLocal extends EJBObject
{
    /**
     * Gets the data based on the parameter of DVO
     * @param a_oTableInfoResult Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     * @throws RemoteException
     */
    public String searchUploadTables(TableInfoResult a_oTableInfoResult)
            throws RemoteException, EElixirException;

    public DataResult searchTableColDefn(long lBatchPrcSeq,String strTableName
            , short nIsMapped) throws RemoteException, EElixirException;

    public DataResult getPreviewData(DataResult a_oDataResult)
            throws RemoteException, EElixirException;

    public DataResult createDataForUpload(DataResult a_oDataResult)
            throws RemoteException, EElixirException;

    public DataResult downloadData(DataResult a_oDataResult)
            throws RemoteException, EElixirException;
//	FindBug_Fix_SUNAINA_STARTED          
	public String getErrorLogs(DataResult a_oDataResult)
				throws RemoteException, EElixirException;
//	FindBug_Fix_SUNAINA_ENDED
	//Code added by Anup_Success_Bounce_Starts
	 public DataResult createUploadSuccessBounce(DataResult a_oDataResult)
     throws RemoteException, EElixirException;
	//Code added by Anup_Success_Bounce_Ends
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Starts>             
	 public boolean findMatchingRecordsForSuccessBounce(int nProcSeq, long ctrlSeqNum, double dSumNetAmnt,String strCCORECSRemarks)
	    throws EElixirException,RemoteException;
	 public int exitSuccessBounceUploadECSCCS(int nProcSeq, long ctrlSeqNum,String strUpdatedBy)
	    throws EElixirException,RemoteException;
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Ends>      

	//Added  by Varun: Release 15.1 For POS 989 Non Hyrbid COllection Upload
	 public String getCSVDataForNH(String userId,String uploadFile) throws EElixirException,RemoteException ;
	 
	//AGN946: Added by Aradhana Pandey: 15_Nov_2017::**START**
	public String getCSVDataForAgentRegUpload(String userId,String uploadFile) throws EElixirException,RemoteException;
	//AGN946: Added by Aradhana Pandey: 15_Nov_2017::**END**
}