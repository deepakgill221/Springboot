/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch Process
*  FILENAME			: PreviewData.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 9/6/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * This action class takes in the mapping data and mapps the data from the text or
 * the flat to the mapped data and displays the preview to the user. C
 * Copyright (c) 2002 Mastek Ltd
 * Date       09/06/2003
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class PreviewData extends BPAction
{
  private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * Constructor of the PreviewData class
   */
  public PreviewData()
  {
  }

  /**
   * Uses the unique id of JobView and gets the detail for that JobView.
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    DataResult oDataResult = null;

    try
    {
        log.entry("PreviewData","process","start");
        BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);

        FetchData fd = new FetchData();
        oDataResult = fd.fetchUploadData(a_oRequest);
        oDataResult = remoteBPSL.getPreviewData(oDataResult);
        log.debug("PreviewData--result accessed");
        a_oRequest.setAttribute("calledFor","done");
        setResult(oDataResult);
        log.debug("PreviewData--result is set");
    }
    catch(RemoteException rex)
    {
        log.debug("RemoteException in Action :"+rex);
      throw new EElixirException(rex, "BP1005");
    }
  }
}