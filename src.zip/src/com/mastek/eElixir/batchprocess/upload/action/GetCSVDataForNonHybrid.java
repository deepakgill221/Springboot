/********************************************************************
*
*  PROJECT			: MAMM
*  MODULE NAME		: Batch Process
*  FILENAME			: GetCSVDataForNonHybrid.java
*  AUTHOR			: Varun
*  VERSION			: 1.0
*  CREATION DATE	: 24/07/2014
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * This action class initiates the process to get the data from Non Hybrid seperation table
 * and returns back the list to create CSV. 
 * @author  Varun
 * @version 1.0
 * 
 */

package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class GetCSVDataForNonHybrid extends BPAction
{
  private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * Constructor of the GetCSVDataForNonHybrid class
   */
  public GetCSVDataForNonHybrid()
  {
	  
  }

  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    String fileName = null;

    try
    {
        log.entry("GetCSVDataForNonHybrid","process","start");
        BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);
	    
     	HttpSession session = a_oRequest.getSession();
		String _strUserId = (String)session.getAttribute("username");
		
		String uploadFileName = (String) session.getAttribute("fileName");
		log.debug("GetCSVDataForNonHybrid.process() :: _strUserId " + _strUserId);
		log.debug("GetCSVDataForNonHybrid.process() :: uploadFileName " + uploadFileName);
		session.removeAttribute("fileName");
		fileName = remoteBPSL.getCSVDataForNH(_strUserId,uploadFileName);
        log.debug("GetCSVDataForNonHybrid--file Name is: "+ fileName);
			
        setResult(fileName);
        log.debug("GetCSVDataForNonHybrid--result is set");
    }
    catch(RemoteException rex)
    {
        log.debug("RemoteException in Action :"+rex);
      throw new EElixirException(rex, "BP1005");
    }
  }
}