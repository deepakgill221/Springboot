/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch Process
*  FILENAME			: UploadSearch.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 5/6/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*1.1         05-01-2011    Shrikrishna     Rel. Q2 (Feb 2011) (Location wise restriction of instrument collection entryv1.4.DOC)
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Get UploadSearch is the Action Class for Getting a details needed for uploading the data
 * Copyright (c) 2002 Mastek Ltd
 * Date       04/06/2003
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.batchprocess.util.BPConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Base64;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.XProperties;


public class UploadSearch extends BPAction
{
  private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * Constructor of the UploadSearch class
   */
  public UploadSearch()
  {
  }

  /**
   * Uses the unique id of JobView and gets the detail for that JobView.
   * @param a_oRequest HttpServletRequest object.exit
   * 
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    DataResult oDataResult = null;
	String strAgentMovementType = null;
	String strServiceRequestType = null;
	short nAgentMovementType = 1;
    //added by suma for service request upload
	short nServiceRequestType= 1;

    try
    {
        log.entry("UploadSearch","process","start");
        BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);
		
		log.debug("strActionID = " + a_oRequest.getParameter("actionevent"));
		String strActionId = a_oRequest.getParameter("actionevent");
		//VA_PT changes by Manisha on 27-Oct-14-START
		log.debug("Before ---- "+strActionId);
		if(strActionId != null)
		{
			byte[] arr = Base64.decode(strActionId);
		  	strActionId = new String(arr, 0, arr.length);
		}
		log.debug("After ---- "+strActionId);
		// VA_PT changes by Manisha on 27-Oct-14-END
		XProperties oXProperties = XProperties.getPropertyUtil(Constants.SETUP_FILE);
		String strBatchPrcUrl = oXProperties.getProperty("upload.dir.in");
		//Added by Srikanth CTS for Bulk Agent Movement Upload
		if(strActionId.trim().equals("BulkAgentMovementUpload"))
		{
			strAgentMovementType= a_oRequest.getParameter("strBulkMovementOption");
			log.debug("strAgentMovementType-->"+strAgentMovementType);
			if(strAgentMovementType != null && !strAgentMovementType.equals(""))
			{
			nAgentMovementType = new Integer(strAgentMovementType).shortValue();
			}
								
		}
		//Ended by Srikanth CTS

	  // -START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0
		if(strActionId.trim().equals("ServiceRequestUpload"))
		{
			strServiceRequestType= a_oRequest.getParameter("strServiceRequestOption");
			log.debug("strServiceRequestType-->"+strServiceRequestType);
			if(strServiceRequestType != null && !strServiceRequestType.equals(""))
			{
				nServiceRequestType = new Integer(strServiceRequestType).shortValue();
			}
								
		}
		// -ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0
		
		short nIsMapped = 0;
		long lBatchPrcSeq = 0;
		String strTableName  = "";
		String strTableDescription ="";
		String strMainProc ="";
		
		

		if(strActionId.trim().equals("AccountMasterUpload"))
		{
			lBatchPrcSeq = 8;
			strTableName = "com_acct_m_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_ACCT_M_UPLD" ;
			strTableDescription = "Account Master Upload";
		}
		else if(strActionId.trim().equals("BankStatementUpload"))
		{
			lBatchPrcSeq = 2;
			strTableName = "mms_bank_stmt_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_BNK_STMT_UPLD" ;
			strTableDescription = "Bank Statment Upload";
		}
		else if(strActionId.trim().equals("InstrumentUpload"))
		{
			lBatchPrcSeq = 3;
			strTableName = "mms_instr_temp";
			nIsMapped = 1;
			strMainProc = "Mm_Sp_Instr_Upld" ;
			strTableDescription = "Instrument Upload  (i.e. CASH / CHEQUE / FOREX / CARDS / OTHERS )";
		}
		else if(strActionId.trim().equals("ECSUpload"))
		{
			lBatchPrcSeq = 4;
			strTableName = "mms_instr_temp";
			nIsMapped = 0;	
			strMainProc = "MM_SP_ECS_STMT_UPLD" ;
			strTableDescription = "Electronic Clearance Statement Upload";
		}
		else if(strActionId.trim().equals("CCDCUpload"))
		{
			lBatchPrcSeq = 5;
			strTableName = "mms_instr_temp";
			nIsMapped = 0;
			strMainProc = "mm_sp_CrDrCardSI_stmt_upld" ;
			strTableDescription = "Credit / Debit Card Upload";
		}
		else if(strActionId.trim().equals("JVUploadOthers"))
		{
			lBatchPrcSeq = 6;
			strTableName = "com_vou_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_JV_OTHER_UPLD" ;
			strTableDescription = "Journal Voucher Upload (Others)";
		}
		else if(strActionId.trim().equals("JVUploadPolicy"))
		{
			lBatchPrcSeq = 7;
			strTableName = "com_vou_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_JV_POLICY_UPLD" ;
			strTableDescription = "Journal Voucher Upload (Policy)";
		}
		else if(strActionId.trim().equals("FutureDrCrUpload"))
		{
			lBatchPrcSeq = 9;
			strTableName = "mms_bank_book_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_FUT_DEBIT_CREDIT_UPLD" ;
			// Added by Manisha for Rel 16.0.5 FIN849 Ready For Deposition on 13-May-2015 - START
			//strTableDescription = "Future Credits and Debits";
			strTableDescription = "Future Credits";
			// Added by Manisha for Rel 16.0.5 FIN849 Ready For Deposition on 13-May-2015 - END
		}
		else if(strActionId.trim().equals("StarTekPolUpload"))
		{
			lBatchPrcSeq = 10;
			strTableName = "com_startek_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_STARTEK_UPLD" ;
			strTableDescription = "Startech Policy Details Upload";	
		}
		else if(strActionId.trim().equals("SunGLChqUpload"))
		{
			lBatchPrcSeq = 11;
			strTableName = "com_vou_instr_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_SUNGL_CHQ_UPLD" ;
			strTableDescription = "Cheque Details Upload from SUN";
		}
		else if(strActionId.trim().equals("CommissionRulesUpload"))
		{
			lBatchPrcSeq = 12;
			strTableName = "chm_comm_rule_temp";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Comm_Upld_Main";
			strTableDescription = "Commission Rules Upload";
		}
		else if(strActionId.trim().equals("EmailIdsUpload"))
		{
			lBatchPrcSeq = 13;
			strTableName = "com_client_email_temp";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Email_Upld_Main";	
			strTableDescription = "Agent Email Ids Upload";
		}
		else if(strActionId.trim().equals("BulkReassignmentUpload"))
		{
			lBatchPrcSeq = 14;
			strTableName = "chm_pol_trf_temp";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Poltrf_Upld_Main";
			strTableDescription = "Bulk Reassignment Upload";
		}
		else if(strActionId.trim().equals("BankDetailsUpload"))
		{
			lBatchPrcSeq =15;
			strTableName = "chm_agent_payment_temp";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Bank_Upld_Main";
			strTableDescription = "Agent Bank Details Upload";
		
			
		}
		else if(strActionId.trim().equals("CommisionMapRulesUpload"))
		{
			lBatchPrcSeq = 16;
			strTableName = "chm_contract_map_temp";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Contract_Map_Upld_Main";
			
			strTableDescription = "Commission Map Upload";
			
		}		
		//<!-- ANUP_Everest Distritbution FS_Phase_II_REL9.0 Starts -->
		else if(strActionId.trim().equals("PlanSetupUpload"))
		{
			lBatchPrcSeq = 18;
			strTableName = "chm_ib_tgt_param_temp";
			nIsMapped = 0;
			strMainProc = "Cm_SP_Bonus_Param_Upld";
			
			strTableDescription = "Plan Setup Upload";
			
		}
		//<!-- ANUP_Everest Distritbution FS_Phase_II_REL9.0 Ends -->
		// ALEX_FSD_Pending_Agents_Reject_Upload Starts
		else if(strActionId.trim().equals("PendingAgentsReject"))
		{
		
			lBatchPrcSeq = 37;
			strTableName = "CHM_REJECT_AGENTS_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_REJECT_AGENTS_UPLD_MAIN";			
			strTableDescription = "Pending Agent's Reject";
			
		}
		// ALEX_FSD_Pending_Agents_Reject_Upload End
		/* Commented by Srikanth CTS for Bulk Agent Movement Upload
		//<!-- ANUP_AGN17_REL9.0 Starts-->
		else if(strActionId.trim().equals("BulkTerminationAgentUpload"))
		{
			lBatchPrcSeq = 34;
			strTableName = "CHM_AGENT_TERM_BULK_TEMP1";
			nIsMapped = 0;
			strMainProc = "Cm_SP_Agt_Term_Bulk_Upld_Main";
			
			strTableDescription = "Bulk Termination of Agent Upload";
			
		}
		//<!-- //ANUP_AGN17_REL9.0 Ends-->
		//<!-- //ANUP_AGN74_REL9.0 Starts -->*/
		
		//Changed by Srikanth CTS for Bulk Agent Movement Upload
		else if(strActionId.trim().equals("BulkAgentMovementUpload"))
		{
			if(nAgentMovementType == BPConstants.BULK_UPLD_MOVEMENT_PROMOTION)
			{
			lBatchPrcSeq = 33;
			strTableName = "Chm_Agt_Promo_Bulk_Temp";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Agt_Promo_Bulk_Upld_Main";
			}else 
			if(nAgentMovementType == BPConstants.BULK_UPLD_MOVEMENT_DEMOTION)
			{
			lBatchPrcSeq = 34;
			strTableName = "Chm_Agt_Demot_Bulk_Temp";
			nIsMapped = 0;
			strMainProc = "Cm_SP_Agt_Demot_Bulk_Upld_Main";
			}else
			if(nAgentMovementType == BPConstants.BULK_UPLD_MOVEMENT_TRANSFER)
			{
			lBatchPrcSeq = 35;
			strTableName = "Chm_Agt_Trans_Bulk_Temp";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Agt_Trans_Bulk_Upld_Main";
			}else
			if(nAgentMovementType == BPConstants.BULK_UPLD_MOVEMENT_REASSIGNMENT)
			{
			lBatchPrcSeq = 20;
			strTableName = "Chm_Agt_Reasign_Bulk_Temp";
			nIsMapped = 0;
			strMainProc = "Cm_SP_Agt_Reasi_Bulk_Upld_Main";
			}else
			if(nAgentMovementType == BPConstants.BULK_UPLD_MOVEMENT_TERMINATION)
			{
			lBatchPrcSeq = 19;
			strTableName = "Chm_Agent_Term_Bulk_Temp";
			nIsMapped = 0;
			strMainProc = "Cm_SP_Agt_Term_Bulk_Upld_Main";
			}else
			// Added by Manisha on 4-May-2016 for MACH17.0 AGN902 - START
			if(nAgentMovementType == BPConstants.BULK_UPLD_MOVEMENT_SUSPENSION)
			{
			lBatchPrcSeq = 54;
			strTableName = "Chm_Agent_Susp_Bulk_Temp";
			nIsMapped = 0;
			strMainProc = "Cm_SP_Agt_Susp_Bulk_Upld_Main";
			}else
			if(nAgentMovementType == BPConstants.BULK_UPLD_MOVEMENT_WITHDRAW)
			{
			lBatchPrcSeq = 55;
			strTableName = "Chm_Agt_Withdr_Bulk_Temp";
			nIsMapped = 0;
			strMainProc = "Cm_SP_Agt_Withdr_Bulk_Up_Main";
			}
			// Added by Manisha on 4-May-2016 for MACH17.0 AGN902 - END
			
			log.debug("testing7");
			strTableDescription = "Bulk Agent Movement Upload";
					
		}
		//End By Srikanth CTS for Bulk Agent Movement Upload
		//<!-- //ANUP_AGN74_REL9.0 Ends -->

		//-START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0
		else if(strActionId.trim().equals("ServiceRequestUpload"))
		{
			if(nServiceRequestType == BPConstants.SERVICE_REQUEST_UPLD_CONTACT)
			{
			lBatchPrcSeq = 44;
			strTableName = "COM_CLIENT_CONT_UPLD_TEMP";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Cont_Upld_Main";
			}else 
			if(nServiceRequestType == BPConstants.SERVICE_REQUEST_UPLD_PAN)
			{
			lBatchPrcSeq = 42;
			strTableName = "Chm_Pan_upld_temp";
			nIsMapped = 0;
			strMainProc = "CM_Sp_Pan_Upld_Main";
			}else
			if(nServiceRequestType == BPConstants.SERVICE_REQUEST_UPLD_ADDRESS)
			{
			lBatchPrcSeq = 43;
			strTableName = "Com_Client_Addr_Upld_Temp";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Address_Upld_Main";
			}
			log.debug("testing8 by SERVICE_REQUEST_UPLD");
			strTableDescription = "Service request Upload";
					
		}
	   //ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0
		 
		//<!-- //Anup_Everest_Upload_Actuarial_Persistancy_Starts -->
		else if(strActionId.trim().equals("ActurialPersistancyUpload"))
		{
			lBatchPrcSeq = 21;
			strTableName = "CHM_PERST_SUM_USRDEF_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_PERST_USERDEF_UPLD_MAIN";
			
			strTableDescription = "Acturial Persistancy Upload";
			
		}
		//<!--//Anup_Everest_Upload_Actuarial_Persistancy_Ends -->
		//<!-- //Anup_Everest_Upload_GO_Association_Starts-->
		else if(strActionId.trim().equals("GOAssociationUpload"))
		{
			lBatchPrcSeq = 22;
			strTableName = "CHM_AGENT_GO_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_GO_UPLD_MAIN";
			
			strTableDescription = "GO Association Upload";
			
		}
		//<!-- //Anup_Everest_Upload_GO_Association_Ends -->
		//<!--Anup_Upload_Commision_Dispatch_Details_Starts-->
		else if(strActionId.trim().equals("CommisionDispatchDetailsUpload"))
		{
			lBatchPrcSeq = 23;
			strTableName = "CHM_COMM_DISPATCH_DTL_TEMP";
			nIsMapped = 0;
			strMainProc = "cm_sp_comm_dispatch_upld_main";
			
			strTableDescription = "Commission Dispatch Details Upload";
			
		}
		//<!-- Anup_Upload_Commision_Dispatch_Details_Ends -->
//		<!--Anup_Upload_GO_Override_APR_REL_Starts-->
		else if(strActionId.trim().equals("GOOverrideUpload"))
		{
			lBatchPrcSeq = 24;
			strTableName = "CHM_IB_GO_OVERRIDE_TEMP";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_IB_GOOVERRIDE_Upld_MAIN";
			
			strTableDescription = "GO Override Details Upload";
			
		}
		//<!--Anup_Upload_GO_Override_APR_REL_Ends-->
//		<!--Anup_Upload_MPP_APR_REL_Starts-->
		else if(strActionId.trim().equals("MPPUpload"))
		{
			lBatchPrcSeq = 25;
			strTableName = "CHM_GO_GLP_SCORE_TEMP";
			nIsMapped = 0;
			strMainProc = "Cm_Sp_Go_Glp_Score_Upld_Main";
			
			strTableDescription = "Gold and GLP Upload";
			
		}
		//<!--Anup_Upload_MPP_APR_REL_Ends-->
		//<!--Anup_Upload_Bancassurance_Starts-->
		else if(strActionId.trim().equals("BancassuranceUpload"))
		{
			lBatchPrcSeq = 26;
			strTableName = "CHM_AGENT_AGENCY_TEMP";
			nIsMapped = 0;
			strMainProc = "cm_sp_agency_upld_main";
			
			strTableDescription = "Bancassurance Incentive Upload";
			
		}
		//<!--Anup_Upload_Bancassurance_Ends-->
		// FIN_71-74_Success or Bounce statements upload facility_APR_REL_Anup_Starts
		else if(strActionId.trim().equals("CreditCardStmtUpload"))
		{
			//Anantha_SuccessBounce_Upload_FS chmged proc name
			
			lBatchPrcSeq = 27;
			strTableName = "mms_credit_card_stmt_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_CC_BANK_STMT_UPLD_INTM";
			
			strTableDescription = "Credit Card Statement Upload";
			
		}
		else if(strActionId.trim().equals("ECSStmtUpload"))
		{
			//Anantha_SuccessBounce_Upload_FS chmged proc name
			
			lBatchPrcSeq = 28;
			strTableName = "mms_ecs_stmt_temp";
			nIsMapped = 0;
			strMainProc = "MM_SP_ECS_BANK_STMT_UPLD_INTM";
			
			strTableDescription = "ECS Statement Upload";
			
		}
		// FIN_71-74_Success or Bounce statements upload facility_APR_REL_Anup_Ends
		// <!--Adjusted_paid_case_setup_Anup_Starts-->
		else if(strActionId.trim().equals("AdjPaidCaseSetupUpload"))
		{
			lBatchPrcSeq = 29;
			strTableName = "CHM_SEGMENT_PRD_ADJ_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_SEGMENT_ADJ_UPLD_MAIN";
			
			strTableDescription = "Adjusted Paid Case Upload";
			
		}
		//<!--Adjusted_paid_case_setup_Anup_Ends-->
    	//<!--AGN98_Anup_Uploads_Bonus/Product_Persistency_Designation_JUL_REL_Starts-->
		else if(strActionId.trim().equals("DesignationUpload"))
		{
			lBatchPrcSeq = 30;
			strTableName = "CHM_BONUS_DESGN_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_BONUS_DESGN_UPLD_MAIN";
			
			strTableDescription = "Designation Upload";
			
		}
		
		else if(strActionId.trim().equals("BonusProductUpload"))
		{
			lBatchPrcSeq = 31;
			strTableName = "CHM_BONUS_PRD_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_BONUS_UPLD_MAIN";
			
			strTableDescription = "Bonus/Product Upload";
			
		}
		else if(strActionId.trim().equals("PersistencyUpload"))
		{
			lBatchPrcSeq = 32;
			strTableName = "CHM_PERST_PRD_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_PERST_PRD_UPLD_MAIN";
			
			strTableDescription = "Persistency Upload";
			
		}
		
    	//<!--AGN98_Anup_Uploads_Bonus/Product_Persistency_Designation_JUL_REL_Ends-->
		//Added by Srikanth CTS for MPS
		else if(strActionId.trim().equals("AgentMPSUpload"))
		{
			lBatchPrcSeq = 36;
			strTableName = "CHM_AGT_MPS_TERM_FLG_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_MPS_TERM_FLAG_UPLD_MAIN";
			strTableDescription = "Agent MPS Upload";
		}
		//End by Srikanth CTS
		// <Rel. Q2 (Feb 2011) - Start : Added by  Shrikrishna on 05-01-2011 FOR CR:Location wise restriction of instrument collection entryv1.4.DOC 
		else if(strActionId.trim().equals("LocationWiseRestritionUpload"))
		{
			lBatchPrcSeq = 38;
			strTableName = "MMS_COLLBLOCK_DTL_TEMP";
			nIsMapped = 0;
			strMainProc = "MM_SP_LOC_COLLBLOCK_UPLD";
			strTableDescription = "Location wise restriction Upload";
		}
		// <Rel. Q2 (Feb 2011) - End : Added by  Shrikrishna on 05-01-2011 FOR CR:Location wise restriction of instrument collection entryv1.4.DOC 
		//Parent_Branch_Code_Change_AGN430_Rohit Starts
		else if(strActionId.trim().equals("BulkAgencyMovementUpload"))
		{
			log.debug("\n"+"ActionID"+strActionId+"\n");
			/*Obtained from select * from com_batch_prc_m  Column: LBATCHPROCSEQ*/
					lBatchPrcSeq = 39;
					strTableName = "CHM_BRCH_TRANS_BULK_TEMP";
					nIsMapped = 0;
					strMainProc = "CM_SP_BRCH_TRAN_BULK_UPLD_MAIN";
					
					strTableDescription = "Bulk Agency Branch Movement Upload";
					
				}
		//Parent_Branch_Code_Change_AGN430_Rohit Ends
		/**
		 * @author himanshu10894
		 * Enter the the lBatchPrcSeq in com_batch_prc_m table for primary key it is manadtory
		 * to fetch the column name from strTableName String
		 */
		
		//<!--<CODE TAG:Added By Himanshu _Bulk Upload Prohibit JV Posting V1.0_Jan2012_START> -->
		else if(strActionId.trim().equals("BulkUploadProhibiJVPosting"))
		{
			log.debug("\n"+"ActionID"+strActionId+"\n");
			/*Obtained from select * from com_batch_prc_m  Column: LBATCHPROCSEQ*/
					lBatchPrcSeq = 40;
					strTableName = "CHM_JV_POSTING_BULK_TEMP";
					nIsMapped = 0;
					strMainProc = "CM_SP_JV_POST_BULK_UPLD_MAIN";
					
					strTableDescription = "Bulk Upload Prohibit JV Posting";
					
				}
		//<!--<CODE TAG:Added By Himanshu _Bulk Upload Prohibit JV Posting V1.0_Jan2012_START> -->
	
// Start FSD_551 Automation of manual upload Sagar 29-oct-2012 
		else if(strActionId.trim().equals("ManMatchUpload"))
		{
			lBatchPrcSeq = 41;
			strTableName = "CHM_MAN_MATCH_UPLD_TEMP";
			nIsMapped = 0;	
			strMainProc = "CM_SP_MANUAL_MATCH_UPLD_MAIN" ;
			strTableDescription = "Manual Match Upload Details";
		}

// End FSD_551 Automation of manual upload Sagar 29-oct-2012
		// Added by Manisha on 7-Aug-2013 for MACH-17 - START
		else if(strActionId.trim().equals("SuspensionFromNBUpload"))
		{
			lBatchPrcSeq = 48;
			strTableName = "CHM_SUPN_RSN_UPLD_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_SUPN_RSN_UPLD_MAIN";
			strTableDescription = "Suspension From New Business Upload";
		}
		// Added by Manisha on 7-Aug-2013 for MACH-17 - END
		
		// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 - Starts
		else if(strActionId.trim().equals("CollectionAchievementUpload"))
		{
			lBatchPrcSeq = 49;
			strTableName = "CHM_COLLECTION_ACHV_UPLD_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_COLN_ACHV_UPLD_MAIN";
			strTableDescription = "MFYP_FRYP Collection Achievement Upload";
		}
		// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 - Ends
		
		// Added by Varun on 09-Jun-2014 for Rel 15.1 FSD_POS989 - Starts
		else if(strActionId.trim().equals("InstrumentUploadForNonHybrid"))
		{
			lBatchPrcSeq = 50;
			strTableName = "MMS_INSTR_NONHYBRD_TEMP";
			nIsMapped = 0;
			strMainProc = "MM_SP_INSTR_NONHYBRID_MAIN";
			strTableDescription = "Instrument Upload for Non Hybrid Policies";
		}
		else if(strActionId.trim().equals("ECSUploadForNonHybrid"))
		{
			lBatchPrcSeq = 51;
			strTableName = "MMS_INSTR_NONHYBRD_TEMP";
			nIsMapped = 0;
			strMainProc = "MM_SP_ECS_NONHYBRID_MAIN";
			strTableDescription = "ECS Upload for Non Hybrid Policies";
		}
		else if(strActionId.trim().equals("CCSUploadForNonHybrid"))
		{
			lBatchPrcSeq = 52;
			strTableName = "MMS_INSTR_NONHYBRD_TEMP";
			nIsMapped = 0;
			strMainProc = "MM_SP_CCS_NONHYBRID_MAIN";
			strTableDescription = "Credit Card Stmt Upload for Non Hybrid Policies";
		}
		// Added by Varun on 09-Jun-2014 for Rel 15.1 FSD_POS989 - Ends
		
		// Added by Manisha on 5-Nov-2015 for Rel 16.1 FIN896 - START
		else if(strActionId.trim().equals("BrsCommentsUploads"))
		{
			lBatchPrcSeq = 53;
			strTableName = "MMS_COMMENTS_UPLOAD_TEMP";
			nIsMapped = 0;
			strMainProc = "MM_COMM_UPLOAD";
			strTableDescription = "Comments Upload";
		}
		// Added by Manisha on 5-Nov-2015 for Rel 16.1 FIN896 - END
		// AGN929: AML & ULIP upload:: Added by Aradhana Pandey: 4_Jul_2017::**START**
		else if(strActionId.trim().equals("AmlUlipTrainingUploads"))
		{
			lBatchPrcSeq = 56;
			strTableName = "CHM_AML_ULIP_TRNG_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_TRAINING_UPLD_MAIN";
			strTableDescription = "Bulk AML and ULIP Training upload";
		}
		// AGN929: AML & ULIP upload:: Added by Aradhana Pandey: 4_Jul_2017::**ENDS**
		// AGN946: Added by Aradhana Pandey: 10_Nov_2017::**START**
		else if(strActionId.trim().equals("AgentRegistrationUpload"))
		{
			lBatchPrcSeq = 57;
			strTableName = "CHM_AGENT_UPLOAD_TEMP";
			nIsMapped = 0;
			strMainProc = "CM_SP_AGENT_UPLD_MAIN";
			strTableDescription = "Agent Registration Upload";
		}
		// AGN946: Added by Aradhana Pandey: 10_Nov_2017::**ENDS**
		else
		{
			log.debug("No Action ID found throwing exception");
			throw new EElixirException("BP1005");				
		}

       log.debug("Primary Key Value is :"+lBatchPrcSeq);
       log.debug("strTableName Value is :"+strTableName);
       log.debug("k Value is :"+strBatchPrcUrl);
       log.debug("nIsMapped Value is :"+nIsMapped);
      
       oDataResult = remoteBPSL.searchTableColDefn(lBatchPrcSeq,strTableName, nIsMapped);
       log.debug("UploadSearch--result accessed");

       // set the other parameters in the data result
       oDataResult.setStrTableName(strTableName);
       oDataResult.setStrBatchPrcUrl(strBatchPrcUrl);
       oDataResult.setNIsMapped(new Short(nIsMapped));
	   //Added by Srikanth CTS for Bulk Agent Movement Upload
	   oDataResult.setMovementType(new Short(nAgentMovementType));
	   oDataResult.setActionID(strActionId);
	   //End by Srikanth CTS
	   //-START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0
	   oDataResult.setServiceRequest(new Short(nServiceRequestType));
	   //ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0

	   oDataResult.setMainProcName(strMainProc);
	   a_oRequest.setAttribute("strTableDescription",strTableDescription);
       setResult(oDataResult);
       log.debug("UploadSearch--result is set");
    }
    catch(RemoteException rex)
    {
      log.debug("RemoteException in Action :"+rex);
      throw new EElixirException(rex, "BP1005");
    }
  }
}

