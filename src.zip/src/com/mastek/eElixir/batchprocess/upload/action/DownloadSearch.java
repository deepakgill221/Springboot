/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch Process
*  FILENAME			: DownloadSearch.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 5/6/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Get DownloadSearch is the Action Class for Getting a details needed for uploading the data
 * Copyright (c) 2002 Mastek Ltd
 * Date       04/06/2003
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class DownloadSearch extends BPAction
{
  private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * Constructor of the DownloadSearch class
   */
  public DownloadSearch()
  {
  }

  /**
   * Uses the unique id of JobView and gets the detail for that JobView.
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    DataResult oDataResult = null;

    try
    {
        log.entry("DownloadSearch","process","start");
        BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);
        long lBatchPrcSeq = Long.parseLong(a_oRequest.getParameter("lBatchPrcSeq"));
        String strTableName  = a_oRequest.getParameter("strTableName");
        String strBatchPrcUrl = a_oRequest.getParameter("strBatchPrcUrl");
        short nIsMapped = Short.parseShort(a_oRequest.getParameter("isMapped"));

        log.debug("Primary Key Value is :"+lBatchPrcSeq);
        log.debug("strTableName Value is :"+strTableName);
        log.debug("strBatchPrcUrl Value is :"+strBatchPrcUrl);
        log.debug("nIsMapped Value is :"+nIsMapped);

       oDataResult = remoteBPSL.searchTableColDefn(lBatchPrcSeq,strTableName, nIsMapped);
       log.debug("DownloadSearch--result accessed");

       // set the other parameters in the data result
       oDataResult.setStrTableName(strTableName);
       oDataResult.setStrBatchPrcUrl(strBatchPrcUrl);
       oDataResult.setNIsMapped(new Short(nIsMapped));

       setResult(oDataResult);
       log.debug("DownloadSearch--result is set");
    }
    catch(RemoteException rex)
    {
        log.debug("RemoteException in Action :"+rex);
      throw new EElixirException(rex, "BP1005");
    }
  }
}