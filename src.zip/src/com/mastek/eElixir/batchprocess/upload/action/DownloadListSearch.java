/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch Process
*  FILENAME			: DownloadSearch.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 05/06/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get DownloadSearch is the Action Class for Getting a list of
 * tables where in the data can be uploaded,depending upon the search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/06/2003
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.tabledefn.util.TableInfoResult;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class DownloadListSearch extends BPAction
{
  private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

  /**
   * Constructor of the DownloadSearch class
   */
  public DownloadListSearch()
  {
  }

  /**
   * This method uses the search data and to populate Benefit
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    TableInfoResult oTableInfoResult = null;
    String result =null;
    try
    {
        log.entry("DownloadSearch","process","Start");

        BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);

        oTableInfoResult = new TableInfoResult();

        String strTableName          = a_oRequest.getParameter("strTableName");
        log.debug("strTableName ::: "+strTableName);
        String strTableDesc        = a_oRequest.getParameter("strTableDesc");
        log.debug("strTableDesc--"+strTableDesc);

        String strIsUploadPrc = a_oRequest.getParameter("nIsUploadPrc");
        log.debug("IsUploadPrc ---"+strIsUploadPrc);

        oTableInfoResult.setIsUploadPrc(new Short(strIsUploadPrc));

        if(strTableName != null && (!strTableName.equals("")))
        {
            oTableInfoResult.setTableName(strTableName);
        }
        else
        {
            oTableInfoResult.setTableName(null);
        }

        if(strTableDesc != null && (!strTableDesc.equals("")))
        {
            oTableInfoResult.setTableDesc(strTableDesc);
        }
        else
        {
            oTableInfoResult.setTableDesc(null);
        }

        log.debug("Before calling the search method");
        result = remoteBPSL.searchUploadTables(oTableInfoResult);
        /* Modified by Pravin Boga - retain search criteria */
        oTableInfoResult.setXMLString(result);
        log.debug("DownloadSearch--result accessed");
        setResult(oTableInfoResult);
        log.debug("DownloadSearch--result is set");
       // setShowSuccess(a_oRequest,Constants.NO_FLAG);

    }
    catch(RemoteException rex)
    {
        //BP1006=The system was unable to search uploads based on the search criteria.
        log.fatal("DownloadSearch","process",rex);
        throw new EElixirException("BP1006");
    }
    catch(EElixirException eex)
    {
        a_oRequest.setAttribute("ResultObject",result);
        log.fatal("DownloadSearch","process",eex);
        throw eex;
    }
  }
}