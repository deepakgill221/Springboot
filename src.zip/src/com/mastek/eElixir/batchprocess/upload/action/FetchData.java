/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME		: BATCH PROCESS
 *  FILENAME		: FetchData.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: June9, 2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *  1.1		18/8/2003	Amit NIgam		Added setParameters for iFormat,iDelimiter,and iColumnSequence
 *  
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/



/**
 * FetchData is the Utility Class for fetching parameter for Upload and Preview
 * Copyright (c) 2002 Mastek Ltd
 * Date       09/06/2002
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.upload.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.tabledefn.util.TableDefResult;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.upload.util.FileDataMap;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class FetchData
{
    private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

    /**
     * Constructor of the FetchData class
     */
    public FetchData()
    {
    }

    /**
     * This Fetches all the paramater for benefit except primary key
     * @param a_oRequest HttpServletRequest object.
     * @return BenefitResult
     * @throws EElixirException
     */
    public DataResult fetchUploadData(HttpServletRequest a_oRequest)
    {
        DataResult oDataResult = new DataResult() ;

        log.entry("FetchData","fetchUploadData","Start----");
        String strTableName = a_oRequest.getParameter("strTableName");
        String strBatchPrcURL = a_oRequest.getParameter("strBatchPrcURL");
        String nIsMapped = a_oRequest.getParameter("nIsMapped");
        String strDataFile = a_oRequest.getParameter("hDataFile");
        String lBatchPrcSeq = a_oRequest.getParameter("lBatchPrcSeq");
        String strMainProc = a_oRequest.getParameter("strMainProc");
        String iFormat = a_oRequest.getParameter("iFormat");
        String iDelimiter = a_oRequest.getParameter("strDelimiter");
		String strMessDelOption = a_oRequest.getParameter("strMessDelOption").trim();
        
        log.debug("strTableName --"+strTableName);
        log.debug("strBatchPrcURL --"+strBatchPrcURL);
        log.debug("nIsMapped --"+nIsMapped);
        log.debug("strDataFile --"+strDataFile);
		log.debug("iFormat1 --"+iFormat);
		log.debug("iDelimiter --"+iDelimiter);
		log.debug("strMessDelOption---"+strMessDelOption);
		
		
        oDataResult.setStrTableName(strTableName);
        oDataResult.setStrBatchPrcUrl(strBatchPrcURL);
        oDataResult.setLBatchPrcSeq(new Long(lBatchPrcSeq));
		oDataResult.setFormat(new Integer(iFormat)); 
		oDataResult.setDelimiter(iDelimiter);
		
		
		if(strMessDelOption != null && (!strMessDelOption.equals("")))
			oDataResult.setMessDelOption(new Short(strMessDelOption));
		else
			oDataResult.setMessDelOption(null);
						
		
		oDataResult.setMainProcName(strMainProc);
		
		if(nIsMapped != null && (!nIsMapped.equals("")))
            oDataResult.setNIsMapped(new Short(nIsMapped));
        else
            oDataResult.setNIsMapped(null);

        oDataResult.setStrDataFile(strDataFile);

        ArrayList alFileDataMap = getFileDataMap(a_oRequest);
        ArrayList alTableDefResult = getTableDef(a_oRequest);

        oDataResult.setAlFileDataMap(alFileDataMap);
        oDataResult.setAlTableDefResult(alTableDefResult);

        return oDataResult;
    }

    private ArrayList getFileDataMap(HttpServletRequest a_oRequest)
    {
        ArrayList alFileDatMap = new ArrayList();

        log.entry("FetchData","getFileDataMap","Start");


        int index = Integer.parseInt(a_oRequest.getParameter("NoOfRows"));

        for(int count=0; count<index; count++)
        {
            FileDataMap oFileDataMap = new FileDataMap();

            oFileDataMap.setStrColName(a_oRequest.getParameter("strColumnName"+count));

            String strDataFrom = a_oRequest.getParameter("nDataFrom"+count);

            if(strDataFrom != null && (!strDataFrom.equals("")))
                oFileDataMap.setLFromDataValue(new Long(strDataFrom));
            else
                oFileDataMap.setLFromDataValue(null);

            String strDataTo = a_oRequest.getParameter("nDataTo"+count);

            if(strDataTo != null && (!strDataTo.equals("")))
                oFileDataMap.setLToDataValue(new Long(strDataTo));
            else
                oFileDataMap.setLToDataValue(null);

 			/*************************Added by nigam (starts)********************************/
			String strColumnSequence = a_oRequest.getParameter("iColumnSeq"+count);
			
			if(strColumnSequence != null && (!strColumnSequence.equals("")))
			{
				oFileDataMap.setColumnSequence(new Integer(strColumnSequence));
			}
			else
				oFileDataMap.setColumnSequence(null); 	
			/*************************Added by nigam (ends)********************************/
 			
 			
            alFileDatMap.add(oFileDataMap);
        }
        log.exit("FetchData","getFileDataMap","End--  alFileDatMap.size() ---"+alFileDatMap.size());
        return alFileDatMap;
    }// end of getFileDataMap

    private ArrayList getTableDef(HttpServletRequest a_oRequest)
    {
        ArrayList alTableDefResult = new ArrayList();

        log.entry("FetchData","getTableDef","Start");

        int index = Integer.parseInt(a_oRequest.getParameter("NoOfRows"));

        for(int count=0; count<index; count++)
        {
            TableDefResult oTableDefResult = new TableDefResult();

            oTableDefResult.setColumnName(a_oRequest.getParameter("strColumnName"+count));

            oTableDefResult.setColumnWidth(a_oRequest.getParameter("nColumnWidth"+count));
            oTableDefResult.setDataType(a_oRequest.getParameter("strDataType"+count));

            alTableDefResult.add(oTableDefResult);
        }
        log.exit("FetchData","getTableDef","End--alTableDefResult.size()--"+alTableDefResult.size());
        return alTableDefResult;
    }// end of getTableDef
    
}