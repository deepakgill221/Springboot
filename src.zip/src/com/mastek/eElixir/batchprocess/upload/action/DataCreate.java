/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch Process
*  FILENAME			: DataCreate.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 9/6/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * This action class initiates the process to upload the data to the specified table
 * and returns back to the list search page with the msg that the process has
 * started.
 * Copyright (c) 2002 Mastek Ltd
 * Date       09/06/2003
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class DataCreate extends BPAction
{
  private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * Constructor of the DataCreate class
   */
  public DataCreate()
  {
  }

  /**
   * Uses the unique id of JobView and gets the detail for that JobView.
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    DataResult oDataResult = null;

    try
    {
        log.entry("DataCreate","process","start");
        BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);
	
        FetchData fd = new FetchData();
        oDataResult = fd.fetchUploadData(a_oRequest);
        
        
        String strMainProc = oDataResult.getMainProcName();
        
		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String)session.getAttribute("username");
		String strLocationCd = (String)session.getAttribute("locationCode");
		oDataResult.setLocationCd(strLocationCd);
		log.debug("   IN ACTION CLASS -> DataCreate :: strLocationCd " + strLocationCd);

        oDataResult.setStrUserId(_strUserId);
        oDataResult = remoteBPSL.createDataForUpload(oDataResult);
        log.debug("DataCreate--result accessed");

		oDataResult.setMainProcName(strMainProc);
			
        setResult(oDataResult);
        log.debug("DataCreate--result is set");
    }
    catch(RemoteException rex)
    {
        log.debug("RemoteException in Action :"+rex);
      throw new EElixirException(rex, "BP1005");
    }
  }
}