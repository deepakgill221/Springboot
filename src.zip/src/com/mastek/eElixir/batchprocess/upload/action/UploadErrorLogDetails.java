/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: BATCH PROCESS
 *  FILENAME		: UploadErrorLogDetails.java
 *  AUTHOR			: Jayasimha Reddy.B
 *  VERSION			: 1.0
 *  CREATION DATE	: Jan 9, 2006
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2006.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/


package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class UploadErrorLogDetails extends BPAction
{
    private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

    /**
     * Constructor of the DownloadData class
     */
    public UploadErrorLogDetails()
    {
    }

    /**
     * This Fetches all Error Occured while uploadind the file
     * @param a_oRequest HttpServletRequest object.
     * @return setResult
     * @throws EElixirException
     */
    public void process (HttpServletRequest a_oRequest) throws EElixirException
    {
        String strResult ="";
        String strMainProc ="";
        DataResult oDataResult =new DataResult();

        try
        {
            BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);
			strMainProc =a_oRequest.getParameter("strMainProc");
			oDataResult.setMainProcName(strMainProc.toUpperCase());
//			FindBug_Fix_SUNAINA_STARTED 
			strResult  = remoteBPSL.getErrorLogs(oDataResult);
//			FindBug_Fix_SUNAINA_STARTED 

            setResult(strResult );
        }
        catch(RemoteException rex)
        {
            log.debug("RemoteException in Action :"+rex);
            throw new EElixirException(rex, "BP1005");
        }
    }

    

}