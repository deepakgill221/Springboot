package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: eElixir</p>
 * <p>Description:NewUploadSuccessBounce is the Action Class for retrieving the parameters of success bounce</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @codetag: Anup_Success_Bounce
 * @author Anup Kumar
 * @version 1.0
 */

public class NewUploadSuccessBounce extends BPAction
{
	 private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * @Constructor
   */
  public NewUploadSuccessBounce(){
  }

  /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean and get the DataResult Object
   * @param: request - Request object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
	  
	 String result =null;
    DataResult oDataResult = null;   
    	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Starts>
    HttpSession session = a_oRequest.getSession();
    try{
    	BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);
        log.entry("NewUploadSuccessBounce","process","Start");
        if(a_oRequest.getParameter("checkBounceRecords")!=null){
			  log.debug("ClassName:NewUploadSuccessBounce | request.getParameter(\"checkBounceRecords\") not NULL ");
			  int nProcSeq =  Integer.parseInt(a_oRequest.getParameter("nProcSeq"));
			  long ctrlSeqNum = Long.parseLong(a_oRequest.getParameter("ctrlSeqNum"));
			  double dSumNetAmnt = Double.parseDouble(a_oRequest.getParameter("dSumNetAmnt"));
			  String strCCORECSRemarks = a_oRequest.getParameter("strCCORECSRemarks");
			  boolean bResult=remoteBPSL.findMatchingRecordsForSuccessBounce(nProcSeq, ctrlSeqNum, dSumNetAmnt, strCCORECSRemarks);
			  log.debug("Result-->"+bResult);
			  setResult(bResult);
			 
		}
        else if(a_oRequest.getParameter("exitUpload")!=null){
			  log.debug("ClassName:NewUploadSuccessBounce | request.getParameter(\"exitUpload\") not NULL ");
			  int nProcSeq =  Integer.parseInt(a_oRequest.getParameter("nProcSeq"));
			  long ctrlSeqNum = Long.parseLong(a_oRequest.getParameter("ctrlSeqNum"));				
	    	  String _strUserId = (String)session.getAttribute("username");
			  int bResult=remoteBPSL.exitSuccessBounceUploadECSCCS(nProcSeq, ctrlSeqNum, _strUserId);
			  log.debug("Result-->"+bResult);
			  setResult(bResult);
			 
		}else{			    
        oDataResult = new DataResult();
        String flag  = a_oRequest.getParameter("flag");
        log.debug("flag ::: "+flag);        
        if(flag!=null && flag.equals("false")){              
            oDataResult = fetchUploadData(a_oRequest);            
            String strMainProc = oDataResult.getMainProcName();            
    		String _strUserId = (String)session.getAttribute("username");
    		String strLocationCd = (String)session.getAttribute("locationCode");
    		oDataResult.setLocationCd(strLocationCd);
            oDataResult.setStrUserId(_strUserId);
            oDataResult = remoteBPSL.createUploadSuccessBounce(oDataResult);            
    		oDataResult.setMainProcName(strMainProc);    			
            setResult(oDataResult);
            log.debug("inside if -->> DataCreate--result is set");
        }else if(flag!=null && flag.equals("true")){
        	 setResult(oDataResult);        	 
        	 a_oRequest.setAttribute("actiontype",DataConstants.ACTION_CREATE);
        	log.debug("Inside Else if--result is set");
        }
		}

    }
  //<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Ends>   
    catch(RemoteException rex)
    {
        //BP1006=The system was unable to search uploads based on the search criteria.
        log.fatal("NewUploadSuccessBounce","process",rex);
        throw new EElixirException("BP1006");
    }
    catch(EElixirException eex)
    {
        a_oRequest.setAttribute("ResultObject",result);
        log.fatal("NewUploadSuccessBounce","process",eex);
        throw eex;
    }
  }   
  
  /**
   * This Fetches all the paramater for benefit except primary key
   * @param a_oRequest HttpServletRequest object.
   * @return BenefitResult
   * @throws EElixirException
   */
  public DataResult fetchUploadData(HttpServletRequest a_oRequest)
  {
      DataResult oDataResult = new DataResult() ;

      log.entry("FetchData","fetchUploadData","Start----");
      String dSumGrossAmt = a_oRequest.getParameter("dSumGrossAmt");
      String dSumBankCharges = a_oRequest.getParameter("dSumBankCharges");
      String dSumServiceTax = a_oRequest.getParameter("dSumServiceTax");
      String dSumNetAmnt = a_oRequest.getParameter("dSumNetAmnt");
      String strCCORECSRemarks = a_oRequest.getParameter("strCCORECSRemarks");
      String lCCORECSCtrlStmtSeqNbr = a_oRequest.getParameter("lCCORECSCtrlStmtSeqNbr");
      String lBatchPrcSeq = a_oRequest.getParameter("iLBatchPrcSeq");
      String strDataFile = a_oRequest.getParameter("hDataFile");
      String lPrcResultSeq = a_oRequest.getParameter("lPrcResultSeq");  
      String strMainProc = a_oRequest.getParameter("strMainProcedure");
      String nProcSeq = a_oRequest.getParameter("nProcSeq");
    
      
      log.debug("dSumGrossAmt --"+dSumGrossAmt);
      log.debug("dSumBankCharges --"+dSumBankCharges);
      log.debug("dSumServiceTax --"+dSumServiceTax);
      log.debug("dSumNetAmnt --"+dSumNetAmnt);
	  log.debug("strCCORECSRemarks --"+strCCORECSRemarks);
	  log.debug("lCCORECSCtrlStmtSeqNbr --"+lCCORECSCtrlStmtSeqNbr);
	  log.debug("lBatchPrcSeq---"+lBatchPrcSeq);
	  log.debug("strDataFile---"+strDataFile);
	  log.debug("lPrcResultSeq---"+lPrcResultSeq);
	  log.debug("strMainProc---"+strMainProc);		
		
      oDataResult.setSumGrossAmt(Double.valueOf(dSumGrossAmt.trim()));
      oDataResult.setSumBankCharges(Double.valueOf(dSumBankCharges.trim()));
      oDataResult.setSumServiceTax(Double.valueOf(dSumServiceTax.trim()));
      oDataResult.setSumNetAmnt(Double.valueOf(dSumNetAmnt.trim()));
      oDataResult.setCCORECSRemarks(strCCORECSRemarks);
      oDataResult.setCCORECSCtrlStmtSeqNbr(new Long(lCCORECSCtrlStmtSeqNbr));
      oDataResult.setLBatchPrcSeq(new Long(lBatchPrcSeq));
      oDataResult.setStrDataFile(strDataFile);
      oDataResult.setLPrcResultSeq(new Long(lPrcResultSeq));	
      oDataResult.setMainProcName(strMainProc);
      oDataResult.setProcSeqNbr(new Short(nProcSeq));
					
		
	  return oDataResult;
  }


}