/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME		: BATCH PROCESS
 *  FILENAME		: DownloadData.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: June 17, 2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1      20/06/2003    Heena Jain    Modified getDownloadCriteria()
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/



/**
 * DownloadData is the class used for downloading the file from the server
 * Copyright (c) 2002 Mastek Ltd
 * Date       17/06/2002
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.upload.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.batchprocess.upload.util.DownloadCriteria;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class DownloadData extends BPAction
{
    private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

    /**
     * Constructor of the DownloadData class
     */
    public DownloadData()
    {
    }

    /**
     * This Fetches all the paramater for benefit except primary key
     * @param a_oRequest HttpServletRequest object.
     * @return BenefitResult
     * @throws EElixirException
     */
    public void process (HttpServletRequest a_oRequest) throws EElixirException
    {
        DataResult oDataResult = new DataResult() ;

        try
        {
            log.entry("UploadSearch","process","start");
            BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);

            log.entry("DownloadData","process","Start----");
            String strTableName = a_oRequest.getParameter("strTableName");
            String strBatchPrcURL = a_oRequest.getParameter("strBatchPrcURL");
            String lBatchPrcSeq = a_oRequest.getParameter("lBatchPrcSeq");

            log.debug("strTableName --"+strTableName);
            log.debug("strBatchPrcURL --"+strBatchPrcURL);
            log.debug("lBatchPrcSeq -- "+lBatchPrcSeq);

            oDataResult.setStrTableName(strTableName);
            oDataResult.setStrBatchPrcUrl(strBatchPrcURL);
            oDataResult.setLBatchPrcSeq(new Long(lBatchPrcSeq));

            ArrayList alDownloadCriteria = getDownloadCriteria(a_oRequest);

            oDataResult.setAlDownloadCriteria(alDownloadCriteria);

            log.debug("UploadSearch--result accessed");
            oDataResult = remoteBPSL.downloadData(oDataResult);

            setResult(oDataResult);
        }
        catch(RemoteException rex)
        {
            log.debug("RemoteException in Action :"+rex);
            throw new EElixirException(rex, "BP1005");
        }
    }

    private ArrayList getDownloadCriteria(HttpServletRequest a_oRequest)
    {
        ArrayList alDownloadCriteria = new ArrayList();

        log.entry("DownloadData","getDownloadCriteria","Start");

        log.debug("No Of Rows--"+a_oRequest.getParameter("NoOfRows"));

        int index = Integer.parseInt(a_oRequest.getParameter("NoOfRows"));
        log.debug("NoOfRows : "+index);

        for(int count=0; count<index; count++)
        {
            DownloadCriteria oDownloadCriteria = new DownloadCriteria();

           String strIsRequired = a_oRequest.getParameter("nIsRequired"+count);

           /**
            * If the isRequired checkbox is checked then set the columnname and
            * NisRequired in Download Criteria
            */
            if(strIsRequired != null && (!strIsRequired.equals("")))
            {
                oDownloadCriteria.setNIsRequired(new Short("1"));
                oDownloadCriteria.setStrColumnName(a_oRequest.getParameter("strColumnName"+count));
                alDownloadCriteria.add(oDownloadCriteria);
            }
        }
        log.exit("DownloadData","getDownloadCriteria","End--  alFileDatMap.size() ---"+alDownloadCriteria.size());
        return alDownloadCriteria;
    }// end of getDownloadCriteria

}