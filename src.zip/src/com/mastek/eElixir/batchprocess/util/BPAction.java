/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch Process
*  FILENAME			: BPAction.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 03/06/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1       17/6/2003     Heena Jain    Changed the logger stmt.
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.batchprocess.util;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSLHome;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;


public abstract class BPAction extends Action
{
   private static Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * Default Constructor
   *
   */
   public BPAction()
  {

  }

  /**
   * This method does lookup for BatchProcessSl
   * @param strHome String
   * @param cHomeClass Class
   * @return BatchProcessSl
   * @throws RemoteException
   * @throws CreateException
   * @throws EElixirException
   */

  /**
   * Returns the Batch Process SL reference
   * @param the http request object required to get the user logged in
   * @return oBatchProcessSL
   * @throws EElixirException
   */
  protected BatchProcessSL getBatchProcessSL(HttpServletRequest a_oRequest)
          throws EElixirException
  {
      EJBHomeFactory oEJBHomeFactory = null;
      BatchProcessSL oBatchProcessSL = null;
      BatchProcessSLHome oBatchProcessSLHome = null;
      try
      {
          log.entry("BPAction","getBatchProcessSL","void");
          oEJBHomeFactory = EJBHomeFactory.getFactory();
          oBatchProcessSLHome = (BatchProcessSLHome) oEJBHomeFactory.lookUpHome
          (EElixirUtils.getJNDIName(Constants.BATCH_PROCESS,"BatchProcessSLHome"),
          BatchProcessSLHome.class);//,getUserId(a_oRequest));
          oBatchProcessSL = oBatchProcessSLHome.create();
          log.exit("BPAction","getBatchProcessSL","" + oBatchProcessSL);
          return oBatchProcessSL;
      }//end try
      catch(RemoteException rex)
      {
          log.fatal("BPAction","getBatchProcessSL",rex);
          throw new EElixirException(rex,rex.getMessage());
      }
      catch(CreateException cex)
      {
          log.fatal("BPAction","getBatchProcessSL",cex);
          throw new EElixirException(cex,cex.getMessage());
      }
      catch(EElixirException eex)
      {
          log.fatal("BPAction","getBatchProcessSL",eex);
          throw eex;
      }
  }

}// end of class