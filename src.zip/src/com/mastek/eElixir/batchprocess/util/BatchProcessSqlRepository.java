package com.mastek.eElixir.batchprocess.util;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.SqlRepository;
import com.mastek.eElixir.common.util.SqlRepositoryIF;


/**
 * <p>Title: </p>
 * <p>Description:This class is inherited from the SqlRepository for the Batch Process
 *  It loads the all the four sql repository in the constructor</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Navneet
 * @version 1.0
 */

public class BatchProcessSqlRepository extends SqlRepository implements SqlRepositoryIF
{

  /**
   * Constructor loads the document object from the sql repository
   * @throws EElixirException
   */
  private BatchProcessSqlRepository () throws EElixirException
  {
	  //Ananth_DistributedCache_DMLQueryRepositories_Implementation
    //loadDocument("batchprocess");
  }

  /**
    * Returns a instance of the SqlRepositoryIF
    * @return _oBatchProcessSqlRepository SqlRepositoryIF
    * @throws EElixirException
    */

  public static SqlRepositoryIF  getSqlRepository () throws EElixirException
  {

    if (_oBatchProcessSqlRepository   == null)
        _oBatchProcessSqlRepository  = new BatchProcessSqlRepository  ();

    return (SqlRepositoryIF)_oBatchProcessSqlRepository ;
  }

  /**
  * Member Variables
  */

  public static BatchProcessSqlRepository  _oBatchProcessSqlRepository = null;
}

