package com.mastek.eElixir.batchprocess.util;

import com.mastek.eElixir.common.util.ActionFactory;


/**
 * <p>Title: AMAL</p>
 * <p>Description:This class is responsible for getting the singleton instance of the ActionFactory</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 */

public class BatchProcessActionFactory extends ActionFactory
{

  private BatchProcessActionFactory()
  {
  }

  /**
    *Returns a Singleton instance of the ActionFactory
    *@return ActionFactory
    */
  public static ActionFactory getActionFactory()
  {
    if (BatchProcessActionFactory._oBatchProcessActionFactorySingleton == null)
        BatchProcessActionFactory._oBatchProcessActionFactorySingleton = new BatchProcessActionFactory ();
    return BatchProcessActionFactory._oBatchProcessActionFactorySingleton;
  }


  /**
  * Member Variables
  */

  public static BatchProcessActionFactory _oBatchProcessActionFactorySingleton = null;
}