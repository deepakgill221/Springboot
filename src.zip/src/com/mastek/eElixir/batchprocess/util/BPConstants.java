package com.mastek.eElixir.batchprocess.util;

/**
 *
 * Modified On   Modified By        Reason
 * 06/06/2003    Heena Jain         Removed UPLOAD_FIND_BY_PK = "UploadFindByPrimaryKey
 * 10/06/2003    Heena Jain         Added INSERT_BATCH_PRC_RESULT,UPDATE_BATCH_PRC_RESULT
 *                                  added BP_RESULT_SEQUENCE. ALso added batch process
 *                                  execution status types
 * 10/06/2003    Pravin Boga        Added TBL_NAMES_SEARCH
 * 11/06/2003    Pravin Boga        Added TBL_DEFN_HDR_UPDATE
 * 11/06/2003    Heena Jain         Added BatchProcessDataMapInsert
 *                                  Added UPDATE_BATCH_PRC_HDR
 * 12/06/2003    Heena Jain         Modified UPDATE_BATCH_PRC_RESULT
 * 17/06/2003    Pravin Boga        Added DATA_FOR_UPLOAD, DATA_FOR_DOWNLOAD
 * 18/06/2003    Heena Jain         Modified the value assigned to DATA_FOR_DOWNLOAD
 * 21/06/2003    Pravin Boga        Added DATA_TYPE_CHAR,DATA_TYPE_DATE,DATA_TYPE_VARCHAR2
 * 05-01-2011    Shrikrishna        Rel. Q2 (Feb 2011) (Location wise restriction of instrument collection entryv1.4.DOC)
 */

public interface BPConstants
{
/* Constant which identifies the data type as Number for Oracle*/
    public static final String DATA_TYPE_NUMBER ="NUMBER";
    public static final String DATA_TYPE_CHAR ="CHAR";
    public static final String DATA_TYPE_DATE ="DATE";
    public static final String DATA_TYPE_VARCHAR2 ="VARCHAR2";    


/* Data Constants */
    public static final int BP_TYPE_UPLOAD = 1;
    public static final int BP_TYPE_BATCH_PRC = 2;

    public static final int BP_EXECUTION_STATUS_CODE = 6013;
    public static final int BATCH_PROCESS_TYPE = 6012;

// Added by nigam for dropdowns in Data Upload:    
	public static final int BATCH_PROCESS_DELIMETER = 6016;
	public static final int BATCH_PROCESS_FORMAT = 6017;
	public static final int BATCH_PROCESS_COMMA = 1;
	public static final int BATCH_PROCESS_FIXED = 1;
	public static final int BATCH_PROCESS_DELIMITED = 2;
	public static final String DELIMITER_AS_COMMA = ",";
	
	public static final int FOR_INSTRUMENT_UPLOAD = 1;
	public static final int FOR_ECS_AND_CR_DR_UPLOAD = 2;
		
    

    public static final int BP_EXC_STATUS_STARTED = 1;
    public static final int BP_EXC_STATUS_COMPLETED = 2;
    public static final int BP_EXC_STATUS_COMPLETED_WITH_ERRORS = 3;
    public static final int BP_EXC_STATUS_TERMINATED = 4;

    // identifies it as upload process information
    public static final Short DATA_FOR_UPLOAD = new Short("1");
    // identifies it as download process information
    public static final Short DATA_FOR_DOWNLOAD = new Short("0");
    
	public static final short PROC_SEQ_FOR_BANK_STMT_UPLOAD = 1;
	public static final short PROC_SEQ_FOR_INSTR_UPLOAD = 2;
	public static final short PROC_SEQ_FOR_ECS_UPLOAD = 3;
	public static final short PROC_SEQ_FOR_CR_DR_UPLOAD = 4;
	public static final short PROC_SEQ_FOR_JV_OTHER_UPLOAD = 5;
	public static final short PROC_SEQ_FOR_JV_POLICY_UPLOAD = 6;
	public static final short PROC_SEQ_FOR_ACCOUNT_UPLOAD = 7;
	public static final short PROC_SEQ_FOR_FUTURE_CRDR_UPLOAD = 8;
	public static final short PROC_SEQ_FOR_STARTEK_POL_UPLOAD = 9;
	public static final short PROC_SEQ_FOR_SUN_CHQ_UPLOAD = 10;
//Added by jayasimha	
	public static final short PROC_SEQ_FOR_COMM_RULE_UPLOAD = 11;
	public static final short PROC_SEQ_FOR_CHM_EMAIL_UPLOAD = 12;
	public static final short PROC_SEQ_FOR_CHM_POL_TRF_UPLOAD = 13;
	public static final short PROC_SEQ_FOR_CHM_AGENT_PAYMENT_UPLOAD = 14;
	public static final short PROC_SEQ_FOR_CHM_COMM_MAP_RULE_UPLOAD = 15;
//	<!-- ANUP_Everest Distritbution FS_Phase_II_REL9.0 Starts -->
	public static final short PROC_SEQ_FOR_CHM_PLAN_SETUP_UPLOAD = 17;
//	<!-- ANUP_Everest Distritbution FS_Phase_II_REL9.0 Ends -->	
	
	//<!-- ANUP_AGN17_REL9.0 Starts-->
	public static final short PROC_SEQ_FOR_BULK_TERMINATION_AGN_UPLOAD = 18;
	//<!-- ANUP_AGN17_REL9.0 Ends-->	
	//<!-- //ANUP_AGN74_REL9.0 Starts -->
	public static final short PROC_SEQ_FOR_BULK_REASSIGN_AGN_UPLOAD = 19;
	//<!-- //ANUP_AGN74_REL9.0 Ends -->
//	<!-- //ANUP_AGN74_REL9.0 Starts -->
	public static final short PROC_SEQ_FOR_CHM_ACTURIAL_PERSIST_UPLOAD = 20;
	//<!-- //ANUP_AGN74_REL9.0 Ends -->
//	<!-- //ANUP_AGN74_REL9.0 Starts -->
	public static final short PROC_SEQ_FOR_CHM_GO_ASSOCIATION_UPLOAD = 21;
	//<!-- //ANUP_AGN74_REL9.0 Ends -->
//	<!--Anup_Upload_Commision_Dispatch_Details_Starts-->
	public static final short PROC_SEQ_FOR_CHM_COMMISION_DISPATCH_UPLOAD = 22;
	//<!--Anup_Upload_Commision_Dispatch_Details_Ends-->
	//<!--Anup_Upload_GO_Override_APR_REL_Starts-->
	public static final short PROC_SEQ_FOR_GOOVERRIDE_UPLOAD = 23;
//	<!--Anup_Upload_GO_Override_APR_REL_Ends-->
//	<!--Anup_Upload_MPP_APR_REL_Starts-->
	public static final short PROC_SEQ_FOR_MPP_UPLOAD = 24;
	//<!--Anup_Upload_MPP_APR_REL_Ends-->
//	<!--Anup_Upload_Bancassurance_Starts-->
	public static final short PROC_SEQ_FOR_BANCASSURANCE_UPLOAD = 25;
	//<!--Anup_Upload_Bancassurance_Ends-->
//	 FIN_71-74_Success or Bounce statements upload facility_APR_REL_Anup_Starts
	public static final short PROC_SEQ_FOR_CREDITCARD_STMT_UPLOAD = 26;
	public static final short PROC_SEQ_FOR_ECS_STMT_UPLOAD = 27;
//	 FIN_71-74_Success or Bounce statements upload facility_APR_REL_Anup_Ends
//		Adjusted_paid_case_setup_Anup_Starts
	public static final short PROC_SEQ_FOR_ADJ_PAID_CASE_UPLOAD = 28;
//		Adjusted_paid_case_setup_Anup_Ends
//	<!--AGN98_Anup_Uploads_Bonus/Product_Persistency_Designation_JUL_REL_Starts-->	
	public static final short PROC_SEQ_FOR_DESGN_UPLOAD = 29;
	public static final short PROC_SEQ_FOR_BONUS_PRD_UPLOAD = 30;
	public static final short PROC_SEQ_FOR_PERST_PRD_UPLOAD = 31;
//	<!--AGN98_Anup_Uploads_Bonus/Product_Persistency_Designation_JUL_REL_Ends-->	
//Srikanth CTS Starts For Bulk Agent movement Upload 
	public static final short PROC_SEQ_FOR_BULK_PROMOTION_AGN_UPLOAD = 32;
	public static final short PROC_SEQ_FOR_BULK_DEMOTION_AGN_UPLOAD = 33;
	public static final short PROC_SEQ_FOR_BULK_TRANSFER_AGN_UPLOAD = 34;
//End Srikanth CTS	
 //START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	public static final short PROC_SEQ_FOR_CONTACT_SERVICE_REQQUEST_UPLOAD = 44;
	public static final short PROC_SEQ_FOR_PAN_SERVICE_REQQUEST_UPLOAD= 42;
	public static final short PROC_SEQ_FOR_ADDRESS_SERVICE_REQQUEST_UPLOAD = 43;
  //ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	
	// Anantha_SuccessBounce_Upload_FS STARTS-changes done by anantha 
	public static final short PROC_SEQ_FOR_CC_BANK_STMT_UPLD_NEW = 1010;
	public static final short PROC_SEQ_FOR_ECS_BANK_STMT_UPLD_NEW = 1011;
	// Anantha_SuccessBounce_Upload_FS ENDS
	
	//Added by Srikanth CTS For MPS
	public static final short PROC_SEQ_FOR_AGENT_MPS_CALCULATION = 35;
	//End by Srikanth CTS MPS
	//ALEX_FSD_Pending_Agents_Reject_Upload Starts
	public static final short PROC_SEQ_FOR_PENDING_REJECT_UPLD = 36;
	//ALEX_FSD_Pending_Agents_Reject_Upload Ends
	    // ------------ CONSTANTS FOR SQL REPOSITORY -------------------

/* For Job View Queries */
    public static final String JOBVIEW_LIST_SEARCH	="JobViewListSearch";
    public static final String JOBVIEW_SEARCH	    ="JobViewSearch";
    public static final String JOBVIEW_FIND_BY_PK   ="JobViewByPrimaryKey";

/* For Upload Queries */
    public static final String UPLOAD_LIST_SEARCH = "UploadListSearch";
    public static final String SELECT_ALL_TAB     ="SelectAllTab";
    public static final String SELECT_DATA_MAP = "SelectDataMap";
    public static final String INSERT_BATCH_PRC_RESULT = "BatchProcessResultInsert";
    public static final String UPDATE_BATCH_PRC_RESULT = "BatchProcessResultUpdate";
    public static final String BP_RESULT_SEQUENCE = "BatchProcessResultSequence";
    public static final String INSERT_BATCH_PRC_DATA_MAP = "BatchProcessDataMapInsert";
    public static final String UPDATE_BATCH_PRC_HDR = "BatchProcessHdrUpdate";
	public static final String SEARCH_PROC_SEQ_NBR = "SearchProcSeqNbr"; 
	//Anantha_SuccessBounce_Upload_FS starts
	 public static final String UPDATE_CC_BNKSTMT_UPLOAD = "CCBnkstmtUploadUpdate";
	 public static final String UPDATE_ECS_BNKSTMT_UPLOAD = "ECSBnkstmtUploadUpdate";

	//Anantha_SuccessBounce_Upload_FS ends	

	// Table Definition
	public static final String TBL_DEFN_LIST_SEARCH = "TblDefnListSearch";
	public static final String TBL_DEFN_HDR_SEARCH = "TblDefnHdrSearch";
  public static final String TBL_DEFN_HDR_INSERT = "TblDefnHdrInsert";
  public static final String TBL_DEFN_DTL_INSERT = "TblDefnDtlInsert";
  public static final String TBL_NAMES_SEARCH = "TblNamesSearch";
  public static final String TBL_DEFN_HDR_UPDATE = "TblDefnHdrUpdate";
  
  // Procedures for Upload operation::
  public static final String PROC_BANK_STMT_UPLOAD_TEMP = "ProcBankStmtUploadTemp";
  public static final String PROC_BANK_STMT_UPLOAD = "ProcBankStmtUpload";
  public static final String PROC_BANK_RECONCILIATION = "ProcBankReconciliation";

  public static final String PROC_INSTRUMENT_UPLOAD_TEMP = "ProcInstrumentUploadTemp";
  public static final String PROC_INSTRUMENT_UPLOAD = "ProcInstrumentUpload";
  public static final String PROC_ECS_STMT_UPLOAD = "ProcECSStmtUpload"; 
  public static final String PROC_CRDR_CARD_SI_UPLOAD = "ProcCrDrCardSIUpload";
  public static final String PROC_JV_TEMP_UPLOAD = "ProcJVTempUpload";
  public static final String PROC_JV_OTHER_UPLOAD = "ProcJVOtherUpload";
  public static final String PROC_JV_POLICY_UPLOAD = "ProcJVPolicyUpload";
  public static final String PROC_ACCOUNT_CODE_UPLOAD = "ProcAccountMasterUpload";
  public static final String PROC_STARTEK_POL_UPLOAD = "ProcStarTekPolUpload";
  public static final String PROC_FUTURE_CRDR_UPLOAD = "ProcFutureCrDrUpload";
  public static final String PROC_SUN_CHQ_UPLOAD = "ProcSunChqUpload";
  public static final short INSTRUMENT_TYPE_CD_FOR_ECS = 4;    
  
  public static final String GET_IP_ADDRESS = "GetIPAddress";
  public static final String GET_EMAIL_ADDRESS = "GetEMailAddress";
  public static final String SUBJECT_MATTER = "Error while reading the file and uploading into a temporary table";
  public static final int FLAG_FOR_PROC_SUCCESS = 0;   
  
  
//Added by jayasimha for Channel management uploads
	
	public static final String PROC_COMM_RULE_TEMP_UPLOAD = "ProcCommRuleTempUpload";
	public static final String PROC_COMM_RULE_MAIN_UPLOAD = "ProcCommRuleMainUpload";
		
	public static final String PROC_BANK_TEMP_UPLOAD = "ProcBankTempUpload";
	public static final String PROC_BANK_MAIN_UPLOAD = "ProcBankMainUpload";
	
	public static final String PROC_POLTRF_TEMP_UPLOAD = "ProcPoltrfTempUpload";
	public static final String PROC_POLTRF_MAIN_UPLOAD = "ProcPoltrfMainUpload";
	
	public static final String PROC_EMAIL_TEMP_UPLOAD = "ProcEmailTempUpload";
	public static final String PROC_EMAIL_MAIN_UPLOAD = "ProcEmailMainUpload";
	
	public static final String PROC_COMM_MAP_RULE_TEMP_UPLOAD = "CommMapRuleTempUpload";
	public static final String PROC_COMM_MAP_RULE_MAIN_UPLOAD = "CommMapRuleMainUpload";	

//	<!-- ANUP_Everest Distritbution FS_Phase_II_REL9.0 Starts -->
	public static final String PROC_PLAN_SETUP_UPLOAD = "ProcPlanSetupUpload";
//	<!-- ANUP_Everest Distritbution FS_Phase_II_REL9.0 Ends -->
//	<!-- ANUP_AGN17_REL9.0 Starts-->
	public static final String PROC_BULK_TERMINATION_AGN_TEMP_UPLOAD = "ProcBulkTerminationTempUpload";
	public static final String PROC_BULK_TERMINATION_AGN_MAIN_UPLOAD = "ProcBulkTerminationMainUpload";
//	<!-- ANUP_AGN17_REL9.0 Ends-->	
//	<!-- //ANUP_AGN74_REL9.0 Starts -->
	public static final String PROC_BULK_REASSIGN_AGN_TEMP_UPLOAD = "ProcBulkReassignmentTempUpload";
	public static final String PROC_BULK_REASSIGN_AGN_MAIN_UPLOAD = "ProcBulkReassignmentMainUpload";
//	<!-- //ANUP_AGN74_REL9.0 Ends -->
	//Srikanth CTS Starts For Bulk Agent movement Upload 
	public static final String PROC_BULK_PROMOTION_AGN_TEMP_UPLOAD = "ProcBulkPromotionTempUpload";
	public static final String PROC_BULK_PROMOTION_AGN_MAIN_UPLOAD = "ProcBulkPromotionMainUpload";
	//START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	public static final String PROC_CONTACT_SERVICE_REQUEST_TEMP_UPLOAD = "ProcContactServiceReqTempUpload";
	public static final String PROC_CONTACT_SERVICE_REQUEST_MAIN_UPLOAD = "ProcContactServiceReqMainUpload";
	//ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	
	public static final String PROC_BULK_DEMOTION_AGN_TEMP_UPLOAD = "ProcBulkDemotionTempUpload";
	public static final String PROC_BULK_DEMOTION_AGN_MAIN_UPLOAD = "ProcBulkDemotionMainUpload";
	//START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	public static final String PROC_PAN_SERVICE_REQUEST_TEMP_UPLOAD = "ProcPanServiceReqTempUpload";
	public static final String PROC_PAN_SERVICE_REQUEST_MAIN_UPLOAD = "ProcPanServiceReqMainUpload";
	//ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	//START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	public static final String PROC_ADDRESS_SERVICE_REQUEST_TEMP_UPLOAD = "ProcAddressServiceReqTempUpload";
	public static final String PROC_ADDRESS_SERVICE_REQUEST_MAIN_UPLOAD = "ProcAddressServiceReqMainUpload";
	//ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	
	public static final String PROC_BULK_TRANSFER_AGN_TEMP_UPLOAD = "ProcBulkTransferTempUpload";
	public static final String PROC_BULK_TRANSFER_AGN_MAIN_UPLOAD = "ProcBulkTransferMainUpload";
	//Ended By Srikanth CTS
//	<!-- //Anup_Everest_Upload_Actuarial_Persistancy_Starts -->
	public static final String PROC_ACTURIAL_PERSIST_TEMP_UPLOAD = "ProcActurialPersistTempUpload";
	public static final String PROC_ACTURIAL_PERSIST_MAIN_UPLOAD = "ProcActurialPersistMainUpload";
//	<!-- //Anup_Everest_Upload_Actuarial_Persistancy_Ends -->
//	<!-- //Anup_Everest_Upload_GO_Association_Starts-->
	public static final String PROC_CHM_GO_ASSOCIATION_TEMP_UPLOAD = "ProcGOAssociationTempUpload";
	public static final String PROC_CHM_GO_ASSOCIATION_MAIN_UPLOAD = "ProcGOAssociationMainUpload";
//	<!-- //Anup_Everest_Upload_GO_Association_Ends--> 
//	<!--Anup_Upload_Commision_Dispatch_Details_Starts-->
	public static final String PROC_CHM_COMMISION_DISPATCH_TEMP_UPLOAD = "ProcCommDispatchTempUpload";
	public static final String PROC_CHM_COMMISION_DISPATCH_MAIN_UPLOAD = "ProcCommDispatchMainUpload";
//	<!--Anup_Upload_Commision_Dispatch_Details_Ends-->
//	<!--Anup_Upload_Bancassurance_Starts-->
	public static final String PROC_CHM_BANCASSURANCE_TEMP_UPLOAD = "ProcBancassuranceTempUpload";
	public static final String PROC_CHM_BANCASSURANCE_MAIN_UPLOAD = "ProcBancassuranceMainUpload";
//	<!--Anup_Upload_Bancassurance_Ends-->
//	<!--Anup_Upload_GO_Override_APR_REL_Starts-->		
	public static final String PROC_CHM_GOOVERRIDE_TEMP_UPLOAD = "ProcGOOverrideTempUpload";
	public static final String PROC_CHM_GOOVERRIDE_MAIN_UPLOAD = "ProcGOOverrideMainUpload";
//	<!--Anup_Upload_GO_Override_APR_REL_Ends-->		
//	<!--Anup_Upload_MPP_APR_REL_Starts-->
	public static final String PROC_CHM_GO_GLP_TEMP_UPLOAD = "ProcGOGLPTempUpload";
	public static final String PROC_CHM_GO_GLP_MAIN_UPLOAD = "ProcGOGLPMainUpload";
//	<!--Anup_Upload_MPP_APR_REL_Ends-->
//	 FIN_71-74_Success or Bounce statements upload facility_APR_REL_Anup_Starts
	// Anantha_SuccessBounce_Upload_FS STARTS
	public static final String PROC_CREDITCARD_STMT_TEMP_UPLOAD = "ProcCreditCardSTMTTempUpload";
	public static final String PROC_CREDITCARD_STMT_MAIN_UPLOAD = "ProcCreditCardSTMTMainUpload";
	public static final String PROC_CREDITCARD_STMT_UPLOAD_NEW = "ProcCreditCardSTMTUploadNew";

	public static final String PROC_ECS_STMT_TEMP_UPLOAD = "ProcECSSTMTTempUpload";
	public static final String PROC_ECS_STMT_MAIN_UPLOAD = "ProcECSSTMTMainUpload";
	public static final String PROC_ECS_STMT_UPLOAD_NEW = "ProcECSSTMTUploadNew";
	public static final boolean CHEKEDFLAG = true;
	// Anantha_SuccessBounce_Upload_FS ENDS
//	 FIN_71-74_Success or Bounce statements upload facility_APR_REL_Anup_Ends
	
//		Adjusted_paid_case_setup_Anup_Starts
	public static final String PROC_CHM_ADJ_PAID_CASE_TEMP_UPLOAD = "ProcAdjPaidCaseTempUpload";
	public static final String PROC_CHM_ADJ_PAID_CASE_MAIN_UPLOAD = "ProcAdjPaidCaseMainUpload";
//		Adjusted_paid_case_setup_Anup_Ends
	//<!--AGN98_Anup_Uploads_Bonus/Product_Persistency_Designation_JUL_REL_Starts-->
	public static final String PROC_CHM_DESGN_TEMP_UPLOAD = "ProcDesgnTempUpload";
	public static final String PROC_CHM_DESGN_MAIN_UPLOAD = "ProcDesgnMainUpload";
	public static final String PROC_CHM_BONUS_PRD_TEMP_UPLOAD = "ProcBonusPrdTempUpload";
	public static final String PROC_CHM_BONUS_PRD_MAIN_UPLOAD = "ProcBonusPrdMainUpload";
	public static final String PROC_CHM_PERST_PRD_TEMP_UPLOAD = "ProcPerstPrdTempUpload";
	public static final String PROC_CHM_PERST_PRD_MAIN_UPLOAD = "ProcPerstPrdMainUpload";
	//<!--AGN98_Anup_Uploads_Bonus/Product_Persistency_Designation_JUL_REL_Ends-->
	
	//Added by Srikanth CTS for MPS
	public static final String PROC_AGENT_MPS_CALCULATION_TEMP = "ProcAgentMPSCalcTemp";
	public static final String PROC_AGENT_MPS_CALCULATION_MAIN = "ProcAgentMPSCalcMain";
	//End by Srikanth CTS
	//  ALEX_FSD_Pending_Agents_Reject_Upload Starts
	public static final String PROC_PENDING_AGENT_REJECT_TEMP = "ProcPendingAgentRejectTemp";
	public static final String PROC_PENDING_AGENT_REJECT_MAIN = "ProcPendingAgentRejectMain";
	//  ALEX_FSD_Pending_Agents_Reject_Upload Ends
	public static final String UPLOAD_ERROR_LIST = "uploaderrorlist";
	public static final String NO_RESULT_XML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><noContent></noContent>";
	public static final int FLAG_FOR_SQLLODER_NOTSUCCESS  = -1;
	public static final int FLAG_FOR_PROC_NOTSUCCESS  = -2;
	public static final int FLAG_FOR_EMAIL = 0;
	public static final int FLAG_FOR_EMAIL_MESSAGES = 1;

	
	
	
//End of the code added by jayasimha for uploads	

	//Added by Srikanth CTS for Bulk Agent Movement Upload
	public static final short BULK_UPLD_MOVEMENT_PROMOTION = 1;
	public static final short BULK_UPLD_MOVEMENT_DEMOTION = 2;
	public static final short BULK_UPLD_MOVEMENT_TRANSFER = 3;
	public static final short BULK_UPLD_MOVEMENT_REASSIGNMENT = 4;
	public static final short BULK_UPLD_MOVEMENT_TERMINATION = 5;
	//Ended by Srikanth CTs for Bulk Agent Movement Upload
	//START by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	public static final short SERVICE_REQUEST_UPLD_CONTACT = 1;
	public static final short SERVICE_REQUEST_UPLD_PAN = 2;
	public static final short SERVICE_REQUEST_UPLD_ADDRESS = 3;
	//ENDED by Sumalatha M on 14-Feb-2013 for Bulk upload for Contact detail,PAN and address change in Myagent_version1.0 -->
	
	// <Rel. Q2 (Feb 2011) - Start : Added by  Shrikrishna on 05-01-2011 FOR CR:Location wise restriction of instrument collection entryv1.4.DOC 
	public static final short PROC_SEQ_FOR_LOCATIONWISE_RESTRICTION_UPLOAD = 37;
	public static final String PROC_LOCATIONWISE_RESTRICTION_TEMP = "LocationwiseRestrictionTemp";
	public static final String PROC_LOCATIONWISE_RESTRICTION_UPLD = "LocationwiseRestrictionUpload";
	//<Rel. Q2 (Feb 2011) - End : Added by  Shrikrishna on 05-01-2011 FOR CR:Location wise restriction of instrument collection entryv1.4.DOC 

	//Start FSD_551 Automation of manual upload Sagar 29-oct-2012

	public static final short PROC_SEQ_FOR_MANUAL_MATCH_UPLOAD = 41;
	public static final String PROC_MANUAL_MATCH_UPLOAD_TEMP = "ProcManualMatchUploadTemp";
	public static final String PROC_MANUAL_MATCH_UPLOAD_MAIN = "ProcManualMatchUploadMain";

	//End FSD_551 Automation of manual upload Sagar 29-oct-2012

	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Starts>
	public static final String SELECT_RESULT = "SelectResult";
	public static final String SELECT_ECSLCASHSEQNO = "SelectEcsLCashSeqNo";
	public static final String SELECT_CCLCASHSEQNO = "SelectCCLCashSeqNo";
	String UPDATE_CCS_EXIT="Ccs_Upload_Exit";
	String UPDATE_ECS_EXIT="Ecs_Upload_Exit";
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Ends>
	// Parent_Branch_Code_Change_AGN430_Rohit Starts
	public static final String PROC_BULK_TRANSFER_AGNCY_TEMP_UPLOAD = "ProcBulkTransferAgencyTempUpload";
	public static final String PROC_BULK_TRANSFER_AGNCY_MAIN_UPLOAD = "ProcBulkTransferAgencyMainUpload";
	/* Obtained from select * from com_batch_prc_m  Column: NPROCSEQ*/
	
	//Added By Himanshu_JV Posting	
	public static final String PROC_BULK_UPLOAD_PROHIBIT_JV_POSTING_TEMP = "ProcBulkUploadProhibitJVPosting";
	public static final String PROC_BULK_UPLOAD_PROHIBIT_JV_POSTING_MAIN = "ProcBulkUploadProhibitJVPostingmain";
	//Ends here
	 //Mismatch in Bank Statement for given  MM_SP_ECS_BANK_STMT_UPLD
	// Added by Manisha on 7-Aug-2013 for MACH-17 - START
	public static final String PROC_SUSP_FROM_NB_TEMP = "ProcSuspensionFromNBUpload";
	public static final String PROC_SUSP_FROM_NB_MAIN = "ProcSuspensionFromNBUploadMain";
	public static final short PROC_SEQ_SUSP_FROM_NB = 48;
	// // Added by Manisha on 7-Aug-2013 for MACH-17 - END
	
	
	public static final short PROC_SEQ_FOR_BULK_TRANSFER_AGNCY_UPLOAD=38 ;
	// Parent_Branch_Code_Change_AGN430_Rohit Ends
	
	//<Added by Himanshu:TS_FSD_Bulk Upload Prohibit JV Postingv1.0.doc
	public static final short PROC_SEQ_FOR_BULK_UPLOAD_PROHIBIT_JV_POSTING=40 ;
	//<Added by Himanshu:TS_FSD_Bulk Upload Prohibit JV Postingv1.0.doc
	
	// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 - START
	public static final short PROC_SEQ_COLLECTION_ACHV_UPLD = 49;
	public static final String PROC_COLLECTION_ACHV_UPLD_TEMP = "ProcCollectionAchievementUpload";
	public static final String PROC_COLLECTION_ACHV_UPLD_MAIN = "ProcCollectionAchievementUploadMain";
	// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 - Ends
	
	//Added by Varun on 09-Jun-2014 for Rel 15.1 FSD_POS989 - Starts
	public static final short PROC_SEQ_NONHYBRID_INSTR_UPLD = 50;
	public static final String PROC_NONHYBRID_INSTR_UPLD_TEMP = "ProcNonHybridInstrumentUpload";
	public static final String PROC_NONHYBRID_INSTR_UPLD_MAIN = "ProcNonHybridInstrumentUploadMain";
	
	public static final short PROC_SEQ_NONHYBRID_ECS_UPLD = 51;	
	public static final String PROC_NONHYBRID_ECS_UPLD_MAIN = "ProcNonHybridECSUploadMain";
	
	public static final short PROC_SEQ_NONHYBRID_CCS_UPLD = 52;	
	public static final String PROC_NONHYBRID_CCS_UPLD_MAIN = "ProcNonHybridCCSUploadMain";	
	
	public static final String NONHYBRID_COLN = "GetNonHybridCollection";
	public static final String CSV_EXT = ".csv";	
	//Added by Varun on 09-Jun-2014 for Rel 15.1 FSD_POS989 - Ends
	
	// Added by Manisha on 28-Jan-2015 for FIN816 - START
	public static final String CHECK_FLAG_FOR_SUCC = "CheckFlagForSucc";
	public static final String CHECK_FLAG_FOR_SUCC_I = "CheckFlagForSuccI";
	// Added by Manisha on 28-Jan-2015 for FIN816 - END
	
	// Added by Manisha on 5-Nov-2015 for Rel 16.1 FIN896 - START
	public static final short PROC_SEQ_COMMENTS_UPLD = 53;
	//public static final String PROC_SEQ_COMMENTS_UPLD_TEMP = "ProcCommentsUploadTemp";
	public static final String PROC_SEQ_COMMENTS_UPLD_MAIN = "ProcCommentsUploadMain";
	// Added by Manisha on 5-Nov-2015 for Rel 16.1 FIN896 - END
	
	// Added by Manisha on 4-May-2016 for MACH17.0 AGN902 - START
	public static final short BULK_UPLD_MOVEMENT_SUSPENSION = 6;
	public static final short BULK_UPLD_MOVEMENT_WITHDRAW = 7;
	public static final short PROC_SEQ_FOR_BULK_SUSPENSION_AGN_UPLOAD = 54;
	public static final short PROC_SEQ_FOR_BULK_WITHDRAW_AGN_UPLOAD = 55;
	public static final String PROC_BULK_SUSPENSION_AGN_TEMP_UPLOAD = "ProcBulkSuspensionTempUpload";
	public static final String PROC_BULK_SUSPENSION_AGN_MAIN_UPLOAD = "ProcBulkSuspensionMainUpload";
	public static final String PROC_BULK_WITHDRAW_AGN_TEMP_UPLOAD = "ProcBulkWithdrawTempUpload";
	public static final String PROC_BULK_WITHDRAW_AGN_MAIN_UPLOAD = "ProcBulkWithdrawMainUpload";
	// Added by Manisha on 4-May-2016 for MACH17.0 AGN902 - END
	
	//  AGN929: AML & ULIP upload:: Added by Aradhana Pandey: 4_Jul_2017::**START** 
	public static final short PROC_SEQ_AML_ULIP_TRNG_UPLD = 56;
	public static final String PROC_AML_ULIP_TRNG_UPLD_MAIN = "ProcAmlUlipTrngUpldMain";
	//  AGN929: AML & ULIP upload:: Added by Aradhana Pandey: 4_Jul_2017::**END**
	
    //AGN946 : Added by Aradhana Pandey: 10_Nov_2017::**START** 
	public static final short PROC_SEQ_AGENT_REGISTRATION_UPLD = 57;
	public static final String PROC_AGENT_REGISTRATION_UPLD_MAIN = "ProcAgentRegistrationUpldMain";
	public static final String PROC_AGENT_REGISTRATION_UPLD_CSV = "ProcAgentRegistrationUpldCsv";
	//AGN946: Added by Aradhana Pandey: 10_Nov_2017::**END**
	
}// end of interface