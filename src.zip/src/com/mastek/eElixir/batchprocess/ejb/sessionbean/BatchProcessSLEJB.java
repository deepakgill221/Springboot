/********************************************************************
 *
 *  PROJECT			: Amal
 *  MODULE NAME		: Batch Process
 *  FILENAME		: BatchProcessSLEJB.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 30 May, 2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1      10/06/2003    Heena Jain   Added getPreviewData(), and createDataForUpload
 * 1.2      17/06/2003    Heena Jain   Added downloadData(DataResult oDataResult)
 * 1.3		05/09/2003	  Heena Jain	Removed the method defn for Table defn
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.batchprocess.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.batchprocess.jobview.ejb.sessionbean.JobViewSLLocal;
import com.mastek.eElixir.batchprocess.jobview.ejb.sessionbean.JobViewSLLocalHome;
import com.mastek.eElixir.batchprocess.jobview.util.JobViewResult;
import com.mastek.eElixir.batchprocess.tabledefn.util.TableInfoResult;
import com.mastek.eElixir.batchprocess.upload.ejb.sessionbean.UploadSLLocal;
import com.mastek.eElixir.batchprocess.upload.ejb.sessionbean.UploadSLLocalHome;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.EJBHomeFactoryLocal;
import com.mastek.eElixir.common.util.Logger;

public class BatchProcessSLEJB implements SessionBean
{

    /**
     * Called by the container to create a session bean instance. Its parameters typically
     * contain the information the client uses to customize the bean instance for its use.
     * It requires a matching pair in the bean class and its home interface.
     */
    public void ejbCreate    ()
    {

    }

    /**
     * A container invokes this method before it ends the life of the session object. This
     * happens as a result of a client's invoking a remove operation, or when a container
     * decides to terminate the session object after a timeout. This method is called with
     * no transaction context.
     */
    public void ejbRemove    ()
    {

    }

    /**
     * The activate method is called when the instance is activated from its 'passive' state.
     * The instance should acquire any resource that it has released earlier in the ejbPassivate()
     * method. This method is called with no transaction context.
     */
    public void ejbActivate    ()
    {

    }

    /**
     * The passivate method is called before the instance enters the 'passive' state. The
     * instance should release any resources that it can re-acquire later in the ejbActivate()
     * method. After the passivate method completes, the instance must be in a state that
     * allows the container to use the Java Serialization protocol to externalize and store
     * away the instance's state. This method is called with no transaction context.
     */
    public void ejbPassivate    ()
    {

    }

    /**
     * Set the associated session context. The container calls this method after the instance
     * creation. The enterprise Bean instance should store the reference to the context
     * object in an instance variable. This method is called with no transaction context.
     *@ param sc
     */
    public void setSessionContext    (SessionContext a_oContext)
    {
      this._oContext = a_oContext;
    }

    /**
     * Constructor of the CHMSLEJB class
     */
    public BatchProcessSLEJB    ()
    {

    }

    /**
     * This method creates the data which is needed for downloading the file
     * @param a_oDataResult
     * @return
     * @throws EElixirException
     * @throws RemoteException
     */
    public DataResult downloadData(DataResult a_oDataResult)
            throws EElixirException,RemoteException
    {
        DataResult oDataResult = null;
        try
        {
            log.entry("BPSLEJB","downloadData","ENTRY");
            _oUploadSLLocalHome= getUploadSLHome();
            _oUploadSLLocal = _oUploadSLLocalHome.create();

            oDataResult = _oUploadSLLocal.downloadData(a_oDataResult);
            log.debug("BPSLEJB -- After downloadData ----");
        }
        catch(EJBException ejbex){
            throw new EElixirException(ejbex, "");
        }
        catch(CreateException ejbex){
            throw new EElixirException(ejbex, "");
        }
        catch(EElixirException eLex)
        {
            throw eLex;
        }
        return oDataResult;
    }// end of downloadData

    public DataResult searchTableColDefn(long lBatchPrcSeq,String strTableName
            , short nIsMapped) throws EElixirException,RemoteException
    {
        DataResult oDataResult = null;
        try
        {
            _oUploadSLLocalHome = getUploadSLHome();
            _oUploadSLLocal = _oUploadSLLocalHome.create();
                 oDataResult = _oUploadSLLocal.searchTableColDefn(lBatchPrcSeq,
                         strTableName, nIsMapped);
        }
        catch(EJBException ejbex){
         throw new EElixirException(ejbex, "");
       }
       catch(CreateException ejbex){
           throw new EElixirException(ejbex, "");
       }
       catch(EElixirException eLex)
       {
           throw eLex;
       }
        log.exit("BatchProcessSLEJB","searchJob","Search For Details"+oDataResult);
        return oDataResult;

    }

    public DataResult createDataForUpload(DataResult a_oDataResult)
            throws EElixirException,RemoteException
    {
        DataResult oDataResult = null;
        try
        {
            log.entry("BPSLEJB","createDataForUpload","ENTRY");
            _oUploadSLLocalHome= getUploadSLHome();
            _oUploadSLLocal = _oUploadSLLocalHome.create();
            log.debug("BPSLEJB _oUploadSLLocal : "+_oUploadSLLocal);
            oDataResult = _oUploadSLLocal.createDataForUpload(a_oDataResult);
            log.debug("BPSLEJB -- After createDataForUpload ----");
        }
        catch(EJBException ejbex){
            throw new EElixirException(ejbex, "");
        }
        catch(CreateException ejbex){
            throw new EElixirException(ejbex, "");
        }
        catch(EElixirException eLex)
        {
            throw eLex;
        }
        return oDataResult;
    }


    public DataResult getPreviewData(DataResult a_oDataResult)
            throws EElixirException,RemoteException
    {
        DataResult oDataResult = null;
        try
        {
            log.entry("BPSLEJB","getPreviewData","ENTRY");
            _oUploadSLLocalHome= getUploadSLHome();
            _oUploadSLLocal = _oUploadSLLocalHome.create();
            log.debug("BPSLEJB _oUploadSLLocal : "+_oUploadSLLocal);
            oDataResult = _oUploadSLLocal.getPreviewData(a_oDataResult);
            log.debug("BPSLEJB -- After getPreviewData ----");
        }
        catch(EJBException ejbex){
            throw new EElixirException(ejbex, "");
        }
        catch(CreateException ejbex){
            throw new EElixirException(ejbex, "");
        }
        catch(EElixirException eLex)
        {
            throw eLex;
        }
        return oDataResult;
    }// end of getPreviewData

    public String searchUploadTables(TableInfoResult a_oTableInfoResult)
            throws EElixirException,RemoteException
    {
        String resultData = null;
        try
        {
            log.entry("BPSLEJB","searchUploadTables","ENTRY");
            _oUploadSLLocalHome= getUploadSLHome();
            _oUploadSLLocal = _oUploadSLLocalHome.create();
            log.debug("BPSLEJB _oUploadSLLocal : "+_oUploadSLLocal);
            resultData = _oUploadSLLocal.searchUploadTables(a_oTableInfoResult);
            log.debug("BPSLEJB -- After serach result ----");
        }
        catch(EJBException ejbex){
            throw new EElixirException(ejbex, "");
        }
        catch(CreateException ejbex){
            throw new EElixirException(ejbex, "");
        }
        catch(EElixirException eLex)
        {
            throw eLex;
        }
        return resultData;

    }//end searchUploadTables


//    FindBug_Fix_SUNAINA_STARTS
	public String getErrorLogs(DataResult _oDataResult)
			throws EElixirException,RemoteException
	{
		String strResult ="";
		
		try
		{
			log.entry("BPSLEJB","searchUploadTables","ENTRY");
			_oUploadSLLocalHome= getUploadSLHome();
			_oUploadSLLocal = _oUploadSLLocalHome.create();
			log.debug("BPSLEJB _oUploadSLLocal : "+_oUploadSLLocal);
			strResult  = _oUploadSLLocal.getErrorLogs(_oDataResult);
			log.debug("BPSLEJB -- After serach result ----");
		}
//        FindBug_Fix_SUNAINA_STARTS
		catch(EJBException ejbex){
			throw new EElixirException(ejbex, "");
		}
		catch(CreateException ejbex){
			throw new EElixirException(ejbex, "");
		}
		catch(EElixirException eLex)
		{
			throw eLex;
		}
		return strResult;

	}//end searchUploadTables



	
	
	
	

    public ArrayList searchJob(long lPrcResultSeq, long lBatchPrcSeq, short nType)
            throws EElixirException,FinderException,RemoteException
    {
        ArrayList alJobViewResult = null;
        try
        {
            _oJobViewSLLocalHome= getJobViewSLHome();
                 alJobViewResult = _oJobViewSLLocal.searchJob(lPrcResultSeq,
                         lBatchPrcSeq, nType);

        }
        catch(EJBException ejbex){
         throw new EElixirException(ejbex, "");
       }
       catch(FinderException fe){
         throw new EElixirException(fe, "");
       }
        log.exit("BatchProcessSLEJB","searchJob","Search For Details"+alJobViewResult);
        return alJobViewResult;

    }// end of searchJob

    public String searchJob(JobViewResult a_oJobViewResult) throws RemoteException,EElixirException
    {
        String resultData = null;
        try
                {
          log.debug("BPSLEJB--In searchSuspend(SearchData a_oSearchData) of CHMSLEJB");

         _oJobViewSLLocalHome= getJobViewSLHome();
          _oJobViewSLLocal = _oJobViewSLLocalHome.create();
          log.debug("BPSLEJB _oJobViewSLLocal : "+_oJobViewSLLocal);
          resultData = _oJobViewSLLocal.searchJob(a_oJobViewResult);
          log.debug("BPSLEJB -- After serach result ----");
        }
    catch(EJBException ejbex){
      throw new EElixirException(ejbex, "");
    }
    catch(CreateException ejbex){
      throw new EElixirException(ejbex, "");
    }
    catch(EElixirException eLex)
    {
      throw eLex;
    }
         return resultData;
    }

    private JobViewSLLocalHome getJobViewSLHome() throws RemoteException,EElixirException
     {
        log.debug("--Looking for JobViewSLLocalHome");
        EJBHomeFactoryLocal objEJBHomeFactoryLocal = EJBHomeFactoryLocal.getFactory();
        JobViewSLLocalHome _oJobViewSLLocalHome = (JobViewSLLocalHome)objEJBHomeFactoryLocal
                .lookUpHome(EElixirUtils.getJNDIName(Constants.BATCH_PROCESS,"JobViewSLLocalHome"),
               JobViewSLLocalHome.class);

        log.debug("--returning JobViewSLLocalHome");
        return _oJobViewSLLocalHome;
  }

  private UploadSLLocalHome getUploadSLHome() throws RemoteException,EElixirException
   {
      log.entry("BPSLEJB","getUploadSLHome()","LOOKING FOR UPLOADSLHOME");

      EJBHomeFactoryLocal objEJBHomeFactoryLocal = EJBHomeFactoryLocal.getFactory();
      UploadSLLocalHome _oUploadSLLocalHome = (UploadSLLocalHome)objEJBHomeFactoryLocal
              .lookUpHome(EElixirUtils.getJNDIName(Constants.BATCH_PROCESS,"UploadSLLocalHome"),
             UploadSLLocalHome.class);

      log.exit("BPSLEJB","getUploadSLHome()","RETURN");
      return _oUploadSLLocalHome;
}
  
//Code added by Anup_Success_Bounce_Starts
		  public DataResult createUploadSuccessBounce(DataResult a_oDataResult)
		  throws EElixirException,RemoteException
		{
		DataResult oDataResult = null;
		try
		{
		  log.entry("BPSLEJB","createUploadSuccessBounce","ENTRY");
		  _oUploadSLLocalHome= getUploadSLHome();
		  _oUploadSLLocal = _oUploadSLLocalHome.create();
		  log.debug("BPSLEJB _oUploadSLLocal : "+_oUploadSLLocal);
		  oDataResult = _oUploadSLLocal.createUploadSuccessBounce(a_oDataResult);
		  log.debug("BPSLEJB -- After createUploadSuccessBounce ----");
		}
		catch(EJBException ejbex){
		  throw new EElixirException(ejbex, "");
		}
		catch(CreateException ejbex){
		  throw new EElixirException(ejbex, "");
		}
		catch(EElixirException eLex)
		{
		  throw eLex;
		}
		return oDataResult;
		}

		//Code added by Anup_Success_Bounce_Ends
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Starts>
	public boolean findMatchingRecordsForSuccessBounce(int nProcSeq,
			long ctrlSeqNum, double dSumNetAmnt, String strCCORECSRemarks)
			throws EElixirException, RemoteException {
		boolean result = false;
		try {
			log
					.entry("BPSLEJB", "findMatchingRecordsForSuccessBounce",
							"ENTRY");
			_oUploadSLLocalHome = getUploadSLHome();
			_oUploadSLLocal = _oUploadSLLocalHome.create();
			log.debug("BPSLEJB _oUploadSLLocal : " + _oUploadSLLocal);
			result = _oUploadSLLocal.findMatchingRecordsForSuccessBounce(
					nProcSeq, ctrlSeqNum, dSumNetAmnt, strCCORECSRemarks);
			log.debug("BPSLEJB -- After createUploadSuccessBounce ----");

		} catch (EJBException ejbex) {
			throw new EElixirException(ejbex, "");
		} catch (CreateException ejbex) {
			throw new EElixirException(ejbex, "");
		} catch (EElixirException eLex) {
			throw eLex;
		}
		return result;
	}
	public int exitSuccessBounceUploadECSCCS(int nProcSeq,long ctrlSeqNum,  String strUpdatedBy)
			throws EElixirException, RemoteException {
		int result = 0;
		try {
			log.entry("BPSLEJB", "findMatchingRecordsForSuccessBounce","ENTRY");
			_oUploadSLLocalHome = getUploadSLHome();
			_oUploadSLLocal = _oUploadSLLocalHome.create();
			log.debug("BPSLEJB _oUploadSLLocal : " + _oUploadSLLocal);
			result = _oUploadSLLocal.exitSuccessBounceUploadECSCCS(nProcSeq, ctrlSeqNum,strUpdatedBy);
			log.debug("BPSLEJB -- After createUploadSuccessBounce ----");

		} catch (EJBException ejbex) {
			throw new EElixirException(ejbex, "");
		} catch (CreateException ejbex) {
			throw new EElixirException(ejbex, "");
		} catch (EElixirException eLex) {
			throw eLex;
		}
		return result;
	}
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Ends>
	//Added  by Varun: Release 15.1 For POS 989 Non Hyrbid COllection Upload start
	public String getCSVDataForNH(String userId,String uploadFile) throws EElixirException,RemoteException {
		String fileName = null;
		try {
			log.entry("BPSLEJB", "getCSVDataForNH", "ENTRY");
			_oUploadSLLocalHome = getUploadSLHome();
			_oUploadSLLocal = _oUploadSLLocalHome.create();
			log.debug("BPSLEJB _oUploadSLLocal : " + _oUploadSLLocal);
			fileName = _oUploadSLLocal.getCSVDataForNH(userId,uploadFile);
			log.debug("BPSLEJB -- After getCSVDataForNH ----");
		} catch (EJBException ejbex) {
			throw new EElixirException(ejbex, "");
		} catch (CreateException ejbex) {
			throw new EElixirException(ejbex, "");
		} catch (EElixirException eLex) {
			throw eLex;
		}
		return fileName;
	}
	//Added  by Varun: Release 15.1 For POS 989 Non Hyrbid COllection Upload end
	
	//AGN946: Added by Aradhana Pandey: 15_Nov_2017::**START**
	public String getCSVDataForAgentRegUpload(String userId,String uploadFile) throws EElixirException,RemoteException
	{

		String fileName = null;
		try {
			log.entry("BPSLEJB", "getCSVDataForAgentRegUpload", "ENTRY");
			_oUploadSLLocalHome = getUploadSLHome();
			_oUploadSLLocal = _oUploadSLLocalHome.create();
			log.debug("BPSLEJB _oUploadSLLocal : " + _oUploadSLLocal);
			fileName = _oUploadSLLocal.getCSVDataForAgentRegUpload(userId,uploadFile);
			log.debug("BPSLEJB -- After getCSVDataForAgentRegUpload ----");
		} catch (EJBException ejbex) {
			throw new EElixirException(ejbex, "");
		} catch (CreateException ejbex) {
			throw new EElixirException(ejbex, "");
		} catch (EElixirException eLex) {
			throw eLex;
		}
		return fileName;	
	}
	//AGN946: Added by Aradhana Pandey: 15_Nov_2017::**END**
	
    private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

    private JobViewSLLocalHome _oJobViewSLLocalHome = null;
    private JobViewSLLocal _oJobViewSLLocal = null;

    private UploadSLLocalHome _oUploadSLLocalHome = null;
    private UploadSLLocal _oUploadSLLocal = null;

    public SessionContext _oContext;
}