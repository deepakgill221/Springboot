/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME		: BATCH PROCESS
 *  FILENAME		: BatchProcessSL.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 30 May, 2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1     10/09/2003    Heena Jain    Added getPreviewData(), and createDataForUpload
 * 1.2     17/06/2003    Heena Jain    Added downloadData(DataResult oDataResult)
 * 1.3	   05/09/2003	  Heena Jain   Removed the method defn for Table defn
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.batchprocess.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.ejb.EJBObject;
import javax.ejb.FinderException;

import com.mastek.eElixir.batchprocess.jobview.util.JobViewResult;
import com.mastek.eElixir.batchprocess.tabledefn.util.TableInfoResult;
import com.mastek.eElixir.batchprocess.upload.util.DataResult;
import com.mastek.eElixir.common.exception.EElixirException;

public interface BatchProcessSL extends EJBObject
{


/* Methods for Job View START */
/**
 * This method is used for list search
 * @param a_oJobViewResult
 * @return
 * @throws EElixirException
 * @throws RemoteException
 */
    public String searchJob(JobViewResult a_oJobViewResult)
            throws EElixirException,RemoteException;

    /**
     *  This method searches the selected job view and displays the corresponding
     * data for the same
     * @param lPrcResultSeq
     * @param lBatchPrcSeq
     * @param nType
     * @return
     * @throws EElixirException
     * @throws FinderException
     * @throws RemoteException
     */
    public ArrayList searchJob(long lPrcResultSeq,long lBatchPrcSeq, short nType)
            throws EElixirException,FinderException,RemoteException;

/* Methods for Job View END */

/* Methods for Uploads START */
    public String searchUploadTables(TableInfoResult a_oTableInfoResult)
            throws EElixirException,RemoteException;

    public DataResult searchTableColDefn(long lBatchPrcSeq,String strTableName, short nIsMapped)
            throws EElixirException,RemoteException;

    public DataResult getPreviewData(DataResult oDataResult)
            throws EElixirException,RemoteException;

    public DataResult createDataForUpload(DataResult oDataResult)
            throws EElixirException,RemoteException;
/* Methods for Uploads END */

/* ----------- Methods for Download START -------------- */

/**
 * This method is invoked by DownloadData action class
 * @param oDataResult
 * @return
 * @throws EElixirException
 * @throws RemoteException
 */
    public DataResult downloadData(DataResult oDataResult)
            throws EElixirException, RemoteException;
//	FindBug_Fix_SUNAINA_STARTED                
	public String getErrorLogs(DataResult oDataResult)
				throws EElixirException, RemoteException;   
//	FindBug_Fix_SUNAINA_STARTED

/* ----------- Methods for Download END -------------- */
	//Code added by Anup_Success_Bounce_Starts
	public DataResult createUploadSuccessBounce(DataResult oDataResult)
    throws EElixirException,RemoteException;
	//Code added by Anup_Success_Bounce_Ends
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Starts>
	public boolean findMatchingRecordsForSuccessBounce(int nProcSeq, long ctrlSeqNum, double dSumNetAmnt,String strCCORECSRemarks)
    throws EElixirException,RemoteException;
	public int exitSuccessBounceUploadECSCCS(int nProcSeq, long ctrlSeqNum,String strUpdatedBy)
    throws EElixirException,RemoteException;
	//<CODE_TAG: Q2_REL_FSD_FIN_158_Success_or_Bounce_statements_upload_facilityV1[1].5 Dated: 14/03/2011 Added By: Alexpandiyan Ends>

	//Added  by Varun: Release 15.1 For POS 989 Non Hyrbid COllection Upload start
	public String getCSVDataForNH(String userId,String uploadFile) throws EElixirException,RemoteException;
	//Added  by Varun: Release 15.1 For POS 989 Non Hyrbid COllection Upload end
	
	//AGN946: Added by Aradhana Pandey: 15_Nov_2017::**START**
	public String getCSVDataForAgentRegUpload(String userId,String uploadFile) throws EElixirException,RemoteException;
	//AGN946: Added by Aradhana Pandey: 15_Nov_2017::**END**
}
