package com.mastek.eElixir.batchprocess.ejb.sessionbean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

import com.mastek.eElixir.common.exception.EElixirException;

public interface BatchProcessSLHome extends EJBHome
{

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public BatchProcessSL create() throws RemoteException, CreateException, EElixirException;

}