/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME		: Batch Process
 *  FILENAME		: JobViewResult
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 05/06/2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1      20/06/2003    Heena Jain    Change for Timestamp
 *
 ***************************************************************/

package com.mastek.eElixir.batchprocess.jobview.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

public class JobViewResult implements Serializable
{
    public GregorianCalendar getDtEndTime() {
        return dtEndTime;
    }
    public GregorianCalendar getDtStartTime() {
        return dtStartTime;
    }
    public Long getLBatchPrcSeq() {
        return lBatchPrcSeq;
    }
    public Long getLPrcResultSeq() {
        return lPrcResultSeq;
    }
    public Long getLRowInserted() {
        return lRowInserted;
    }
    public Long getLRowRejected() {
        return lRowRejected;
    }
    public Long getLTotalRow() {
        return lTotalRow;
    }
    public Short getNStatus() {
        return nStatus;
    }
    public Short getNType() {
        return nType;
    }
    public String getStatus() {
        return status;
    }
    public String getStrElapsedTime() {
        return strElapsedTime;
    }
    public String getStrLogFileName() {
        return strLogFileName;
    }
    public String getStrUserId() {
        return strUserId;
    }
    public void setStrUserId(String strUserId) {
        this.strUserId = strUserId;
    }
    public void setStrLogFileName(String strLogFileName) {
        this.strLogFileName = strLogFileName;
    }
    public void setStrElapsedTime(String strElapsedTime) {
        this.strElapsedTime = strElapsedTime;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public void setNType(Short nType) {
        this.nType = nType;
    }
    public void setNStatus(Short nStatus) {
        this.nStatus = nStatus;
    }
    public void setLTotalRow(Long lTotalRow) {
        this.lTotalRow = lTotalRow;
    }
    public void setLRowRejected(Long lRowRejected) {
        this.lRowRejected = lRowRejected;
    }
    public void setLRowInserted(Long lRowInserted) {
        this.lRowInserted = lRowInserted;
    }
    public void setLPrcResultSeq(Long lPrcResultSeq) {
        this.lPrcResultSeq = lPrcResultSeq;
    }
    public void setLBatchPrcSeq(Long lBatchPrcSeq) {
        this.lBatchPrcSeq = lBatchPrcSeq;
    }
    public void setDtStartTime(GregorianCalendar dtStartTime) {
        this.dtStartTime = dtStartTime;
    }
    public void setDtEndTime(GregorianCalendar dtEndTime) {
        this.dtEndTime = dtEndTime;
    }

    /**
     * Added By Pravin Boga
     * Reason - to reatin the search criteria
     */
    public void setXMLString(String a_strXMLString)
    {
        this._strXMLString = a_strXMLString;
    }

    public String getXMLString()
    {
        return this._strXMLString;
  }


    private Long lPrcResultSeq;
    private Short nType;
    private Long lBatchPrcSeq;
    private GregorianCalendar dtStartTime;
    private GregorianCalendar dtEndTime;
    private Long lTotalRow;
    private Long lRowInserted;
    private Long lRowRejected;
    private String strElapsedTime;
    private Short nStatus;
    private String strLogFileName;
    private String strUserId;
    private String status;
    private String _strXMLString;


}