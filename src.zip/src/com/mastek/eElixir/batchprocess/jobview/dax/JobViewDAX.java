/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME		: Batch Process
 *  FILENAME		: JobViewDAX.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 03/06/2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1      14/06/2003    Heena Jain    Added order by clause in getJobView(long, long ,short )
 * 1.2      20/06/2003    Heena Jain    Changed for timestamp
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.batchprocess.jobview.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.batchprocess.jobview.ejb.entitybean.JobViewPK;
import com.mastek.eElixir.batchprocess.jobview.util.JobViewResult;
import com.mastek.eElixir.batchprocess.util.BPConstants;
import com.mastek.eElixir.batchprocess.util.BatchProcessSqlRepository;
import com.mastek.eElixir.common.exception.EElixirDAXException;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;
/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the JobView object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 */

public class JobViewDAX extends DAX
{
   private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * Constructor
   */
  public JobViewDAX()
  {
  }

  public JobViewResult getJobResult(JobViewPK a_oJobViewPK)
            throws EElixirException
    {
        PreparedStatement oPreparedStatement = null;
        ResultSet rsSearchJob = null;
        String strSelectSql = null;
        JobViewResult jobResult = null;

        try
        {
            log.entry("JobViewDAX","getJobResult",
                      "a_oJobViewPK : " + a_oJobViewPK);

            strSelectSql = getSQLString("Select",BPConstants.JOBVIEW_FIND_BY_PK);

            log.debug("JobViewDAX","getJobResult",
                      " strSelectSql : " + strSelectSql);

            Object[] oArr =
            {
                a_oJobViewPK.getLPrcResultSeq(),
                a_oJobViewPK.getLBatchPrcSeq(),
                a_oJobViewPK.getNType()
            };

            int[] iArr =
            {
                Types.NUMERIC,
                Types.NUMERIC,
                Types.NUMERIC
            };

            oPreparedStatement =
                    this.getPreparedStatement(strSelectSql, oArr, iArr);
            log.debug("oPreparedStatement......"+oPreparedStatement);

            rsSearchJob = executeQuery(oPreparedStatement);
            log.debug("rsSearchJob......"+rsSearchJob);
            if(rsSearchJob.next())
            {
                log.debug("rsSearchJob.Next()..");
                jobResult = new JobViewResult();
                jobResult.setLPrcResultSeq(new Long(rsSearchJob.getLong("LPRCRESULTSEQ")));
                jobResult.setNType(new Short(rsSearchJob.getShort("NTYPE")));
                jobResult.setLBatchPrcSeq(new Long(rsSearchJob.getLong("LBATCHPRCSEQ")));
                jobResult.setDtStartTime(DateUtil.retGregorian(rsSearchJob.getTimestamp("DTSTARTTIME")));
                jobResult.setDtEndTime(DateUtil.retGregorian(rsSearchJob.getTimestamp("DTENDTIME")));
                jobResult.setLTotalRow(new Long(rsSearchJob.getLong("LTOTALROW")));
                jobResult.setLRowInserted(new Long(rsSearchJob.getLong("LROWINSERTED")));
                jobResult.setLRowRejected(new Long(rsSearchJob.getLong("LROWREJECTED")));
                jobResult.setStrElapsedTime(rsSearchJob.getString("STRELAPSEDTIME"));
                jobResult.setNStatus(new Short(rsSearchJob.getShort("NSTATUS")));
                jobResult.setStrLogFileName(rsSearchJob.getString("STRLOGFILENAME"));
                jobResult.setStrUserId(rsSearchJob.getString("STRUSERID"));

            }// end if
            log.exit("JobViewDAX","getJobResult",
                   "oJobViewResult : " + jobResult);

            return jobResult;
        }// end try
        catch(SQLException sqlex)
        {
            // BP1003=Unable to retrieve the Job View Data
            log.fatal("JobViewDAX","getJobResult",
                      sqlex.getMessage());
            throw new EElixirDAXException(sqlex, "BP1003");
        }
        finally
        {
            try
            {
                if(oPreparedStatement != null)
                    oPreparedStatement.close();
            }
            catch(SQLException sqlex)
            {
                log.fatal("JobViewDAX","getJobResult",
                          sqlex.getMessage());
                throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
            }
        }
    }



  /**
     * getJobView gets the Job Details
     * @return JobViewResult
     * @param long LPRCRESULTSEQ -- Result Seq no
     * @param long LBATCHPRCSEQ --- Batch Process master seq no
     * @param short NTYPE --- Type identifies the tpe of process
     * @throws EElixirException
     */
    public ArrayList getJobView(long a_lPrcResultSeq, long a_lBatchPrcSeq, short nType)
            throws EElixirException
    {
      ResultSet rsSearchJob = null;
      PreparedStatement pstmtSearchJob = null;
      ArrayList alJobResult = new ArrayList();

      try
      {
          log.debug("a_lPrcResultSeq ----"+a_lPrcResultSeq);
          log.debug("a_lBatchPrcSeq ----"+a_lBatchPrcSeq);
          log.debug("nType ----"+nType);

          // Check if it is a upload process
          if(BPConstants.BP_TYPE_UPLOAD == nType)
          {
              String strSelectJobQuery =
                      getSQLString("Select", BPConstants.JOBVIEW_SEARCH);

              strSelectJobQuery += "AND LBATCHPRCSEQ = ? ";

              strSelectJobQuery += " ORDER BY LPRCRESULTSEQ DESC ";
              log.debug("Query String for select : "+strSelectJobQuery);

              pstmtSearchJob = getPreparedStatement(strSelectJobQuery);
              pstmtSearchJob.setShort(1,nType);
              pstmtSearchJob.setLong(2, a_lBatchPrcSeq);
              rsSearchJob = executeQuery(pstmtSearchJob);
              log.debug("After Query execution");

              while(rsSearchJob.next())
              {
                  JobViewResult jobResult = new JobViewResult();

                  jobResult.setLPrcResultSeq(new Long(rsSearchJob.getLong("LPRCRESULTSEQ")));
                  jobResult.setNType(new Short(rsSearchJob.getShort("NTYPE")));
                  jobResult.setLBatchPrcSeq(new Long(rsSearchJob.getLong("LBATCHPRCSEQ")));
                  jobResult.setDtStartTime(DateUtil.retGregorian(rsSearchJob.getTimestamp("DTSTARTTIME")));
                  jobResult.setDtEndTime(DateUtil.retGregorian(rsSearchJob.getTimestamp("DTENDTIME")));
                  jobResult.setLTotalRow(new Long(rsSearchJob.getLong("LTOTALROW")));
                  jobResult.setLRowInserted(new Long(rsSearchJob.getLong("LROWINSERTED")));
                  jobResult.setLRowRejected(new Long(rsSearchJob.getLong("LROWREJECTED")));
                  jobResult.setStrElapsedTime(rsSearchJob.getString("STRELAPSEDTIME"));
                  jobResult.setNStatus(new Short(rsSearchJob.getShort("NSTATUS")));
                  jobResult.setStrLogFileName(rsSearchJob.getString("STRLOGFILENAME"));
                  jobResult.setStrUserId(rsSearchJob.getString("STRUSERID"));

                  alJobResult.add(jobResult);

              }// end of while

          }// end if of upload process

        return alJobResult;
      }
      catch(SQLException sqlex){
         // BP1003=Unable to retrieve the Job View Data
        log.debug(sqlex.getMessage());
        throw new EElixirDAXException(sqlex, "BP1003");
      }
      finally
      {
        try
        {
          if(rsSearchJob != null)
            rsSearchJob.close();

          if(pstmtSearchJob != null)
            pstmtSearchJob.close();
        }
        catch(SQLException sqlex)
        {
          log.debug(sqlex.getMessage());
          throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
    }

  /**
   * Populates the resultset into XML string object
   * @param a_oResultObject Object
   * @return XML string object
   * @throws EElixirException
   */

  public String getJobView(JobViewResult oJobViewResult) throws EElixirException
  {
    log.debug("JobViewDAX--Inside getJobView of DAX");
    PreparedStatement pstmtSearchJob = null;
    Statement st = null ;
    StringBuffer sb = new StringBuffer();
    HashMap hmQueryMap = new HashMap();

    log.debug("JobViewDAX--Search Data" + oJobViewResult);
    try
    {
      log.debug("JobViewDAX--TRY" );
      Short nType = oJobViewResult.getNType();
      Short nStatus = oJobViewResult.getNStatus();
      GregorianCalendar dtStartTime = oJobViewResult.getDtStartTime();
      GregorianCalendar dtEndTime = oJobViewResult.getDtEndTime();

      String strSearchJobQuery = getSQLString("Select",
              BPConstants.JOBVIEW_LIST_SEARCH);
      log.debug("strSearchJobQuery--"+strSearchJobQuery);

      hmQueryMap.put("Main",strSearchJobQuery);

      strSearchJobQuery = " AND pr.NTYPE = ? " ;
      hmQueryMap.put("NTYPE",strSearchJobQuery);

      strSearchJobQuery = " AND pr.NSTATUS =  ? " ;
      hmQueryMap.put("NSTATUS",strSearchJobQuery);

      strSearchJobQuery = " AND pr.DTSTARTTIME >=  ? " ;
      hmQueryMap.put("DTSTARTTIME",strSearchJobQuery);

      strSearchJobQuery = " AND pr.DTENDTIME <=  ? " ;
      hmQueryMap.put("DTENDTIME",strSearchJobQuery);

      String strQuery = (String)hmQueryMap.get("Main");
      log.debug("JobViewDAX--Strquery =" + strQuery);

      if (nType != null)
      {
        strQuery += (String)hmQueryMap.get("NTYPE");
      }
      if (nStatus!= null )
      {
        strQuery += (String)hmQueryMap.get("NSTATUS");
      }
      if (dtStartTime != null ) {
        strQuery += (String)hmQueryMap.get("DTSTARTTIME");
      }
      if (dtEndTime!= null ) {
        strQuery += (String)hmQueryMap.get("DTENDTIME");
      }

      strQuery = strQuery + " order by pr.LPRCRESULTSEQ";
      log.debug("JobViewDAX--FINAL FORMED Strquery =" + strQuery);

      pstmtSearchJob = getPreparedStatement(strQuery);
      log.debug("JobViewDAX--Query Formed  " + strQuery);

      int iPosition = 0 ;

      // set the param type for the Batch Process Type
      pstmtSearchJob.setInt(++iPosition, BPConstants.BATCH_PROCESS_TYPE);
      // set the param type for the Batch Process Exceution Type
      pstmtSearchJob.setInt(++iPosition, BPConstants.BP_EXECUTION_STATUS_CODE);

      if (nType!= null )
      {
        log.debug("JobViewDAX--Adding nType " );
        pstmtSearchJob.setShort(++iPosition, nType.shortValue());
      }
      if (nStatus != null ) {
        log.debug("JobViewDAX--Adding nStatus" );
        pstmtSearchJob.setShort(++iPosition,nStatus.shortValue());
      }

      if (dtStartTime != null ) {
        log.debug("JobViewDAX--Adding Start Date " );
        pstmtSearchJob.setTimestamp(++iPosition,DateUtil.retTimestamp(dtStartTime));
      }
      if (dtEndTime != null ) {
        log.debug("JobViewDAX--Adding End Date " );
        pstmtSearchJob.setTimestamp(++iPosition,DateUtil.retTimestamp(dtEndTime));
      }
      ResultSet rsSearch = executeQuery(pstmtSearchJob);
      return XMLConverter.getXMLString(rsSearch);
    }
    catch(SQLException sqlex)
    {
      log.debug(sqlex.getMessage());
      throw new EElixirDAXException(sqlex, "BP1001");
    }
    finally
    {
      try
      {
        if(pstmtSearchJob != null)
          pstmtSearchJob.close();
      }
      catch(SQLException sqlex)
      {
        log.debug(sqlex.getMessage());
        throw new EElixirDAXException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }


  /**
    * Description getSQLString takes querytype and key and returns query
    * @return query string
    * @param a_strSQLType SQL Type i.e Select , Insert , Delete , Update
    * @param a_strKey String
    * @throws EElixirException
    */
   private String getSQLString(String a_strSQLType,String a_strKey)
           throws EElixirException
   {
        log.debug("JobViewDAX--getSQLString" );
     SqlRepositoryIF sqlRFIF = null;
     String strSql = "";
     try
     {
       sqlRFIF = BatchProcessSqlRepository.getSqlRepository();
       log.debug("JobViewDAX--getSQLString---" +sqlRFIF);
       strSql=sqlRFIF.getSQLString(a_strKey,a_strSQLType);
       log.debug("JobViewDAX--getSQLString---" +strSql);
     }
     catch(EElixirException eex)
     {
//        BP1002=Could not Get SQL String
       log.debug("JobViewDAX--sql ex"+ eex);
       log.debug(eex.getMessage());
       throw new EElixirException(eex,"BP1002"); // could not get sql string
     }
     return strSql;
   }

}// end of class



