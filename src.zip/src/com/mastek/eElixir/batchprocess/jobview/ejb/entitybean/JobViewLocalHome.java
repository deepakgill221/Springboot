package com.mastek.eElixir.batchprocess.jobview.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.batchprocess.jobview.util.JobViewResult;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 * <p>Title: JobViewLocalHome</p>
 * <p>Description: This is the local home interface JobView EJB</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * <p>Date 03/06/2003
 * @author Heena Jain
 * @version 1.0
 */
public interface JobViewLocalHome extends EJBHome
{

  /**
   * Called by the client to find an EJB bean instance, usually find by primary
   * key
   * @throws javax.ejb.FinderException
   */
  public JobViewLocal findByPrimaryKey(JobViewPK a_oJobViewPK)
      throws RemoteException, FinderException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public JobViewLocal create() throws RemoteException, CreateException,  EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching
   * pair in the bean class
   * @param a_oJobViewResult the JobViewResult object
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public JobViewLocal create(JobViewResult a_oJobViewResult)
          throws RemoteException, CreateException,  EElixirException;

  public String getJobView(JobViewResult a_oResultObject)
            throws RemoteException, EElixirException;
}