/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME		: Batch Process
 *  FILENAME		: JobViewSLEJB.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 03/06/2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.batchprocess.jobview.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.batchprocess.jobview.dax.JobViewDAX;
import com.mastek.eElixir.batchprocess.jobview.ejb.entitybean.JobViewLocal;
import com.mastek.eElixir.batchprocess.jobview.ejb.entitybean.JobViewLocalHome;
import com.mastek.eElixir.batchprocess.jobview.ejb.entitybean.JobViewPK;
import com.mastek.eElixir.batchprocess.jobview.util.JobViewResult;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.exception.EElixirFinderException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.EJBHomeFactoryLocal;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: eElixir</p>
 * <p>Description: This JobViewSLEJB session bean acts as an interface for the
 *  JobView Entity bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 */

public class JobViewSLEJB implements SessionBean
{

    /**
     * Constructor of the JobViewSLEJB class
     */
    public JobViewSLEJB    ()
    {

    }

    /**
     * Called by the container to create a session bean instance. Its parameters typically
     * contain the information the client uses to customize the bean instance for its use.
     * It requires a matching pair in the bean class and its home interface.
     * @throws EElixirException
     * @throws CreateException
     */
    public void ejbCreate    () throws RemoteException, CreateException,  EElixirException
    {

    }

    /**
     * A container invokes this method before it ends the life of the session object. This
     * happens as a result of a client's invoking a remove operation, or when a container
     * decides to terminate the session object after a timeout. This method is called with
     * no transaction context.
     */
    public void ejbRemove    ()
    {

    }

    /**
     * The activate method is called when the instance is activated from its 'passive' state.
     * The instance should acquire any resource that it has released earlier in the ejbPassivate()
     * method. This method is called with no transaction context.
     */
    public void ejbActivate    ()
    {

    }

    /**
     * The passivate method is called before the instance enters the 'passive' state. The
     * instance should release any resources that it can re-acquire later in the ejbActivate()
     * method. After the passivate method completes, the instance must be in a state that
     * allows the container to use the Java Serialization protocol to externalize and store
     * away the instance's state. This method is called with no transaction context.
     */
    public void ejbPassivate    ()
    {

    }

    /**
     * Set the associated session context. The container calls this method after the instance
     * creation. The enterprise Bean instance should store the reference to the context
     * object in an instance variable. This method is called with no transaction context.
     * @param sc SessionContext
     */

    public void setSessionContext    (SessionContext sc)
    {
        this._EJBContext = sc;
    }


    public ArrayList searchJob(long a_lPrcResultSeq, long a_lBatchPrcSeq, short nType)
            throws RemoteException, FinderException, EElixirException
    {
        ArrayList alJobResult = null;
        try
        {
            log.debug("JOBVIEWSLEJB","searchJob","Start");
            log.debug("Prc Result Seq ------"+a_lPrcResultSeq);
            log.debug("Batch Seq No --------"+a_lBatchPrcSeq);
            log.debug("nTYpe ---------------"+nType);
            _oJobViewHome = getJobViewHome();
           JobViewPK oJobViewPK = new JobViewPK();
//            JobViewPK oJobViewPK = new JobViewPK(new Long(a_lPrcResultSeq),
 //                   new Short(nType),new Long(a_lBatchPrcSeq));
            oJobViewPK.setLPrcResultSeq(new Long(a_lPrcResultSeq));
            oJobViewPK.setLBatchPrcSeq(new Long(a_lBatchPrcSeq));
            oJobViewPK.setNType(new Short(nType));
            log.debug("PK object in SLEJB"+oJobViewPK);
            _oJobView = _oJobViewHome.findByPrimaryKey(oJobViewPK);
            log.debug("JOBVIEWSLEJB--Getting Result from JOBVIEW Bean");

           alJobResult = _oJobView.getJobViewResult();
           log.debug("JobViewSLEJB--Result Obtained"+ alJobResult);
           }
           catch(FinderException fe)
           {
               _EJBContext.setRollbackOnly();
               log.debug("JobViewSLEJB--FinderException " + fe);
               throw new EElixirFinderException(fe);
           }
           catch(EJBException ejbex){
               _EJBContext.setRollbackOnly();
               log.debug("JobViewSLEJB--EJBException " + ejbex);
               throw (EElixirException)ejbex.getCausedByException();
           }
           catch(EElixirException eex)
           {
               _EJBContext.setRollbackOnly();
               log.debug("JobViewSLEJB--EElixirException " + eex);
               throw eex;
           }
           return alJobResult;
    }

    /**
     * Gets the data based on the parameter of DVO
     * @param a_oResultObject Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     */
    public String searchJob(JobViewResult a_oResultObject)
            throws  RemoteException, EElixirException
    {
        try
        {
            log.debug("JobViewSLEJB--Before	Lookup of entity bean");
            _oJobViewHome = getJobViewHome();
            log.debug("JobViewSLEJB--After Lookup");
            _strXML = _oJobViewHome.getJobView(a_oResultObject);
        }
        catch(EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            Exception e= ejbex.getCausedByException();
            if (e instanceof EElixirException)
            {
                throw (EElixirException)e;
            }
            else
            {
                throw ejbex;
            }
        }
        catch(EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }

        log.debug(_strXML);
        return _strXML;
    }


    /**
     * Gets the Dax object and sets the connection on it.
     * @return JobViewDAX
     * @throws EElixirException
     */
    private JobViewDAX getDAX() throws EElixirException
    {
        JobViewDAX _oJobViewDAX = null;
        try
        {
            if(_oConnection == null || _oConnection.isClosed())
            {
                _oConnection = DBConnection.getConnection();
            }
            _oJobViewDAX = new JobViewDAX();
            _oJobViewDAX.setConnection(_oConnection);
        }
        catch(SQLException sqlEx)
        {
            throw new EElixirException(sqlEx, sqlEx.getMessage());
        }
        return _oJobViewDAX;
    }

    /**
     * Gets the Home object.
     * @return JobViewHome
     * @throws EElixirException
     */

    private JobViewLocalHome getJobViewHome() throws RemoteException, EElixirException
    {
        log.debug("JobViewSLEJB--Looking for JobViewLocalHome");
        EJBHomeFactoryLocal objEJBHomeFactoryLocal = EJBHomeFactoryLocal.getFactory();
        JobViewLocalHome _oJobViewLocalHome = (JobViewLocalHome)objEJBHomeFactoryLocal
                .lookUpHome(EElixirUtils.getJNDIName(Constants.BATCH_PROCESS,"JobViewLocalHome"),
                JobViewLocalHome.class);

        log.debug("JobViewSLEJB--returning JobViewLocalHome");
        return _oJobViewLocalHome;
    }



    /**
     * Attributes declaration
     */
    private Connection _oConnection = null;
    private JobViewDAX _oJobViewDAX;
    private String _strXML;
    public SessionContext _EJBContext = null;
    public JobViewLocalHome _oJobViewHome;
    private JobViewLocal _oJobView;

    private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
}