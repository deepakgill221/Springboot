package com.mastek.eElixir.batchprocess.jobview.ejb.entitybean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.mastek.eElixir.batchprocess.jobview.util.JobViewResult;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 * <p>Title: JobViewLocal</p>
 * <p>Description: This is the local interface JobViewLocal EJB</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Date 03/06/2003
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 */
public interface JobViewLocal extends EJBObject
{

    public ArrayList getJobViewResult() throws  RemoteException, EElixirException;

    public void setJobViewResult(JobViewResult a_oJobViewResult)
          throws  RemoteException, EElixirException;
}