/********************************************************************
 *
 *  PROJECT			: AMAL
 *  MODULE NAME	    : Batch Process
 *  FILENAME		: JobViewSLLocal.java
 *  AUTHOR			: Heena Jain
 *  VERSION			: 1.0
 *  CREATION DATE	: 03/06/2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.batchprocess.jobview.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;
import javax.ejb.FinderException;

import com.mastek.eElixir.batchprocess.jobview.util.JobViewResult;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This JobViewSL Local interface provides method for getting the
 *  data from JobView bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface JobViewSLLocal extends EJBObject
{
    /**
     * Gets the data based on the parameter of DVO
     * @param a_oResultObject Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     * @throws RemoteException
     */
    public String searchJob(JobViewResult a_oJobViewResult)
            throws RemoteException, EElixirException;

    public ArrayList searchJob(long a_lPrcResultSeq, long a_lBatchPrcSeq, short nType)
            throws RemoteException, FinderException, EElixirException;

}