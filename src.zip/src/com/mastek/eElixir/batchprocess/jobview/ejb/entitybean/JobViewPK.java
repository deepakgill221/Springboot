package com.mastek.eElixir.batchprocess.jobview.ejb.entitybean;
import java.io.Serializable;

/**
 * <p>Title: JobViewPK</p>
 * <p>Description: Primary key object for the JobViewEJB</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Date 03/06/2003
 * <p>Company: Mastek Ltd</p>
 * @author Heena Jain
 * @version 1.0
 */
public class JobViewPK implements Serializable
{
  /**
   * public no argument constructor
   */
  public JobViewPK()
  {
  }

  /**
   * Constructor with three arguments
   * @param a_olBenSeqNbr the Long benefit sequence number
   * @param a_olBenAdvSeqNbr the Long benefit detail number
   */
  public JobViewPK(Long a_olPrcResultSeq, Short a_onType, Long a_olBatchPrcSeq)
  {
      System.out.println("JOBVIEWPK------------");
      this.lPrcResultSeq = a_olPrcResultSeq;
      this.lBatchPrcSeq = a_olBatchPrcSeq;
      this.nType = a_onType;
      System.out.println("JOBVIEWPK lPrcResultSeq---"+lPrcResultSeq);
      System.out.println("JOBVIEWPK lBatchPrcSeq---"+lBatchPrcSeq);
      System.out.println("JOBVIEWPK nType---"+nType);

  }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode()
  {
    int iHashCode = 0;

    if(this.lPrcResultSeq != null && this.lBatchPrcSeq != null && this.nType != null)
    {
        iHashCode = (this.lPrcResultSeq.hashCode()) +
                    (this.lBatchPrcSeq.hashCode())+
                    (this.nType.hashCode());
    }

    return iHashCode;

  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * obj) method is unspecified.
   * @return boolean
   */
  public boolean equals(Object a_obj)
  {
    JobViewPK oJobViewPK = null;
    boolean bEqual = false;

    if(a_obj != null)
    {
        if(a_obj instanceof JobViewPK)
        {
            oJobViewPK = (JobViewPK) a_obj;
            if(this.lPrcResultSeq != null && oJobViewPK.getLPrcResultSeq() != null &&
               this.lBatchPrcSeq != null && oJobViewPK.getLBatchPrcSeq() != null &&
               this.nType != null && oJobViewPK.getNType() != null &&
               this.lPrcResultSeq.longValue() == oJobViewPK.getLPrcResultSeq().longValue() &&
               this.lBatchPrcSeq.longValue() == oJobViewPK.getLBatchPrcSeq().longValue() &&
               this.nType.shortValue() == oJobViewPK.getNType().shortValue()
               )
            {
                bEqual = true;
            }
        }
    }
    return bEqual;
  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public java.lang.String toString    ()
  {
    return lPrcResultSeq+".."+lBatchPrcSeq +".."+nType;
  }

    public Long getLBatchPrcSeq() {
        return lBatchPrcSeq;
    }
    public Long getLPrcResultSeq() {
        return lPrcResultSeq;
    }
    public Short getNType() {
        return nType;
    }
    public void setLBatchPrcSeq(Long lBatchPrcSeq) {
        this.lBatchPrcSeq = lBatchPrcSeq;
    }
    public void setLPrcResultSeq(Long lPrcResultSeq) {
        this.lPrcResultSeq = lPrcResultSeq;
    }
    public void setNType(Short nType) {
        this.nType = nType;
    }




  private Long lPrcResultSeq;
  private Short nType;
  private Long lBatchPrcSeq;

}