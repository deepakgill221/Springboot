/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch Process
*  FILENAME			: JobViewListSearch.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 03/06/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1      20/06/2003     Heena Jain    Changed for timestamp
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get JobViewListSearch is the Action Class for Getting a list of
 * Jobs,depending upon the search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       03/06/2003
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.jobview.action;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.jobview.util.JobViewResult;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;


public class JobViewListSearch extends BPAction
{
  private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);

  /**
   * Constructor of the JobViewListSearch class
   */
  public JobViewListSearch()
  {

  }

  /**
   * This method uses the search data and to populate Benefit
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    JobViewResult jobViewResult = null;
    String result =null;
    try
    {
        log.debug("JobViewListSearch","process","Start of method");
        jobViewResult = new JobViewResult();
        BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);

      String nType          = a_oRequest.getParameter("nType");
      log.debug("nType ::: "+nType);
      String nStatus        = a_oRequest.getParameter("nStatus");
      log.debug("nStatus--"+nStatus);
      String dtStartTime    = a_oRequest.getParameter("dtStartTime");
      log.debug("dtStartTime--"+dtStartTime);
      String dtEndTime      = a_oRequest.getParameter("dtEndTime");
      log.debug("dtEndTime---"+dtEndTime);

      if(nType != null && (!nType.equals("")))
      {
        jobViewResult.setNType(new Short(nType));
      }
      else
      {
          jobViewResult.setNType(null);
      }

      if(nStatus != null && (!nStatus.equals("")))
      {
        jobViewResult.setNStatus(new Short(nStatus));
      }
      else
      {
          jobViewResult.setNStatus(null);
      }

      if(dtStartTime != null && (!dtStartTime.equals("")))
      {
        jobViewResult.setDtStartTime(DateUtil.retGCDate(dtStartTime));
      }
      else
      {
          jobViewResult.setDtStartTime(null);
      }

      if(dtEndTime != null && (!dtEndTime.equals("")))
      {
        jobViewResult.setDtEndTime(DateUtil.retGCDate(dtEndTime));
      }
      else
      {
          jobViewResult.setDtEndTime(null);
      }
      log.debug("Before calling the search method");
      /* Modified by Pravin Boga to retain the search criteria */
      result = remoteBPSL.searchJob(jobViewResult);
      jobViewResult.setXMLString(result);
      log.debug("JobViewListSearch--result accessed");
      setResult(jobViewResult);
      log.debug("JobViewListSearch--result is set");
    }
    catch(RemoteException rex)
    {
        //BP1001=The system was unable to search jobs based on the search criteria.
        log.fatal("jobViewListSearch","process",rex);
        throw new EElixirException("BP1001");
    }
    catch(EElixirException eex)
    {
        a_oRequest.setAttribute("ResultObject",result);
        log.fatal("JobViewListSearch","process",eex);
        throw eex;
    }
  }

}