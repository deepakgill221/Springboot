/********************************************************************
*
*  PROJECT			: AMAL
*  MODULE NAME		: Batch Process
*  FILENAME			: JobViewSearch.java
*  AUTHOR			: Heena Jain
*  VERSION			: 1.0
*  CREATION DATE	: 4/6/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Get JobViewSearch is the Action Class for Getting a JobView Detail,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       04/06/2003
 * @author    Heena Jain
 * @version 1.0
 */

package com.mastek.eElixir.batchprocess.jobview.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.batchprocess.ejb.sessionbean.BatchProcessSL;
import com.mastek.eElixir.batchprocess.util.BPAction;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
//import com.mastek.eElixir.common.helper.UserObject;

public class JobViewSearch extends BPAction
{
  private Logger log = Logger.getInstance(Constants.BATCH_PROCESS_LOG);
  /**
   * Constructor of the JobViewSearch class
   */
  public JobViewSearch()
  {

  }


  /**
   * Uses the unique id of JobView and gets the detail for that JobView.
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ArrayList alJobViewResult = null;

    try
    {
       BatchProcessSL remoteBPSL = getBatchProcessSL(a_oRequest);
       long lPrcResultSeq = Long.parseLong(a_oRequest.getParameter("lPrcResultSeq"));
       long lBatchPrcSeq = Long.parseLong(a_oRequest.getParameter("lBatchPrcSeq"));
       short nType = Short.parseShort(a_oRequest.getParameter("nType"));
       log.debug("Primary Key Value is :"+lPrcResultSeq);
       log.debug("Ntype Value is :"+nType);

       alJobViewResult = remoteBPSL.searchJob(lPrcResultSeq,lBatchPrcSeq, nType);
       log.debug("JobViewSearch--result accessed");

       setResult(alJobViewResult);
       log.debug("JobViewSearch--result is set");
    }
    catch(RemoteException rex)
    {
        log.debug("RemoteException in Action :"+rex);
      throw new EElixirException(rex, "BP1005");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "BP1004");
    }
  }
}