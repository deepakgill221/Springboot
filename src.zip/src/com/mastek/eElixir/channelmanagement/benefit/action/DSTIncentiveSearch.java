/********************************************************************
*
*
*  PROJECT			: MNYL
*  MODULE NAME		: MY AGENT
*  FILENAME			: DSTIncentiveSearch.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE	: Jan 29, 2009
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004 
*  SPEC VER.		:	1.0
*  CODE TAG			:ANUP_DST_Incentive_April_REL_Start
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * DSTIncentiveSearch.java is the action class to select 
 * the DSTIncentive Details for the OtherBenefit Program
 * Created on Jan 29, 2009
 * @author Anup Kumar
 * Copyright (c) 2004 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class DSTIncentiveSearch extends Action
 {
     private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     /**
      * Constructor of the GetBenefitParameter class
      */
     public DSTIncentiveSearch()
     {
     }
     /**
      * This method makes a remote call to the Session bean which in turn makes a
      * call to all other ejb bean and creates a record and populates the DVO
      * @param a_oRequest HttpServletRequest object.
      * @throws EElixirException
      */
     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         ArrayList alDSTDetails = null;
         try
 		{
            long lBonusHdrSeqNbr = Long.parseLong(a_oRequest.getParameter("lBonusHdrSeqNbr"));
 			CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
 			alDSTDetails = remoteCHMSL.searchPersReduction(lBonusHdrSeqNbr);
 		    setResult(alDSTDetails);
 		   
 		}
 	    catch(RemoteException rex)
 	    {
 	      a_oRequest.setAttribute("ResultObject", alDSTDetails);
 	      throw new EElixirException(rex, "P1006");
 	    }
 	    catch(CreateException cex)
 	    {
 	      a_oRequest.setAttribute("ResultObject", alDSTDetails);
 	      throw new EElixirException(cex, "P1007");
 	    }
 	    catch (FinderException fex)
 	    {
 	      a_oRequest.setAttribute("ResultObject", alDSTDetails);
 	      throw new EElixirException(fex, "P9002");
 	    }
 		catch(EElixirException eex)
 		{
 			throw eex;
 		}
     }
 }
