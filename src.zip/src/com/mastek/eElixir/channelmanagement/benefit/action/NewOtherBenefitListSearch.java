/********************************************************************
*  PROJECT			: MNYL
*  MODULE NAME		: My Agent
*  FILENAME			: NewOtherBenefitListSearch.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE    : September 13, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2004.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * NewOtherBenefitListSearch is the Action Class for Getting jsp page for first time when the 
 * menu link is clicked
 * Copyright (c) 2004 Mastek Ltd
 * Date       13/09/2004
 * @author    Sandeep Bangera
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.benefit.action;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.BonusResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Log;
import com.mastek.eElixir.common.util.Logger;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class NewOtherBenefitListSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor of the NewBenefitListSearch class
   */
  public NewOtherBenefitListSearch()
  {

  }

  /**
   * This is a dummy method, used only when page is loaded first time
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
	  //Added By Himanshu: for DR CR functionality
	  String strValidVal = null;//Himanshu
      CHMSL oRemoteCHMSL = null;//Himanshu
      HttpSession session = a_oRequest.getSession(); //Himanshu
	 
    try
    {
      MenuAccessLog.createMenuAccessLog(a_oRequest);
      a_oRequest.setAttribute("actiontype",DataConstants.ACTION_ADD);
      //Code Added By Himanshu : ACS :Inclusion in ACS
      
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      strValidVal = remoteCHMSL.searchvalidValue();
     log.debug("---Actionclass: strValidVal==" +strValidVal);
  	session.setAttribute("DRCRAcctCode",strValidVal);
      
  	log.debug("NewBonusListSearch "+ session.getAttribute("DRCRAcctCode"));
      
   
    }
    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
  }
}
