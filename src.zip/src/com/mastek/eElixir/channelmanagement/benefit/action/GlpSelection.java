/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: GlpSelection.java
*  AUTHOR			: Amid P Sahu
*  VERSION			: 1.0
*  CREATION DATE	: Dec 23,2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3
*********************************************************************/



/**
 * DesignationExclusionSelection is the action class to select 
 * the DesignationExclusion that are applicable for the OtherBenefit Program
 * Created on Dec 23,2008
 * @author Amid P Sahu
 * Copyright (c) 2008 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class GlpSelection extends Action
 {
     private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     public GlpSelection()
     {
     }

     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         
     }
 }
