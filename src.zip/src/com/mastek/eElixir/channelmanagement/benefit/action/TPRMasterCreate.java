/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME				: TPRMasterCreate.java
 *  AUTHOR					: Anup Kumar
 *  VERSION					: 1.0
 *  CREATION DATE		    : June 30, 2010
 *  COMPANY				    : Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2010.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * Anup_AugRel2010_FSD_TPR_V1.3
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class TPRMasterCreate extends Action {

	/**
	 * Constructor
	 */

	public TPRMasterCreate() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :
	 *            ResultObject object.
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		log.entry("TPRMasterCreate","process","entry");	
		CHMSL remoteCHMSL = null;
		try {
			setTPRMasterResult(request);
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			remoteCHMSL.createTPRMaster(_oTPRList);
			_oTPRList = remoteCHMSL.searchChannelTPRTypes(request.getParameter("cChannelType"));
			request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
			setResult(_oTPRList);

		} catch (FinderException fex) {
			request.setAttribute("actiontype", DataConstants.ACTION_CREATE);
			request.setAttribute("ResultObject", _oTPRResult);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("actiontype", DataConstants.ACTION_CREATE);
			request.setAttribute("ResultObject", _oTPRResult);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("actiontype", DataConstants.ACTION_CREATE);
			request.setAttribute("ResultObject", _oTPRResult);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {			
			request.setAttribute("actiontype", DataConstants.ACTION_CREATE);
			request.setAttribute("ResultObject", _oTPRResult);
			throw eLex;
		}

	}

	private void setTPRMasterResult(HttpServletRequest a_oRequest) {
		String strTPRType[] = a_oRequest.getParameterValues("strTPRType");
		String strTPRDesc[] = a_oRequest.getParameterValues("strTPRDesc");
		String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
		String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");
		String cChannelType = a_oRequest.getParameter("cChannelType");
		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String) session.getAttribute("username");
		String SeqNumb[] = a_oRequest.getParameterValues("SeqNumb");
		//Alex_TPR_SIT_FIX 3 Aug 2010 Start	
		String strScreen = null;
		if(a_oRequest.getParameterValues("screen")!=null){
			strScreen = a_oRequest.getParameter("screen");
		}
		//Alex_TPR_SIT_FIX 3 Aug 2010 End	

		if (statusFlag != null) {
			for (int i = 0; i < statusFlag.length; i++) {
				if (!(statusFlag[i].equals(DataConstants.CLEAR_MODE))) {
					_oTPRResult = new TPRResult();					
					if (SeqNumb[i] != null && !SeqNumb[i].trim().equals("")) {
						_oTPRResult.setTPRHdrSeqNbr(new Long(SeqNumb[i]));

					} else {
						_oTPRResult.setTPRHdrSeqNbr(null);
					}
					
					_oTPRResult.setChannelType(cChannelType);
					_oTPRResult.setTPRType(strTPRType[i]);
					_oTPRResult.setTPRDescription(strTPRDesc[i]);
					_oTPRResult.setStatusFlag(statusFlag[i]);
					if (dtUpdated[i] != null && !dtUpdated[i].trim().equals("")) {
						_oTPRResult.setTsDtUpdated(Timestamp
								.valueOf(dtUpdated[i]));
					}
					_oTPRResult.setUserId(_strUserId);
					//Alex_TPR_SIT_FIX 3 Aug 2010 Start	
					_oTPRResult.set_strTPRScreen(strScreen);
					//Alex_TPR_SIT_FIX 3 Aug 2010 End	
					log.debug("show all parameter: setChannelType-"
							+ cChannelType + " TPR type-" + strTPRType[i]
							+ "TPR desc-" + strTPRDesc[i] + " statusFlag-"
							+ statusFlag[i] + " dtUpdated-" + dtUpdated[i]
							+ " strUserId- " + _strUserId);
					_oTPRList.add(_oTPRResult);

				}
			}
		}
	}

	// class level variable declarations.
	ArrayList _oTPRList = new ArrayList();

	TPRResult _oTPRResult = null;

	ArrayList _oTPRCriteriaList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
