/********************************************************************
*
**
*  PROJECT			: MNYL
*  MODULE NAME		: MY AGENT
*  FILENAME			: DSTIncentiveUpdate.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE	: Jan 29, 2009
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004 
*  SPEC VER.		:	1.0
*  CODE TAG			:ANUP_DST_Incentive_April_REL_Start
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * DSTIncentiveUpdate.java is the action class to select 
 * the DSTIncentive Details for the OtherBenefit Program
 * Created on Jan 29, 2009
 * @author Anup Kumar
 * Copyright (c) 2004 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitAgentDetail;
import com.mastek.eElixir.channelmanagement.benefit.util.PerReductionResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class DSTIncentiveUpdate extends Action
 {
     private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     /**
      * Constructor of the GetBenefitParameter class
      */
     public DSTIncentiveUpdate()
     {
     }
     /**
      * This method makes a remote call to the Session bean which in turn makes a
      * call to all other ejb bean and creates a record and populates the DVO
      * @param a_oRequest HttpServletRequest object.
      * @throws EElixirException
      */
     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
    	 PerReductionResult oPerReductionResult = null;
    	 ArrayList alDSTDetails = new ArrayList();
         Long lBonusHdrSeqNbr = null;
         HttpSession session = a_oRequest.getSession();
		 String strUserId = (String) session.getAttribute("username");
         try
         {
          String[] strPerstType = a_oRequest.getParameterValues("strPerstType1");
          String[] strPerstTarget = a_oRequest.getParameterValues("strPerstTarget1");
          String[] dPerstFrom = a_oRequest.getParameterValues("dPerstFrom");
          String[] dPerstTo = a_oRequest.getParameterValues("dPerstTo");
          String[] dPerstPerc = a_oRequest.getParameterValues("dPerstPerc");
          String[] strStatusFlag = a_oRequest.getParameterValues("strStatusFlag");
          String[] lIbPercSeqNbr = a_oRequest.getParameterValues("PKValueNum");
          if(a_oRequest.getParameter("lBonusHdrSeqNbr") != null)
          {
              lBonusHdrSeqNbr = new Long(a_oRequest.getParameter("lBonusHdrSeqNbr"));
          }
          
          if (dPerstFrom != null)
            {
                for (int i = 0; i < dPerstFrom.length; i++)
                {
                    if (!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE))
                    {
                    	oPerReductionResult = new PerReductionResult();
                    	
                    	oPerReductionResult.setPersistencyType(strPerstType[0]);
                    
                    	oPerReductionResult.setTargetValuePerc(new Double(strPerstTarget[0]));
        
                    	oPerReductionResult.setFromPerc(new Double(dPerstFrom[i]));
                
                    	oPerReductionResult.setToPerc(new Double(dPerstTo[i]));
                   
                    	oPerReductionResult.setPercentagePerc(new Double(dPerstPerc[i]));
                    
                    	oPerReductionResult.setStatusFlag(strStatusFlag[i]);                    	
                    	oPerReductionResult.setUserId(strUserId);
                    	
                        if (!strStatusFlag[i].equals(DataConstants.INSERT_MODE))
                        {
                  
                        	oPerReductionResult.setPercSeqNbr(new Long(lIbPercSeqNbr[i]));
                        }
                        alDSTDetails.add(oPerReductionResult);
                    }

                }
                CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
                remoteCHMSL.updatePerReductionDetails(alDSTDetails, lBonusHdrSeqNbr);

                alDSTDetails = remoteCHMSL.searchPersReduction(lBonusHdrSeqNbr.longValue());
                setResult(alDSTDetails);
            }
         }
         catch(RemoteException rex)
         {
           a_oRequest.setAttribute("ResultObject", alDSTDetails);
           throw new EElixirException(rex, "P1006");
         }
         catch(CreateException cex)
         {
           a_oRequest.setAttribute("ResultObject", alDSTDetails);
           throw new EElixirException(cex, "P1007");
         }
         catch (FinderException fex)
         {
           a_oRequest.setAttribute("ResultObject", alDSTDetails);
           throw new EElixirException(fex, "P9002");
         }
         catch(EElixirException eex)
         {
           log.debug("BenefitCreate--Inside catch of EElixir exception in process of BenefitCreate");
           a_oRequest.setAttribute("ResultObject", alDSTDetails);
           throw eex;
         }
     }
 }
