/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : MY AGENT	
*  FILENAME			: OtherBenefitSearch.java
*  AUTHOR			: SANDEEP BANGERA
*  VERSION			: 1.0
*  CREATION DATE	: SEPTEMBER 14, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * OtherBenefitSearch is the Action Class for Getting the Data for Update mode based on the
 * hyperlink clicked in the list search page
 * Copyright (c) 2004 Mastek Ltd
 * Date       14/09/2004
 * @author    Sandeep Bangera
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
public class OtherBenefitSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor of the BenefitSearch class
   */
  public OtherBenefitSearch()
  {

  }


  /**
   * Uses the unique id of Benefit and gets the detail for that Benefit.
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
	OtherBenefitResult oOtherBenefitResult = null;
	try{

	  CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
	  long lBonusHdrSeqNbr = Long.parseLong(a_oRequest.getParameter("strPKey"));
	  oOtherBenefitResult = remoteCHMSL.searchOtherBenefit(lBonusHdrSeqNbr);
	  log.debug("BenefitSearch--result accessed");
	  a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
	  setResult(oOtherBenefitResult);
	  log.debug("BenefitSearch--result is set");
	}
	catch(RemoteException rex)
	{
	  throw new EElixirException(rex, "P1006");
	}
	catch(CreateException cex)
	{
	  throw new EElixirException(cex, "P1007");
	}
	catch(FinderException fex)
	{
	  throw new EElixirException(fex, "P9002");
	}
  }
}
