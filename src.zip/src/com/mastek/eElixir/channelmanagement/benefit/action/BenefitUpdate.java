/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitUpdate.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * BenefitUpdate is the Action Class for updating a Benefit.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.benefit.dvo.BenefitCalculationCriteria;
import com.mastek.eElixir.channelmanagement.benefit.dvo.BenefitEligibilityCriteria;
import com.mastek.eElixir.channelmanagement.benefit.util.BenefitFetch;
import com.mastek.eElixir.channelmanagement.benefit.util.BenefitResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class BenefitUpdate extends Action
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the BenefitUpdate class
   */
  public BenefitUpdate()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    BenefitResult oBenefitResult = null;
    BenefitCalculationCriteria oBenefitCalculationCriteria = null;
    BenefitEligibilityCriteria oBenefitEligibilityCriteria = null;
    BenefitFetch oBenefitFetch = new BenefitFetch();
    CHMSL remoteCHMSL = null;
    try{
      String dtUpdated = a_oRequest.getParameter("dtUpdated");
      remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      log.debug("BenefitUpdate--Before fetching parameters");
      oBenefitResult = oBenefitFetch.fetchBenefit(a_oRequest);
      oBenefitResult.setBenSeqNbr(new Long(a_oRequest.getParameter("lBenSeqNbr").trim()));
      if (dtUpdated != null && !dtUpdated.trim().equals(""))
      {
        oBenefitResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated));
      }
      log.debug("BenefitUpdate--After fetching parameters");

      log.debug("BenefitUpdate--before create Benefit");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      remoteCHMSL.updateBenefit(oBenefitResult);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      oBenefitResult = remoteCHMSL.searchBenefit(oBenefitResult.getBenSeqNbr().longValue());
      setResult(oBenefitResult);
      log.debug("BenefitUpdate--result accessed");

    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oBenefitResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oBenefitResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", oBenefitResult);
      throw new EElixirException(fex, "P9002");
    }
    catch(EElixirException eex)
    {
      log.debug("BenefitUpdate--Inside catch of EElixir exception in process of BenefitUpdate");
      if (eex.getCustomErrorCode().equalsIgnoreCase("P1100"))
      {
        try
        {
             oBenefitResult = remoteCHMSL.searchBenefit(oBenefitResult.getBenSeqNbr().longValue());
        }
        catch(RemoteException rex)
        {
          a_oRequest.setAttribute("ResultObject", oBenefitResult);
          throw new EElixirException(rex, "P1006");
        }
        catch(FinderException cex)
        {
          a_oRequest.setAttribute("ResultObject", oBenefitResult);
          throw new EElixirException(cex, "P1007");
        }
      }
      a_oRequest.setAttribute("ResultObject", oBenefitResult);
      throw eex;
    }
  }

}