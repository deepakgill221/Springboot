/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME					: TPRListSearch.java
*  AUTHOR					: Anup Kumar
*  VERSION					: 1.0
*  CREATION DATE		    : May 28, 2010
*  COMPANY				    : Mastek Ltd.
*  COPYRIGHT			    : COPYRIGHT (C) 2010.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*Anup_AugRel2010_FSD_TPR_V1.3
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;




/**
 * <p>Title: eElixir</p>
 * <p>Description: Action Class for retrieving the Benefit </p>
 * @author Anup Kumar
 * @version 1.0
 */

//Anup_AugRel2010_FSD_TPR_V1.3

public class TPRListSearch extends Action
{

  /**
   * @Constructor
   */
  public TPRListSearch(){
  }

  /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean and get the Benefit ArrayList Object
   * @param: request - Request object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest request)  throws EElixirException
  {
	log.debug("TPRListSearch process starts");
    ArrayList _oTPRList = null;
    request.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);
    try{

    	CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
    	String cChannelType = request.getParameter("cChannelType");    	
        _oTPRList = remoteCHMSL.searchChannelTPRTypes(cChannelType);
        setResult(_oTPRList);
        request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
        log.debug("TPRListSearch process end");
    }
    catch(RemoteException rex)
    {
      request.setAttribute("ResultObject", _oTPRList);
      throw new EElixirException(rex, "P1006");
    }
   catch(FinderException rex)
    {
      request.setAttribute("ResultObject", _oTPRList);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      request.setAttribute("ResultObject", _oTPRList);
      throw new EElixirException(cex, "P1007");
    }

    catch(EElixirException cex)
    {
      request.setAttribute("ResultObject", _oTPRList);
      throw cex;
    }


  }
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}
