/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: GetApplicableAgentAgency.java
*  AUTHOR			: Jimmy K G
*  VERSION			: 1.0
*  CREATION DATE	: Jan 24, 2007
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2007.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * GetApplicableAgentAgency is the action class to select 
 * the agents or agencys for the OtherBenefit bonus  Program
 * Created on Jan 24, 2007
 * @author Jimmy K G
 * Copyright (c) 2007 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;


 public class GetApplicableAgentAgency extends Action
 {
        
     /**
      * Constructor of the GetApplicableAgentAgency class
      */
     public GetApplicableAgentAgency()
     {
     }
     /**
      * This method makes a remote call to the Session bean which in turn makes a
      * call to all other ejb bean and creates a record and populates the DVO
      * @param a_oRequest HttpServletRequest object.
      * @throws EElixirException
      */
     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         
     }
 }
