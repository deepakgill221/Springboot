/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: DesignationSelection.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: September 17, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * DesignationSelection is the action class to select 
 * the designations that are applicable for the OtherBenefit Program
 * Created on Sep 17, 2004
 * @author Sandeep Bangera
 * Copyright (c) 2004 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class DesignationSelection extends Action
 {
     private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     public DesignationSelection()
     {
     }

     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         
     }
 }
