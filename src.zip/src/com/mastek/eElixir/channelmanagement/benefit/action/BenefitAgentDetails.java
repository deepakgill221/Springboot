/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: BenefitAgentDetails.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: September 17, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * BenefitAgentDetails is the action class to select 
 * the Agents for the OtherBenefit Program
 * Created on Sep 17, 2004
 * @author Sandeep Bangera
 * Copyright (c) 2004 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class BenefitAgentDetails extends Action
 {
     private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     /**
      * Constructor of the GetBenefitParameter class
      */
     public BenefitAgentDetails()
     {
     }
     /**
      * This method makes a remote call to the Session bean which in turn makes a
      * call to all other ejb bean and creates a record and populates the DVO
      * @param a_oRequest HttpServletRequest object.
      * @throws EElixirException
      */
     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         ArrayList alAgentDetails = null;
         try
 		{
            long lBonusHdrSeqNbr = Long.parseLong(a_oRequest.getParameter("lBonusHdrSeqNbr"));
 			CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
 			alAgentDetails = remoteCHMSL.searchOtherBenefitAgentDetails(lBonusHdrSeqNbr);
 		    setResult(alAgentDetails);
 		    log.debug("BenefitCreate--result set exiting method process");
 		}
 	    catch(RemoteException rex)
 	    {
 	      a_oRequest.setAttribute("ResultObject", alAgentDetails);
 	      throw new EElixirException(rex, "P1006");
 	    }
 	    catch(CreateException cex)
 	    {
 	      a_oRequest.setAttribute("ResultObject", alAgentDetails);
 	      throw new EElixirException(cex, "P1007");
 	    }
 	    catch (FinderException fex)
 	    {
 	      a_oRequest.setAttribute("ResultObject", alAgentDetails);
 	      throw new EElixirException(fex, "P9002");
 	    }
 		catch(EElixirException eex)
 		{
 			throw eex;
 		}
     }
 }
