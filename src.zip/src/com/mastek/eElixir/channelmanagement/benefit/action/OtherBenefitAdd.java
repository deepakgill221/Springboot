/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : MY AGENT
*  FILENAME			: OtherBenefitAdd.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: Sept 14, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2004.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.benefit.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

/**
 * OtherBenefitAdd is the Entry class for Creating Other Benefit
 * Copyright (c) 2004 Mastek Ltd
 * Date       14/09/2004
 * @author    Sandeep Bangera
 * @version 1.0
 */
public class OtherBenefitAdd extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the OtherBenefitAdd class
   */
  public OtherBenefitAdd()
  {

  }


  /**
   * This is a dummy method, used only when entry page is loaded first time
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
  }
}
