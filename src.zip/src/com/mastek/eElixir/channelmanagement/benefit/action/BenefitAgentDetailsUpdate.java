/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: BenefitAgentDetailsUpdate.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: September 17, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * BenefitAgentDetailsUpdate is the action class to select 
 * the Agents for the OtherBenefit Program
 * Created on Sep 17, 2004
 * @author Sandeep Bangera
 * Copyright (c) 2004 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitAgentDetail;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class BenefitAgentDetailsUpdate extends Action
 {
     private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     /**
      * Constructor of the GetBenefitParameter class
      */
     public BenefitAgentDetailsUpdate()
     {
     }
     /**
      * This method makes a remote call to the Session bean which in turn makes a
      * call to all other ejb bean and creates a record and populates the DVO
      * @param a_oRequest HttpServletRequest object.
      * @throws EElixirException
      */
     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         OtherBenefitAgentDetail oOtherBenefitAgentDetail = null;
         ArrayList alAgentDetails = new ArrayList();
         Long lBonusHdrSeqNbr = null;
         HttpSession session = a_oRequest.getSession();
		 String strUserId = (String) session.getAttribute("username");
         try
         {
          String[] strAgentcd = a_oRequest.getParameterValues("strAgentCd");
          String[] strAgentName = a_oRequest.getParameterValues("strAgentName");
          String[] dTargetValue = a_oRequest.getParameterValues("dTargetValue");
          String[] strStatusFlag = a_oRequest.getParameterValues("strStatusFlag");
          String[] lIbTargetSeqNbr = a_oRequest.getParameterValues("PKValueNum");
          if(a_oRequest.getParameter("lBonusHdrSeqNbr") != null)
          {
              lBonusHdrSeqNbr = new Long(a_oRequest.getParameter("lBonusHdrSeqNbr"));
          }
          
          if (strAgentcd != null)
            {
                for (int i = 0; i < strAgentcd.length; i++)
                {
                    if (!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE))
                    {
                        oOtherBenefitAgentDetail = new OtherBenefitAgentDetail();
                        oOtherBenefitAgentDetail.setAgentCd(strAgentcd[i]);
                        oOtherBenefitAgentDetail.setAgentName(strAgentName[i]);
                        oOtherBenefitAgentDetail.setTargetValue(new Double(dTargetValue[i]));
                        oOtherBenefitAgentDetail.setStatusFlag(strStatusFlag[i]);
                        oOtherBenefitAgentDetail.setUserId(strUserId);
                        if (!strStatusFlag[i].equals(DataConstants.INSERT_MODE))
                        {
                            oOtherBenefitAgentDetail.setTargetAgtSeqNbr(new Long(lIbTargetSeqNbr[i]));
                        }
                        alAgentDetails.add(oOtherBenefitAgentDetail);
                    }

                }
                CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
                remoteCHMSL.updateAgentTargetDetails(alAgentDetails, lBonusHdrSeqNbr);

                alAgentDetails = remoteCHMSL.searchOtherBenefitAgentDetails(lBonusHdrSeqNbr.longValue());
                setResult(alAgentDetails);
            }
         }
         catch(RemoteException rex)
         {
           a_oRequest.setAttribute("ResultObject", alAgentDetails);
           throw new EElixirException(rex, "P1006");
         }
         catch(CreateException cex)
         {
           a_oRequest.setAttribute("ResultObject", alAgentDetails);
           throw new EElixirException(cex, "P1007");
         }
         catch (FinderException fex)
         {
           a_oRequest.setAttribute("ResultObject", alAgentDetails);
           throw new EElixirException(fex, "P9002");
         }
         catch(EElixirException eex)
         {
           log.debug("BenefitCreate--Inside catch of EElixir exception in process of BenefitCreate");
           a_oRequest.setAttribute("ResultObject", alAgentDetails);
           throw eex;
         }
     }
 }
