/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: GetBenefitParameter.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: September 17, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * GetBenefitParameter is the action class to select 
 * the parameters for the OtherBenefit Program
 * Created on Sep 17, 2004
 * @author Sandeep Bangera
 * Copyright (c) 2004 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class GetBenefitParameter extends Action
 {
     private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     /**
      * Constructor of the GetBenefitParameter class
      */
     public GetBenefitParameter()
     {
     }
     /**
      * This method makes a remote call to the Session bean which in turn makes a
      * call to all other ejb bean and creates a record and populates the DVO
      * @param a_oRequest HttpServletRequest object.
      * @throws EElixirException
      */
     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         
     }
 }
