/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: OtherBenefitUpdate.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: September 17, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * OtherBenefitUpdate is the Action Class for creating a new Benefit.
 * Copyright (c) 2004 Mastek Ltd
 * Date       17/09/2002
 * @author    Sandeep Bangera
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitFetch;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;


public class OtherBenefitUpdate extends Action
{
	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
	
	/**
	 * Constructor of the BenefitCreate class
	*/
	public OtherBenefitUpdate()
	{
	}

  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
	public void process(HttpServletRequest a_oRequest)  throws EElixirException
	{
		OtherBenefitResult oOtherBenefitResult = null;
		OtherBenefitFetch oOtherBenefitFetch = new OtherBenefitFetch();
		try
		{
			log.debug("BenefitCreate--Before fetching parameters");
			oOtherBenefitResult = oOtherBenefitFetch.fetchOtherBenefit(a_oRequest);
			log.debug("BenefitCreate--After fetching parameters");
			
			CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			log.debug("BenefitCreate--before create Benefit");
	        remoteCHMSL.updateOtherBenefit(oOtherBenefitResult);
		    a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		    oOtherBenefitResult = remoteCHMSL.searchOtherBenefit(oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
		    setResult(oOtherBenefitResult);
		    log.debug("BenefitCreate--result set exiting method process");
		    EElixirUtils.reloadMaster(DataConstants.BASE_PARAMETER + "");
		}
	    catch(RemoteException rex)
	    {
	      a_oRequest.setAttribute("ResultObject", oOtherBenefitResult);
	      throw new EElixirException(rex, "eP1006");
	    }
	    catch(CreateException cex)
	    {
	      a_oRequest.setAttribute("ResultObject", oOtherBenefitResult);
	      throw new EElixirException(cex, "P1007");
	    }
	    catch (FinderException fex)
	    {
	      a_oRequest.setAttribute("ResultObject", oOtherBenefitResult);
	      throw new EElixirException(fex, "P9002");
	    }
		catch(EElixirException eex)
		{				
			a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);//CR_OtherBenefit_sequence_Rel8.2
			a_oRequest.setAttribute("ResultObject", oOtherBenefitResult);
			throw eex;
		}
	}	
}
