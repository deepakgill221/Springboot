/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: MY AGENT
*  FILENAME			: OtherBenefitListSearch.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: September 14, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1		01-02-2007	Jimmy K G		Added new Field strAgentCd in the Benefit Search page for Release 8.0
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get OtherBenefitListSearch is the Action Class for 
 * Getting a list of Other Benefits ,depending upon the
 * search data.
 * Copyright (c) 2004 Mastek Ltd
 * Date       14/09/2002
 * @author    Sandeep Bangera
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class OtherBenefitListSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the BenefitListSearch class
   */
  public OtherBenefitListSearch()
  {

  }

  /**
   * This method uses the search data and to populate Benefit
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    String result =null;
    try{
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

      String strBenType     = a_oRequest.getParameter("strBenType");
      String strBenDesc   = a_oRequest.getParameter("strBenDesc");
      String cChannelType = a_oRequest.getParameter("cChannelType");
      String dtStart    = a_oRequest.getParameter("dtEffFrom");
      String dtEnd      = a_oRequest.getParameter("dtEffTo");
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
      String strAgentCd      = a_oRequest.getParameter("strAgentCd");
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
      SearchData oSearchData = new SearchData();
      
      oSearchData.setTask1(strBenType);
      oSearchData.setTask2(strBenDesc);
      oSearchData.setTask3(cChannelType);
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
      oSearchData.setTask4(strAgentCd);
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
      if(!dtStart.trim().equals("")){
        oSearchData.setTaskDate1(DateUtil.retGCDate(dtStart.trim()));
      }
      
      if(!dtEnd.trim().equals("")){
        oSearchData.setTaskDate2(DateUtil.retGCDate(dtEnd.trim()));
      }
      
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);
      result = remoteCHMSL.searchOtherBenefit(oSearchData);
      setResult(result);
    }
    catch(RemoteException rex)
    {
      log.exception("OtherBenefitListSearch remote exception");
      rex.printStackTrace();
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      log.exception("OtherBenefitListSearch create exception");
      cex.printStackTrace();
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      log.exception("OtherBenefitListSearch finder exception");
      fex.printStackTrace();
      throw new EElixirException(fex, "P9002");
    }
  }


}
