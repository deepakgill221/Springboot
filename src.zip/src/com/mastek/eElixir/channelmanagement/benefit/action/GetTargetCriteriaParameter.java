/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: GetTargetCriteriaParameter.java
*  AUTHOR			: Arun
*  VERSION			: 1.0
*  CREATION DATE	: June 28, 2007
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2007.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*Arun_FSOtherBenefitsTargetTab_REL8.1 starts
*********************************************************************/



/**
 * GetTargetCriteriaParameter is the action class to select 
 * the TargetCriteriaparameters for the OtherBenefit Program
 * Created on June 28, 2007
 * @author Arun
 * Copyright (c) 2007 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class GetTargetCriteriaParameter extends Action
 {
     private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     /**
      * Constructor of the GetTargetCriteriaParameter class
      */
     public GetTargetCriteriaParameter()
     {
     }
     /**
      * This Is a Dummy Method
      * @param a_oRequest HttpServletRequest object.
      * @throws EElixirException
      */
     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         
     }
 }
