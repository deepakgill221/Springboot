/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME		: NewTPRSearch.java
 *  AUTHOR			: Anup Kumar
 *  VERSION			: 1.0
 *  CREATION DATE	: May 28, 2010
 *  
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/


package com.mastek.eElixir.channelmanagement.benefit.action;

/**
 * Called at the beginnning of TPR
 * Date   28/05/2010
 * @author Anup Mastek
 * @version 1.0
 */

//Anup_AugRel2010_FSD_TPR_V1.3


 import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;


 public class NewTPRSearch extends Action
 {

   
   public NewTPRSearch()
   {

   }

   /**
    * blank process method to follow the MVC architecture, it just makes the xsl file available to the requested jsp at the beginning
    * @param : request - Request object.
    * @throws EElixirException
    */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     try
     {
       MenuAccessLog.createMenuAccessLog(a_oRequest);
       a_oRequest.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
     }
     catch(RemoteException rex)
     {
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       throw new EElixirException(cex, "P1007");
     }
     catch(EElixirException eex)
     {
       throw eex;
     }

   }
 }