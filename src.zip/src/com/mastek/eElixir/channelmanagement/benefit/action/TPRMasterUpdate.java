/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME				: TPRMasterUpdate.java
 *  AUTHOR					: Anup Kumar
 *  VERSION					: 1.0
 *  CREATION DATE		    : June 18, 2010
 *  COMPANY				    : Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * Anup_AugRel2010_FSD_TPR_V1.3
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.benefit.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.channelmanagement.benefit.util.TPRDetailsResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

public class TPRMasterUpdate extends Action {

	/**
	 * Constructor
	 */

	public TPRMasterUpdate() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :
	 *            ResultObject object.
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		log.entry("TPRMasterUpdate","process","entry");
		
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		
		CHMSL remoteCHMSL = null;
		try {
			setTPRMasterResult(request);
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			
			remoteCHMSL.updateTPRMaster(_oTPRResult);
			
			_oTPRResult = remoteCHMSL.searchTPRMasterData(_oTPRResult.getTPRHdrSeqNbr().longValue());
			setResult(_oTPRResult);
			
		} catch (FinderException fex) {
			request.setAttribute("ResultObject", _oTPRResult);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oTPRResult);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oTPRResult);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log.debug("In TPRMasterCreate eelixir exception before setting result"
							+ eLex);
			request.setAttribute("ResultObject", _oTPRResult);
			throw eLex;
		}

	}

	private void setTPRMasterResult(HttpServletRequest a_oRequest) {
		
		log.entry("TPRMasterUpdate","setTPRMasterResult","starts");
		
		String strTPRType = a_oRequest.getParameter("strTPRType");
		String strTPRDesc = a_oRequest.getParameter("strTPRDesc");
		String cChannelType = a_oRequest.getParameter("cChannelType");		
		String lTPRHdrSeqNbr = a_oRequest.getParameter("lTPRHdrSeqNbr");
		String nFreqCal = a_oRequest.getParameter("nFreqCal");		
		String nFreqProd = a_oRequest.getParameter("nFreqProd");		
		String nVintageFrom = a_oRequest.getParameter("nVintageFrom");
		String nVintageTo = a_oRequest.getParameter("nVintageTo");			
		
		String strParamCdVal[] = a_oRequest.getParameterValues("strParamCdVal");	
		String dTargetValue[] = a_oRequest.getParameterValues("dTargetValue");
		String dtEffFrom[] = a_oRequest.getParameterValues("dtEffFrom");
		String dtEffTo[] = a_oRequest.getParameterValues("dtEffTo");
		String nIsParamAppl[] = a_oRequest.getParameterValues("nIsParamAppl");
		String lTPRDtlSeqNbr[] = a_oRequest.getParameterValues("TPRDetSeqNbr");
		String strSegmentCd[] = a_oRequest.getParameterValues("strSegmentCd");
		String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
		String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");		
		
		HttpSession session = a_oRequest.getSession();

		String _strUserId = (String) session.getAttribute("username");

		_oTPRResult = new TPRResult();
		_oTPRResult.setChannelType(cChannelType);
		_oTPRResult.setTPRType(strTPRType);

		_oTPRResult.setTPRDescription(strTPRDesc);

		_oTPRResult.setTPRHdrSeqNbr(new Long(lTPRHdrSeqNbr));
	
		

		if (nVintageFrom != null && !nVintageFrom.trim().equals("")) {
			_oTPRResult.setVintageFrom(new Long(nVintageFrom));
		} else {
			_oTPRResult.setVintageFrom(null);
		}
		
		if (nVintageTo != null && !nVintageTo.trim().equals("")) {
			_oTPRResult.setVintageTo(new Long(nVintageTo));
		} else {
			_oTPRResult.setVintageTo(null);
		}
		
		if (nFreqCal != null && !nFreqCal.trim().equals("")) {
			_oTPRResult.setFreqCal(new Short(nFreqCal));
		} else {
			_oTPRResult.setFreqCal(null);
		}
		
		
		if (nFreqProd != null && !nFreqProd.trim().equals("")) {
			_oTPRResult.setFreqProd(new Short(
					nFreqProd));
		} else {
			_oTPRResult.setFreqProd(null);
		}		
		_oTPRResult.setUserId(_strUserId);

		if (statusFlag != null) {
			for (int i = 0; i < statusFlag.length; i++) {

				if (!(statusFlag[i].equals(DataConstants.CLEAR_MODE))) {
					_oTPRDetailsResult = new TPRDetailsResult();
					
					log.debug("TPR DTL Seq Nbr"+lTPRDtlSeqNbr[i]);
					
					log.debug("TPR DTL StatusFlag"+statusFlag[i]);
					
					if (lTPRDtlSeqNbr[i] != null && !lTPRDtlSeqNbr[i].trim().equals("")) {
						_oTPRDetailsResult.setTPRDetSeqNbr(new Long(lTPRDtlSeqNbr[i]));

					} else {
						_oTPRDetailsResult.setTPRDetSeqNbr(null);
					}
					
					
					if (strParamCdVal[i] != null && !strParamCdVal[i].trim().equals("")) {
					_oTPRDetailsResult.setParamCd(strParamCdVal[i].trim());
					}else {
						_oTPRDetailsResult.setParamCd(null);
					}
					if (dTargetValue[i] != null && !dTargetValue[i].trim().equals("")) {
					_oTPRDetailsResult.setTargetValue(dTargetValue[i].trim());
					}else{
						_oTPRDetailsResult.setTargetValue(null);
					}
					if (dtEffFrom[i] != null && !dtEffFrom[i].trim().equals("")) {
					_oTPRDetailsResult.setDtEffFrom(DateUtil
							.retGCDate(dtEffFrom[i].trim()));
					}else{
						_oTPRDetailsResult.setDtEffFrom(null);
					}
					if (dtEffTo[i] != null && !dtEffTo[i].trim().equals("")) {
					_oTPRDetailsResult.setDtEffTo(DateUtil
							.retGCDate(dtEffTo[i].trim()));
					}else{
						_oTPRDetailsResult.setDtEffTo(null);
					}
					_oTPRDetailsResult.setStatusFlag(statusFlag[i]);
					
					if (nIsParamAppl[i] != null && !nIsParamAppl[i].trim().equals("")) {
					_oTPRDetailsResult.setIsParamAppl(new Short(nIsParamAppl[i]));
					}else{
						_oTPRDetailsResult.setIsParamAppl(null);
					}
					_oTPRDetailsResult.setSegmentatonCd(strSegmentCd[i]);

					if (dtUpdated[i] != null && !dtUpdated[i].trim().equals("")) {
						_oTPRDetailsResult.setTsDtUpdated(Timestamp
								.valueOf(dtUpdated[i]));
					}

					_oTPRCriteriaList.add(_oTPRDetailsResult);

				}
			}
		}
		_oTPRResult.setTPRDetails(_oTPRCriteriaList);		
	}
	
	

	// class level variable declarations.

	TPRResult _oTPRResult = null;

	TPRDetailsResult _oTPRDetailsResult = null;

	ArrayList _oTPRCriteriaList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
