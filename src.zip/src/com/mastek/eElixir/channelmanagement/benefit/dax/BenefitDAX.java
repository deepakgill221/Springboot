/********************************************************************
 *
 *  PROJECT                        : PRUDENTIAL
 *  MODULE NAME                        : CHANNEL MANAGEMENT
 *  FILENAME                        : BenefitDAX.java
 *  AUTHOR                        : Pallav Laddha
 *  VERSION                        : 1.0
 *  CREATION DATE                : October 20, 2002
 *  COMPANY                        : Mastek Ltd.
 *  COPYRIGHT                        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY           REASON
 *--------------------------------------------------------------------------------
 *1.0       19/12/2002  Heena Jain   Changes done onsite merging line no 410 modified
 *1.1       30Jan       Pallav        Added delete functionality
 *2.1       06/09/2003  Dipti F       UT Rework
 *2.2       29/09/2003  Dipti F       UT Rework Column Benefit Type change
 *2.3		Sep 17 2004	Sandeep B	  Added the Other Benefit Program methods
 *2.4		Jan-22-2007	Jimmy K G	  Added new fields for Release 8.0.
 *									  Hold Percentage,Year,Cap Percentage,Paid To,Reportees,
 *									  Consider Agent Terminated Status,Bonus Level.
 *			24-03-2011	Shrikrishna  CR:FSD-Agent_Compensation_2011_v1.0.doc
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.benefit.dvo.BenefitEligibilityCriteria;
import com.mastek.eElixir.channelmanagement.benefit.util.BenefitResult;
import com.mastek.eElixir.channelmanagement.benefit.util.CriteriaParameterResult;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitAgentDetail;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.channelmanagement.benefit.util.PerReductionResult;
import com.mastek.eElixir.channelmanagement.benefit.util.TargetOfficeMultiplierResult;//Arun
import com.mastek.eElixir.channelmanagement.benefit.util.TargetParamDetailsResult;//Arun
import com.mastek.eElixir.channelmanagement.benefit.util.TPRDetailsResult;
import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.dax.BonusDAX;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.BonusResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;
import com.mastek.eElixir.channelmanagement.benefit.util.TargetCriteriaParamResult;//Arun

/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the Benefit object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class BenefitDAX extends DAX
{
    /*
     * Member variables
     */
    private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor
     */
    public BenefitDAX()
    {
    }

    /**
     * Populates the resultset into XML string object
     *
     * @param a_oResultObject
     *            Object
     * @return XML string object
     * @throws EElixirException
     */
    public String getBenefit(Object a_oResultObject) throws EElixirException
    {
        log.debug("BenefitDAX--Inside getBenefit of DAX");

        PreparedStatement pstmtSearchBenefit = null;
        HashMap hmQueryMap = new HashMap();
        SearchData oSearchData = (SearchData) a_oResultObject;
        log.debug("BenefitDAX--Search Data" + oSearchData);

        try
        {
            String strBenDesc = oSearchData.getTask1();
            String strBenType = oSearchData.getTask2();
            String cChannelType = oSearchData.getTask3();
            String strDesgnCd = oSearchData.getTask4();

            GregorianCalendar dtEffFrom = oSearchData.getTaskDate1();
            GregorianCalendar dtEffTo = oSearchData.getTaskDate2();
            log.debug("BenefitDAX--after Search Data");

            String strSearchBenefitQuery = getSQLString("Select", CHMConstants.BENEFIT_LIST_SEARCH);

            hmQueryMap.put("Main", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND cbh.STRBENDESC LIKE  ? ";
            hmQueryMap.put("BENEFITDESC", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND cbh.strBenType =  ? ";
            hmQueryMap.put("BENEFITTYPE", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND cbh.cChannelType =  ? ";
            hmQueryMap.put("CHANNELTYPE", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND cbh.strDesgnCd =  ? ";
            hmQueryMap.put("DESNCD", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND cbh.dtEffFrom =  ? ";
            hmQueryMap.put("EffectiveDateFrom", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND cbh.dtEffTo =  ? ";
            hmQueryMap.put("EffectiveDateTo", strSearchBenefitQuery);

            String strQuery = (String) hmQueryMap.get("Main");
            log.debug("BenefitDAX--Strquery =" + strQuery);

            if ((strBenDesc != null) && !strBenDesc.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("BENEFITDESC");
            }

            if ((strBenType != null) && !strBenType.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("BENEFITTYPE");
            }

            if ((cChannelType != null) && !cChannelType.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("CHANNELTYPE");
            }

            if ((strDesgnCd != null) && !strDesgnCd.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("DESNCD");
            }

            if (dtEffFrom != null)
            {
                strQuery += (String) hmQueryMap.get("EffectiveDateFrom");
            }

            if (dtEffTo != null)
            {
                strQuery += (String) hmQueryMap.get("EffectiveDateTo");
            }

            strQuery = strQuery + " order by cbh.STRBENDESC";
            log.debug("BenefitDAX--Strquery =" + strQuery);
            pstmtSearchBenefit = getPreparedStatement(strQuery);
            log.debug("BenefitDAX--Query Formed  " + strQuery);

            int iPosition = 0;

            if ((strBenDesc != null) && !strBenDesc.trim().equals(""))
            {
                log.debug("BenefitDAX--Adding Benefit Desc ");
                pstmtSearchBenefit.setString(++iPosition, "%" + strBenDesc.trim().toUpperCase() + "%");
            }

            if ((strBenType != null) && !strBenType.trim().equals(""))
            {
                log.debug("BenefitDAX--Adding Benefit Type");
                pstmtSearchBenefit.setString(++iPosition, strBenType.trim());
            }

            if ((cChannelType != null) && !cChannelType.trim().equals(""))
            {
                log.debug("BenefitDAX--Adding Channel Type ");
                pstmtSearchBenefit.setString(++iPosition, cChannelType.trim());
            }

            if ((strDesgnCd != null) && !strDesgnCd.trim().equals(""))
            {
                log.debug("BenefitDAX--Adding Desgncode ");
                pstmtSearchBenefit.setString(++iPosition, strDesgnCd.trim());
            }

            if (dtEffFrom != null)
            {
                log.debug("BenefitDAX--Adding Effective Date From");
                pstmtSearchBenefit.setTimestamp(++iPosition, DateUtil.retTimestamp(dtEffFrom));
            }

            if (dtEffTo != null)
            {
                log.debug("BenefitDAX--Adding Effective Date To");
                pstmtSearchBenefit.setTimestamp(++iPosition, DateUtil.retTimestamp(dtEffTo));
            }

            ResultSet rsSearch = executeQuery(pstmtSearchBenefit);

            return XMLConverter.getXMLString(rsSearch);
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9001");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P9001");
        } finally
        {
            try
            {
                if (pstmtSearchBenefit != null)
                {
                    pstmtSearchBenefit.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Inserts a new record
     *
     * @param a_oBenefitResult
     *            BenefitResult
     * @return long Returns the next seq no generated on Benefit table
     * @throws EElixirException
     */
    public long createBenefit(BenefitResult a_oBenefitResult) throws EElixirException
    {
        PreparedStatement pstmtCreateBenefit = null;

        //ArrayList arrProductMix = null;
        long lbenseqnbr;
        String strCreatedBy = null;

        try
        {
            String strBenDesc = a_oBenefitResult.getBenDesc().toUpperCase();
            String strBenType = a_oBenefitResult.getBenType();
            GregorianCalendar dtEffFrom = a_oBenefitResult.getDtEffFrom();
            GregorianCalendar dtEffTo = a_oBenefitResult.getDtEffTo();
            Character cChannelType = a_oBenefitResult.getChannelType();
            String strDesgnCd = a_oBenefitResult.getDesgnCd();
            Short nFreqOfCalc = a_oBenefitResult.getFreqOfCalc();
            Short nFreqOfPmt = a_oBenefitResult.getFreqOfPmt();
            Short nStartMonth = a_oBenefitResult.getStartMonth();
            Short nRef = a_oBenefitResult.getRef();
            Short nIsSpecificBenefit = a_oBenefitResult.getIsSpecificBenefit();
            Long lFormlDefnSeqNbr = a_oBenefitResult.getFormlDefnSeqNbr();
            strCreatedBy = a_oBenefitResult.getUserId();

            //  BenefitCalculationCriteria oBenefitCalculationCriteria =
            // a_oBenefitResult.getBenefitCalculationCriteria();
            BenefitEligibilityCriteria oBenefitEligibilityCriteria = a_oBenefitResult.getBenefitEligibilityCriteria();

            //arrProductMix = a_oBenefitResult.getArrProductMix();
            // Before inserting a new record this function generates a new Seq
            // no, on which the
            // new record is inserted.
            lbenseqnbr = getNextBenSeqNbr();
            log.debug("BenefitDAX--------------the dax created newkey----" + lbenseqnbr);

            String strCreateBenefitQuery = getSQLString("Insert", CHMConstants.BENEFIT_INSERT);

            log.debug("BenefitDAX--StrBenefitquery =" + strCreateBenefitQuery);
            pstmtCreateBenefit = getPreparedStatement(strCreateBenefitQuery);

            pstmtCreateBenefit.setLong(1, lbenseqnbr);
            pstmtCreateBenefit.setString(2, strBenDesc.trim().toUpperCase());
            pstmtCreateBenefit.setString(3, strBenType);
            pstmtCreateBenefit.setTimestamp(4, DateUtil.retTimestamp(dtEffFrom));
            pstmtCreateBenefit.setTimestamp(5, DateUtil.retTimestamp(dtEffTo));
            pstmtCreateBenefit.setString(6, (cChannelType.charValue() + "").trim());
            pstmtCreateBenefit.setString(7, strDesgnCd);
            pstmtCreateBenefit.setShort(8, nFreqOfCalc.shortValue());
            pstmtCreateBenefit.setShort(9, nFreqOfPmt.shortValue());
            pstmtCreateBenefit.setShort(10, nStartMonth.shortValue());
            pstmtCreateBenefit.setShort(11, nRef.shortValue());
            pstmtCreateBenefit.setShort(12, nIsSpecificBenefit.shortValue());

            if (lFormlDefnSeqNbr != null)
            {
                pstmtCreateBenefit.setLong(13, lFormlDefnSeqNbr.longValue());
            } else
            {
                pstmtCreateBenefit.setNull(13, java.sql.Types.INTEGER);
            }

            pstmtCreateBenefit.setString(14, strCreatedBy);

            if (a_oBenefitResult.getIsTDSAppl() == null)
            {
                pstmtCreateBenefit.setNull(15, java.sql.Types.INTEGER);
            } else
            {
                pstmtCreateBenefit.setShort(15, a_oBenefitResult.getIsTDSAppl().shortValue());
            }

            if (a_oBenefitResult.getIsSTAppl() == null)
            {
                pstmtCreateBenefit.setNull(16, java.sql.Types.INTEGER);
            } else
            {
                pstmtCreateBenefit.setShort(16, a_oBenefitResult.getIsSTAppl().shortValue());
            }

            log.debug("BenefitDAX--After setting all values");

            //java.sql.Types.INTEGER

            /*
             * Do this way for null values if(oiProdVer == null){
             * pstmtCreateBenefit.setInt(9,java.sql.Types.INTEGER); } else{
             * pstmtCreateBenefit.setInt(9,oiProdVer.intValue()); }
             */
            int icount = executeUpdate(pstmtCreateBenefit);
            log.debug("BenefitDAX--" + icount);
            log.debug("BenefitDAX--------------the dax created newkey----" + lbenseqnbr);

            // Now inserting Calculation criteria
            Short nBenDetailType = null;
            Short nMonthFrom = null;
            Short nMonthTo = null;

            /*
             * if (oBenefitCalculationCriteria != null) {
             * log.debug("BenefitDAX--Now inserting Calculation criteria");
             * nBenDetailType = oBenefitCalculationCriteria.getBenDetailType();
             * nEvalFunction = oBenefitCalculationCriteria.getEvalFunction();
             * dEvalValue = oBenefitCalculationCriteria.getEvalValue();
             * nMonthFrom = oBenefitCalculationCriteria.getMonthFrom(); nMonthTo =
             * oBenefitCalculationCriteria.getMonthTo();
             *
             * String strCreateBenefitCalculationQuery =
             * getSQLString("Insert",CHMConstants.BENEFIT_CALCULATION_INSERT);
             * log.debug("BenefitDAX--strCreateBenefitCalculationQuery =" +
             * strCreateBenefitCalculationQuery); pstmtCreateBenefit =
             * getPreparedStatement(strCreateBenefitCalculationQuery);
             *
             * pstmtCreateBenefit.setLong(1,lbenseqnbr);
             * pstmtCreateBenefit.setShort(2,nBenDetailType.shortValue());
             * pstmtCreateBenefit.setShort(3,nEvalFunction.shortValue());
             *
             * if(dEvalValue == null){
             * pstmtCreateBenefit.setNull(4,java.sql.Types.DOUBLE); } else{
             * pstmtCreateBenefit.setDouble(4,dEvalValue.doubleValue()); }
             * pstmtCreateBenefit.setShort(5,nMonthFrom.shortValue());
             * pstmtCreateBenefit.setShort(6,nMonthTo.shortValue());
             * pstmtCreateBenefit.setString(7,strCreatedBy); icount =
             * executeUpdate(pstmtCreateBenefit); log.debug("BenefitDAX--Count
             * of Calculation criteria" + icount);
             *  }
             */
            // Now inserting Eligibility criteria
            log.debug("BenefitDAX--Now inserting Eligibility criteria");
            nBenDetailType = oBenefitEligibilityCriteria.getBenDetailType();

            Short nCritFunction = oBenefitEligibilityCriteria.getCritFunction();
            String strElgbleValue = oBenefitEligibilityCriteria.getElgbleValue();
            nMonthFrom = oBenefitEligibilityCriteria.getMonthFrom();
            nMonthTo = oBenefitEligibilityCriteria.getMonthTo();

            if (nCritFunction != null)
            {
                String strCreateBenefitEligibilityQuery = getSQLString("Insert", CHMConstants.BENEFIT_ELIGIBILITY_INSERT);
                log.debug("BenefitDAX--strCreateBenefitEligibilityQuery =" + strCreateBenefitEligibilityQuery);
                pstmtCreateBenefit = getPreparedStatement(strCreateBenefitEligibilityQuery);

                pstmtCreateBenefit.setLong(1, lbenseqnbr);
                pstmtCreateBenefit.setShort(2, nBenDetailType.shortValue());
                pstmtCreateBenefit.setShort(3, nCritFunction.shortValue());
                pstmtCreateBenefit.setString(4, strElgbleValue);
                pstmtCreateBenefit.setShort(5, nMonthFrom.shortValue());
                pstmtCreateBenefit.setShort(6, nMonthTo.shortValue());
                pstmtCreateBenefit.setString(7, strCreatedBy);
                icount = executeUpdate(pstmtCreateBenefit);
                log.debug("BenefitDAX--Count of Eligibility criteria" + icount);
            }

            // Now inserting Product Mix data
            log.debug("BenefitDAX--Now inserting Product Mix data");

            int count = 0;

            /*
             * if(arrProductMix != null){ for(int i=0; i <arrProductMix.size();
             * i++){ String strCreateProductMixQuery =
             * getSQLString("Insert",CHMConstants.BENEFIT_PRODUCT_MIX_INSERT);
             * pstmtCreateBenefit =
             * getPreparedStatement(strCreateProductMixQuery);
             *
             * ProductMix oProductMix = (ProductMix)arrProductMix.get(i);
             * pstmtCreateBenefit.setLong(1,lbenseqnbr);
             * pstmtCreateBenefit.setString(2,oProductMix.getProdCd());
             * pstmtCreateBenefit.setInt(3,oProductMix.getProdVer().intValue());
             * pstmtCreateBenefit.setDouble(4,oProductMix.getProdPerc().doubleValue());
             * pstmtCreateBenefit.setString(5,strCreatedBy); count++; icount =
             * executeUpdate(pstmtCreateBenefit); } }
             */
            log.debug("BenefitDAX--Count of Product mix" + count);

            return lbenseqnbr;
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9007");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw eex;
        } finally
        {
            try
            {
                if (pstmtCreateBenefit != null)
                {
                    pstmtCreateBenefit.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    
    
    //******************Himanshu: Inclusion in ACS:Q1 release: Code Start***********************
    
    public String getDRCRcodeDetails()
    throws EElixirException
{
    	
    ResultSet resultsetforacs = null;
    PreparedStatement preparedstatementforacs = null;
   // BonusProducts oBonusProducts = null;
    String stringforacs = "";
      
    String strValidVal = "";
    try
    {
    	
        String strSelectACSCodeQuery = getSQLString(CHMConstants.ACCOUNT_CODE_ACS_SEARCH ,"Select");
    
        preparedstatementforacs  = getPreparedStatement(strSelectACSCodeQuery);
        resultsetforacs = executeQuery(preparedstatementforacs);
    	
        while (resultsetforacs.next())
        {
        
        	
           // oBonusProducts = new BonusProducts();
        	//  oBonusProducts.setnvalidateValue(resultsetforacs.getString("STRCDDESC"));
        	
            stringforacs = resultsetforacs.getString("STRCDDESC");
           
        	strValidVal=strValidVal.concat(stringforacs+",");
        
      
        }
        if(strValidVal.length() != 0)
        {
        	return strValidVal.substring(0,strValidVal.lastIndexOf(","));
        }
        else
        {
        	return strValidVal;
        }
        
    }
    catch (SQLException sqlex)
    {
	
        throw new EElixirException(sqlex, "P8076");
    }
    finally
    {
        try
        {
            if (resultsetforacs != null)
            {
            	resultsetforacs.close();
            }
        }
        catch (SQLException sqlex)
        {
			
            throw new EElixirException(sqlex, "P8076");
        }
    }
}
    //******************Himanshu: Inclusion in ACS:Q1 release: Code Ends here***********************
    
   

    /**
     * getBenefit gets the Benefit Details
     *
     * @return BenefitResult
     * @param a_lbenseqnbr
     *            long
     * @throws EElixirException
     */
    public BenefitResult getBenefit(long a_lbenseqnbr) throws EElixirException
    {
        ResultSet rsSearchBenefit = null;
        BenefitResult oBenefitResult = null;
        PreparedStatement pstmtSearchBenefit = null;

        //     BenefitCalculationCriteria oBenefitCalculationCriteria = null;
        BenefitEligibilityCriteria oBenefitEligibilityCriteria = null;

        try
        {
            String strSelectBenefitQuery = getSQLString("Select", CHMConstants.BENEFIT_SEARCH);
            log.debug("BenefitDAX--search query is " + strSelectBenefitQuery);
            log.debug("BenefitDAX--primary key is " + a_lbenseqnbr);
            pstmtSearchBenefit = getPreparedStatement(strSelectBenefitQuery);
            pstmtSearchBenefit.setLong(1, a_lbenseqnbr);

            rsSearchBenefit = executeQuery(pstmtSearchBenefit);
            log.debug("BenefitDAX--Query executed properly");
            oBenefitResult = new BenefitResult();

            if (rsSearchBenefit.next())
            {
                oBenefitResult.setIsDirty(DataConstants.DISPLAY_MODE);
                oBenefitResult.setBenSeqNbr(new Long(rsSearchBenefit.getLong(1)));
                oBenefitResult.setBenDesc(rsSearchBenefit.getString(2));
                oBenefitResult.setDtEffFrom(DateUtil.retGregorian(rsSearchBenefit.getTimestamp(3)));
                oBenefitResult.setDtEffTo(DateUtil.retGregorian(rsSearchBenefit.getTimestamp(4)));
                oBenefitResult.setBenType(rsSearchBenefit.getString(5));
                oBenefitResult.setChannelType(new Character(rsSearchBenefit.getString(6).charAt(0)));
                oBenefitResult.setDesgnCd(rsSearchBenefit.getString(7));
                oBenefitResult.setFreqOfCalc(new Short(rsSearchBenefit.getShort(8)));
                oBenefitResult.setFreqOfPmt(new Short(rsSearchBenefit.getShort(9)));
                oBenefitResult.setRef(new Short(rsSearchBenefit.getShort(10)));
                oBenefitResult.setStartMonth(new Short(rsSearchBenefit.getShort(11)));
                oBenefitResult.setIsSpecificBenefit(new Short(rsSearchBenefit.getShort("NISSPECIFICBENEFIT")));

                oBenefitResult.setIsTDSAppl(new Short(rsSearchBenefit.getShort("NISTDSAPPL")));
                oBenefitResult.setIsSTAppl(new Short(rsSearchBenefit.getShort("NISSTAPPL")));

                oBenefitResult.setTsDtUpdated(rsSearchBenefit.getTimestamp("dtupdated"));

                long lFormlDefnseq = rsSearchBenefit.getLong("LFORMLDEFNSEQNBR");
                log.debug("BenefitDAX--Benefit form seq nbr " + lFormlDefnseq);

                if (!rsSearchBenefit.wasNull())
                {
                    oBenefitResult.setFormlDefnSeqNbr(new Long(rsSearchBenefit.getLong("LFORMLDEFNSEQNBR")));
                }

                log.debug("BenefitDAX--Benefit filled");
            }

            //" Now the part for Benefit Calculation"
            log.debug("BenefitDAX-- Now the part for Benefit Calculation");

            String strSelectBenefitCalculationQuery = getSQLString("Select", CHMConstants.BENEFIT_CALCULATION_SEARCH);
            log.debug("BenefitDAX--search query is " + strSelectBenefitCalculationQuery);
            pstmtSearchBenefit = getPreparedStatement(strSelectBenefitCalculationQuery);
            pstmtSearchBenefit.setLong(1, a_lbenseqnbr);
            pstmtSearchBenefit.setInt(2, DataConstants.BENEFIT_CALCULATION);

            rsSearchBenefit = executeQuery(pstmtSearchBenefit);
            log.debug("BenefitDAX--Query executed properly");

            /*
             * oBenefitCalculationCriteria = new BenefitCalculationCriteria();
             * if(rsSearchBenefit.next()) {
             * oBenefitCalculationCriteria.setBenSeqNbr(new Long(a_lbenseqnbr));
             * oBenefitCalculationCriteria.setBenDetailType(new
             * Short(rsSearchBenefit.getShort(1)));
             * oBenefitCalculationCriteria.setMonthFrom(new
             * Short(rsSearchBenefit.getShort(2)));
             * oBenefitCalculationCriteria.setMonthTo(new
             * Short(rsSearchBenefit.getShort(3)));
             * oBenefitCalculationCriteria.setEvalFunction(new
             * Short(rsSearchBenefit.getShort(4))); double d =
             * rsSearchBenefit.getDouble(5); if(rsSearchBenefit.wasNull()){
             * oBenefitCalculationCriteria.setEvalValue(null); } else{
             * oBenefitCalculationCriteria.setEvalValue(new
             * Double(rsSearchBenefit.getDouble(5))); }
             * //oBenefitCalculationCriteria.setEvalValue(new
             * Double(rsSearchBenefit.getDouble(5)));
             * //oBenefitCalculationCriteria.setEvalValue(new
             * Double(rsSearchBenefit.getDouble(5))); }
             * oBenefitResult.setBenefitCalculationCriteria(oBenefitCalculationCriteria);
             */
            //" Now the part for Benefit Eligibility"
            log.debug("BenefitDAX-- Now the part for Benefit Eligibility");

            String strSelectBenefitEligibilityQuery = getSQLString("Select", CHMConstants.BENEFIT_ELIGIBILITY_SEARCH);
            log.debug("BenefitDAX--search query is " + strSelectBenefitEligibilityQuery);
            pstmtSearchBenefit = getPreparedStatement(strSelectBenefitEligibilityQuery);
            pstmtSearchBenefit.setLong(1, a_lbenseqnbr);
            pstmtSearchBenefit.setInt(2, DataConstants.BENEFIT_ELIGIBILITY);

            rsSearchBenefit = executeQuery(pstmtSearchBenefit);
            log.debug("BenefitDAX--Query executed properly");
            oBenefitEligibilityCriteria = new BenefitEligibilityCriteria();

            if (rsSearchBenefit.next())
            {
                oBenefitEligibilityCriteria.setBenSeqNbr(new Long(a_lbenseqnbr));
                oBenefitEligibilityCriteria.setBenDetailType(new Short(rsSearchBenefit.getShort(1)));
                oBenefitEligibilityCriteria.setMonthFrom(new Short(rsSearchBenefit.getShort(2)));
                oBenefitEligibilityCriteria.setMonthTo(new Short(rsSearchBenefit.getShort(3)));
                oBenefitEligibilityCriteria.setCritFunction(new Short(rsSearchBenefit.getShort(4)));
                oBenefitEligibilityCriteria.setElgbleValue(rsSearchBenefit.getString(5));
            }

            oBenefitResult.setBenefitEligibilityCriteria(oBenefitEligibilityCriteria);

            // Now the part of Product Mix

            /*
             * log.debug("BenefitDAX-- Now the part for Product Mix"); String
             * strSelectProductMixQuery =
             * getSQLString("Select",CHMConstants.BENEFIT_PRODUCT_MIX_SEARCH);
             * log.debug("BenefitDAX--search query is "+
             * strSelectProductMixQuery); pstmtSearchBenefit =
             * getPreparedStatement(strSelectProductMixQuery);
             * pstmtSearchBenefit.setLong(1,a_lbenseqnbr);
             *
             * rsSearchBenefit = executeQuery(pstmtSearchBenefit);
             * log.debug("BenefitDAX--Query executed properly"); arrProductMix =
             * new ArrayList(10); int count = 0; while(rsSearchBenefit.next()) {
             * ProductMix oProductMix = new ProductMix();
             * oProductMix.setBenSeqNbr(new Long(a_lbenseqnbr));
             * oProductMix.setProdCd(rsSearchBenefit.getString(1));
             * oProductMix.setProdVer(new Integer(rsSearchBenefit.getInt(2)));
             * oProductMix.setProdPerc(new
             * Double(rsSearchBenefit.getDouble(3)));
             * arrProductMix.add(oProductMix); count++; }
             * log.debug("BenefitDAX--Count for no of ProductMix obtained is :" +
             * count); if(count == 0){ arrProductMix = null; }
             */

            //oBenefitResult.setArrProductMix(arrProductMix);
            return oBenefitResult;
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9008");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P9008");
        } finally
        {
            try
            {
                if (rsSearchBenefit != null)
                {
                    rsSearchBenefit.close();
                }

                if (pstmtSearchBenefit != null)
                {
                    pstmtSearchBenefit.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Updates the Benefit, Currently only Effective To date can be updated
     *
     * @return int No of rows updated
     * @param: a_oBenefitResult BenefitResult
     * @throws EElixirException
     */
    public int updateBenefit(BenefitResult a_oBenefitResult) throws EElixirException
    {
        PreparedStatement pstmtUpdateBenefit = null;
        String strUpdatedBy = null;

        try
        {
            String strUpdateQuery = getSQLString("Update", CHMConstants.BENEFIT_UPDATE);
            pstmtUpdateBenefit = getPreparedStatement(strUpdateQuery);

            GregorianCalendar dtEffToDate = a_oBenefitResult.getDtEffTo();
            Long lbenseqnbr = a_oBenefitResult.getBenSeqNbr();
            strUpdatedBy = a_oBenefitResult.getUserId();
            pstmtUpdateBenefit.setTimestamp(1, DateUtil.retTimestamp(dtEffToDate));
            pstmtUpdateBenefit.setString(2, strUpdatedBy);
            pstmtUpdateBenefit.setLong(3, lbenseqnbr.longValue());

            int iUpdateBenefit = executeUpdate(pstmtUpdateBenefit);

            return iUpdateBenefit;
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9005");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P9005");
        } finally
        {
            try
            {
                if (pstmtUpdateBenefit != null)
                {
                    pstmtUpdateBenefit.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * findBenefit finds whether the benefit is there or not
     *
     * @return boolean
     * @param a_lbenseqnbr
     *            long
     * @throws EElixirException
     */
    public boolean findBenefit(long a_lbenseqnbr) throws EElixirException
    {
        ResultSet rsSearchBenefit = null;
        PreparedStatement pstmtFindPrimaryKey = null;

        try
        {
            String strSelectBenefitQuery = getSQLString("Select", CHMConstants.FIND_BENEFIT_BY_PRIMARYKEY);

            if (pstmtFindPrimaryKey == null)
            {
                pstmtFindPrimaryKey = getPreparedStatement(strSelectBenefitQuery);
            }

            pstmtFindPrimaryKey.setLong(1, a_lbenseqnbr);

            rsSearchBenefit = executeQuery(pstmtFindPrimaryKey);

            if (rsSearchBenefit.next())
            {
                return true;
            } else
            {
                return false;
            }
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9002");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P9002");
        } finally
        {
            try
            {
                if (rsSearchBenefit != null)
                {
                    rsSearchBenefit.close();
                }

                if (pstmtFindPrimaryKey != null)
                {
                    pstmtFindPrimaryKey.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Removes the selected Benefit
     *
     * @return int No of rows removed
     * @param: a_lBenSeqNbr long
     * @throws EElixirException
     */
    public int removeBenefit(long a_lBenSeqNbr) throws EElixirException
    {
        PreparedStatement pstmtRemoveBenefit = null;

        try
        {
            log.debug("BenefitDAX-- Inside remove Benefit");

            String strRemoveQuery = getSQLString("Delete", CHMConstants.BENEFIT_ELIGIBILITY_CALCULATION_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, a_lBenSeqNbr);

            int iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Removed Eligibility and calculation");
            removeAllProductMix(a_lBenSeqNbr);
            log.debug("BenefitDAX-- Removed Product Mix");
            strRemoveQuery = getSQLString("Delete", CHMConstants.BENEFIT_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, a_lBenSeqNbr);
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- removed Benefit" + iRemoveBenefit);

            return iRemoveBenefit;
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9022");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P9022");
        } finally
        {
            try
            {
                if (pstmtRemoveBenefit != null)
                {
                    pstmtRemoveBenefit.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Description getSQLString takes querytype and key and returns query
     *
     * @return query string
     * @param a_strSQLType
     *            SQL Type i.e Select , Insert , Delete , Update
     * @param a_strKey
     *            String
     * @throws EElixirException
     */
    private String getSQLString(String a_strSQLType, String a_strKey) throws EElixirException
    {
        SqlRepositoryIF sqlRFIF = null;
        String strSql = "";

        try
        {
            sqlRFIF = CHMSqlRepository.getSqlRepository();
            strSql = sqlRFIF.getSQLString(a_strKey, a_strSQLType);
        } catch (EElixirException eex)
        {
            log.debug("BenefitDAX--sql ex" + eex);
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3019"); // could not get sql
            // string
        }

        return strSql;
    }

    /**
     * This function removes the existing record
     *
     * @throws EElixirException
     * @param a_lBenSeqNbr
     *            long
     */
    protected void removeAllProductMix(long a_lBenSeqNbr) throws EElixirException
    {
        PreparedStatement pstmtRemoveProductMixContest = null;

        try
        {
            String strRemoveProductMixQuery = getSQLString("Delete", CHMConstants.BENEFIT_ALL_PRODUCT_MIX_DELETE);
            pstmtRemoveProductMixContest = getPreparedStatement(strRemoveProductMixQuery);
            pstmtRemoveProductMixContest.setLong(1, a_lBenSeqNbr);

            int icount = executeUpdate(pstmtRemoveProductMixContest);
            log.debug("ContestDAX--remove of Product mix" + icount);
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9508");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P9508");
        } finally
        {
            try
            {
                if (pstmtRemoveProductMixContest != null)
                {
                    pstmtRemoveProductMixContest.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * This function generates a new Seq no, on which the new record is
     * inserted.
     *
     * @return long Returns the next seq no generated on Benefit table
     * @throws EElixirException
     */
    protected long getNextBenSeqNbr() throws EElixirException
    {
        Statement stmtNextSeqBenefit = null;
        long lSeqNo;

        try
        {
            String strNextSeqQuery = getSQLString("Select", CHMConstants.BENEFIT_SEQUENCENO);

            stmtNextSeqBenefit = getStatement();

            ResultSet rsSeqNo = stmtNextSeqBenefit.executeQuery(strNextSeqQuery);
            rsSeqNo.next();
            lSeqNo = rsSeqNo.getLong(1);
            log.debug(lSeqNo + "");

            return lSeqNo;
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9006");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P9006");
        } finally
        {
            try
            {
                if (stmtNextSeqBenefit != null)
                {
                    stmtNextSeqBenefit.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    //added by Sandeep for other Benefit
    /**
     * Populates the resultset into XML string object
     * @param a_oResultObject
     *            Object
     * @return XML string object
     * @throws EElixirException
     */
    public String getOtherBenefit(SearchData a_oSearchData) throws EElixirException
    {
        log.debug("BenefitDAX--Inside getOtherBenefit of DAX");

        PreparedStatement pstmtSearchBenefit = null;
        HashMap hmQueryMap = new HashMap();
        log.debug("BenefitDAX--Search Data" + a_oSearchData);

        try
        {
            String strBenType = a_oSearchData.getTask1();
            String strBenDesc = a_oSearchData.getTask2();
            String cChannelType = a_oSearchData.getTask3();
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
            String strAgentCd = a_oSearchData.getTask4();
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
            GregorianCalendar dtStart = a_oSearchData.getTaskDate1();
            GregorianCalendar dtEnd = a_oSearchData.getTaskDate2();

            String strSearchBenefitQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_LIST_SEARCH);

            hmQueryMap.put("Main", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND CBDH.STRBONUSTYPE =  ? ";
            hmQueryMap.put("BENEFITTYPE", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND UPPER(CBDH.STRBONUSDESC) LIKE  ? ";
            hmQueryMap.put("BENEFITDESC", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND CBDH.CCHANNELTYPE =  ? ";
            hmQueryMap.put("CHANNELTYPE", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND CBDH.DTEFFFROM =  ? ";
            hmQueryMap.put("DTSTART", strSearchBenefitQuery);

            strSearchBenefitQuery = " AND CBDH.DTEFFTO =  ? ";
            hmQueryMap.put("DTEND", strSearchBenefitQuery);
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
            strSearchBenefitQuery = " AND CIA.STRAGENTCD =  ? ";
            hmQueryMap.put("STRAGENTCD", strSearchBenefitQuery);
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
            String strQuery = (String) hmQueryMap.get("Main");
            log.debug("BenefitDAX--Strquery =" + strQuery);

            if ((strBenType != null) && !strBenType.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("BENEFITTYPE");
            }

            if ((strBenDesc != null) && !strBenDesc.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("BENEFITDESC");
            }

            if ((cChannelType != null) && !cChannelType.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("CHANNELTYPE");
            }

            if (dtStart != null)
            {
                strQuery += (String) hmQueryMap.get("DTSTART");
            }

            if (dtEnd != null)
            {
                strQuery += (String) hmQueryMap.get("DTEND");
            }
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
            if ((strAgentCd != null) &&  !strAgentCd.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("STRAGENTCD");
            }
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
            strQuery = strQuery + " order by CBDH.STRBONUSDESC";

            log.debug("BenefitDAX--Strquery =" + strQuery);
            pstmtSearchBenefit = getPreparedStatement(strQuery);

            pstmtSearchBenefit.setInt(1, DataConstants.BONUS_RELOAD);
            pstmtSearchBenefit.setInt(2, DataConstants.COMMON_FREQUENCY);
            pstmtSearchBenefit.setInt(3, DataConstants.BENEFIT_PAYMENT_FREQUENCY);
            pstmtSearchBenefit.setInt(4, DataConstants.YES_NO);

            int iPosition = 4;

            if ((strBenType != null) && !strBenType.trim().equals(""))
            {
                log.debug("BenefitDAX--Adding Benefit Type");
                pstmtSearchBenefit.setString(++iPosition, strBenType.trim());
            }

            if ((strBenDesc != null) && !strBenDesc.trim().equals(""))
            {
                log.debug("BenefitDAX--Adding Benefit Desc ");
                pstmtSearchBenefit.setString(++iPosition, "%" + strBenDesc.trim().toUpperCase() + "%");
            }

            if ((cChannelType != null) && !cChannelType.trim().equals(""))
            {
                log.debug("BenefitDAX--Adding Channel Type ");
                pstmtSearchBenefit.setString(++iPosition, cChannelType.trim());
            }

            if (dtStart != null)
            {
                log.debug("BenefitDAX--Adding Effective Date From");
                pstmtSearchBenefit.setTimestamp(++iPosition, DateUtil.retTimestamp(dtStart));
            }

            if (dtEnd != null)
            {
                log.debug("BenefitDAX--Adding Effective Date To");
                pstmtSearchBenefit.setTimestamp(++iPosition, DateUtil.retTimestamp(dtEnd));
            }
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
            if ((strAgentCd != null) && !strAgentCd.trim().equals(""))
            {
                log.debug("BenefitDAX--Adding Agent/Agency Code");
                pstmtSearchBenefit.setString(++iPosition, strAgentCd.trim());
            }
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
            ResultSet rsSearch = executeQuery(pstmtSearchBenefit);

            return XMLConverter.getXMLString(rsSearch);
        } catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());
            throw new EElixirException(sqlex, "P9001");
        } catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P9001");
        } finally
        {
            try
            {
                if (pstmtSearchBenefit != null)
                {
                    pstmtSearchBenefit.close();
                }
            } catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    public long createOtherBenefit(OtherBenefitResult a_oOtherBenefitResult) throws EElixirException
    {
        PreparedStatement pstmtInsertOtherBenefit = null;
        ResultSet rsBonus = null;
        long lbenseqnbr = 0;

        try
        {
            String strSelectBonusSeqQuery = getSQLString("Select", CHMConstants.BONUS_HDR_SEQUENCE);
            log.debug("strSelectBonusSeqQuery " + strSelectBonusSeqQuery);
            rsBonus = executeQuery(strSelectBonusSeqQuery);

            if (rsBonus.next())
            {
                lbenseqnbr = rsBonus.getLong(1);
                a_oOtherBenefitResult.setBonusHdrSeqNbr(new Long(lbenseqnbr));
            } else
            {
                log.fatal("Sequence no not generated");
                throw new EElixirException("p4528");
            }

            log.debug("Inside Dax-before method strInsertBonusQuery Insert other benefit HDR Insert ");
            String strInsertBonusQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_HDR_INSERT);
            pstmtInsertOtherBenefit = getPreparedStatement(strInsertBonusQuery);
            
            log.debug("Inside Dax-strInsertBonusQuery Insert other benefit HDR Insert ");
            log.debug("-1:Insert-lbenseqnbr value is :"+lbenseqnbr);
            pstmtInsertOtherBenefit.setLong(1, lbenseqnbr);
            pstmtInsertOtherBenefit.setString(2, a_oOtherBenefitResult.getBonusType());
            pstmtInsertOtherBenefit.setString(3, a_oOtherBenefitResult.getBonusDesc());

            pstmtInsertOtherBenefit.setTimestamp(4, DateUtil.retTimestamp(a_oOtherBenefitResult.getEffFrom()));

            if(a_oOtherBenefitResult.getEffTo() != null)
            {

                pstmtInsertOtherBenefit.setTimestamp(5, DateUtil.retTimestamp(a_oOtherBenefitResult.getEffTo()));
            }
            else
            {
                pstmtInsertOtherBenefit.setTimestamp(5,DateUtil.retTimestamp(DateUtil.retGCDate(DataConstants.MAX_DATE_LIMIT)));
            }
            pstmtInsertOtherBenefit.setString(6, a_oOtherBenefitResult.getChannelType());
            pstmtInsertOtherBenefit.setShort(7, a_oOtherBenefitResult.getFreqOfCalc().shortValue());
            pstmtInsertOtherBenefit.setShort(8, a_oOtherBenefitResult.getFreqOfPmt().shortValue());
            pstmtInsertOtherBenefit.setShort(9, a_oOtherBenefitResult.getStartMonthCalc().shortValue());
            pstmtInsertOtherBenefit.setShort(10, a_oOtherBenefitResult.getPmtDay().shortValue());
            pstmtInsertOtherBenefit.setShort(11, a_oOtherBenefitResult.getIsTDSAppl().shortValue());
            pstmtInsertOtherBenefit.setShort(12, a_oOtherBenefitResult.getIsSTAppl().shortValue());
            pstmtInsertOtherBenefit.setString(13, a_oOtherBenefitResult.getUserId());
            pstmtInsertOtherBenefit.setShort(14, a_oOtherBenefitResult.getIsTargetBased().shortValue());

            if(a_oOtherBenefitResult.getNoOfInstallment() != null)
            {
                pstmtInsertOtherBenefit.setShort(15, a_oOtherBenefitResult.getNoOfInstallment().shortValue());
            }
            else
            {
                pstmtInsertOtherBenefit.setNull(15,Types.INTEGER);
            }
            pstmtInsertOtherBenefit.setInt(16, DataConstants.PRODUCT_NA);
            pstmtInsertOtherBenefit.setInt(17, DataConstants.PRODUCT_NA);

            if(a_oOtherBenefitResult.getFreqOfInstallment() != null)
            {
                pstmtInsertOtherBenefit.setInt(18, a_oOtherBenefitResult.getFreqOfInstallment().intValue());
            }
            else
            {
                pstmtInsertOtherBenefit.setNull(18, Types.INTEGER);
            }
            //shameem
         //Arun_FSOtherBenefitsTargetTab_REL8.1 Start
            if(a_oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
            {
              pstmtInsertOtherBenefit.setNull(19, Types.SMALLINT);
            }
            else
            {
			if(a_oOtherBenefitResult.getTargetProRata() != null)
			{
				pstmtInsertOtherBenefit.setShort(19, a_oOtherBenefitResult.getTargetProRata().shortValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(19, Types.SMALLINT);
			}
            }
        //Arun_FSOtherBenefitsTargetTab_REL8.1 End
			if(a_oOtherBenefitResult.getIsCampaign() != null)
			{
				pstmtInsertOtherBenefit.setShort(20, a_oOtherBenefitResult.getIsCampaign().shortValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(20, Types.SMALLINT);
			}
			pstmtInsertOtherBenefit.setShort(21, a_oOtherBenefitResult.getEndImmediate().shortValue());
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
			if(a_oOtherBenefitResult.getCapPercentage() != null)
			{
				pstmtInsertOtherBenefit.setDouble(22,a_oOtherBenefitResult.getCapPercentage().doubleValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(22,Types.DOUBLE);
			}
			if(a_oOtherBenefitResult.getHoldPercentage() != null )
			{
				pstmtInsertOtherBenefit.setDouble(23,a_oOtherBenefitResult.getHoldPercentage().doubleValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(23,Types.DOUBLE);
			}
			if(a_oOtherBenefitResult.getReportees() != null)
			{
				pstmtInsertOtherBenefit.setShort(24,a_oOtherBenefitResult.getReportees().shortValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(24,Types.SMALLINT);
			}
			if(a_oOtherBenefitResult.getAgentTerminatedStatus() != null)
			{
				pstmtInsertOtherBenefit.setShort(25,a_oOtherBenefitResult.getAgentTerminatedStatus().shortValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(25,Types.SMALLINT);
			}
			if(a_oOtherBenefitResult.getBonusLevel() != null)
			{
				pstmtInsertOtherBenefit.setShort(26,a_oOtherBenefitResult.getBonusLevel().shortValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(26,Types.SMALLINT);
			}
			if(a_oOtherBenefitResult.getYearBasis() != null)
			{
				pstmtInsertOtherBenefit.setShort(27,a_oOtherBenefitResult.getYearBasis().shortValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(27,Types.SMALLINT);
			}
			pstmtInsertOtherBenefit.setString(28,a_oOtherBenefitResult.getPaidToAgentAgency());
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
//Jimmy_OtherBenefits_1.10_REL8.0 Starts
			if(a_oOtherBenefitResult.getBonusPayOutMethod() != null)
			{
				pstmtInsertOtherBenefit.setShort(29,a_oOtherBenefitResult.getBonusPayOutMethod().shortValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(29,Types.SMALLINT);
			}
			if(a_oOtherBenefitResult.getMinRequirement() != null)
			{
				pstmtInsertOtherBenefit.setDouble(30,new Double(a_oOtherBenefitResult.getMinRequirement()).doubleValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(30,Types.DOUBLE);
			}
//Jimmy_OtherBenefits_1.10_REL8.0 Ends
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Starts
//Arun_FSOtherBenefitsTargetTab_REL8.1 Start
			if(a_oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
			{
			  if(a_oOtherBenefitResult.getTgtRecalculationType()!=null)
			 {
			  	pstmtInsertOtherBenefit.setShort(31,a_oOtherBenefitResult.getTgtRecalculationType().shortValue());
			 }
			 else
			 {
			   pstmtInsertOtherBenefit.setNull(31,Types.SMALLINT);
			 }
			}
			else
			{
			if (a_oOtherBenefitResult.getRecalculationType() != null)
            {
				pstmtInsertOtherBenefit.setShort(31,a_oOtherBenefitResult.getRecalculationType().shortValue());
            }
            else
            {
            	pstmtInsertOtherBenefit.setNull(31,Types.SMALLINT);
            }
			}
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Ends
			if(a_oOtherBenefitResult.getTgtPlanAttachmentTo()!= null)
			{
			  pstmtInsertOtherBenefit.setShort(32,a_oOtherBenefitResult.getTgtPlanAttachmentTo().shortValue());
			}
			else
			{
			  pstmtInsertOtherBenefit.setNull(32,Types.SMALLINT);
			}

// Arun_FSOtherBenefitsTargetTab_REL8.1 End
			//CR_OtherBenefit_sequence_Rel8.2_start
			if(a_oOtherBenefitResult.getSeqNbr() != null)
            {
                pstmtInsertOtherBenefit.setShort(33, a_oOtherBenefitResult.getSeqNbr().shortValue());
			}
            else
            {
                pstmtInsertOtherBenefit.setNull(33,Types.SMALLINT);
            }
			//CR_OtherBenefit_sequence_Rel8.2_end
			// Santosh_Everest_Distribution Starts


			if (a_oOtherBenefitResult.getSegmnetType() != null) {
				pstmtInsertOtherBenefit.setShort(34, a_oOtherBenefitResult
						.getSegmnetType().shortValue());
			} else {
				pstmtInsertOtherBenefit.setNull(34, Types.SMALLINT);
			}

			if (a_oOtherBenefitResult.getSegmnedOrNot() != null) {
				pstmtInsertOtherBenefit.setShort(35, a_oOtherBenefitResult
						.getSegmnedOrNot().shortValue());
			} else {
				pstmtInsertOtherBenefit.setNull(35, Types.SMALLINT);
			}
			// Santosh_Everest_Distribution Ends
			//Santosh_Ph_II Starts //Removed MAndatory check Ananth_Feb_SIT
			
			if (a_oOtherBenefitResult.getFreqOfProd() != null) {
				pstmtInsertOtherBenefit.setShort(36, a_oOtherBenefitResult.getFreqOfProd().shortValue());
			} else {
				pstmtInsertOtherBenefit.setNull(36, Types.SMALLINT);
			}			
			
			//Santosh_Ph_II Starts
			//Amid : modified for clawback Start
			if (a_oOtherBenefitResult.getClawbackPeriod() != null) {
				pstmtInsertOtherBenefit.setShort(37, a_oOtherBenefitResult
						.getClawbackPeriod().shortValue());
			} else {
				pstmtInsertOtherBenefit.setNull(37, Types.SMALLINT);
			}

			//Amid : modified for clawback End
			//SUNAINA_FS_TRAINING_INCENTIVE_STARTS
			if (a_oOtherBenefitResult.getHeldPayoutFreq() != null) {
				pstmtInsertOtherBenefit.setShort(38, a_oOtherBenefitResult
						.getHeldPayoutFreq().shortValue());
			} else {
				pstmtInsertOtherBenefit.setNull(38, Types.SMALLINT);
			}
			//SUNAINA_FS_TRAINING_INCENTIVE_ENDS
			//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Starts
			if (a_oOtherBenefitResult.getIsGoAssociationAppl() != null) {
				pstmtInsertOtherBenefit.setShort(39, a_oOtherBenefitResult
						.getIsGoAssociationAppl().shortValue());
			} else {
				pstmtInsertOtherBenefit.setNull(39, Types.SMALLINT);
			}
			//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Ends

			//Prabhat Modified for FlatHoldPayout start
			
			if(a_oOtherBenefitResult.getFlatHoldPayout()!=null)
			{
				pstmtInsertOtherBenefit.setDouble(40,a_oOtherBenefitResult.getFlatHoldPayout().doubleValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(40, Types.DOUBLE);
			}
				
			
			//Prabhat Modified for FlatHoldPayout end

// Anantha_Banca_Inc start
			
			if(a_oOtherBenefitResult.getCBPPerc()!=null)
			{
				pstmtInsertOtherBenefit.setDouble(41,a_oOtherBenefitResult.getCBPPerc().doubleValue());
			}
			else
			{
				pstmtInsertOtherBenefit.setNull(41, Types.DOUBLE);
			}
				
			
//Added by Narendra CTS for Bonus screen
			if (a_oOtherBenefitResult.getBonusToTermAgent() != null) {
				pstmtInsertOtherBenefit.setShort(42, a_oOtherBenefitResult
						.getBonusToTermAgent().shortValue());
			} else {
				pstmtInsertOtherBenefit.setNull(42, Types.SMALLINT);
			}
//End by Narendra CTS
//			 Anantha_Banca_Inc end
			
			//<Rel.  - Start : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
			if (a_oOtherBenefitResult.getCeipExclusion() != null) {
				pstmtInsertOtherBenefit.setShort(43, a_oOtherBenefitResult
						.getCeipExclusion());
			} else {
				pstmtInsertOtherBenefit.setNull(43, Types.INTEGER);
			}
			 //start CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011 
		    
		    if(a_oOtherBenefitResult.getPrdPeriod() != null){
		    	log.debug("Production User Defined period:"+a_oOtherBenefitResult.getPrdPeriod());
				pstmtInsertOtherBenefit.setShort(44,a_oOtherBenefitResult.getPrdPeriod().shortValue());
			}
		    else{
		    	log.debug("Inside Else condition Production User Defined period:");
		    	
		    	pstmtInsertOtherBenefit.setNull(44,Types.SMALLINT);
		    }
		    
		   // End CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011
		    
		    
		    
		    //Himanshu
		    
		    if (a_oOtherBenefitResult.getnIsInclusioninACS() != null) {
				pstmtInsertOtherBenefit.setShort(45, a_oOtherBenefitResult.getnIsInclusioninACS().shortValue());
			} else {
				pstmtInsertOtherBenefit.setNull(45, Types.SMALLINT);
			}
		    if (a_oOtherBenefitResult.getnbonusdescinACS()!= null) {
		    	pstmtInsertOtherBenefit.setString(46, a_oOtherBenefitResult.getnbonusdescinACS());
				}else {
					pstmtInsertOtherBenefit.setNull(46, Types.VARCHAR);
				}
				
		    // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Starts
		    if (a_oOtherBenefitResult.get_nPayIfColnNotPresent()!= null) {
		    	pstmtInsertOtherBenefit.setShort(47, a_oOtherBenefitResult.get_nPayIfColnNotPresent());
				}else {
					pstmtInsertOtherBenefit.setNull(47, Types.SMALLINT);
				}
		    // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Ends		    
		    
		    
		    //Himanshu	    
		    
		    
			
			//<Rel.  - End : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
           executeUpdate(pstmtInsertOtherBenefit);
//Arun_FSOtherBenefitsTargetTab_REL8.1 Start
           if(a_oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
           {
        	  insertCriteriaParams(a_oOtherBenefitResult);
           }
           else
           {
//Arun_FSOtherBenefitsTargetTab_REL8.1 End
        	   
        	   log.debug("Inside Dax-before estrInsertBonusQuery Insert other benefit Details Insert ");
            if(a_oOtherBenefitResult.getIsTargetBased().intValue() == DataConstants.YES)
            {
                long lParamSeqNbr = insertCriteriaParams(a_oOtherBenefitResult);
                strInsertBonusQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_DETAIL_INSERT);
                log.debug("AT the other place OTHER_BENEFIT_DETAIL_INSERT");
              //  log.debug(" a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue()" +
			//	a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue() +
			//	" lParamSeqNbr : "+ lParamSeqNbr +
             //   " DataConstants.TARGET_PARAMETER :" + DataConstants.TARGET_PARAMETER +
            //    " a_oOtherBenefitResult.getCriParamIds() : " + a_oOtherBenefitResult.getCriParamIds());
                pstmtInsertOtherBenefit = getPreparedStatement(strInsertBonusQuery);
                pstmtInsertOtherBenefit.setLong(1, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
                pstmtInsertOtherBenefit.setLong(2, lParamSeqNbr);
                pstmtInsertOtherBenefit.setInt(3, DataConstants.TARGET_PARAMETER);
                pstmtInsertOtherBenefit.setString(4, a_oOtherBenefitResult.getCriParamIds());
                pstmtInsertOtherBenefit.setNull(5, Types.DOUBLE);
                pstmtInsertOtherBenefit.setNull(6, Types.DOUBLE);
                pstmtInsertOtherBenefit.setNull(7, Types.DOUBLE);
                pstmtInsertOtherBenefit.setNull(8, Types.DOUBLE);
                pstmtInsertOtherBenefit.setDouble(9,a_oOtherBenefitResult.getTargetValue().doubleValue());
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Starts
                pstmtInsertOtherBenefit.setString(10, a_oOtherBenefitResult.getUserId());
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Ends
                executeUpdate(pstmtInsertOtherBenefit);
            }
            else
            {
                insertCriteriaParams(a_oOtherBenefitResult);
            }
           }
//Jimmy_OtherBenefits_1.1_REL8.0 Starts

           	updateApplicableAgentAgencyDtls(a_oOtherBenefitResult);

//Jimmy_OtherBenefits_1.1_REL8.0 Ends
            updateOtherBenefitDesignationDetails(a_oOtherBenefitResult);
            updateOtherBenefitCriDesgnDetails(a_oOtherBenefitResult);
            //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start           
            updateDesignationExclusionDetails(a_oOtherBenefitResult);
            //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
            //Amid_MP/P_Incentive Scheme Starts           
             updateGlpDetails(a_oOtherBenefitResult);
            //Amid_MP/P_Incentive Scheme Ends
            //Arun_FSOtherBenefitsTargetTab_REL8.1 Start
            if(a_oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
            {
            updateOtherBenefitOfficeMultiplierDtls(a_oOtherBenefitResult);
            updateOtherBenefitTgtCriteriaParamDtls(a_oOtherBenefitResult);
            updateOtherBenefitTargetParamDetails(a_oOtherBenefitResult);
            }
            //Arun_FSOtherBenefitsTargetTab_REL8.1 End
            //Arun_CR_OtherBenefit start
            if(a_oOtherBenefitResult.getOSAcctCd() != null && !a_oOtherBenefitResult.getOSAcctCd().trim().equals(""))
            {
                BonusResult oBonusResult = new BonusResult();
                BonusDAX oBonusDAX = getDAX();
                oBonusResult.setBonusHdrSeqNbr(new Long(lbenseqnbr));
                oBonusResult.setAcctCd(a_oOtherBenefitResult.getAcctCd());
                oBonusResult.setOSAcctCd(a_oOtherBenefitResult.getOSAcctCd());
                oBonusResult.setProvAcctCd(a_oOtherBenefitResult.getProvAcctCd());
                oBonusResult.setUserId(a_oOtherBenefitResult.getUserId());
                oBonusDAX.chkBonusAccountDetails(oBonusResult);
            }
            insertBaseParam(a_oOtherBenefitResult.getBonusDesc(),a_oOtherBenefitResult.getBonusHdrSeqNbr(),a_oOtherBenefitResult.getUserId());
            return lbenseqnbr;
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "createBonus", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        } finally
        {
            try
            {
                if (pstmtInsertOtherBenefit != null)
                {
                    pstmtInsertOtherBenefit.close();
                }
                if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
            catch (EElixirException eElex)
			{						
				throw new EElixirException(eElex, "P1005");
            }
        }
    }

    public long insertCriteriaParams(OtherBenefitResult a_oOtherBenefitResult) throws EElixirException
    {
        ArrayList alCriteriaParameters = null;
        PreparedStatement pstmtCriteriaInsert = null;
        CriteriaParameterResult oCriteriaParameterResult = null;
        long lParamSeqNbr = 0;
        try
        {
            alCriteriaParameters = a_oOtherBenefitResult.getCriParamDetails();

            String[] dBonusRate = a_oOtherBenefitResult.getBonusRate();
            String[] strStatusFlag = a_oOtherBenefitResult.getParamStatusFlag();
            String strCriteriaDetailQuery = null;
            ResultSet rsCriteria = null;

            if (alCriteriaParameters != null)
            {
                for (int i = 0; i < dBonusRate.length; i++)
                {
                    if (strStatusFlag[i].equalsIgnoreCase(DataConstants.INSERT_MODE))
                    {

                        strCriteriaDetailQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_DETAIL_SEQUENCE);
                        log.debug("--2-InsetCriteriaParams() select query is "+strCriteriaDetailQuery);
                        rsCriteria = executeQuery(strCriteriaDetailQuery);

                        if (rsCriteria.next())
                        {
                            lParamSeqNbr = rsCriteria.getLong(1);
                        }
                        else
                        {
                            log.fatal("Sequence no not generated");
                            throw new EElixirException("p4528");
                        }

                        strCriteriaDetailQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_DETAIL_INSERT);
                        log.debug("--3-InsetCriteriaParams() insert query is "+strCriteriaDetailQuery);
                        log.debug("OTHER_BENEFIT_DETAIL_INSERT");
                        pstmtCriteriaInsert = getPreparedStatement(strCriteriaDetailQuery);
                        log.debug("--3-InsetCriteriaParams()-getBonusHdrSeqNbr:"+a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
                        pstmtCriteriaInsert.setLong(1, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
                        log.debug("--3-InsetCriteriaParams()-lParamSeqNbr:"+lParamSeqNbr);
                        pstmtCriteriaInsert.setLong(2, lParamSeqNbr);
                        pstmtCriteriaInsert.setInt(3, DataConstants.BONUS_PARAMETER);
                        pstmtCriteriaInsert.setString(4, a_oOtherBenefitResult.getBonusParamId());
                      // Arun_FSOtherBenefitsTargetTab_REL8.1 Start
                        if(a_oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
                        {
                          pstmtCriteriaInsert.setNull(5,Types.SMALLINT);
                        }
                        else
                        {
                        pstmtCriteriaInsert.setShort(5, a_oOtherBenefitResult.getAmtPerc().shortValue());
                        }
                        if(a_oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
                        {
                           pstmtCriteriaInsert.setNull(6, Types.DOUBLE);
                        }
                        else
                        {
                        if (a_oOtherBenefitResult.getUnits() != null)
                        {
                            pstmtCriteriaInsert.setDouble(6, a_oOtherBenefitResult.getUnits().doubleValue());
                        }
                        else
                        {
                            pstmtCriteriaInsert.setNull(6, Types.DOUBLE);
                        }
                        }
                     //  Arun_FSOtherBenefitsTargetTab_REL8.1 End
                        pstmtCriteriaInsert.setNull(7, Types.DOUBLE);
                        pstmtCriteriaInsert.setNull(8, Types.DOUBLE);
                        pstmtCriteriaInsert.setDouble(9, Double.parseDouble(dBonusRate[i]));
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Starts
                        pstmtCriteriaInsert.setString(10, a_oOtherBenefitResult.getUserId());
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Ends
                        executeUpdate(pstmtCriteriaInsert);

                        for (int j = 0; j < alCriteriaParameters.size(); j++)
                        {
                            oCriteriaParameterResult = (CriteriaParameterResult) alCriteriaParameters.get(j);
                            pstmtCriteriaInsert = getPreparedStatement(strCriteriaDetailQuery);
                            log.debug("--3-InsetCriteriaParams()-getBonusHdrSeqNbr:"+a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
                            pstmtCriteriaInsert.setLong(1, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
                            log.debug("--3-InsetCriteriaParams()-lParamSeqNbr:"+lParamSeqNbr);
                            pstmtCriteriaInsert.setLong(2, lParamSeqNbr);
                            pstmtCriteriaInsert.setInt(3, DataConstants.CRITERIA_PARAMETER);
                            pstmtCriteriaInsert.setString(4, oCriteriaParameterResult.getBaseParamId());
                            pstmtCriteriaInsert.setNull(5, Types.DOUBLE);
                            pstmtCriteriaInsert.setNull(6, Types.DOUBLE);
                            pstmtCriteriaInsert.setDouble(7, Double.parseDouble(oCriteriaParameterResult.getDFrom()[i]));
                            pstmtCriteriaInsert.setDouble(8, Double.parseDouble(oCriteriaParameterResult.getDTo()[i]));
                            pstmtCriteriaInsert.setNull(9, Types.DOUBLE);
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Starts
                            pstmtCriteriaInsert.setString(10, a_oOtherBenefitResult.getUserId());
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Ends
                            executeUpdate(pstmtCriteriaInsert);
                        }
                    }
                }
            }
            return lParamSeqNbr;
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "createBonus", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        } finally
        {
            try
            {
                if (pstmtCriteriaInsert != null)
                {
                    pstmtCriteriaInsert.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
        }
    }

    public void deleteCriteriaParams(OtherBenefitResult a_oOtherBenefitResult) throws EElixirException
    {
        ArrayList alCriteriaParameters = null;
        PreparedStatement pstmtCriteriaInsert = null;
        CriteriaParameterResult oCriteriaParameterResult = null;

        try
        {
            alCriteriaParameters = a_oOtherBenefitResult.getCriParamDetails();

            String[] dBonusRate = a_oOtherBenefitResult.getBonusRate();
            String[] strStatusFlag = a_oOtherBenefitResult.getParamStatusFlag();
            String[] strParamSeqNbr = a_oOtherBenefitResult.getParamSeqNbr();
            String strCriteriaDetailQuery = null;
            ResultSet rsCriteria = null;

            if (alCriteriaParameters != null)
            {
                for (int i = 0; i < dBonusRate.length; i++)
                {
                    if(strStatusFlag[i].equalsIgnoreCase(DataConstants.DELETE_MODE))
                    {
                      /*Has modified By Arun for Delete problem in Parameters*/
	                   	strCriteriaDetailQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_BONUS_DELETE);
                    	pstmtCriteriaInsert = getPreparedStatement(strCriteriaDetailQuery);
                    	pstmtCriteriaInsert.setLong(1, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
                    	pstmtCriteriaInsert.setLong(2, Long.parseLong(strParamSeqNbr[i]));
                    	pstmtCriteriaInsert.setInt(3, DataConstants.TARGET_PARAMETER);
                    	executeUpdate(pstmtCriteriaInsert);
                    }
                }
            }
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "createBonus", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        } finally
        {
            try
            {
                if (pstmtCriteriaInsert != null)
                {
                    pstmtCriteriaInsert.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
        }
    }
    public void updateCriteriaParams(OtherBenefitResult a_oOtherBenefitResult) throws EElixirException
    {
        ArrayList alCriteriaParameters = null;
        PreparedStatement pstmtCriteriaInsert = null;
        CriteriaParameterResult oCriteriaParameterResult = null;

        try
        {
            alCriteriaParameters = a_oOtherBenefitResult.getCriParamDetails();

            String[] dBonusRate = a_oOtherBenefitResult.getBonusRate();
            String[] strStatusFlag = a_oOtherBenefitResult.getParamStatusFlag();
            String[] strParamSeqNbr = a_oOtherBenefitResult.getParamSeqNbr();
            String strCriteriaDetailQuery = null;
            ResultSet rsCriteria = null;

            if (alCriteriaParameters != null)
            {
                for (int i = 0; i < dBonusRate.length; i++)
                {
                    if(strStatusFlag[i].equalsIgnoreCase(DataConstants.UPDATE_MODE))
                    {
	                    strCriteriaDetailQuery = getSQLString("Update", CHMConstants.OTHER_BENEFIT_BONUS_UPDATE);
	                    strCriteriaDetailQuery = strCriteriaDetailQuery + " AND LPARAMSEQNBR= ?  ";
	                    pstmtCriteriaInsert = getPreparedStatement(strCriteriaDetailQuery);
	                    //Aru Target Tab Start
	                    if(a_oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
                        {
                           pstmtCriteriaInsert.setNull(1,Types.SMALLINT);
                        }
	                    else
	                    {
	                    pstmtCriteriaInsert.setShort(1, a_oOtherBenefitResult.getAmtPerc().shortValue());
	                    }
	                    if(a_oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
                        {
	                      pstmtCriteriaInsert.setNull(2,Types.SMALLINT);
                        }
	                    else
	                    {
	                    if (a_oOtherBenefitResult.getUnits() != null)
	                    {
	                        pstmtCriteriaInsert.setDouble(2, a_oOtherBenefitResult.getUnits().doubleValue());
	                      }
	                      else
	                    {
	                        pstmtCriteriaInsert.setNull(2, Types.DOUBLE);
	                      }
	                    }
	                    pstmtCriteriaInsert.setDouble(3, Double.parseDouble(dBonusRate[i]));
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Starts
	                    pstmtCriteriaInsert.setString(4, a_oOtherBenefitResult.getUserId());
	                    pstmtCriteriaInsert.setLong(5, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
	                    pstmtCriteriaInsert.setInt(6, DataConstants.BONUS_PARAMETER);
	                    pstmtCriteriaInsert.setString(7, a_oOtherBenefitResult.getBonusParamId());
	                    pstmtCriteriaInsert.setLong(8, Long.parseLong(strParamSeqNbr[i]));
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Ends
	                    executeUpdate(pstmtCriteriaInsert);

	                    for (int j = 0; j < alCriteriaParameters.size(); j++)
	                    {
	                        strCriteriaDetailQuery = getSQLString("Update", CHMConstants.OTHER_BENEFIT_CRITERIA_UPDATE);
	                        oCriteriaParameterResult = (CriteriaParameterResult) alCriteriaParameters.get(j);
	                        pstmtCriteriaInsert = getPreparedStatement(strCriteriaDetailQuery);

	                        pstmtCriteriaInsert.setDouble(1, Double.parseDouble(oCriteriaParameterResult.getDFrom()[i]));
	                        pstmtCriteriaInsert.setDouble(2, Double.parseDouble(oCriteriaParameterResult.getDTo()[i]));
	                        pstmtCriteriaInsert.setString(3, a_oOtherBenefitResult.getUserId());
	                        pstmtCriteriaInsert.setLong(4, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
	                        pstmtCriteriaInsert.setLong(5, Long.parseLong(strParamSeqNbr[i]));
	                        pstmtCriteriaInsert.setInt(6, DataConstants.CRITERIA_PARAMETER);
	                        pstmtCriteriaInsert.setString(7, oCriteriaParameterResult.getBaseParamId());
	                        executeUpdate(pstmtCriteriaInsert);
	                    }
                    }
                }
            }
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "createBonus", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        } finally
        {
            try
            {
                if (pstmtCriteriaInsert != null)
                {
                    pstmtCriteriaInsert.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
        }
    }
    /**
     * Retrieves the OtherBenefit Record
     *
     * @param a_lBonusHdrSeqNbr
     *            Long
     * @return BonusResult
     * @throws EElixirException
     */
    public OtherBenefitResult getOtherBenefit(Long a_lBonusHdrSeqNbr) throws EElixirException
    {
        ResultSet rsSearchBonus = null;
        OtherBenefitResult oOtherBenefitResult = null;
        PreparedStatement pstmtSearchBonus = null;

        try
        {
        	
        	log.debug("Bonus_HDR_SELECT..in TRY BLOCK");
            String strSelectBonusQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_HDR_SELECT);

            pstmtSearchBonus = getPreparedStatement(strSelectBonusQuery);
            pstmtSearchBonus.setLong(1, a_lBonusHdrSeqNbr.longValue());
            rsSearchBonus = executeQuery(pstmtSearchBonus);
            oOtherBenefitResult = new OtherBenefitResult();

            while (rsSearchBonus.next())
            {
            	//Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Starts
            	oOtherBenefitResult.set_nPayIfColnNotPresent(rsSearchBonus.getShort("NPAYIFCOLNNOTPRESENT"));
            	//Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Ends
                oOtherBenefitResult.setBonusHdrSeqNbr(a_lBonusHdrSeqNbr);
                oOtherBenefitResult.setBonusType(rsSearchBonus.getString("STRBONUSTYPE"));
                oOtherBenefitResult.setBonusDesc(rsSearchBonus.getString("STRBONUSDESC"));
                oOtherBenefitResult.setEffFrom(DateUtil.retGregorian(rsSearchBonus.getTimestamp("DTEFFFROM")));
                oOtherBenefitResult.setEffTo(DateUtil.retGregorian(rsSearchBonus.getTimestamp("DTEFFTO")));
                oOtherBenefitResult.setChannelType(rsSearchBonus.getString("CCHANNELTYPE"));
                oOtherBenefitResult.setFreqOfCalc(new Short(rsSearchBonus.getShort("NFREQOFCALC")));
                oOtherBenefitResult.setFreqOfPmt(new Short(rsSearchBonus.getShort("NFREQOFPMT")));
                oOtherBenefitResult.setStartMonthCalc(new Short(rsSearchBonus.getShort("NSTARTMONTHCALC")));
                oOtherBenefitResult.setPmtDay(new Short(rsSearchBonus.getShort("NSTARTMONTHPMT")));
                oOtherBenefitResult.setIsTDSAppl(new Short(rsSearchBonus.getShort("NISTDSAPPL")));
                oOtherBenefitResult.setIsSTAppl(new Short(rsSearchBonus.getShort("NISSTAPPL")));
                if(rsSearchBonus.wasNull())//arun startTargetTab
                {
                 oOtherBenefitResult.setIsTargetBased(null);
                }
                else
                {
                oOtherBenefitResult.setIsTargetBased(new Short(rsSearchBonus.getShort("NISTARGETBASED")));
                }
                if(rsSearchBonus.wasNull())
                {
                 oOtherBenefitResult.setTargetProRata(null);
                }
                else
                {
				oOtherBenefitResult.setTargetProRata(new Short(rsSearchBonus.getShort("NTARGETPRORATA")));//shameem
                }//arun End TargetTab
				oOtherBenefitResult.setIsCampaign(new Short(rsSearchBonus.getShort("NISCAMPAIGN")));//shameem
				oOtherBenefitResult.setEndImmediate(new Short(rsSearchBonus.getShort("NENDIMMEDIATE")));//jayasimha
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
				double tempDouble=rsSearchBonus.getDouble("DCAPPERC");
				if(!rsSearchBonus.wasNull())
				{
					oOtherBenefitResult.setCapPercentage(new Double(tempDouble));
				}
				tempDouble=rsSearchBonus.getDouble("DHOLDPERC");
				if(!rsSearchBonus.wasNull())
				{
					oOtherBenefitResult.setHoldPercentage(new Double(tempDouble));
				}
				short tempShort = rsSearchBonus.getShort("NREPORTEES");
				if(!rsSearchBonus.wasNull())
				{
					oOtherBenefitResult.setReportees(new Short(tempShort));
				}
				tempShort = rsSearchBonus.getShort("NAGTTERMINATEDSTAT");
				if(!rsSearchBonus.wasNull())
				{
					oOtherBenefitResult.setAgentTerminatedStatus(new Short(tempShort));
				}
				tempShort = rsSearchBonus.getShort("NBONUSLEVEL");
				if(rsSearchBonus.wasNull())//Arun start target Tab
				{
					oOtherBenefitResult.setBonusLevel(null);
				}
				else
				{
				 oOtherBenefitResult.setBonusLevel(new Short(tempShort));
				}//Arun end TargetTab
				tempShort = rsSearchBonus.getShort("NYEARBASIS");
				if(!rsSearchBonus.wasNull())
				{
					oOtherBenefitResult.setYearBasis(new Short(tempShort));
				}
				oOtherBenefitResult.setPaidToAgentAgency(rsSearchBonus.getString("STRPAIDTO"));
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
//Jimmy_OtherBenefits_1.10_REL8.0 Starts
				tempShort = rsSearchBonus.getShort("NISINCREMENT");
				if(!rsSearchBonus.wasNull())
				{
					oOtherBenefitResult.setBonusPayOutMethod(new Short(tempShort));
				}
				oOtherBenefitResult.setMinRequirement(rsSearchBonus.getString("NMININCRVAL"));
//Jimmy_OtherBenefits_1.10_REL8.0 Ends
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Starts
				tempShort=rsSearchBonus.getShort("NRECALCULATE");
				if(!oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
				{
                if (rsSearchBonus.wasNull())
                {
                	oOtherBenefitResult.setRecalculationType(null);
                }
                else
                {
                	oOtherBenefitResult.setRecalculationType(new Short(tempShort));
                 }
				}
                else
                {
                  if (rsSearchBonus.wasNull())
                  {
                   	oOtherBenefitResult.setTgtRecalculationType(null);
                  }
                  else
                  {
                   	oOtherBenefitResult.setTgtRecalculationType(new Short(tempShort));
                  }
                }
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Ends
                tempShort = rsSearchBonus.getShort("NINSTALLMENT");
                if(!rsSearchBonus.wasNull())
                {
                    oOtherBenefitResult.setNoOfInstallment(new Short(tempShort));
                }

                oOtherBenefitResult.setAcctCd(rsSearchBonus.getString("STRACCTCD"));
                oOtherBenefitResult.setProvAcctCd(rsSearchBonus.getString("STRPROVACCTCD"));
                oOtherBenefitResult.setOSAcctCd(rsSearchBonus.getString("STROSACCTCD"));

                //Updated by
                oOtherBenefitResult.setUserId(rsSearchBonus.getString("STRUPDATEDBY"));
                oOtherBenefitResult.setTsDtUpdated(rsSearchBonus.getTimestamp("DTUPDATED"));
                oOtherBenefitResult.setIsDirty(DataConstants.DISPLAY_MODE);
                oOtherBenefitResult.setIsInclOrExclTgt(new Short(rsSearchBonus.getShort("NISINCLOREXCLTGT")));
                oOtherBenefitResult.setIsInclOrExclPmt(new Short(rsSearchBonus.getShort("NISINCLOREXCLPMT")));
                tempShort = rsSearchBonus.getShort("NFREQOFINST");
                if(!rsSearchBonus.wasNull())
                {
                    oOtherBenefitResult.setFreqOfInstallment(new Short(tempShort));
                }
//              Arun_FSOtherBenefitsTargetTab_REL8.1 Start
              tempShort=rsSearchBonus.getShort("NTGTBNSLEVEL");
              if(rsSearchBonus.wasNull())
              {
            	 oOtherBenefitResult.setTgtPlanAttachmentTo(null);
              }
              else
              {
            	oOtherBenefitResult.setTgtPlanAttachmentTo(new Short(tempShort));
              }

//            Arun_FSOtherBenefitsTargetTab_REL8.1 end
				// Santosh_Everest_Distribution Starts


				tempShort = rsSearchBonus.getShort("STRSEGMENTCD");
				if (rsSearchBonus.wasNull()) {
					oOtherBenefitResult.setSegmnetType(null);
				} else {
					oOtherBenefitResult.setSegmnetType(new Short(tempShort));
				}

				tempShort = rsSearchBonus.getShort("NSEGMENTAPPL");
				if (rsSearchBonus.wasNull()) {
					oOtherBenefitResult.setSegmnedOrNot(null);
				} else {
					oOtherBenefitResult.setSegmnedOrNot(new Short(tempShort));
				}

				// Santosh_Everest_Distribution Ends
				//Santosh_Ph_II Starts
                oOtherBenefitResult.setFreqOfProd(new Short(rsSearchBonus.getShort("NPRODNFREQ")));
				//Santosh_Ph_II Ends

                //Amid : modified for clawback Start

                oOtherBenefitResult.setClawbackPeriod(new Short(rsSearchBonus.getShort("NCLAWBACKPRD")));

                //Amid : modified for clawback End

              //SUNAINA_FS_TRAINING_INCENTIVE_STARTS
                short strPayout =  rsSearchBonus.getShort("NPMTFREQ");
                if (rsSearchBonus.wasNull()) {
    				oOtherBenefitResult.setHeldPayoutFreq(null);
    			} else {
    				oOtherBenefitResult.setHeldPayoutFreq(new Short(strPayout));
    			}
              //SUNAINA_FS_TRAINING_INCENTIVE_ENDS
                //Amid_Everest_Ph2_App_IP_Incentive_Scheme_Starts
                short goAssociationAppl =  rsSearchBonus.getShort("NISGOASSOCIATIONAPPL");
                if(rsSearchBonus.wasNull())
                {
                 oOtherBenefitResult.setIsGoAssociationAppl(null);              
                }
                else
                {
                 oOtherBenefitResult.setIsGoAssociationAppl(new Short(goAssociationAppl));
                }
                //Amid_Everest_Ph2_App_IP_Incentive_Scheme_Ends
             //Prabhat Modified for Flat Hold Payout
                
                double dFlatHoldPayout=rsSearchBonus.getDouble("NFLATHOLDPMTPERC");
                
                if(rsSearchBonus.wasNull())
                {
                	oOtherBenefitResult.setFlatHoldPayout(null);
                }
                else
                {
                	oOtherBenefitResult.setFlatHoldPayout(new Double(dFlatHoldPayout));
                }
                
//Added by Narendra CTS for Bonus screen
                short sBonusToTermAgt = rsSearchBonus.getShort("NBONUSTOTERMAGENT");
                if (rsSearchBonus.wasNull()) {
                	oOtherBenefitResult.setBonusToTermAgent(null);

    			} else {

                    oOtherBenefitResult.setBonusToTermAgent(new Short(sBonusToTermAgt));
                }

//End by Narendra CTS
             //Prabhat Modified for Flat Hold Payout
//              Anantha_Banca_Inc 
                
                double dCBPPerc=rsSearchBonus.getDouble("DCBPPERC");
                log.debug("BenefitDAX >>dCBPPerc"+dCBPPerc);
                
                if(rsSearchBonus.wasNull())
                {
                	oOtherBenefitResult.setCBPPerc(null);
                }
                else
                {
                	log.debug("BenefitDAX >>dCBPPerc"+dCBPPerc);
                	oOtherBenefitResult.setCBPPerc(new Double(dCBPPerc));
                }
                
//              Anantha_Banca_Inc
              //CR_OtherBenefit_sequence_Rel8.2_start
              tempShort=rsSearchBonus.getShort("nseqnbr");
              if(rsSearchBonus.wasNull())
              {
            	 oOtherBenefitResult.setSeqNbr(null);
              }
              else
              {
            	oOtherBenefitResult.setSeqNbr(new Short(tempShort));
              }
              //CR_OtherBenefit_sequence_Rel8.2_end
              
              
            //<Rel.  - Start : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
              oOtherBenefitResult.setCeipExclusion(Short.valueOf(rsSearchBonus.getShort("NCEIPEXCL")));
            //<Rel.  - End : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
              //start CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011 
  		    
              tempShort=rsSearchBonus.getShort("NUSERPERIOD");
              log.debug("SELECT Production User Defined period:"+tempShort);
              if(rsSearchBonus.wasNull()){
  				
  		    	oOtherBenefitResult.setPrdPeriod(null);
  			}
  		    else{
  		    	log.debug("INSIDE ELSE UserDefined");
  		    	oOtherBenefitResult.setPrdPeriod(Short.valueOf(tempShort));
  		    }
  		    //end CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011 
              
              //Added By Himanshu
              log.debug("Bonus_Hdr_select");
             /* if(rsSearchBonus.wasNull()){
            	  log.debug("Bonus_Hdr_select1");
  		    	oOtherBenefitResult.setnIsInclusioninACS(null);
  			}
  		    else{*/
  		    
  		    	 
  		    	 oOtherBenefitResult.setnIsInclusioninACS(new Short(rsSearchBonus.getShort("NISINCLOREXCLACS")));
  		    	log.debug("BenefitDAX >>dCBPPercINCLUSIONINACS====="+ rsSearchBonus.getShort("NISINCLOREXCLACS"));
  		//    }
              
              
             // if(rsSearchBonus.wasNull()){
            	//  log.debug("Bonus_Hdr_select3");
    				
    		    	//oOtherBenefitResult.setnbonusdescinACS(null);
    			//}
    		   // else{
    		    	//log.debug("Bonus_Hdr_select4");
    		    	 oOtherBenefitResult.setnbonusdescinACS(rsSearchBonus.getString("STRBONUSACSDESC"));
    		    	 log.debug("BenefitDAX >>dCBPPercBoNUSDESCRIPTION====="+ rsSearchBonus.getString("STRBONUSACSDESC"));
    		   // }
       
            }


            oOtherBenefitResult.setTgtCriParamUpdateCount(new Short("2"));//Arun_FSOtherBenefitsTargetTab_REL8.1
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
            	getApplicableAgentAgencyDtls(oOtherBenefitResult);
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
            getCriteriaParams(oOtherBenefitResult);
            getOtherBenefitApplicabilityDesignation(oOtherBenefitResult);
            getOtherBenefitCriteriaDesignation(oOtherBenefitResult);
            //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start
            getDesignationExclusion(oOtherBenefitResult);
            //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
            //Amid_MP/P_Incentive Scheme Starts
            getGlpDetails(oOtherBenefitResult);
            //Amid_MP/P_Incentive Scheme Ends
            
            if(oOtherBenefitResult.getIsTargetBased().intValue() == DataConstants.YES)
            {
                strSelectBonusQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_BONUS_RATE_SELECT);
                pstmtSearchBonus = getPreparedStatement(strSelectBonusQuery);
                pstmtSearchBonus.setLong(1, oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
                pstmtSearchBonus.setInt(2, DataConstants.TARGET_PARAMETER);
                rsSearchBonus = executeQuery(pstmtSearchBonus);
                while(rsSearchBonus.next())
                {
                    double dTargetValue = rsSearchBonus.getDouble("DRATE");
                    if(!rsSearchBonus.wasNull())
                    {
                        oOtherBenefitResult.setTargetValue(new Double(dTargetValue));
                    }
                }
            }
//          Arun_FSOtherBenefitsTargetTab_REL8.1 Start
            if(oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
			{
             String strRowColCountquery=null;
             strRowColCountquery=getSQLString("Select", CHMConstants.OTHER_BENEFIT_ROWCOUNT);
             pstmtSearchBonus = getPreparedStatement(strRowColCountquery);
             pstmtSearchBonus.setLong(1, oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
             rsSearchBonus = executeQuery(pstmtSearchBonus);
              int rowcount=0;
              int colcount=0;
             if(rsSearchBonus.next())
             {
              rowcount=rsSearchBonus.getInt("TGTROWCOUNT");
             }
             strRowColCountquery=getSQLString("Select", CHMConstants.OTHER_BENEFIT_COLCOUNT);
             pstmtSearchBonus = getPreparedStatement(strRowColCountquery);
             pstmtSearchBonus.setLong(1, oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
             rsSearchBonus = executeQuery(pstmtSearchBonus);
             if(rsSearchBonus.next())
             {
              colcount=rsSearchBonus.getInt("TGTCOLCOUNT");
             }
              oOtherBenefitResult.setRowCount(new Integer(rowcount));
              oOtherBenefitResult.setColumnCount(new Integer(colcount));
              getOtherBenefitOfficeMultiplierDtls(oOtherBenefitResult);
              getOtherBenefitTgtCriteriaParamDtls(oOtherBenefitResult);
              getOtherBenefitTargetParamDetails(oOtherBenefitResult);
			}
            else
            {
             oOtherBenefitResult.setRowCount(null);
             oOtherBenefitResult.setColumnCount(null);
             oOtherBenefitResult.setOffMultiplierFrom(null);
             oOtherBenefitResult.setOffMultiplierTo(null);
             oOtherBenefitResult.setOffMultiplier(null);
            }
  //   Arun_FSOtherBenefitsTargetTab_REL8.1 end

        return oOtherBenefitResult;
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw new EElixirException(eex, "P4538");
        } finally
        {
            try
            {
                if (rsSearchBonus != null)
                {
                    rsSearchBonus.close();
                }

                if (pstmtSearchBonus != null)
                {
                    pstmtSearchBonus.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }

    public void getOtherBenefitApplicabilityDesignation(OtherBenefitResult oOtherBenefitResult) throws EElixirException
    {

        PreparedStatement psSelect = null;
        ResultSet rsSelect = null;
        OtherBenefitAgentDetail oOtherBenefitAgentDetail = null;
        ArrayList alDesgnDtls = new ArrayList();
        String[] strApplDesgn = null;
        try
        {
            String strQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_APPL_DESGN_SELECT);
            psSelect = getPreparedStatement(strQuery);
            psSelect.setLong(1, oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
            rsSelect = executeQuery(psSelect);

            while (rsSelect.next())
            {
                alDesgnDtls.add(rsSelect.getString("STRDESGNCD"));
            }
            if(alDesgnDtls.size() > 0)
            {
                strApplDesgn = new String[alDesgnDtls.size()];
                for(int i=0;i<alDesgnDtls.size();i++)
                {
                    strApplDesgn[i] = (String)alDesgnDtls.get(i);
                }
                oOtherBenefitResult.setApplDesgn(strApplDesgn);
            }
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw eex;
        }
        finally
        {
            try
            {
                if (psSelect != null)
                {
                    psSelect.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }
    public void getOtherBenefitCriteriaDesignation(OtherBenefitResult oOtherBenefitResult) throws EElixirException
    {

        PreparedStatement psSelect = null;
        ResultSet rsSelect = null;
        OtherBenefitAgentDetail oOtherBenefitAgentDetail = null;
        ArrayList alDesgnDtls = new ArrayList();
        String[] strCriDesgn = null;
//Jimmy_OtherBenefits_1.4_REL8.0 Starts
        ArrayList alIsMnylAgt = new ArrayList();
        String[] _strIsMnylAgt = null;
        short tempShort;
        try
        {
            String strQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_CRI_DESGN_SELECT);
            psSelect = getPreparedStatement(strQuery);
            psSelect.setLong(1, oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
            rsSelect = executeQuery(psSelect);

            while (rsSelect.next())
            {
                alDesgnDtls.add(rsSelect.getString("STRDESGNCD"));
                tempShort = rsSelect.getShort("NISMNYLAGT");
                if(!rsSelect.wasNull())
                {
                	alIsMnylAgt.add(Short.toString(tempShort));
                }
                else
                {
                	alIsMnylAgt.add(" ");
                }

            }
            if(alDesgnDtls.size() >0)
            {
            	strCriDesgn = new String[alDesgnDtls.size()];
                for(int i=0;i<alDesgnDtls.size();i++)
                {
                	strCriDesgn[i] = (String)alDesgnDtls.get(i);

                }
                oOtherBenefitResult.setCriDesgn(strCriDesgn);
                }
            if(alIsMnylAgt.size() >0)
            {
            	_strIsMnylAgt = new String[alIsMnylAgt.size()];
                for(int i=0;i<alIsMnylAgt.size();i++)
                {
                	_strIsMnylAgt[i] =(String)alIsMnylAgt.get(i);

            }
                oOtherBenefitResult.setIsMnylAgent(_strIsMnylAgt);
            }
//Jimmy_OtherBenefits_1.4_REL8.0 Ends
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw eex;
        }
        finally
        {
            try
            {
                if (psSelect != null)
                {
                    psSelect.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }
//  Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start 
    public void getDesignationExclusion(OtherBenefitResult oOtherBenefitResult) throws EElixirException
    {
    	
        PreparedStatement psSelect = null;
        ResultSet rsSelect = null;       
        ArrayList alDesgCd = new ArrayList();
        String[] strDesgCd = null;
        ArrayList alIsInclOrExcl = new ArrayList();
        String[] strIsInclOrExcl = null;
        ArrayList alstrBaseParamId = new ArrayList();
        String[] strstrBaseParamId = null;
        short tempShort;
        try
        {	
            String strQuery = getSQLString("Select", CHMConstants.DESIGNATION_EXCLUSION_SELECT);            
            psSelect = getPreparedStatement(strQuery);
            psSelect.setLong(1, oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
            rsSelect = executeQuery(psSelect);
            while (rsSelect.next())
            {
            	alstrBaseParamId.add(rsSelect.getString("STRBASEPARAMID"));
            	alDesgCd.add(rsSelect.getString("STRDESGNCD"));  
                tempShort = rsSelect.getShort("NISINCLOREXCL");            
                if(!rsSelect.wasNull())
                {
                	alIsInclOrExcl.add(Short.toString(tempShort));            
                }
                else
                {
                	alIsInclOrExcl.add(" ");
                }

            }
            if(alDesgCd.size() >0)
            {
            	strDesgCd = new String[alDesgCd.size()];
                for(int i=0;i<alDesgCd.size();i++)
                {
                	strDesgCd[i] = (String)alDesgCd.get(i);
                }
                oOtherBenefitResult.setDesgCd(strDesgCd);
             }
            if(alstrBaseParamId.size() >0)
            {
            	strstrBaseParamId = new String[alstrBaseParamId.size()];
                for(int i=0;i<alstrBaseParamId.size();i++)
                {
                	strstrBaseParamId[i] =(String)alstrBaseParamId.get(i);
                }
                oOtherBenefitResult.setBaseParamId(strstrBaseParamId);
            }
            if(alIsInclOrExcl.size() >0)
            {
            	strIsInclOrExcl = new String[alIsInclOrExcl.size()];
                for(int i=0;i<alIsInclOrExcl.size();i++)
                {
                	strIsInclOrExcl[i] =(String)alIsInclOrExcl.get(i);
                }
                oOtherBenefitResult.setIsInclOrExcl(strIsInclOrExcl);
            }
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getDesignationExclusion", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p9701");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getDesignationExclusion", "EElixirException " + eex.getMessage());
            throw eex;
        }
        finally
        {
            try
            {
                if (psSelect != null)
                {
                    psSelect.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getDesignationExclusion", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p9701");
            }
        }
    }
    //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
    //Amid_MP/P_Incentive Scheme Starts
    public void getGlpDetails(OtherBenefitResult oOtherBenefitResult) throws EElixirException
    {
    	
        PreparedStatement psSelect = null;
        ResultSet rsSelect = null;       
        ArrayList alScoreType = new ArrayList();
        String[] strScoreTyped = null;
        ArrayList alGlpWeightage = new ArrayList();
        String[] strGlpWeightage = null;
        ArrayList alFrom = new ArrayList();
        String[] strFrom = null;
        ArrayList alTo = new ArrayList();
        String[] strTo = null;
        ArrayList alValue = new ArrayList();
        String[] strValue = null;
        short tempShort;
        double tempDouble;
        try
        {	
            String strQuery = getSQLString("Select", CHMConstants.GLP_SELECT);            
            psSelect = getPreparedStatement(strQuery);
            psSelect.setLong(1, oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
            rsSelect = executeQuery(psSelect);
            while (rsSelect.next())
            {     
                tempShort = rsSelect.getShort("NSCORETYPE");            
                if(!rsSelect.wasNull())
                {
                	alScoreType.add(Short.toString(tempShort));            
                }
                else
                {
                	alScoreType.add(" ");
                }
               
                tempDouble = rsSelect.getDouble("NWEIGHTAGE");  
                if(!rsSelect.wasNull())
                {
                	alGlpWeightage.add(Double.toString(tempDouble));            
                }
                else
                {
                	alGlpWeightage.add(" ");
                }
                tempDouble = rsSelect.getDouble("DFROM"); 
                if(!rsSelect.wasNull())
                {
                	alFrom.add(Double.toString(tempDouble));            
                }
                else
                {
                	alFrom.add(" ");
                }
                tempDouble = rsSelect.getDouble("DTO"); 
                if(!rsSelect.wasNull())
                {
                	alTo.add(Double.toString(tempDouble));            
                }
                else
                {
                	alTo.add(" ");
                }
                tempDouble = rsSelect.getDouble("NVALUE"); 
                if(!rsSelect.wasNull())
                {
                	alValue.add(Double.toString(tempDouble));            
                }
                else
                {
                	alValue.add(" ");
                }

            }
            if(alScoreType.size() >0)
            {
            	strScoreTyped = new String[alScoreType.size()];
                for(int i=0;i<alScoreType.size();i++)
                {
                	strScoreTyped[i] = (String)alScoreType.get(i);
                }
                oOtherBenefitResult.setScoreType(strScoreTyped);
             }
            if(alGlpWeightage.size() >0)
            {
            	strGlpWeightage = new String[alGlpWeightage.size()];
                for(int i=0;i<alGlpWeightage.size();i++)
                {
                	strGlpWeightage[i] =(String)alGlpWeightage.get(i);
                }
                oOtherBenefitResult.setGlpWeightage(strGlpWeightage);
            }
            if(alFrom.size() >0)
            {
            	strFrom= new String[alFrom.size()];
                for(int i=0;i<alFrom.size();i++)
                {
                	strFrom[i] =(String)alFrom.get(i);
                }
                oOtherBenefitResult.setFrom(strFrom);
            }
            if(alTo.size() >0)
            {
            	strTo= new String[alTo.size()];
                for(int i=0;i<alTo.size();i++)
                {
                	strTo[i] =(String)alTo.get(i);
                }
                oOtherBenefitResult.setTo(strTo);
            }
            if(alValue.size() >0)
            {
            	strValue= new String[alValue.size()];
                for(int i=0;i<alValue.size();i++)
                {
                	strValue[i] =(String)alValue.get(i);
                }
                oOtherBenefitResult.setValue(strValue);
            }
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getGlpDetails", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p9701");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getGlpDetails", "EElixirException " + eex.getMessage());
            throw eex;
        }
        finally
        {
            try
            {
                if (psSelect != null)
                {
                    psSelect.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getGlpDetails", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p9701");
            }
        }
    }
    //Amid_MP/P_Incentive Scheme Ends

    public void getCriteriaParams(OtherBenefitResult a_oOtherBenefitResult) throws EElixirException
    {
        ResultSet rsSearchBonus = null;
        ResultSet rsSearchCriteria = null;
        PreparedStatement pstmtSearchBonus = null;
        PreparedStatement psSearchCriteria = null;
        ArrayList alCriteriaParamDetails = new ArrayList();
        CriteriaParameterResult oCriteriaParameterResult = null;
        String strBaseParamIds = null;
        String strBaseParamNames = null;
        ArrayList alRateFrom = null;
        ArrayList alRateTo = null;

        try
        {
            String strSelectBonusQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_DTL_SELECT);

            pstmtSearchBonus = getPreparedStatement(strSelectBonusQuery);
            pstmtSearchBonus.setLong(1, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
            pstmtSearchBonus.setInt(2, DataConstants.CRITERIA_PARAMETER);
            rsSearchBonus = executeQuery(pstmtSearchBonus);

            while (rsSearchBonus.next())
            {
                if (strBaseParamIds == null)
                {
                    strBaseParamIds = rsSearchBonus.getString("STRBASEPARAMID");
                    strBaseParamNames = rsSearchBonus.getString("STRBASEPARAMDESC");
                } else
                {
                    strBaseParamIds = strBaseParamIds + "||" + rsSearchBonus.getString("STRBASEPARAMID");
                    strBaseParamNames = strBaseParamNames + "||" + rsSearchBonus.getString("STRBASEPARAMDESC");
                }

                a_oOtherBenefitResult.setCriParamIds(strBaseParamIds);
                a_oOtherBenefitResult.setCriParamNames(strBaseParamNames);
                oCriteriaParameterResult = new CriteriaParameterResult();

                oCriteriaParameterResult.setBaseParamId(rsSearchBonus.getString("STRBASEPARAMID"));
                strSelectBonusQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_RATE_SELECT);
                psSearchCriteria = getPreparedStatement(strSelectBonusQuery);
                psSearchCriteria.setLong(1, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
                psSearchCriteria.setInt(2, DataConstants.CRITERIA_PARAMETER);
                psSearchCriteria.setString(3, oCriteriaParameterResult.getBaseParamId());
                rsSearchCriteria = executeQuery(psSearchCriteria);
                alRateFrom = new ArrayList();
                alRateTo = new ArrayList();

                while (rsSearchCriteria.next())
                {
                    alRateFrom.add(rsSearchCriteria.getString("DFROM"));
                    alRateTo.add(rsSearchCriteria.getString("DTO"));
                }

                String[] dRateFrom = new String[alRateFrom.size()];

                for (int i = 0; i < alRateFrom.size(); i++)
                {
                    dRateFrom[i] = (String) alRateFrom.get(i);
                }

                String[] dRateTo = new String[alRateTo.size()];

                for (int i = 0; i < alRateTo.size(); i++)
                {
                    dRateTo[i] = (String) alRateTo.get(i);
                }

                oCriteriaParameterResult.setDFrom(dRateFrom);
                oCriteriaParameterResult.setDTo(dRateTo);
                alCriteriaParamDetails.add(oCriteriaParameterResult);
            }

            a_oOtherBenefitResult.setCriParamDetails(alCriteriaParamDetails);

            strSelectBonusQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_BONUS_RATE_SELECT);
            pstmtSearchBonus = getPreparedStatement(strSelectBonusQuery);
            pstmtSearchBonus.setLong(1, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
            pstmtSearchBonus.setInt(2, DataConstants.BONUS_PARAMETER);
            rsSearchBonus = executeQuery(pstmtSearchBonus);
            alRateFrom = new ArrayList();
            alRateTo = new ArrayList();

            while (rsSearchBonus.next())
            {
                a_oOtherBenefitResult.setBonusParamId(rsSearchBonus.getString("STRBASEPARAMID"));
                a_oOtherBenefitResult.setAmtPerc(new Short(rsSearchBonus.getShort("NAMTPERC")));

                double nUnits = rsSearchBonus.getDouble("NUNITS");

                if (rsSearchBonus.wasNull())
                {
                    a_oOtherBenefitResult.setUnits(null);
                } else
                {
                    a_oOtherBenefitResult.setUnits(new Double(nUnits));
                }

                alRateFrom.add(rsSearchBonus.getString("DRATE"));
                alRateTo.add(rsSearchBonus.getString("LPARAMSEQNBR"));
            }

            String[] dBonusRate = new String[alRateFrom.size()];
            String[] lParamSeqNbr = new String[alRateTo.size()];
            String[] strPramstatus=new String[alRateFrom.size()];//CR_OtherBenefit_sequence_Rel8.2_start
            for (int i = 0; i < alRateFrom.size(); i++)
            {
                dBonusRate[i] = (String) alRateFrom.get(i);
                lParamSeqNbr[i] = (String) alRateTo.get(i);
                strPramstatus[i]=DataConstants.UPDATE_MODE;//CR_OtherBenefit_sequence_Rel8.2_start
            }

            a_oOtherBenefitResult.setBonusRate(dBonusRate);
            a_oOtherBenefitResult.setParamSeqNbr(lParamSeqNbr);
            a_oOtherBenefitResult.setParamStatusFlag(strPramstatus);//CR_OtherBenefit_sequence_Rel8.2_start
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw new EElixirException(eex, "P4538");
        } finally
        {
            try
            {
                if (rsSearchBonus != null)
                {
                    rsSearchBonus.close();
                }

                if (pstmtSearchBonus != null)
                {
                    pstmtSearchBonus.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }

    public void updateOtherBenefit(OtherBenefitResult a_oOtherBenefitDetails) throws EElixirException
    {
        PreparedStatement pstmtUpdateOtherBenefit = null;

        try
        {
            String strUpdateQuery = getSQLString("Update", CHMConstants.OTHER_BENEFIT_HDR_UPDATE);
            pstmtUpdateOtherBenefit = getPreparedStatement(strUpdateQuery);

            pstmtUpdateOtherBenefit.setString(1, a_oOtherBenefitDetails.getBonusDesc());
            pstmtUpdateOtherBenefit.setString(2, a_oOtherBenefitDetails.getBonusType());
            pstmtUpdateOtherBenefit.setTimestamp(3, DateUtil.retTimestamp(a_oOtherBenefitDetails.getEffFrom()));
            pstmtUpdateOtherBenefit.setTimestamp(4, DateUtil.retTimestamp(a_oOtherBenefitDetails.getEffTo()));
            pstmtUpdateOtherBenefit.setString(5, a_oOtherBenefitDetails.getChannelType());
            pstmtUpdateOtherBenefit.setShort(6, a_oOtherBenefitDetails.getFreqOfCalc().shortValue());
            pstmtUpdateOtherBenefit.setShort(7, a_oOtherBenefitDetails.getFreqOfPmt().shortValue());
            pstmtUpdateOtherBenefit.setShort(8, a_oOtherBenefitDetails.getStartMonthCalc().shortValue());
            pstmtUpdateOtherBenefit.setShort(9, a_oOtherBenefitDetails.getPmtDay().shortValue());
            pstmtUpdateOtherBenefit.setShort(10, a_oOtherBenefitDetails.getIsSTAppl().shortValue());
            pstmtUpdateOtherBenefit.setShort(11, a_oOtherBenefitDetails.getIsTDSAppl().shortValue());
            pstmtUpdateOtherBenefit.setShort(12, a_oOtherBenefitDetails.getIsTargetBased().shortValue());
            if(a_oOtherBenefitDetails.getNoOfInstallment() != null)
            {
                pstmtUpdateOtherBenefit.setShort(13, a_oOtherBenefitDetails.getNoOfInstallment().shortValue());
            }
            else
            {
                pstmtUpdateOtherBenefit.setNull(13, Types.INTEGER);
            }

            if(a_oOtherBenefitDetails.getFreqOfInstallment() != null)
            {
                pstmtUpdateOtherBenefit.setShort(14, a_oOtherBenefitDetails.getFreqOfInstallment().shortValue());
            }
            else
            {
                pstmtUpdateOtherBenefit.setNull(14, Types.INTEGER);
            }

            pstmtUpdateOtherBenefit.setString(15, a_oOtherBenefitDetails.getUserId());

            //shameem
			if(a_oOtherBenefitDetails.getTargetProRata() != null)
			{
				pstmtUpdateOtherBenefit.setLong(16, a_oOtherBenefitDetails.getTargetProRata().shortValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(16, Types.SMALLINT);
			}

			if(a_oOtherBenefitDetails.getIsCampaign() != null)
			{
				pstmtUpdateOtherBenefit.setLong(17, a_oOtherBenefitDetails.getIsCampaign().shortValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(17, Types.SMALLINT);
			}


			if(a_oOtherBenefitDetails.getEndImmediate() != null)
			{
				pstmtUpdateOtherBenefit.setLong(18, a_oOtherBenefitDetails.getEndImmediate().shortValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(18, Types.SMALLINT);
			}
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
			if(a_oOtherBenefitDetails.getCapPercentage() != null)
			{
				pstmtUpdateOtherBenefit.setDouble(19,a_oOtherBenefitDetails.getCapPercentage().doubleValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(19,Types.DOUBLE);
			}
			if(a_oOtherBenefitDetails.getHoldPercentage() != null)
			{
				pstmtUpdateOtherBenefit.setDouble(20,a_oOtherBenefitDetails.getHoldPercentage().doubleValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(20,Types.DOUBLE);
			}
			if(a_oOtherBenefitDetails.getReportees() != null)
			{
				pstmtUpdateOtherBenefit.setShort(21,a_oOtherBenefitDetails.getReportees().shortValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(21,Types.SMALLINT);
			}
			if(a_oOtherBenefitDetails.getAgentTerminatedStatus() != null)
			{
				pstmtUpdateOtherBenefit.setShort(22,a_oOtherBenefitDetails.getAgentTerminatedStatus().shortValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(22,Types.SMALLINT);
			}
			if(a_oOtherBenefitDetails.getBonusLevel() != null)
			{
				pstmtUpdateOtherBenefit.setShort(23,a_oOtherBenefitDetails.getBonusLevel().shortValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(23,Types.SMALLINT);
			}
			if(a_oOtherBenefitDetails.getYearBasis() != null)
			{
				pstmtUpdateOtherBenefit.setShort(24,a_oOtherBenefitDetails.getYearBasis().shortValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(24,Types.SMALLINT);
			}
			pstmtUpdateOtherBenefit.setString(25,a_oOtherBenefitDetails.getPaidToAgentAgency());
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
//Jimmy_OtherBenefits_1.10_REL8.0 Starts
			if(a_oOtherBenefitDetails.getBonusPayOutMethod() != null)
			{
				pstmtUpdateOtherBenefit.setShort(26,a_oOtherBenefitDetails.getBonusPayOutMethod().shortValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(26,Types.SMALLINT);
			}
			if(a_oOtherBenefitDetails.getMinRequirement() != null)
			{
				pstmtUpdateOtherBenefit.setDouble(27,new Double(a_oOtherBenefitDetails.getMinRequirement()).doubleValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(27,Types.DOUBLE);
			}
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Starts
		  if(a_oOtherBenefitDetails.getBonusType().equals(DataConstants.AAP_BT))//Arun targetTab start
	      {
			  if (a_oOtherBenefitDetails.getTgtRecalculationType() != null)
	          {
				  pstmtUpdateOtherBenefit.setShort(28, a_oOtherBenefitDetails.getTgtRecalculationType().shortValue());
	          }
			  else
			  {
				 pstmtUpdateOtherBenefit.setNull(28, Types.SMALLINT);
			  }
	      }
		  else
		  {
			if (a_oOtherBenefitDetails.getRecalculationType() != null)
            {
				pstmtUpdateOtherBenefit.setShort(28, a_oOtherBenefitDetails.getRecalculationType().shortValue());
            }
            else
            {
            	pstmtUpdateOtherBenefit.setNull(28, Types.SMALLINT);
            }
		  }//Arun TargetTab end
//Jimmy_OtherBenefits_1.10_REL8.0 Ends
		  if(a_oOtherBenefitDetails.getBonusType().equals(DataConstants.AAP_BT))//Arun targetTab start
	      {
			 if(a_oOtherBenefitDetails.getTgtPlanAttachmentTo()!=null)
			 {
				 pstmtUpdateOtherBenefit.setShort(29,a_oOtherBenefitDetails.getTgtPlanAttachmentTo().shortValue());
			 }
			 else
			 {
				 pstmtUpdateOtherBenefit.setNull(29, Types.SMALLINT);
			 }
	      }
		  else
		  {
			  pstmtUpdateOtherBenefit.setNull(29, Types.SMALLINT);
		  }
         // CR_OtherBenefit_sequence_Rel8.2_start
			if (a_oOtherBenefitDetails.getSeqNbr() != null)
            {
			 	pstmtUpdateOtherBenefit.setShort(30, a_oOtherBenefitDetails.getSeqNbr().shortValue());
		    }
          else
          {
        	pstmtUpdateOtherBenefit.setNull(30, Types.SMALLINT);
          }

        			// Santosh_Everest_Distribution Starts

			if (a_oOtherBenefitDetails.getSegmnetType() != null) {
				pstmtUpdateOtherBenefit.setShort(31, a_oOtherBenefitDetails
						.getSegmnetType().shortValue());
			} else {
				pstmtUpdateOtherBenefit.setNull(31, Types.SMALLINT);
			}

			if (a_oOtherBenefitDetails.getSegmnedOrNot() != null) {
				pstmtUpdateOtherBenefit.setShort(32, a_oOtherBenefitDetails
						.getSegmnedOrNot().shortValue());
			} else {
				pstmtUpdateOtherBenefit.setNull(32, Types.SMALLINT);
			}

			// Santosh_Everest_Distribution Ends

			//Santosh_Ph_II Starts //Removed MAndatory check Ananth_Feb_SIT
			
			if (a_oOtherBenefitDetails.getFreqOfProd() != null) {
				pstmtUpdateOtherBenefit.setShort(33, a_oOtherBenefitDetails.getFreqOfProd().shortValue());
			} else {
				pstmtUpdateOtherBenefit.setNull(33, Types.SMALLINT);
			}	
			
		
			//Santosh_Ph_II Ends
			//Amid : modified for clawback Start

			if (a_oOtherBenefitDetails.getClawbackPeriod() != null) {
				pstmtUpdateOtherBenefit.setShort(34, a_oOtherBenefitDetails
						.getClawbackPeriod().shortValue());
			} else {
				pstmtUpdateOtherBenefit.setNull(34, Types.SMALLINT);
			}

			//Amid : Modified for clawback End

			//SUNAINA_FS_TRAINING_INCENTIVE_STARTS
			if (a_oOtherBenefitDetails.getHeldPayoutFreq() != null) {
				pstmtUpdateOtherBenefit.setShort(35, a_oOtherBenefitDetails
						.getHeldPayoutFreq().shortValue());
			} else {
				pstmtUpdateOtherBenefit.setNull(35, Types.SMALLINT);
			}
			//SUNAINA_FS_TRAINING_INCENTIVE_ENDS
			//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Starts
			if (a_oOtherBenefitDetails.getIsGoAssociationAppl() != null) {
				pstmtUpdateOtherBenefit.setShort(36, a_oOtherBenefitDetails
						.getIsGoAssociationAppl().shortValue());
			} else {
				pstmtUpdateOtherBenefit.setNull(36, Types.SMALLINT);
			}
			//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Ends

			//Prabhat_FS_Everest02 FlatHoldPayout start
			
			if(a_oOtherBenefitDetails.getFlatHoldPayout()!=null)
			{
				pstmtUpdateOtherBenefit.setDouble(37,a_oOtherBenefitDetails.getFlatHoldPayout().doubleValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(37, Types.DOUBLE);
			}
			
			//Prabhat_FS_Everest02 FlatHoldPayout start 
			
//			 Anantha_Banca_Inc start
			
			if(a_oOtherBenefitDetails.getCBPPerc()!=null)
			{
				pstmtUpdateOtherBenefit.setDouble(38,a_oOtherBenefitDetails.getCBPPerc().doubleValue());
			}
			else
			{
				pstmtUpdateOtherBenefit.setNull(38, Types.DOUBLE);
			}
			
//Added by Narendra CTS for Bonus screen

			if (a_oOtherBenefitDetails.getBonusToTermAgent() != null) {
				pstmtUpdateOtherBenefit.setShort(39, a_oOtherBenefitDetails
						.getBonusToTermAgent().shortValue());
			} else {
				pstmtUpdateOtherBenefit.setNull(39, Types.SMALLINT);
			}

//End by Narendra CTS
//			 Anantha_Banca_Inc End

			//<Rel.  - Start : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
			if (a_oOtherBenefitDetails.getCeipExclusion() != null) {
				pstmtUpdateOtherBenefit.setShort(40, a_oOtherBenefitDetails
						.getCeipExclusion());
			} else {
				pstmtUpdateOtherBenefit.setNull(40, Types.INTEGER);
			}
			
//start CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011 
		    
		    if(a_oOtherBenefitDetails.getPrdPeriod() != null){
				
		    	log.debug("exception getPrdPeriod() "+a_oOtherBenefitDetails.getPrdPeriod());
		    	pstmtUpdateOtherBenefit.setShort(41,a_oOtherBenefitDetails.getPrdPeriod().shortValue());
			}
		    else{
		    	log.debug("IN Else Part OtherBenefit Details");
		    	pstmtUpdateOtherBenefit.setNull(41,Types.SMALLINT);
		    }
//end CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011 
		  //Himanshu
			if (a_oOtherBenefitDetails.getnIsInclusioninACS() != null) {
				pstmtUpdateOtherBenefit.setShort(42, a_oOtherBenefitDetails
						.getnIsInclusioninACS().shortValue());
			} else {
				pstmtUpdateOtherBenefit.setNull(42, Types.SMALLINT);
			}
			
			if (a_oOtherBenefitDetails.getnbonusdescinACS()!= null) {
			pstmtUpdateOtherBenefit.setString(43, a_oOtherBenefitDetails.getnbonusdescinACS());
			}else {
				pstmtUpdateOtherBenefit.setNull(43, Types.VARCHAR);
			}
			
			//Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Starts
			if (a_oOtherBenefitDetails.get_nPayIfColnNotPresent()!=null)
			{
				pstmtUpdateOtherBenefit.setShort(44, a_oOtherBenefitDetails.get_nPayIfColnNotPresent());
			}
			else{
				pstmtUpdateOtherBenefit.setNull(44, Types.SMALLINT);
			}
			//Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Ends
			
			pstmtUpdateOtherBenefit.setLong(45, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
			
			//<Rel.  - End : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
			
			
			
			//Himahsu 
			
			
			
		 //pstmtUpdateOtherBenefit.setLong(31, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
    //CR_OtherBenefit_sequence_Rel8.2_end
			//Arun Target Tab end
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Ends
	        executeUpdate(pstmtUpdateOtherBenefit);
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
            updateApplicableAgentAgencyDtls(a_oOtherBenefitDetails);
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
            updateOtherBenefitDesignationDetails(a_oOtherBenefitDetails);
            updateOtherBenefitCriDesgnDetails(a_oOtherBenefitDetails);
            //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start
            updateDesignationExclusionDetails(a_oOtherBenefitDetails);
            //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End            
            //Amid_MP/P_Incentive Scheme Starts           
            updateGlpDetails(a_oOtherBenefitDetails);
           //Amid_MP/P_Incentive Scheme Ends
            updateCriteriaParams(a_oOtherBenefitDetails);
            insertCriteriaParams(a_oOtherBenefitDetails);
            deleteCriteriaParams(a_oOtherBenefitDetails);
            //Arun_FSOtherBenefitsTargetTab_REL8.1 Start
           if(a_oOtherBenefitDetails.getBonusType().equals(DataConstants.AAP_BT))
           {
            updateOtherBenefitOfficeMultiplierDtls(a_oOtherBenefitDetails);
            updateOtherBenefitTgtCriteriaParamDtls(a_oOtherBenefitDetails);
            updateOtherBenefitTargetParamDetails(a_oOtherBenefitDetails);
           }
            //Arun_FSOtherBenefitsTargetTab_REL8.1 End
            //inserting or deleting from the com_charge_type
            BonusResult oBonusResult = new BonusResult();
            BonusDAX oBonusDAX = getDAX();
            oBonusResult.setBonusHdrSeqNbr(a_oOtherBenefitDetails.getBonusHdrSeqNbr());
            oBonusResult.setAcctCd(a_oOtherBenefitDetails.getAcctCd());
            oBonusResult.setOSAcctCd(a_oOtherBenefitDetails.getOSAcctCd());
            oBonusResult.setProvAcctCd(a_oOtherBenefitDetails.getProvAcctCd());
            oBonusResult.setUserId(a_oOtherBenefitDetails.getUserId());
            oBonusDAX.chkBonusAccountDetails(oBonusResult);
            updateBaseParam(a_oOtherBenefitDetails.getBonusDesc(),a_oOtherBenefitDetails.getBonusHdrSeqNbr(),a_oOtherBenefitDetails.getUserId());
            //Arun Target Tab Start
            if(!a_oOtherBenefitDetails.getBonusType().equals(DataConstants.AAP_BT))
            {
            if(a_oOtherBenefitDetails.getIsTargetBased().intValue() == DataConstants.YES)
            {
                strUpdateQuery = getSQLString("Update", CHMConstants.OTHER_BENEFIT_BONUS_UPDATE);
                pstmtUpdateOtherBenefit = getPreparedStatement(strUpdateQuery);

                pstmtUpdateOtherBenefit.setNull(1, Types.INTEGER);
                pstmtUpdateOtherBenefit.setNull(2, Types.DOUBLE);
                pstmtUpdateOtherBenefit.setDouble(3,a_oOtherBenefitDetails.getTargetValue().doubleValue());
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Starts
                pstmtUpdateOtherBenefit.setString(4, a_oOtherBenefitDetails.getUserId());
                pstmtUpdateOtherBenefit.setLong(5, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
                pstmtUpdateOtherBenefit.setInt(6, DataConstants.TARGET_PARAMETER);
                pstmtUpdateOtherBenefit.setString(7, a_oOtherBenefitDetails.getBonusParamId());
//Jimmy_OtherBenefits_1.3.2.1_REL8.0_Addendum Ends
                executeUpdate(pstmtUpdateOtherBenefit);
            }

           }
            //Arun Target Tab end
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        } catch (EElixirException eex)
        {
        	if(eex.getCustomErrorCode().equalsIgnoreCase("p9556"))
        	{
        		log.debug("exception message is p9556 ");
        		log.fatal(getClass().getName(), "updateOtherBenefit", "EElixirException " + eex.getMessage());
                eex.printStackTrace();
                throw new EElixirException(eex, "p9556");

        	}
        	else
        	{
            log.fatal(getClass().getName(), "updateOtherBenefit", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        	}
        } finally
        {
            try
            {
                if (pstmtUpdateOtherBenefit != null)
                {
                    pstmtUpdateOtherBenefit.close();
                }
                if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
            catch (EElixirException eElex)
			{						
				throw new EElixirException(eElex, "P1005");
            }
        }
    }

    public void updateOtherBenefitDesignationDetails(OtherBenefitResult a_oOtherBenefitDetails) throws EElixirException
    {
        PreparedStatement pstmtDesgn = null;
        long lDesgnApplSeqNbr = 0;
        String[] _strApplDesgn = a_oOtherBenefitDetails.getApplDesgn();
        ResultSet rsDesgn = null;

        try
        {

            String strQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_APPL_DESIGNATION_DELETE);
            pstmtDesgn = getPreparedStatement(strQuery);
            pstmtDesgn.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
            executeUpdate(pstmtDesgn);
            if (_strApplDesgn != null)
            {
                for (int i = 0; i < _strApplDesgn.length; i++)
                {
                    strQuery = getSQLString("Select", CHMConstants.APPLICABILITY_SEQUENCE);
                    rsDesgn = executeQuery(strQuery);

                    if (rsDesgn.next())
                    {
                        lDesgnApplSeqNbr = rsDesgn.getLong(1);
                    }

                    strQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_APPL_DESIGNATION_INSERT);
                    pstmtDesgn = getPreparedStatement(strQuery);
                    pstmtDesgn.setLong(1, lDesgnApplSeqNbr);
                    pstmtDesgn.setLong(2, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
                    pstmtDesgn.setString(3, _strApplDesgn[i]);
                    pstmtDesgn.setString(4, a_oOtherBenefitDetails.getUserId());
                    executeUpdate(pstmtDesgn);
                }
            }
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "updateOtherBenefit", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        } finally
        {
            try
            {
                if (pstmtDesgn != null)
                {
                    pstmtDesgn.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
        }
    }

    public void updateOtherBenefitCriDesgnDetails(OtherBenefitResult a_oOtherBenefitDetails) throws EElixirException
    {
        PreparedStatement pstmtDesgn = null;
        String[] _strCriDesgn = a_oOtherBenefitDetails.getCriDesgn();
//Jimmy_OtherBenefits_1.4_REL8.0 Starts
        String[] _strIsMnylAgt = a_oOtherBenefitDetails.getIsMnylAgent();
//Jimmy_OtherBenefits_1.4_REL8.0 Ends


        try
        {

            String strQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_CRI_DESIGNATION_DELETE);
            pstmtDesgn = getPreparedStatement(strQuery);
            pstmtDesgn.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
            executeUpdate(pstmtDesgn);
            if (_strCriDesgn != null)
            {
                for (int i = 0; i < _strCriDesgn.length; i++)
                {
                    strQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_CRI_DESIGNATION_INSERT);
                    pstmtDesgn = getPreparedStatement(strQuery);
                    pstmtDesgn.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
                    pstmtDesgn.setString(2, _strCriDesgn[i]);
//Jimmy_OtherBenefits_1.4_REL8.0 Starts
                    if(_strIsMnylAgt != null)
                    {
                    	if(_strIsMnylAgt[i] != null && !_strIsMnylAgt[i].trim().equals(""))
                    	{
                     		pstmtDesgn.setShort(3,new Short(_strIsMnylAgt[i]).shortValue());
                    	}
                    	else
                    	{
                    		pstmtDesgn.setNull(3,Types.SMALLINT);
                    	}
                    }
                    else
                    {
                    	pstmtDesgn.setNull(3,Types.SMALLINT);
                    }
                    pstmtDesgn.setString(4, a_oOtherBenefitDetails.getUserId());
//Jimmy_OtherBenefits_1.4_REL8.0 Ends
                    executeUpdate(pstmtDesgn);
                }
            }
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "updateOtherBenefit", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        } finally
        {
            try
            {
                if (pstmtDesgn != null)
                {
                    pstmtDesgn.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
        }
    }
//  Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start
    public void updateDesignationExclusionDetails(OtherBenefitResult a_oOtherBenefitDetails) throws EElixirException
    {
        PreparedStatement pstmtDesgn = null;        
        String[] _strDesgCd = a_oOtherBenefitDetails.getDesgCd();
        String[] _strBaseParamId = a_oOtherBenefitDetails.getBaseParamId();
        String[] _nIsInclOrExcl = a_oOtherBenefitDetails.getIsInclOrExcl();
        ResultSet rsDesgn = null;

        try
        {

            String strQuery = getSQLString("Delete", CHMConstants.DESIGNATION_EXCLUSION_DELETE);
            pstmtDesgn = getPreparedStatement(strQuery);
            pstmtDesgn.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
            executeUpdate(pstmtDesgn);
            if (_strDesgCd != null)
            {
                for (int i = 0; i < _strDesgCd.length; i++)
                {
                    strQuery = getSQLString("Insert", CHMConstants.DESIGNATION_EXCLUSION_INSERT);
                    pstmtDesgn = getPreparedStatement(strQuery);
                    pstmtDesgn.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
                    if(_nIsInclOrExcl != null)
                    {
                    	if(_nIsInclOrExcl[i] != null && !_nIsInclOrExcl[i].trim().equals(""))
                    	{
                     		pstmtDesgn.setShort(2,new Short(_nIsInclOrExcl[i]).shortValue());
                    	}
                    	else
                    	{
                    		pstmtDesgn.setNull(2,Types.SMALLINT);
                    	}
                    }                    
                    pstmtDesgn.setString(3, _strDesgCd[i]);
                    pstmtDesgn.setString(4, _strBaseParamId[i]);                   
                    pstmtDesgn.setString(5, a_oOtherBenefitDetails.getUserId());
                    executeUpdate(pstmtDesgn);
                }
            }
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "updateDesignationExclusionDetails", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p9700");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "updateDesignationExclusionDetails", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p9700");
        } finally
        {
            try
            {
                if (pstmtDesgn != null)
                {
                    pstmtDesgn.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "updateDesignationExclusionDetails", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p9700");
            }
        }
    }

    //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
    
// Amid_MP/P_Incentive Scheme Starts
    public void updateGlpDetails(OtherBenefitResult a_oOtherBenefitDetails) throws EElixirException
    {
    	
        PreparedStatement pstmtGlp = null;        
        String[] _strScoreType = a_oOtherBenefitDetails.getScoreType();
        String[] _nGlpWeightage = a_oOtherBenefitDetails.getGlpWeightage();
        String[] _dFrom = a_oOtherBenefitDetails.getFrom();
        String[] _dTo = a_oOtherBenefitDetails.getTo();
        String[] _nValue = a_oOtherBenefitDetails.getValue();
        ResultSet rsDesgn = null;
        try
        {
            String strQuery = getSQLString("Delete", CHMConstants.GLP_DELETE);
            pstmtGlp = getPreparedStatement(strQuery);
            pstmtGlp.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
            executeUpdate(pstmtGlp);
            if (_strScoreType != null)
            {
                for (int i = 0; i < _strScoreType.length; i++)
                {
                    strQuery = getSQLString("Insert", CHMConstants.GLP_INSERT);
                    pstmtGlp = getPreparedStatement(strQuery);
                    pstmtGlp.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
		            
	            	if(_strScoreType[i] != null && !_strScoreType[i].trim().equals(""))
	            	{
	             		pstmtGlp.setShort(2,new Short(_strScoreType[i]).shortValue());
	             		log.debug("inside updateGlpDetails>>Insert>_strScoreType>>"+_strScoreType[i]);
	            	}
	            	else
	            	{
	            		pstmtGlp.setNull(2,Types.SMALLINT);
	            	}
		           
                	if(_nGlpWeightage[i] != null && !_nGlpWeightage[i].trim().equals(""))
                	{
                 		//pstmtGlp.setShort(3,new D(_nGlpWeightage[i]).shortValue());
                 		pstmtGlp.setDouble(3, new Double(_nGlpWeightage[i]).doubleValue());
                	}
                	else
                	{
                		pstmtGlp.setNull(3,Types.DOUBLE);
                	}
                   
                    
                	if(_dFrom[i] != null && !_dFrom[i].trim().equals(""))
                	{
                		pstmtGlp.setDouble(4, new Double(_dFrom[i]).doubleValue());
                 		//pstmtGlp.setShort(4,new Short(_dFrom[i]).shortValue());
                	}
                	else
                	{
                		pstmtGlp.setNull(4,Types.DOUBLE);
                	}
                 
                	if(_dTo[i] != null && !_dTo[i].trim().equals(""))
                	{
                		pstmtGlp.setDouble(5, new Double(_dTo[i]).doubleValue());
                 		//pstmtGlp.setShort(5,new Short(_dTo[i]).shortValue());
                	}
                	else
                	{
                		pstmtGlp.setNull(5,Types.DOUBLE);
                	}
                   
                	if(_nValue[i] != null && !_nValue[i].trim().equals(""))
                	{
                		pstmtGlp.setDouble(6, new Double(_nValue[i]).doubleValue());
                 		//pstmtGlp.setShort(6,new Short(_nValue[i]).shortValue());
                	}
                	else
                	{
                		pstmtGlp.setNull(6,Types.DOUBLE);
                	}
                    
                    pstmtGlp.setString(7, a_oOtherBenefitDetails.getUserId());
                    executeUpdate(pstmtGlp);
                }
            }
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "updateGlpDetails", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p9700");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "updateGlpDetails", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p9700");
        } finally
        {
            try
            {
                if (pstmtGlp != null)
                {
                	pstmtGlp.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "updateGlpDetails", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p9700");
            }
        }
    }

    //Amid_MP/P_Incentive Scheme Starts

    public void checkAgentDesignation(String strAgentCd, Long lBonusHdrSeqNbr) throws EElixirException
    {
        ResultSet rsSearchBonus = null;
        OtherBenefitResult oOtherBenefitResult = null;
        PreparedStatement pstmtSearchBonus = null;

        try
        {
            String strSelectBonusQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_AGENT_DESGN_CHECK);
            pstmtSearchBonus = getPreparedStatement(strSelectBonusQuery);
            pstmtSearchBonus.setString(1, strAgentCd);
            pstmtSearchBonus.setLong(2, lBonusHdrSeqNbr.longValue());
            rsSearchBonus = executeQuery(pstmtSearchBonus);
            oOtherBenefitResult = new OtherBenefitResult();
            int iCount = 0;
            while (rsSearchBonus.next())
            {
                iCount = rsSearchBonus.getInt(1);
            }
            if (iCount == 0)
            {
                throw new EElixirException("P9999");
            }
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw eex;
        } finally
        {
            try
            {
                if (rsSearchBonus != null)
                {
                    rsSearchBonus.close();
                }

                if (pstmtSearchBonus != null)
                {
                    pstmtSearchBonus.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }

    public void updateAgentTargetDetails(ArrayList alAgentDetails, Long lBonusHdrSeqNbr) throws EElixirException
    {
        PreparedStatement psUpdateAgent = null;
        OtherBenefitAgentDetail oOtherBenefitAgentDetail = null;
        String strQuery = null;
        ResultSet rsAgent = null;
        try
        {
            if (alAgentDetails != null)
            {
                for (int i = 0; i < alAgentDetails.size(); i++)
                {
                    oOtherBenefitAgentDetail = (OtherBenefitAgentDetail) alAgentDetails.get(i);
                    if (oOtherBenefitAgentDetail.getStatusFlag().equals(DataConstants.INSERT_MODE))
                    {
                        long lBonusAgtSeqNbr = 0;
                        strQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_AGENT_SEQ);
                        rsAgent = executeQuery(strQuery);
                        if (rsAgent.next())
                        {
                            lBonusAgtSeqNbr = rsAgent.getLong(1);
                        } else
                        {
                            log.fatal("Sequence no not generated");
                            throw new EElixirException("p4528");
                        }
                        strQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_AGENT_INSERT);
                        psUpdateAgent = getPreparedStatement(strQuery);
                        psUpdateAgent.setLong(1, lBonusHdrSeqNbr.longValue());
                        psUpdateAgent.setLong(2, lBonusAgtSeqNbr);
                        psUpdateAgent.setString(3, oOtherBenefitAgentDetail.getAgentCd());
                        psUpdateAgent.setDouble(4, oOtherBenefitAgentDetail.getTargetValue().doubleValue());
                        psUpdateAgent.setString(5, oOtherBenefitAgentDetail.getUserId());
                        executeQuery(psUpdateAgent);
                    }
                    if (oOtherBenefitAgentDetail.getStatusFlag().equals(DataConstants.DELETE_MODE))
                    {
                        strQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_AGENT_DELETE);
                        strQuery = strQuery + " and LIBTARGETSEQNBR = ? ";
                        psUpdateAgent = getPreparedStatement(strQuery);
                        psUpdateAgent.setLong(1, lBonusHdrSeqNbr.longValue());
                        psUpdateAgent.setLong(2, oOtherBenefitAgentDetail.getTargetAgtSeqNbr().longValue());
                        executeQuery(psUpdateAgent);
                    }
                    if (oOtherBenefitAgentDetail.getStatusFlag().equals(DataConstants.UPDATE_MODE))
                    {
                        strQuery = getSQLString("Update", CHMConstants.OTHER_BENEFIT_AGENT_UPDATE);
                        psUpdateAgent = getPreparedStatement(strQuery);
                        psUpdateAgent.setString(1, oOtherBenefitAgentDetail.getAgentCd());
                        psUpdateAgent.setDouble(2, oOtherBenefitAgentDetail.getTargetValue().doubleValue());
                        psUpdateAgent.setString(3, oOtherBenefitAgentDetail.getUserId());
                        psUpdateAgent.setLong(4, lBonusHdrSeqNbr.longValue());
                        psUpdateAgent.setLong(5, oOtherBenefitAgentDetail.getTargetAgtSeqNbr().longValue());
                        executeQuery(psUpdateAgent);
                    }
                }
            }

        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw eex;
        } finally
        {
            try
            {
                if (psUpdateAgent != null)
                {
                    psUpdateAgent.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }

    public ArrayList getOtherBenefitAgentDetails(long lBonusHdrSeqNbr) throws EElixirException
    {
        ArrayList alAgentDetails = new ArrayList();
        PreparedStatement psSelect = null;
        ResultSet rsSelect = null;
        OtherBenefitAgentDetail oOtherBenefitAgentDetail = null;
        try
        {
            String strQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_AGENT_SELECT);
            psSelect = getPreparedStatement(strQuery);
            psSelect.setLong(1, lBonusHdrSeqNbr);
            rsSelect = executeQuery(psSelect);

            while (rsSelect.next())
            {
                oOtherBenefitAgentDetail = new OtherBenefitAgentDetail();
                oOtherBenefitAgentDetail.setTargetAgtSeqNbr(new Long(rsSelect.getLong("LIBTARGETSEQNBR")));
                oOtherBenefitAgentDetail.setAgentCd(rsSelect.getString("STRAGENTCD"));
                oOtherBenefitAgentDetail.setTargetValue(new Double(rsSelect.getDouble("DVALUE")));
                oOtherBenefitAgentDetail.setAgentName(rsSelect.getString("AGTNAME"));
                alAgentDetails.add(oOtherBenefitAgentDetail);
            }
            return alAgentDetails;
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw eex;
        } finally
        {
            try
            {
                if (psSelect != null)
                {
                    psSelect.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }

    public void removeOtherBenefit(Long lBonusHdrSeqNbr) throws EElixirException
    {
        PreparedStatement pstmtRemoveBenefit = null;
        try
        {
            log.debug("BenefitDAX-- Inside remove OtherBenefit");

            String strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_PARAM_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            int iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- params deleted count " + iRemoveBenefit);

            strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_CRI_DESIGNATION_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- criteria designations deleted count " + iRemoveBenefit);

            strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_APPL_DESIGNATION_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- applicable designations deleted count " + iRemoveBenefit);

            strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_AGENT_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Agents deleted count " + iRemoveBenefit);

            strRemoveQuery = getSQLString("Delete", CHMConstants.BONUS_PRODUCT_DELETE_FOR_HEADER);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Bonus product deleted count " + iRemoveBenefit);

            strRemoveQuery = getSQLString("Delete", CHMConstants.BONUS_DISTR_PRODUCT_DELETE_FOR_HEADER);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Bonus distribution product deleted count " + iRemoveBenefit);
            /*Arun_FSOtherBenefitsTargetTab_REL8.1 Start*/
            strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_OFF_MULTIPLIER_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Office Multiplier deleted count " + iRemoveBenefit);

            strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_TGT_CRIPARAM_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Target Criteria Parameter deleted count " + iRemoveBenefit);

            strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_TGT_PARAM_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Target Parameter deleted count " + iRemoveBenefit);
            /*Arun_FSOtherBenefitsTargetTab_REL8.1 End*/
            //deleting accounting details
            BonusDAX oBonusDAX = getDAX();
            oBonusDAX.deleteBonusAccountDetails(lBonusHdrSeqNbr);

            deleteBaseParam(lBonusHdrSeqNbr);
			//Added for deleting the child records

			log.debug("BENEFIT_CAMPAIGN_DELETE lBonusHdrSeqNbr " + lBonusHdrSeqNbr);
			strRemoveQuery = getSQLString("Delete",CHMConstants.BENEFIT_CAMPAIGN_DELETE);
			pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
			pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
			iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
			log.debug("BenefitDAX-- Bonus Campaign deleted count " + iRemoveBenefit);


			log.debug("BONUS_HDR_DELETE");
            strRemoveQuery = getSQLString("Delete", CHMConstants.BONUS_HDR_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Bonus header deleted " + iRemoveBenefit);

//Jimmy_OtherBenefits_1.1_REL8.0 Starts
            log.debug("OTHER_BENEFIT_AGENT_AGENCY_LVL_DELETE");
            strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_AGENT_AGENCY_LVL_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- Agent Agency Level Delete " + iRemoveBenefit);
//Jimmy_OtherBenefits_1.1_REL8.0 Ends

        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());
            throw new EElixirException("P4541");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException("P4541");
        } finally
        {
            try
            {
                if (pstmtRemoveBenefit != null)
                {
                    pstmtRemoveBenefit.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }

    }

    public void deleteCriteriaParameters(Long lBonusHdrSeqNbr) throws EElixirException
    {
        PreparedStatement pstmtRemoveBenefit = null;
        try
        {
            log.debug("BenefitDAX-- Inside remove OtherBenefit");

            String strRemoveQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_PARAM_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setLong(1, lBonusHdrSeqNbr.longValue());
            int iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- params deleted count " + iRemoveBenefit);
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());
            throw new EElixirException("P4541");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException("P4541");
        } finally
        {
            try
            {
                if (pstmtRemoveBenefit != null)
                {
                    pstmtRemoveBenefit.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }

    }

    public void insertBaseParam(String strBonusDesc,Long lBonusHdrSeqNbr,String strUserId) throws EElixirException
    {
        String strQuery = null;
        ResultSet rs = null;
        String strBaseParamSeq = null;
        PreparedStatement ps = null;
        try
        {
            strQuery = getSQLString("Select", CHMConstants.GET_BASE_PARAM_SEQ);
            rs = executeQuery(strQuery);

            while (rs.next())
            {
                strBaseParamSeq = rs.getString(1);
            }
            strQuery = getSQLString("Insert", CHMConstants.BASE_PARAM_INSERT);
            ps = getPreparedStatement(strQuery);
            ps.setString(1,strBaseParamSeq);
            ps.setString(2,strBonusDesc);
            ps.setString(3,"1");
            ps.setString(4,"cm_sp_get_bonus_amnt");
            ps.setString(5,lBonusHdrSeqNbr.toString());
            ps.setString(6,strUserId);
            executeQuery(ps);
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "createBonus", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        } finally
        {
            try
            {
                if (ps != null)
                {
                    ps.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
        }
    }

    public void updateBaseParam(String strBonusDesc,Long lBonusHdrSeqNbr,String strUserId) throws EElixirException
    {
        String strQuery = null;
        String strBaseParamSeq = null;
        PreparedStatement ps = null;
        try
        {
            strQuery = getSQLString("Update", CHMConstants.BASE_PARAM_UPDATE);
            ps = getPreparedStatement(strQuery);
            ps.setString(1,strBonusDesc);
            ps.setString(2,strUserId);
            ps.setString(3,lBonusHdrSeqNbr.toString());
            executeQuery(ps);
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "p4528");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "createBonus", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "p4528");
        } finally
        {
            try
            {
                if (ps != null)
                {
                    ps.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "createBonus", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "p4528");
            }
        }
    }

    public void deleteBaseParam(Long lBonusHdrSeqNbr) throws EElixirException
    {
        PreparedStatement pstmtRemoveBenefit = null;
        try
        {
            log.debug("BenefitDAX-- Inside remove OtherBenefit");
            String strRemoveQuery = getSQLString("Delete", CHMConstants.BASE_PARAM_DELETE);
            pstmtRemoveBenefit = getPreparedStatement(strRemoveQuery);
            pstmtRemoveBenefit.setString(1, lBonusHdrSeqNbr.toString());
            int iRemoveBenefit = executeUpdate(pstmtRemoveBenefit);
            log.debug("BenefitDAX-- params deleted count " + iRemoveBenefit);
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());
            throw new EElixirException("P4541");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException("P4541");
        } finally
        {
            try
            {
                if (pstmtRemoveBenefit != null)
                {
                    pstmtRemoveBenefit.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }

    }

//Jimmy_OtherBenefits_1.1_REL8.0 Starts
    public void getApplicableAgentAgencyDtls(OtherBenefitResult a_oOtherBenefitResult)throws EElixirException
    {
    	 PreparedStatement psSelect = null;
         ResultSet rsSelect = null;
         ArrayList alAgtAgncyCd = new ArrayList();
         String[] strAgtAgncyCd = null;
         ArrayList alAgtAgncyName = new ArrayList();
         String[] strAgtAgncyName = null;
         try
         {
             String strQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_AGENT_AGENCY_LVL_SELECT);
             psSelect = getPreparedStatement(strQuery);
             psSelect.setLong(1, a_oOtherBenefitResult.getBonusHdrSeqNbr().longValue());
             rsSelect = executeQuery(psSelect);

             while (rsSelect.next())
             {
            	 alAgtAgncyCd.add(rsSelect.getString("STRAGENTCD"));
            	 alAgtAgncyName.add(rsSelect.getString("AGTNAME"));
             }
            if((alAgtAgncyCd.size() > 0) && (alAgtAgncyName .size() > 0))
             {
            	 strAgtAgncyCd = new String[alAgtAgncyCd.size()];
            	 strAgtAgncyName = new String[alAgtAgncyName.size()];
                 for(int i=0;(i<alAgtAgncyCd.size()&& i<alAgtAgncyName.size());i++)
                 {
                	 strAgtAgncyCd[i] = (String)alAgtAgncyCd.get(i);
                	 strAgtAgncyName[i]=(String)alAgtAgncyName.get(i);
                 }
                 a_oOtherBenefitResult.setApplicableAgentAgencyCode(strAgtAgncyCd);
                 a_oOtherBenefitResult.setApplicableAgentAgencyName(strAgtAgncyName);
             }
         }
         catch (SQLException sqlex)
         {
             log.fatal(getClass().getName(), "getApplicableAgentAgencyDtls", "SQLException " + sqlex.getMessage());
             throw new EElixirException(sqlex, "P7186");
         }
         catch (EElixirException eex)
         {
             log.fatal(getClass().getName(), "getApplicableAgentAgencyDtls", "EElixirException " + eex.getMessage());
             throw eex;
         }
         finally
         {
             try
             {
                 if (psSelect != null)
                 {
                     psSelect.close();
                 }
             } catch (SQLException sqlex)
             {
                 log.fatal(getClass().getName(), "getOtherBenefitAgentAgencyDtls", "SQLException " + sqlex.getMessage());
                 throw new EElixirException(sqlex, "P7186");
             }
         }

    }

    public void updateApplicableAgentAgencyDtls(OtherBenefitResult a_oOtherBenefitDetails) throws EElixirException
    {
        PreparedStatement pstmtAgtAgncy = null;
        String[] _strAgtAgncyCd = a_oOtherBenefitDetails.getApplicableAgentAgencyCode();
        try
        {

            String strQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_AGENT_AGENCY_LVL_DELETE);
            pstmtAgtAgncy = getPreparedStatement(strQuery);
            pstmtAgtAgncy.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
            executeUpdate(pstmtAgtAgncy);
            if(a_oOtherBenefitDetails.getBonusLevel() != null)
            {
            	if((a_oOtherBenefitDetails.getBonusLevel().intValue() == DataConstants.AGENCY) || (a_oOtherBenefitDetails.getBonusLevel().intValue() == DataConstants.AGENT))
            	{
            	   if (_strAgtAgncyCd != null )
            	   {
            		   for (int i = 0; i < _strAgtAgncyCd.length ; i++)
            		   {
            			   strQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_AGENT_AGENCY_LVL_INSERT);
            			   pstmtAgtAgncy = getPreparedStatement(strQuery);
            			   pstmtAgtAgncy.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
            			   pstmtAgtAgncy.setString(2, _strAgtAgncyCd[i]);
            			   pstmtAgtAgncy.setString(3, a_oOtherBenefitDetails.getUserId());
            			   executeUpdate(pstmtAgtAgncy);
            		   }
            	   }
            	}
            }
        }
        catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "updateApplicableAgentAgencyDtls", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P7187");
        }
        catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "updateApplicableAgentAgencyDtls", "EElixirException " + eex.getMessage());
            eex.printStackTrace();
            throw new EElixirException(eex, "P7187");
        } finally
        {
            try
            {
                if (pstmtAgtAgncy != null)
                {
                	pstmtAgtAgncy.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "updateOtherBenefitAgentAgencyDtls", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P7187");
            }
        }
    }

//Jimmy_OtherBenefits_1.1_REL8.0 Ends
//  Arun_FSOtherBenefitsTargetTab_REL8.1 Start
  public void updateOtherBenefitOfficeMultiplierDtls(OtherBenefitResult a_oOtherBenefitDetails)throws EElixirException
  {
	  PreparedStatement pstmtOffMul = null;
      ArrayList alOffMulFrom=null;
      ArrayList alOffMulTo=null;
      ArrayList alOffMul=null;
      TargetOfficeMultiplierResult oTargetOfficeMultiplierResult=a_oOtherBenefitDetails.getOffMultiplierDetails();
      try
      {

          String strQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_OFF_MULTIPLIER_DELETE);
          pstmtOffMul = getPreparedStatement(strQuery);
          pstmtOffMul.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
          executeUpdate(pstmtOffMul);
          if (oTargetOfficeMultiplierResult != null)
          {   alOffMulFrom =oTargetOfficeMultiplierResult.getOfficeMultiplierFrom();
              alOffMulTo =oTargetOfficeMultiplierResult.getOfficeMultiplierTo();
              alOffMul =oTargetOfficeMultiplierResult.getOfficeMultiplier();
              for (int i=0;i<alOffMulFrom.size();i++)
              {
                   strQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_OFF_MULTIPLIER_INSERT);
                   pstmtOffMul = getPreparedStatement(strQuery);
                   pstmtOffMul.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
                   pstmtOffMul.setInt(2,Integer.parseInt((String)alOffMulFrom.get(i)));
                   pstmtOffMul.setInt(3,Integer.parseInt((String)alOffMulTo.get(i)));
                   pstmtOffMul.setDouble(4, Double.parseDouble((String)alOffMul.get(i)));//Arun changed for SIT FIX
                  pstmtOffMul.setString(5, a_oOtherBenefitDetails.getUserId());
                  pstmtOffMul.setString(6, a_oOtherBenefitDetails.getUserId());
                  executeUpdate(pstmtOffMul);
              }
          }
      }
      catch (SQLException sqlex)
      {
          log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
          throw new EElixirException(sqlex, "p4528");
      }
      catch (EElixirException eex)
      {
          log.fatal(getClass().getName(), "updateOtherBenefit", "EElixirException " + eex.getMessage());
          eex.printStackTrace();
          throw new EElixirException(eex, "p4528");
      } finally
      {
          try
          {
              if (pstmtOffMul != null)
              {
            	  pstmtOffMul.close();
              }
          }
          catch (SQLException sqlex)
          {
              log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
              throw new EElixirException(sqlex, "p4528");
          }
      }
  }
  //Arun_SIT_TargetTab_ExchangeParam_fix_start
  public void  updateOtherBenefitTgtCriteriaParamDtls(OtherBenefitResult a_oOtherBenefitDetails)throws EElixirException
  {
	  PreparedStatement pstmtTgtCriParam = null;
      ArrayList alTgtCriParamId=null;
      ArrayList alBnsWeightage=null;
      //Modified by Amid Start
      ArrayList alBnsWeightage2=null;
      ArrayList alBnsWeightage3=null;
      //Modified by Amid End
      ArrayList alOffVintageFrom=null;
      ArrayList alOffVintageTo=null;
      ArrayList alMinRequirement=null;
      ArrayList alCriteriaSeqNbrs=null;
      TargetCriteriaParamResult oTargetCriteriaParamResult=a_oOtherBenefitDetails.getTargetCriParamDetails();
      Long lCriteriaSeq=null;
      long lprimCriteriaSeq=0;
      try
      {
    	  String strSelectQuery=getSQLString("Select",CHMConstants.OTHER_BENEFIT_CRI_SEQ_NUMBERS);
    	  log.debug("BenefitDax--TargetSeqnumbers query is "+strSelectQuery);
    	  alCriteriaSeqNbrs=getSeqNumbers(a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue(),strSelectQuery);
    	  if(alCriteriaSeqNbrs.size()<=0)
    	  {
    	   String strSeqquery=getSQLString("Select",CHMConstants.OTHER_BENEFIT_NEXT_CRI_SEQ_NBR);
    	   lCriteriaSeq=getNextSeqNumber(strSeqquery);
    	   lprimCriteriaSeq=lCriteriaSeq.longValue();
    	  }
          String strQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_TGT_CRIPARAM_DELETE);
          pstmtTgtCriParam = getPreparedStatement(strQuery);
          pstmtTgtCriParam.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
          executeUpdate(pstmtTgtCriParam);
          if (oTargetCriteriaParamResult != null)
          {
        	  alTgtCriParamId =oTargetCriteriaParamResult.getCriteriaParamIds();
              alBnsWeightage =oTargetCriteriaParamResult.getBnsWeightage();
//            Modified by Amid Start
              alBnsWeightage2 =oTargetCriteriaParamResult.getBnsWeightage2();
              alBnsWeightage3 =oTargetCriteriaParamResult.getBnsWeightage3();
//            Modified by Amid End
              alOffVintageFrom =oTargetCriteriaParamResult.getOfficeVintageFrom();
              alOffVintageTo=oTargetCriteriaParamResult.getOfficeVinatageTo();
              alMinRequirement=oTargetCriteriaParamResult.getMinRequirement();
        	  for (int i = 0;i<alTgtCriParamId.size();i++)
              {
                  strQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_TGT_CRIPARAM_INSERT);
                  log.debug("--8-updateOtherBenefitTgtCriteriaParamDtls Insert query is :"+strQuery);
                  pstmtTgtCriParam = getPreparedStatement(strQuery);
                  pstmtTgtCriParam.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
                  pstmtTgtCriParam.setString(2,(String)alTgtCriParamId.get(i));
                  pstmtTgtCriParam.setInt(3,Integer.parseInt((String)alOffVintageFrom.get(i)));
                  pstmtTgtCriParam.setInt(4,Integer.parseInt((String)alOffVintageTo.get(i)));
                  pstmtTgtCriParam.setDouble(5,Double.parseDouble(((String)alBnsWeightage.get(i))));
//                Modified by Amid Start
                  pstmtTgtCriParam.setDouble(6,Double.parseDouble(((String)alBnsWeightage2.get(i))));
                  pstmtTgtCriParam.setDouble(7,Double.parseDouble(((String)alBnsWeightage3.get(i))));
//                Modified by Amid End
                  pstmtTgtCriParam.setDouble(8,Double.parseDouble((String)alMinRequirement.get(i)));
                  pstmtTgtCriParam.setString(9, a_oOtherBenefitDetails.getUserId());
                  pstmtTgtCriParam.setString(10, a_oOtherBenefitDetails.getUserId());
                  if(alCriteriaSeqNbrs.size()<=0)
                  {
                    pstmtTgtCriParam.setLong(11,lprimCriteriaSeq++);
                  }
                  else
                  {
                   pstmtTgtCriParam.setLong(11,((Long)alCriteriaSeqNbrs.get(i)).longValue());
                   log.debug("BenefitDax-updateOtherBenefitTgtCriteriaParamDtls-Arrayseqnbr "+((Long)alCriteriaSeqNbrs.get(i)).longValue());
                  }
                  executeUpdate(pstmtTgtCriParam);
              }
          }
      }
      catch (SQLException sqlex)
      {
          log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
          throw new EElixirException(sqlex, "p4528");
      }
      catch (EElixirException eex)
      {
          log.fatal(getClass().getName(), "updateOtherBenefit", "EElixirException " + eex.getMessage());
          eex.printStackTrace();
          throw new EElixirException(eex, "p4528");
      } finally
      {
          try
          {
              if (pstmtTgtCriParam != null)
              {
            	  pstmtTgtCriParam.close();
              }
          }
          catch (SQLException sqlex)
          {
              log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
              throw new EElixirException(sqlex, "p4528");
          }
      }
  }
  //Arun_SIT_TargetTab_ExchangeParam_fix_start
  public void  updateOtherBenefitTargetParamDetails(OtherBenefitResult a_oOtherBenefitDetails)throws EElixirException
  {
	  PreparedStatement pstmtTgtParam = null;
      ArrayList alDesignation=null;
      ArrayList alAgentGOCd=null;
      ArrayList alTgtValues=null;
      ArrayList alTgtCriParamId=null;
      ArrayList alDupCriParamId=null;
      ArrayList alTargetSeqNbr=null;//Arun_SIT_TargetTab_ExchangeParam_fix_start
      Long lTargetSeq=null;
      long lprimTargetSeq=0;
      int count=0;
      TargetParamDetailsResult oTargetParamDetailsResult =a_oOtherBenefitDetails.getTargetParameterDetails();
      TargetCriteriaParamResult oTargetCriteriaParamResult=a_oOtherBenefitDetails.getTargetCriParamDetails();
      try
      {
    	  String strSelectQuery=getSQLString("Select",CHMConstants.OTHER_BENEFIT_TGT_SEQ_NUMBERS);
    	  log.debug("BenefitDax--TargetSeqnumbers query is "+strSelectQuery);
    	  alTargetSeqNbr=getSeqNumbers(a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue(),strSelectQuery);
    	  if(alTargetSeqNbr.size()<=0)
    	  {
    	   String strSeqquery=getSQLString("Select",CHMConstants.OTHER_BENEFIT_NEXT_TGT_SEQ_NBR);
    	   lTargetSeq=getNextSeqNumber(strSeqquery);
    	   lprimTargetSeq=lTargetSeq.longValue();
    	  }

          String strQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_TGT_PARAM_DELETE);
          log.debug("--9-updateOtherBenefitTargetParamDetails-Delete query is "+strQuery);
          pstmtTgtParam = getPreparedStatement(strQuery);
          pstmtTgtParam.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
          executeUpdate(pstmtTgtParam);
          if (oTargetParamDetailsResult != null)
          {
        	  strQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_TGT_PARAM_INSERT);
        	  log.debug("--9-updateOtherBenefitTargetParamDetails-Insert query is "+strQuery);
        	  pstmtTgtParam = getPreparedStatement(strQuery);
        	  alDesignation =oTargetParamDetailsResult.getDesgnCd();
        	  alAgentGOCd =oTargetParamDetailsResult.getAgentGOCd();
        	  alTgtValues =oTargetParamDetailsResult.getDtarget();
        	  alDupCriParamId=oTargetCriteriaParamResult.getCriteriaParamIds();
//            FindBug_Fix_SUNAINA_STARTS
        	  alTgtCriParamId=removeduplicateCriParams(alDupCriParamId);
//            FindBug_Fix_SUNAINA_ENDED

              for (int i=0;i <  a_oOtherBenefitDetails.getRowCount().intValue();i++)
              {
                 for(int j=0;j<a_oOtherBenefitDetails.getColumnCount().intValue();j++)
                {
                  for(int k=0,cnt=1;k< a_oOtherBenefitDetails.getFreqOfCalc().intValue();k++)
                  {
                    pstmtTgtParam.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
                     if(((String)alDesignation.get(i)).equals("0"))
                     {


                       pstmtTgtParam.setNull(2,Types.VARCHAR);
                     }
                     else
                     {
                        pstmtTgtParam.setString(2,(String)alDesignation.get(i));

                     }

                     pstmtTgtParam.setString(3,(String)alAgentGOCd.get(i));
                     pstmtTgtParam.setString(4,(String)alTgtCriParamId.get(j));
                     pstmtTgtParam.setInt(5,cnt++);
                     pstmtTgtParam.setDouble(6,Double.parseDouble((String)alTgtValues.get(count)));
                     pstmtTgtParam.setString(7, a_oOtherBenefitDetails.getUserId());
                     pstmtTgtParam.setString(8, a_oOtherBenefitDetails.getUserId());
                     if(alTargetSeqNbr.size()<=0)
                     {
                       pstmtTgtParam.setLong(9,lprimTargetSeq++);
                     }
                     else
                     {
                      pstmtTgtParam.setLong(9,((Long)alTargetSeqNbr.get(count)).longValue());
                      log.debug("BenefitDax-updateOtherBenefitTargetParamDetails-Arrayseqnbr "+((Long)alTargetSeqNbr.get(count)).longValue());
                     }
                     executeUpdate(pstmtTgtParam);
                     count++;
              }
          }
       }
     }
   }
      catch (SQLException sqlex)
      {
          log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
          throw new EElixirException(sqlex, "p4528");
      }
      catch (EElixirException eex)
      {
          log.fatal(getClass().getName(), "updateOtherBenefit", "EElixirException " + eex.getMessage());
          eex.printStackTrace();
          throw new EElixirException(eex, "p4528");
      } finally
      {
          try
          {
              if (pstmtTgtParam != null)
              {
            	  pstmtTgtParam.close();
              }
          }
          catch (SQLException sqlex)
          {
              log.fatal(getClass().getName(), "updateOtherBenefit", "SQLException " + sqlex.getMessage());
              throw new EElixirException(sqlex, "p4528");
          }
      }

  }
  public void getOtherBenefitOfficeMultiplierDtls(OtherBenefitResult a_oOtherBenefitDetails)throws EElixirException
  {
	  ResultSet rsSearchOffMul = null;
      PreparedStatement pstmtSearchOffMul = null;
      String strOffMulFrom = null;
      String strOffMulTo = null;
      String strOffMul = null;
      double offMuldouble;//Arun Changed for SIT FIX
      try
      {
          String strSelectOffMulQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_OFFMUL_SELECT);

          pstmtSearchOffMul = getPreparedStatement(strSelectOffMulQuery);
          pstmtSearchOffMul.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
          rsSearchOffMul = executeQuery(pstmtSearchOffMul);

          while (rsSearchOffMul.next())
          {
              if (strOffMulFrom == null)
              {
            	  strOffMulFrom = rsSearchOffMul.getString("NOFFVINTAGEFROM");
            	  strOffMulTo = rsSearchOffMul.getString("NOFFVINTAGETO");
                // Arun Changed for SIT FIX Start
            	  offMuldouble= rsSearchOffMul.getDouble("NOFFMULTIPLIER");
            	  strOffMul = Double.toString(offMuldouble);
                // Arun Changed for SIT FIX End
              }
              else
              {
            	  strOffMulFrom = strOffMulFrom + "||" + rsSearchOffMul.getString("NOFFVINTAGEFROM");
            	  strOffMulTo = strOffMulTo + "||" + rsSearchOffMul.getString("NOFFVINTAGETO");
                 // Arun Changed for SIT FIX Start
            	  offMuldouble=rsSearchOffMul.getDouble("NOFFMULTIPLIER");
            	  strOffMul= strOffMul + "||" + Double.toString(offMuldouble);
                // Arun Changed for SIT FIX End
              }
          }
          a_oOtherBenefitDetails.setOffMultiplierFrom(strOffMulFrom);
          a_oOtherBenefitDetails.setOffMultiplierTo(strOffMulTo);
          a_oOtherBenefitDetails.setOffMultiplier(strOffMul);
      }
      catch (SQLException sqlex)
     {
      log.fatal(getClass().getName(), "getOtherBenefitOfficeMultiplierDtls", "SQLException " + sqlex.getMessage());
      throw new EElixirException(sqlex, "P4538");
  } catch (EElixirException eex)
  {
      log.fatal(getClass().getName(), "getOtherBenefitOfficeMultiplierDtls", "EElixirException " + eex.getMessage());
      throw new EElixirException(eex, "P4538");
  } finally
  {
      try
      {
          if (rsSearchOffMul != null)
          {
        	  rsSearchOffMul.close();
          }

          if (pstmtSearchOffMul != null)
          {
        	  pstmtSearchOffMul.close();
          }
      } catch (SQLException sqlex)
      {
          log.fatal(getClass().getName(), "getOtherBenefitOfficeMultiplierDtls", "SQLException " + sqlex.getMessage());
          throw new EElixirException(sqlex, "P4538");
      }
   }
  }
  public void getOtherBenefitTgtCriteriaParamDtls(OtherBenefitResult a_oOtherBenefitDetails)throws EElixirException
  {
	  ResultSet rsSearchTgtCriParam = null;
      PreparedStatement pstmtSearchTgtCriParam = null;
      String strBaseParamId = null;
      String strBaseParamnames =null;
      String nOffVintageFrom = null;
      String nOffVintageTo = null;
      String nBnsWeightage =null;
      String nBnsMinReq =null;
//    Modified by Amid Start
      String nBnsWeightage2 =null;
      String nBnsWeightage3 =null;
//    Modified by Amid End

      try
      {
          String strSelectTgtCriParamQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_TGTCRIPARAM_SELECT);

          pstmtSearchTgtCriParam = getPreparedStatement(strSelectTgtCriParamQuery);
          pstmtSearchTgtCriParam.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
          rsSearchTgtCriParam = executeQuery(pstmtSearchTgtCriParam);

          while (rsSearchTgtCriParam.next())
          {
              if (strBaseParamId == null)
              {
            	  strBaseParamId = rsSearchTgtCriParam.getString("STRBASEPARAMID");
            	  strBaseParamnames=rsSearchTgtCriParam.getString("STRBASEPARAMDESC");
            	  nOffVintageFrom = rsSearchTgtCriParam.getString("NOFFVINTAGEFROM");
            	  nOffVintageTo = rsSearchTgtCriParam.getString("NOFFVINTAGETO");
            	  nBnsWeightage = rsSearchTgtCriParam.getString("NBNSWEIGHTAGE");
            	  nBnsMinReq = rsSearchTgtCriParam.getString("NBNSMINREQ");
            	  //Modified by Amid Start
            	  nBnsWeightage2 = rsSearchTgtCriParam.getString("NBNSWEIGHTAGE2");
            	  nBnsWeightage3 = rsSearchTgtCriParam.getString("NBNSWEIGHTAGE3");
            	  //Modified by Amid End            	  
              } else
              {
            	  strBaseParamId = strBaseParamId + "||" + rsSearchTgtCriParam.getString("STRBASEPARAMID");
            	  strBaseParamnames= strBaseParamnames +"||" + rsSearchTgtCriParam.getString("STRBASEPARAMDESC");
            	  nOffVintageFrom = nOffVintageFrom + "||" + rsSearchTgtCriParam.getString("NOFFVINTAGEFROM");
            	  nOffVintageTo= nOffVintageTo + "||" + rsSearchTgtCriParam.getString("NOFFVINTAGETO");
            	  nBnsWeightage = nBnsWeightage + "||" + rsSearchTgtCriParam.getString("NBNSWEIGHTAGE");
            	  nBnsMinReq= nBnsMinReq + "||" + rsSearchTgtCriParam.getString("NBNSMINREQ");
//            	Modified by Amid Start
            	  nBnsWeightage2 = nBnsWeightage2 + "||" + rsSearchTgtCriParam.getString("NBNSWEIGHTAGE2");
            	  nBnsWeightage3 = nBnsWeightage3 + "||" + rsSearchTgtCriParam.getString("NBNSWEIGHTAGE3");
//            	Modified by Amid End
              }
          }
          a_oOtherBenefitDetails.setTgtCriParamIds(strBaseParamId);
          a_oOtherBenefitDetails.setTgtCriPramNames(strBaseParamnames);
          a_oOtherBenefitDetails.setTgtOffWeightage(nBnsWeightage);
          a_oOtherBenefitDetails.setTgtOffVintageFrom(nOffVintageFrom);
          a_oOtherBenefitDetails.setTgtOffVintageTo(nOffVintageTo);
          a_oOtherBenefitDetails.setTgtMinReqment(nBnsMinReq);
//        Modified by Amid Start
          a_oOtherBenefitDetails.setTgtOffWeightage2(nBnsWeightage2);
          a_oOtherBenefitDetails.setTgtOffWeightage3(nBnsWeightage3);
//        Modified by Amid End

      }
      catch (SQLException sqlex)
     {
      log.fatal(getClass().getName(), "getOtherBenefitTgtCriteriaParamDtls", "SQLException " + sqlex.getMessage());
      throw new EElixirException(sqlex, "P4538");
  } catch (EElixirException eex)
  {
      log.fatal(getClass().getName(), "getOtherBenefitTgtCriteriaParamDtls", "EElixirException " + eex.getMessage());
      throw new EElixirException(eex, "P4538");
  } finally
  {
      try
      {
          if (rsSearchTgtCriParam != null)
          {
        	  rsSearchTgtCriParam.close();
          }

          if (pstmtSearchTgtCriParam != null)
          {
        	  pstmtSearchTgtCriParam.close();
          }
      } catch (SQLException sqlex)
      {
          log.fatal(getClass().getName(), "getOtherBenefitTgtCriteriaParamDtls", "SQLException " + sqlex.getMessage());
          throw new EElixirException(sqlex, "P4538");
      }
   }

  }
  public void getOtherBenefitTargetParamDetails(OtherBenefitResult a_oOtherBenefitDetails)throws EElixirException
  {
	  ResultSet rsSearchTgtParamDtl = null;
      PreparedStatement pstmtSearchTgtParamDtl = null;
      String strDegnCd ="";
      String strAgentCd="";
      String strDTarget ="";
      int count=0;
      try
      {
          String strSelectTgtParamDtlQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_TGTPARAMDTL_SELECT);

          pstmtSearchTgtParamDtl = getPreparedStatement(strSelectTgtParamDtlQuery);
          pstmtSearchTgtParamDtl.setLong(1, a_oOtherBenefitDetails.getBonusHdrSeqNbr().longValue());
          rsSearchTgtParamDtl = executeQuery(pstmtSearchTgtParamDtl);
          int count1=(a_oOtherBenefitDetails.getFreqOfCalc().intValue())*(a_oOtherBenefitDetails.getColumnCount().intValue());
           while (rsSearchTgtParamDtl.next())
          {

              if (strDegnCd == "")
              {
            	  strDegnCd = rsSearchTgtParamDtl.getString("STRDESGNCD");
            	  if(strDegnCd==null)
            	     strDegnCd="0";
              }
              else
              {
            	if((count % count1)==0)
            	{
            	 if(rsSearchTgtParamDtl.getString("STRDESGNCD")==null)
            	 {
            		strDegnCd= strDegnCd + "||" + "0";
            	 }
            	 else
            	 {
            	  strDegnCd = strDegnCd + "||" + rsSearchTgtParamDtl.getString("STRDESGNCD");
            	 }
            	}
              }
              if(strAgentCd == "")
              {
            	strAgentCd=rsSearchTgtParamDtl.getString("STRAGENTCD");
              }
              else
              {
            	if((count % count1)==0)
            	{
            	 strAgentCd = strAgentCd + "||" + rsSearchTgtParamDtl.getString("STRAGENTCD");
            	}
              }
              if(strDTarget == "")
              {
            	  strDTarget = rsSearchTgtParamDtl.getString("DTARGET");

              }
              else
              {
            	  strDTarget = strDTarget + "||" + rsSearchTgtParamDtl.getString("DTARGET");
              }
              count=count+1;
          }
          a_oOtherBenefitDetails.setTgtDesgnCd(strDegnCd);
          a_oOtherBenefitDetails.setAgentorGOCd(strAgentCd);
          a_oOtherBenefitDetails.setTargetParamValue(strDTarget);

      }
      catch (SQLException sqlex)
     {
      log.fatal(getClass().getName(), "getOtherBenefitTargetParamDetails", "SQLException " + sqlex.getMessage());
      throw new EElixirException(sqlex, "P4538");
  } catch (EElixirException eex)
  {
      log.fatal(getClass().getName(), "getOtherBenefitTargetParamDetails", "EElixirException " + eex.getMessage());
      throw new EElixirException(eex, "P4538");
  } finally
  {
      try
      {
          if (rsSearchTgtParamDtl != null)
          {
        	  rsSearchTgtParamDtl.close();
          }

          if (pstmtSearchTgtParamDtl != null)
          {
        	  pstmtSearchTgtParamDtl.close();
          }
      } catch (SQLException sqlex)
      {
          log.fatal(getClass().getName(), "getOtherBenefitTargetParamDetails", "SQLException " + sqlex.getMessage());
          throw new EElixirException(sqlex, "P4538");
      }
   }

  }
//FindBug_Fix_SUNAINA_STARTS
  public ArrayList removeduplicateCriParams(ArrayList alDupCriParams)
  {
//    FindBug_Fix_SUNAINA_ENDED
	  ArrayList alRemovdup=new ArrayList();
	  for(int i=0;i<alDupCriParams.size();i++)
	  {
		  alRemovdup.add(alDupCriParams.get(i));
		  for(int j=i+1;j<alDupCriParams.size();j++)
		  {
			  if(alDupCriParams.get(i).equals(alDupCriParams.get(j)))
			  {
				  alDupCriParams.remove(j);
				  j--;
			  }
		  }

	  }
	  return alRemovdup;
  }


 //Arun_FSOtherBenefitsTargetTab_REL8.1 End
  //Arun_SIT_TargetTab_ExchangeParam_fix_start
  public ArrayList getSeqNumbers(long a_lseqnbr,String a_strQuery) throws EElixirException
  {
	  ArrayList alSeqNumbers=null;
	  ResultSet rsSeqNbrsResult = null;
      PreparedStatement pstmtSeqNbrs = null;
      try
      {
    	  alSeqNumbers=new ArrayList();
    	  log.debug("BenefitDax--getSeqNumbers()--query is "+a_strQuery);
    	  pstmtSeqNbrs = getPreparedStatement(a_strQuery);
    	  pstmtSeqNbrs.setLong(1, a_lseqnbr);
    	  rsSeqNbrsResult = executeQuery(pstmtSeqNbrs);
		  while(rsSeqNbrsResult.next())
		  {
			if(rsSeqNbrsResult.getLong("seqnbr")!=0)
			{
			 alSeqNumbers.add(new Long(rsSeqNbrsResult.getLong("seqnbr")));
			 log.debug("seqnumbers are "+rsSeqNbrsResult.getLong("seqnbr"));
			}
		  }
      }
      catch(SQLException sqlex){
		  sqlex.printStackTrace();
		  log.exception(sqlex.getMessage());
		  throw new EElixirException(sqlex,"P9555");
		}
		catch(EElixirException eex)
		{
		  eex.printStackTrace();
		  log.exception(eex.getMessage());
		  throw new EElixirException(eex,"P9555");
		}
		finally
		{
		  try
		  {
			if(rsSeqNbrsResult != null)
				rsSeqNbrsResult.close();

			if(pstmtSeqNbrs != null)
				pstmtSeqNbrs.close();
		  }
		  catch(SQLException sqlex){
			sqlex.printStackTrace();
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
		  }
		}

	  return alSeqNumbers;
  }
  public Long getNextSeqNumber(String a_strseqQuery) throws EElixirException
  {
	  try
      {
      	log.debug("BenefitDax-->getNextSeqNumber()-query is "+a_strseqQuery);
         ResultSet rsNextSeqNbr = executeQuery(a_strseqQuery);
		 log.debug("BenefitDax-->getNextSeqNumber()--After Excecute query");
		 rsNextSeqNbr.next();

        Long lSeqVal = new Long(rsNextSeqNbr.getLong(1));
        return lSeqVal;
      }
      catch (SQLException sqlex)
      {
      	log.fatal(getClass().getName(), "getLocChargeSeqNbr ",
              sqlex.getMessage());
          throw new EElixirException(sqlex, "P9555");
      }
      catch (EElixirException eex)
      {
      	log.fatal(getClass().getName(), "getLocChargeSeqNbr ",
              eex.getMessage());
          throw new EElixirException(eex, "P9555");
      }

  }
   //Arun_SIT_TargetTab_ExchangeParam_fix_End

    private BonusDAX getDAX() throws EElixirException
    {
        _oConnection = DBConnection.getConnection();

        CHMDAXFactory oDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        BonusDAX _oBonusDAX = (BonusDAX) oDAXFactory.createDAX(CHMDAXFactory.BONUSDAX);
        _oBonusDAX.setConnection(_oConnection);

        return _oBonusDAX;
    }
    //<!--ANUP_DST_Incentive_April_REL_Start-->	
    public ArrayList getPersistReductSearch(long lBonusHdrSeqNbr) throws EElixirException
    {
        ArrayList alDSTDetails = new ArrayList();
        PreparedStatement psSelect = null;
        ResultSet rsSelect = null;
        PerReductionResult oPerReductionResult = null;
        try
        {
            String strQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_PERSIST_REDUCT_SELECT);
            psSelect = getPreparedStatement(strQuery);
            psSelect.setLong(1, lBonusHdrSeqNbr);
            rsSelect = executeQuery(psSelect);
            log.debug("strQuery "+ strQuery+"  lBonusHdrSeqNbr: "+lBonusHdrSeqNbr);
            while (rsSelect.next())
            {
            	oPerReductionResult = new PerReductionResult();
            	oPerReductionResult.setPercSeqNbr(new Long(rsSelect.getLong("LPERSTSLABSEQNBR")));            	
            	oPerReductionResult.setPersistencyType(rsSelect.getString("STRPERSTTYPE"));
            	oPerReductionResult.setTargetValuePerc(new Double(rsSelect.getDouble("DPERSTTARGET")));
            	oPerReductionResult.setFromPerc(new Double(rsSelect.getDouble("DFROMPERC")));
            	oPerReductionResult.setToPerc(new Double(rsSelect.getDouble("DTOPERC")));
            	oPerReductionResult.setPercentagePerc(new Double(rsSelect.getDouble("DRATEPERC")));  
            	log.debug("LPERSTSLABSEQNBR:   "+rsSelect.getLong("LPERSTSLABSEQNBR")+ rsSelect.getString("STRPERSTTYPE")+rsSelect.getDouble("DPERSTTARGET")+rsSelect.getDouble("DFROMPERC"));
            	alDSTDetails.add(oPerReductionResult);
            }
            return alDSTDetails;
        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw eex;
        } finally
        {
            try
            {
                if (psSelect != null)
                {
                    psSelect.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }
    
    
    public void updatePerReductionDetails(ArrayList alDSTDetails, Long lBonusHdrSeqNbr) throws EElixirException
    {
    	
        PreparedStatement psUpdateAgent = null;
        PerReductionResult oPerReductionResult = null;
        String strQuery = null;
        ResultSet rs = null;
        try
        {
            if (alDSTDetails != null)
            {
                for (int i = 0; i < alDSTDetails.size(); i++)
                {
                	oPerReductionResult = (PerReductionResult) alDSTDetails.get(i);
                	
                    if (oPerReductionResult.getStatusFlag().equals(DataConstants.INSERT_MODE))
                    { log.debug("Inside Insert");
                        long lPersSeqNbr = 0;
                        strQuery = getSQLString("Select", CHMConstants.OTHER_BENEFIT_PERST_REDUCTION_SEQ);
                        rs = executeQuery(strQuery);
                        if (rs.next())
                        {
                        	lPersSeqNbr = rs.getLong(1);
                        } else
                        {
                            log.fatal("Sequence No. not generated");
                            throw new EElixirException("p4528");
                        }
                        strQuery = getSQLString("Insert", CHMConstants.OTHER_BENEFIT_PERST_REDUCTION_INSERT);                        
                        psUpdateAgent = getPreparedStatement(strQuery);
                        psUpdateAgent.setLong(1, lBonusHdrSeqNbr.longValue());
                        psUpdateAgent.setLong(2, lPersSeqNbr);
                        psUpdateAgent.setString(3, oPerReductionResult.getPersistencyType());
                        psUpdateAgent.setDouble(4, oPerReductionResult.getTargetValuePerc().doubleValue());
                        psUpdateAgent.setDouble(5, oPerReductionResult.getFromPerc().doubleValue());
                        psUpdateAgent.setDouble(6, oPerReductionResult.getToPerc().doubleValue());
                        psUpdateAgent.setDouble(7, oPerReductionResult.getPercentagePerc().doubleValue());
                        psUpdateAgent.setString(8, oPerReductionResult.getUserId());
                        executeQuery(psUpdateAgent);
                    }
                    if (oPerReductionResult.getStatusFlag().equals(DataConstants.DELETE_MODE))
                    {
                        strQuery = getSQLString("Delete", CHMConstants.OTHER_BENEFIT_PERST_REDUCTION_DELETE);
                        strQuery = strQuery + " and LPERSTSLABSEQNBR = ? ";
                        log.debug(" Delete Query fired "+ strQuery);
                        psUpdateAgent = getPreparedStatement(strQuery);
                        psUpdateAgent.setLong(1, lBonusHdrSeqNbr.longValue());
                        psUpdateAgent.setLong(2, oPerReductionResult.getPercSeqNbr().longValue());
                        executeQuery(psUpdateAgent);
                    }
                    if (oPerReductionResult.getStatusFlag().equals(DataConstants.DISPLAY_MODE))
                    {
                    	log.debug("Inside UPDATE_MODE");
                        strQuery = getSQLString("Update", CHMConstants.OTHER_BENEFIT_PERST_REDUCTION_UPDATE);
                       
                        psUpdateAgent = getPreparedStatement(strQuery);
                        psUpdateAgent.setString(1, oPerReductionResult.getPersistencyType());
                        psUpdateAgent.setDouble(2, oPerReductionResult.getTargetValuePerc().doubleValue());
                        psUpdateAgent.setDouble(3, oPerReductionResult.getFromPerc().doubleValue());
                        psUpdateAgent.setDouble(4, oPerReductionResult.getToPerc().doubleValue());
                        psUpdateAgent.setDouble(5, oPerReductionResult.getPercentagePerc().doubleValue());
                        psUpdateAgent.setString(6, oPerReductionResult.getUserId());
                        psUpdateAgent.setLong(7, lBonusHdrSeqNbr.longValue());
                        psUpdateAgent.setLong(8, oPerReductionResult.getPercSeqNbr().longValue());
                        executeQuery(psUpdateAgent);
                    }
                }
            }

        } catch (SQLException sqlex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
            throw new EElixirException(sqlex, "P4538");
        } catch (EElixirException eex)
        {
            log.fatal(getClass().getName(), "getOtherBenefit", "EElixirException " + eex.getMessage());
            throw eex;
        } finally
        {
            try
            {
                if (psUpdateAgent != null)
                {
                    psUpdateAgent.close();
                }
            } catch (SQLException sqlex)
            {
                log.fatal(getClass().getName(), "getOtherBenefit", "SQLException " + sqlex.getMessage());
                throw new EElixirException(sqlex, "P4538");
            }
        }
    }

    //<!--ANUP_DST_Incentive_April_REL_Ends-->	
    //Anup_AugRel2010_FSD_TPR_V1.3_Starts
    
    /**
     * searchChannelSegments gets the Channel wise TPR Details
     * @return ArrayList
     * @author Anup Kumar
     * @throws EElixirException
     */
	
   public ArrayList searchChannelTPRTypes(String a_cChannelType) throws EElixirException
   {
   	log.entry("BenefitDAX", "searchChannelTPRTypes", "entry");
   	 ResultSet rsSearchannelTPRType = null;
        PreparedStatement _pstmtFindPrimaryKey = null;
        ArrayList _oChannelTPRList = new ArrayList();
        TPRResult _oTPRResult= null;
        try
        {
            log.debug("BenefitDAX--in searchChannelTPRTypes FOR Channel :--- " +
                a_cChannelType);

            String strSelectSubChannelQuery =getSQLString("Select",
                    CHMConstants.FIND_TPRTYPES_BY_CHANNELTYPE);
            log.debug(strSelectSubChannelQuery);

            if (_pstmtFindPrimaryKey == null)
            {
                _pstmtFindPrimaryKey = getPreparedStatement(strSelectSubChannelQuery);
            }

            _pstmtFindPrimaryKey.setString(1, a_cChannelType);

            rsSearchannelTPRType = executeQuery(_pstmtFindPrimaryKey);

            while (rsSearchannelTPRType.next())
            {
           	 _oTPRResult = new TPRResult();

           	 _oTPRResult.setIsDirty(DataConstants.DISPLAY_MODE);
           	 
           	 _oTPRResult.setTPRHdrSeqNbr(new Long(rsSearchannelTPRType.getLong(
           			  "LTPRDEFNHSEQNBR")));
           	        
           	 _oTPRResult.setChannelType(rsSearchannelTPRType.getString(
   			 "CCHANNELTYPE"));
           	            	 
           	 _oTPRResult.setTPRType(rsSearchannelTPRType.getString(
   			 "STRTPRTYPE"));
           	 
           	 _oTPRResult.setTPRDescription(rsSearchannelTPRType.getString(
   			 "STRTPRDESC"));
           	_oTPRResult.setStatusFlag(DataConstants.UPDATE_MODE);
           	 
           	 _oChannelTPRList.add(_oTPRResult);
            }

            log.exit("SegmentDAX", "searchChannelTPRTypes", "exit");
            return _oChannelTPRList;
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());
            throw new EElixirException(sqlex, "aug10e3");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "aug10e3");
        }
        finally
        {
            try
            {
                if (_pstmtFindPrimaryKey != null)
                {
                    _pstmtFindPrimaryKey.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, "aug10e3");
            }
        }
   }
   
   /**
    * findTPRMaster finds whether the TPR is there or not
    * @return boolean
    * @param a_strTPRType String
    * @throws EElixirException
    */
  public boolean findTPRMaster(long a_lTPRHdrSeqNbr)
      throws EElixirException
  {
	   log.entry("BenefitDAX", "findTPRMaster", "entry");
      ResultSet rsSearchTPRMaster = null;
      PreparedStatement pstmtFindPrimaryKey = null;

      try
      {
          String strSelectSegmentQuery = getSQLString("Select",
                  CHMConstants.FIND_TPR_BY_PRIMARYKEY);
          pstmtFindPrimaryKey = getPreparedStatement(strSelectSegmentQuery);
          pstmtFindPrimaryKey.setLong(1,a_lTPRHdrSeqNbr);
          rsSearchTPRMaster = executeQuery(pstmtFindPrimaryKey);

          if (rsSearchTPRMaster.next())
          {
               return true;
          }
          else
          {
               return false;
          }
      }
      catch (SQLException sqlex)
      {
          log.exception(sqlex.getMessage());

          throw new EElixirException(sqlex, "aug10e2");
      }
      catch (EElixirException eex)
      {
          log.exception(eex.getMessage());
          throw new EElixirException(eex, "aug10e2");
      }
      finally
      {
          try
          {
              if (rsSearchTPRMaster != null)
              {
           	   rsSearchTPRMaster.close();
              }

              if (pstmtFindPrimaryKey != null)
              {
                  pstmtFindPrimaryKey.close();
              }
          }
          catch (SQLException sqlex)
          {
              log.exception(sqlex.getMessage());
              throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
          }
      }
  }
  
  
 public TPRResult getTPRMaster(long a_lffseqnbr)
	throws EElixirException
{
	log.entry("BenefitDAX", "getTPRMaster", "entry");
	TPRResult oTPRResult = null;
	ResultSet rsSearchTPRMaster = null;			

	PreparedStatement pstmtSearchTPRMaster = null;			

	try			
	{
		String strTPRMasterQuery = getSQLString("Select", CHMConstants.TPR_MASTERSEQ_SEARCH);
		
		pstmtSearchTPRMaster = getPreparedStatement(strTPRMasterQuery);
		pstmtSearchTPRMaster.setLong(1, a_lffseqnbr);

		rsSearchTPRMaster = executeQuery(pstmtSearchTPRMaster);
		oTPRResult = new TPRResult();

		if (rsSearchTPRMaster.next())
		{
			oTPRResult.setIsDirty(DataConstants.DISPLAY_MODE);
			
			oTPRResult.setTPRHdrSeqNbr(new Long(rsSearchTPRMaster.getLong("LTPRDEFNHSEQNBR")));
			if(rsSearchTPRMaster.wasNull())
				oTPRResult.setTPRHdrSeqNbr(null);
					
			oTPRResult.setTPRType(rsSearchTPRMaster.getString("STRTPRTYPE"));
			oTPRResult.setTPRDescription(rsSearchTPRMaster.getString("STRTPRDESC"));
			oTPRResult.setChannelType(rsSearchTPRMaster.getString("CCHANNELTYPE"));
			if (rsSearchTPRMaster.getString("NVINTAGEFROM") != null) {
			oTPRResult.setVintageFrom(new Long(rsSearchTPRMaster.getLong("NVINTAGEFROM")));
			}else
			oTPRResult.setVintageFrom(null);			
			
			if (rsSearchTPRMaster.getString("NVINTAGETO") != null) {
			oTPRResult.setVintageTo(new Long(rsSearchTPRMaster.getLong("NVINTAGETO")));
			}else
			oTPRResult.setVintageTo(null);
			
			if (rsSearchTPRMaster.getString("NFREQOFCALC") != null) {
			oTPRResult.setFreqCal(new Short(rsSearchTPRMaster.getShort("NFREQOFCALC")));
			}else
			oTPRResult.setFreqCal(null);
			
			if (rsSearchTPRMaster.getString("NFREQOFPROD") != null) {
			oTPRResult.setFreqProd(new Short(rsSearchTPRMaster.getShort("NFREQOFPROD")));
			}else
			oTPRResult.setFreqProd(null);		
			
			oTPRResult.setStatusFlag(DataConstants.UPDATE_MODE);
		
		}
		getCriteriaTPRDetail(oTPRResult);
		//getTPRDesignations(oTPRResult);

		log.exit("BenefitDAX", "getTPRMaster", "exit");
		return oTPRResult;
	}
	catch (SQLException sqlex)
	{
		log.exception(sqlex.getMessage());
		throw new EElixirException(sqlex, "aug10e3");
	}
	catch (EElixirException eex)
	{
		log.exception(eex.getMessage());
		throw new EElixirException(eex, "aug10e3");
	}
	finally
	{
		try
		{
			if (rsSearchTPRMaster != null)
			{
				rsSearchTPRMaster.close();
			}

			if (pstmtSearchTPRMaster != null)
			{
				pstmtSearchTPRMaster.close();
			}
		}
		catch (SQLException sqlex)
		{
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
		}
	}

}
 
 public void getCriteriaTPRDetail(TPRResult oTPRResult) throws EElixirException{
	  
	    log.entry("BenefitDAX", "getCriteriaTPRDetail", "entry");
	    ResultSet rsTPRCriteriaDetails = null;			
   	PreparedStatement pstmtTPRCriteriaDetails = null;
   	TPRDetailsResult oTPRDetailsResult =null;
   	ArrayList _oTPRCriteriaDtlList = new ArrayList();
   	
		try			
		{
			String strTPRDetailsQuery = getSQLString("Select", CHMConstants.TPR_SEARCH_MASTER_DETAILS);
			
			pstmtTPRCriteriaDetails = getPreparedStatement(strTPRDetailsQuery);
			pstmtTPRCriteriaDetails.setLong(1, oTPRResult.getTPRHdrSeqNbr().longValue());

			rsTPRCriteriaDetails = executeQuery(pstmtTPRCriteriaDetails);
			while (rsTPRCriteriaDetails.next()) {
				oTPRDetailsResult = new TPRDetailsResult();

				oTPRDetailsResult
						.setIsDirty(DataConstants.DISPLAY_MODE);

				oTPRDetailsResult.setTPRDetSeqNbr(new Long(
						rsTPRCriteriaDetails.getLong("LTPRDEFNDSEQNBR")));
				
				oTPRDetailsResult
						.setParamCd(rsTPRCriteriaDetails
								.getString("STRPARAMCD"));
				oTPRDetailsResult
						.setTargetValue(rsTPRCriteriaDetails
								.getString("DTARGET"));
				
				if (rsTPRCriteriaDetails.getTimestamp("DTEFFFROM") != null) {
					oTPRDetailsResult.setDtEffFrom(DateUtil
							.retGregorian(rsTPRCriteriaDetails
									.getTimestamp("DTEFFFROM")));
				} else {
					oTPRDetailsResult.setDtEffFrom(null);
				}
				if (rsTPRCriteriaDetails.getTimestamp("DTEFFTO") != null) {
					oTPRDetailsResult.setDtEffTo(DateUtil
							.retGregorian(rsTPRCriteriaDetails
									.getTimestamp("DTEFFTO")));
				} else {
					oTPRDetailsResult.setDtEffTo(null);
				}

		
				if (new Short(
						rsTPRCriteriaDetails.getShort("NISPARAMAPPL")) != null) {
					oTPRDetailsResult.setIsParamAppl(new Short(
							rsTPRCriteriaDetails.getShort("NISPARAMAPPL")));
				} else {
					oTPRDetailsResult.setIsParamAppl(null);
				}
				
				if(rsTPRCriteriaDetails.getString("STRSEGMENTCD")!= null){
				oTPRDetailsResult.setSegmentatonCd(rsTPRCriteriaDetails
						.getString("STRSEGMENTCD"));
				}else{
					oTPRDetailsResult.setSegmentatonCd(null);
				}


				if (rsTPRCriteriaDetails.getTimestamp("DTUPDATED") != null) {
					oTPRDetailsResult
							.setTsDtUpdated(rsTPRCriteriaDetails
									.getTimestamp("DTUPDATED"));
				} else {
					oTPRDetailsResult.setTsDtUpdated(null);
				}
				
				oTPRDetailsResult
						.setStatusFlag(DataConstants.UPDATE_MODE); // changed
				
				_oTPRCriteriaDtlList.add(oTPRDetailsResult);
			}

			oTPRResult.setTPRDetails(_oTPRCriteriaDtlList);
			log.exit("BenefitDAX", "getCriteriaTPRDetail", "exit");
		
		}
		catch (SQLException sqlex)
		{
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, "aug10e3");
		}
		catch (EElixirException eex)
		{
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "aug10e3");
		}
		finally
		{
			try
			{
				if (rsTPRCriteriaDetails != null)
				{
					rsTPRCriteriaDetails.close();
				}

				if (pstmtTPRCriteriaDetails != null)
				{
					pstmtTPRCriteriaDetails.close();
				}
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
 }
 
	
 
 /**
	 * Inserts a new record
	 * 
	 * @param a_oTPRResult
	 *            TPRResult
	 * @throws EElixirException
	 */
	public long createTPRMaster(TPRResult a_oTPRResult)
			throws EElixirException {
		PreparedStatement pstmtCreateTPRMst = null;
		long _lTPRHdrSeqNbr;		
		try {
			String strInsertTPRMstQuery = getSQLString("Insert",
					CHMConstants.TPR_MASTER_INSERT);
			pstmtCreateTPRMst = getPreparedStatement(strInsertTPRMstQuery);
			_lTPRHdrSeqNbr = getNextTPRHdrSeqNbr();
			int iPos = 0;
			pstmtCreateTPRMst.setLong(++iPos, _lTPRHdrSeqNbr);
			pstmtCreateTPRMst.setString(++iPos, a_oTPRResult
					.getTPRType().toUpperCase());
			pstmtCreateTPRMst.setString(++iPos, a_oTPRResult
					.getChannelType());
			pstmtCreateTPRMst.setString(++iPos, a_oTPRResult
					.getTPRDescription());
			pstmtCreateTPRMst.setString(++iPos, a_oTPRResult.getUserId());
			executeUpdate(pstmtCreateTPRMst);
			return _lTPRHdrSeqNbr;
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			log.fatal(sqlex.getMessage());
			throw new EElixirException(sqlex, "aug10e5");
		} catch (EElixirException eex) {
			eex.printStackTrace();
			log.fatal(eex.getMessage());
			throw new EElixirException(eex, "aug10e5");
		} finally {
			try {
				if (pstmtCreateTPRMst != null) {
					pstmtCreateTPRMst.close();
				}
			} catch (SQLException sqlex) {
				sqlex.printStackTrace();
				log.fatal(sqlex.getMessage());
				throw new EElixirException(sqlex, "aug10e5");
			}
		}
	}
	

public void updateTPRMaster(TPRResult a_oTPRResult)
	throws EElixirException
{
	log.entry("BenefitDAX","updateTPRMaster","starts");
	PreparedStatement pstmtUpdateTPRMaster = null;
   ArrayList alTPRCriteriaDetails = null;
	try
	{
		// Alex_TPR_SIT_FIX 3 Aug 2010 Start		 
		String strTPRMasterQuery = getSQLString("Update", CHMConstants.TPR_MASTER_UPDATE);
		String strTPRMasterQuerywithOutDetail = getSQLString("Update",  CHMConstants.TPR_MASTER_UPDATE_WITHOUT_DETAIL);
		String strChannelType = a_oTPRResult.getChannelType();
		String strTPRType = a_oTPRResult.getTPRType();
		String strTPRDesc = a_oTPRResult.getTPRDescription();	
		Long nVintageFrom = a_oTPRResult.getVintageFrom();
		Long nVintageTo = a_oTPRResult.getVintageTo();
		Short nFreqCal = a_oTPRResult.getFreqCal();
		Short nFreqProd = a_oTPRResult.getFreqProd();		
		String strUpdatedBy = a_oTPRResult.getUserId();
		int iPos =0;
		if(a_oTPRResult.get_strTPRScreen()==null){
			pstmtUpdateTPRMaster = getPreparedStatement(strTPRMasterQuery);			
			if(strTPRType != null)
				pstmtUpdateTPRMaster.setString(++iPos,strTPRType);
			else
				pstmtUpdateTPRMaster.setNull(++iPos, Types.VARCHAR);
	
			if(strTPRDesc != null)
				pstmtUpdateTPRMaster.setString(++iPos,strTPRDesc);
			else
				pstmtUpdateTPRMaster.setNull(++iPos, Types.VARCHAR);
			
			if(strChannelType != null)
				pstmtUpdateTPRMaster.setString(++iPos,strChannelType);
			else
				pstmtUpdateTPRMaster.setNull(++iPos, Types.VARCHAR);
			
			if(nFreqCal != null)
				pstmtUpdateTPRMaster.setShort(++iPos,nFreqCal.shortValue());
			else
				pstmtUpdateTPRMaster.setNull(++iPos, Types.SMALLINT);
			
			if(nFreqProd != null)
				pstmtUpdateTPRMaster.setShort(++iPos,nFreqProd.shortValue());
			else
				pstmtUpdateTPRMaster.setNull(++iPos, Types.SMALLINT);
			
			if(nVintageFrom != null)
				pstmtUpdateTPRMaster.setLong(++iPos,nVintageFrom.longValue());
			else
				pstmtUpdateTPRMaster.setNull(++iPos, Types.SMALLINT);
			
			if(nVintageTo != null)
				pstmtUpdateTPRMaster.setLong(++iPos,nVintageTo.longValue());
			else
				pstmtUpdateTPRMaster.setNull(++iPos, Types.SMALLINT);		
			
			pstmtUpdateTPRMaster.setString(++iPos,strUpdatedBy);
			pstmtUpdateTPRMaster.setLong(++iPos,a_oTPRResult.getTPRHdrSeqNbr().longValue());			
	
			int rowsUpdated = executeUpdate(pstmtUpdateTPRMaster);
		
			log.debug("calling Updated records"+rowsUpdated);
	
			//Insert Criteria parameter details for TPR
			alTPRCriteriaDetails = a_oTPRResult.getTPRDetails();
			log.debug("above if condition in dax");
				if(alTPRCriteriaDetails != null && alTPRCriteriaDetails.size() > 0){				
					addUpdateDeleteTPRCriteriaDetails(a_oTPRResult);
				}	
				log.exit("BenefitDAX","updateTPRMaster","exit");
		}else{		
			pstmtUpdateTPRMaster = getPreparedStatement(strTPRMasterQuerywithOutDetail);
			pstmtUpdateTPRMaster.setString(++iPos,strTPRType);
			pstmtUpdateTPRMaster.setString(++iPos,strTPRDesc);
			pstmtUpdateTPRMaster.setString(++iPos,strUpdatedBy);
			pstmtUpdateTPRMaster.setLong(++iPos,a_oTPRResult.getTPRHdrSeqNbr().longValue());	
			int rowsUpdated = executeUpdate(pstmtUpdateTPRMaster);
			log.debug("Only Update Master Table");
		}
		// Alex_TPR_SIT_FIX 3 Aug 2010 End		 
	}				
	catch (SQLException sqlex)
	{
		log.exception(sqlex.getMessage());

		//throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
		throw new EElixirException(sqlex, "aug10e4");
	}
	catch (EElixirException eex)
	{
		log.exception(eex.getMessage());
		throw eex;
	}
	finally
	{
		try
		{
			if (pstmtUpdateTPRMaster != null)
			{
				pstmtUpdateTPRMaster.close();
			}
		}
		catch (SQLException sqlex)
		{
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
		}
	}
}

public void addUpdateDeleteTPRCriteriaDetails(TPRResult a_oTPRResult)
throws EElixirException
{
	log.debug("addUpdateDeleteRYCRuledesgnDetails");
	ArrayList alTPRCriteriaDetails = a_oTPRResult.getTPRDetails();
	
	TPRDetailsResult oTPRDetailsResult = null; 
	log.debug("alRYCRuleDesgDetails.size() : " + alTPRCriteriaDetails.size());
	int iSize=alTPRCriteriaDetails.size();
	
	for (int i = 0; i < iSize; i++)
	{
		oTPRDetailsResult  = (TPRDetailsResult ) alTPRCriteriaDetails.get(i);
		String strStatusFlag = oTPRDetailsResult.getStatusFlag();
		
	
		if (strStatusFlag == null)
		{
			strStatusFlag = DataConstants.UPDATE_MODE;
			log.debug("addUpdateDeleteTPRCriteriaDetails.Status()UPdate:--->"+strStatusFlag);
		}
	
		if (strStatusFlag.equals(DataConstants.INSERT_MODE))
		{
		
			log.debug("addUpdateDeleteTPRCriteriaDetails.Status()Insert:--->"+strStatusFlag);
			createTPRCriteriaDetails(oTPRDetailsResult,a_oTPRResult.getTPRHdrSeqNbr().longValue(),
										a_oTPRResult.getUserId());
		}
	
		if (strStatusFlag.equals(DataConstants.UPDATE_MODE))
		{
			log.debug("addUpdateDeleteTPRCriteriaDetails.Status()Update:--->"+strStatusFlag);
			updateTPRCriteriaDetails(oTPRDetailsResult,a_oTPRResult.getTPRHdrSeqNbr().longValue(),
					a_oTPRResult.getUserId());
		}
	
		if (strStatusFlag.equals(DataConstants.DELETE_MODE))
		{
			log.debug("alRYCRuleDesgDetails.Status() Delete:--->"+strStatusFlag);
			deleteTPRCriteriaDetails(oTPRDetailsResult,a_oTPRResult.getTPRHdrSeqNbr().longValue(),
					a_oTPRResult.getUserId());
		}
	}
	
	
}
	
public void createTPRCriteriaDetails(
		TPRDetailsResult a_oTPRCrieteriaResult, long _lHdrSeqNbr, String strUserID) throws EElixirException {
	
	log.entry("BenefitDAX","createTPRCriteriaDetails","starts");
	PreparedStatement pstmtCreateTPRCriteria = null;
	long _dtlSeqNumb =0;
	try {
		
		String strInsertTPRCriQuery = getSQLString("Insert",
				CHMConstants.TPR_CRITERIA_DETAILS_INSERT);
		pstmtCreateTPRCriteria = getPreparedStatement(strInsertTPRCriQuery);
		
	GregorianCalendar dtEffFrom = a_oTPRCrieteriaResult
				.getDtEffFrom();
		GregorianCalendar dtEffTo = a_oTPRCrieteriaResult
				.getDtEffTo();
		
		_dtlSeqNumb = getNextTPRDtlSeqNbr();
		int iPos = 0;

		log.debug("TPR Dtl SeqNbr"+_dtlSeqNumb);
		log.debug("TPR HDR SeqNbr"+_lHdrSeqNbr);
		
		pstmtCreateTPRCriteria.setLong(++iPos, _dtlSeqNumb);
		
		pstmtCreateTPRCriteria.setLong(++iPos, _lHdrSeqNbr);
	
		pstmtCreateTPRCriteria.setString(++iPos,
				a_oTPRCrieteriaResult.getParamCd());

		if(a_oTPRCrieteriaResult.getTargetValue() != null)
		{
			pstmtCreateTPRCriteria.setDouble(++iPos, new Double(
				a_oTPRCrieteriaResult.getTargetValue()).doubleValue());
		}
		else
		{
			pstmtCreateTPRCriteria.setNull(++iPos,Types.DOUBLE);
		}

		if (dtEffFrom != null) {
			pstmtCreateTPRCriteria.setTimestamp(++iPos, DateUtil
					.retTimestamp(dtEffFrom));
		}
		else
		{
			pstmtCreateTPRCriteria.setNull(++iPos,Types.TIMESTAMP);
		}

		if (dtEffTo != null) {
			pstmtCreateTPRCriteria.setTimestamp(++iPos, DateUtil
					.retTimestamp(dtEffTo));
		}
		else
		{
			pstmtCreateTPRCriteria.setNull(++iPos,Types.TIMESTAMP);
		}
		
		
		if (a_oTPRCrieteriaResult.getIsParamAppl() != null) {
			pstmtCreateTPRCriteria.setShort(++iPos, a_oTPRCrieteriaResult.getIsParamAppl().shortValue());
		}
		else
		{
			pstmtCreateTPRCriteria.setNull(++iPos,Types.SMALLINT);
		}
		if(a_oTPRCrieteriaResult.getSegmentatonCd() !=null){
		pstmtCreateTPRCriteria.setString(++iPos,
				a_oTPRCrieteriaResult.getSegmentatonCd());
		}else
		{
			pstmtCreateTPRCriteria.setNull(++iPos,Types.VARCHAR);
		}
		pstmtCreateTPRCriteria.setString(++iPos, strUserID);

		executeUpdate(pstmtCreateTPRCriteria);
		log.entry("BenefitDAX","createTPRCriteriaDetails","end");
	} catch (SQLException sqlex) {
		sqlex.printStackTrace();
		log.fatal(sqlex.getMessage());
		throw new EElixirException(sqlex, "aug10e4");
	} catch (EElixirException eex) {
		eex.printStackTrace();
		log.fatal(eex.getMessage());
		throw new EElixirException(eex, "aug10e4");
	} finally {
		try {
			if (pstmtCreateTPRCriteria != null) {
				pstmtCreateTPRCriteria.close();
			}
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			log.fatal(sqlex.getMessage());
			throw new EElixirException(sqlex, "aug10e4");
		}
	}

}

public void updateTPRCriteriaDetails(
		TPRDetailsResult a_oTPRCrieteriaResult, long _lHdrSeqNbr, String strUserID) throws EElixirException {
	
	log.entry("SegmentDAX","updateTPRCriteriaDetails","starts");
	PreparedStatement pstmtUpdateTPRCriteria = null;
	try {
		
		String strInsertTPRCriQuery = getSQLString("Update",
				CHMConstants.TPR_CRITERIA_DETAILS_UPDATE);
		pstmtUpdateTPRCriteria = getPreparedStatement(strInsertTPRCriQuery);
		
	GregorianCalendar dtEffFrom = a_oTPRCrieteriaResult
				.getDtEffFrom();
		GregorianCalendar dtEffTo = a_oTPRCrieteriaResult
				.getDtEffTo();
		
		int iPos = 0;
		
		log.debug("_l TPRHDRSeqNbr"+_lHdrSeqNbr);
		pstmtUpdateTPRCriteria.setLong(++iPos, _lHdrSeqNbr);
	
		pstmtUpdateTPRCriteria.setString(++iPos,
				a_oTPRCrieteriaResult.getParamCd());

		if(a_oTPRCrieteriaResult.getTargetValue() != null)
		{
			pstmtUpdateTPRCriteria.setDouble(++iPos, new Double(
				a_oTPRCrieteriaResult.getTargetValue()).doubleValue());
		}
		else
		{
			pstmtUpdateTPRCriteria.setNull(++iPos,Types.DOUBLE);
		}

		if (dtEffFrom != null) {
			pstmtUpdateTPRCriteria.setTimestamp(++iPos, DateUtil
					.retTimestamp(dtEffFrom));
		}
		else
		{
			pstmtUpdateTPRCriteria.setNull(++iPos,Types.TIMESTAMP);
		}

		if (dtEffTo != null) {
			pstmtUpdateTPRCriteria.setTimestamp(++iPos, DateUtil
					.retTimestamp(dtEffTo));
		}
		else
		{
			pstmtUpdateTPRCriteria.setNull(++iPos,Types.TIMESTAMP);
		}
		

		if (a_oTPRCrieteriaResult.getIsParamAppl() != null) {
			pstmtUpdateTPRCriteria.setShort(++iPos, a_oTPRCrieteriaResult.getIsParamAppl().shortValue());
		}
		else
		{
			pstmtUpdateTPRCriteria.setNull(++iPos,Types.SMALLINT);
		}
		
		if (a_oTPRCrieteriaResult.getSegmentatonCd() != null) {
			pstmtUpdateTPRCriteria.setString(++iPos, a_oTPRCrieteriaResult.getSegmentatonCd());
		}
		else
		{
			pstmtUpdateTPRCriteria.setNull(++iPos,Types.VARCHAR);
		}

		pstmtUpdateTPRCriteria.setString(++iPos, strUserID);
		
		pstmtUpdateTPRCriteria.setLong(++iPos, a_oTPRCrieteriaResult.getTPRDetSeqNbr().longValue());
		
		executeUpdate(pstmtUpdateTPRCriteria);
		
		log.exit("SegmentDAX","updateTPRCriteriaDetails","exit");

	} catch (SQLException sqlex) {
		sqlex.printStackTrace();
		log.fatal(sqlex.getMessage());
		throw new EElixirException(sqlex, "aug10e6");
	} catch (EElixirException eex) {
		eex.printStackTrace();
		log.fatal(eex.getMessage());
		throw new EElixirException(eex, "aug10e6");
	} finally {
		try {
			if (pstmtUpdateTPRCriteria != null) {
				pstmtUpdateTPRCriteria.close();
			}
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			log.fatal(sqlex.getMessage());
			throw new EElixirException(sqlex, "aug10e6");
		}
	}

}

public void deleteTPRCriteriaDetails(
		TPRDetailsResult a_oTPRCrieteriaResult, long _lHdrSeqNbr, String strUserID) throws EElixirException {
	
	log.entry("BenefitDAX","deleteTPRCriteriaDetails","starts");
	PreparedStatement pstmtDeleteTPRCriteria = null;
	try {
		
		String strDeleteTPRCriQuery = getSQLString("Delete",
				CHMConstants.TPR_MASTER_DETAILS_DELETE);
		pstmtDeleteTPRCriteria = getPreparedStatement(strDeleteTPRCriQuery);

		int iPos = 0;
		pstmtDeleteTPRCriteria.setLong(++iPos, _lHdrSeqNbr);
		pstmtDeleteTPRCriteria.setLong(++iPos, a_oTPRCrieteriaResult.getTPRDetSeqNbr().longValue());
		log.debug("4");
		executeUpdate(pstmtDeleteTPRCriteria);
		
		log.entry("BenefitDAX","deleteTPRCriteriaDetails","end");

	} catch (SQLException sqlex) {
		sqlex.printStackTrace();
		log.fatal(sqlex.getMessage());
		throw new EElixirException(sqlex, "aug10e7");
	} catch (EElixirException eex) {
		eex.printStackTrace();
		log.fatal(eex.getMessage());
		throw new EElixirException(eex, "aug10e7");
	} finally {
		try {
			if (pstmtDeleteTPRCriteria != null) {
				pstmtDeleteTPRCriteria.close();
			}
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			log.fatal(sqlex.getMessage());
			throw new EElixirException(sqlex, "aug10e7");
		}
	}

}
	
	protected long getNextTPRHdrSeqNbr() throws EElixirException
	{
	    Statement stmtTPRMaster = null;
	    long lSeqNo;
	    try
	    {
	     String strNextSeqQuery = getSQLString("Select",CHMConstants.TPR_HDR_SEQ);
	
	      stmtTPRMaster = getStatement();
	      ResultSet rsSeqNo = stmtTPRMaster.executeQuery(strNextSeqQuery);
	      rsSeqNo.next();
	      lSeqNo = rsSeqNo.getLong(1);
	      log.debug(lSeqNo + "");
	      return lSeqNo;
	    }
	    catch(SQLException sqlex){
	      sqlex.printStackTrace();
	      log.exception(sqlex.getMessage());
	      throw new EElixirException(sqlex, sqlex.getErrorCode() + "aug10e8");
	    }
	    finally
	    {
	      try
	      {
	        if(stmtTPRMaster != null)
	        	stmtTPRMaster.close();
	      }
	      catch(SQLException sqlex){
	        sqlex.printStackTrace();
	        log.exception(sqlex.getMessage());
	        throw new EElixirException(sqlex, sqlex.getErrorCode() + "aug10e8");
	      }
	    }
   }
	
	protected long getNextTPRDtlSeqNbr() throws EElixirException
	{
	    Statement stmtTPRMaster = null;
	    long lSeqNo;
	    try
	    {
	     String strNextSeqQuery = getSQLString("Select",CHMConstants.TPR_DTL_MASTER_SEQ);
	
	      stmtTPRMaster = getStatement();
	      ResultSet rsSeqNo = stmtTPRMaster.executeQuery(strNextSeqQuery);
	      rsSeqNo.next();
	      lSeqNo = rsSeqNo.getLong(1);
	      log.debug(lSeqNo + "");
	      return lSeqNo;
	    }
	    catch(SQLException sqlex){
	      sqlex.printStackTrace();
	      log.exception(sqlex.getMessage());
	      throw new EElixirException(sqlex, sqlex.getErrorCode() + "aug10e9");
	    }
	    finally
	    {
	      try
	      {
	        if(stmtTPRMaster != null)
	        	stmtTPRMaster.close();
	      }
	      catch(SQLException sqlex){
	        sqlex.printStackTrace();
	        log.exception(sqlex.getMessage());
	        throw new EElixirException(sqlex, sqlex.getErrorCode() + "aug10e9");
	      }
	    }
   }
	
	/**
	 * deletes TPRResult record
	 * 
	 * @return void
	 * @param TPRResult
	 * @throws EElixirException
	 */
	public void deleteTPRMaster(TPRResult oTPRResult)
			throws EElixirException {
		PreparedStatement _pstmtTPR = null;
		PreparedStatement pstmtTPRCriteria = null;
		Long TPRHdrSeqNbr = oTPRResult.getTPRHdrSeqNbr();
		try {
			String strdeleteSegment = getSQLString("Delete",
					CHMConstants.TPR_MASTER_DELETE);			
			_pstmtTPR = getPreparedStatement(strdeleteSegment);
			_pstmtTPR.setLong(1, TPRHdrSeqNbr.longValue());
			executeUpdate(_pstmtTPR);
			String strdeleteTPRCriteria = getSQLString("Delete",
					CHMConstants.TPR_MASTER_DETAILS_DELETE_ALL);
			pstmtTPRCriteria = getPreparedStatement(strdeleteTPRCriteria);
			pstmtTPRCriteria.setLong(1, TPRHdrSeqNbr.longValue());
			executeUpdate(pstmtTPRCriteria);

		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException("aug10e7");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException("aug10e7");
		} finally {
			try {
				if (_pstmtTPR != null) {
					_pstmtTPR.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "aug10e7");
			}
		}
	}


  //Anup_AugRel2010_FSD_TPR_V1.3_Ends
}
