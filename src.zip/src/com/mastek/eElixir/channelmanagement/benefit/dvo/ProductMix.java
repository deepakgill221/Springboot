/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ProductMix.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for ProductMix</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.dvo;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class ProductMix extends UserData implements Serializable
{
   protected Long _lbenseqnbr;
   protected String _strProdCd;
   protected Integer _iProdVer;
   protected Double _dProdPerc;
   protected String _strStatusFlag;
   /**
   * Constructor
   */
   public ProductMix()
   {

   }
  public Double getProdPerc() {
    return _dProdPerc;
  }
  public void setProdPerc(Double a_dProdPerc) {
    this._dProdPerc = a_dProdPerc;
  }
  public Integer getProdVer() {
    return _iProdVer;
  }
  public void setProdVer(Integer a_iProdVer) {
    this._iProdVer = a_iProdVer;
  }
  public Long getBenSeqNbr() {
    return _lbenseqnbr;
  }
  public void setBenSeqNbr(Long a_lbenseqnbr) {
    this._lbenseqnbr = a_lbenseqnbr;
  }
  public String getProdCd() {
    return _strProdCd;
  }
  public void setProdCd(String a_strProdCd) {
    this._strProdCd = a_strProdCd;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }
  public String toString(){
    String retValue = "";
    retValue = retValue + "_lbenseqnbr:" + _lbenseqnbr + "\n";
    retValue = retValue + "_dProdPerc:" + _dProdPerc + "\n";
    retValue = retValue + "_strProdCd:" + _strProdCd + "\n";
    retValue = retValue + "_iProdVer:" + _iProdVer + "\n";
    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";
    return retValue;

  }
}
