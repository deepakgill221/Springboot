/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitCalculationCriteria.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Benefit Calculation Criteria</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.benefit.dvo;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class BenefitCalculationCriteria extends UserData implements Serializable
{

   /**
    * Header Table Sequence Number
    */
   protected Long _lBenSeqNbr = null;

   /**
    * Benefit Detail Type
    */
   protected Short _nBenDetailType = null;

   /**
    * From Month
    */
   protected Short _nMonthFrom = null;

   /**
    * To Month
    */
   protected Short _nMonthTo = null;


   /**
    * Evaluation Function Name
    */
   protected Short _nEvalFunction = null;


   /**
    * Evaluation Value
    */
   protected Double _dEvalValue = null;



   /**
    * @roseuid 3DB3A4820213
    */
   public BenefitCalculationCriteria()
   {

   }
  public Double getEvalValue() {
    return _dEvalValue;
  }
  public void setEvalValue(Double a_dEvalValue) {
    this._dEvalValue = a_dEvalValue;
  }
  public Long getBenSeqNbr() {
    return _lBenSeqNbr;
  }
  public void setBenSeqNbr(Long a_lBenSeqNbr) {
    this._lBenSeqNbr = a_lBenSeqNbr;
  }
  public Short getBenDetailType() {
    return _nBenDetailType;
  }
  public void setBenDetailType(Short a_nBenDetailType) {
    this._nBenDetailType = a_nBenDetailType;
  }
  public Short getEvalFunction() {
    return _nEvalFunction;
  }
  public void setEvalFunction(Short a_nEvalFunction) {
    this._nEvalFunction = a_nEvalFunction;
  }
  public Short getMonthFrom() {
    return _nMonthFrom;
  }
  public void setMonthFrom(Short a_nMonthFrom) {
    this._nMonthFrom = a_nMonthFrom;
  }
  public Short getMonthTo() {
    return _nMonthTo;
  }
  public void setMonthTo(Short a_nMonthTo) {
    this._nMonthTo = a_nMonthTo;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_lBenSeqNbr:" + _lBenSeqNbr + "\n";
    retValue = retValue + "_nBenDetailType:" + _nBenDetailType + "\n";
    retValue = retValue + "_nMonthFrom:" + _nMonthFrom + "\n";
    retValue = retValue + "_nMonthTo:" + _nMonthTo + "\n";
    retValue = retValue + "_nEvalFunction:" + _nEvalFunction + "\n";
    retValue = retValue + "_dEvalValue:" + _dEvalValue + "\n";
    return retValue;
  }
}
