/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitEligibilityCriteria.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Benefit Eligibility Criteria</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.benefit.dvo;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class BenefitEligibilityCriteria extends UserData implements Serializable
{

   /**
    * Header Sequence Number
    */
   protected Long _lBenSeqNbr = null;

   /**
    * Detail Benefit Type
    */
   protected Short _nBenDetailType = null;

   /**
    * Month From
    */
   protected Short _nMonthFrom = null;

   /**
    * Month To
    */
   protected Short _nMonthTo = null;

   /**
    * Criteria Function Name
    */
   protected Short _nCritFunction = null;

    /**
    * Eligibility Value
    */
   protected String _strElgbleValue = null;


   /**
    * @roseuid 3DB3A48B0373
    */
   public BenefitEligibilityCriteria()
   {

   }
  public Long getBenSeqNbr() {
    return _lBenSeqNbr;
  }
  public void setBenSeqNbr(Long a_lBenSeqNbr) {
    this._lBenSeqNbr = a_lBenSeqNbr;
  }
  public Short getBenDetailType() {
    return _nBenDetailType;
  }
  public void setBenDetailType(Short a_nBenDetailType) {
    this._nBenDetailType = a_nBenDetailType;
  }
  public Short getCritFunction() {
    return _nCritFunction;
  }
  public void setCritFunction(Short a_nCritFunction) {
    this._nCritFunction = a_nCritFunction;
  }
  public Short getMonthFrom() {
    return _nMonthFrom;
  }
  public void setMonthFrom(Short a_nMonthFrom) {
    this._nMonthFrom = a_nMonthFrom;
  }
  public Short getMonthTo() {
    return _nMonthTo;
  }
  public void setMonthTo(Short a_nMonthTo) {
    this._nMonthTo = a_nMonthTo;
  }
  public String getElgbleValue() {
    return _strElgbleValue;
  }
  public void setElgbleValue(String a_strElgbleValue) {
    this._strElgbleValue = a_strElgbleValue;
  }
  public String toString(){
    String retValue = "";
    retValue = retValue + "_lBenSeqNbr:" + _lBenSeqNbr + "\n";
    retValue = retValue + "_nBenDetailType:" + _nBenDetailType + "\n";
    retValue = retValue + "_nMonthFrom:" + _nMonthFrom + "\n";
    retValue = retValue + "_nMonthTo:" + _nMonthTo + "\n";

    retValue = retValue + "_nCritFunction:" + _nCritFunction + "\n";
    retValue = retValue + "_strElgbleValue:" + _strElgbleValue + "\n";
    return retValue;
  }
}
