/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: MY AGENT
*  FILENAME			: OtherBenefitFetch.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: September 17, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*1.1		22-jan-2007		Jimmy K G	Added new fields for Release 8.0.
*										Hold Percentage,Year,Cap Percentage,Paid To,Reportees,
*										Consider Agent Terminated Status,Bonus Level.
*			24-03-2011	   Shrikrishna  CR:FSD-Agent_Compensation_2011_v1.0.doc
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:Helper Class that would get the data from the request object and return OtherBenefitResult object</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Sandeep
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.util;

import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

	public class OtherBenefitFetch
	{
		private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

		public OtherBenefitFetch()
		{
		}

		/**
		 * This Fetches all the paramater for Other benefit
		 * @param a_oRequest HttpServletRequest object.
		 * @return OtherBenefitResult
		 * @throws EElixirException
		 */
		public OtherBenefitResult fetchOtherBenefit(HttpServletRequest a_oRequest)
		{
			
		
			OtherBenefitResult oOtherBenefitResult = new OtherBenefitResult();
			log.debug("strBenDesc :"+a_oRequest.getParameter("strBenDesc")+"--");
			if((a_oRequest.getParameter("strBenDesc") != null) && !(a_oRequest.getParameter("strBenDesc").trim().equals("")))
			{
			    oOtherBenefitResult.setBonusDesc(a_oRequest.getParameter("strBenDesc").trim());
			}

			log.debug("strBenType :"+a_oRequest.getParameter("strBenType")+"--");
			if((a_oRequest.getParameter("strBenType") != null) && !(a_oRequest.getParameter("strBenType").trim().equals("")))
			{
			    oOtherBenefitResult.setBonusType(a_oRequest.getParameter("strBenType").trim());
			}
			log.debug("cChannelType :"+a_oRequest.getParameter("cChannelType")+"--");
			if((a_oRequest.getParameter("cChannelType") != null) && !(a_oRequest.getParameter("cChannelType").trim().equals("")))
			{
			    oOtherBenefitResult.setChannelType(a_oRequest.getParameter("cChannelType").trim());
			}

//Added By jayasimha Reddy

			log.debug("nEndImmediate :"+a_oRequest.getParameter("nEndImmediate")+"--");
			if((a_oRequest.getParameter("nEndImmediate") != null) && !(a_oRequest.getParameter("nEndImmediate").trim().equals("")))
			{
			    oOtherBenefitResult.setEndImmediate(new Short(a_oRequest.getParameter("nEndImmediate").trim()));
			}

			log.debug("strDesgnCd :"+a_oRequest.getParameter("strDesgnCd")+"--");
			if((a_oRequest.getParameter("strDesgnCd") != null) && !(a_oRequest.getParameter("strDesgnCd").trim().equals("")))
			{
			    oOtherBenefitResult.setDesgnCd(a_oRequest.getParameter("strDesgnCd").trim());
			}
			log.debug("dtEffFrom :"+a_oRequest.getParameter("dtEffFrom")+"--");
			if((a_oRequest.getParameter("dtEffFrom") != null) && !(a_oRequest.getParameter("dtEffFrom").trim().equals("")))
			{
			    oOtherBenefitResult.setEffFrom(DateUtil.retGCDate(a_oRequest.getParameter("dtEffFrom").trim()));
			}
			log.debug("dtEffTo :"+a_oRequest.getParameter("dtEffTo")+"--");
			if((a_oRequest.getParameter("dtEffTo") != null) && !(a_oRequest.getParameter("dtEffTo").trim().equals("")))
			{
			    oOtherBenefitResult.setEffTo(DateUtil.retGCDate(a_oRequest.getParameter("dtEffTo").trim()));
			}
			log.debug("nFreqOfCalc :"+a_oRequest.getParameter("nFreqOfCalc")+"--");
			if((a_oRequest.getParameter("nFreqOfCalc") != null) && !(a_oRequest.getParameter("nFreqOfCalc").trim().equals("")))
			{
			    oOtherBenefitResult.setFreqOfCalc(new Short(a_oRequest.getParameter("nFreqOfCalc").trim()));
			}
			log.debug("nStartMonth :"+a_oRequest.getParameter("nStartMonth")+"--");
			if((a_oRequest.getParameter("nStartMonth") != null) && !(a_oRequest.getParameter("nStartMonth").trim().equals("")))
			{
			    oOtherBenefitResult.setStartMonthCalc(new Short(a_oRequest.getParameter("nStartMonth").trim()));
			}
			log.debug("nFreqofPmt :"+a_oRequest.getParameter("nFreqofPmt")+"--");
			if((a_oRequest.getParameter("nFreqofPmt") != null) && !(a_oRequest.getParameter("nFreqofPmt").trim().equals("")))
			{
			    oOtherBenefitResult.setFreqOfPmt(new Short(a_oRequest.getParameter("nFreqofPmt").trim()));
			}
			log.debug("nPmtDay :"+a_oRequest.getParameter("nPmtDay")+"--");
			if((a_oRequest.getParameter("nPmtDay") != null) && !(a_oRequest.getParameter("nPmtDay").trim().equals("")))
			{
			    oOtherBenefitResult.setPmtDay(new Short(a_oRequest.getParameter("nPmtDay").trim()));
			}
			log.debug("nInstallment :"+a_oRequest.getParameter("nInstallment")+"--");
			if((a_oRequest.getParameter("nInstallment") != null) && !(a_oRequest.getParameter("nInstallment").trim().equals("")))
			{
			    oOtherBenefitResult.setNoOfInstallment(new Short(a_oRequest.getParameter("nInstallment").trim()));
			}
			log.debug("nIsTDSAppl :"+a_oRequest.getParameter("nIsTDSAppl")+"--");
			if((a_oRequest.getParameter("nIsTDSAppl") != null) && !(a_oRequest.getParameter("nIsTDSAppl").trim().equals("")))
			{
			    oOtherBenefitResult.setIsTDSAppl(new Short(a_oRequest.getParameter("nIsTDSAppl").trim()));
			}
			log.debug("nIsSTAppl :"+a_oRequest.getParameter("nIsSTAppl")+"--");
			if((a_oRequest.getParameter("nIsSTAppl") != null) && !(a_oRequest.getParameter("nIsSTAppl").trim().equals("")))
			{
			    oOtherBenefitResult.setIsSTAppl(new Short(a_oRequest.getParameter("nIsSTAppl").trim()));
			}
			log.debug("strOSAcctCd :"+a_oRequest.getParameter("strOSAcctCd")+"--");
			if((a_oRequest.getParameter("strOSAcctCd") != null) && !(a_oRequest.getParameter("strOSAcctCd").trim().equals("")))
			{
			    oOtherBenefitResult.setOSAcctCd(a_oRequest.getParameter("strOSAcctCd").trim());
			}
			log.debug("strProvAcctCd :"+a_oRequest.getParameter("strProvAcctCd")+"--");
			if((a_oRequest.getParameter("strProvAcctCd") != null) && !(a_oRequest.getParameter("strProvAcctCd").trim().equals("")))
			{
			    oOtherBenefitResult.setProvAcctCd(a_oRequest.getParameter("strProvAcctCd").trim());
			}
			log.debug("strAcctCd :"+a_oRequest.getParameter("strAcctCd")+"--");
			if((a_oRequest.getParameter("strAcctCd") != null) && !(a_oRequest.getParameter("strAcctCd").trim().equals("")))
			{
			    oOtherBenefitResult.setAcctCd(a_oRequest.getParameter("strAcctCd").trim());
			}
			log.debug("nIsTargetBased :"+a_oRequest.getParameter("nIsTargetBased")+"--");
			if((a_oRequest.getParameter("nIsTargetBased") != null) && !(a_oRequest.getParameter("nIsTargetBased").trim().equals("")))
			{
			    oOtherBenefitResult.setIsTargetBased(new Short(a_oRequest.getParameter("nIsTargetBased").trim()));
			}
			// shameem
			log.debug("nTargetProRata :"+a_oRequest.getParameter("nTargetProRata")+"--");
			if((a_oRequest.getParameter("nTargetProRata") != null) && !(a_oRequest.getParameter("nTargetProRata").trim().equals("")))
			{
				oOtherBenefitResult.setTargetProRata(new Short(a_oRequest.getParameter("nTargetProRata").trim()));
			}
			log.debug("strCriParamIds :"+a_oRequest.getParameter("strCriParamIds")+"--");
			if((a_oRequest.getParameter("strCriParamIds") != null) && !(a_oRequest.getParameter("strCriParamIds").trim().equals("")))
			{
			    oOtherBenefitResult.setCriParamIds(a_oRequest.getParameter("strCriParamIds").trim());
			}
			log.debug("strCriParamNames :"+a_oRequest.getParameter("strCriParamNames")+"--");
			if((a_oRequest.getParameter("strCriParamNames") != null) && !(a_oRequest.getParameter("strCriParamNames").trim().equals("")))
			{
			    oOtherBenefitResult.setCriParamNames(a_oRequest.getParameter("strCriParamNames").trim());
			}
			//if not AAP-BT
			if(oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
			{
			 log.debug("strCriParamIds--AAP_BT values are :"+a_oRequest.getParameter("strCriParamIds")+"--");
			 if((a_oRequest.getParameter("strCriParamIds") != null) && !(a_oRequest.getParameter("strCriParamIds").trim().equals("")))
			 {
			    oOtherBenefitResult.setBonusParamId(a_oRequest.getParameter("strCriParamIds").trim());
			  }
			}
			else
			{
			log.debug("strBonusParamId :"+a_oRequest.getParameter("strBonusParamId")+"--");
			if((a_oRequest.getParameter("strBonusParamId") != null) && !(a_oRequest.getParameter("strBonusParamId").trim().equals("")))
			{
			    oOtherBenefitResult.setBonusParamId(a_oRequest.getParameter("strBonusParamId").trim());
			 }
			}
			//if not AAP-BT
			if(oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
			{
				oOtherBenefitResult.setAmtPerc(null);
				oOtherBenefitResult.setUnits(null);
			}
			else
			{
			log.debug("nAmtPerc :"+a_oRequest.getParameter("nAmtPerc")+"--");
			if((a_oRequest.getParameter("nAmtPerc") != null) && !(a_oRequest.getParameter("nAmtPerc").trim().equals("")))
			{
			    oOtherBenefitResult.setAmtPerc(new Short(a_oRequest.getParameter("nAmtPerc")));
			}
             //if not AAP-BT
			log.debug("dUnits :"+a_oRequest.getParameter("dUnits")+"--");
			if((a_oRequest.getParameter("dUnits") != null) && !(a_oRequest.getParameter("dUnits").trim().equals("")))
			{
			    oOtherBenefitResult.setUnits(new Double(a_oRequest.getParameter("dUnits")));
			 }
			}
            //if not AAP-BT
			log.debug("After else nAmtperc and dunits");
//Jimmy_OtherBenefits_1.3.2.1_REL8.0 Starts
			if(oOtherBenefitResult.getBonusType().equals(DataConstants.AAP_BT))
			{
			 //Arun changed for SIT FIX Start
			 if((a_oRequest.getParameter("nTgtRecalculationType") != null) && !(a_oRequest.getParameter("nTgtRecalculationType").trim().equals("")))
			 {
			  oOtherBenefitResult.setTgtRecalculationType(new Short(a_oRequest.getParameter("nTgtRecalculationType")));
			 }
			 else
			 {
			  oOtherBenefitResult.setTgtRecalculationType(null);
			 }
			 //Arun changed for SIT FIX End
			  log.debug("nTgtRecalculationType :"+a_oRequest.getParameter("nTgtRecalculationType")+"--");

			}
			else
			{
			log.debug("nRecalculationType :"+a_oRequest.getParameter("nRecalculationType")+"--");
			if((a_oRequest.getParameter("nRecalculationType") != null) && !(a_oRequest.getParameter("nRecalculationType").trim().equals("")))
			{
				if(oOtherBenefitResult.getFreqOfCalc().toString().equals(String.valueOf(DataConstants.YEARLY)))
				{
					oOtherBenefitResult.setRecalculationType(null);
				}
				else
				{
					oOtherBenefitResult.setRecalculationType(new Short(a_oRequest.getParameter("nRecalculationType")));
				}
				}
			}
//Jimmy_OtherBenefits_1.3.2.1_REL8.0 Ends
			log.debug("dRate :"+a_oRequest.getParameter("dRate")+"--");
			if(a_oRequest.getParameterValues("dRate") != null)
			{
			    oOtherBenefitResult.setBonusRate((a_oRequest.getParameterValues("dRate")));
			}
			log.debug("strStatusFlag :"+a_oRequest.getParameter("strStatusFlag")+"--");
			if(a_oRequest.getParameterValues("strStatusFlag") != null)
			{
			    oOtherBenefitResult.setParamStatusFlag((a_oRequest.getParameterValues("strStatusFlag")));
			}
			log.debug("PKValueNum :"+a_oRequest.getParameter("PKValueNum")+"--");
			if(a_oRequest.getParameterValues("PKValueNum") != null)
			{
			    oOtherBenefitResult.setParamSeqNbr((a_oRequest.getParameterValues("PKValueNum")));
			}
			log.debug("lBonusHdrSeqNbr :"+a_oRequest.getParameter("lBonusHdrSeqNbr")+"--");
			if((a_oRequest.getParameter("lBonusHdrSeqNbr") != null) && !(a_oRequest.getParameter("lBonusHdrSeqNbr").trim().equals("")))
			{
			    oOtherBenefitResult.setBonusHdrSeqNbr(new Long(a_oRequest.getParameter("lBonusHdrSeqNbr")));
			}
			//if not AAP-BT
			log.debug("dTargetValue :"+a_oRequest.getParameter("dTargetValue")+"--");
			if((a_oRequest.getParameter("dTargetValue") != null) && !(a_oRequest.getParameter("dTargetValue").trim().equals("")))
			{
			    oOtherBenefitResult.setTargetValue(new Double(a_oRequest.getParameter("dTargetValue")));
			}
			log.debug("nIsInclOrExclTgt :"+a_oRequest.getParameter("nIsInclOrExclTgt")+"--");
			if((a_oRequest.getParameter("nIsInclOrExclTgt") != null) && !(a_oRequest.getParameter("nIsInclOrExclTgt").trim().equals("")))
			{
			    oOtherBenefitResult.setIsInclOrExclTgt(new Short(a_oRequest.getParameter("nIsInclOrExclTgt")));
			}
			log.debug("nIsInclOrExclPmt :"+a_oRequest.getParameter("nIsInclOrExclPmt")+"--");
			if((a_oRequest.getParameter("nIsInclOrExclPmt") != null) && !(a_oRequest.getParameter("nIsInclOrExclPmt").trim().equals("")))
			{
			    oOtherBenefitResult.setIsInclOrExclPmt(new Short(a_oRequest.getParameter("nIsInclOrExclPmt")));
			}
			log.debug("nFreqOfInst :"+a_oRequest.getParameter("nFreqOfInst")+"--");
			if((a_oRequest.getParameter("nFreqOfInst") != null) && !(a_oRequest.getParameter("nFreqOfInst").trim().equals("")))
			{
			    oOtherBenefitResult.setFreqOfInstallment(new Short(a_oRequest.getParameter("nFreqOfInst")));
			}

			// shameem
			log.debug("nIsCampaign :"+a_oRequest.getParameter("nIsCampaign")+"--");
			if((a_oRequest.getParameter("nIsCampaign") != null) && !(a_oRequest.getParameter("nIsCampaign").trim().equals("")))
			{
			 	oOtherBenefitResult.setIsCampaign(new Short(a_oRequest.getParameter("nIsCampaign").trim()));
			}
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
			log.debug("nHoldPercentage :"+a_oRequest.getParameter("nHoldPercentage")+"--");
			if((a_oRequest.getParameter("nHoldPercentage")!= null) && !(a_oRequest.getParameter("nHoldPercentage").trim().equals("")))
			{
				oOtherBenefitResult.setHoldPercentage(new Double(a_oRequest.getParameter("nHoldPercentage").trim()));
			}
			log.debug("nCapPercentage :"+a_oRequest.getParameter("nCapPercentage")+"--");
			if((a_oRequest.getParameter("nCapPercentage")!= null) && !(a_oRequest.getParameter("nCapPercentage").trim().equals("")))
			{
				oOtherBenefitResult.setCapPercentage(new Double(a_oRequest.getParameter("nCapPercentage").trim()));
			}
			log.debug("nReportees :"+a_oRequest.getParameter("nReportees")+"--");
			if((a_oRequest.getParameter("nReportees")!= null) && !(a_oRequest.getParameter("nReportees").trim().equals("")))
			{
				oOtherBenefitResult.setReportees(new Short(a_oRequest.getParameter("nReportees").trim()));
			}
			log.debug("nAgtTerminatedStat :"+a_oRequest.getParameter("nAgtTerminatedStat")+"--");
			if((a_oRequest.getParameter("nAgtTerminatedStat")!= null) && !(a_oRequest.getParameter("nAgtTerminatedStat").trim().equals("")))
			{
				oOtherBenefitResult.setAgentTerminatedStatus(new Short(a_oRequest.getParameter("nAgtTerminatedStat").trim()));
			}
			//Amid_added_nBonusToTermAgent_field_Starts
			log.debug("nBonusToTermAgent :"+a_oRequest.getParameter("nBonusToTermAgent")+"--");
			if((a_oRequest.getParameter("nBonusToTermAgent")!= null) && !(a_oRequest.getParameter("nBonusToTermAgent").trim().equals("")))
			{
				oOtherBenefitResult.setBonusToTermAgent(new Short(a_oRequest.getParameter("nBonusToTermAgent").trim()));
			}
			//Amid_added_nBonusToTermAgent_field_Ends
			log.debug("nBonusLevel :"+a_oRequest.getParameter("nBonusLevel")+"--");
			if((a_oRequest.getParameter("nBonusLevel")!= null) && !(a_oRequest.getParameter("nBonusLevel").trim().equals("")))
			{
				oOtherBenefitResult.setBonusLevel(new Short(a_oRequest.getParameter("nBonusLevel").trim()));
			}
			log.debug("nYearBasis :"+a_oRequest.getParameter("nYearBasis")+"--");
			if((a_oRequest.getParameter("nYearBasis")!= null) && !(a_oRequest.getParameter("nYearBasis").trim().equals("")))
			{
				oOtherBenefitResult.setYearBasis(new Short(a_oRequest.getParameter("nYearBasis").trim()));
			}
			log.debug("strPaidToAgtAgncy :"+a_oRequest.getParameter("strPaidToAgtAgncy")+"--");
			if((a_oRequest.getParameter("strPaidToAgtAgncy")!= null) && !(a_oRequest.getParameter("strPaidToAgtAgncy").trim().equals("")))
			{
				oOtherBenefitResult.setPaidToAgentAgency(a_oRequest.getParameter("strPaidToAgtAgncy").trim());
			}
			log.debug("nBnusPayOutMthd :"+a_oRequest.getParameter("nBnusPayOutMthd")+"--");
//Jimmy_OtherBenefits_1.10_REL8.0 Starts
			if((a_oRequest.getParameter("nBnusPayOutMthd")!= null) && !(a_oRequest.getParameter("nBnusPayOutMthd").trim().equals("")))
			{
				oOtherBenefitResult.setBonusPayOutMethod(new Short(a_oRequest.getParameter("nBnusPayOutMthd").trim()));
			}
			log.debug("nMinRequirement :"+a_oRequest.getParameter("nMinRequirement")+"--");
			if((a_oRequest.getParameter("nMinRequirement")!= null) && !(a_oRequest.getParameter("nMinRequirement").trim().equals("")))
			{
				oOtherBenefitResult.setMinRequirement(a_oRequest.getParameter("nMinRequirement").trim());
			}
//Jimmy_OtherBenefits_1.10_REL8.0 Ends
			oOtherBenefitResult.setApplicableAgentAgencyCode(getApplicableAgentAgencyCode(a_oRequest));
			log.debug("ApplicableAgentAgencyCode :"+oOtherBenefitResult.getApplicableAgentAgencyCode());
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
			//CR_OtherBenefit_sequence_Rel8.2_start
			log.debug("nSeqnbr :"+a_oRequest.getParameter("nSeqnbr")+"--");
			if((a_oRequest.getParameter("nSeqnbr") != null) && !(a_oRequest.getParameter("nSeqnbr").trim().equals("")))
			{
			    oOtherBenefitResult.setSeqNbr(new Short(a_oRequest.getParameter("nSeqnbr").trim()));
			}
			//CR_OtherBenefit_sequence_Rel8.2_end
			HttpSession session = a_oRequest.getSession();
			String strUserId = (String) session.getAttribute("username");
		    oOtherBenefitResult.setUserId(strUserId);

		    oOtherBenefitResult.setCriParamDetails(getCriteriaParameterDetails(a_oRequest));
		    oOtherBenefitResult.setApplDesgn(getApplDesgn(a_oRequest));
		    oOtherBenefitResult.setCriDesgn(getCriDesgn(a_oRequest));
//Jimmy_OtherBenefits_1.4_REL8.0 Starts
		    oOtherBenefitResult.setIsMnylAgent(getIsMnylAgent(a_oRequest));
		    log.debug("IsMnylAgent :"+oOtherBenefitResult.getIsMnylAgent()+"--");
//Jimmy_OtherBenefits_1.4_REL8.0 Ends
//Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start
		    oOtherBenefitResult.setDesgCd(getDesgCd(a_oRequest));
		    oOtherBenefitResult.setBaseParamId(getBaseParamId(a_oRequest));
		    oOtherBenefitResult.setIsInclOrExcl(getIsInclOrExcl(a_oRequest));
//Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
		    //Amid_MP/P_Incentive Scheme Starts
		    oOtherBenefitResult.setScoreType(getScoreTypeValue(a_oRequest));
		    oOtherBenefitResult.setGlpWeightage(getGlpWeightageValue(a_oRequest));
		    oOtherBenefitResult.setFrom(getFromValue(a_oRequest));
		    oOtherBenefitResult.setTo(getToValue(a_oRequest));	
		    oOtherBenefitResult.setValue(getGlpValue(a_oRequest));	
		    //Amid_MP/P_Incentive Scheme Ends
//Arun_FSOtherBenefitsTargetTab_REL8.1 starts
		    if((a_oRequest.getParameter("nCriParamUpdateCount")!= null) && !(a_oRequest.getParameter("nCriParamUpdateCount").trim().equals("")))
		    {
		    	oOtherBenefitResult.setTgtCriParamUpdateCount(new Short("2"));
		     }
		    if((a_oRequest.getParameter("strPlanAtchmentTo")!= null) && !(a_oRequest.getParameter("strPlanAtchmentTo").trim().equals("")))
			{
				oOtherBenefitResult.setTgtPlanAttachmentTo(new Short(a_oRequest.getParameter("strPlanAtchmentTo").trim()));
			}
		    if((a_oRequest.getParameter("nTgtRecalculationType")!= null) && !(a_oRequest.getParameter("nTgtRecalculationType").trim().equals("")))
			{
				oOtherBenefitResult.setTgtRecalculationType(new Short(a_oRequest.getParameter("nTgtRecalculationType").trim()));
			}
		    if((a_oRequest.getParameter("criteriaParamId")!= null) && !(a_oRequest.getParameter("criteriaParamId").trim().equals("")))
			{
				oOtherBenefitResult.setTgtCriParamIds(a_oRequest.getParameter("criteriaParamId").trim());
			}
		    if((a_oRequest.getParameter("criteriaParamName")!= null) && !(a_oRequest.getParameter("criteriaParamName").trim().equals("")))
			{
				oOtherBenefitResult.setTgtCriPramNames(a_oRequest.getParameter("criteriaParamName").trim());
			}
		    if((a_oRequest.getParameter("nWeightage")!= null) && !(a_oRequest.getParameter("nWeightage").trim().equals("")))
			{
				oOtherBenefitResult.setTgtOffWeightage(a_oRequest.getParameter("nWeightage").trim());
			}
		    //Modified by Amid Start
		    if((a_oRequest.getParameter("nWeightage2")!= null) && !(a_oRequest.getParameter("nWeightage2").trim().equals("")))
			{
				oOtherBenefitResult.setTgtOffWeightage2(a_oRequest.getParameter("nWeightage2").trim());
			}
		    if((a_oRequest.getParameter("nWeightage3")!= null) && !(a_oRequest.getParameter("nWeightage3").trim().equals("")))
			{
				oOtherBenefitResult.setTgtOffWeightage3(a_oRequest.getParameter("nWeightage3").trim());
			}
		    //Modified by Amid End
		    if((a_oRequest.getParameter("nOffVintageFrom")!= null) && !(a_oRequest.getParameter("nOffVintageFrom").trim().equals("")))
			{
				oOtherBenefitResult.setTgtOffVintageFrom(a_oRequest.getParameter("nOffVintageFrom").trim());
			}
		    if((a_oRequest.getParameter("nOffVintageTo")!= null) && !(a_oRequest.getParameter("nOffVintageTo").trim().equals("")))
			{
				oOtherBenefitResult.setTgtOffVintageTo(a_oRequest.getParameter("nOffVintageTo").trim());
			}
		    if((a_oRequest.getParameter("nMinreqmnt")!= null) && !(a_oRequest.getParameter("nMinreqmnt").trim().equals("")))
			{
				oOtherBenefitResult.setTgtMinReqment(a_oRequest.getParameter("nMinreqmnt").trim());
			}
		    if((a_oRequest.getParameter("rowcount")!= null) && !(a_oRequest.getParameter("rowcount").trim().equals("")))
			{
				oOtherBenefitResult.setRowCount(new Integer(a_oRequest.getParameter("rowcount").trim()));
			}
		    if((a_oRequest.getParameter("columcount")!= null) && !(a_oRequest.getParameter("columcount").trim().equals("")))
			{
				oOtherBenefitResult.setColumnCount(new Integer(a_oRequest.getParameter("columcount").trim()));
			}

		   	oOtherBenefitResult.setTargetCriParamDetails(getTargetCriParams(a_oRequest));
		    if((a_oRequest.getParameter("nOffMultiplierFrom")!= null) && !(a_oRequest.getParameter("nOffMultiplierFrom").trim().equals("")))
			{
				oOtherBenefitResult.setOffMultiplierFrom(a_oRequest.getParameter("nOffMultiplierFrom").trim());
		     }
		    if((a_oRequest.getParameter("nOffMultiplierTo")!= null) && !(a_oRequest.getParameter("nOffMultiplierTo").trim().equals("")))
			{
				oOtherBenefitResult.setOffMultiplierTo(a_oRequest.getParameter("nOffMultiplierTo").trim());

			}
		    if((a_oRequest.getParameter("nOffMultiplier")!= null) && !(a_oRequest.getParameter("nOffMultiplier").trim().equals("")))
			{
				oOtherBenefitResult.setOffMultiplier(a_oRequest.getParameter("nOffMultiplier").trim());

			}
		    oOtherBenefitResult.setOffMultiplierDetails(getOfficeMultiplier(a_oRequest));
		    if((a_oRequest.getParameter("nAgentorGOCd")!= null) && !(a_oRequest.getParameter("nAgentorGOCd").trim().equals("")))
			{
				oOtherBenefitResult.setAgentorGOCd(a_oRequest.getParameter("nAgentorGOCd").trim());

			}
		    if((a_oRequest.getParameter("strTgtDesgnCd")!= null) && !(a_oRequest.getParameter("strTgtDesgnCd").trim().equals("")))
			{
				oOtherBenefitResult.setTgtDesgnCd(a_oRequest.getParameter("strTgtDesgnCd").trim());

			}
		    if((a_oRequest.getParameter("TargetParamValue")!= null) && !(a_oRequest.getParameter("TargetParamValue").trim().equals("")))
			{
				oOtherBenefitResult.setTargetParamValue(a_oRequest.getParameter("TargetParamValue").trim());

			}
	// Santosh_Everest_Distribution Starts

		if ((a_oRequest.getParameter("nSegmnetType") != null)
				&& !(a_oRequest.getParameter("nSegmnetType").trim().equals(""))) {
			oOtherBenefitResult.setSegmnetType(new Short(a_oRequest
					.getParameter("nSegmnetType").trim()));
		} else {
			oOtherBenefitResult.setSegmnetType(null);
		}


		if ((a_oRequest.getParameter("nSegmnedOrNot") != null)
				&& !(a_oRequest.getParameter("nSegmnedOrNot").trim().equals(""))) {
			oOtherBenefitResult.setSegmnedOrNot(new Short(a_oRequest
					.getParameter("nSegmnedOrNot").trim()));
		} else {
			oOtherBenefitResult.setSegmnedOrNot(null);
		}

		// Santosh_Everest_Distribution Ends
		//Santosh_Ph_II Starts
		log.debug("nFreqOfProd :"+a_oRequest.getParameter("nFreqOfProd")+"--");
		if((a_oRequest.getParameter("nFreqOfProd") != null) && !(a_oRequest.getParameter("nFreqOfProd").trim().equals("")))
		{
		    oOtherBenefitResult.setFreqOfProd(new Short(a_oRequest.getParameter("nFreqOfProd").trim()));
		}
		//Santosh_Ph_II Ends
		//Amid : modified for clawback Start
		if((a_oRequest.getParameter("nClawbackPeriod") != null) && !(a_oRequest.getParameter("nClawbackPeriod").trim().equals("")))
		{
		    oOtherBenefitResult.setClawbackPeriod(new Short(a_oRequest.getParameter("nClawbackPeriod").trim()));
		}
		//Amid : modified for clawback
		//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Starts
		if((a_oRequest.getParameter("nIsGoAssociationAppl") != null) && !(a_oRequest.getParameter("nIsGoAssociationAppl").trim().equals("")))
		{
		    oOtherBenefitResult.setIsGoAssociationAppl(new Short(a_oRequest.getParameter("nIsGoAssociationAppl").trim()));
		}
//		Amid_Everest_Ph2_App_IP_Incentive_Scheme_Ends
		
		 //*****Himanshu: Inclusion in ACS:Q1 release: Code Start******
		
		if((a_oRequest.getParameter("nInclusioninACS") != null) && !(a_oRequest.getParameter("nInclusioninACS").trim().equals("")))
		{
			log.debug("OtherBenefitFetch.java before inclusionorExclusion..if ..cindition");
		    oOtherBenefitResult.setnIsInclusioninACS(new Short(a_oRequest.getParameter("nInclusioninACS").trim()));
		    log.debug("OtherBenefitFetch.java before inclusionorExclusion..if ..cindition");
		}
		if((a_oRequest.getParameter("nBonusDescriptioninACS") != null) && !(a_oRequest.getParameter("nBonusDescriptioninACS").trim().equals("")))
		{
		    oOtherBenefitResult.setnbonusdescinACS(a_oRequest.getParameter("nBonusDescriptioninACS").trim());
		}
		
		 //*****Himanshu: Inclusion in ACS:Q1 release: Code Ends here******
		
		
		
		    oOtherBenefitResult.setTargetParameterDetails(getTargetParameterDetails(a_oRequest));
//Arun_FSOtherBenefitsTargetTab_REL8.1 ends

		  //SUNAINA_FS_TRAINING_INCENTIVE_STARTS
		    log.debug("nPmtFreq :"+a_oRequest.getParameter("nPmtFreq")+"--");
		    if((a_oRequest.getParameter("nPmtFreq") != null) && !(a_oRequest.getParameter("nPmtFreq").trim().equals("")))
			{
			    oOtherBenefitResult.setHeldPayoutFreq(new Short(a_oRequest.getParameter("nPmtFreq").trim()));
			}
		  //SUNAINA_FS_TRAINING_INCENTIVE_ENDS
		    //Prabhat Modified for Flat Hold Payout start
		    if((a_oRequest.getParameter("nFlatHoldPayout") != null) && !(a_oRequest.getParameter("nFlatHoldPayout").trim().equals("")))
			{
			    oOtherBenefitResult.setFlatHoldPayout(new Double(a_oRequest.getParameter("nFlatHoldPayout").trim()));
			}
		    //Prabhat Modified for Flat Hold Payout End
		    
//		  Anantha_Banca_Inc start
		    if((a_oRequest.getParameter("nCBPPerc") != null) && !(a_oRequest.getParameter("nCBPPerc").trim().equals("")))
			{
			    oOtherBenefitResult.setCBPPerc(new Double(a_oRequest.getParameter("nCBPPerc").trim()));
			}
//		  Anantha_Banca_Inc End
		    //<Rel.  - Start : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
		    if((a_oRequest.getParameter("ceipExclusion") != null) && !(a_oRequest.getParameter("ceipExclusion").trim().equals("")))
			{
			    oOtherBenefitResult.setCeipExclusion(Short.valueOf(a_oRequest.getParameter("ceipExclusion").trim()));
			}
		  //<Rel.  - End : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
		    
		  //start CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011 
		    log.debug("nPrdPeriod :"+a_oRequest.getParameter("nPrdPeriod")+"--");
		    if((a_oRequest.getParameter("nPrdPeriod") != null) && !(a_oRequest.getParameter("nPrdPeriod").trim().equals(""))){
				
				oOtherBenefitResult.setPrdPeriod(Short.valueOf(a_oRequest.getParameter("nPrdPeriod")));
			}
		    
		   // End CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011
		    
		  //Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Starts
		    if((a_oRequest.getParameter("nPayIfColnNotPresent") != null) && !(a_oRequest.getParameter("nPayIfColnNotPresent").trim().equals(""))){
				
				oOtherBenefitResult.set_nPayIfColnNotPresent(Short.valueOf(a_oRequest.getParameter("nPayIfColnNotPresent")));
			}
		  //Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Ends		    

		    
			return oOtherBenefitResult;
		}
		//Arun_FSOtherBenefitsTargetTab_REL8.1 Starts
		public TargetCriteriaParamResult getTargetCriParams(HttpServletRequest a_oRequest)
		{
			ArrayList alTgtCriparamDetails =null;
			TargetCriteriaParamResult oTargetCriteriaParamResult =null;
		 if((a_oRequest.getParameter("criteriaParamId")!= null) && !(a_oRequest.getParameter("criteriaParamId").trim().equals("")))
		 {
			 alTgtCriparamDetails =new ArrayList();
			 oTargetCriteriaParamResult=new TargetCriteriaParamResult();
			 StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("criteriaParamId"),"||");
			 while(st.hasMoreTokens())
			 {
				 alTgtCriparamDetails.add(st.nextToken());
			 }
			 oTargetCriteriaParamResult.setCriteriaParamIds(alTgtCriparamDetails);
			 st = new StringTokenizer(a_oRequest.getParameter("criteriaParamName"),"||");
			 alTgtCriparamDetails =new ArrayList();
			 while(st.hasMoreTokens())
			 {
			   alTgtCriparamDetails.add(st.nextToken());
			 }
			 oTargetCriteriaParamResult.setCriteriaParamNames(alTgtCriparamDetails);
			 st = new StringTokenizer(a_oRequest.getParameter("nWeightage"),"||");
			 alTgtCriparamDetails =new ArrayList();
			 while(st.hasMoreTokens())
			 {
			   alTgtCriparamDetails.add(st.nextToken());
			 }
			 oTargetCriteriaParamResult.setBnsWeightage(alTgtCriparamDetails);
			 //	Modified by Amid Start
			 st = new StringTokenizer(a_oRequest.getParameter("nWeightage2"),"||");
			 alTgtCriparamDetails =new ArrayList();
			 while(st.hasMoreTokens())
			 {
			   alTgtCriparamDetails.add(st.nextToken());
			 }
			 oTargetCriteriaParamResult.setBnsWeightage2(alTgtCriparamDetails);
			 
			 st = new StringTokenizer(a_oRequest.getParameter("nWeightage3"),"||");
			 alTgtCriparamDetails =new ArrayList();
			 while(st.hasMoreTokens())
			 {
			   alTgtCriparamDetails.add(st.nextToken());
			 }			 
			 oTargetCriteriaParamResult.setBnsWeightage3(alTgtCriparamDetails);
			 //Modified by Amid End
			 st = new StringTokenizer(a_oRequest.getParameter("nOffVintageFrom"),"||");
			 alTgtCriparamDetails =new ArrayList();
			 while(st.hasMoreTokens())
			 {
			   alTgtCriparamDetails.add(st.nextToken());
			 }
			 oTargetCriteriaParamResult.setOfficeVintageFrom(alTgtCriparamDetails);
			 st = new StringTokenizer(a_oRequest.getParameter("nOffVintageTo"),"||");
			 alTgtCriparamDetails =new ArrayList();
			 while(st.hasMoreTokens())
			 {
			   alTgtCriparamDetails.add(st.nextToken());
			 }
			 oTargetCriteriaParamResult.setOfficeVinatageTo(alTgtCriparamDetails);
			 st = new StringTokenizer(a_oRequest.getParameter("nMinreqmnt"),"||");
			 alTgtCriparamDetails =new ArrayList();
			 while(st.hasMoreTokens())
			 {
			   alTgtCriparamDetails.add(st.nextToken());
			 }
			 oTargetCriteriaParamResult.setMinRequirement(alTgtCriparamDetails);
		  }
		   return oTargetCriteriaParamResult;
		}

		public TargetOfficeMultiplierResult getOfficeMultiplier(HttpServletRequest a_oRequest)
		{
			ArrayList alOfficeMultiplier =null;
			TargetOfficeMultiplierResult oTargetOfficeMultiplierResult =null;
		 if((a_oRequest.getParameter("nOffMultiplierFrom")!= null) && !(a_oRequest.getParameter("nOffMultiplierFrom").trim().equals("")))
		 {
			 alOfficeMultiplier =new ArrayList();
			 oTargetOfficeMultiplierResult=new TargetOfficeMultiplierResult();
			 StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nOffMultiplierFrom"),"||");
			 while(st.hasMoreTokens())
			 {
				 alOfficeMultiplier.add(st.nextToken());
			 }
			 oTargetOfficeMultiplierResult.setOfficeMultiplierFrom(alOfficeMultiplier);
			 st = new StringTokenizer(a_oRequest.getParameter("nOffMultiplierTo"),"||");
			 alOfficeMultiplier =new ArrayList();
			 while(st.hasMoreTokens())
			 {
				 alOfficeMultiplier.add(st.nextToken());
			 }
			 oTargetOfficeMultiplierResult.setOfficeMultiplierTo(alOfficeMultiplier);
			 st = new StringTokenizer(a_oRequest.getParameter("nOffMultiplier"),"||");
			 alOfficeMultiplier =new ArrayList();
			 while(st.hasMoreTokens())
			 {
				 alOfficeMultiplier.add(st.nextToken());
			 }
			 oTargetOfficeMultiplierResult.setOfficeMultiplier(alOfficeMultiplier);

		  }
		 return oTargetOfficeMultiplierResult;
		}
		public TargetParamDetailsResult getTargetParameterDetails(HttpServletRequest a_oRequest)
		{
			ArrayList alTargetParameter =null;
			TargetParamDetailsResult oTargetParamDetailsResult =null;
		 if((a_oRequest.getParameter("nAgentorGOCd")!= null) && !(a_oRequest.getParameter("nAgentorGOCd").trim().equals("")))
		 {
			 alTargetParameter =new ArrayList();
			 oTargetParamDetailsResult=new TargetParamDetailsResult();
			 StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nAgentorGOCd"),"||");
			 while(st.hasMoreTokens())
			 {
				 alTargetParameter.add(st.nextToken());
			 }
			 oTargetParamDetailsResult.setAgentGOCd(alTargetParameter);
			 st = new StringTokenizer(a_oRequest.getParameter("strTgtDesgnCd"),"||");
			 alTargetParameter =new ArrayList();
			 while(st.hasMoreTokens())
			 {
				 alTargetParameter.add(st.nextToken());
			 }
			 oTargetParamDetailsResult.setDesgnCd(alTargetParameter);
			 st = new StringTokenizer(a_oRequest.getParameter("TargetParamValue"),"||");
			 alTargetParameter =new ArrayList();
			 while(st.hasMoreTokens())
			 {
				 alTargetParameter.add(st.nextToken());
			 }
			 oTargetParamDetailsResult.setDtarget(alTargetParameter);

		  }
		 return oTargetParamDetailsResult;
		}
		//Arun_FSOtherBenefitsTargetTab_REL8.1 ends
		public ArrayList getCriteriaParameterDetails(HttpServletRequest a_oRequest)
		{
		    ArrayList alCriParamDetails = null;
		    CriteriaParameterResult oCriteriaParameterResult = null;
		    ArrayList dRateFrom = null;
		    ArrayList dRateTo = null;
		    if((a_oRequest.getParameter("strCriParamIds") != null) && !(a_oRequest.getParameter("strCriParamIds").trim().equals("")))
			{
		        alCriParamDetails = new ArrayList();
		        StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("strCriParamIds"),"||");
		        String strBaseParamId= null;
		        while(st.hasMoreTokens())
		        {
		            strBaseParamId = st.nextToken();
		            oCriteriaParameterResult = new CriteriaParameterResult();
		            oCriteriaParameterResult.setBaseParamId(strBaseParamId);
		            oCriteriaParameterResult.setDFrom(a_oRequest.getParameterValues("dValueFrom_" + strBaseParamId));
		            log.debug(a_oRequest.getParameterValues("dValueFrom_"+strBaseParamId) + "" );
		            oCriteriaParameterResult.setDTo(a_oRequest.getParameterValues("dValueTo_"+ strBaseParamId));
		            log.debug(a_oRequest.getParameterValues("dValueTo_"+strBaseParamId) + "" );
		            alCriParamDetails.add(oCriteriaParameterResult);
		        }
			}
		    return alCriParamDetails;
		}

		public String[] getApplDesgn(HttpServletRequest a_oRequest)
		{
		    String[] strApplDesgn = null;
		    ArrayList alApplDesgn = null;
		    if(a_oRequest.getParameter("strApplDesgnCd") != null && !(a_oRequest.getParameter("strApplDesgnCd").trim().equals("")))
		    {
				StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("strApplDesgnCd"),"||");
				alApplDesgn = new ArrayList();
				while(st.hasMoreTokens())
				{
				    alApplDesgn.add(st.nextToken());
				}
				if(alApplDesgn.size() > 0)
				{
				    strApplDesgn = new String[alApplDesgn.size()];
				    for(int i=0;i<alApplDesgn.size();i++)
				    {
				        strApplDesgn[i] = (String)alApplDesgn.get(i);
				    }
				}
		    }
		    return strApplDesgn;
		}

		public String[] getCriDesgn(HttpServletRequest a_oRequest)
		{
		    String[] strCriDesgn = null;
		    ArrayList alCriDesgn = null;
		    if(a_oRequest.getParameter("strCriDesgnCd") != null && !(a_oRequest.getParameter("strCriDesgnCd").trim().equals("")))
		    {
				StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("strCriDesgnCd"),"||");
				alCriDesgn = new ArrayList();
				while(st.hasMoreTokens())
				{
				    alCriDesgn.add(st.nextToken());
				}
				if(alCriDesgn.size() > 0)
				{
				    strCriDesgn = new String[alCriDesgn.size()];
				    for(int i=0;i<alCriDesgn.size();i++)
				    {
				        strCriDesgn[i] = (String)alCriDesgn.get(i);

				    }
				}
		    }
		    return strCriDesgn;
		}
//Jimmy_OtherBenefits_1.1_REL8.0 Starts

		public String[] getApplicableAgentAgencyCode(HttpServletRequest a_oRequest)
		{
		    String[] strAgtAgncyCd = null;
		    ArrayList alAgtAgncyCd = null;
		    if(a_oRequest.getParameter("strApplicableAgtAgncyCd") != null && !(a_oRequest.getParameter("strApplicableAgtAgncyCd").trim().equals("")))
		    {
				StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("strApplicableAgtAgncyCd"),"||");
				alAgtAgncyCd = new ArrayList();
				while(st.hasMoreTokens())
				{
					alAgtAgncyCd.add(st.nextToken());
				}
				if(alAgtAgncyCd.size() > 0)
				{
					strAgtAgncyCd = new String[alAgtAgncyCd.size()];
				    for(int i=0;i<alAgtAgncyCd.size();i++)
				    {
				    	strAgtAgncyCd[i] = (String)alAgtAgncyCd.get(i);
				    }
				}
		    }
		    return strAgtAgncyCd;
		}
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
//Jimmy_OtherBenefits_1.4_REL8.0 Starts
		public String[] getIsMnylAgent(HttpServletRequest a_oRequest)
		{
		    String[] strIsMnylAgt = null;
		    ArrayList alIsMnylAgt = null;
		    if(a_oRequest.getParameter("nIsMnylAgt") != null && !(a_oRequest.getParameter("nIsMnylAgt").trim().equals("")))
		    {
				StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nIsMnylAgt"),"||");
				alIsMnylAgt = new ArrayList();
				while(st.hasMoreTokens())
				{
					alIsMnylAgt.add(st.nextToken());
				}
				if(alIsMnylAgt.size() > 0)
				{
					strIsMnylAgt = new String[alIsMnylAgt.size()];
				    for(int i=0;i<alIsMnylAgt.size();i++)
				    {
				    	strIsMnylAgt[i] = (String)alIsMnylAgt.get(i);

				    }
				}
		    }
		    return strIsMnylAgt;
		}
//Jimmy_OtherBenefits_1.4_REL8.0 Ends
		// Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start
		   public String[] getDesgCd(HttpServletRequest a_oRequest)
			{
			    String[] strDesgCd = null;
			    ArrayList alDesgCd = null;
			    if(a_oRequest.getParameter("strDesgCd") != null && !(a_oRequest.getParameter("strDesgCd").trim().equals("")))
			    {
					StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("strDesgCd"),"||");
					alDesgCd = new ArrayList();
					while(st.hasMoreTokens())
					{
						alDesgCd.add(st.nextToken());
					}
					if(alDesgCd.size() > 0)
					{
						strDesgCd = new String[alDesgCd.size()];
					    for(int i=0;i<alDesgCd.size();i++)
					    {
					    	strDesgCd[i] = (String)alDesgCd.get(i);

					    }
					}
			    }
			    return strDesgCd;
			}
		   public String[] getBaseParamId(HttpServletRequest a_oRequest)
			{
			    String[] strBaseParamId = null;
			    ArrayList alBaseParamId = null;
			    if(a_oRequest.getParameter("strBaseParamId") != null && !(a_oRequest.getParameter("strBaseParamId").trim().equals("")))
			    {
					StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("strBaseParamId"),"||");
					alBaseParamId = new ArrayList();
					while(st.hasMoreTokens())
					{
						alBaseParamId.add(st.nextToken());
					}
					if(alBaseParamId.size() > 0)
					{
						strBaseParamId = new String[alBaseParamId.size()];
					    for(int i=0;i<alBaseParamId.size();i++)
					    {
					    	strBaseParamId[i] = (String)alBaseParamId.get(i);

					    }
					}
			    }
			    return strBaseParamId;
			}
		   public String[] getIsInclOrExcl(HttpServletRequest a_oRequest)
			{
			    String[] strIsInclOrExcl = null;
			    ArrayList alIsInclOrExcl = null;
			    if(a_oRequest.getParameter("nIsInclOrExcl") != null && !(a_oRequest.getParameter("nIsInclOrExcl").trim().equals("")))
			    {
					StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nIsInclOrExcl"),"||");
					alIsInclOrExcl = new ArrayList();
					while(st.hasMoreTokens())
					{
						alIsInclOrExcl.add(st.nextToken());
					}
					if(alIsInclOrExcl.size() > 0)
					{
						strIsInclOrExcl = new String[alIsInclOrExcl.size()];
					    for(int i=0;i<alIsInclOrExcl.size();i++)
					    {
					    	strIsInclOrExcl[i] = (String)alIsInclOrExcl.get(i);

					    }
					}
			    }
			    return strIsInclOrExcl;
			}

		   //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
		   //Amid_MP/P_Incentive Scheme Starts
		   public String[] getScoreTypeValue(HttpServletRequest a_oRequest)
			{
			    String[] strScoreType = null;
			    ArrayList alScoreType = null;
			    if(a_oRequest.getParameter("nScoreType") != null && !(a_oRequest.getParameter("nScoreType").trim().equals("")))
			    {
					StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nScoreType"),"||");
					alScoreType = new ArrayList();
					while(st.hasMoreTokens())
					{
						alScoreType.add(st.nextToken());
					}
					if(alScoreType.size() > 0)
					{
						strScoreType = new String[alScoreType.size()];
					    for(int i=0;i<alScoreType.size();i++)
					    {
					    	strScoreType[i] = (String)alScoreType.get(i);

					    }
					}
			    }
			    return strScoreType;
			}
		   public String[] getGlpWeightageValue(HttpServletRequest a_oRequest)
			{
			    String[] strGlpWeightagee = null;
			    ArrayList alGlpWeightage = null;
			    if(a_oRequest.getParameter("nGlpWeightage") != null && !(a_oRequest.getParameter("nGlpWeightage").trim().equals("")))
			    {
					StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nGlpWeightage"),"||");
					alGlpWeightage = new ArrayList();
					while(st.hasMoreTokens())
					{
						alGlpWeightage.add(st.nextToken());
					}
					if(alGlpWeightage.size() > 0)
					{
						strGlpWeightagee = new String[alGlpWeightage.size()];
					    for(int i=0;i<alGlpWeightage.size();i++)
					    {
					    	strGlpWeightagee[i] = (String)alGlpWeightage.get(i);

					    }
					}
			    }
			    return strGlpWeightagee;
			}
		   public String[] getFromValue(HttpServletRequest a_oRequest)
			{
			    String[] strFrom = null;
			    ArrayList alFrom = null;
			    if(a_oRequest.getParameter("dFrom") != null && !(a_oRequest.getParameter("dFrom").trim().equals("")))
			    {
					StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("dFrom"),"||");
					alFrom = new ArrayList();
					while(st.hasMoreTokens())
					{
						alFrom.add(st.nextToken());
					}
					if(alFrom.size() > 0)
					{
						strFrom = new String[alFrom.size()];
					    for(int i=0;i<alFrom.size();i++)
					    {
					    	strFrom[i] = (String)alFrom.get(i);
					    	log.debug("OtherBenefitFetch>>getFrom>>"+strFrom[i]);
					    }
					}
			    }
			    return strFrom;
			}
		   public String[] getToValue(HttpServletRequest a_oRequest)
			{
			    String[] strTo = null;
			    ArrayList alTo = null;
			    if(a_oRequest.getParameter("dTo") != null && !(a_oRequest.getParameter("dTo").trim().equals("")))
			    {
					StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("dTo"),"||");
					alTo = new ArrayList();
					while(st.hasMoreTokens())
					{
						alTo.add(st.nextToken());
					}
					if(alTo.size() > 0)
					{
						strTo = new String[alTo.size()];
					    for(int i=0;i<alTo.size();i++)
					    {
					    	strTo[i] = (String)alTo.get(i);
					    	log.debug("OtherBenefitFetch>>getTo>>"+strTo[i]);
					    }
					}
			    }
			    return strTo;
			}
		   public String[] getGlpValue(HttpServletRequest a_oRequest)
			{
			    String[] strValue = null;
			    ArrayList alValue = null;
			    if(a_oRequest.getParameter("nValue") != null && !(a_oRequest.getParameter("nValue").trim().equals("")))
			    {
					StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nValue"),"||");
					alValue = new ArrayList();
					while(st.hasMoreTokens())
					{
						alValue.add(st.nextToken());
					}
					if(alValue.size() > 0)
					{
						strValue = new String[alValue.size()];
					    for(int i=0;i<alValue.size();i++)
					    {
					    	strValue[i] = (String)alValue.get(i);

					    }
					}
			    }
			    return strValue;
			}
		   //Amid_MP/P_Incentive Scheme Ends
	}
