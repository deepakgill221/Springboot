
/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: MY AGENT
 *  FILENAME		: PerReductionResult.java
 *  AUTHOR			: Anup Kumar
 *  VERSION			: 1.0
 *  CREATION DATE	: January 30, 2009
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2004.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *ANUP_DST_Incentive_April_REL_Starts
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * <p> Title: eElixir </p>
 * <p> Description:Result object for Other Benefit Agent Result </p>
 * <p> Copyright: Copyright (c) 2002 * </p>
 * <p> Company: Mastek Ltd * </p>
 * @author Sandeep
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.benefit.util;

import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class PerReductionResult extends UserData implements Serializable
{
    public PerReductionResult()
    {
    }
    private String _strPersistencyType = null;    
    private Double _dFromPerc = null;
    private Double _dToPerc = null;
    private Double _dTargetValuePerc = null;
    private Double _dPercentagePerc = null;
    private Long _lPercSeqNbr = null;
    private String _strStatusFlag = null;
    
    public String getStatusFlag()
    {
        return this._strStatusFlag;
    }
    public void setStatusFlag(String strStatusFlag)
    {
        this._strStatusFlag = strStatusFlag;
    }
    
    
	public Double getFromPerc() {
		return _dFromPerc;
	}

	public void setFromPerc(Double fromPerc) {
		_dFromPerc = fromPerc;
	}

	public Double getPercentagePerc() {
		return _dPercentagePerc;
	}

	public void setPercentagePerc(Double percentagePerc) {
		_dPercentagePerc = percentagePerc;
	}

	public Double getTargetValuePerc() {
		return _dTargetValuePerc;
	}

	public void setTargetValuePerc(Double targetValuePerc) {
		_dTargetValuePerc = targetValuePerc;
	}

	public Double getToPerc() {
		return _dToPerc;
	}

	public void setToPerc(Double toPerc) {
		_dToPerc = toPerc;
	}

	public Long getPercSeqNbr() {
		return _lPercSeqNbr;
	}

	public void setPercSeqNbr(Long PercSeqNbr) {
		_lPercSeqNbr = PercSeqNbr;
	}

	public String getPersistencyType() {
		return _strPersistencyType;
	}

	public void setPersistencyType(String persistencyType) {
		_strPersistencyType = persistencyType;
	}
}
