/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: MY AGENT
*  FILENAME			: CriteriaParameterResult.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: September 17, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2004.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
* <p> Title: eElixir </p>
* <p> Description:Result object for Criteria Parameters</p>
* <p> Copyright: Copyright (c) 2002 * </p>
* <p> Company: Mastek Ltd * </p>
* @author Sandeep
* @version 1.0
*/

package com.mastek.eElixir.channelmanagement.benefit.util;

import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class CriteriaParameterResult extends UserData implements Serializable 
{
    public CriteriaParameterResult()
    {
        
    }
    
    private Long lBonusHdrSeqNbr = null;
    private Long lParamSeqNbr = null;
    private String strBaseParamId = null;
    private String[] alDFrom = null;
    private String[] alDTo = null;
    
    /**
     * @return Returns the alDFrom.
     */
    public String[] getDFrom() {
        
        return alDFrom;
    }
    /**
     * @param alDFrom The alDFrom to set.
     */
    public void setDFrom(String[] alDFrom) {
        this.alDFrom = alDFrom;
    }
    /**
     * @return Returns the alDTo.
     */
    public String[] getDTo() {
        return alDTo;
    }
    /**
     * @param alDTo The alDTo to set.
     */
    public void setDTo(String[] alDTo) {
        this.alDTo = alDTo;
    }
    /**
     * @return Returns the lBonusHdrSeqNbr.
     */
    public Long getBonusHdrSeqNbr() {
        return lBonusHdrSeqNbr;
    }
    /**
     * @param bonusHdrSeqNbr The lBonusHdrSeqNbr to set.
     */
    public void setBonusHdrSeqNbr(Long bonusHdrSeqNbr) {
        lBonusHdrSeqNbr = bonusHdrSeqNbr;
    }
    /**
     * @return Returns the lParamSeqNbr.
     */
    public Long getParamSeqNbr() {
        return lParamSeqNbr;
    }
    /**
     * @param paramSeqNbr The lParamSeqNbr to set.
     */
    public void setParamSeqNbr(Long paramSeqNbr) {
        lParamSeqNbr = paramSeqNbr;
    }
    /**
     * @return Returns the strBaseParamId.
     */
    public String getBaseParamId() {
        return strBaseParamId;
    }
    /**
     * @param strBaseParamId The strBaseParamId to set.
     */
    public void setBaseParamId(String strBaseParamId) {
        this.strBaseParamId = strBaseParamId;
    }
}
