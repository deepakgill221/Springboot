/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : CHANNEL MANAGEMENT
*  FILENAME			: TPRResult.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE    : Jun 18, 2010
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*									
*
* Anup_AugRel2010_FSD_TPR_V1.3
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for TPR Master</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Anup
 * @version 1.0
 */



package com.mastek.eElixir.channelmanagement.benefit.util;
import java.io.Serializable;
import java.util.HashMap;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

/**
 * @author 204828
 *
 */
public class TPRResult extends UserData implements Serializable
{


   private Long _lTPRHdrSeqNbr = null;
   private  String _cChannelType = null;
   private String _strTPRType = null;
   private  String _strTPRDescription = null;   
   private Short _nFreqProd = null;
   private Short _nFreqCal = null;
   private Long _nVintageFrom = null;
   private Long _nVintageTo = null;      
   private  String _strStatusFlag = null;
   private ArrayList al_TPRDetails = null; 
   // Alex_TPR_SIT_FIX 3 Aug 2010 Start	
   private  String _strTPRScreen = null;   
   // Alex_TPR_SIT_FIX 3 Aug 2010 End	


	/**
	 * @return the _lTPRHdrSeqNbr
	 */
	public Long getTPRHdrSeqNbr() {
		return _lTPRHdrSeqNbr;
	}
	
	/**
	 * @param hdrSeqNbr the _lTPRHdrSeqNbr to set
	 */
	public void setTPRHdrSeqNbr(Long hdrSeqNbr) {
		_lTPRHdrSeqNbr = hdrSeqNbr;
	}
	
	/**
	 * @return the _cChannelType
	 */
	public String getChannelType() {
		return _cChannelType;
	}
	
	/**
	 * @param channelType the _cChannelType to set
	 */
	public void setChannelType(String channelType) {
		_cChannelType = channelType;
	}
	
	/**
	 * @return the _strTPRType
	 */
	public String getTPRType() {
		return _strTPRType;
	}
	
	/**
	 * @param type the _strTPRType to set
	 */
	public void setTPRType(String type) {
		_strTPRType = type;
	}
	
	/**
	 * @return the _strTPRDescription
	 */
	public String getTPRDescription() {
		return _strTPRDescription;
	}
	
	/**
	 * @param description the _strTPRDescription to set
	 */
	public void setTPRDescription(String description) {
		_strTPRDescription = description;
	}
	
	
	
	public ArrayList getTPRDetails() {
		return al_TPRDetails;
	}
	
	public void setTPRDetails(ArrayList _mpsDetails) {
		this.al_TPRDetails = _mpsDetails;
	}




	/**
	 * Default Constructor
	 */
	public TPRResult(){
	
	}
	
	public Short getFreqProd() {
		return _nFreqProd;
	}
	
	public void setFreqProd(Short freqProd) {
		_nFreqProd = freqProd;
	}
	
	public Short getFreqCal() {
		return _nFreqCal;
	}
	
	public void setFreqCal(Short freqCal) {
		_nFreqCal = freqCal;
	}
	
	public Long getVintageFrom() {
		return _nVintageFrom;
	}
	
	public void setVintageFrom(Long vintageFrom) {
		_nVintageFrom = vintageFrom;
	}
	
	public Long getVintageTo() {
		return _nVintageTo;
	}
	
	public void setVintageTo(Long vintageTo) {
		_nVintageTo = vintageTo;
	}
	
	public String getStatusFlag() {
		return _strStatusFlag;
	}
	
	public void setStatusFlag(String statusFlag) {
		_strStatusFlag = statusFlag;
	}

	//Alex_TPR_SIT_FIX 3 Aug 2010 Start	
	public String get_strTPRScreen() {
		return _strTPRScreen;
	}

	public void set_strTPRScreen(String screen) {
		_strTPRScreen = screen;
	}
	//Alex_TPR_SIT_FIX 3 Aug 2010 End	

}
