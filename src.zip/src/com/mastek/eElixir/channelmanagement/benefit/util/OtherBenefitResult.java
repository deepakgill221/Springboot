/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: MY AGENT
 *  FILENAME		: OtherBenefitResult.java
 *  AUTHOR			: Sandeep Bangera
 *  VERSION			: 1.0
 *  CREATION DATE	: September 17, 2004
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2004.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *1.1	  Dec 05 2004	Shameem Shaik	As per new Change Request for adding Target Pro-Rata
 *1.2	  Jan-19-2007	Jimmy K G		Added new data members for Release 8.0.
 *										Hold Percentage,Year,Cap Percentage,Paid To,Reportees,
 *										Consider Agent Terminated Status,Bonus Level.
 *		  24-03-2011	Shrikrishna     CR:FSD-Agent_Compensation_2011_v1.0.doc
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * <p> Title: eElixir </p>
 * <p> Description:Result object for Other Benefit Result </p>
 * <p> Copyright: Copyright (c) 2002 * </p>
 * <p> Company: Mastek Ltd * </p>
 * @author Sandeep
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.benefit.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class OtherBenefitResult extends UserData implements Serializable {
    public OtherBenefitResult() {
    }

    public String getChannelType() {
        return _cChannelType;
    }
    public void setChannelType(String channelType) {
        _cChannelType = channelType;
    }

    public GregorianCalendar getEffFrom() {
        return _dtEffFrom;
    }
    public void setEffFrom(GregorianCalendar effFrom) {
        _dtEffFrom = effFrom;
    }

    public GregorianCalendar getEffTo() {
        return _dtEffTo;
    }
    public void setEffTo(GregorianCalendar effTo) {
        _dtEffTo = effTo;
    }

    public Short getFreqOfCalc() {
        return _nFreqOfCalc;
    }
    public void setFreqOfCalc(Short freqOfCalc) {
        _nFreqOfCalc = freqOfCalc;
    }

    public Short getFreqOfPmt() {
        return _nFreqOfPmt;
    }
    public void setFreqOfPmt(Short freqOfPmt) {
        _nFreqOfPmt = freqOfPmt;
    }

    public Short getIsInclOrExclPmt() {
        return _nIsInclOrExclPmt;
    }
    public void setIsInclOrExclPmt(Short isInclOrExclPmt) {
        _nIsInclOrExclPmt = isInclOrExclPmt;
    }

    public Short getIsInclOrExclTgt() {
        return _nIsInclOrExclTgt;
    }
    public void setIsInclOrExclTgt(Short isInclOrExclTgt) {
        _nIsInclOrExclTgt = isInclOrExclTgt;
    }

    public Short getIsSTAppl() {
        return _nIsSTAppl;
    }
    public void setIsSTAppl(Short isSTAppl) {
        _nIsSTAppl = isSTAppl;
    }

    public Short getIsTDSAppl() {
        return _nIsTDSAppl;
    }
    public void setIsTDSAppl(Short isTDSAppl) {
        _nIsTDSAppl = isTDSAppl;
    }

    public Short getNoOfInstallment() {
        return _nNoOfInstallment;
    }
    public void setNoOfInstallment(Short noOfInstallment) {
        _nNoOfInstallment = noOfInstallment;
    }

    public Short getStartMonthCalc() {
        return _nStartMonthCalc;
    }
    public void setStartMonthCalc(Short startMonthCalc) {
        _nStartMonthCalc = startMonthCalc;
    }

    public Short getPmtDay() {
        return _nPmtDay;
    }
    public void setPmtDay(Short nPmtDay) {
        _nPmtDay = nPmtDay;
    }

    public String getAcctCd() {
        return _strAcctCd;
    }
    public void setAcctCd(String acctCd) {
        _strAcctCd = acctCd;
    }


    public String getBonusDesc() {
        return _strBonusDesc;
    }
    public void setBonusDesc(String bonusDesc) {
        _strBonusDesc = bonusDesc;
    }

    public String getBonusType() {
        return _strBonusType;
    }
    public void setBonusType(String bonusType) {
        _strBonusType = bonusType;
    }

    public String getDesgnCd() {
        return _strDesgnCd;
    }
    public void setDesgnCd(String desgnCd) {
        _strDesgnCd = desgnCd;
    }

    public String getOSAcctCd() {
        return _strOSAcctCd;
    }
    public void setOSAcctCd(String acctCd) {
        _strOSAcctCd = acctCd;
    }

    public String getProvAcctCd() {
        return _strProvAcctCd;
    }
    public void setProvAcctCd(String provAcctCd) {
        _strProvAcctCd = provAcctCd;
    }

    public Long getBonusHdrSeqNbr()
    {
        return _lBonusHdrSeqNbr;
    }
    public void setBonusHdrSeqNbr(Long a_lBonusHdrSeqNbr)
    {
        this._lBonusHdrSeqNbr = a_lBonusHdrSeqNbr;
    }

    public Short getIsTargetBased() {
        return _nIsTargetBased;
    }
    public void setIsTargetBased(Short nIsTargetBased) {
        _nIsTargetBased = nIsTargetBased;
    }

    // shameem
	public Short getTargetProRata() {
		 return _nTargetProRata;
	 }
	 public void setTargetProRata(Short nTargetProRata) {
		_nTargetProRata = nTargetProRata;
	 }

    public String getCriParamIds()
    {
        return _strCriParamIds;
    }
    public void setCriParamIds(String strCriParamIds)
    {
        this._strCriParamIds = strCriParamIds;
    }

    public String getCriParamNames()
    {
        return _strCriParamNames;
    }
    public void setCriParamNames(String strCriParamNames)
    {
        this._strCriParamNames = strCriParamNames;
    }

    public ArrayList getCriParamDetails()
    {
        return _alCriParamDetails;
    }
    public void setCriParamDetails(ArrayList _alCriParamDetails)
    {
        this._alCriParamDetails = _alCriParamDetails;
    }

    public String getBonusParamId()
    {
        return this._strBonusParamId;
    }
    public void setBonusParamId(String strBonusParamId)
    {
        this._strBonusParamId = strBonusParamId;
    }

    public Short getAmtPerc()
    {
        return this._nAmtPerc;
    }
    public void setAmtPerc(Short nAmtPerc)
    {
        this._nAmtPerc = nAmtPerc;
    }

    public Double getUnits()
    {
        return this._dUnits;
    }
    public void setUnits(Double dUnits)
    {
        this._dUnits = dUnits;
    }

    public String[] getBonusRate()
    {
        return this._strBonusRate;
    }
    public void setBonusRate(String[] strBonusRate)
    {
        this._strBonusRate = strBonusRate;
    }

    public String[] getApplDesgn()
    {
        return this._strApplDesgn;
    }
    public void setApplDesgn(String[] strApplDesgn)
    {
        this._strApplDesgn = strApplDesgn;
    }
    //*****Himanshu: Inclusion in ACS:Q1 release: Code Start******
    
    public Short getnIsInclusioninACS() {
		return this._nIsInclusioninACS;
	}

	public void setnIsInclusioninACS(Short nIsInclusioninACS) {
		this._nIsInclusioninACS = nIsInclusioninACS;
	}

	public String getnbonusdescinACS() {
		return this._nbonusdescinACS;
	}

	public void setnbonusdescinACS(String nbonusdescinACS) {
		this._nbonusdescinACS = nbonusdescinACS;
	}
	
	 //*****Himanshu: Inclusion in ACS:Q1 release: Code Ends here******

    public String[] getCriDesgn()
    {
        return this._strCriDesgn;
    }
    public void setCriDesgn(String[] strCriDesgn)
    {
        this._strCriDesgn = strCriDesgn;
    }

    public String[] getParamSeqNbr()
    {
        return this._lParamSeqNbr;
    }
    public void setParamSeqNbr(String[] strParamSeqNbr)
    {
        this._lParamSeqNbr = strParamSeqNbr;
    }

    public String[] getParamStatusFlag()
    {
        return this._strParamStatusFlag;
    }
    public void setParamStatusFlag(String[] _strParamStatusFlag)
    {
        this._strParamStatusFlag = _strParamStatusFlag;
    }

    public Double getTargetValue()
    {
        return this._dTargetValue;
    }
    public void setTargetValue(Double dTargetValue)
    {
        this._dTargetValue = dTargetValue;
    }

    public void setFreqOfInstallment(Short nFreqofInstallment)
    {
        this._nFreqOfInst = nFreqofInstallment;
    }
    public Short getFreqOfInstallment()
    {
        return this._nFreqOfInst;
    }

    // shameem ------------------------------------
	/**
		 * Gets Is Campaign
		 * @return Short
		*/
		public Short getIsCampaign()
		{
			return _nIsCampaign;
		}

		/**
		 * Sets Is Compaign
		 * @param a_nIsCampaign boolean
		*/
		public void setIsCampaign(Short a_nIsCampaign)
		{
			this._nIsCampaign = a_nIsCampaign;
		}
    // -----------------------------------------------------------------

    // Jayasimha------------------------------------
	/**
		 * Gets End Immediate
		 * @return Short
		*/
		public Short getEndImmediate()
		{
			return _nEndImmediate;
		}

		/**
		 * Sets End Immediate
		 * @param a_nEndImmediate boolean
		*/
		public void setEndImmediate(Short a_nEndImmediate)
		{
			this._nEndImmediate = a_nEndImmediate;
		}
    // -----------------------------------------------------------------

//Jimmy_OtherBenefits_1.1_REL8.0 Starts

		public Short getYearBasis()
		{
			return _nYearBasis;
		}
		public void setYearBasis(Short a_nYearBasis)
		{
			this._nYearBasis = a_nYearBasis;
		}
		public Short getReportees()
		{
			return _nReportees;
		}
		public void setReportees(Short a_nReportees)
		{
			this._nReportees = a_nReportees;
		}
		public Short getAgentTerminatedStatus()
		{
			return _nAgtTerminatedStat;
		}
		public void setAgentTerminatedStatus(Short a_nAgtTerminatedStat)
		{
			this._nAgtTerminatedStat = a_nAgtTerminatedStat;
		}
		//Amid_added_nBonusToTermAgent_field_Starts		
		public Short getBonusToTermAgent()
		{
			return _nBonusToTermAgent;
		}
		public void setBonusToTermAgent(Short a_nBonusToTermAgent)
		{
			this._nBonusToTermAgent = a_nBonusToTermAgent;
		}
		//Amid_added_nBonusToTermAgent_field_Ends
		public Short getBonusLevel()
		{
			return _nBonusLevel;
		}
		public void setBonusLevel(Short a_nBonusLevel)
		{
			this._nBonusLevel = a_nBonusLevel;
		}
		public Double getCapPercentage()
		{
			return _dCapPercentage;
		}
		public void setCapPercentage(Double a_dCapPercentage)
		{
			this._dCapPercentage = a_dCapPercentage;
		}
		public Double getHoldPercentage()
		{
			return _dHoldPercentage;
		}
		public void setHoldPercentage(Double a_dHoldPercentage)
		{
			this._dHoldPercentage = a_dHoldPercentage;
		}
		public String getPaidToAgentAgency()
		{
			return _strPaidToAgtAgncy;
		}
		public void setPaidToAgentAgency(String a_strPaidToAgtAgncy)
		{
			this._strPaidToAgtAgncy = a_strPaidToAgtAgncy;
		}
		public String[] getApplicableAgentAgencyCode()
		{
		    return _strApplicableAgtAgncyCd;
		}
		public void setApplicableAgentAgencyCode(String[] a_strApplicableAgtAgncyCd)
		{
		    this._strApplicableAgtAgncyCd = a_strApplicableAgtAgncyCd;
		}
		public String[] getApplicableAgentAgencyName()
		{
		    return _strApplicableAgtAgncyName;
		}
		public void setApplicableAgentAgencyName(String[] a_strApplicableAgtAgncyName)
		{
		    this._strApplicableAgtAgncyName = a_strApplicableAgtAgncyName;
		}
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
//Jimmy_OtherBenefits_1.3.2.1_REL8.0 Starts
		public Short getRecalculationType()
		{
			return _nRecalculationType;
		}
		public void setRecalculationType(Short a_nRecalculationType)
		{
			this._nRecalculationType = a_nRecalculationType;
		}
//Jimmy_OtherBenefits_1.3.2.1_REL8.0 Ends
//Jimmy_OtherBenefits_1.4_REL8.0 Starts
		public String[] getIsMnylAgent()
		{
			return _nIsMnylAgt;
		}
		public void setIsMnylAgent(String[] a_nIsMnylAgt)
		{
			this._nIsMnylAgt = a_nIsMnylAgt;
		}
//Jimmy_OtherBenefits_1.4_REL8.0 Ends
//Jimmy_OtherBenefits_1.10_REL8.0 Starts
		public String getMinRequirement()
		{
			return _strMinRequirement;
		}
		public void setMinRequirement(String a_strMinRequirement)
		{
			this._strMinRequirement = a_strMinRequirement;
		}
		public Short getBonusPayOutMethod()
		{
			return _nBnusPayOutMthd;
		}
		public void setBonusPayOutMethod(Short a_nBnusPayOutMthd)
		{
			this._nBnusPayOutMthd = a_nBnusPayOutMthd;
		}
//Jimmy_OtherBenefits_1.10_REL8.0 Ends
 // Arun_FSOtherBenefitsTargetTab_REL8.1 Start
	   	public void setTgtPlanAttachmentTo(Short a_nTgtPlanAttachmentTo)
		{
			this._nTgtPlanAttachmentTo= a_nTgtPlanAttachmentTo;
		}
		public Short getTgtPlanAttachmentTo()
		{
			return _nTgtPlanAttachmentTo;
		}
		public void setTgtRecalculationType(Short a_TgtRecalculationType)
		{
			this._nTgtRecalculationType= a_TgtRecalculationType;
		}
		public Short getTgtRecalculationType()
		{
			return _nTgtRecalculationType;
		}
		public void setTgtCriParamIds(String a_strTgtCriParamIds)
		{
			this._strTgtCriParamIds=a_strTgtCriParamIds;
		}
		public String getTgtCriParamIds()
		{
			return _strTgtCriParamIds;
		}
		public void setTgtCriPramNames(String a_strTgtCriPramNames)
		{
			this._strTgtCriPramNames=a_strTgtCriPramNames;
		}
		public String getTgtCriPramNames()
		{
			return _strTgtCriPramNames;
		}
		public void setTgtOffWeightage(String a_strTgtOffWeightage)
		{
			this._strTgtOffWeightage=a_strTgtOffWeightage;
		}
		public String getTgtOffWeightage()
		{
			return _strTgtOffWeightage;
		}
//		Modified by Amid Start
		public void setTgtOffWeightage2(String a_strTgtOffWeightage2)
		{
			this._strTgtOffWeightage2=a_strTgtOffWeightage2;
		}
		public void setTgtOffWeightage3(String a_strTgtOffWeightage3)
		{
			this._strTgtOffWeightage3=a_strTgtOffWeightage3;
		}
		public String getTgtOffWeightage2()
		{
			return _strTgtOffWeightage2;
		}
		public String getTgtOffWeightage3()
		{
			return _strTgtOffWeightage3;
		}
//		Modified by Amid End
		public void setTgtOffVintageFrom(String a_strTgtOffVintageFrom)
		{
			this._strTgtOffVintageFrom=a_strTgtOffVintageFrom;
		}
		public String getTgtOffVintageFrom()
		{
			return _strTgtOffVintageFrom;
		}
		public void setTgtOffVintageTo(String a_strTgtOffVintageTo)
		{
			this._strTgtOffVintageTo=a_strTgtOffVintageTo;
		}
		public String getTgtOffVintageTo()
		{
			return _strTgtOffVintageTo;
		}
		public void setTgtMinReqment(String a_strTgtMinReqment)
		{
			this._strTgtMinReqment=a_strTgtMinReqment;
		}
		public String getTgtMinReqment()
		{
			return _strTgtMinReqment;
		}
		public TargetCriteriaParamResult getTargetCriParamDetails()
	    {
	    	return oTargetCriteriaParamResult;
	    }
	    public void setTargetCriParamDetails(TargetCriteriaParamResult oTargetCriteriaParamResult)
	    {
	     this.oTargetCriteriaParamResult=oTargetCriteriaParamResult;
	    }
	    public void setOffMultiplierFrom(String _strOffMultiplierFrom)
		{
			this._strOffMultiplierFrom=_strOffMultiplierFrom;
		}
		public void setOffMultiplierTo(String _strOffMultiplierTo)
		{
			this._strOffMultiplierTo=_strOffMultiplierTo;
		}
		public void setOffMultiplier(String _strOffMultiplier)
		{
			this._strOffMultiplier=_strOffMultiplier;
		}
		public String getOffMultiplierFrom()
		{
			return _strOffMultiplierFrom;
		}
		public String getOffMultiplierTo()
		{
			return _strOffMultiplierTo;
		}
		public String getOffMultiplier()
		{
		   return _strOffMultiplier;
		}
		public TargetOfficeMultiplierResult getOffMultiplierDetails()
	    {
	    	return oTargetOfficeMultiplierResult;
	    }
	    public void setOffMultiplierDetails(TargetOfficeMultiplierResult oTargetOfficeMultiplierResult)
	    {
	     this.oTargetOfficeMultiplierResult=oTargetOfficeMultiplierResult;
	    }
	   	public void setRowCount(Integer _nRowCount)
	   	{
	   		this._nRowCount=_nRowCount;
	   	}
	   	public Integer getRowCount()
	   	{
	   		return _nRowCount;
	   	}
	   	public void setColumnCount(Integer _nColumnCount)
		{
			this._nColumnCount=_nColumnCount;
		}
	   	public Integer getColumnCount()
	   	{
	   		return _nColumnCount;
	   	}
	   	public void setTgtDesgnCd(String _strTgtDesgnCd)
		{
		  this._strTgtDesgnCd=_strTgtDesgnCd;
		}
		public String getTgtDesgnCd()
		{
			return _strTgtDesgnCd;
		}
		
		 //*****Himanshu: Inclusion in ACS:Q1 release: Code Start****** 
		  public String getaccountcodeforAcs() {
				return _accountcodeforAcs;
			}

			public void setaccountcodeforAcs(String accountcodeforAcs) {
				this._accountcodeforAcs = accountcodeforAcs;
			}
			
		 //*****Himanshu: Inclusion in ACS:Q1 release: Code Ends here******
		
		
		public void setAgentorGOCd(String _nAgentorGOCd)
		{
			this._nAgentorGOCd=_nAgentorGOCd;
		}
		public String getAgentorGOCd()
		{
			return _nAgentorGOCd;
		}
		public void setTargetParamValue(String _strTargetParamValue)
		{
		 this._strTargetParamValue=_strTargetParamValue;
		}
		public String getTargetParamValue()
		{
			return _strTargetParamValue;
		}
		
				
		
		public TargetParamDetailsResult getTargetParameterDetails()
		{
			return oTargetParamDetailsResult;
		}
		public void setTargetParameterDetails(TargetParamDetailsResult oTargetParamDetailsResult)
		{
			this.oTargetParamDetailsResult=oTargetParamDetailsResult;
		}
		public void setYearTgt(String _strYearTgt)
		{
		 this._strYearTgt=_strYearTgt;
		}
		public String getYearTgt()
		{
			return _strYearTgt;
		}
		public void setTgtCriParamUpdateCount(Short _nCriParamUpdateCount)
		{
			this._nCriParamUpdateCount=_nCriParamUpdateCount;
		}
		public Short getTgtCriParamUpdateCount()
		{
			return _nCriParamUpdateCount;
		}
   //  Arun_FSOtherBenefitsTargetTab_REL8.1 Ends
		//CR_OtherBenefit_sequence_Rel8.2_start
		public void setSeqNbr(Short nSeqNbr)
		{
			_nSeqNbr=nSeqNbr;
		}
		public Short getSeqNbr()
		{
			return _nSeqNbr;
		}
//CR_OtherBenefit_sequence_Rel8.2_end
		
		// start CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011
		public Short _nPrdPeriod;
		
		public void setPrdPeriod(Short nPrdPeriod){
			this._nPrdPeriod = nPrdPeriod;
		}
		
		public Short getPrdPeriod(){
			return _nPrdPeriod;
		}
		
		// End CR:FSD_ADM_Componsation_2011_v1.0.doc added/modified by Nilkanth on 16-06-2011
    public String toString()
    {
        String retValue = " _lBonusHdrSeqNbr : " + _lBonusHdrSeqNbr + "_nbonusdescinACS:"+ _nbonusdescinACS + "_nIsInclusioninACS:" + _nIsInclusioninACS
         + " _strBonusType : " + _strBonusType + " _strBonusDesc : " + _strBonusDesc + " _dtEffFrom : " + _dtEffFrom + " _dtEffTo : " +
            _dtEffTo + " _cChannelType : " + _cChannelType + " _strDesgnCd : " +
            _strDesgnCd + " _nFreqOfCalc : " + _nFreqOfCalc +" _accountcodeforAcs :"+ _accountcodeforAcs+
            " _nStartMonthCalc  : " + _nStartMonthCalc + " _nFreqOfPmt : " +
            _nFreqOfPmt + " _nPmtDay : " + _nPmtDay +
            " _nIsInclOrExclPmt : " + _nIsInclOrExclPmt +
            " _nIsInclOrExclTgt : " + _nIsInclOrExclTgt +
            " _nIsTDSAppl : " + _nIsTDSAppl + " _nIsSTAppl : " + _nIsSTAppl +
            " _nIsTargetBased:" + _nIsTargetBased+ " _nTargetProRata:" + _nTargetProRata
            + "_strCriParamNames : " + _strCriParamNames + "_strCriParamIds : " + _strCriParamIds +
            "_nFreqOfInst " + _nFreqOfInst+ " _nIsCampaignc :" + _nIsCampaign + " _nEndImmediate :" +
            _nEndImmediate +"_nAgtTerminatedStat:"+ _nAgtTerminatedStat +"_nBonusLevel:"+ _nBonusLevel +
            "_dCapPercentage:"+_dCapPercentage +"_dHoldPercentage:"+ _dHoldPercentage +
            "_nReportees:"+_nReportees +"_nYearBasis:"+ _nYearBasis +
            "_strPaidToAgtAgncy:"+ _strPaidToAgtAgncy+"_strApplicableAgtAgncyCd[]:"+ _strApplicableAgtAgncyCd +
            "_strApplicableAgtAgncyName[]"+_strApplicableAgtAgncyName+
            "_nRecalculationType"+_nRecalculationType+ "_nIsMnylAgt" + _nIsMnylAgt
            + "_strMinRequirement" + _strMinRequirement + "_nBnusPayOutMthd" + _nBnusPayOutMthd + "_nTgtBnsLevel" + _nTgtBnsLevel
            + "_nSeqNbr : " + _nSeqNbr + "_nIsInclOrExcl" + _nIsInclOrExcl + "_strBaseParamId" + _strBaseParamId+ "_strDesgCd" + _strDesgCd;

        return retValue;
    }

    //member variable declarations
    private String _strBonusDesc;
    private String _strBonusType;
    private GregorianCalendar _dtEffFrom;
    private GregorianCalendar _dtEffTo;
    private String _cChannelType;
	private Short _nEndImmediate;
    private String _strDesgnCd;
    private Short _nFreqOfCalc;
    //Santosh_Ph_II
    private Short _nFreqOfProd;
    private Short _nStartMonthCalc;
    private Short _nFreqOfPmt;
    private Short _nPmtDay;
    private Short _nNoOfInstallment;
    private Short _nIsTDSAppl;
    private Short _nIsSTAppl;
    private String _strAcctCd;
    private String _strOSAcctCd;
    private String _strProvAcctCd;
    private Short _nIsInclOrExclPmt;
    private Short _nIsInclOrExclTgt;
    private Long _lBonusHdrSeqNbr;
    private Short _nIsTargetBased;
	private Short _nTargetProRata; // shameem
    private String _strCriParamIds;
    private String _strCriParamNames;
    private ArrayList _alCriParamDetails;

    private String _strBonusParamId;
    private Short _nAmtPerc;
    private Double _dUnits;
    private String[] _strBonusRate;
    private String[] _strApplDesgn;
    private String[] _strCriDesgn;
    //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start
    private String[] _strDesgCd;
    private String[] _strBaseParamId;
    private String[] _nIsInclOrExcl;
    //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
    //Amid_MP/P_Incentive Scheme Starts
    private String[] _nScoreType;
    private String[] _nGlpWeightage;
    private String[] _dFrom;
    private String[] _dTo;
    private String[] _nValue;
    //Amid_MP/P_Incentive Scheme Ends
    private String[] _lParamSeqNbr;
    private String[] _strParamStatusFlag;

    private Double _dTargetValue;
    private Short _nFreqOfInst;
	private Short _nIsCampaign; // shameem
//Jimmy_OtherBenefits_1.1_REL8.0 Starts
	private Short _nYearBasis;
	private Short _nAgtTerminatedStat;
    //Amid_added_nBonusToTermAgent_field_Starts	
	private Short _nBonusToTermAgent;
   //Amid_added_nBonusToTermAgent_field_Ends
	private Short _nBonusLevel;
	private Short _nReportees;
	private Double _dCapPercentage;
	private Double _dHoldPercentage;
	private String _strPaidToAgtAgncy;
	private String[] _strApplicableAgtAgncyCd;
	private String[] _strApplicableAgtAgncyName;
//Jimmy_OtherBenefits_1.1_REL8.0 Ends
//Jimmy_OtherBenefits_1.3.2.1_REL8.0 Starts
	private Short _nRecalculationType;
//Jimmy_OtherBenefits_1.3.2.1_REL8.0 Ends
//Jimmy_OtherBenefits_1.4_REL8.0 Starts
	private String[] _nIsMnylAgt;
//Jimmy_OtherBenefits_1.4_REL8.0 Ends
//Jimmy_OtherBenefits_1.10_REL8.0 Starts
	private String _strMinRequirement;
	private Short _nBnusPayOutMthd;
//Jimmy_OtherBenefits_1.10_REL8.0 Ends
	private Short _nTgtBnsLevel;
//	Arun_FSOtherBenefitsTargetTab_REL8.1 Starts
	private Short _nCriParamUpdateCount;
	private Short _nTgtPlanAttachmentTo;
	private Short _nTgtRecalculationType;
	private String _strTgtCriParamIds;
	private String _strTgtCriPramNames;
	private String _strTgtOffWeightage;
//	Modified by Amid Start
	private String _strTgtOffWeightage2;
	private String _strTgtOffWeightage3;
//	Modified by Amid End
	private String _strTgtOffVintageFrom;
	private String _strTgtOffVintageTo;
	private String _strTgtMinReqment;
	private TargetCriteriaParamResult oTargetCriteriaParamResult;
	private String _strOffMultiplierFrom;
	private String _strOffMultiplierTo;
	private String _strOffMultiplier;
	private TargetOfficeMultiplierResult oTargetOfficeMultiplierResult;
	private Integer _nRowCount;
	private Integer _nColumnCount;
	private String _strTgtDesgnCd;
	private String _nAgentorGOCd;
	private String _strTargetParamValue;
	 
	private TargetParamDetailsResult oTargetParamDetailsResult;
	private String _strYearTgt;
//Arun_FSOtherBenefitsTargetTab_REL8.1 Ends
	private Short _nSeqNbr;//CR_OtherBenefit_sequence_Rel8.2_start
	//SUNAINA_FS_TRAINING_INCENTIVE_STARTS
	private Short _nHeldPayoutFreq = null;
	//SUNAINA_FS_TRAINING_INCENTIVE_ENDS
	//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Ends	
	private Short _nIsGoAssociationAppl = null;
	//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Ends
	private String _accountcodeforAcs;//Added By Himanshu for valid DR/CR Account checking
	private Short _nIsInclusioninACS =null; //Himanshu
	private String _nbonusdescinACS =null; //Himanshu

	// Santosh_Everest_Distribution Starts
	private Short _nSegmnetType;

	private Short _nSegmnedOrNot;
// Amid modified for clawback Start
	 private Short _nClawbackPeriod;
//Amid modified for clawback End
	//Prabhat Modified for Flat Hold Payout start
	 
	 private Double _nFlatHoldPayout;
//	 Anantha_Banca_Inc
	 private Double _nCBPPerc;
	//<Rel.  - Start : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
	 private Short _nCeipExclusion;
	//<Rel.  - End : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
	 
	//<Rel.  - Start : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  > 
	public Short getCeipExclusion() {
		return _nCeipExclusion;
	}

	public void setCeipExclusion(Short _nCeipExclusion) {
		this._nCeipExclusion = _nCeipExclusion;
	}
	//<Rel.  - End : Added by  Shrikrishna on 24-03-2011 FOR CR:FSD-Agent_Compensation_2011_v1.0.doc  >
	public Double getFlatHoldPayout() {
		return _nFlatHoldPayout;
	}

	public void setFlatHoldPayout(Double flatHoldPayout) {
		_nFlatHoldPayout = flatHoldPayout;
	}

//	Prabhat Modified for Flat Hold Payout End
	public Short getClawbackPeriod() {
		return _nClawbackPeriod;
	}

	public void setClawbackPeriod(Short clawbackPeriod) {
		this._nClawbackPeriod = clawbackPeriod;
	}

	public Short getSegmnetType() {
		return _nSegmnetType;
	}

	public void setSegmnetType(Short segmnetType) {
		_nSegmnetType = segmnetType;
	}

	public Short getSegmnedOrNot() {
		return _nSegmnedOrNot;
	}

	public void setSegmnedOrNot(Short segmnedOrNot) {
		_nSegmnedOrNot = segmnedOrNot;
	}
	// Santosh_Everest_Distribution Ends

	public Short getFreqOfProd() {
		return _nFreqOfProd;
	}

	public void setFreqOfProd(Short freqOfProd) {
		this._nFreqOfProd = freqOfProd;
	}
	//SUNAINA_FS_TRAINING_INCENTIVE_STARTS
    /**
     * Gets HeldPayoutFreq
     * @return Short
     */

	 public Short getHeldPayoutFreq()
	    {
	        return _nHeldPayoutFreq;
	    }

	    /**
	     * Sets HeldPayoutFreq
	     * @param a_nHeldPayoutFreq Short
	     */
	    public void setHeldPayoutFreq(Short a_nHeldPayoutFreq)
	    {
	        this._nHeldPayoutFreq = a_nHeldPayoutFreq;
	    }
	  //SUNAINA_FS_TRAINING_INCENTIVE_ENDS
	   //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 Start
		public String[] getIsInclOrExcl() {
			return _nIsInclOrExcl;
		}

		public void setIsInclOrExcl(String[] isInclOrExcl) {
			this._nIsInclOrExcl = isInclOrExcl;
		}

		public String[] getBaseParamId() {
			return _strBaseParamId;
		}

		public void setBaseParamId(String[] baseParamId) {
			this._strBaseParamId = baseParamId;
		}

		public String[] getDesgCd() {
			return _strDesgCd;
		}

		public void setDesgCd(String[] desgCd) {
			this._strDesgCd = desgCd;
		}
	    //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
		//Amid_MP/P_Incentive Scheme Starts
		public String[] getScoreType() {
			return _nScoreType;
		}

		public void setScoreType(String[] ScoreType) {
			this._nScoreType = ScoreType;
		}
		public String[] getGlpWeightage() {
			return _nGlpWeightage;
		}

		public void setGlpWeightage(String[] GlpWeightage) {
			this._nGlpWeightage = GlpWeightage;
		}
		public void setFrom(String[] From) {
			this._dFrom = From;
		}
		public String[] getFrom() {
			return _dFrom;
		}
		public void setTo(String[] To) {
			this._dTo = To;
		}
		public String[] getTo() {
			return _dTo;
		}
		public void setValue(String[] Value) {
			this._nValue = Value;
		}
		public String[] getValue() {
			return _nValue;
		}
		//Amid_MP/P_Incentive Scheme Ends
		

		public Double getCBPPerc() {
			return _nCBPPerc;
		}

		public void setCBPPerc(Double perc) {
			_nCBPPerc = perc;
		}
	    //Amid_FSD _AGN-95_Recruitment Bonus Disbursement v1.3 End
		//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Starts	
		public Short getIsGoAssociationAppl() {
			return _nIsGoAssociationAppl;
		}

		public void setIsGoAssociationAppl(Short isGoAssociationAppl) {
			this._nIsGoAssociationAppl = isGoAssociationAppl;
		}
		//Amid_Everest_Ph2_App_IP_Incentive_Scheme_Ends	
		
	   // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 starts
		private Short _nPayIfColnNotPresent = null;

		public Short get_nPayIfColnNotPresent() {
			return _nPayIfColnNotPresent;
		}

		public void set_nPayIfColnNotPresent(Short nPayIfColnNotPresent) {
			_nPayIfColnNotPresent = nPayIfColnNotPresent;
		}
	   // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 ends
		
}

