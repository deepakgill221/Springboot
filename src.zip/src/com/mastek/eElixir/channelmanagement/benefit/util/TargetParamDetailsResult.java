/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: MY AGENT
*  FILENAME			: TargetParamDetailsResult.java
*  AUTHOR			: Arun Kumar
*  VERSION			: 1.0
*  CREATION DATE	: July 8th 2007
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2007.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.0    july 8th 2007  Arun Kumar    Rel8.1 Other Benefits                                   
*
*
*  Arun_FSOtherBenefitsTargetTab_REL8.1 
*--------------------------------------------------------------------------------
*
/*********************************************************************/

/**
* <p> Title: eElixir </p>
* <p> Description:Result object for OtherBenefit Target parameter Details</p>
* <p> Copyright: Copyright (c) 2007 * </p>
* <p> Company: Mastek Ltd * </p>
* @author Arun Kumar
* @version 1.0
*/

package com.mastek.eElixir.channelmanagement.benefit.util;

import java.io.Serializable;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class TargetParamDetailsResult extends UserData implements Serializable 
{
    public TargetParamDetailsResult()
    {
        
    }
    
    
     private ArrayList alDesgnCd=null;
     private ArrayList alAgentGOCd=null;
     private ArrayList alDtarget=null;
    
     public ArrayList getDesgnCd()
     {
       return alDesgnCd;
     }
     public void setDesgnCd(ArrayList alDesgnCd )
     {
    	 this.alDesgnCd=alDesgnCd;
     }
     public ArrayList getAgentGOCd()
     {
    	 return alAgentGOCd;
     }
     public void setAgentGOCd(ArrayList alAgentGOCd)
     {
    	 this.alAgentGOCd=alAgentGOCd;
     }
     public ArrayList getDtarget()
     {
    	 return alDtarget;
     }
     public void setDtarget(ArrayList alDtarget)
     {
    	 this.alDtarget=alDtarget;
     }
       
}
