/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: MY AGENT
*  FILENAME			: TargetOfficeMultiplierResult.java
*  AUTHOR			: Arun Kumar
*  VERSION			: 1.0
*  CREATION DATE	: July 8th 2007
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2007.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.0    july 8th 2007  Arun Kumar    Rel8.1 Other Benefits                                   
*
*
*  Arun_FSOtherBenefitsTargetTab_REL8.1 
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
* <p> Title: eElixir </p>
* <p> Description:Result object for OtherBenefit Target Office Multiplier Result</p>
* <p> Copyright: Copyright (c) 2007 * </p>
* <p> Company: Mastek Ltd * </p>
* @author Arun Kumar
* @version 1.0
*/

package com.mastek.eElixir.channelmanagement.benefit.util;

import java.io.Serializable;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class TargetOfficeMultiplierResult extends UserData implements Serializable 
{
    public TargetOfficeMultiplierResult()
    {
        
    }
    
      private ArrayList alOfficeMultiplierFrom=null;
      private ArrayList alOfficeMultiplierTo=null;
      private ArrayList alOfficeMultiplier=null;
   

    /**
     * @return Returns the alOfficeMultiplierFrom.
     */
	public ArrayList getOfficeMultiplierFrom()
	{
		return alOfficeMultiplierFrom;
	}
	/**
     * @param alOfficeMultiplierFrom
     * The alOfficeMultiplierFrom to set.
     */
	public void setOfficeMultiplierFrom(ArrayList alOfficeMultiplierFrom)
	{
		this.alOfficeMultiplierFrom = alOfficeMultiplierFrom;
	}
	/**
     * @return Returns the alOfficeMultiplierTo.
     */
	public ArrayList getOfficeMultiplierTo()
	{
		return alOfficeMultiplierTo;
	}
	/**
     * @param alOfficeMultiplierTo
     * The alOfficeMultiplierTo to set.
     */
	public void setOfficeMultiplierTo(ArrayList alOfficeMultiplierTo)
	{
		this.alOfficeMultiplierTo = alOfficeMultiplierTo;
	}
	/**
     * @return Returns the alOfficeMultiplier.
     */
	public ArrayList getOfficeMultiplier()
	{
		return alOfficeMultiplier;
	}
	/**
     * @param alOfficeMultiplier
     * The alOfficeMultiplier to set.
     */
	public void setOfficeMultiplier(ArrayList alOfficeMultiplier)
	{
		this.alOfficeMultiplier = alOfficeMultiplier;
	}

   
}
