/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitFetch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*2.1        06/09/2003   Dipti F        UT Rework
*2.2        29/09/2003   Dipti F        UT Rework Column Benefit Type change
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * BenefitFetch is the Utility Class for fetching parameter for Benefit
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.benefit.util;

import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.benefit.dvo.BenefitEligibilityCriteria;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;


public class BenefitFetch
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the BenefitFetch class
   */
  public BenefitFetch()
  {

  }


  /**
   * This Fetches all the paramater for benefit except primary key
   * @param a_oRequest HttpServletRequest object.
   * @return BenefitResult
   * @throws EElixirException
   */
  public BenefitResult fetchBenefit(HttpServletRequest a_oRequest) {
    BenefitResult oBenefitResult = null;
    log.debug("BenefitFetch--Inside Benefit Fetch");
    BenefitEligibilityCriteria oBenefitEligibilityCriteria = null;

    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");

    String strBenDesc               = a_oRequest.getParameter("strBenDesc").trim();

    String strBenType                  = a_oRequest.getParameter("strBenType").trim();

    log.debug("BenefitFetch--Got 2 values strBenDesc, strBenType:" + strBenDesc + " " + strBenType);

    GregorianCalendar dtEffFrom = DateUtil.retGCDate(a_oRequest.getParameter("dtEffFrom").trim());

    GregorianCalendar dtEffTo = null;
    if(a_oRequest.getParameter("dtEffTo").trim().equals("")){

      dtEffTo   = DateUtil.retGCDate(DataConstants.MAX_DATE_LIMIT);
    }
    else{

      dtEffTo   = DateUtil.retGCDate(a_oRequest.getParameter("dtEffTo").trim());
    }
    log.debug("BenefitFetch--After fetching date");

    Character cChannelType          = new Character(a_oRequest.getParameter("cChannelType").trim().charAt(0));

    String strDesgnCd               = a_oRequest.getParameter("strDesgnCd").trim();

    Short nFreqOfCalc               = new Short(a_oRequest.getParameter("nFreqOfCalc").trim());

    Short nFreqOfPmt                = new Short(a_oRequest.getParameter("nFreqOfPmt").trim());

    Short nStartMonth               = new Short(a_oRequest.getParameter("nStartMonth").trim());

    Short nRef                      = new Short(a_oRequest.getParameter("nRef").trim());

    Short nIsSpecificBenefit        = new Short(a_oRequest.getParameter("nIsSpecificBenefit").trim());

    Long lFormlDefnSeqNbr			= null;


    String strIsTDSAppl = a_oRequest.getParameter("nIsTDSAppl");
    String strIsSTAppl = a_oRequest.getParameter("nIsSTAppl");
	Short nIsTDSAppl = null;
	Short nIsSTAppl = null;
	if ((strIsTDSAppl != null) && !strIsTDSAppl.equals(""))
	{
		nIsTDSAppl = new Short(strIsTDSAppl);
	}
	if ((strIsSTAppl != null) && !strIsSTAppl.equals(""))
	{
		nIsSTAppl = new Short(strIsSTAppl);
	}

    oBenefitResult = new BenefitResult();
    oBenefitResult.setBenDesc(strBenDesc);
    oBenefitResult.setBenType(strBenType);
    oBenefitResult.setDtEffFrom(dtEffFrom);
    oBenefitResult.setDtEffTo(dtEffTo);
    oBenefitResult.setChannelType(cChannelType);
    oBenefitResult.setDesgnCd(strDesgnCd);

    oBenefitResult.setFreqOfCalc(nFreqOfCalc);
    oBenefitResult.setFreqOfPmt(nFreqOfPmt);
    oBenefitResult.setStartMonth(nStartMonth);

    oBenefitResult.setRef(nRef);
    oBenefitResult.setIsSpecificBenefit(nIsSpecificBenefit);

    if (nIsSpecificBenefit.intValue() == DataConstants.NO)
    {

	    lFormlDefnSeqNbr = new Long(a_oRequest.getParameter("lFormlDefnSeqNbr").trim());
	    oBenefitResult.setFormlDefnSeqNbr(lFormlDefnSeqNbr);
    }
    oBenefitResult.setUserId(_strUserId);

	oBenefitResult.setIsTDSAppl(nIsTDSAppl);
	oBenefitResult.setIsSTAppl(nIsSTAppl);

    //Now Fetching record for Benefit Calculation type Calculation

    Short nBenDetailType = null;
    Short nMonthFrom = null;
    Short nMonthTo = null;
	/* 
    if (nIsSpecificBenefit.intValue() == DataConstants.YES)
    {
	    nBenDetailType = new Short(a_oRequest.getParameter("nBenDetailTypeC").trim());
	    log.debug("BenefitFetch--nBenDetailTypeC:" + nBenDetailType);
	    nEvalFunction  = new Short(a_oRequest.getParameter("nEvalFunctionC").trim());
	    log.debug("BenefitFetch--nEvalFunctionC:" + nEvalFunction);
	    Double dEvalValue = null;
	    if(!a_oRequest.getParameter("dEvalValueC").trim().equals("")){
	        log.debug("BenefitFetch--inside fetch of dEvalValue");
	        dEvalValue  = new Double(a_oRequest.getParameter("dEvalValueC").trim());
	    }
	    log.debug("BenefitFetch--dEvalValue:" + dEvalValue);
	    nMonthFrom     = new Short(a_oRequest.getParameter("nMonthFromC").trim());
	    log.debug("BenefitFetch--nMonthFrom:" + nMonthFrom);
	    nMonthTo       = new Short(a_oRequest.getParameter("nMonthToC").trim());
	    log.debug("BenefitFetch--nMonthTo:" + nMonthTo);
	    log.debug("BenefitFetch--Fetched details of Benefit Calculation");

   
	    oBenefitCalculationCriteria = new BenefitCalculationCriteria();
	    oBenefitCalculationCriteria.setBenDetailType(nBenDetailType);
	    oBenefitCalculationCriteria.setEvalFunction(nEvalFunction);
	    oBenefitCalculationCriteria.setEvalValue(dEvalValue);
	    oBenefitCalculationCriteria.setMonthFrom(nMonthFrom);
	    oBenefitCalculationCriteria.setMonthTo(nMonthTo);
	    oBenefitCalculationCriteria.setUserId(_strUserId);
	    oBenefitResult.setBenefitCalculationCriteria(oBenefitCalculationCriteria);
    }
	*/
    // ************************************************************
    //Now Fetching record for Benefit Eligibility type Calculation
	    Short nCritFunction   =null;

			String strBenDetailType =a_oRequest.getParameter("nBenDetailTypeE");

    if(strBenDetailType!=null && !strBenDetailType.trim().equals(""))
	  {

		nBenDetailType        = new Short(a_oRequest.getParameter("nBenDetailTypeE").trim());
	  }

	String strCritFunction =a_oRequest.getParameter("nCritFunctionE").trim();

	if ( strCritFunction!=null && !strCritFunction.trim().equals("") )
	{
		nCritFunction   = new Short(strCritFunction);
	}

    String strElgbleValue = a_oRequest.getParameter("strElgbleValueE").trim();

		String strMonthFrom=a_oRequest.getParameter("nMonthFromE");
   if (strMonthFrom!=null && !strMonthFrom.trim().equals(""))
   {
    nMonthFrom            = new Short(strMonthFrom);
   }

		String strMonthTo=a_oRequest.getParameter("nMonthFromE").trim();
		if ( strMonthTo!=null && !strMonthTo.equals(""))
		{
			    nMonthTo = new Short(strMonthTo);

		}

    log.debug("BenefitFetch--Fetched details of Benefit Eligibility");
		
    oBenefitEligibilityCriteria = new BenefitEligibilityCriteria();
    oBenefitEligibilityCriteria.setBenDetailType(nBenDetailType);
    oBenefitEligibilityCriteria.setCritFunction(nCritFunction);
    oBenefitEligibilityCriteria.setElgbleValue(strElgbleValue);
    oBenefitEligibilityCriteria.setMonthFrom(nMonthFrom);
    oBenefitEligibilityCriteria.setMonthTo(nMonthTo);
    oBenefitEligibilityCriteria.setUserId(_strUserId);
		
    //oBenefitResult.setArrProductMix(productMixFetch(a_oRequest));

    oBenefitResult.setBenefitEligibilityCriteria(oBenefitEligibilityCriteria);
    return oBenefitResult;
  }

  /**
   * This method fetches all the details of Standard Commission.
   * @return ArrayList ArrayList of ProductMix
   * @param a_oRequest HttpServletRequest object.
   */
 /* private ArrayList productMixFetch(HttpServletRequest a_oRequest){
    ArrayList arrProductMix = null;
    ProductMix oProductMix = null;
    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");

    log.debug("BenefitFetch--Fetching details of Benefit Product Mix");
    String[] strProdCdVer = a_oRequest.getParameterValues("strProdCdVer");
    //String[] lbenseqnbr = a_oRequest.getParameterValues("lbenseqnbr"); //double
    String[] strProdPerc = a_oRequest.getParameterValues("dProdPerc"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlag"); //String

    // if minimum one of the status flag is not of type clear mode then
    // initialize arrProdMix
    if(strProdCdVer != null){
      for(int i = 0; i<strProdCdVer.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          arrProductMix = new ArrayList(10);
          break;
        }
      }
    }
    log.debug("BenefitFetch--Checking Clear Mode flag");

    if(arrProductMix != null){
      for(int i = 0; i<strProdCdVer.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){

          oProductMix = new ProductMix();
          log.debug("BenefitFetch--Before Getting ProdCd and Ver");
          StringTokenizer st = new StringTokenizer(strProdCdVer[i],"|");
          String strProdCd = null;
          String strProdVer = null;
          while(st.hasMoreTokens()){
            strProdCd = (String)st.nextElement();
            break;
          }
          while(st.hasMoreTokens()){
            strProdVer = (String)st.nextElement();
          }
          Integer iProdVer = null;
          if(strProdVer != null){
            iProdVer = new Integer(strProdVer);
          }
          log.debug("BenefitFetch--After Getting ProdCd and Ver");
          oProductMix.setProdCd(strProdCd);
          oProductMix.setProdVer(iProdVer);
          oProductMix.setStatusFlag(strStatusFlag[i]);
          oProductMix.setUserId(_strUserId);
          log.debug("BenefitFetch--After setting ProdCd and Ver");
          oProductMix.setProdPerc(new Double(strProdPerc[i].trim()));
          log.debug("BenefitFetch--After setting dProdPerc");
          arrProductMix.add(oProductMix);
        }
      }
    }
    log.debug("BenefitFetch--Fetched details of Benefit Product Mix");
    return arrProductMix;
  }*/



}