/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: MY AGENT
*  FILENAME			: TargetCriteriaParamResult.java
*  AUTHOR			: Arun Kumar
*  VERSION			: 1.0
*  CREATION DATE	: July 8th 2007
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2007.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*  Arun_FSOtherBenefitsTargetTab_REL8.1
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
* <p> Title: eElixir </p>
* <p> Description:Result object for OtherBenefit Target Criteria Parameter Details</p>
* <p> Copyright: Copyright (c) 2007 * </p>
* <p> Company: Mastek Ltd * </p>
* @author Arun Kumar
* @version 1.0
*/

package com.mastek.eElixir.channelmanagement.benefit.util;

import java.io.Serializable;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class TargetCriteriaParamResult extends UserData implements Serializable
{
    public TargetCriteriaParamResult()
    {

    }


    private ArrayList alCriteriaParamIds =null;
    private ArrayList alCriteriaParamNames=null;
    private ArrayList alOfficeVintageFrom=null;
    private ArrayList alOfficeVintageTo=null;
    private ArrayList alWeightage=null;
//	Modified by Amid Start
    private ArrayList alWeightage2=null;
    private ArrayList alWeightage3=null;
//	Modified by Amid End

    private ArrayList alMinRequirement=null;

    /**
     * @return Returns the alCriteriaParamIds.
     */
    public ArrayList getCriteriaParamIds() {
        return alCriteriaParamIds;
    }
    /**
     * @param alCriteriaParamIds The alCriteriaParamIds to set.
     */
    public void setCriteriaParamIds(ArrayList alCriteriaParamIds) {
        this.alCriteriaParamIds = alCriteriaParamIds;
    }
    /**
     * @return Returns the alCriteriaParamNames.
     */
    public ArrayList  getCriteriaParamNames() {
        return alCriteriaParamNames;
    }
    /**
     * @param alCriteriaParamNames The alCriteriaParamNames to set.
     */
    public void setCriteriaParamNames(ArrayList alCriteriaParamNames) {
        this.alCriteriaParamNames = alCriteriaParamNames;
    }
    /**
     * @return Returns the alOfficeVintageFrom.
     */
	public ArrayList getOfficeVintageFrom()
	{
		return alOfficeVintageFrom;
	}
	/**
     * @param alOfficeVintageFrom
     * The alOfficeVintageFrom to set.
     */
	public void setOfficeVintageFrom(ArrayList alOfficeVintageFrom)
	{
		this.alOfficeVintageFrom =alOfficeVintageFrom;
	}
	/**
     * @return Returns the alOfficeVintageTo.
     */
	public ArrayList getOfficeVinatageTo()
	{
		return alOfficeVintageTo;
	}
	/**
     * @param alOfficeVintageTo
     * The alOfficeVintageTo to set.
     */
	public void setOfficeVinatageTo(ArrayList alOfficeVintageTo)
	{
		this.alOfficeVintageTo = alOfficeVintageTo;
	}
	/**
     * @return Returns the alWeightage.
     */
	public ArrayList getBnsWeightage()
	{
		return alWeightage;
	}
//	Modified by Amid Start	
	public ArrayList getBnsWeightage2()
	{
		return alWeightage2;
	}
	public ArrayList getBnsWeightage3()
	{
		return alWeightage3;
	}
//	Modified by Amid End
	/**
     * @param alWeightage
     * The alWeightage to set.
     */
	public void setBnsWeightage(ArrayList alWeightage)
	{
		this.alWeightage = alWeightage;
	}
//	Modified by Amid Start	
	public void setBnsWeightage2(ArrayList alWeightage2)
	{
		this.alWeightage2 = alWeightage2;
	}
	public void setBnsWeightage3(ArrayList alWeightage3)
	{
		this.alWeightage3 = alWeightage3;
	}
//	Modified by Amid End
	/**
     * @param alMinRequirement
     * The alMinRequirement to set.
     */
	public void setMinRequirement(ArrayList alMinRequirement)
	{
		this.alMinRequirement = alMinRequirement;
	}
	/**
     * @return Returns the alMinRequirement.
     */
	public ArrayList getMinRequirement()
	{
		return alMinRequirement;
	}
}
