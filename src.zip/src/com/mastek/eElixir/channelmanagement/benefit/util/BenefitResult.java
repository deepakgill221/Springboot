/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitResult.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*2.1        06/09/2003   Dipti F        UT Rework
*2.2        29/09/2003   Dipti F        UT Rework Column Benefit Type change
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Benefit Result</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.benefit.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.benefit.dvo.BenefitEligibilityCriteria;
import com.mastek.eElixir.channelmanagement.util.UserData;

public class BenefitResult extends UserData implements Serializable{
   /**
    * Sequence Number
    */
   protected Long _lBenSeqNbr = null;

   /**
    * Benefit Description
    */
   protected String _strBenDesc = null;

   /**
    * Benefit Type
    */
   protected String _nBenType = null;

   /**
    * Effective From Date
    */
   protected GregorianCalendar _dtEffFrom = null;

   /**
    * Effective To Date
    */
   protected GregorianCalendar _dtEffTo = null;

   /**
    * Channel Type , from Channel type master
    */
   protected Character _cChannelType = null;

   /**
    * Designation Code
    */
   protected String _strDesgnCd = null;

   /**
    * Fequency of Calculation
    */
   protected Short _nFreqOfCalc = null;

   /**
    * Frequency of Payment
    */
   protected Short _nFreqOfPmt = null;

   /**
    * Start of Month
    */
   protected Short _nStartMonth = null;

   /**
    * TDS Applicable
    */
   protected Short _nIsTDSAppl = null;

   /**
    * ST Applicable
    */
   protected Short _nIsSTAppl = null;

   /**
    * Reference
    */
   protected Short _nRef = null;
   protected Short _nIsSpecificBenefit = null;

   protected Long _lFormlDefnSeqNbr = null;

   //protected ArrayList _arrProductMix = null;


   protected BenefitEligibilityCriteria _oBenefitEligibilityCriteria;

   public BenefitResult()
   {

   }
  public Character getChannelType() {
    return _cChannelType;
  }
  public void setChannelType(Character a_cChannelType) {
    this._cChannelType = a_cChannelType;
  }
  public GregorianCalendar getDtEffFrom() {
    return _dtEffFrom;
  }
  public void setDtEffFrom(GregorianCalendar a_dtEffFrom) {
    this._dtEffFrom = a_dtEffFrom;
  }
  public GregorianCalendar getDtEffTo() {
    return _dtEffTo;
  }
  public void setDtEffTo(GregorianCalendar a_dtEffTo) {
    this._dtEffTo = a_dtEffTo;
  }
  public Long getBenSeqNbr() {
    return _lBenSeqNbr;
  }
  public void setBenSeqNbr(Long a_lBenSeqNbr) {
    this._lBenSeqNbr = a_lBenSeqNbr;
  }
  public String getBenType() {
    return _nBenType;
  }
  public void setBenType(String a_nBenType) {
    this._nBenType = a_nBenType;
  }
  public Short getFreqOfCalc() {
    return _nFreqOfCalc;
  }
  public void setFreqOfCalc(Short a_nFreqOfCalc) {
    this._nFreqOfCalc = a_nFreqOfCalc;
  }
  public Short getFreqOfPmt() {
    return _nFreqOfPmt;
  }
  public void setFreqOfPmt(Short a_nFreqOfPmt) {
    this._nFreqOfPmt = a_nFreqOfPmt;
  }
  public Short getRef() {
    return _nRef;
  }
  public void setRef(Short a_nRef) {
    this._nRef = a_nRef;
  }
  public Short getStartMonth() {
    return _nStartMonth;
  }
  public void setStartMonth(Short a_nStartMonth) {
    this._nStartMonth = a_nStartMonth;
  }
  public BenefitEligibilityCriteria getBenefitEligibilityCriteria() {
    return _oBenefitEligibilityCriteria;
  }
  public void setBenefitEligibilityCriteria(BenefitEligibilityCriteria a_oBenefitEligibilityCriteria) {
    this._oBenefitEligibilityCriteria = a_oBenefitEligibilityCriteria;
  }
  public String getBenDesc() {
    return _strBenDesc;
  }
  public void setBenDesc(String a_strBenDesc) {
    this._strBenDesc = a_strBenDesc;
  }
  public String getDesgnCd() {
    return _strDesgnCd;
  }
  public void setDesgnCd(String a_strDesgnCd) {
    this._strDesgnCd = a_strDesgnCd;
  }

  public Short getIsSpecificBenefit() {
    return _nIsSpecificBenefit;
  }
  public void setIsSpecificBenefit(Short a_nIsSpecificBenefit) {
    this._nIsSpecificBenefit = a_nIsSpecificBenefit;
  }

  public Long getFormlDefnSeqNbr() {
    return _lFormlDefnSeqNbr;
  }
  public void setFormlDefnSeqNbr(Long a_lFormlDefnSeqNbr) {
    this._lFormlDefnSeqNbr = a_lFormlDefnSeqNbr;
  }

  public Short getIsTDSAppl() {
    return _nIsTDSAppl;
  }
  public void setIsTDSAppl(Short a_nIsTDSAppl) {
    this._nIsTDSAppl = a_nIsTDSAppl;
  }

  public Short getIsSTAppl() {
    return _nIsSTAppl;
  }
  public void setIsSTAppl(Short a_nIsSTAppl) {
    this._nIsSTAppl = a_nIsSTAppl;
  }

  /*public ArrayList getArrProductMix() {
    return _arrProductMix;
  }
  public void setArrProductMix(ArrayList a_arrProductMix) {
    this._arrProductMix = a_arrProductMix;
  }*/


  public String toString(){
    String retValue = "";
    retValue = retValue + "_lBenSeqNbr:" + _lBenSeqNbr + "\n";
    retValue = retValue + "_strBenDesc:" + _strBenDesc + "\n";
    retValue = retValue + "_nBenType:" + _nBenType + "\n";
    retValue = retValue + "_dtEffFrom:" + _dtEffFrom + "\n";

    retValue = retValue + "_dtEffTo:" + _dtEffTo + "\n";
    retValue = retValue + "_cChannelType:" + _cChannelType + "\n";
    retValue = retValue + "_strDesgnCd:" + _strDesgnCd + "\n";
    retValue = retValue + "_nFreqOfCal:" + _nFreqOfCalc + "\n";

    retValue = retValue + "_nFreqOfPmt:" + _nFreqOfPmt + "\n";
    retValue = retValue + "_nStartMonth:" + _nStartMonth + "\n";
    retValue = retValue + "_nRef:" + _nRef + "\n";
    retValue = retValue + "_nIsSpecificBenefit:" + _nIsSpecificBenefit + "\n";
    retValue = retValue + "_oBenefitEligibilityCriteria:" + _oBenefitEligibilityCriteria + "\n";
    //retValue = retValue + "_arrProductMix:" + _arrProductMix + "\n";

    return retValue;
  }



}
