/********************************************************************
 *  PROJECT			: MNYL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME		: TPRDetailsResult.java
 *  AUTHOR			: Anup Kumar
 *  VERSION			: 1.0
 *  CREATION DATE   : June 26, 2010
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT	    : COPYRIGHT (C) 2002.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *	Anup_AugRel2010_FSD_TPR_V1.3	
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for TPR Details </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Anup Kumar
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.benefit.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class TPRDetailsResult extends UserData implements Serializable {

	protected Long _lTPRDetSeqNbr = null;
	
	private String _strParamCd = null;

	private String _strStatusFlag = null;

	private GregorianCalendar _dtEffFrom = null;

	private GregorianCalendar _dtEffTo = null;

	private String _dValue = null;
	
	private Short _nIsParamAppl = null; 
	
	private String _strSegmentaton = null; 
	
	

	public TPRDetailsResult() {

	}
	public Long getTPRDetSeqNbr() {
		return _lTPRDetSeqNbr;
	}

	public void setTPRDetSeqNbr(Long mpsDetSeqNbr) {
		this._lTPRDetSeqNbr = mpsDetSeqNbr;
	}
	
	public String getParamCd() {
		return _strParamCd;
	}

	public void setParamCd(String a_strParamCd) {
		this._strParamCd = a_strParamCd;
	}

	public void setTargetValue(String a_dValue) {
		this._dValue = a_dValue;
	}

	public String getTargetValue() {
		return _dValue;
	}

	public String getStatusFlag() {
		return _strStatusFlag;
	}

	public void setStatusFlag(String a_strStatusFlag) {
		this._strStatusFlag = a_strStatusFlag;
	}

	public GregorianCalendar getDtEffFrom() {
		return _dtEffFrom;
	}

	public void setDtEffFrom(GregorianCalendar a_dtEffFrom) {
		this._dtEffFrom = a_dtEffFrom;
	}

	public GregorianCalendar getDtEffTo() {
		return _dtEffTo;
	}

	public void setDtEffTo(GregorianCalendar a_dtEffTo) {
		this._dtEffTo = a_dtEffTo;
	}
		
	public Short getIsParamAppl()
    {
        return _nIsParamAppl;
    }

    public void setIsParamAppl(Short a_nIsParamAppl)
    {
        this._nIsParamAppl = a_nIsParamAppl;
    }
	

	public String toString() {
		String retValue = " _strParamCd : " + _strParamCd + "_dtEffFrom"
				+ _dtEffFrom + "_dtEffTo :" + _dtEffTo + " StatusFlag : "
				+ _strStatusFlag +"_nIsParamAppl :"+_nIsParamAppl;
		retValue = retValue + "\n";
		return retValue;
	}
	public String getSegmentatonCd() {
		return _strSegmentaton;
	}
	public void setSegmentatonCd(String segmentaton) {
		_strSegmentaton = segmentaton;
	}	

}
