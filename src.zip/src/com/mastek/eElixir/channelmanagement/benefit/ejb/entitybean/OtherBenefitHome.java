/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : My Agent
*  FILENAME         : OtherBenefitHome.java
*  AUTHOR           : Sandeep Bangera
*  VERSION          : 1.0
*  CREATION DATE    : Jul 24, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_BONUS_DETAILS
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
**********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.common.exception.EElixirException;

public interface OtherBenefitHome extends EJBHome
{
    /**
     * Called by the client to find an EJB bean instance, usually find by primary key
     * @throws javax.ejb.FinderException
     */
    public OtherBenefit findByPrimaryKey(OtherBenefitPK primaryKey)
        throws FinderException, RemoteException, EElixirException;

    /**
     * Called by the client to create an EJB bean instance. It requires a matching pair in
     * the bean class, i.e. ejbCreate().
     * @return Bonus
     * @throws java.rmi.RemoteException
     * @throws javax.ejb.CreateException
     */
    public OtherBenefit create()
        throws CreateException, RemoteException, EElixirException;

    /**
     * Called by the client to create an EJB bean instance. It requires a matching pair in
     * the bean class
     * @param a_oBonusResult BonusResult
     * @throws java.rmi.RemoteException
     * @throws javax.ejb.CreateException
     */
    public OtherBenefit create(OtherBenefitResult a_oOtherBenefitResult)
        throws CreateException, RemoteException, EElixirException;
}
