/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: TPRMasterHome.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE    : Jun 21, 2010
*  
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* Anup_AugRel2010_FSD_TPR_V1.3
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This TPR home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * @author Anup Kumar
 * @version 1.0
 */


public interface TPRMasterHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @throws javax.ejb.FinderException
   */

  public TPRMaster findByPrimaryKey(TPRMasterPK primaryKey)
      throws FinderException, RemoteException, EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @return TPRResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public TPRMaster create()throws CreateException,RemoteException,EElixirException;


  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class
   * @param a_oSegmentationResult SegmentationResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public TPRMaster create(TPRResult a_oTPRResult) throws CreateException,RemoteException,EElixirException;


}