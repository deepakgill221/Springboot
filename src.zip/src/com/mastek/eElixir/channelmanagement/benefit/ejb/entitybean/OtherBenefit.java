/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : My Agent
*  FILENAME         : OtherBenefit.java
*  AUTHOR           : Sandeep Bangera
*  VERSION          : 1.0
*  CREATION DATE    : Jul 24, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_BONUS_DETAILS
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
**********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.common.exception.EElixirException;

public interface OtherBenefit extends EJBObject
{
    /* This method gets the BonusResult Object
    * @return BonusResult
    */
    public OtherBenefitResult getOtherBenefitResult()
        throws RemoteException, EElixirException;

    /* This method sets the BonusResult Object
    * @param a_oBonusResult BonusResult
    */
    public void setOtherBenefitResult(OtherBenefitResult a_oOtherBenefitResult)
        throws RemoteException, EElixirException;
}
