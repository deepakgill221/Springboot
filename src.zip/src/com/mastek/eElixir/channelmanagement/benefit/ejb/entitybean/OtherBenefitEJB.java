/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : OtherBenefitEJB.java
*  AUTHOR           : Sandeep Bangera
*  VERSION          : 1.0
*  CREATION DATE    : Jul 24, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_BONUS_DETAILS
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
**********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.benefit.dax.BenefitDAX;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.dax.BonusDAX;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;

public class OtherBenefitEJB implements EntityBean
{
    /**
     * Attributes declaration
     */
    private EntityContext _oContext;
    private Connection _oConnection = null;
    private DataSource _oDatasource = null;
    private BenefitDAX _oBenefitDAX;
	private BonusDAX _oBonusDAX;
    private OtherBenefitResult _oOtherBenefitResult;
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor for BonusEJB class
     */
    public OtherBenefitEJB()
    {
    }

    /**
     * Matching method of the create() method of the bean's home interface. The container
     * invokes an ejbCreate method to create an entity object. It executes in the transaction
     * context determined by the transactionattribute of the matching create() method.
     * @return BonusPK
     * @throws CreateException
     * @throws EElixirException
     */
    public OtherBenefitPK ejbCreate() throws CreateException, EElixirException
    {
        //OtherBenefitPK bpk = new OtherBenefitPK();
        return null;
    }

    /**
     * Matching method of the create(BonusResult a_oBonusResult) method of the bean's home interface. The container
     * invokes an ejbCreate method to create an entity object. It executes in the transaction
     * context determined by the transactionattribute of the matching create() method.
     * @param  a_oBonusResult BonusResult
     * @return BonusPK
     * @throws javax.ejb.CreateException
     * @throws EElixirException
     */
    public OtherBenefitPK ejbCreate(OtherBenefitResult a_oOtherBenefitResult)
        throws CreateException, EElixirException
    {
        try
        {
            _oBenefitDAX = getDAX();
            _oBenefitDAX.createOtherBenefit(a_oOtherBenefitResult);
            OtherBenefitPK cpk = new OtherBenefitPK(a_oOtherBenefitResult.getBonusHdrSeqNbr());

            return cpk;
        }
        catch (EElixirException eex)
        {
			_oLogger.fatal(getClass().getName(),"ejbCreate","EElixirException "+eex.getMessage());
            throw eex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
				_oLogger.fatal(getClass().getName(),"ejbCreate","EElixirException "+eElex.getMessage());
                throw new EElixirException(eElex, "P1005");
            }
        }
    }

    /**
     * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
     * on an instance after it invokes the ejbCreate method with the same arguments. It
     * executes in the same transaction context as that of the matching ejbCreate method.
     * @throws javax.ejb.CreateException
     * @throws EElixirException
     */
    public void ejbPostCreate() throws CreateException, EElixirException
    {
    }

    /**
     * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
     * on an instance after it invokes the ejbCreate method with the same arguments. It
     * executes in the same transaction context as that of the matching ejbCreate method.
     * @param a_oBonusResult BonusResult
     * @throws javax.ejb.CreateException
     * @throws EElixirException
     */
    public void ejbPostCreate(OtherBenefitResult a_oOtherBenefitResult)
        throws CreateException, EElixirException
    {
    }

    /**
     * A container invokes this method when the instance is taken out of the pool of available
     * instances to become associated with a specific EJB object. This method transitions
     * the instance to the ready state. This method executes in an unspecified transaction
     * context.
     */
    public void ejbActivate()
    {
    }

    /**
     * A container invokes this method on an instance before the instance becomes disassociated
     * with a specific EJB object. After this method completes, the container will place
     * the instance into the pool of available instances. This method executes in an unspecified
     * transaction context.
     */
    public void ejbPassivate()
    {
    }

    /**
     * A container invokes this method to instruct the instance to synchronize its state
     * by loading it from the underlying database. This method always executes in the transaction
     * context determined by the value of the transaction attribute in the deployment descriptor.
     */
    public void ejbLoad()
    {
        OtherBenefitPK oOtherBenefitPK = (OtherBenefitPK) _oContext.getPrimaryKey();

        try
        {
            _oBenefitDAX = (BenefitDAX) getDAX();
            _oOtherBenefitResult = _oBenefitDAX.getOtherBenefit(oOtherBenefitPK._lBonusHdrSeqNbr);
        }
        catch (EElixirException eex)
        {
			_oLogger.fatal(getClass().getName(),"ejbLoad","EElixirException "+eex.getMessage());
            throw new EJBException(eex);
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eex)
            {
				_oLogger.fatal(getClass().getName(),"ejbLoad","EElixirException "+eex.getMessage());
                throw new EJBException(eex);
            }
        }
    }

    /**
     * A container invokes this method to instruct the instance to synchronize its state
     * by storing it to the underlying database. This method always executes in the transaction
     * context determined by the value of the transaction attribute in the deployment descriptor.
     */
    public void ejbStore()
    {
        try
        {
            if ((this._oOtherBenefitResult != null) &&
                    this._oOtherBenefitResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
            {
                _oBenefitDAX = getDAX();
                _oBenefitDAX.updateOtherBenefit(_oOtherBenefitResult);
            }
        }
        catch (EElixirException ex)
        {
			_oLogger.fatal(getClass().getName(),"ejbStore","EElixirException "+ex.getMessage());
            throw new EJBException(ex);
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eex)
            {
				_oLogger.fatal(getClass().getName(),"ejbStore","EElixirException "+eex.getMessage());
                throw new EJBException(eex);
            }
        }
    }

    /**
     * A container invokes this method before it removes the EJB object that is currently
     * associated with the instance. It is invoked when a client invokes a remove operation
     * on the enterprise Bean's home or remote interface. It transitions the instance from
     * the ready state to the pool of available instances. It is called in the transaction
     * context of the remove operation.
     * @throws javax.ejb.RemoveException
     */
    public void ejbRemove()
    {
        
    }

    /**
     * Set the associated entity context. The container invokes this method on an instance
     * after the instance has been created. This method is called in an unspecified transaction
     * context.
     * @param sc
     */
    public void setEntityContext(EntityContext ctx)
    {
        _oContext = ctx;
    }

    /**
     * Unset the associated entity context. The container calls this method before removing
     * the instance. This is the last method that the container invokes on the instance.
     * The Java garbage collector will  invoke the finalize() method on the instance. It
     * is called in an unspecified transaction context.
     */
    public void unsetEntityContext()
    {
        _oContext = null;
    }

    /**
     * Invoked by the container on the instance when the container selects the instance to
     * execute a matching client-invoked find() method. It executes in the transaction
     * context determined by the transaction attribute of the matching find() method.
     * @return BonusPK
     * @param a_BonusPK BonusPK
     * @throws javax.ejb.FinderException
     * @throws EElixirException
     */
    public OtherBenefitPK ejbFindByPrimaryKey(OtherBenefitPK a_oOtherBenefitPK)
        throws FinderException, EElixirException
    {
        try
        {	//since the tables for bonus and other benefit are the same using the bonus dax here
			_oBonusDAX = getBonusDAX();
            boolean bFlag = _oBonusDAX.findBonus(a_oOtherBenefitPK._lBonusHdrSeqNbr);
            if (bFlag)
            {
                return a_oOtherBenefitPK;
            }
            else
            {
                throw new EElixirException("P4538");
            }
        }
        catch (EElixirException eex)
        {
			_oLogger.fatal(getClass().getName(),"ejbFindByPrimaryKey","EElixirException "+eex.getMessage());
            throw new EJBException(eex);
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
				_oLogger.fatal(getClass().getName(),"ejbFindByPrimaryKey","EElixirException "+eElex.getMessage());
                throw new EElixirException(eElex, "P1005");
            }
        }
    }

    /**
     * Gets the Dax object and sets the connection on it.
     * @return BenefitDAX
     * @throws EElixirException
     */
      private BenefitDAX getDAX() throws EElixirException
      {
        _oConnection = DBConnection.getConnection();
        CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        BenefitDAX _oBenefitDAX = (BenefitDAX)theDAXFactory.createDAX(theDAXFactory.BENEFITDAX);
        _oBenefitDAX.setConnection(_oConnection);
        return _oBenefitDAX;
      }
      
	  private BonusDAX getBonusDAX() throws EElixirException
	  {
		  _oConnection = DBConnection.getConnection();
		  CHMDAXFactory oDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
		  BonusDAX _oBonusDAX = (BonusDAX) oDAXFactory.createDAX(CHMDAXFactory.BONUSDAX);
		  _oBonusDAX.setConnection(_oConnection);
		  return _oBonusDAX;
	  }

	/**
	 * Gets BonusResult
	 * @return BonusResult
	 * @throws EElixirException
	 */
    public OtherBenefitResult getOtherBenefitResult() throws EElixirException
    {
        return _oOtherBenefitResult;
    }

	/**
	 * Sets BonusResult
	 * @param a_oBonusResult BonusResult
	 * @throws EElixirException
	 */
    public void setOtherBenefitResult(OtherBenefitResult a_oOtherBenefitResult)
        throws EElixirException
    {
        this._oOtherBenefitResult = a_oOtherBenefitResult;
    }
}
