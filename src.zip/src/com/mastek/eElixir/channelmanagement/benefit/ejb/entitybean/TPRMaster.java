/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : CHANNEL MANAGEMENT
*  FILENAME			: TPRMaster.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE    : Jun 21, 2010
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*Anup_AugRel2010_FSD_TPR_V1.3_Starts
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This SegmentMaster interface provides method for retrieving data from the
 * database through primaryKey  </p>
 * @author Anup Kumar
 * @version 1.0
 */



public interface TPRMaster extends EJBObject
{
  /* This method gets the TPRResult Object
  * @return SegmentationResult
  */
  public TPRResult getTPRMasterResult() throws RemoteException, EElixirException;

  /* This method sets the TPRResult Object
  * @param a_oTPRResult ChannelResult
  */
  public void setTPRMasterResult(TPRResult a_oTPRResult) throws RemoteException, EElixirException;

}