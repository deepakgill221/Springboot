/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitPK.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : october 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean;
import java.io.Serializable;

/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the BenefitBean which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class BenefitPK implements Serializable
{

  /**
   * Constructor
   */
  public BenefitPK    ()
  {
  }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode    ()
  {
	int iHashcode=0;
    if(new Long(_lbenseqnbr)!= null)
    iHashcode= new Long(_lbenseqnbr).hashCode();
    return iHashcode;

  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * obj) method is unspecified.
   * @return boolean
   */
  public boolean equals    (java.lang.Object obj)
  {
    boolean bEqual=false;
    if(obj!=null && obj instanceof BenefitPK)
 	{
		if (this._lbenseqnbr  ==  ((BenefitPK)obj)._lbenseqnbr)
		{
		  bEqual = true;
		}
	}
    return bEqual;

  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public java.lang.String toString    ()
  {
    return null;
  }

  /**
   *  Method to access the Seq No field
   *
   */
  public long getBenSeqNbr()
  {
    return this._lbenseqnbr;
  }

  /**
   *  Method to set value of the Seq No field
   *
   */
  public void setBenSeqNbr(long a_lbenseqnbr)
  {
    this._lbenseqnbr = a_lbenseqnbr;
  }

  /**
   * Constructor
   * @param SeqNo long
   */

  public BenefitPK    (long a_lbenseqnbr)
  {
    this._lbenseqnbr = a_lbenseqnbr;
  }

  private long _lbenseqnbr;


}