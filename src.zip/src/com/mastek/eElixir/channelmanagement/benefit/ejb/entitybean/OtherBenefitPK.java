/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : MY Agent
*  FILENAME         : OtherBenefitPK.java
*  AUTHOR           : Sandeep Bangera
*  VERSION          : 1.0
*  CREATION DATE    : Jul 24, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_BONUS_DETAILS
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
* 
*
*
*--------------------------------------------------------------------------------
*
**********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean;

import java.io.Serializable;

public class OtherBenefitPK implements Serializable
{
	/**
	 * primary key variable
	 */
    public Long _lBonusHdrSeqNbr = null;

	/**
	 * default Constructor
	 */
    /*public OtherBenefitPK()
    {
    }*/

    /**
     * Constructor for BonusPK 
     */
    public OtherBenefitPK(Long a_lBonusHdrSeqNbr)
    {
        this._lBonusHdrSeqNbr = a_lBonusHdrSeqNbr;
    }

    /**
     * Referencing to object that represents the entity object.
     * @return integer value
     */
    public int hashCode()
    {
		int iHashCode = (_lBonusHdrSeqNbr == null)?0:_lBonusHdrSeqNbr.hashCode();
		return iHashCode;
    }

    /**
     * Method that compares two entity object references -- since the Java Object.equals(Object
     * obj) method is unspecified.
     * @return boolean
     */
    public boolean equals(java.lang.Object obj)
    {
		boolean bEqual = false;
		if(obj !=null && obj instanceof OtherBenefitPK)
		{
	        bEqual = (this._lBonusHdrSeqNbr.longValue() == ((OtherBenefitPK) obj)._lBonusHdrSeqNbr.longValue())
    			        ? true : false;
		}
        return bEqual;
    }

    /**
     * Own toString() method of a bean's PK class.
     * @return String
     */
    public java.lang.String toString()
    {
        return _lBonusHdrSeqNbr.toString();
    }
	/**
     * Own toString() method of a bean's PK class.
     * @return String
     */
    public Long getBonusSeqNbr()
    {
        return _lBonusHdrSeqNbr;
    }
}
