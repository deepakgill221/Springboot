/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitSLEJB.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*  1.1         30Jan             Pallav                Added delete functionality
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.sessionbean;


import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.benefit.dax.BenefitDAX;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.Benefit;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.BenefitHome;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.BenefitPK;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.OtherBenefit;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.OtherBenefitHome;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.OtherBenefitPK;
import com.mastek.eElixir.channelmanagement.benefit.util.BenefitResult;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitAgentDetail;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.channelmanagement.process.action.ProcessDAX;
import com.mastek.eElixir.channelmanagement.process.util.ProcessResult;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.TPRMaster;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.TPRMasterHome;
import com.mastek.eElixir.channelmanagement.benefit.ejb.entitybean.TPRMasterPK;
import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.dax.BonusDAX;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.entitybean.BonusHome;

import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

/**
 * <p>Title: eElixir</p>
 * <p>Description: This BenefitSLEJB session bean acts as an interface for the Benefit Entity bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class BenefitSLEJB implements SessionBean
{

  /**
   * 
   * Constructor of the BenefitSLEJB class
   */
  public BenefitSLEJB    ()
  {

  }

  /**
   * Called by the container to create a session bean instance. Its parameters typically
   * contain the information the client uses to customize the bean instance for its use.
   * It requires a matching pair in the bean class and its home interface.
   * @throws EElixirException
   * @throws CreateException
   */
  public void ejbCreate    () throws CreateException,  EElixirException
  {

  }

  /**
   * A container invokes this method before it ends the life of the session object. This
   * happens as a result of a client's invoking a remove operation, or when a container
   * decides to terminate the session object after a timeout. This method is called with
   * no transaction context.
   */
  public void ejbRemove    ()
  {

  }

  /**
   * The activate method is called when the instance is activated from its 'passive' state.
   * The instance should acquire any resource that it has released earlier in the ejbPassivate()
   * method. This method is called with no transaction context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * The passivate method is called before the instance enters the 'passive' state. The
   * instance should release any resources that it can re-acquire later in the ejbActivate()
   * method. After the passivate method completes, the instance must be in a state that
   * allows the container to use the Java Serialization protocol to externalize and store
   * away the instance's state. This method is called with no transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * Set the associated session context. The container calls this method after the instance
   * creation. The enterprise Bean instance should store the reference to the context
   * object in an instance variable. This method is called with no transaction context.
   * @param sc SessionContext
   */

  public void setSessionContext    (SessionContext sc)
  {
    this._EJBContext = sc;
  }



  /**
   * Gets the data based on the parameter of DVO
   * @param a_oResultObject Object
   * @return String XML format string object
   * @throws EElixirException
   * @throws FinderException
   */
  public String searchBenefit(Object a_oResultObject) throws  FinderException, EElixirException
  {
    try{
      _oBenefitDAX = (BenefitDAX)getDAX();
      log.debug("BenefitSLEJB--before getBenefit method of dax object");
      _strCon = _oBenefitDAX.getBenefit(a_oResultObject);
      log.debug("BenefitSLEJB--after getBenefit method of dax object");
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      Exception e= ejbex.getCausedByException();
      if (e instanceof EElixirException)
      {
        throw (EElixirException)e;
      }
      else
      {
        throw ejbex;
      }
    }
    catch(EElixirException eLex)
    {
      _EJBContext.setRollbackOnly();
      throw eLex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
    log.debug(_strCon);
    return _strCon;
  }

  /**
   * Gets the Data depending on the Seq No
   * @param a_lbenseqnbr long
   * @return BenefitResult
   * @throws FinderException
   * @throws EElixirException
   */
  public BenefitResult searchBenefit(long a_lbenseqnbr) throws FinderException,EElixirException{
    BenefitResult oBenefitResult = null;
    try
    {
      /*
      EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      log.debug("BenefitSLEJB--Before Lookup");
      _oBenefitHome = (BenefitHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("BenefitHome"),BenefitHome.class);
      log.debug("BenefitSLEJB--Home LookUP _oBenefitHome:" + _oBenefitHome);
      */
       _oBenefitHome = getBenefitHome();
       BenefitPK _oBenefitPK = new BenefitPK();
      _oBenefitPK.setBenSeqNbr(a_lbenseqnbr);
      _oBenefit = _oBenefitHome.findByPrimaryKey(_oBenefitPK);
      log.debug("BenefitSLEJB--Getting Result from Benefit Bean");
      oBenefitResult =  _oBenefit.getBenefitResult();
      log.debug("BenefitSLEJB--Result Obtained"+ oBenefitResult);
    }
    catch(FinderException fe)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--FinderException " + fe);
      throw new EElixirException(fe,"P9002");
    }
    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--RemoteEXception " + rex);
      throw new EElixirException(rex, "P1006");
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--EJBException " + ejbex);
      throw (EElixirException)ejbex.getCausedByException();
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--EElixirException " + eex);
      throw eex;
    }
    return oBenefitResult;
  }



//--------------------------------Himanshu:code for Valid values in ACS
	
	 public String searchvalidValue() throws RemoteException, EJBException, EElixirException,FinderException
	 {
		
		 try
		 {
			 String strValidVal = "";
			 log.debug("Himanshu: After Try searchvalidValue for BenefitSLEJB()");  
			//  _oBenefitHome = getBenefitHome();
		
			 
			 log.debug("Himanshu: After Try searchvalidValue or BenefitSLEJB()");    	
			  BenefitDAX oBenefitDAX = getDAX();
		
			 strValidVal= oBenefitDAX.getDRCRcodeDetails();
			 log.debug("Himanshu: After Try searchvalidValue()" +strValidVal );    
			 return strValidVal;
			 
		 }
		 catch (EJBException eex)
		   {
			   log.fatal(getClass().getName(),"searchvalidValue","EJBException "+eex.getMessage());
			   throw eex;
	 }
	 }

	//----------------------------------Code Ends here
  /**
   * Updates data into Benefit
   * @param a_oBenefitResult BenefitResult
   * @throws FinderException
   * @throws EElixirException
   */
  public void updateBenefit(BenefitResult a_oBenefitResult) throws FinderException,EElixirException{
    BenefitResult oBenefitResult = null;
    try
    {
      /*
      EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      log.debug("BenefitSLEJB--Before Lookup");
      _oBenefitHome = (BenefitHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("BenefitHome"),BenefitHome.class);
      log.debug("BenefitSLEJB--Home LookUP _oBenefitHome:" + _oBenefitHome);
      */
      _oBenefitHome = getBenefitHome();
       BenefitPK _oBenefitPK = new BenefitPK();
      _oBenefitPK.setBenSeqNbr(a_oBenefitResult.getBenSeqNbr().longValue());
      _oBenefit = _oBenefitHome.findByPrimaryKey(_oBenefitPK);
      BenefitResult con_BenefitResult = _oBenefit.getBenefitResult();
      if (con_BenefitResult.getTsDtUpdated() != null && (!con_BenefitResult.getTsDtUpdated().equals(a_oBenefitResult.getTsDtUpdated())))
      {
        log.debug("concurrency failed thorwing exception");
        throw new EElixirException("P1100");
      }
      log.debug("BenefitSLEJB--Updating call to  Benefit Bean");
      _oBenefit.setBenefitResult(a_oBenefitResult);
      log.debug("BenefitSLEJB--Result Obtained"+ oBenefitResult);
    }
    catch(FinderException fe)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--FinderException " + fe);
      throw new EElixirException(fe,"P9002");
    }
    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--RemoteEXception " + rex);
      throw new EElixirException(rex, "P1006");
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--EJBException " + ejbex);
      throw (EElixirException)ejbex.getCausedByException();
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--EElixirException " + eex);
      throw eex;
    }
  }



  /**
   * Creates the Data from the CHMSLEJB
   * @param a_oBenefitResult BenefitResult
   * @return long
   * @throws EJBException
   * @throws EElixirException
   */
  public long createBenefit(BenefitResult a_oBenefitResult) throws  EJBException, EElixirException
  {
    BenefitResult benefitResult = null;
    log.debug("BenefitSLEJB--In create Benefit of BenefitSLEJB");
    long lbenseqnbr = 0;
    try
    {
      //EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      //CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      //log.debug("BenefitSLEJB--Before Lookup of entity bean");
      //_oBenefitHome = (BenefitHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("BenefitHome"),BenefitHome.class);
      //log.debug("BenefitSLEJB--After Lookup");
      _oBenefitHome = getBenefitHome();
      _oBenefit = _oBenefitHome.create(a_oBenefitResult);
      lbenseqnbr = ((BenefitPK)_oBenefit.getPrimaryKey()).getBenSeqNbr();
      log.debug("BenefitSLEJB--Key is " + lbenseqnbr);
    }
    catch (CreateException cex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(cex, "P9007");
    }
    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(rex, "P1006");
    }
    //catch (FinderException fex)
    //{
     // _EJBContext.setRollbackOnly();
     // throw new EElixirException(fex, "P3024");
    //}
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw (EElixirException)ejbex.getCausedByException();
      //throw new EElixirException(ejbex, "P3025");
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--Inside catch of Eelixir exception in createBenefit of BenefitSLEJB");
      throw eex;
    }
     //return BenefitResult;
    return lbenseqnbr;
  }


  /**
  * Invoked by	the	session	bean to	look up	the	Benefit EJB. for Deleting a Benefit
  * @param  a_oBenefitResult BenefitResult
  * @throws RemoveException
  * @throws EElixirException
  * @throws EJBException
  */
 public void deleteBenefit(BenefitResult a_oBenefitResult) throws RemoveException, EJBException, EElixirException
 {
       try
       {
         _oBenefitHome = getBenefitHome();
         BenefitPK oBenefitPK = new BenefitPK();
         log.debug("BenefitSLEJB--Inside Delete1 ");
         oBenefitPK.setBenSeqNbr(a_oBenefitResult.getBenSeqNbr().longValue());
         log.debug("BenefitSLEJB--Inside Delete2 ");
         Benefit  oBenefit	= _oBenefitHome.findByPrimaryKey(oBenefitPK);
         log.debug("BenefitSLEJB--Inside Delete3 ");
         oBenefit.remove();
         log.debug("BenefitSLEJB--Inside Delete4");
       }
       catch(FinderException fex)
       {
         _EJBContext.setRollbackOnly();
         throw	new	EElixirException(fex, "P9002");
       }
       catch (RemoveException rex)
       {
         _EJBContext.setRollbackOnly();
         throw	new	EElixirException(rex, "P9022");
       }
       catch (RemoteException rex)
       {
         _EJBContext.setRollbackOnly();
         throw	new	EElixirException(rex, "P1006");
       }
       catch(EJBException ejbex){
         _EJBContext.setRollbackOnly();
         throw	(EElixirException)ejbex.getCausedByException();
       }
       catch(EElixirException eLex)
       {
         _EJBContext.setRollbackOnly();
         throw	eLex;
       }
 }

	 /**
	  * Gets the data based on the parameter of DVO
	  * @param a_oResultObject Object
	  * @return String XML format string object
	  * @throws EElixirException
	  * @throws FinderException
	  */
   public String searchOtherBenefit(SearchData a_oSearchData) throws  FinderException, EElixirException
	 {
	   try{
	     _oBenefitDAX = (BenefitDAX)getDAX();
	     log.debug("BenefitSLEJB--before getBenefit method of dax object");
	     _strCon = _oBenefitDAX.getOtherBenefit(a_oSearchData);
	     log.debug("BenefitSLEJB--after getBenefit method of dax object");
	     //DBConnection.closeConnection(_oConnection);
	   }
	   catch(EJBException ejbex){
	     _EJBContext.setRollbackOnly();
	     Exception e= ejbex.getCausedByException();
	     if (e instanceof EElixirException)
	     {
	       throw (EElixirException)e;
	     }
	     else
	     {
	       throw ejbex;
	     }
	   }
	   catch(EElixirException eLex)
	   {
	     _EJBContext.setRollbackOnly();
	     throw eLex;
	   }
	   finally{
	     try{
	       if(_oConnection != null)
	         DBConnection.closeConnection(_oConnection);
	     }
	     catch(EElixirException eElex){
	       throw new EElixirException(eElex,"P1005");
	     }
	   }
	   return _strCon;
	 }

   
   public long createOtherBenefit(OtherBenefitResult a_oOtherBenefitResult) throws  EJBException, EElixirException
   {
     log.debug("BenefitSLEJB--In create Benefit of BenefitSLEJB");
     long lbenseqnbr = 0;
     try
     {
    	 
       //BenefitDAX oBenefitDAX = getDAX();

       _oOtherBenefitHome = getOtherBenefitHome();
       _oOtherBenefit = _oOtherBenefitHome.create(a_oOtherBenefitResult);
       lbenseqnbr = ((OtherBenefitPK)_oOtherBenefit.getPrimaryKey()).getBonusSeqNbr().longValue();
       log.debug("BenefitSLEJB--Key is " + lbenseqnbr);
     }
     catch (CreateException cex)
     {
       _EJBContext.setRollbackOnly();
       throw new EElixirException(cex, "P9007");
     }
     catch (RemoteException rex)
     {
       _EJBContext.setRollbackOnly();
       throw new EElixirException(rex, "P1006");
     }
     catch(EJBException ejbex){
       _EJBContext.setRollbackOnly();
       throw (EElixirException)ejbex.getCausedByException();
     }
     finally{
	     try{
	       if(_oConnection != null)
	         DBConnection.closeConnection(_oConnection);
	     }
	     catch(EElixirException eElex){
	       throw new EElixirException(eElex,"P1005");
	     }
     }
     
     return lbenseqnbr;
   }
   
   public void deleteOtherBenefit(Long lBonusHdrSeqNbr) throws FinderException,EElixirException
   {
       try
       {
         _oOtherBenefitHome = getOtherBenefitHome();
         OtherBenefitPK _oOtherBenefitPK = new OtherBenefitPK(lBonusHdrSeqNbr);
         _oOtherBenefit = _oOtherBenefitHome.findByPrimaryKey(_oOtherBenefitPK);
         BenefitDAX oBenefitDAX = getDAX();
         oBenefitDAX.removeOtherBenefit(lBonusHdrSeqNbr);
       }
       catch (RemoteException rex)
       {
         _EJBContext.setRollbackOnly();
         throw new EElixirException(rex, "P1006");
       }
       catch(EJBException ejbex){
         _EJBContext.setRollbackOnly();
         throw (EElixirException)ejbex.getCausedByException();
       }
       catch(EElixirException eex)
       {
         _EJBContext.setRollbackOnly();
         log.debug("BenefitSLEJB--Inside catch of Eelixir exception in createBenefit of BenefitSLEJB");
         throw eex;
       }
       finally{
  	     try{
  	       if(_oConnection != null)
  	         DBConnection.closeConnection(_oConnection);
  	     }
  	     catch(EElixirException eElex){
  	       throw new EElixirException(eElex,"P1005");
  	     }
       }
   }
   public void updateOtherBenefit(OtherBenefitResult a_oOtherBenefitResult) throws FinderException,EElixirException{
       BenefitResult oBenefitResult = null;
       try
       {
     
    	   BenefitDAX oBenefitDAX = getDAX();
    	 
         _oOtherBenefitHome = getOtherBenefitHome();
          OtherBenefitPK _oOtherBenefitPK = new OtherBenefitPK(a_oOtherBenefitResult.getBonusHdrSeqNbr());
         _oOtherBenefit = _oOtherBenefitHome.findByPrimaryKey(_oOtherBenefitPK);
         /*BenefitResult con_BenefitResult = _oOtherBenefit.getOtherBenefitResult();
         if (con_BenefitResult.getTsDtUpdated() != null && (!con_BenefitResult.getTsDtUpdated().equals(a_oBenefitResult.getTsDtUpdated())))
         {
           log.debug("concurrency failed thorwing exception");
           throw new EElixirException("P1100");
         }*/
         log.debug("BenefitSLEJB--Updating call to  OtherBenefit Bean");
         _oOtherBenefit.setOtherBenefitResult(a_oOtherBenefitResult);
         log.debug("BenefitSLEJB--Result Obtained"+ oBenefitResult);
       }
       catch(FinderException fe)
       {
         _EJBContext.setRollbackOnly();
         log.debug("BenefitSLEJB--FinderException " + fe);
         throw new EElixirException(fe,"P9002");
       }
       catch (RemoteException rex)
       {
         _EJBContext.setRollbackOnly();
         log.debug("BenefitSLEJB--RemoteEXception " + rex);
         throw new EElixirException(rex, "P1006");
       }
       catch(EJBException ejbex){
         _EJBContext.setRollbackOnly();
         log.debug("BenefitSLEJB--EJBException " + ejbex);
         throw (EElixirException)ejbex.getCausedByException();
       }
       catch(EElixirException eex)
       {
    	   log.debug("BenefitSLEJB-EElixirException-Uniquesequence");
         _EJBContext.setRollbackOnly();
         log.debug("BenefitSLEJB--EElixirException " + eex);
         throw eex;
       }
       finally{
    	     try{
    	       if(_oConnection != null)
    	         DBConnection.closeConnection(_oConnection);
    	     }
    	     catch(EElixirException eElex){
    	       throw new EElixirException(eElex,"P1005");
    	     }
       }
     }

   public OtherBenefitResult searchOtherBenefit(long a_lBonusHdrSeqNbr) throws FinderException,EElixirException{
	OtherBenefitResult oOtherBenefitResult = null;
    try
    {
       _oOtherBenefitHome = getOtherBenefitHome();
       OtherBenefitPK _oOtherBenefitPK = new OtherBenefitPK(new Long(a_lBonusHdrSeqNbr));
	   _oOtherBenefit = _oOtherBenefitHome.findByPrimaryKey(_oOtherBenefitPK);
      log.debug("BenefitSLEJB--Getting Result from Benefit Bean");
      oOtherBenefitResult = _oOtherBenefit.getOtherBenefitResult();
      log.debug("BenefitSLEJB--Result Obtained"+ oOtherBenefitResult);
    }
    catch(FinderException fe)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--FinderException " + fe);
      throw new EElixirException(fe,"P9002");
    }
    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--RemoteEXception " + rex);
      throw new EElixirException(rex, "P1006");
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--EJBException " + ejbex);
      throw (EElixirException)ejbex.getCausedByException();
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("BenefitSLEJB--EElixirException " + eex);
      throw eex;
    }
    return oOtherBenefitResult;
  }

   
   public void updateAgentTargetDetails(ArrayList alAgentDetails,Long lBonusHdrSeqNbr) throws RemoteException,EElixirException
   {
       try
       {
  	     _oBenefitDAX = (BenefitDAX)getDAX();
  	     OtherBenefitAgentDetail oOtherBenefitAgentDetail = null;
  	     if(alAgentDetails != null)
  	     {
  	        for(int i=0;i<alAgentDetails.size();i++)
  	        {
  	           oOtherBenefitAgentDetail = (OtherBenefitAgentDetail)alAgentDetails.get(i);
  	           if(!oOtherBenefitAgentDetail.getStatusFlag().equals(DataConstants.DELETE_MODE))
  	           {
  	               _oBenefitDAX.checkAgentDesignation(oOtherBenefitAgentDetail.getAgentCd(),lBonusHdrSeqNbr);
  	           }
  	        }
  	      _oBenefitDAX.updateAgentTargetDetails(alAgentDetails,lBonusHdrSeqNbr); 
  	     }
  	   }
  	   catch(EJBException ejbex){
  	     _EJBContext.setRollbackOnly();
  	     Exception e= ejbex.getCausedByException();
  	     if (e instanceof EElixirException)
  	     {
  	       throw (EElixirException)e;
  	     }
  	     else
  	     {
  	       throw ejbex;
  	     }
  	   }
  	   catch(EElixirException eLex)
  	   {
  	     _EJBContext.setRollbackOnly();
  	     throw eLex;
  	   }
  	   finally{
  	     try{
  	       if(_oConnection != null)
  	         DBConnection.closeConnection(_oConnection);
  	     }
  	     catch(EElixirException eElex){
  	       throw new EElixirException(eElex,"P1005");
  	     }
  	   }
   }
   public void deleteCriteriaParameters(Long lBonusHdrSeqNbr) throws FinderException,EElixirException
   {
       try
       {
           _oBenefitDAX = (BenefitDAX)getDAX();
           _oBenefitDAX.deleteCriteriaParameters(lBonusHdrSeqNbr);
       }
       catch(EJBException ejbex)
       {
           _EJBContext.setRollbackOnly();
           Exception e= ejbex.getCausedByException();
           if (e instanceof EElixirException)
           {
               throw (EElixirException)e;
           }
           else
           {
               throw ejbex;
           }	
       }
       catch(EElixirException eLex)
       {
           _EJBContext.setRollbackOnly();
           throw eLex;
       }
       finally
       {
           try
           {
               if(_oConnection != null)
                   DBConnection.closeConnection(_oConnection);
           }
           catch(EElixirException eElex)
           {
    	       throw new EElixirException(eElex,"P1005");
           }
       }
   }
   
   public ArrayList searchOtherBenefitAgentDetails (long lBonusHdrSeqNbr)throws RemoteException,EElixirException
   {
       ArrayList alAgentDetails = null;
       try
       {
           _oBenefitDAX = (BenefitDAX)getDAX();
           alAgentDetails = _oBenefitDAX.getOtherBenefitAgentDetails(lBonusHdrSeqNbr);
           return alAgentDetails; 
       }
       catch(EJBException ejbex)
       {
           _EJBContext.setRollbackOnly();
           Exception e= ejbex.getCausedByException();
           if (e instanceof EElixirException)
           {
               throw (EElixirException)e;
           }
           else
           {
               throw ejbex;
           }	
       }
       catch(EElixirException eLex)
       {
           _EJBContext.setRollbackOnly();
           throw eLex;
       }
       finally
       {
           try
           {
               if(_oConnection != null)
                   DBConnection.closeConnection(_oConnection);
           }
           catch(EElixirException eElex)
           {
    	       throw new EElixirException(eElex,"P1005");
           }
       }
   }

  /**
   * Gets the Dax object and sets the connection on it.
   * @return BenefitDAX
   * @throws EElixirException
   */
    private BenefitDAX getDAX() throws EElixirException
    {
      _oConnection = DBConnection.getConnection();
      CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
      BenefitDAX _oBenefitDAX = (BenefitDAX)theDAXFactory.createDAX(theDAXFactory.BENEFITDAX);
      _oBenefitDAX.setConnection(_oConnection);

      return _oBenefitDAX;
    }

    /**
     * Gets the Home object.
     * @return BenefitHome
     * @throws EElixirException
     */
    private BenefitHome getBenefitHome() throws EElixirException
    {
      EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      log.debug("BenefitSLEJB--Before Lookup");
      BenefitHome oBenefitHome = (BenefitHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("BenefitHome"),BenefitHome.class);
      log.debug("BenefitSLEJB--Home LookUP _oBenefitHome:" + oBenefitHome);
      return oBenefitHome;
    }

    private OtherBenefitHome getOtherBenefitHome() throws EElixirException
    {
      EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      log.debug("BenefitSLEJB--Before Lookup");
      OtherBenefitHome oOtherBenefitHome = (OtherBenefitHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("OtherBenefitHome"),OtherBenefitHome.class);
      log.debug("BenefitSLEJB--Home LookUP _oOtherBenefitHome:" + oOtherBenefitHome);
      return oOtherBenefitHome;
    }
    
    //<!--ANUP_DST_Incentive_April_REL_Start-->	
    public ArrayList searchPersReduction (long lBonusHdrSeqNbr)throws RemoteException,EElixirException
    {
        ArrayList alDSTDetails = null;
        try
        {
            _oBenefitDAX = (BenefitDAX)getDAX();
            alDSTDetails = _oBenefitDAX.getPersistReductSearch(lBonusHdrSeqNbr);
            return alDSTDetails; 
        }
        catch(EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            Exception e= ejbex.getCausedByException();
            if (e instanceof EElixirException)
            {
                throw (EElixirException)e;
            }
            else
            {
                throw ejbex;
            }	
        }
        catch(EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }
        finally
        {
            try
            {
                if(_oConnection != null)
                    DBConnection.closeConnection(_oConnection);
            }
            catch(EElixirException eElex)
            {
     	       throw new EElixirException(eElex,"P1005");
            }
        }
    }
    
    
    public void updatePerReductionDetails(ArrayList alDSTDetails,Long lBonusHdrSeqNbr) throws RemoteException,EElixirException
    {
        try
        {
   	     _oBenefitDAX = (BenefitDAX)getDAX();
   	     OtherBenefitAgentDetail oOtherBenefitAgentDetail = null;
   	     if(alDSTDetails != null)
   	     {  	        
   	      _oBenefitDAX.updatePerReductionDetails(alDSTDetails,lBonusHdrSeqNbr); 
   	     }
   	   }
   	   catch(EJBException ejbex){
   	     _EJBContext.setRollbackOnly();
   	     Exception e= ejbex.getCausedByException();
   	     if (e instanceof EElixirException)
   	     {
   	       throw (EElixirException)e;
   	     }
   	     else
   	     {
   	       throw ejbex;
   	     }
   	   }
   	   catch(EElixirException eLex)
   	   {
   	     _EJBContext.setRollbackOnly();
   	     throw eLex;
   	   }
   	   finally{
   	     try{
   	       if(_oConnection != null)
   	         DBConnection.closeConnection(_oConnection);
   	     }
   	     catch(EElixirException eElex){
   	       throw new EElixirException(eElex,"P1005");
   	     }
   	   }
    }
    //<!--ANUP_DST_Incentive_April_REL_Ends-->	
    //<!--ANUP_Session_Listner_Implementation_Start-->	
    public ProcessResult callProceduresMyAgent (HashMap hmParam)throws RemoteException,EElixirException
    {
    	ProcessResult oProcessResult = null;
        try
        {
        	ProcessDAX pdax = new ProcessDAX();
            oProcessResult =  pdax.callProcedures(hmParam);
            return oProcessResult; 
        }
        catch(EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            Exception e= ejbex.getCausedByException();
            if (e instanceof EElixirException)
            {
                throw (EElixirException)e;
            }
            else
            {
                throw ejbex;
            }	
        }
        catch(EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }
        finally
        {
            try
            {
                if(_oConnection != null)
                    DBConnection.closeConnection(_oConnection);
            }
            catch(EElixirException eElex)
            {
     	       throw new EElixirException(eElex,"P1005");
            }
        }
    }
//  <!--ANUP_Session_Listner_Implementation_Ends-->
  //Anup_AugRel2010_FSD_TPR_V1.3_Starts
	public ArrayList searchChannelTPRTypes(String a_cChannelType) throws FinderException, EElixirException
    {
		String a_strMethodName ="searchChannelTPRTypes";	
    	try{
    		
    	 _oBenefitDAX = getDAX();     	
 
    	 return _oBenefitDAX.searchChannelTPRTypes(a_cChannelType);
    	}catch(EElixirException eex)
    	{
    		throw eex;
    	}
    	finally
		{
			try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{				
				throw new EElixirException(eElex, "P1005");
			}
		}
        	
    }
	
	
	public TPRResult searchTPRMasterData(long a_lTPRHDRSeqNbr)
		throws FinderException, EElixirException, RemoteException
	{
		log.entry(a_strClassName, "searchTPRMasterData", "starts");
		TPRResult oTPRResult = null;
		try{
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			
			log.debug("TPRMasterHome--Before Lookup");
			_oTPRMasterHome = (TPRMasterHome)objEJBHomeFactory.lookUpHome(
					oCHMPropertyUtil.getCHMProperty("TPRMasterHome"),TPRMasterHome.class);			
			TPRMasterPK _oTPRMasterPK = new TPRMasterPK();
			_oTPRMasterPK.setTPRHDRSeqNbr(a_lTPRHDRSeqNbr);		  
			_oTPRMaster = _oTPRMasterHome.findByPrimaryKey(_oTPRMasterPK);
			oTPRResult =  _oTPRMaster.getTPRMasterResult();
			  
		return oTPRResult;
	}
	catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
	Exception e= ejbex.getCausedByException();
	if (e instanceof EElixirException)
	{
	  throw (EElixirException)e;
	}
	else
	{
	  throw ejbex;
	}
	}
	catch(EElixirException eLex)
	{
		_EJBContext.setRollbackOnly();
	throw eLex;
	}
	finally{
	try{
	  if(_oConnection != null)
		DBConnection.closeConnection(_oConnection);
	}
	catch(EElixirException eElex){
	  throw new EElixirException(eElex,"P1005");
	}
	}
}
	


public void createTPRMaster(ArrayList a_alTPRList) throws FinderException, EElixirException
{
	TPRResult oTPRResult = null;
	boolean bFlag=false;
    try
    {
    	TPRMasterPK oTPRMasterPK=null;
    	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();       
        _oTPRMasterHome = (TPRMasterHome)objEJBHomeFactory.lookUpHome(
				oCHMPropertyUtil.getCHMProperty("TPRMasterHome"),TPRMasterHome.class);
          String strStatus = null;
        if (a_alTPRList != null)
        {
        	int iSize = a_alTPRList.size();
            for (int i = 0; i < iSize; i++)
            {                	
            	oTPRResult = (TPRResult) a_alTPRList.get(i);
            	strStatus=oTPRResult.getStatusFlag();
            	      	
			   	 if(strStatus.trim().equals(DataConstants.INSERT_MODE))
                 {              		 
			   		_oBenefitDAX = (BenefitDAX)getDAX();                		
			   		_oTPRMasterHome.create(oTPRResult);
                 }
            	 else if (strStatus.trim().equals(DataConstants.UPDATE_MODE))
                 {               		
            		 oTPRMasterPK = new TPRMasterPK(oTPRResult.getTPRHdrSeqNbr().longValue());
            		 _oTPRMaster = _oTPRMasterHome.findByPrimaryKey(oTPRMasterPK);
                    TPRResult oConTPRResult = _oTPRMaster.getTPRMasterResult();
                                 
                   /* if ((oConTPRResult.getTsDtUpdated() != null) &&
                             (!oConTPRResult.getTsDtUpdated().equals(oTPRResult.getTsDtUpdated())))
                     {
                         log.fatal(
                             "concurrency failed throwing exception");
                         throw new EElixirException("P1100");
                     }
                    */

                     _oTPRMaster.setTPRMasterResult(oTPRResult);
                 }
            	 else if (strStatus.trim().equals(DataConstants.DELETE_MODE))
                 {
            		 _oBenefitDAX = (BenefitDAX)getDAX();
            		 _oBenefitDAX.deleteTPRMaster(oTPRResult);
                 }
            	 
            }
        }
    }
    catch (CreateException cex)
    {
        log.fatal(getClass().getName(), "createTPRMaster ",
            "CreateException " + cex.getMessage());
        _EJBContext.setRollbackOnly();
        throw new EElixirException(cex, "aug10e1");
    }
    catch (RemoteException rex)
    {
        log.fatal(getClass().getName(), "createTPRMaster ",
            "RemoteException " + rex.getMessage());
        _EJBContext.setRollbackOnly();
        throw new EElixirException(rex, "P1006");
    }
    catch (FinderException fex)
    {
        log.fatal(getClass().getName(), "createTPRMaster ",
            "FinderException " + fex.getMessage());
        _EJBContext.setRollbackOnly();
        throw new EElixirException(fex, "aug10e2");
    }
    catch (EJBException ejbex)
    {
        log.fatal(getClass().getName(), "createTPRMaster ",
            "EJBException " + ejbex.getMessage());
        _EJBContext.setRollbackOnly();
        throw (EElixirException) ejbex.getCausedByException();
    }
    catch (EElixirException eex)
    {
        log.fatal(getClass().getName(), "createTPRMaster ",
            "EElixirException " + eex.getMessage());
        _EJBContext.setRollbackOnly();
        throw eex;
    }
    finally
	{
		try
		{
			if (_oConnection != null)
			{
				DBConnection.closeConnection(_oConnection);
			}
		}
		catch (EElixirException eElex)
		{
			log.fatal(getClass().getName(), "createTPRMaster",
				"EElixirException " + eElex.getMessage());
			throw new EElixirException(eElex, "P1005");
		}
	}
    
}

public void updateTPRMaster(TPRResult a_TPRResult)
throws RemoteException, EElixirException
{
	log.entry("BenefitSLEJB","updateTPRMaster","starts");
	try
	{	
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();		
		log.debug("TPRMasterHome--Before Lookup");
		_oTPRMasterHome = (TPRMasterHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("TPRMasterHome"),TPRMasterHome.class);		
		log.debug("a_TPRResult.getTPRHdrSeqNbr()-->"+a_TPRResult.getTPRHdrSeqNbr());		
		TPRMasterPK _oTPRMasterPK = new TPRMasterPK(a_TPRResult.getTPRHdrSeqNbr().longValue());			  
	    _oTPRMaster = _oTPRMasterHome.findByPrimaryKey(_oTPRMasterPK);
	    _oTPRMaster.setTPRMasterResult(a_TPRResult);		
		log.exit("BenefitSLEJB","updateTPRMaster","exit");
	} 
	catch (FinderException cex)
	{
		_EJBContext.setRollbackOnly();
	  throw new EElixirException(cex, "aug10e4");
	}
	catch (RemoteException rex)
	{
		_EJBContext.setRollbackOnly();
	  throw new EElixirException(rex, "P1006");
	}
	catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
	Exception e= ejbex.getCausedByException();
	if (e instanceof EElixirException)
	{
	  throw (EElixirException)e;
	}
	else
	{
	  throw ejbex;
	}
	}
	catch(EElixirException eLex)
	{
		_EJBContext.setRollbackOnly();
	throw eLex;
	}
	finally{
	try{
	  if(_oConnection != null)
		DBConnection.closeConnection(_oConnection);
	}
	catch(EElixirException eElex){
	  throw new EElixirException(eElex,"P1005");
	}
	}
}
	
	
	
//Anup_AugRel2010_FSD_TPR_V1.3_Ends

/**
 * Attributes declaration
 */
  private Connection       _oConnection = null;
  private BenefitDAX      _oBenefitDAX;
  private String           _strCon;
  public SessionContext    _EJBContext = null;
  public BenefitHome      _oBenefitHome;
  private Benefit         _oBenefit;

  public OtherBenefitHome _oOtherBenefitHome;
  private OtherBenefit _oOtherBenefit;
  private String a_strClassName = "BenefitSLEJB";
  private TPRMaster _oTPRMaster = null;
  private TPRMasterHome _oTPRMasterHome = null;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}