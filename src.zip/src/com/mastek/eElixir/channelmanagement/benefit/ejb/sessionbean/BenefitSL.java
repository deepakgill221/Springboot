/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitSL.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*  1.1         30Jan             Pallav                Added delete functionality
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.benefit.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;

import com.mastek.eElixir.channelmanagement.benefit.util.BenefitResult;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.channelmanagement.process.util.ProcessResult;
import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.SearchData;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This BenefitSL Local interface provides method for getting the data from Benefit bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface BenefitSL extends EJBObject
{
  /**
   * Gets the data based on the parameter of DVO
   * @param a_oResultObject Object
   * @return String XML format string object
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public String searchBenefit(Object a_oResultObject) throws EElixirException , FinderException , RemoteException;

  /**
   * Gets the Data depending on the Seq No
   * @param lbenseqnbr long
   * @return BenefitResult
   * @throws FinderException
   * @throws EElixirException
   * @throws RemoteException
   */
  public BenefitResult searchBenefit(long lbenseqnbr) throws FinderException,EElixirException, RemoteException;
  /**
   * Creates the Data from the CHMSLEJB
   * @param a_oBenefitResult BenefitResult
   * @return long
   * @throws EJBException
   * @throws EElixirException
   * @throws RemoteException
   */
  public long createBenefit(BenefitResult a_oBenefitResult) throws  EJBException, EElixirException, RemoteException;
  /**
   * Updates data into Benefit
   * @param a_oBenefitResult BenefitResult
   * @throws FinderException
   * @throws EElixirException
   * @throws RemoteException
   */
  public void updateBenefit(BenefitResult a_oBenefitResult) throws FinderException,EElixirException, RemoteException;

  /**
   * Deletes the Data from the CHMSLEJB
   * @param a_oBenefitResult BenefitResult
   * @throws EJBException
   * @throws EElixirException
   * @throws RemoteException
   * @throws RemoveException
   */
  public void deleteBenefit(BenefitResult a_oBenefitResult) throws  RemoveException, EJBException, EElixirException, RemoteException;

  
  /**
   * Gets the data based on the parameter of DVO
   * @param a_oResultObject Object
   * @return String XML format string object
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public String searchOtherBenefit(SearchData a_oSearchData) throws EElixirException , FinderException , RemoteException;
  
  /**
   * Creates the Data from the CHMSLEJB
   * @param a_oOtherBenefitResult OtherBenefitResult
   * @return long
   * @throws EJBException
   * @throws EElixirException
   * @throws RemoteException
   */
  public long createOtherBenefit(OtherBenefitResult a_oOtherBenefitResult) throws  EJBException, EElixirException, RemoteException;

 /**
   * Gets the data based on primary key of the chm_bonus_hdr table
   * @param lBonusHdrSeqNbr long
   * @return OtherBenefitResult
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public OtherBenefitResult searchOtherBenefit(long lBonusHdrSeqNbr) throws EElixirException , FinderException , RemoteException;

  /**
   * updates the other benefit Record 
   * @param OtherBenefitResult 
   * @return void
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public void updateOtherBenefit(OtherBenefitResult a_oOtherBenefitResult) throws RemoteException,FinderException,EElixirException;
  
  /**
   * updates the other benefit Agent Target Details 
   * @param OtherBenefitResult 
   * @return void
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public void updateAgentTargetDetails(ArrayList alAgentDetails,Long lBonusHdrSeqNbr) throws RemoteException,EElixirException;
  
  /**
   * Gets the Agent Target Details for Other Benefit Definition  
   * @param LbonusHdrSeqNbr 
   * @return ArrayList
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public ArrayList searchOtherBenefitAgentDetails (long lBonusHdrSeqNbr)throws RemoteException,EElixirException;
  
  /**
   * Deletes the  Other Benefit Records
   * @param OtherBenefitResult 
   * @return void
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public void deleteOtherBenefit(Long lBonusHdrSeqNbr) throws RemoteException,FinderException,EElixirException;
  
  /**
   * Deletes the  Criteria Parameters
   * @param Long
   * @return void
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public void deleteCriteriaParameters(Long lBonusHdrSeqNbr) throws RemoteException,FinderException,EElixirException;
  //ANUP_DST_Incentive_April_REL_Start
  /**
   * Gets the CHM_PERST_REDUCTION Details for Other Benefit Definition  
   * @param LbonusHdrSeqNbr 
   * @return ArrayList
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public ArrayList searchPersReduction (long lBonusHdrSeqNbr)throws RemoteException,EElixirException;
  /**
   * updates the other benefit DSTDetails
   * @param OtherBenefitResult 
   * @return void
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public void updatePerReductionDetails(ArrayList alDSTDetails,Long lBonusHdrSeqNbr) throws RemoteException,EElixirException;
  //ANUP_DST_Incentive_April_REL_Ends
  //<!--ANUP_Session_Listner_Implementation_Start-->
  /**
   * Call procedure function
   * @param HashMap 
   * @return ProcessResult
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public ProcessResult callProceduresMyAgent(HashMap hmParam) throws RemoteException,EElixirException;
  //<!--ANUP_Session_Listner_Implementation_Ends-->
//Anup_AugRel2010_FSD_TPR_V1.3_Starts

  
  
//By Himanshu
  
  public String searchvalidValue( )throws RemoteException, EJBException, EElixirException;

  //himanshu: code Ends
  
  
  
  
  
  
  public ArrayList searchChannelTPRTypes(String a_cChannelType)
  	 	throws FinderException, RemoteException, EElixirException;
  	 
  public TPRResult searchTPRMasterData(long lTPRHdrSeqNbr)
  	    throws FinderException, EElixirException, RemoteException;

  public void createTPRMaster(ArrayList a_TPRResult)
  		throws EJBException, EElixirException, RemoteException;

  public void updateTPRMaster(TPRResult a_TPRResult)
  	throws EJBException, EElixirException, RemoteException;
  	 
  	 //Anup_AugRel2010_FSD_TPR_V1.3_Ends
}