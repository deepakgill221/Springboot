package com.mastek.eElixir.channelmanagement.helper;

import com.mastek.eElixir.common.util.ActionFactory;


/**
 * <p>Title: AMAL</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Design Team
 * @version 1.0
 */

public class CHMActionFactory extends ActionFactory
{

  private CHMActionFactory()
  {
  }

  /**
 * Returns a instance of the ActionFactory
 */
  public static ActionFactory getActionFactory()
  {
    if (CHMActionFactory._oCHMActionFactorySingleton == null)
        CHMActionFactory._oCHMActionFactorySingleton = new CHMActionFactory ();
    return CHMActionFactory._oCHMActionFactorySingleton;
  }


  /**
  * Member Variables
  */

  public static CHMActionFactory _oCHMActionFactorySingleton = null;
}