/********************************************************************
 *
 *  PROJECT                            : PRUDENTIAL
 *  MODULE NAME                        : CHANNEL MANAGEMENT
 *  FILENAME                           : ContestDAX.java
 *  AUTHOR                             : Pallav Laddha
 *  VERSION                            : 1.0
 *  CREATION DATE                      : October 20, 2002
 *  COMPANY                            : Mastek Ltd.
 *  COPYRIGHT                          : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY       REASON
 *--------------------------------------------------------------------------------
 *  1.1     6/1/2003    Jimmy    Defect Fix of 1109
 *  1.2     30Jan       Pallav   Added delete functionality
 *  2.1     27/09/2003  Dipti F  UT Rework
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.contest.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.contest.util.ContestEligibilityCriteria;
import com.mastek.eElixir.channelmanagement.contest.util.ContestProductMix;
import com.mastek.eElixir.channelmanagement.contest.util.ContestResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;


/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the Contest object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class ContestDAX extends DAX
{
    /*
    *  Member variables
    */
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor
     */
    public ContestDAX()
    {
    }

    /**
     * Populates the resultset into XML string object
     * @param a_oResultObject Object
     * @return XML string object
     * @throws EElixirException
     */
    public String getContest(Object a_oResultObject) throws EElixirException
    {
        PreparedStatement pstmtSearchContest = null;
        Statement st = null;
        StringBuffer sb = new StringBuffer();
        HashMap hmQueryMap = new HashMap();
        SearchData oSearchData = (SearchData) a_oResultObject;

        try
        {
            String strContestDesc = oSearchData.getTask1();
            String nContestType = oSearchData.getTask2();
            String cChannelType = oSearchData.getTask3();
            String strDesgnCd = oSearchData.getTask4();
            String strSubChannelType = oSearchData.getTask5();

            GregorianCalendar dtEffFrom = oSearchData.getTaskDate1();
            GregorianCalendar dtEffTo = oSearchData.getTaskDate2();

            String strSearchContestQuery = getSQLString("Select",
                    CHMConstants.CONTEST_LIST_SEARCH);

            hmQueryMap.put("Main", strSearchContestQuery);

            strSearchContestQuery = " AND ch.STRCONTESTDESC LIKE  ? ";
            hmQueryMap.put("CONTESTDESC", strSearchContestQuery);

            strSearchContestQuery = " AND ch.nContestType =  ? ";
            hmQueryMap.put("CONTESTTYPE", strSearchContestQuery);

            strSearchContestQuery = " AND ch.cChannelType =  ? ";
            hmQueryMap.put("CHANNELTYPE", strSearchContestQuery);

            //Fixed defect id 1109
            strSearchContestQuery = " AND ch.strSubChannelType =  ? ";
            hmQueryMap.put("SUBCHANNELTYPE", strSearchContestQuery);

            strSearchContestQuery = " AND ch.strDesgnCd =  ? ";
            hmQueryMap.put("DESNCD", strSearchContestQuery);

            strSearchContestQuery = " AND ch.dtEffFrom =  ? ";
            hmQueryMap.put("EffectiveDateFrom", strSearchContestQuery);

            strSearchContestQuery = " AND ch.dtEffTo =  ? ";
            hmQueryMap.put("EffectiveDateTo", strSearchContestQuery);

            String strQuery = (String) hmQueryMap.get("Main");

            if ((strContestDesc != null) && !strContestDesc.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("CONTESTDESC");
            }

            if ((nContestType != null) && !nContestType.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("CONTESTTYPE");
            }

            if ((cChannelType != null) && !cChannelType.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("CHANNELTYPE");
            }

            if ((strSubChannelType != null) &&
                    !strSubChannelType.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("SUBCHANNELTYPE");
            }

            if ((strDesgnCd != null) && !strDesgnCd.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("DESNCD");
            }

            if (dtEffFrom != null)
            {
                strQuery += (String) hmQueryMap.get("EffectiveDateFrom");
            }

            if (dtEffTo != null)
            {
                strQuery += (String) hmQueryMap.get("EffectiveDateTo");
            }

            strQuery = strQuery + " order by ch.STRCONTESTDESC";

            pstmtSearchContest = getPreparedStatement(strQuery);

            int iPosition = 0;
            pstmtSearchContest.setInt(++iPosition, DataConstants.CONTEST_TYPE);

            if ((strContestDesc != null) && !strContestDesc.trim().equals(""))
            {
                pstmtSearchContest.setString(++iPosition,
                    DataConstants.LIKE_OPERATOR +
                    strContestDesc.trim().toUpperCase() +
                    DataConstants.LIKE_OPERATOR);
            }

            if ((nContestType != null) && !nContestType.trim().equals(""))
            {
                pstmtSearchContest.setInt(++iPosition,
                    Integer.parseInt(nContestType.trim()));
            }

            if ((cChannelType != null) && !cChannelType.trim().equals(""))
            {
                pstmtSearchContest.setString(++iPosition, cChannelType.trim());
            }

            if ((strSubChannelType != null) &&
                    !strSubChannelType.trim().equals(""))
            {
                pstmtSearchContest.setString(++iPosition,
                    strSubChannelType.trim());
            }

            if ((strDesgnCd != null) && !strDesgnCd.trim().equals(""))
            {
                pstmtSearchContest.setString(++iPosition, strDesgnCd.trim());
            }

            if (dtEffFrom != null)
            {
                pstmtSearchContest.setTimestamp(++iPosition,
                    DateUtil.retTimestamp(dtEffFrom));
            }

            if (dtEffTo != null)
            {
                pstmtSearchContest.setTimestamp(++iPosition,
                    DateUtil.retTimestamp(dtEffTo));
            }

            ResultSet rsSearch = executeQuery(pstmtSearchContest);

            return XMLConverter.getXMLString(rsSearch);
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "getContest",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P9501");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "getContest", eex.getMessage());
            throw new EElixirException(eex, "P9501");
        }
        finally
        {
            try
            {
                if (pstmtSearchContest != null)
                {
                    pstmtSearchContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.fatal(getClass().getName(), "getContest",
                    sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * getContest gets the Contest Details
     * @return ContestResult
     * @param a_lcontestseqnbr long
     * @throws EElixirException
     */
    public ContestResult getContest(long a_lcontestseqnbr)
        throws EElixirException
    {
        ResultSet rsSearchContest = null;
        ContestResult oContestResult = null;
        PreparedStatement pstmtSearchContest = null;

        ContestEligibilityCriteria oContestEligibilityCriteria = null;
        ArrayList arrProductMix = null;
        ArrayList arrRewardDefinition = null;

        try
        {
            String strSelectContestQuery = getSQLString("Select",
                    CHMConstants.CONTEST_SEARCH);

            pstmtSearchContest = getPreparedStatement(strSelectContestQuery);
            pstmtSearchContest.setLong(1, a_lcontestseqnbr);

            rsSearchContest = executeQuery(pstmtSearchContest);

            oContestResult = new ContestResult();

            if (rsSearchContest.next())
            {
                /* CHANGE TO AVOID UPDATE  */
                oContestResult.setIsDirty(DataConstants.DISPLAY_MODE);
                oContestResult.setContestSeqNbr(new Long(a_lcontestseqnbr));
                oContestResult.setContestDesc(rsSearchContest.getString(
                        "STRCONTESTDESC"));
                oContestResult.setDtEffFrom(DateUtil.retGregorian(
                        rsSearchContest.getTimestamp("dtEffFrom")));
                oContestResult.setDtEffTo(DateUtil.retGregorian(
                        rsSearchContest.getTimestamp("dtEffTo")));
                oContestResult.setContestType(new Short(
                        rsSearchContest.getShort("NCONTESTTYPE")));
                oContestResult.setChannelType(new Character(
                        rsSearchContest.getString("cChannelType").charAt(0)));
                oContestResult.setSubChannelType(rsSearchContest.getString(
                        "STRSUBCHANNELTYPE"));
                oContestResult.setDesgnCd(rsSearchContest.getString(
                        "STRDESGNCD"));
                oContestResult.setFreqOfCalc(new Short(rsSearchContest.getShort(
                            "NFREQOFCALC")));
                oContestResult.setRewardFreq(new Short(rsSearchContest.getShort(
                            "NREWARDFREQ")));
                oContestResult.setTsDtUpdated(rsSearchContest.getTimestamp(
                        "dtupdated"));

                //oContestResult.setRef(new Short(rsSearchContest.getShort("NREF")));
                //oContestResult.setStartMonth(new Short(rsSearchContest.getShort("NSTARTMONTH")));
                oContestResult.setRewardType(new Short(rsSearchContest.getShort(
                            "NREWARDTYPE")));

                double d = rsSearchContest.getDouble("DREWARDAMNT");

                if (rsSearchContest.wasNull())
                {
                    oContestResult.setRewardAmnt(null);
                }
                else
                {
                    oContestResult.setRewardAmnt(new Double(d));
                }

                if (rsSearchContest.getString("NCRITFUNCTION") != null)
                {
                    oContestResult.setCritFunction(new Short(
                            rsSearchContest.getShort("NCRITFUNCTION")));
                }

                oContestResult.setRewardDesc(rsSearchContest.getString(
                        "STRREWARDDESC"));
                oContestResult.setIsSpecificContest(new Short(
                        rsSearchContest.getShort("NISSPECIFICCONTEST")));

                //oContestResult.setIsInclOrExcl(new Short(rsSearchContest.getShort("NISINCLOREXCL")));
                oContestResult.setAgentCd(rsSearchContest.getString(
                        "STRAGENTCD"));
            }

            //" Now the part for Contest Eligibility"
            String strSelectContestEligibilityQuery = getSQLString("Select",
                    CHMConstants.CONTEST_ELIGIBILITY_SEARCH);

            pstmtSearchContest = getPreparedStatement(strSelectContestEligibilityQuery);
            pstmtSearchContest.setLong(1, a_lcontestseqnbr);
            pstmtSearchContest.setInt(2, DataConstants.CONTEST_ELIGIBILITY);

            rsSearchContest = executeQuery(pstmtSearchContest);

            oContestEligibilityCriteria = new ContestEligibilityCriteria();

            if (rsSearchContest.next())
            {
                oContestEligibilityCriteria.setContestSeqNbr(new Long(
                        a_lcontestseqnbr));
                oContestEligibilityCriteria.setContestDetailType(new Short(
                        rsSearchContest.getShort("NCONTESTDETAILTYPE")));
                oContestEligibilityCriteria.setMonthFrom(new Short(
                        rsSearchContest.getShort("NMONTHFROM")));
                oContestEligibilityCriteria.setMonthTo(new Short(
                        rsSearchContest.getShort("NMONTHTO")));
                oContestEligibilityCriteria.setCritFunction(new Short(
                        rsSearchContest.getShort("NCRITFUNCTION")));
                oContestEligibilityCriteria.setElgbleValue(rsSearchContest.getString(
                        "STRELGBLEVALUE"));
                oContestEligibilityCriteria.setTsDtUpdated(rsSearchContest.getTimestamp(
                        "DTUPDATED"));
            }

            oContestResult.setContestEligibilityCriteria(oContestEligibilityCriteria);

            // Now the part of Product Mix
            String strSelectProductMixQuery = getSQLString("Select",
                    CHMConstants.CONTEST_PRODUCT_MIX_SEARCH);

            pstmtSearchContest = getPreparedStatement(strSelectProductMixQuery);
            pstmtSearchContest.setLong(1, a_lcontestseqnbr);

            rsSearchContest = executeQuery(pstmtSearchContest);

            arrProductMix = new ArrayList(10);

            int count = 0;

            while (rsSearchContest.next())
            {
                ContestProductMix oContestProductMix = new ContestProductMix();
                oContestProductMix.setContestSeqNbr(new Long(a_lcontestseqnbr));
                oContestProductMix.setProdCd(rsSearchContest.getString(
                        "STRPRODCD"));
                oContestProductMix.setProdVer(new Integer(
                        rsSearchContest.getInt("IPRODVER")));
                oContestProductMix.setProdPerc(new Double(
                        rsSearchContest.getDouble("DPRODPERC")));
                arrProductMix.add(oContestProductMix);
                count++;
            }

            if (count == 0)
            {
                arrProductMix = null;
            }

            oContestResult.setArrProductMix(arrProductMix);

            // Now the part of Reward Definition
            return oContestResult;
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "getContest",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P9502");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "getContest", eex.getMessage());
            throw new EElixirException(eex, "P9502");
        }
        finally
        {
            try
            {
                if (rsSearchContest != null)
                {
                    rsSearchContest.close();
                }

                if (pstmtSearchContest != null)
                {
                    pstmtSearchContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.fatal(getClass().getName(), "getContest",
                    sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
      * Inserts a new record
      * @param a_oContestResult ContestResult
      * @return long Returns the next seq no generated on Contest table
      * @throws EElixirException
      */
    public long createContest(ContestResult a_oContestResult)
        throws EElixirException
    {
        PreparedStatement pstmtCreateContest = null;
        ResultSet rsCreateContest = null;
        ArrayList arrProductMix = null;

        long lcontestseqnbr;
        String strCreatedBy = null;

        try
        {
            String strContestDesc = a_oContestResult.getContestDesc()
                                                    .toUpperCase();
            Short nContestType = a_oContestResult.getContestType();
            GregorianCalendar dtEffFrom = a_oContestResult.getDtEffFrom();
            GregorianCalendar dtEffTo = a_oContestResult.getDtEffTo();
            Character cChannelType = a_oContestResult.getChannelType();
            String strSubChannelType = a_oContestResult.getSubChannelType();
            String strDesgnCd = a_oContestResult.getDesgnCd();
            Short nFreqOfCalc = a_oContestResult.getFreqOfCalc();
            Short nRewardFreq = a_oContestResult.getRewardFreq();
            Short nStartMonth = a_oContestResult.getStartMonth();
            Short nRef = a_oContestResult.getRef();

            Short nRewardType = a_oContestResult.getRewardType();
            Double dRewardAmnt = a_oContestResult.getRewardAmnt();
            String strRewardDesc = a_oContestResult.getRewardDesc();
            Short nIsSpecificContest = a_oContestResult.getIsSpecificContest();
            String strAgentCd = a_oContestResult.getAgentCd();
            Short nIsInclOrExcl = a_oContestResult.getIsInclOrExcl();
            strCreatedBy = a_oContestResult.getUserId();

            Short nCritFunctionEV = a_oContestResult.getCritFunction();

            ContestEligibilityCriteria oContestEligibilityCriteria = a_oContestResult.getContestEligibilityCriteria();
            arrProductMix = a_oContestResult.getArrProductMix();

            // Before inserting a new record this function generates a new Seq no, on which the
            // new record is inserted.
            lcontestseqnbr = getNextContestSeqNbr();

            String strCreateContestQuery = getSQLString("Insert",
                    CHMConstants.CONTEST_INSERT);

            pstmtCreateContest = getPreparedStatement(strCreateContestQuery);

            pstmtCreateContest.setLong(1, lcontestseqnbr);
            pstmtCreateContest.setString(2, strContestDesc.trim().toUpperCase());
            pstmtCreateContest.setShort(3, nContestType.shortValue());
            pstmtCreateContest.setTimestamp(4, DateUtil.retTimestamp(dtEffFrom));
            pstmtCreateContest.setTimestamp(5, DateUtil.retTimestamp(dtEffTo));
            pstmtCreateContest.setString(6,
                (cChannelType.charValue() + "").trim());
            pstmtCreateContest.setString(7, strSubChannelType.trim());
            pstmtCreateContest.setString(8, strDesgnCd);
            pstmtCreateContest.setShort(9, nFreqOfCalc.shortValue());
            pstmtCreateContest.setShort(10, nRewardFreq.shortValue());

            //pstmtCreateContest.setShort(11,nStartMonth.shortValue());
            //pstmtCreateContest.setShort(12,nRef.shortValue());
            pstmtCreateContest.setShort(11, nRewardType.shortValue());

            if ((nRewardFreq.shortValue() != DataConstants.REWARD_FREQUENCY_PERIODIC) &&
                    (nRewardType.shortValue() == DataConstants.REWARD_TYPE_GIFT_COUPON))
            {
                pstmtCreateContest.setDouble(12, dRewardAmnt.doubleValue());
            }
            else
            {
                pstmtCreateContest.setNull(12, java.sql.Types.INTEGER);
            }

            pstmtCreateContest.setString(13, strRewardDesc);
            pstmtCreateContest.setShort(14, nIsSpecificContest.shortValue());

            //pstmtCreateContest.setShort(19,nIsInclOrExcl.shortValue());
            pstmtCreateContest.setString(15, strCreatedBy);

            if (strAgentCd != null)
            {
                pstmtCreateContest.setString(16, strAgentCd.trim().toUpperCase());
            }
            else
            {
                pstmtCreateContest.setNull(16, java.sql.Types.VARCHAR);
            }

            if (nCritFunctionEV != null)
            {
                pstmtCreateContest.setShort(17, nCritFunctionEV.shortValue());
            }
            else
            {
                pstmtCreateContest.setNull(17, java.sql.Types.NUMERIC);
            }

            int icount = executeUpdate(pstmtCreateContest);

            // Now inserting Calculation criteria
            // Now inserting Eligibility criteria
            Short nContestDetailType = oContestEligibilityCriteria.getContestDetailType();
            String strElgbleValue = null;

            if (oContestEligibilityCriteria.getMonthFrom() != null)
            {
                Short nCritFunction = oContestEligibilityCriteria.getCritFunction();
                strElgbleValue = oContestEligibilityCriteria.getElgbleValue();

                Short nMonthFrom = oContestEligibilityCriteria.getMonthFrom();
                Short nMonthTo = oContestEligibilityCriteria.getMonthTo();

                String strCreateContestEligibilityQuery = getSQLString("Insert",
                        CHMConstants.CONTEST_ELIGIBILITY_INSERT);

                pstmtCreateContest = getPreparedStatement(strCreateContestEligibilityQuery);

                pstmtCreateContest.setLong(1, lcontestseqnbr);
                pstmtCreateContest.setShort(2, nContestDetailType.shortValue());
                pstmtCreateContest.setShort(3, nCritFunction.shortValue());
                pstmtCreateContest.setString(4, strElgbleValue);
                pstmtCreateContest.setShort(5, nMonthFrom.shortValue());
                pstmtCreateContest.setShort(6, nMonthTo.shortValue());
                pstmtCreateContest.setString(7, strCreatedBy);
                icount = executeUpdate(pstmtCreateContest);
            }

            // Now inserting Product Mix data
            if (arrProductMix != null)
            {
                for (int i = 0; i < arrProductMix.size(); i++)
                {
                    ContestProductMix oContestProductMix = (ContestProductMix) arrProductMix.get(i);
                    insertProductMix(oContestProductMix, lcontestseqnbr);
                }
            }

            // Now inserting Reward Definition data
            return lcontestseqnbr;
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "createContest",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P9503");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "createContest",
                eex.getMessage());
            throw new EElixirException(eex, "P9503");
        }
        finally
        {
            try
            {
                if (pstmtCreateContest != null)
                {
                    pstmtCreateContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.fatal(getClass().getName(), "createContest",
                    sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Updates the Contest, Currently only Effective To date can be updated
     * @param: a_oContestResult ContestResult
     * @throws EElixirException
     */
    public void updateContest(ContestResult a_oContestResult)
        throws EElixirException
    {
        PreparedStatement pstmtUpdateContest = null;
        ArrayList arrProductMix = null;
        ArrayList arrRewardDefinition = null;
        String strUpdatedBy = null;
        ResultSet rsSearchEligibility = null;
        PreparedStatement pstmtFindPrimaryKey = null;

        try
        {
            long lcontestseqnbr = a_oContestResult.getContestSeqNbr().longValue();
            String strContestDesc = a_oContestResult.getContestDesc()
                                                    .toUpperCase();
            Short nContestType = a_oContestResult.getContestType();
            GregorianCalendar dtEffFrom = a_oContestResult.getDtEffFrom();
            GregorianCalendar dtEffTo = a_oContestResult.getDtEffTo();
            Character cChannelType = a_oContestResult.getChannelType();
            String strSubChannelType = a_oContestResult.getSubChannelType();
            String strDesgnCd = a_oContestResult.getDesgnCd();
            Short nFreqOfCalc = a_oContestResult.getFreqOfCalc();
            Short nRewardFreq = a_oContestResult.getRewardFreq();

            //Short nStartMonth               = a_oContestResult.getStartMonth();
            //Short nRef                      = a_oContestResult.getRef();
            Short nRewardType = a_oContestResult.getRewardType();
            Double dRewardAmnt = a_oContestResult.getRewardAmnt();
            String strRewardDesc = a_oContestResult.getRewardDesc();
            Short nIsSpecificContest = a_oContestResult.getIsSpecificContest();

            //Short nIsInclOrExcl             = a_oContestResult.getIsInclOrExcl();
            String strAgentCd = a_oContestResult.getAgentCd();
            strUpdatedBy = a_oContestResult.getUserId();

            Short nCritFunctionEV = a_oContestResult.getCritFunction();

            ContestEligibilityCriteria oContestEligibilityCriteria = a_oContestResult.getContestEligibilityCriteria();
            arrProductMix = a_oContestResult.getArrProductMix();

            if (compareDt(dtEffFrom))
            {
                String strUpdateContestQuery = getSQLString("Update",
                        CHMConstants.CONTEST_UPDATE);

                pstmtUpdateContest = getPreparedStatement(strUpdateContestQuery);

                pstmtUpdateContest.setString(1,
                    strContestDesc.trim().toUpperCase());
                pstmtUpdateContest.setShort(2, nContestType.shortValue());
                pstmtUpdateContest.setTimestamp(3,
                    DateUtil.retTimestamp(dtEffFrom));
                pstmtUpdateContest.setTimestamp(4,
                    DateUtil.retTimestamp(dtEffTo));
                pstmtUpdateContest.setString(5,
                    (cChannelType.charValue() + "").trim());
                pstmtUpdateContest.setString(6, strSubChannelType);
                pstmtUpdateContest.setString(7, strDesgnCd);
                pstmtUpdateContest.setShort(8, nFreqOfCalc.shortValue());
                pstmtUpdateContest.setShort(9, nRewardFreq.shortValue());

                //pstmtUpdateContest.setShort(10,nStartMonth.shortValue());
                //pstmtUpdateContest.setShort(11,nRef.shortValue());
                pstmtUpdateContest.setShort(10, nRewardType.shortValue());

                if ((nRewardFreq.shortValue() != DataConstants.REWARD_FREQUENCY_PERIODIC) &&
                        (nRewardType.shortValue() == DataConstants.REWARD_TYPE_GIFT_COUPON))
                {
                    pstmtUpdateContest.setDouble(11, dRewardAmnt.doubleValue());
                }
                else
                {
                    pstmtUpdateContest.setNull(11, java.sql.Types.INTEGER);
                }

                pstmtUpdateContest.setString(12, strRewardDesc);
                pstmtUpdateContest.setShort(13, nIsSpecificContest.shortValue());

                //pstmtUpdateContest.setShort(18,nIsInclOrExcl.shortValue());
                pstmtUpdateContest.setString(14, strUpdatedBy);

                if (strAgentCd != null)
                {
                    pstmtUpdateContest.setString(15, strAgentCd);
                }
                else
                {
                    pstmtUpdateContest.setNull(15, java.sql.Types.VARCHAR);
                }

                if (nCritFunctionEV != null)
                {
                    pstmtUpdateContest.setShort(16, nCritFunctionEV.shortValue());
                }
                else
                {
                    pstmtUpdateContest.setNull(16, java.sql.Types.NUMERIC);
                }

                pstmtUpdateContest.setLong(17, lcontestseqnbr);

                int icount = executeUpdate(pstmtUpdateContest);

                // Now inserting Eligibility criteria
                // here first it checks if the record is already existing, if present and if
                // user removed all the record then it deletes those.
                // if the record is present and if user has changed it then it updates that record.
                // If the record is not present and if user entered a new one then it inserts a new record into it.
                Short nContestDetailType = oContestEligibilityCriteria.getContestDetailType();
                String strElgbleValue = null;

                if (oContestEligibilityCriteria.getMonthFrom() != null)
                {
                    Short nCritFunction = oContestEligibilityCriteria.getCritFunction();
                    strElgbleValue = oContestEligibilityCriteria.getElgbleValue();

                    Short nMonthFrom = oContestEligibilityCriteria.getMonthFrom();
                    Short nMonthTo = oContestEligibilityCriteria.getMonthTo();

                    String strSelectContestQuery = getSQLString("Select",
                            CHMConstants.FIND_CONTEST_ELIGIBILITY_BY_PRIMARYKEY);

                    pstmtFindPrimaryKey = getPreparedStatement(strSelectContestQuery);
                    pstmtFindPrimaryKey.setLong(1, lcontestseqnbr);
                    pstmtFindPrimaryKey.setShort(2,
                        (short) DataConstants.CONTEST_ELIGIBILITY);
                    rsSearchEligibility = executeQuery(pstmtFindPrimaryKey);

                    if (rsSearchEligibility.next())
                    {
                        String strUpdateContestEligibilityQuery = getSQLString("Update",
                                CHMConstants.CONTEST_ELIGIBILITY_UPDATE);

                        pstmtUpdateContest = getPreparedStatement(strUpdateContestEligibilityQuery);

                        pstmtUpdateContest.setShort(1,
                            nCritFunction.shortValue());
                        pstmtUpdateContest.setString(2, strElgbleValue);
                        pstmtUpdateContest.setShort(3, nMonthFrom.shortValue());
                        pstmtUpdateContest.setShort(4, nMonthTo.shortValue());
                        pstmtUpdateContest.setString(5, strUpdatedBy);
                        pstmtUpdateContest.setLong(6, lcontestseqnbr);
                        pstmtUpdateContest.setShort(7,
                            (short) DataConstants.CONTEST_ELIGIBILITY);
                        icount = executeUpdate(pstmtUpdateContest);
                    }
                    else
                    {
                        String strCreateContestEligibilityQuery = getSQLString("Insert",
                                CHMConstants.CONTEST_ELIGIBILITY_INSERT);

                        pstmtUpdateContest = getPreparedStatement(strCreateContestEligibilityQuery);
                        pstmtUpdateContest.setLong(1, lcontestseqnbr);
                        pstmtUpdateContest.setShort(2,
                            nContestDetailType.shortValue());
                        pstmtUpdateContest.setShort(3,
                            nCritFunction.shortValue());
                        pstmtUpdateContest.setString(4, strElgbleValue);
                        pstmtUpdateContest.setShort(5, nMonthFrom.shortValue());
                        pstmtUpdateContest.setShort(6, nMonthTo.shortValue());
                        pstmtUpdateContest.setString(7, strUpdatedBy);
                        icount = executeUpdate(pstmtUpdateContest);
                    }
                }
                else
                {
                    String strDeleteContestEligibilityQuery = getSQLString("Delete",
                            CHMConstants.CONTEST_ELIGIBILITY_DELETE);
                    pstmtUpdateContest = getPreparedStatement(strDeleteContestEligibilityQuery);
                    pstmtUpdateContest.setLong(1, lcontestseqnbr);
                    pstmtUpdateContest.setShort(2,
                        (short) DataConstants.CONTEST_ELIGIBILITY);
                    icount = executeUpdate(pstmtUpdateContest);
                }
            }
            else
            {
                String strUpdateContestQuery = getSQLString("Update",
                        CHMConstants.CONTEST_EFF_TO_DATE_UPDATE);

                pstmtUpdateContest = getPreparedStatement(strUpdateContestQuery);
                pstmtUpdateContest.setTimestamp(1,
                    DateUtil.retTimestamp(dtEffTo));
                pstmtUpdateContest.setString(2, strUpdatedBy);
                pstmtUpdateContest.setLong(3, lcontestseqnbr);

                int icount = executeUpdate(pstmtUpdateContest);
            }
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "updateContest",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P9504");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "updateContest",
                eex.getMessage());
            throw new EElixirException(eex, "P9504");
        }
        finally
        {
            try
            {
                if (pstmtUpdateContest != null)
                {
                    pstmtUpdateContest.close();
                }

                if (pstmtFindPrimaryKey != null)
                {
                    pstmtFindPrimaryKey.close();
                }

                if (rsSearchEligibility != null)
                {
                    rsSearchEligibility.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.fatal(getClass().getName(), "updateContest",
                    sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
      * findContest finds whether the contest is there or not
      * @return boolean
      * @param a_lcontestseqnbr long
      * @throws EElixirException
      */
    public boolean findContest(long a_lcontestseqnbr) throws EElixirException
    {
        ResultSet rsSearchContest = null;
        PreparedStatement pstmtFindPrimaryKey = null;

        try
        {
            String strSelectContestQuery = getSQLString("Select",
                    CHMConstants.FIND_CONTEST_BY_PRIMARYKEY);

            if (pstmtFindPrimaryKey == null)
            {
                pstmtFindPrimaryKey = getPreparedStatement(strSelectContestQuery);
            }

            pstmtFindPrimaryKey.setLong(1, a_lcontestseqnbr);

            rsSearchContest = executeQuery(pstmtFindPrimaryKey);

            if (rsSearchContest.next())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "findContest",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P9505");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "findContest", eex.getMessage());
            throw new EElixirException(eex, "P9505");
        }
        finally
        {
            try
            {
                if (rsSearchContest != null)
                {
                    rsSearchContest.close();
                }

                if (pstmtFindPrimaryKey != null)
                {
                    pstmtFindPrimaryKey.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.fatal(getClass().getName(), "findContest",
                    sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
      * This function inserts the record into ContestProductMix table
      * @return int
      * @throws EElixirException
      * @param a_oContestProductMix ContestProductMix
      * @param a_lcontestseqnbr long
       */
    protected int insertProductMix(ContestProductMix a_oContestProductMix,
        long a_lcontestseqnbr) throws EElixirException
    {
        PreparedStatement pstmtCreateProductMixContest = null;

        try
        {
            String strCreateProductMixQuery = getSQLString("Insert",
                    CHMConstants.CONTEST_PRODUCT_MIX_INSERT);
            pstmtCreateProductMixContest = getPreparedStatement(strCreateProductMixQuery);

            pstmtCreateProductMixContest.setLong(1, a_lcontestseqnbr);
            pstmtCreateProductMixContest.setString(2,
                a_oContestProductMix.getProdCd());
            pstmtCreateProductMixContest.setInt(3,
                a_oContestProductMix.getProdVer().intValue());
            pstmtCreateProductMixContest.setDouble(4,
                a_oContestProductMix.getProdPerc().doubleValue());
            pstmtCreateProductMixContest.setString(5,
                a_oContestProductMix.getUserId());

            int icount = executeUpdate(pstmtCreateProductMixContest);

            return icount;
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "insertProductMix",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P9506");
        }
        catch (EElixirException eex)
        {
            _oLogger.exception(eex.getMessage());
            throw new EElixirException(eex, "P9506");
        }
        finally
        {
            try
            {
                if (pstmtCreateProductMixContest != null)
                {
                    pstmtCreateProductMixContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
      * This function updates the existing record
      * @return int
      * @throws EElixirException
      * @param a_oContestProductMix ContestProductMix
      * @param a_lcontestseqnbr long
      */
    protected int updateProductMix(ContestProductMix a_oContestProductMix,
        long a_lcontestseqnbr) throws EElixirException
    {
        PreparedStatement pstmtUpdateProductMixContest = null;

        try
        {
            String strCreateProductMixQuery = getSQLString("Update",
                    CHMConstants.CONTEST_PRODUCT_MIX_UPDATE);
            pstmtUpdateProductMixContest = getPreparedStatement(strCreateProductMixQuery);
            pstmtUpdateProductMixContest.setDouble(1,
                a_oContestProductMix.getProdPerc().doubleValue());
            pstmtUpdateProductMixContest.setString(2,
                a_oContestProductMix.getUserId());
            pstmtUpdateProductMixContest.setLong(3, a_lcontestseqnbr);
            pstmtUpdateProductMixContest.setString(4,
                a_oContestProductMix.getProdCd());
            pstmtUpdateProductMixContest.setInt(5,
                a_oContestProductMix.getProdVer().intValue());

            int icount = executeUpdate(pstmtUpdateProductMixContest);

            return icount;
        }
        catch (SQLException sqlex)
        {
            _oLogger.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9507");
        }
        catch (EElixirException eex)
        {
            _oLogger.exception(eex.getMessage());
            throw new EElixirException(eex, "P9507");
        }
        finally
        {
            try
            {
                if (pstmtUpdateProductMixContest != null)
                {
                    pstmtUpdateProductMixContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
       * This function removes the existing record
       * @throws EElixirException
       * @param a_oContestProductMix ContestProductMix
       * @param a_lcontestseqnbr long
       */
    protected void removeProductMix(ContestProductMix a_oContestProductMix,
        long a_lcontestseqnbr) throws EElixirException
    {
        PreparedStatement pstmtRemoveProductMixContest = null;

        try
        {
            String strRemoveProductMixQuery = getSQLString("Delete",
                    CHMConstants.CONTEST_PRODUCT_MIX_DELETE);
            pstmtRemoveProductMixContest = getPreparedStatement(strRemoveProductMixQuery);
            pstmtRemoveProductMixContest.setLong(1, a_lcontestseqnbr);
            pstmtRemoveProductMixContest.setString(2,
                a_oContestProductMix.getProdCd());
            pstmtRemoveProductMixContest.setInt(3,
                a_oContestProductMix.getProdVer().intValue());

            int icount = executeUpdate(pstmtRemoveProductMixContest);
        }
        catch (SQLException sqlex)
        {
            _oLogger.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9508");
        }
        catch (EElixirException eex)
        {
            _oLogger.exception(eex.getMessage());
            throw new EElixirException(eex, "P9508");
        }
        finally
        {
            try
            {
                if (pstmtRemoveProductMixContest != null)
                {
                    pstmtRemoveProductMixContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
       * This function removes the existing record
       * @throws EElixirException
       * @param a_lcontestseqnbr long
       */
    protected void removeAllProductMix(long a_lcontestseqnbr)
        throws EElixirException
    {
        PreparedStatement pstmtRemoveProductMixContest = null;

        try
        {
            String strRemoveProductMixQuery = getSQLString("Delete",
                    CHMConstants.CONTEST_ALL_PRODUCT_MIX_DELETE);
            pstmtRemoveProductMixContest = getPreparedStatement(strRemoveProductMixQuery);
            pstmtRemoveProductMixContest.setLong(1, a_lcontestseqnbr);

            int icount = executeUpdate(pstmtRemoveProductMixContest);
        }
        catch (SQLException sqlex)
        {
            _oLogger.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9508");
        }
        catch (EElixirException eex)
        {
            _oLogger.exception(eex.getMessage());
            throw new EElixirException(eex, "P9508");
        }
        finally
        {
            try
            {
                if (pstmtRemoveProductMixContest != null)
                {
                    pstmtRemoveProductMixContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Removes the selected Contest
     * @return int No of rows removed
     * @param: a_lContestSeqNbr long
     * @throws EElixirException
     */
    public int removeContest(long a_lContestSeqNbr) throws EElixirException
    {
        PreparedStatement pstmtRemoveContest = null;

        try
        {
            // deleting from chm_contest_crit table, deleting both Eligibility, and Evaluation
            String strRemoveQuery = getSQLString("Delete",
                    CHMConstants.CONTEST_ELIGIBILITY_EVALUATION_DELETE);
            pstmtRemoveContest = getPreparedStatement(strRemoveQuery);
            pstmtRemoveContest.setLong(1, a_lContestSeqNbr);

            int iRemoveContest = executeUpdate(pstmtRemoveContest);

            // deleting all data for given seq no from chm_contest_prod
            removeAllProductMix(a_lContestSeqNbr);

            // deleting all data for given seq no from chm_contest_reward
            //Actual delete from  Contest table
            strRemoveQuery = getSQLString("Delete", CHMConstants.CONTEST_DELETE);
            pstmtRemoveContest = getPreparedStatement(strRemoveQuery);
            pstmtRemoveContest.setLong(1, a_lContestSeqNbr);
            iRemoveContest = executeUpdate(pstmtRemoveContest);

            return iRemoveContest;
        }
        catch (SQLException sqlex)
        {
            _oLogger.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9513");
        }
        catch (EElixirException eex)
        {
            _oLogger.exception(eex.getMessage());
            throw new EElixirException(eex, "P9513");
        }
        finally
        {
            try
            {
                if (pstmtRemoveContest != null)
                {
                    pstmtRemoveContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
      * This function generates a new Seq no, on which the
      * new record is inserted.
      * @return long Returns the next seq no generated on Contest table
      * @throws EElixirException
      */
    protected long getNextContestSeqNbr() throws EElixirException
    {
        Statement stmtNextSeqContest = null;
        long lSeqNo;

        try
        {
            String strNextSeqQuery = getSQLString("Select",
                    CHMConstants.CONTEST_SEQUENCENO);

            stmtNextSeqContest = getStatement();

            ResultSet rsSeqNo = stmtNextSeqContest.executeQuery(strNextSeqQuery);
            rsSeqNo.next();
            lSeqNo = rsSeqNo.getLong(1);

            return lSeqNo;
        }
        catch (SQLException sqlex)
        {
            _oLogger.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P9512");
        }
        catch (EElixirException eex)
        {
            _oLogger.exception(eex.getMessage());
            throw new EElixirException(eex, "P9512");
        }
        finally
        {
            try
            {
                if (stmtNextSeqContest != null)
                {
                    stmtNextSeqContest.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
       * Description getSQLString takes querytype and key and returns query
       * @return query string
       * @param a_strSQLType SQL Type i.e Select , Insert , Delete , Update
       * @param a_strKey String
       * @throws EElixirException
       */
    private String getSQLString(String a_strSQLType, String a_strKey)
        throws EElixirException
    {
        SqlRepositoryIF sqlRFIF = null;
        String strSql = "";

        try
        {
            sqlRFIF = CHMSqlRepository.getSqlRepository();
            strSql = sqlRFIF.getSQLString(a_strKey, a_strSQLType);
        }
        catch (EElixirException eex)
        {
            _oLogger.exception(eex.getMessage());
            throw new EElixirException(eex, "P3019"); // could not get sql string
        }

        return strSql;
    }

    /**
       * Compares Date
       * @return boolean
       * @param a_ofirstdt GregorianCalendar
       * @throws EElixirException
     */
    protected boolean compareDt(GregorianCalendar a_ofirstdt)
    {
        //compares if firstdate is greater than or equal to seconddate
        GregorianCalendar sysDate = new GregorianCalendar();

        int day1 = a_ofirstdt.get(a_ofirstdt.DATE);
        int month1 = a_ofirstdt.get(a_ofirstdt.MONTH) + 1;
        int year1 = a_ofirstdt.get(a_ofirstdt.YEAR);

        int day2 = sysDate.get(sysDate.DATE);
        int month2 = sysDate.get(sysDate.MONTH) + 1;
        int year2 = sysDate.get(sysDate.YEAR);

        if (year1 > year2)
        {
            return true;
        }
        else if (year1 < year2)
        {
            return false;
        }
        else if (month1 > month2)
        {
            return true;
        }
        else if (month1 < month2)
        {
            return false;
        }
        else if (day1 < day2)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}
