/********************************************************************
 *
 *  PROJECT				: PRUDENTIAL
 *  MODULE NAME	: CHANNEL MANAGEMENT
 *  FILENAME				: ContestEJB.java
 *  AUTHOR				: Pallav Laddha
 *  VERSION				: 1.0
 *  CREATION DATE	: October 20, 2002
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT		    : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *  1.1         30Jan             Pallav                Added delete functionality
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.contest.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.contest.dax.ContestDAX;
import com.mastek.eElixir.channelmanagement.contest.util.ContestResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;



/**
 * <p>Title: eElixir</p>
 * <p>Description: This Contest Entity bean retrive data from the database according to seach condition</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class ContestEJB implements EntityBean
{
  /**
   * Attributes declaration
   */
  private EntityContext _oContext;
  private Connection _oConnection = null;
  private DataSource _oDatasource = null;
  private ContestDAX  _oContestDAX;
  private ContestResult _oContestResult;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


  /**
   * Constructor for ContestEJB class
   */
  public ContestEJB    ()
  {

  }

  /**
   * Matching method of the create() method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @return ContestPK
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public com.mastek.eElixir.channelmanagement.contest.ejb.entitybean.ContestPK ejbCreate    () throws CreateException, EElixirException
  {
    ContestPK bpk = new ContestPK();

    return bpk;

  }

  /**
   * Matching method of the create(ContestResult a_oContestResult) method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @param  a_oContestResult ContestResult
   * @return ContestPK
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public ContestPK ejbCreate   (ContestResult a_oContestResult) throws CreateException, EElixirException
  {
    ContestPK bpk = null;
    try{
      _oContestDAX = getDAX();
      log.debug("ContestEJB--before getContest method of dax object");
      long lcontestseqnbr = _oContestDAX.createContest(a_oContestResult);
      log.debug("ContestEJB-------------------------the value obained in Entity bean is ---"+ lcontestseqnbr);
      bpk = new ContestPK(lcontestseqnbr);
      //bpk.setContestSeqNbr(lcontestseqnbr);
      log.debug("ContestEJB--Key in entiy bean is " + bpk.getContestSeqNbr());
      log.debug("ContestEJB--after getContest method of dax object");
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex, "P1005");
      }
    }
    log.debug("ContestEJB--Key in entiy bean is again " + bpk.getContestSeqNbr());
    return bpk;
  }

  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate    () throws CreateException, EElixirException
  {

  }


  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @param a_oContestResult ContestResult
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate    (ContestResult a_oContestResult) throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method when the instance is taken out of the pool of available
   * instances to become associated with a specific EJB object. This method transitions
   * the instance to the ready state. This method executes in an unspecified transaction
   * context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * A container invokes this method on an instance before the instance becomes disassociated
   * with a specific EJB object. After this method completes, the container will place
   * the instance into the pool of available instances. This method executes in an unspecified
   * transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by loading it from the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbLoad    ()
  {
    log.debug("ContestEJB--ejbLoad() fired");
    ContestPK contestPK = (ContestPK)_oContext.getPrimaryKey();
    try
    {
      _oContestResult = new  ContestResult();
      _oContestDAX = (ContestDAX)getDAX();
      log.debug("ContestEJB--Before Calling getApplication on ContestDAX");
      _oContestResult = _oContestDAX.getContest(contestPK.getContestSeqNbr());
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eex)
      {
        throw new EJBException(eex);
      }
    }
  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by storing it to the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbStore    ()
  {
    log.debug("ContestEJB--ejbStore() fired");
	/* CHANGE TO AVOID UPDATE  */
    if(this._oContestResult != null && this._oContestResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
    {
    try
      {
      _oContestDAX = (ContestDAX)getDAX();
        _oContestDAX.updateContest(_oContestResult);
      }
      catch(EElixirException ex)
      {
        throw new EJBException(ex);
      }
      finally
      {
        try
        {
          if(_oConnection != null)
            DBConnection.closeConnection(_oConnection);
        }
        catch(EElixirException eex)
        {
          throw new EJBException(eex);
        }
      }
    }
  }

  /**
   * A container invokes this method before it removes the EJB object that is currently
   * associated with the instance. It is invoked when a client invokes a remove operation
   * on the enterprise Bean's home or remote interface. It transitions the instance from
   * the ready state to the pool of available instances. It is called in the transaction
   * context of the remove operation.
   * @throws javax.ejb.RemoveException
   */
  public void ejbRemove    ()
  {
    log.debug("ContestEJB--ejbRemove() fired");
    try
    {
      ContestDAX oContestDAX = getDAX();
      oContestDAX.removeContest(((ContestPK)(_oContext.getPrimaryKey())).getContestSeqNbr());
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eex)
      {
        throw new EJBException(eex);
      }
    }
  }

  /**
   * Set the associated entity context. The container invokes this method on an instance
   * after the instance has been created. This method is called in an unspecified transaction
   * context.
   * @param ctx EntityContext
   */
  public void setEntityContext    (EntityContext ctx)
  {
    _oContext = ctx;
  }

  /**
   * Unset the associated entity context. The container calls this method before removing
   * the instance. This is the last method that the container invokes on the instance.
   * The Java garbage collector will  invoke the finalize() method on the instance. It
   * is called in an unspecified transaction context.
   */
  public void unsetEntityContext    ()
  {
    _oContext = null;
  }

  /**
   * Invoked by the container on the instance when the container selects the instance to
   * execute a matching client-invoked find() method. It executes in the transaction
   * context determined by the transaction attribute of the matching find() method.
   * @param a_ContestPK ContestPK
   * @return ContestPK
   * @throws javax.ejb.FinderException
   * @throws EElixirException
   */
  public ContestPK ejbFindByPrimaryKey    (ContestPK a_ContestPK) throws FinderException,EElixirException
  {
    try{
      log.debug("ContestEJB--Inside Findby primary key of ContestEJB");
      _oContestDAX = getDAX();
      log.debug( "Inside Find by primary key " + a_ContestPK.getContestSeqNbr() + "");
      boolean bFlag = _oContestDAX.findContest(a_ContestPK.getContestSeqNbr());
      log.debug( "After find contest");
      if(bFlag){
        log.debug("ContestEJB--Returning Contest Primary Key");
        return a_ContestPK;
      }
      else
        throw new EElixirException("P9505"); // to be decided
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
  }


/**
 * Gets the Dax object and sets the connection on it.
 * @return ContestDAX
 * @throws EElixirException
 */
  private ContestDAX getDAX() throws EElixirException
  {
    _oConnection = DBConnection.getConnection();
    CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
    ContestDAX _oContestDAX = (ContestDAX)theDAXFactory.createDAX(theDAXFactory.CONTESTDAX);
    _oContestDAX.setConnection(_oConnection);

    return _oContestDAX;
  }


  public ContestResult getContestResult() throws  EElixirException
  {
    return _oContestResult;
  }

  public void setContestResult(ContestResult a_oContestResult) throws  EElixirException
  {
    this._oContestResult = a_oContestResult;
  }


}