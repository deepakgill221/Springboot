/********************************************************************
*
*  PROJECT                        : PRUDENTIAL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : ContestSLEJB.java
*  AUTHOR                         : Pallav Laddha
*  VERSION                        : 1.0
*  CREATION DATE                  : September 20, 2002
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION DATE        BY        REASON
*--------------------------------------------------------------------------------
*  1.1    30Jan03     Pallav    Added delete functionality
*  2.1    27/09/2003  Dipti F   UT Rework
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.contest.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.contest.dax.ContestDAX;
import com.mastek.eElixir.channelmanagement.contest.ejb.entitybean.Contest;
import com.mastek.eElixir.channelmanagement.contest.ejb.entitybean.ContestHome;
import com.mastek.eElixir.channelmanagement.contest.ejb.entitybean.ContestPK;
import com.mastek.eElixir.channelmanagement.contest.util.ContestEligibilityCriteria;
import com.mastek.eElixir.channelmanagement.contest.util.ContestResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.ejb.sessionbean.CommonSL;
import com.mastek.eElixir.common.ejb.sessionbean.CommonSLHome;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;


/**
 * <p>Title: eElixir</p>
 * <p>Description: This ContestSLEJB session bean acts as an interface for the Contest Entity bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class ContestSLEJB implements SessionBean
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Attributes declaration
     */
    private Connection _oConnection = null;
    private ContestDAX _oContestDAX;
    private String _strCon;
    public SessionContext _EJBContext = null;
    public ContestHome _oContestHome;
    private Contest _oContest;

    /**
     * Constructor of the ContestSLEJB class
     */
    public ContestSLEJB()
    {
    }

    /**
     * Called by the container to create a session bean instance. Its parameters typically
     * contain the information the client uses to customize the bean instance for its use.
     * It requires a matching pair in the bean class and its home interface.
     * @throws EElixirException
     * @throws CreateException
     */
    public void ejbCreate() throws CreateException, EElixirException
    {
    }

    /**
     * A container invokes this method before it ends the life of the session object. This
     * happens as a result of a client's invoking a remove operation, or when a container
     * decides to terminate the session object after a timeout. This method is called with
     * no transaction context.
     */
    public void ejbRemove()
    {
    }

    /**
     * The activate method is called when the instance is activated from its 'passive' state.
     * The instance should acquire any resource that it has released earlier in the ejbPassivate()
     * method. This method is called with no transaction context.
     */
    public void ejbActivate()
    {
    }

    /**
     * The passivate method is called before the instance enters the 'passive' state. The
     * instance should release any resources that it can re-acquire later in the ejbActivate()
     * method. After the passivate method completes, the instance must be in a state that
     * allows the container to use the Java Serialization protocol to externalize and store
     * away the instance's state. This method is called with no transaction context.
     */
    public void ejbPassivate()
    {
    }

    /**
     * Set the associated session context. The container calls this method after the instance
     * creation. The enterprise Bean instance should store the reference to the context
     * object in an instance variable. This method is called with no transaction context.
     * @param sc SessionContext
     */
    public void setSessionContext(SessionContext sc)
    {
        this._EJBContext = sc;
    }

    /**
     * Gets the data based on the parameter of DVO
     * @param a_oResultObject Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     */
    public String searchContest(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        try
        {
            _oContestDAX = (ContestDAX) getDAX();
            _strCon = _oContestDAX.getContest(a_oResultObject);
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();

            Exception e = ejbex.getCausedByException();

            if (e instanceof EElixirException)
            {
                throw (EElixirException) e;
            }
            else
            {
                throw ejbex;
            }
        }
        catch (EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }

        return _strCon;
    }

    /**
     * Gets the Data depending on the Seq No
     * @param a_lcontestseqnbr long
     * @return ContestResult
     * @throws FinderException
     * @throws EElixirException
     */
    public ContestResult searchContest(long a_lcontestseqnbr)
        throws FinderException, EElixirException
    {
        ContestResult oContestResult = null;

        try
        {
            _oContestHome = getContestHome();

            ContestPK _oContestPK = new ContestPK(a_lcontestseqnbr);

            //_oContestPK.setContestSeqNbr(a_lcontestseqnbr);
            _oContest = _oContestHome.findByPrimaryKey(_oContestPK);

            oContestResult = _oContest.getContestResult();
        }
        catch (FinderException fe)
        {
            _EJBContext.setRollbackOnly();
            _oLogger.debug("ContestSLEJB--FinderException " + fe);
            throw new EElixirException(fe, "P9505");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            _oLogger.debug("ContestSLEJB--RemoteEXception " + rex);
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            _oLogger.debug("ContestSLEJB--EJBException " + ejbex);
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            _oLogger.debug("ContestSLEJB--EElixirException " + eex);
            throw eex;
        }

        return oContestResult;
    }

    /**
     * Updates data into Contest
     * @param a_oContestResult ContestResult
     * @throws FinderException
     * @throws EElixirException
     */
    public void updateContest(ContestResult a_oContestResult)
        throws FinderException, EElixirException
    {
        ContestResult oContestResult = null;

        try
        {
            String strAgentCd = a_oContestResult.getAgentCd();
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);

            if (strAgentCd != null)
            {
                if (!strAgentCd.trim().equals(""))
                {
                    ArrayList al = new ArrayList();
                    al.add(new Integer(DataConstants.AGENCY));

                    if (!_oCommonSL.validateAgentAgency(strAgentCd, al))
                    {
                        throw new EElixirException("p5124");
                    }
                }
            }

            _oContestHome = getContestHome();

            ContestPK _oContestPK = new ContestPK(a_oContestResult.getContestSeqNbr()
                                                                  .longValue());

            //_oContestPK.setContestSeqNbr(a_oContestResult.getContestSeqNbr().longValue());
            _oContest = _oContestHome.findByPrimaryKey(_oContestPK);

            ContestResult con_ContestResult = _oContest.getContestResult();

            if ((con_ContestResult.getTsDtUpdated() != null) &&
                    (!con_ContestResult.getTsDtUpdated().equals(a_oContestResult.getTsDtUpdated())))
            {
                throw new EElixirException("P1100");
            }

            ContestEligibilityCriteria con_oContestEligibilityCriteria = con_ContestResult.getContestEligibilityCriteria();
            ContestEligibilityCriteria a_oContestEligibilityCriteria = a_oContestResult.getContestEligibilityCriteria();

            if ((con_oContestEligibilityCriteria.getTsDtUpdated() != null) &&
                    (!con_oContestEligibilityCriteria.getTsDtUpdated().equals(a_oContestEligibilityCriteria.getTsDtUpdated())))
            {
                throw new EElixirException("P1100");
            }

            if ((con_oContestEligibilityCriteria.getTsDtUpdated() != null) &&
                    (!con_oContestEligibilityCriteria.getTsDtUpdated().equals(a_oContestEligibilityCriteria.getTsDtUpdated())))
            {
                throw new EElixirException("P1100");
            }

            _oContestDAX = (ContestDAX) getDAX();

            _oContest.setContestResult(a_oContestResult);
        }
        catch (CreateException cex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(cex, "P9502");
        }
        catch (FinderException fe)
        {
            _EJBContext.setRollbackOnly();
            _oLogger.debug("ContestSLEJB--FinderException " + fe);
            throw new EElixirException(fe, "P9502");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            _oLogger.debug("ContestSLEJB--RemoteEXception " + rex);
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            _oLogger.debug("ContestSLEJB--EJBException " + ejbex);
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            _oLogger.debug("ContestSLEJB--EElixirException " + eex);
            throw eex;
        }
        finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eElex) {
				throw eElex;
			}
		}
    }

    /**
     * Creates the Data from the CHMSLEJB
     * @param a_oContestResult ContestResult
     * @return long
     * @throws EJBException
     * @throws EElixirException
     */
    public long createContest(ContestResult a_oContestResult)
        throws EJBException, EElixirException
    {
        long lcontestseqnbr = 0;

        try
        {
            _oContestHome = getContestHome();

            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);

            String strAgentCd = a_oContestResult.getAgentCd();

            if (strAgentCd != null)
            {
                if (!strAgentCd.trim().equals(""))
                {
                    ArrayList al = new ArrayList();
                    al.add(new Integer(DataConstants.AGENCY));

                    if (!_oCommonSL.validateAgentAgency(strAgentCd, al))
                    {
                        throw new EElixirException("p5215");
                    }
                }
            }

            _oContest = _oContestHome.create(a_oContestResult);
            lcontestseqnbr = ((ContestPK) _oContest.getPrimaryKey()).getContestSeqNbr();
        }
        catch (CreateException cex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(cex, "P9503");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();

            //throw new EElixirException(ejbex, "P3025");
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();

            throw eex;
        }

        //return ContestResult;
        return lcontestseqnbr;
    }

    /**
    * Invoked by        the        session        bean to        look up        the        Contest EJB. for Deleting a Contest
    * @param  a_lComProjSeqNbr long
    * @throws RemoveException
    * @throws EElixirException
    * @throws EJBException
    */
    public void deleteContest(ContestResult a_oContestResult)
        throws RemoveException, EJBException, EElixirException
    {
        try
        {
            _oContestHome = getContestHome();

            ContestPK oContestPK = new ContestPK();

            oContestPK.setContestSeqNbr(a_oContestResult.getContestSeqNbr()
                                                        .longValue());

            Contest oContest = _oContestHome.findByPrimaryKey(oContestPK);

            oContest.remove();
        }
        catch (FinderException fex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(fex, "P9505");
        }
        catch (RemoveException rex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P9513");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }
    }

    /**
     * Gets the Home object.
     * @return ContestHome
     * @throws EElixirException
     */
    private ContestHome getContestHome() throws EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

        ContestHome oContestHome = (ContestHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContestHome"), ContestHome.class);

        return oContestHome;
    }

    /**
     * Gets the Dax object and sets the connection on it.
     * @return ContestDAX
     * @throws EElixirException
     */
    private ContestDAX getDAX() throws EElixirException
    {
        _oConnection = DBConnection.getConnection();

        CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        ContestDAX _oContestDAX = (ContestDAX) theDAXFactory.createDAX(theDAXFactory.CONTESTDAX);
        _oContestDAX.setConnection(_oConnection);

        return _oContestDAX;
    }

    private CommonSL getCommonSL(String strHome, Class cHomeClass)
        throws RemoteException, EElixirException, CreateException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        CommonSLHome oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        CommonSL oCommonSL = oCommonSLHome.create();

        return oCommonSL;
    }
}
