/********************************************************************
*
*  PROJECT                        : PRUDENTIAL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : ContestSL.java
*  AUTHOR                         : Pallav Laddha
*  VERSION                        : 1.0
*  CREATION DATE                  : September 20, 2002
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION        DATE            BY         REASON
*--------------------------------------------------------------------------------
*  1.1         30Jan             Pallav     Added delete functionality
*  2.1         27/09/2003        Dipti F	UT Rework 
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.contest.ejb.sessionbean;

import java.rmi.RemoteException;

import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;

import com.mastek.eElixir.channelmanagement.contest.util.ContestResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This ContestSL Local interface provides method for getting the data from Contest bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public interface ContestSL extends EJBObject
{
    /**
     * Gets the data based on the parameter of DVO
     * @param a_oResultObject Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     * @throws RemoteException
     */
    public String searchContest(Object a_oResultObject)
        throws EElixirException, FinderException, RemoteException;

    /**
      * Gets the Data depending on the Seq No
      * @param a_lcontestseqnbr long
      * @return ContestResult
      * @throws FinderException
      * @throws EElixirException
      * @throws RemoteException
      */
    public ContestResult searchContest(long a_lcontestseqnbr)
        throws FinderException, EElixirException, RemoteException;

    /**
     * Creates the Data from the CHMSLEJB
     * @param a_oContestResult ContestResult
     * @return long
     * @throws EJBException
     * @throws EElixirException
     * @throws RemoteException
     */
    public long createContest(ContestResult a_oContestResult)
        throws EJBException, EElixirException, RemoteException;

    /**
     * Updates data into Contest
     * @param a_oContestResult ContestResult
     * @throws FinderException
     * @throws EElixirException
     * @throws RemoteException
     */
    public void updateContest(ContestResult a_oContestResult)
        throws FinderException, EElixirException, RemoteException;

    /**
     * Deletes the Data from the CHMSLEJB
     * @param a_oContestResult ContestResult
     * @throws EJBException
     * @throws EElixirException
     * @throws RemoteException
     * @throws RemoveException
     */
    public void deleteContest(ContestResult a_oContestResult)
        throws RemoveException, EJBException, EElixirException, RemoteException;
}
