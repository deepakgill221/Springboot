/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContestEligibilityCriteria.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Contest Eligibility Criteria</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.contest.util;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class ContestEligibilityCriteria extends UserData implements Serializable
{

   /**
    * Header Sequence Number
    */
   protected Long _lContestSeqNbr = null;

   /**
    * Detail Contest Type
    */
   protected Short _nContestDetailType = null;

   /**
    * Month From
    */
   protected Short _nMonthFrom = null;

   /**
    * Month To
    */
   protected Short _nMonthTo = null;

   /**
    * Criteria Function Name
    */
   protected Short _nCritFunction = null;

    /**
    * Eligibility Value
    */
   protected String _strElgbleValue = null;


   /**
    * @roseuid 3DB3A48B0373
    */
   public ContestEligibilityCriteria()
   {

   }
  public Long getContestSeqNbr() {
    return _lContestSeqNbr;
  }
  public void setContestSeqNbr(Long a_lContestSeqNbr) {
    this._lContestSeqNbr = a_lContestSeqNbr;
  }
  public Short getContestDetailType() {
    return _nContestDetailType;
  }
  public void setContestDetailType(Short a_nContestDetailType) {
    this._nContestDetailType = a_nContestDetailType;
  }
  public Short getCritFunction() {
    return _nCritFunction;
  }
  public void setCritFunction(Short a_nCritFunction) {
    this._nCritFunction = a_nCritFunction;
  }
  public Short getMonthFrom() {
    return _nMonthFrom;
  }
  public void setMonthFrom(Short a_nMonthFrom) {
    this._nMonthFrom = a_nMonthFrom;
  }
  public Short getMonthTo() {
    return _nMonthTo;
  }
  public void setMonthTo(Short a_nMonthTo) {
    this._nMonthTo = a_nMonthTo;
  }
  public String getElgbleValue() {
    return _strElgbleValue;
  }
  public void setElgbleValue(String a_strElgbleValue) {
    this._strElgbleValue = a_strElgbleValue;
  }
  public String toString(){
    String retValue = "";
    retValue = retValue + "_lContestSeqNbr:" + _lContestSeqNbr + "\n";
    retValue = retValue + "_nContestDetailType:" + _nContestDetailType + "\n";
    retValue = retValue + "_nMonthFrom:" + _nMonthFrom + "\n";
    retValue = retValue + "_nMonthTo:" + _nMonthTo + "\n";

    retValue = retValue + "_nCritFunction:" + _nCritFunction + "\n";
    retValue = retValue + "_strElgbleValue:" + _strElgbleValue + "\n";
    return retValue;
  }
}
