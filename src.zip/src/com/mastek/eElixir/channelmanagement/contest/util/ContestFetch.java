/********************************************************************
*
*  PROJECT                        : PRUDENTIAL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : ContestFetch.java
*  AUTHOR                         : Pallav Laddha
*  VERSION                        : 1.0
*  CREATION DATE                  : October 20, 2002
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE        BY       REASON
*--------------------------------------------------------------------------------
*  2.1     27/09/2003  Dipti F  UT Rework
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * ContestFetch is the Utility Class for fetching parameter for Contest
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.contest.util;

import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;


public class ContestFetch
{
    //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor of the ContestFetch class
     */
    public ContestFetch()
    {
    }

    /**
     * This Fetches all the paramater for benefit except primary key
     * @param a_oRequest HttpServletRequest object.
     * @return ContestResult
     * @throws EElixirException
     */
    public ContestResult fetchContest(HttpServletRequest a_oRequest)
    {
        ContestResult oContestResult = null;

        //ContestEvaluationCriteria oContestEvaluationCriteria = null;
        ContestEligibilityCriteria oContestEligibilityCriteria = null;
        String dtUpdated = a_oRequest.getParameter("dtUpdated");

        HttpSession session = a_oRequest.getSession();
        String _strUserId = (String) session.getAttribute("username");

        String strContestDesc = a_oRequest.getParameter("strContestDesc").trim();
        Short nContestType = new Short(a_oRequest.getParameter("nContestType")
                                                 .trim());

        GregorianCalendar dtEffFrom = DateUtil.retGCDate(a_oRequest.getParameter(
                    "dtEffFrom").trim());
        GregorianCalendar dtEffTo = null;

        if (a_oRequest.getParameter("dtEffTo").trim().equals(""))
        {
            dtEffTo = DateUtil.retGCDate(DataConstants.MAX_DATE_LIMIT);
        }
        else
        {
            dtEffTo = DateUtil.retGCDate(a_oRequest.getParameter("dtEffTo")
                                                   .trim());
        }

        Character cChannelType = new Character(a_oRequest.getParameter(
                    "cChannelType").trim().charAt(0));
        String strDesgnCd = a_oRequest.getParameter("strDesgnCd").trim();
        String strSubChannelType = a_oRequest.getParameter("strSubChannelType")
                                             .trim();
        String strAgentCd = a_oRequest.getParameter("strAgencyCd");
        Short nFreqOfCalc = new Short(a_oRequest.getParameter("nFreqOfCalc")
                                                .trim());
        Short nRewardFreq = new Short(a_oRequest.getParameter("nRewardFreq")
                                                .trim());

        Short nRewardType = new Short(a_oRequest.getParameter("nRewardType")
                                                .trim());
        Double dRewardAmnt = null;

        if ((nRewardFreq.shortValue() != DataConstants.REWARD_FREQUENCY_PERIODIC) &&
                (nRewardType.shortValue() == DataConstants.REWARD_TYPE_GIFT_COUPON))
        {
            dRewardAmnt = new Double(a_oRequest.getParameter("dRewardAmntMain")
                                               .trim());
        }

        String strRewardDesc = a_oRequest.getParameter("strRewardDesc").trim();

        Short nIsSpecificContest = new Short(a_oRequest.getParameter(
                    "nIsSpecificContest").trim());
        String strCritFunction = a_oRequest.getParameter("nCritFunctionEV")
                                           .trim();

        oContestResult = new ContestResult();

        if ((dtUpdated != null) && !dtUpdated.trim().equals(""))
        {
            oContestResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated));
        }

        oContestResult.setContestDesc(strContestDesc);
        oContestResult.setContestType(nContestType);
        oContestResult.setDtEffFrom(dtEffFrom);

        oContestResult.setDtEffTo(dtEffTo);
        oContestResult.setChannelType(cChannelType);

        oContestResult.setSubChannelType(strSubChannelType);
        oContestResult.setDesgnCd(strDesgnCd);

        if ((strCritFunction != null) && !strCritFunction.trim().equals(""))
        {
            oContestResult.setCritFunction(new Short(strCritFunction.trim()));
        }

        oContestResult.setFreqOfCalc(nFreqOfCalc);
        oContestResult.setRewardFreq(nRewardFreq);
        oContestResult.setRewardType(nRewardType);
        oContestResult.setRewardAmnt(dRewardAmnt);
        oContestResult.setRewardDesc(strRewardDesc);

        oContestResult.setIsSpecificContest(nIsSpecificContest);

        oContestResult.setAgentCd(strAgentCd);

        oContestResult.setUserId(_strUserId);

        Short nCritFunction = null;

        Short nMonthFrom = null;
        Short nMonthTo = null;

        //Now Fetching record for Contest Eligibility
        //Setting the value to null since it may be present or not present.
        nMonthFrom = null;
        nMonthTo = null;
        nCritFunction = null;

        Short nContestDetailType = new Short(a_oRequest.getParameter(
                    "nContestDetailTypeEL").trim());

        if (!a_oRequest.getParameter("nMonthFromEL").trim().equals(""))
        {
            nMonthFrom = new Short(a_oRequest.getParameter("nMonthFromEL").trim());
            nMonthTo = new Short(a_oRequest.getParameter("nMonthToEL").trim());
            nCritFunction = new Short(a_oRequest.getParameter("nCritFunctionEL")
                                                .trim());
        }

        String strElgbleValue = "";

        if (a_oRequest.getParameter("strElgbleValueEL") != null)
        {
            strElgbleValue = a_oRequest.getParameter("strElgbleValueEL").trim();
        }

        String cont_elgibility_dtUpdated = a_oRequest.getParameter(
                "cont_elgibility_dtUpdated");
        oContestEligibilityCriteria = new ContestEligibilityCriteria();
        oContestEligibilityCriteria.setContestDetailType(nContestDetailType);
        oContestEligibilityCriteria.setCritFunction(nCritFunction);
        oContestEligibilityCriteria.setElgbleValue(strElgbleValue);
        oContestEligibilityCriteria.setMonthFrom(nMonthFrom);
        oContestEligibilityCriteria.setMonthTo(nMonthTo);
        oContestEligibilityCriteria.setUserId(_strUserId);

        if ((cont_elgibility_dtUpdated != null) &&
                !cont_elgibility_dtUpdated.trim().equals(""))
        {
            oContestEligibilityCriteria.setTsDtUpdated(Timestamp.valueOf(
                    cont_elgibility_dtUpdated));
        }
        oContestResult.setContestEligibilityCriteria(oContestEligibilityCriteria);

        return oContestResult;
    }
}
