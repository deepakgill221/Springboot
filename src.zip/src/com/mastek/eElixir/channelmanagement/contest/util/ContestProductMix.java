/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContestProductMix.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description: for ContestProductMix</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.contest.util;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class ContestProductMix extends UserData implements Serializable
{
   protected Long _lContestseqnbr;
   protected String _strProdCd;
   protected Integer _iProdVer;
   protected Double _dProdPerc;
   protected String _strStatusFlag;
   /**
   * Constructor
   */
   public ContestProductMix()
   {

   }
  public Double getProdPerc() {
    return _dProdPerc;
  }
  public void setProdPerc(Double a_dProdPerc) {
    this._dProdPerc = a_dProdPerc;
  }
  public Integer getProdVer() {
    return _iProdVer;
  }
  public void setProdVer(Integer a_iProdVer) {
    this._iProdVer = a_iProdVer;
  }
  public Long getContestSeqNbr() {
    return _lContestseqnbr;
  }
  public void setContestSeqNbr(Long a_lContestseqnbr) {
    this._lContestseqnbr = a_lContestseqnbr;
  }
  public String getProdCd() {
    return _strProdCd;
  }
  public void setProdCd(String a_strProdCd) {
    this._strProdCd = a_strProdCd;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }
  public String toString(){
    String retValue = "";
    retValue = retValue + "_lContestseqnbr:" + _lContestseqnbr + "\n";
    retValue = retValue + "_dProdPerc:" + _dProdPerc + "\n";
    retValue = retValue + "_strProdCd:" + _strProdCd + "\n";
    retValue = retValue + "_iProdVer:" + _iProdVer + "\n";
    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";
    return retValue;

  }
}
