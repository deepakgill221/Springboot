/********************************************************************
*
*  PROJECT                        : PRUDENTIAL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : ContestResult.java
*  AUTHOR                         : Pallav Laddha
*  VERSION                        : 1.0
*  CREATION DATE                  : December 16, 2002
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION        DATE                  BY               REASON
*--------------------------------------------------------------------------------
*  2.1           27/09/2003           Dipti F   		UT Rework
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Contest Result</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.contest.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;


public class ContestResult extends UserData implements Serializable
{
    private Long _lContestSeqNbr = null;
    private String _strContestDesc = null;
    private Short _nContestType = null;
    private GregorianCalendar _dtEffFrom = null;
    private GregorianCalendar _dtEffTo = null;
    private Character _cChannelType = null;
    private String _strSubChannelType = null;
    private String _strDesgnCd = null;
    private Short _nFreqOfCalc = null;
    private Short _nRewardFreq = null;
    private Short _nStartMonth = null;
    private Short _nRef = null;
    private Short _nIsInclOrExcl = null;
    private Short _nRewardType = null;
    private Double _dRewardAmnt = null;
    private String _strRewardDesc = null;
    private Short _nIsSpecificContest = null;
    private String _strAgentCd = null;
    private ArrayList _arrProductMix = null;
    private Short _nCritFunction = null;
    private ContestEligibilityCriteria _oContestEligibilityCriteria;

    public ContestResult()
    {
    }

    public Short getCritFunction()
    {
        return _nCritFunction;
    }

    public void setCritFunction(Short a_nCritFunction)
    {
        this._nCritFunction = a_nCritFunction;
    }

    public void setAgentCd(String a_strAgentCd)
    {
        this._strAgentCd = a_strAgentCd;
    }

    public String getAgentCd()
    {
        return this._strAgentCd;
    }

    public Character getChannelType()
    {
        return _cChannelType;
    }

    public void setChannelType(Character a_cChannelType)
    {
        this._cChannelType = a_cChannelType;
    }

    public String getSubChannelType()
    {
        return _strSubChannelType;
    }

    public void setSubChannelType(String a_strSubChannelType)
    {
        this._strSubChannelType = a_strSubChannelType;
    }

    public GregorianCalendar getDtEffFrom()
    {
        return _dtEffFrom;
    }

    public void setDtEffFrom(GregorianCalendar a_dtEffFrom)
    {
        this._dtEffFrom = a_dtEffFrom;
    }

    public GregorianCalendar getDtEffTo()
    {
        return _dtEffTo;
    }

    public void setDtEffTo(GregorianCalendar a_dtEffTo)
    {
        this._dtEffTo = a_dtEffTo;
    }

    public Long getContestSeqNbr()
    {
        return _lContestSeqNbr;
    }

    public void setContestSeqNbr(Long a_lContestSeqNbr)
    {
        this._lContestSeqNbr = a_lContestSeqNbr;
    }

    public Short getContestType()
    {
        return _nContestType;
    }

    public void setContestType(Short a_nContestType)
    {
        this._nContestType = a_nContestType;
    }

    public Short getFreqOfCalc()
    {
        return _nFreqOfCalc;
    }

    public void setFreqOfCalc(Short a_nFreqOfCalc)
    {
        this._nFreqOfCalc = a_nFreqOfCalc;
    }

    public Short getRewardFreq()
    {
        return _nRewardFreq;
    }

    public void setRewardFreq(Short a_nRewardFreq)
    {
        this._nRewardFreq = a_nRewardFreq;
    }

    public Short getRef()
    {
        return _nRef;
    }

    public void setRef(Short a_nRef)
    {
        this._nRef = a_nRef;
    }

    public Short getStartMonth()
    {
        return _nStartMonth;
    }

    public void setStartMonth(Short a_nStartMonth)
    {
        this._nStartMonth = a_nStartMonth;
    }

    public ContestEligibilityCriteria getContestEligibilityCriteria()
    {
        return _oContestEligibilityCriteria;
    }

    public void setContestEligibilityCriteria(
        ContestEligibilityCriteria a_oContestEligibilityCriteria)
    {
        this._oContestEligibilityCriteria = a_oContestEligibilityCriteria;
    }

    public String getContestDesc()
    {
        return _strContestDesc;
    }

    public void setContestDesc(String a_strContestDesc)
    {
        this._strContestDesc = a_strContestDesc;
    }

    public String getDesgnCd()
    {
        return _strDesgnCd;
    }

    public void setDesgnCd(String a_strDesgnCd)
    {
        this._strDesgnCd = a_strDesgnCd;
    }

    public Short getIsInclOrExcl()
    {
        return _nIsInclOrExcl;
    }

    public void setIsInclOrExcl(Short a_nIsInclOrExcl)
    {
        this._nIsInclOrExcl = a_nIsInclOrExcl;
    }

    public Short getIsSpecificContest()
    {
        return _nIsSpecificContest;
    }

    public void setIsSpecificContest(Short a_nIsSpecificContest)
    {
        this._nIsSpecificContest = a_nIsSpecificContest;
    }

    public Double getRewardAmnt()
    {
        return _dRewardAmnt;
    }

    public void setRewardAmnt(Double a_dRewardAmnt)
    {
        this._dRewardAmnt = a_dRewardAmnt;
    }

    public Short getRewardType()
    {
        return _nRewardType;
    }

    public void setRewardType(Short a_nRewardType)
    {
        this._nRewardType = a_nRewardType;
    }

    public String getRewardDesc()
    {
        return _strRewardDesc;
    }

    public void setRewardDesc(String a_strRewardDesc)
    {
        this._strRewardDesc = a_strRewardDesc;
    }

    public ArrayList getArrProductMix()
    {
        return _arrProductMix;
    }

    public void setArrProductMix(ArrayList a_arrProductMix)
    {
        this._arrProductMix = a_arrProductMix;
    }

    public String toString()
    {
        String retValue = "";
        retValue = retValue + "_lContestSeqNbr:" + _lContestSeqNbr + "\n";
        retValue = retValue + "_strContestDesc:" + _strContestDesc + "\n";
        retValue = retValue + "_nContestType:" + _nContestType + "\n";
        retValue = retValue + "_dtEffFrom:" + _dtEffFrom + "\n";
        retValue = retValue + "_dtEffTo:" + _dtEffTo + "\n";
        retValue = retValue + "_cChannelType:" + _cChannelType + "\n";
        retValue = retValue + "_strDesgnCd:" + _strDesgnCd + "\n";
        retValue = retValue + "_nFreqOfCal:" + _nFreqOfCalc + "\n";
        retValue = retValue + "_nRewardFreq:" + _nRewardFreq + "\n";
        retValue = retValue + "_nStartMonth:" + _nStartMonth + "\n";
        retValue = retValue + "_nRef:" + _nRef + "\n";
        retValue = retValue + "_nRewardType:" + _nRewardType + "\n";
        retValue = retValue + "_nRewardAmnt:" + _dRewardAmnt + "\n";
        retValue = retValue + "_strRewardDesc:" + _strRewardDesc + "\n";
        retValue = retValue + "_nIsSpecificContest:" + _nIsSpecificContest +
            "\n";
        retValue = retValue + "_nIsInclOrExcl:" + _nIsInclOrExcl + "\n";
        retValue = retValue + "_oContestEligibilityCriteria:" +
            _oContestEligibilityCriteria + "\n";
        retValue = retValue + "_arrProductMix:" + _arrProductMix + "\n";
        retValue = retValue + "strAgentCd:" + _strAgentCd + "\n";

        return retValue;
    }
}
