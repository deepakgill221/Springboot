/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContestListSearch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get ContestListSearch is the Action Class for Getting a list of Contest ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.contest.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class ContestListSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the ContestListSearch class
   */
  public ContestListSearch()
  {

  }

  /**
   * This method uses the search data and to populate Contest
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    Object contestResult = null;
    String result =null;
    try{
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);


      String strContestDesc   = a_oRequest.getParameter("strContestDesc");
      String nContestType     = a_oRequest.getParameter("nContestType");
      String dtEffFrom    = a_oRequest.getParameter("dtEffFrom");
      String dtEffTo      = a_oRequest.getParameter("dtEffTo");
      String cChannelType = a_oRequest.getParameter("cChannelType");
      String strSubChannelType = a_oRequest.getParameter("strSubChannelType");
      String strDesgnCd   = a_oRequest.getParameter("strDesgnCd");


      SearchData oSearchData = new SearchData();
      oSearchData.setTask1(strContestDesc);
      oSearchData.setTask2(nContestType);
      if(!dtEffFrom.trim().equals("")){
        oSearchData.setTaskDate1(DateUtil.retGCDate(dtEffFrom.trim()));
      }
      else{
        oSearchData.setTaskDate1(null);
      }

      if(!dtEffTo.trim().equals("")){
        oSearchData.setTaskDate2(DateUtil.retGCDate(dtEffTo.trim()));
      }
      else{
        oSearchData.setTaskDate2(null);
      }

      oSearchData.setTask3(cChannelType);
      oSearchData.setTask4(strDesgnCd);
      oSearchData.setTask5(strSubChannelType);
      contestResult = oSearchData;
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);
      result = remoteCHMSL.searchContest(contestResult);
      log.debug("ContestListSearch--result accessed");
      setResult(result);
      log.debug("ContestListSearch--result is set");
    }


    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "P9505");
    }
  }


}