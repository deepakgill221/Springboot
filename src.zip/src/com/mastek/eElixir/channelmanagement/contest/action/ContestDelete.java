/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContestDelete.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : Jan 20, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * ContestDelete is the Action Class for creating a new Contest.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.contest.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.contest.util.ContestFetch;
import com.mastek.eElixir.channelmanagement.contest.util.ContestResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class ContestDelete extends Action
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the ContestDelete class
   */
  public ContestDelete()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ContestResult oContestResult = null;
    ContestFetch oContestFetch = new ContestFetch();
    try{
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      log.debug("ContestDelete--Before fetching parameters");
      oContestResult = oContestFetch.fetchContest(a_oRequest);
      oContestResult.setContestSeqNbr(new Long(a_oRequest.getParameter("lContestSeqNbr").trim()));
      log.debug("ContestDelete--After fetching parameters");
      log.debug("ContestDelete--before create Contest");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
     remoteCHMSL.deleteContest(oContestResult);


      //setResult(oContestResult);
      log.debug("ContestDelete--result accessed");

    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oContestResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oContestResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", oContestResult);
      throw new EElixirException(fex, "P9505");
    }
    catch(RemoveException rex)
    {
      a_oRequest.setAttribute("ResultObject", oContestResult);
      throw new EElixirException(rex, "P9513");
    }
    catch(EElixirException eex)
    {
      log.debug("ContestDelete--Inside catch of EElixir exception in process of ContestDelete");
      a_oRequest.setAttribute("ResultObject", oContestResult);
      throw eex;
    }
  }

}