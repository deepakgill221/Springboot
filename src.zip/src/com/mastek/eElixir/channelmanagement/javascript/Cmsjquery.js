/**
 *
 * Filename: Cmsjquery.js
 * Description:This file is used for all client/server side javascript/jquery/ajax 
   functionality for channel management module.
 * Date:19-Oct-2010
 * Copyright: Copyright (c) 2010
 * Company: Mastek Ltd
 * Author : Anantha Reddy Nalla
 * version 1.0
 */


// Anantha_FSD_Duplicate_myFlow_Application_Niumber_v1[1].1 Starts
		
		function getDuplicatePANNbrDtl(obj1,obj2)
		{
		     if (checkIfBlank(obj2))
			  {				 
				  obj2.value="";
				  return false;
			  }
			 			  
			$.ajax({url:"CHMController",
					global: false,
      				type: "POST",
					data:({ajaxCall:"Y",
					   // VA_PT changes by Manisha on 19-Aug-16-START
					   // action:"AjaxValidatorCMSAction",
					   action:actionNameEncryption("AjaxValidatorCMSAction"),
					   // VA_PT changes by Manisha on 19-Aug-16-END
					   tempStrAgentCdjq:obj1.value,
					   StrMyFlowAppNbrjq:obj2.value,
					   strDifferentiatorjq:"DuplicateMyFlowNbrChk"
					}),
					dataType: "text",
					async: false,  
					success: function(textdata)
					{
					  	if(textdata!=null&&textdata!='')
						{
							alert("The MyFlow Application Number entered already exists for "+textdata);
							obj2.value="";
							obj2.focus();
								
							//return false;						
						}
					}	
				}); 
				
		} 
		// Anantha_FSD_Duplicate_myFlow_Application_Niumber_v1[1].1 Ends
		