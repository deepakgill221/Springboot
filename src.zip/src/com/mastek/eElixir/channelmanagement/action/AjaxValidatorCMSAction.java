/********************************************************************
 *
 *  PROJECT		    : PRUDENTIAL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME		: ValidateIRDA.java
 *  AUTHOR		    : Prabhat Kumar Krishna
 *  VERSION		    : 1.0
 *  CREATION DATE	: June 04, 2009
 *  COMPANY		    : Qualtech Consultants.
 *  COPYRIGHT		: COPYRIGHT (C) 2009.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *1.0		04/06/2009	Prabhat Kr.		For validation IRDA tab should be enabled or disabled
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMJQueryData;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

/**
 * @author Anantha Reddy Nalla
 * //Anantha_FSD_Duplicate_myFlow_Application_Niumber_v1[1].1
 *
 */
public class AjaxValidatorCMSAction extends Action{

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	  /**
	   * Default Constructor
	   */
	
		public AjaxValidatorCMSAction()
		{
			
		}
	
	  /**
	   * This method makes a remote call to the Session bean which in turn makes a local
	   * call to all other bean and populates the xml data
	   * @param : request - Request object.
	   * @throws EElixirException
	   */
	  public void process(HttpServletRequest request)  throws EElixirException
	  {
		  log.debug("AjaxValidatorAgentAction--process--Start");
		
		  try
		  {   
			  log.debug("AjaxValidatorAgentAction--process--CHM bean Look Up " );
		      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
		      log.debug("AjaxValidatorAgentAction--process--CHM bean Look Up Done " + remoteCHMSL );
		      
		      
		      String strDifferentiatorFlag =getStringValue(request.getParameter("strDifferentiatorjq"));
		      CHMJQueryData oCHMJQueryData=new CHMJQueryData();
		      String  strAgentCode=null;
		      
		      if(strDifferentiatorFlag!=null)		    		  
		      {
		    	  if(strDifferentiatorFlag.equals("DuplicateMyFlowNbrChk"))
		    	  {
		    		 
		    		  oCHMJQueryData.setTask1(getStringValue(request.getParameter("StrMyFlowAppNbrjq")));
		    		  
		    		  oCHMJQueryData.setTask2(getStringValue(request.getParameter("tempStrAgentCdjq")));
		    		  
		    		  strAgentCode = remoteCHMSL.validateDuplicateMyFlowAppNumber(oCHMJQueryData);
		    		  log.debug("AjaxValidatorAgentAction--process >> "+strAgentCode);
		    	  }
		      }
		  
		      
		      log.debug("AjaxValidatorAgentAction--process--Done");
		    		      
		      setResult(strAgentCode);
		      
		  }
		  catch(Exception ex)
		  {			  
		      setResult(ex.getMessage());
		      //xml=XMLConverter.addTaginXML(XMLConverter.getBlankXML(), "info", e.getMessage());
		  }
	  }
	
}
