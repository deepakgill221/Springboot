/********************************************************************
*
*  PROJECT					: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME					: UnderConstruction.java
*  AUTHOR					: VINAY CEREJO
*  VERSION					: 1.0
*  CREATION DATE		: November  06, 2002
*  COMPANY				: Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.action;

/**
 * Just a simple Action class to display Under COnstruction banner
 * Copyright (c) 2002 Mastek Ltd
 * Date       06/11/2002
 * @author    Vinay Cerejo
 * @version 1.0
 */


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class UnderConstruction extends Action
{
	
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

   /**
    * @roseuid 3B94961803B7
    */
   public UnderConstruction()
   {

   }

   /**
   * blank process method to follow the MVC architecture, 
   * @param : request - Request object.
   * 
   * @throws EElixirException
   */
   public void process(HttpServletRequest request)  throws EElixirException
   {
		log.debug("executeSQLLoader--Begin");
		Process p = null;
		BufferedReader err=null;
		String a_strLoaderParam = "cmd /c dir";
		try
		{ 
			log.debug("executeSQLLoader--CMD: " +  a_strLoaderParam);
			p = Runtime.getRuntime().exec(a_strLoaderParam);
			//p.waitFor();
			err	= new BufferedReader(new InputStreamReader(p.getInputStream()));		
			String line;		
			while ((line = err.readLine()) != null)	System.out.println(line);
			
		}
		catch (Exception ex)	{
			log.debug("Execution Halted Midway. ");
			log.debug("Cause : " + ex);
			ex.printStackTrace();

		}
//		FindBug_Fix_SUNAINA_STARTS
		finally{
			try {
				err.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
//		FindBug_Fix_SUNAINA_ENDED
		log.debug("executeSQLLoader--End");
		log.debug("Execution Complete. Exit with "  + p.exitValue());
		//return p.exitValue();

   }
}
