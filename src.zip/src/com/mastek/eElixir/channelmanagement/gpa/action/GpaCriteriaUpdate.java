/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME					: GpaCriteriaUpdate.java
*  AUTHOR					: Sunaina Bhat
*  VERSION					: 1.0
*  CREATION DATE		    : July 03, 2008
*  COMPANY				    : Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.gpa.action;


import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

public class GpaCriteriaUpdate extends Action
{
	 String strSeqNbr = null;
	    String strParameter = null;
   /**
    * Constructer
    */

   public GpaCriteriaUpdate()
   {

   }


   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean .
   * @param : ResultObject object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */

   public void process(HttpServletRequest request)  throws EElixirException
   {
	   log.debug("u are in GpaStandardUpdate Action");
     request.setAttribute("actiontype",DataConstants.ACTION_UPDATE);
     CHMSL remoteCHMSL = null;


     try

     {

        setGpaResults(request);
       log.debug("u are back");
       remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
  	  strSeqNbr = request.getParameter("strSeqNbr");
  	  log.debug("strSeqNbr***************"+strSeqNbr);
       strParameter = request.getParameter("strParameter");
       log.debug("strParameter***************"+strParameter);
       log.debug("u befoer updateGpa");
       remoteCHMSL.updateGpaCriteria(_oGpaCriteriaMasterResult);
       log.debug("u after updateGpa");
       _oGpaCriteriaMasterResult = remoteCHMSL.searchGpaCriteria(Long.parseLong(strSeqNbr),strParameter);

        setResult(_oGpaCriteriaMasterResult);
      }
     catch(FinderException fex)
     {
       request.setAttribute("ResultObject", _oGpaCriteriaMasterResult);
       throw new EElixirException(fex, "P1007");
     }
     catch(RemoteException rex)
     {
       request.setAttribute("ResultObject", _oGpaCriteriaMasterResult);
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       request.setAttribute("ResultObject", _oGpaCriteriaMasterResult);

       throw new EElixirException(cex, "P1007");
     }
     catch(EElixirException eLex)
     {
      log.debug("In GpaUpdate eelixir exception before setting result" + eLex);
      if (eLex.getCustomErrorCode().equalsIgnoreCase("P1100"))
      {
        try
        {
        	_oGpaCriteriaMasterResult = remoteCHMSL.searchGpaCriteria(Long.parseLong(strSeqNbr),strParameter);
          setResult(_oGpaCriteriaMasterResult);
        }
        catch(RemoteException rex)
        {
          request.setAttribute("ResultObject", _oGpaCriteriaMasterResult);
          throw new EElixirException(rex, "P1006");
        }

      }
      request.setAttribute("ResultObject", _oGpaCriteriaMasterResult);
      throw eLex;
     }

   }

   private void setGpaResults(HttpServletRequest a_oRequest)
   {
     strParameter = a_oRequest.getParameter("strParameter");
     String strPoints[] = a_oRequest.getParameterValues("strPoints");
     String strFomPercent[]=a_oRequest.getParameterValues("strFromPercent");
     String strToPercent[]=a_oRequest.getParameterValues("strToPercent");
     String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
     String[] dtUpdated      = a_oRequest.getParameterValues("dtUpdated");
     String SeqNumb[] = a_oRequest.getParameterValues("SeqNumb1");
     strSeqNbr = a_oRequest.getParameter("strSeqNbr");


     HttpSession  session = a_oRequest.getSession();
     String  _strUserId = (String)session.getAttribute("username");
     log.debug("statusFlag"+statusFlag);
     _oGpaCriteriaMasterResult = new GpaCriteriaMasterResult();
     _oGpaCriteriaMasterResult.setParameter(strParameter);
     log.debug("strParameter-->  "+ _oGpaCriteriaMasterResult.getParameter());
     _oGpaCriteriaMasterResult.setSeqNumb(new Long(strSeqNbr));
     log.debug(" strSeqNbr -->  "+ _oGpaCriteriaMasterResult.getSeqNumb());
     if(statusFlag != null)
     {
       for(int i = 0; i < statusFlag.length; i++)
       {
         if(!(statusFlag[i].equals(DataConstants.CLEAR_MODE)) )
         {

        	 _oGpaCriteriaResult = new GpaCriteriaResult();


        	 _oGpaCriteriaResult.setPoints(strPoints[i]);
        	 log.debug("setPoints"+_oGpaCriteriaResult.getPoints());
        	 log.debug("first value");
        	 _oGpaCriteriaResult.setFomPercent(strFomPercent[i]);
        	 log.debug("setFomPercent"+_oGpaCriteriaResult.getFomPercent());
        	 log.debug("2nd value");
        	 _oGpaCriteriaResult.setToPercent(strToPercent[i]);
        	 log.debug("setToPercent"+_oGpaCriteriaResult.getToPercent());
        	 log.debug("3rd value");


        	 _oGpaCriteriaResult.setStatusFlag(statusFlag[i]);
          log.debug("statusFlag"+_oGpaCriteriaResult.getStatusFlag());

          log.debug("u are here");

          if(SeqNumb[i]!=null &&!SeqNumb[i].trim().equals(""))
          {
        	  _oGpaCriteriaResult.setCriteriaSeqNbr(new Long(SeqNumb[i]));
        	  log.debug("setSegSeqNbr"+_oGpaCriteriaResult.getCriteriaSeqNbr());

          }
          else
   	      {
        	  _oGpaCriteriaResult.setCriteriaSeqNbr(null);
        	  log.debug("nulllll setSegSeqNbr"+_oGpaCriteriaResult.getCriteriaSeqNbr());
   	      }

          _oGpaCriteriaResult.setSeqNbr(new Long(strSeqNbr));
          log.debug("setSeqNbr setting in dvo"+_oGpaCriteriaResult.getSeqNbr());

       	 if (dtUpdated[i] != null && !dtUpdated[i].trim().equals(""))
          {
         	  log.debug("u are in dtupdate");
         	 _oGpaCriteriaResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated[i]));
        	 log.debug("setTsDtUpdated"+_oGpaCriteriaResult.getDtUpdated());
          }
       	_oGpaCriteriaResult.setUserId(_strUserId);
         log.debug("End of setting dataaaaaaaaaaaaaaaaaa");
         _oGpaList.add(_oGpaCriteriaResult);

       }
       }
     }
     _oGpaCriteriaMasterResult.setGpaCriteriaResult(_oGpaList);
   }

   //class level variable declarations.
   GpaCriteriaMasterResult _oGpaCriteriaMasterResult=null;
   GpaCriteriaResult _oGpaCriteriaResult = null;
  // String strSeqNbr = null;
   //String strParameter = null;
   ArrayList _oGpaList = new ArrayList() ;
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


}

