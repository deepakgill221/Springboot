/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME		: NewGpaStandardListSearch.java
 *  AUTHOR			: Sunaina Bhat
 *  VERSION			: 1.0
 *  CREATION DATE	: June 24, 2008
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2008.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * Sunaina_Everest_Segmentation_PhaseII_Start
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/


package com.mastek.eElixir.channelmanagement.gpa.action;

/**
 * Called at the beginnning of GpaStandard Create
 * Copyright (c) 2008 Mastek Ltd
 * Date       June 24, 2008
 * @author    Sunaina Bhat
 * @version 1.0
 */

 import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


 public class NewGpaStandardListSearch extends Action
 {


   public NewGpaStandardListSearch()
   {

   }

   /**
    * blank process method to follow the MVC architecture, it just makes the xsl file available to the requested jsp at the beginning
    * @param : request - Request object.
    * @throws EElixirException
    */
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     try
     {
    	 log.debug("you are inside dummy action");
       MenuAccessLog.createMenuAccessLog(a_oRequest);
       a_oRequest.setAttribute("actiontype",DataConstants.ACTION_CREATE);
     }
     catch(RemoteException rex)
     {
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       throw new EElixirException(cex, "P1007");
     }
     catch(EElixirException eex)
     {
       throw eex;
     }

   }
 }