/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME					: GPAMasterListSearch.java
*  AUTHOR					: Sunaina Bhat
*  VERSION					: 1.0
*  CREATION DATE		    : July 01, 2008
*  COMPANY				    : Mastek Ltd.
*  COPYRIGHT			    : COPYRIGHT (C) 2008.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.gpa.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;




/**
 * <p>Title: eElixir</p>
 * <p>Description: Action Class for retrieving the Gpa </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Sunaina Bhat
 * @version 1.0
 */

public class GPACopy extends Action
{


  /**
   * @Constructor
   */
  public GPACopy(){
  }

  /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean and get the Segmentations ArrayList Object
   * @param: request - Request object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest request)  throws EElixirException
  {
    log.debug("u are inside class");
    ArrayList _oGpaList = null;
    request.setAttribute("actiontype", DataConstants.ACTION_CREATE);
    try{

      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      HttpSession  session = request.getSession();
      String  a_strUserId = (String)session.getAttribute("username");
      String a_strDesignation = request.getParameter("strDesignation");
	  String a_strInputDesc = request.getParameter("strInputDesg");
      remoteCHMSL.copyDesignationGpa(a_strDesignation,a_strInputDesc,a_strUserId);
      log.debug("data is copied");

    }
    catch(RemoteException rex)
    {

      throw new EElixirException(rex, "P1006");
    }
   catch(FinderException rex)
    {

      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {

      throw new EElixirException(cex, "P1007");
    }

    catch(EElixirException cex)
    {

      throw cex;
    }


  }
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}

