/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : SegmentCriteriaSearch.java
*  AUTHOR           : Arun Kumar
*  VERSION          : 1.0
*  CREATION DATE    : Mar 03, 2008
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2008.
*  SPEC NAME        : EVEREST
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
*
* Arun_Everest_Segmentation
*
*--------------------------------------------------------------------------------
*
**********************************************************************/
package com.mastek.eElixir.channelmanagement.gpa.action;


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaMasterResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class GpaCriteriaSearch extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor for SegmentCriteriaSearch
     */
    public GpaCriteriaSearch()
    {
    }

    /**
     * The Process Method is used to retrieve the Segment criteria records
     * @param a_oRequest HttpServletRequest
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
    	ArrayList _oGpaList = null;
        String strSeqNbr = null;
        String strParameter = null;
        GpaCriteriaMasterResult _oGpaCriteriaMasterResult = null;

        try
        {
        	 a_oRequest.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);

             CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
             strSeqNbr = a_oRequest.getParameter("strSeqNbr");
             strParameter = a_oRequest.getParameter("strParameter");

             _oLogger.debug("SEQUENCE NUMBER*********"+strSeqNbr);
             _oLogger.debug("strParameter*********"+strParameter);

             _oGpaCriteriaMasterResult = oRemoteCHMSL.searchGpaCriteria(Long.parseLong(strSeqNbr),strParameter);
             _oLogger.debug("u are back from serch");

             setResult(_oGpaCriteriaMasterResult);
             a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);


        }
        catch (RemoteException rex)
        {
			_oLogger.fatal(getClass().getName(),"process","RemoteException "+rex.getMessage());
            a_oRequest.setAttribute("ResultObject", _oGpaCriteriaMasterResult);
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
			_oLogger.fatal(getClass().getName(),"process","CreateException "+cex.getMessage());
            a_oRequest.setAttribute("ResultObject", _oGpaCriteriaMasterResult);
            throw new EElixirException(cex, "P1007");
        }
        catch (EElixirException eex)
        {
			_oLogger.fatal(getClass().getName(),"process","EElixirException "+eex.getMessage());
            a_oRequest.setAttribute("ResultObject", _oGpaCriteriaMasterResult);
            throw eex;
        }
        catch (Exception ex)
        {
			_oLogger.fatal(getClass().getName(),"process","Exception "+ex.getMessage());
            a_oRequest.setAttribute("ResultObject", _oGpaCriteriaMasterResult);
            throw new EElixirException(ex, "P1001");
        }
    }
}

