/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME					: GpaUpdate.java
*  AUTHOR					: Sunaina Bhat
*  VERSION					: 1.0
*  CREATION DATE		    : July 03, 2008
*  COMPANY				    : Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.gpa.action;


import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

public class GpaUpdate extends Action
{

   /**
    * Constructer
    */

   public GpaUpdate()
   {

   }


   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean .
   * @param : ResultObject object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */

   public void process(HttpServletRequest request)  throws EElixirException
   {
	   log.debug("u are in gpaUpdate Action");
     request.setAttribute("actiontype",DataConstants.ACTION_UPDATE);
     CHMSL remoteCHMSL = null;
     try
     {
       setGpaResults(request);
      log.debug("u are back");
       remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
       log.debug("u befoer updateGpa");
       remoteCHMSL.updateGpa(_oGpaList);
       log.debug("u after updateGpa");
       _oGpaList = remoteCHMSL.searchDesignationGpa(request.getParameter("strDesignation"));

        setResult(_oGpaList);
      }
     catch(FinderException fex)
     {
       request.setAttribute("ResultObject", _oGpaList);
       throw new EElixirException(fex, "P1007");
     }
     catch(RemoteException rex)
     {
       request.setAttribute("ResultObject", _oGpaList);
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       request.setAttribute("ResultObject", _oGpaList);

       throw new EElixirException(cex, "P1007");
     }
     catch(EElixirException eLex)
     {
      log.debug("In GpaUpdate eelixir exception before setting result" + eLex);
      if (eLex.getCustomErrorCode().equalsIgnoreCase("P1100"))
      {
        try
        {
        	_oGpaList = remoteCHMSL.searchDesignationGpa(request.getParameter("strDesignation"));
          setResult(_oGpaList);
        }
        catch(RemoteException rex)
        {
          request.setAttribute("ResultObject", _oGpaList);
          throw new EElixirException(rex, "P1006");
        }
        catch(FinderException cex)
        {
          request.setAttribute("ResultObject", _oGpaList);
          throw new EElixirException(cex, "P1007");
        }

      }
      request.setAttribute("ResultObject", _oGpaList);
      throw eLex;
     }

   }

   private void setGpaResults(HttpServletRequest a_oRequest)
   {
     String strParameter[] = a_oRequest.getParameterValues("strParameter");
     String strWeightage1[] = a_oRequest.getParameterValues("strWeightage1");
     String strWeightage2[]=a_oRequest.getParameterValues("strWeightage2");
     String strWeightage3[]=a_oRequest.getParameterValues("strWeightage3");
     String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
     String[] dtUpdated      = a_oRequest.getParameterValues("dtUpdated");
     String SeqNumb[] = a_oRequest.getParameterValues("SeqNumb");
     String strDesignation = a_oRequest.getParameter("strDesignation");
     String nFreqOfProd = a_oRequest.getParameter("nFreqOfProd");
     String nFreqOfCalc = a_oRequest.getParameter("nFreqOfCalc");

     String strSegmentation[] = a_oRequest.getParameterValues("strSegmentation");
     String[] dtEffFrom      = a_oRequest.getParameterValues("dtEffFrom");
     String[] dtEffTo      = a_oRequest.getParameterValues("dtEffTo");
     
     //Modified by Prabhat for July_PH2_SMGPA start
     String[] ncumncum=a_oRequest.getParameterValues("strCumulative");
     //Modified by Prabhat for July_PH2_SMGPA End

     HttpSession  session = a_oRequest.getSession();
     String  _strUserId = (String)session.getAttribute("username");
     log.debug("statusFlag"+statusFlag);
     if(statusFlag != null)
     {
       for(int i = 0; i < statusFlag.length; i++)
       {
         if(!(statusFlag[i].equals(DataConstants.CLEAR_MODE)) )
         {
        	 _oGpaResult = new GpaResult();
        	 _oGpaResult.setDesignation(strDesignation);
        	 log.debug("strDesignation"+_oGpaResult.getDesignation());
        	 _oGpaResult.setFreqOfCalc(new Short(nFreqOfCalc));
        	 log.debug("_oGpaResult.getFreqOfCalc"+_oGpaResult.getFreqOfCalc());
        	 _oGpaResult.setFreqOfProd(new Short(nFreqOfProd));
        	 log.debug("_oGpaResult.getFreqOfProd"+_oGpaResult.getFreqOfProd());
        	 _oGpaResult.setParameter(strParameter[i]);
        	 log.debug("strParameter"+_oGpaResult.getParameter());
        	 _oGpaResult.setWeightage1(strWeightage1[i]);
        	 log.debug("setWeightage1"+_oGpaResult.getWeightage1());
        	 _oGpaResult.setWeightage2(strWeightage2[i]);
        	 log.debug("setWeightage2"+_oGpaResult.getWeightage2());
        	 _oGpaResult.setWeightage3(strWeightage3[i]);
        	 log.debug("setWeightage2"+_oGpaResult.getWeightage3());
        	 _oGpaResult.setSegmention(strSegmentation[i]);
        	 log.debug(_oGpaResult.getSegmention());
        	 
        	 //Modified by Prabhat for July_PH2_SMGPA start
        	 
        	 _oGpaResult.setCumulativeNcumulative(Integer.parseInt(ncumncum[i]));
        	 log.debug("Cumulative & Non Cumulative : "+_oGpaResult.getCumulativeNcumulative());
        	 
        	 //Modified by Prabhat for July_PH2_SMGPA End
        	 
        	 if (dtEffFrom[i] != null && !dtEffFrom[i].trim().equals(""))
             {
        		 _oGpaResult.setDtEffFrom(DateUtil.retGCDate(dtEffFrom[i].trim()));
        		 log.debug("setDtEffFrom"+_oGpaResult.getDtEffFrom());
             }
        	 if (dtEffTo[i] != null && !dtEffTo[i].trim().equals(""))
             {

        		 _oGpaResult.setDtEffTo(DateUtil.retGCDate(dtEffTo[i].trim()));
        		 log.debug("setDtEffTo"+_oGpaResult.getDtEffTo());
             }

          _oGpaResult.setStatusFlag(statusFlag[i]);
          log.debug("statusFlag"+_oGpaResult.getStatusFlag());

          if(SeqNumb[i]!=null &&!SeqNumb[i].trim().equals(""))
          {
        	  _oGpaResult.setSeqNbr(new Long(SeqNumb[i]));
        	  log.debug("setSegSeqNbr"+_oGpaResult.getSeqNbr());

          }
          else
   	      {
        	  _oGpaResult.setSeqNbr(null);
        	  log.debug("nulllll setSegSeqNbr"+_oGpaResult.getSeqNbr());
   	      }

       	 if (dtUpdated[i] != null && !dtUpdated[i].trim().equals(""))
          {
         	  log.debug("u are in dtupdate");
        	 _oGpaResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated[i]));
        	 log.debug("setTsDtUpdated"+_oGpaResult.getDtUpdated());
          }
         _oGpaResult.setUserId(_strUserId);
         log.debug("End of setting dataaaaaaaaaaaaaaaaaa");
         _oGpaList.add(_oGpaResult);

       }
       }
     }
   }

   //class level variable declarations.

   GpaResult _oGpaResult = null;
   ArrayList _oGpaList = new ArrayList() ;
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


}

