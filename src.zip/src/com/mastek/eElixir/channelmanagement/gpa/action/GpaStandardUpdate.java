/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME					: GpaUpdate.java
*  AUTHOR					: Sunaina Bhat
*  VERSION					: 1.0
*  CREATION DATE		    : July 03, 2008
*  COMPANY				    : Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.gpa.action;


import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class GpaStandardUpdate extends Action
{
	 String strSeqNbr = null;

   /**
    * Constructer
    */

   public GpaStandardUpdate()
   {

   }


   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean .
   * @param : ResultObject object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */

   public void process(HttpServletRequest request)  throws EElixirException
   {
	   log.debug("u are in GpaStandardUpdate Action");
     request.setAttribute("actiontype",DataConstants.ACTION_UPDATE);
     CHMSL remoteCHMSL = null;


     try

     {

        setGpaResults(request);
       log.debug("u are back");
       remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
  	  strSeqNbr = request.getParameter("strSeqNbr");
  	  log.debug("strSeqNbr***************"+strSeqNbr);
      log.debug("u befoer updateGpa");
       remoteCHMSL.updateGpaStandard(_oGpaStandardMasterResult);
       log.debug("u after updateGpa");
       _oGpaStandardMasterResult = remoteCHMSL.searchGpaStandards(Long.parseLong(strSeqNbr),request.getParameter("strParameter"));

        setResult(_oGpaStandardMasterResult);
      }
     catch(FinderException fex)
     {
       request.setAttribute("ResultObject", _oGpaStandardMasterResult);
       throw new EElixirException(fex, "P1007");
     }
     catch(RemoteException rex)
     {
       request.setAttribute("ResultObject", _oGpaStandardMasterResult);
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       request.setAttribute("ResultObject", _oGpaStandardMasterResult);

       throw new EElixirException(cex, "P1007");
     }
     catch(EElixirException eLex)
     {
      log.debug("In GpaUpdate eelixir exception before setting result" + eLex);
      if (eLex.getCustomErrorCode().equalsIgnoreCase("P1100"))
      {
        try
        {
        	_oGpaStandardMasterResult = remoteCHMSL.searchGpaStandards(Long.parseLong(strSeqNbr),request.getParameter("strParameter"));
          setResult(_oGpaStandardMasterResult);
        }
        catch(RemoteException rex)
        {
          request.setAttribute("ResultObject", _oGpaStandardMasterResult);
          throw new EElixirException(rex, "P1006");
        }
             }
      request.setAttribute("ResultObject", _oGpaStandardMasterResult);
      throw eLex;
     }

   }

   private void setGpaResults(HttpServletRequest a_oRequest)
   {
     String strParameter = a_oRequest.getParameter("strParameter");
     String strFromMonth[] = a_oRequest.getParameterValues("strFomMonth");
     String strToMonth[]=a_oRequest.getParameterValues("strToMonth");
     String strTarget[]=a_oRequest.getParameterValues("strTarget");
     String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
     String[] dtUpdated      = a_oRequest.getParameterValues("dtUpdated");
     String SeqNumb[] = a_oRequest.getParameterValues("SeqNumb1");
     strSeqNbr = a_oRequest.getParameter("strSeqNbr");


     HttpSession  session = a_oRequest.getSession();
     String  _strUserId = (String)session.getAttribute("username");
     log.debug("statusFlag"+statusFlag);
     _oGpaStandardMasterResult = new GpaStandardMasterResult();
     _oGpaStandardMasterResult.setParameter(strParameter);
     log.debug("_oGpaStandardMasterResult.setParameter(strParameter)"+ _oGpaStandardMasterResult.getParameter());
     _oGpaStandardMasterResult.setSeqNumb(new Long(strSeqNbr));
     log.debug(" _oGpaStandardMasterResult.setSeqNumb(new Long(strSeqNbr))"+ _oGpaStandardMasterResult.getSeqNumb());
     if(statusFlag != null)
     {
       for(int i = 0; i < statusFlag.length; i++)
       {
         if(!(statusFlag[i].equals(DataConstants.CLEAR_MODE)) )
         {

        	 _oGpaStandardResult = new GpaStandardResult();
        	// _oGpaStandardResult.setParameter(strParameter);
        	// log.debug("strParameter"+_oGpaStandardResult.getParameter());

        	 _oGpaStandardResult.setFomMonth(strFromMonth[i]);
        	 log.debug("strFromMonth"+_oGpaStandardResult.getFomMonth());
        	 _oGpaStandardResult.setToMonth(strToMonth[i]);
        	 log.debug("strToMonth"+_oGpaStandardResult.getToMonth());
        	 _oGpaStandardResult.setTarget(strTarget[i]);
        	 log.debug("strTarget"+_oGpaStandardResult.getTarget());


        	 _oGpaStandardResult.setStatusFlag(statusFlag[i]);
          log.debug("statusFlag"+_oGpaStandardResult.getStatusFlag());


          if(SeqNumb[i]!=null &&!SeqNumb[i].trim().equals(""))
          {
        	  _oGpaStandardResult.setStandardSeqNbr(new Long(SeqNumb[i]));
        	  log.debug("setSegSeqNbr"+_oGpaStandardResult.getStandardSeqNbr());

          }
          else
   	      {
        	  _oGpaStandardResult.setStandardSeqNbr(null);
        	  log.debug("nulllll setSegSeqNbr"+_oGpaStandardResult.getStandardSeqNbr());
   	      }

          _oGpaStandardResult.setSeqNbr(new Long(strSeqNbr));
          log.debug("setSeqNbr setting in dvo"+_oGpaStandardResult.getSeqNbr());

       	 if (dtUpdated[i] != null && !dtUpdated[i].trim().equals(""))
          {
         	  log.debug("u are in dtupdate");
         	 _oGpaStandardResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated[i]));
        	 log.debug("setTsDtUpdated"+_oGpaStandardResult.getDtUpdated());
          }
       	_oGpaStandardResult.setUserId(_strUserId);
         log.debug("End of setting dataaaaaaaaaaaaaaaaaa");
         _oGpaList.add(_oGpaStandardResult);

       }
       }
     }
     _oGpaStandardMasterResult.setGpaStandResult(_oGpaList);
   }

   //class level variable declarations.
   GpaStandardMasterResult _oGpaStandardMasterResult=null;
   GpaStandardResult _oGpaStandardResult = null;
  // String strSeqNbr = null;
   //String strParameter = null;
   ArrayList _oGpaList = new ArrayList() ;
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


}

