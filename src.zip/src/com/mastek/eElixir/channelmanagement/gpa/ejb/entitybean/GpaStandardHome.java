/********************************************************************
*
*  PROJECT			:MNYL
*  MODULE NAME	    : CHANNEL MANAGEMENT
*  FILENAME			: SegmentCriteriaHome.java
*  AUTHOR			: Sunaina Bhat
*  VERSION			: 1.0
*  CREATION DATE    : July 15, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.gpa.util.GpaResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This SegmentCriteria home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Arun Kumar
 * @version 1.0
 */


public interface GpaStandardHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @throws javax.ejb.FinderException
   */

  public GpaStandard findByPrimaryKey(GpaPK primaryKey)
      throws FinderException, RemoteException, EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @return SegmentCriteria
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public GpaStandard create() throws CreateException, RemoteException, EElixirException;



}