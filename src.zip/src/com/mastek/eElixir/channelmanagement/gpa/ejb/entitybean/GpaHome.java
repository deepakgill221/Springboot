/********************************************************************
*
*  PROJECT			:MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: SegmentMasterHome.java
*  AUTHOR			: Arun Kumar
*  VERSION			: 1.0
*  CREATION DATE	        : Feb 26, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* Arun_Everest_Segmentation
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.gpa.util.GpaResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This Gpa home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Arun Kumar
 * @version 1.0
 */


public interface GpaHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @throws javax.ejb.FinderException
   */

  public Gpa findByPrimaryKey(GpaPK primaryKey)
      throws FinderException, RemoteException, EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @return SegmentationResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public Gpa create() throws CreateException, RemoteException, EElixirException;


  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class
   * @param a_oSegmentationResult SegmentationResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public Gpa create(GpaResult a_oGpaResult) throws CreateException, RemoteException, EElixirException;


}