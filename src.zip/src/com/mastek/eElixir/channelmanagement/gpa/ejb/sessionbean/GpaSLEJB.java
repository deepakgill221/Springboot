/********************************************************************
*
*  PROJECT          : MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : SegmentSLEJB.java
*  AUTHOR           : Arun Kumar
*  VERSION          : 1.0
*  CREATION DATE    : Feb 22, 2008
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2008.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION        DATE           BY                        REASON
*--------------------------------------------------------------------------------
*    Arun_Everest_Segmentation_Start
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.gpa.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.gpa.dax.GpaDAX;
import com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean.Gpa;
import com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean.GpaCriteria;
import com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean.GpaCriteriaHome;
import com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean.GpaHome;
import com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean.GpaPK;
import com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean.GpaStandard;
import com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean.GpaStandardHome;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardResult;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.entitybean.SegmentCriteriaHome;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.entitybean.SegmentMasterPK;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentWeightageResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;


public class GpaSLEJB implements SessionBean
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);
    /**
     * Attributes declaration
     */
     private GpaDAX _oGpaDAX=null;
    private Connection _oConnection = null;
    private SessionContext _oSessionContext = null;
    private GpaHome _oGpaHome =null;
    private GpaStandard _oGpaStandard=null;
    private GpaStandardHome _oGpaStandardHome=null;
    private GpaCriteriaHome _oGpaCriteriaHome=null;
    private GpaCriteria _oGpaCriteria=null;

    private Gpa _oGpa=null;


    private GpaStandardResult _oGpaStandardResult=null;

    /**
     * Constructor of the SegmentSLEJB class
     */
    public GpaSLEJB()
    {
    }

    /**
     * Called by the container to create a session bean instance. Its parameters typically
     * contain the information the client uses to customize the bean instance for its use.
     * It requires a matching pair in the bean class and its home interface.
     * @throws CreateException
     * @throws EElixirException
     */
    public void ejbCreate() throws CreateException, EElixirException
    {
    }

    /**
     * A container invokes this method before it ends the life of the session object. This
     * happens as a result of a client's invoking a remove operation, or when a container
     * decides to terminate the session object after a timeout. This method is called with
     * no transaction context.
     */
    public void ejbRemove()
    {
    }

    /**
     * The activate method is called when the instance is activated from its 'passive' state.
     * The instance should acquire any resource that it has released earlier in the ejbPassivate()
     * method. This method is called with no transaction context.
     */
    public void ejbActivate()
    {
    }

    /**
     * The passivate method is called before the instance enters the 'passive' state. The
     * instance should release any resources that it can re-acquire later in the ejbActivate()
     * method. After the passivate method completes, the instance must be in a state that
     * allows the container to use the Java Serialization protocol to externalize and store
     * away the instance's state. This method is called with no transaction context.
     */
    public void ejbPassivate()
    {
    }

    /**
     * Set the associated session context. The container calls this method after the instance
     * creation. The enterprise Bean instance should store the reference to the context
     * object in an instance variable. This method is called with no transaction context.
     * @param sc SessionContext
     */
    public void setSessionContext(SessionContext a_oSessionContext)
    {
        this._oSessionContext = a_oSessionContext;
    }

    private GpaDAX getDAX() throws EElixirException
    {
        _oConnection = DBConnection.getConnection();

        CHMDAXFactory oCHMDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        GpaDAX _oGpaDAX = (GpaDAX) oCHMDAXFactory.createDAX(CHMDAXFactory.GPADAX);
        _oGpaDAX.setConnection(_oConnection);
       
        return _oGpaDAX;
    }

     public GpaStandardMasterResult searchGpaStandards(long a_strSeqNbr,String a_strParameter) throws FinderException, EElixirException
    {
    	 try
         {
    	 _oGpaDAX = getDAX();
         _oLogger.debug("GPASLEJB RETURN");
    	 return _oGpaDAX.searchGpaStandards(a_strSeqNbr,a_strParameter);

    }
    	 catch(EJBException ejbex)
         {
            throw new EElixirException(ejbex, "jan805");
         }
         catch(EElixirException eLex)
         {
            throw eLex;
         }
         finally
         {
            try
            {
               if(_oConnection != null)
                  DBConnection.closeConnection(_oConnection);
            }
            catch(EElixirException eElex)
            {
               throw eElex;
            }
         }

      }

     public GpaCriteriaMasterResult searchGpaCriteria(long a_strSeqNbr,String a_strParameter) throws FinderException, EElixirException
     {
    	try
        {
     	 _oGpaDAX = getDAX();

     	 return _oGpaDAX.searchGpaCriteria(a_strSeqNbr,a_strParameter);

     }
     catch(EJBException ejbex)
     {
        throw new EElixirException(ejbex, "p8106");
     }
     catch(EElixirException eLex)
     {
        throw eLex;
     }
     finally
     {
        try
        {
           if(_oConnection != null)
              DBConnection.closeConnection(_oConnection);
        }
        catch(EElixirException eElex)
        {
           throw eElex;
        }
     }

  }

     public ArrayList searchDesignationGpa(String a_strDesignation ) throws FinderException, EElixirException
     {
    	 try
         {
    	 _oGpaDAX = getDAX();

     	 return _oGpaDAX.searchDesignationGpa(a_strDesignation );

     }
    	 catch(EJBException ejbex)
         {
            throw new EElixirException(ejbex, "p8107");
         }
         catch(EElixirException eLex)
         {
            throw eLex;
         }
         finally
         {
            try
            {
               if(_oConnection != null)
                  DBConnection.closeConnection(_oConnection);
            }
            catch(EElixirException eElex)
            {
               throw eElex;
            }
         }

      }

     public void updateGpa(ArrayList _oGpaList) throws FinderException, EElixirException
     {
    	 _oLogger.debug("updateGpa **********");
    	 GpaResult oGpaResult = null;

         try
         {
        	 _oLogger.debug("Sunaina");
         	 GpaPK oGpaPK= new GpaPK();
             EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
             CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
             _oGpaHome = (GpaHome) oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
             "GpaHome"), GpaHome.class);
             GpaDAX _oGpaDAX = (GpaDAX)getDAX();
             String strStatus = null;
             if (_oGpaList != null)
             {
             	int iSize = _oGpaList.size();
             	
                 for (int i = 0; i < iSize; i++)
                 {
                	 oGpaResult = (GpaResult) _oGpaList.get(i);
                 	strStatus=oGpaResult.getStatusFlag();
                 	

 				   	 if(strStatus.trim().equals(DataConstants.INSERT_MODE))
                      {
 				   		
                		Long lSeqNbr=_oGpaDAX.getNextSeqNbr();
                	  	oGpaResult.setSeqNbr(lSeqNbr);
                		_oGpaHome.create(oGpaResult);
                		

                      }
                 	 else if (strStatus.trim().equals(DataConstants.UPDATE_MODE))
                      {

                 		
                 		Long lSegSeqNbr = oGpaResult.getSeqNbr();
                 		
                 		oGpaPK.setSeqNbr(lSegSeqNbr);
                 		
                 		_oGpa = _oGpaHome.findByPrimaryKey(oGpaPK);
                 		
                 		GpaResult oConGpaResult = _oGpa.getGpaResult();
                 	

                          if ((oConGpaResult.getTsDtUpdated() != null) &&
                             (!oConGpaResult.getTsDtUpdated().equals(oGpaResult.getTsDtUpdated())))
                           {
                              _oLogger.fatal(
                                  "concurrency failed thorwing exception");
                              throw new EElixirException("P1100");
                          }

                          _oGpa.setGpaResult(oGpaResult);
                          _oLogger.debug("get the values"+ _oGpa.getGpaResult());



                      }
                 	 else if (strStatus.trim().equals(DataConstants.DELETE_MODE))
                      {
                 		
                 		//_oGpaDAX = (GpaDAX)getDAX();
                 		 _oGpaDAX.deleteGpa(oGpaResult);
                      }

                 }
             }
         }
         catch (CreateException cex)
         {
             _oLogger.fatal(getClass().getName(), "updateGpa ",
                 "CreateException " + cex.getMessage());
             _oSessionContext.setRollbackOnly();
             throw new EElixirException(cex, "p8170");
         }
         catch (RemoteException rex)
         {
             _oLogger.fatal(getClass().getName(), "updateGpa ",
                 "RemoteException " + rex.getMessage());
             _oSessionContext.setRollbackOnly();
             throw new EElixirException(rex, "P1006");
         }
         catch (FinderException fex)
         {
             _oLogger.fatal(getClass().getName(), "updateGpa ",
                 "FinderException " + fex.getMessage());
             _oSessionContext.setRollbackOnly();
             throw new EElixirException(fex, "p8110");
         }
         catch (EJBException ejbex)
         {
             _oLogger.fatal(getClass().getName(), "updateGpa ",
                 "EJBException " + ejbex.getMessage());
             _oSessionContext.setRollbackOnly();
             throw (EElixirException) ejbex.getCausedByException();
         }
         catch (EElixirException eex)
         {
             _oLogger.fatal(getClass().getName(), "updateGpa ",
                 "EElixirException " + eex.getMessage());
             _oSessionContext.setRollbackOnly();
             throw eex;
         }
         finally
 		{
 			try
 			{
 				if (_oConnection != null)
 				{
 					DBConnection.closeConnection(_oConnection);
 				}
 			}
 			catch (EElixirException eElex)
 			{
 				_oLogger.fatal(getClass().getName(), "updateGpa",
 					"EElixirException " + eElex.getMessage());
 				throw new EElixirException(eElex, "P1005");
 			}
 		}

     }


     public void updateGpaStandard(GpaStandardMasterResult _oGpaStandardMasterResult) throws FinderException, EElixirException
     {
    	

		try
		{
			
		 	 GpaPK oGpaPK= null;
		     EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
		     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		     _oGpaStandardHome = (GpaStandardHome) oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
		     "GpaStandardHome"), GpaStandardHome.class);
		      oGpaPK = new GpaPK(_oGpaStandardMasterResult.getSeqNumb());
		     _oGpaStandard = _oGpaStandardHome.findByPrimaryKey(oGpaPK);
		     _oGpaStandard.setGpaStandardMasterResult(_oGpaStandardMasterResult);


		 }
		 catch (RemoteException rex)
		 {
		    _oLogger.fatal(getClass().getName(), "updateGpaStandard ",
		        "RemoteException " + rex.getMessage());
		    _oSessionContext.setRollbackOnly();
		    throw new EElixirException(rex, "P1006");
		 }
		catch (FinderException fex)
		{
		    _oLogger.fatal(getClass().getName(), "updateGpaStandard ",
		        "FinderException " + fex.getMessage());
		    _oSessionContext.setRollbackOnly();
		    throw new EElixirException(fex, "jan814");
		}
		catch (EJBException ejbex)
		{
		    _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
		        "EJBException " + ejbex.getMessage());
		    _oSessionContext.setRollbackOnly();
		    throw (EElixirException) ejbex.getCausedByException();
		}
		catch (EElixirException eex)
		{
		    _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
		        "EElixirException " + eex.getMessage());
		    _oSessionContext.setRollbackOnly();
		    throw eex;
		}
		finally
		{
			try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{
				_oLogger.fatal(getClass().getName(), "updateSegmentMaster",
					"EElixirException " + eElex.getMessage());
				throw new EElixirException(eElex, "P1005");
			}
		}
		}


     public void updateGpaCriteria(GpaCriteriaMasterResult _oGpaCriteriaMasterResult) throws FinderException, EElixirException
     {
    	
		try
		{
			
		 	 GpaPK oGpaPK= null;
		     EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
		     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		     _oGpaCriteriaHome = (GpaCriteriaHome) oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
		     "GpaCriteriaHome"), GpaCriteriaHome.class);
		      oGpaPK = new GpaPK(_oGpaCriteriaMasterResult.getSeqNumb());
		     _oGpaCriteria = _oGpaCriteriaHome.findByPrimaryKey(oGpaPK);
		     _oGpaCriteria.setGpaCriteriaMasterResult(_oGpaCriteriaMasterResult);


		 }
		 catch (RemoteException rex)
		 {
		    _oLogger.fatal(getClass().getName(), "updateGpaStandard ",
		        "RemoteException " + rex.getMessage());
		    _oSessionContext.setRollbackOnly();
		    throw new EElixirException(rex, "P1006");
		 }
		catch (FinderException fex)
		{
		    _oLogger.fatal(getClass().getName(), "updateGpaStandard ",
		        "FinderException " + fex.getMessage());
		    _oSessionContext.setRollbackOnly();
		    throw new EElixirException(fex, "jan817");
		}
		catch (EJBException ejbex)
		{
		    _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
		        "EJBException " + ejbex.getMessage());
		    _oSessionContext.setRollbackOnly();
		    throw (EElixirException) ejbex.getCausedByException();
		}
		catch (EElixirException eex)
		{
		    _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
		        "EElixirException " + eex.getMessage());
		    _oSessionContext.setRollbackOnly();
		    throw eex;
		}
		finally
		{
			try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{
				_oLogger.fatal(getClass().getName(), "updateSegmentMaster",
					"EElixirException " + eElex.getMessage());
				throw new EElixirException(eElex, "P1005");
			}
		}
		}

     public void copyDesignationGpa(String a_strDesignation,String a_strInputDesg,String a_strUserId) throws FinderException, EElixirException
     {
    	 try
         {
    		 
    	 _oGpaDAX = getDAX();
    	
     	 _oGpaDAX.copyDesignationGpa(a_strDesignation,a_strInputDesg,a_strUserId );

     }
    	 catch(EJBException ejbex)
         {
            throw new EElixirException(ejbex, "p8171");
         }
         catch(EElixirException eLex)
         {
            throw eLex;
         }
         finally
         {
            try
            {
               if(_oConnection != null)
                  DBConnection.closeConnection(_oConnection);
            }
            catch(EElixirException eElex)
            {
               throw eElex;
            }
         }

      }

  }