/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: Gpa.java
*  AUTHOR			: Sunaina Bhat
*  VERSION			: 1.0
*  CREATION DATE	        : Feb 25, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.gpa.util.GpaResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This interface provides method for retreving data from the
 * database through primaryKey  </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Sunaina Bhat
 * @version 1.0
 */



public interface Gpa extends EJBObject
{
  /* This method gets the SegmentationResult Object
  * @return SegmentationResult
  */
  public GpaResult getGpaResult() throws RemoteException, EElixirException;

  /* This method sets the SegmentationResult Object
  * @param a_oSegmentationResult ChannelResult
  */
  public void setGpaResult(GpaResult a_oGpaResult) throws RemoteException, EElixirException;

}