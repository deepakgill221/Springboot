/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : CHANNEL MANAGEMENT
*  FILENAME			: GpaStandard.java
*  AUTHOR			: Sunaina Bhat
*  VERSION			: 1.0
*  CREATION DATE    : July 15, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.gpa.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This GpaStandard interface provides method for retreving data from the
 * database through primaryKey  </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Sunaina Bhat
 * @version 1.0
 */



public interface GpaStandard extends EJBObject
{
  /* This method gets the SegmentationResult Object
  * @return SegmentCriteriaResult
  */
  public GpaStandardMasterResult getGpaStandardMasterResult() throws RemoteException, EElixirException;

  /* This method sets the SegmentCriteriaResult Object
  * @param a_oSegmentCriteriaResult SegmentCriteriaResult
  */
  public void setGpaStandardMasterResult(GpaStandardMasterResult a_oGpaStandardMasterResult) throws RemoteException, EElixirException;

}