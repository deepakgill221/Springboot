/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : SegmentSL.java
*  AUTHOR           : Sunaina Bhat
*  VERSION          : 1.0
*  CREATION DATE    : June 26, 2008
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION        DATE	BY              REASON
*--------------------------------------------------------------------------------
* //Sunaina_Everest_Segmentation_PhaseII
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.gpa.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardResult;


public interface GpaSL extends EJBObject
{
    /**
	   *
	   * @param String
	   * @throws FinderException
	   * @throws RemoteException
	   * @throws EElixirException
	   */
    public GpaStandardMasterResult searchGpaStandards(long a_strSeqNbr,String a_strParameter)
    throws FinderException, RemoteException, EElixirException;
    /**
     *
     * @param a_strParameter
     * @return
     * @throws FinderException
     * @throws RemoteException
     * @throws EElixirException
     */
    public GpaCriteriaMasterResult searchGpaCriteria(long a_strSeqNbr,String a_strParameter)
    throws FinderException, RemoteException, EElixirException;

    public ArrayList searchDesignationGpa(String a_strDesignation )
    throws FinderException, RemoteException, EElixirException;

    public void updateGpa(ArrayList _oGpaList)
    throws FinderException, RemoteException, EElixirException;

    public void updateGpaStandard(GpaStandardMasterResult _oGpaStandardMasterResult)
    throws FinderException, RemoteException, EElixirException;

    public void updateGpaCriteria(GpaCriteriaMasterResult _oGpaCriteriaMasterResult)
    throws FinderException, RemoteException, EElixirException;

    public void copyDesignationGpa(String a_strDesignation,String a_strInputDesg,String a_strUserId)
    throws FinderException, RemoteException, EElixirException;

}
