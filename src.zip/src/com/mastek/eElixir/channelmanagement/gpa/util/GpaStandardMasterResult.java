
/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: SegmentCriteriaResult.java
*  AUTHOR			: Sunaina Bhat
*  VERSION			: 1.0
*  CREATION DATE	        :
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Segmentation Master</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Arun
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.gpa.util;
import java.io.Serializable;
import java.util.HashMap;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class GpaStandardMasterResult extends UserData implements Serializable
{

   private HashMap _hmSegmentMst;
   private ArrayList _alGpaStandResult;

   private  Long _strSeqNumb = null;
   private  String _strParameter = null;


  public GpaStandardMasterResult()
  {

  }

  public Long getSeqNumb() {
    return _strSeqNumb;
  }
  public void setSeqNumb(Long a_strSeqNumb) {
    this._strSeqNumb = a_strSeqNumb;
  }
  public String getParameter() {
    return _strParameter;
  }
  public void setParameter(String a_strParameter) {
    this._strParameter = a_strParameter;
  }


  public void setGpaStandResult(ArrayList a_alGpaStandResult)
  {
	  this._alGpaStandResult=a_alGpaStandResult;
  }
  public ArrayList getGpaStandResult()
  {
	  return _alGpaStandResult;
  }



  public String toString(){
    String retValue =  " _strSeqNumb : " + _strSeqNumb +"_strParameter :"+_strParameter+
    "_alGpaStandResult"+ _alGpaStandResult  ;
    retValue = retValue + "_hmSegmentMst:" + _hmSegmentMst + "\n";
    return retValue;
  }


}

