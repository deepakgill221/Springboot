/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: SegmentCriteriaResult.java
*  AUTHOR			: Arun Kumar
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 05, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
* Arun_Everest_Segmentation
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Segmentation Master</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Arun
 * @version 1.0
 */



package com.mastek.eElixir.channelmanagement.gpa.util;
import java.io.Serializable;
import java.util.HashMap;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class GpaCriteriaResult extends UserData implements Serializable
{

   private HashMap _hmGpaMst;


   private  String _strParameter = null;

   private  String _strStatusFlag = null;

   private String _strPoints = null;

   private String _strFomPercent =null;

   private String _strToPercent = null;

   protected Long _lSeqNbr = null;

   protected Long _lCriteriaSeqNbr = null;


  public GpaCriteriaResult()
  {

  }

  public Long getCriteriaSeqNbr() {
	    return _lCriteriaSeqNbr;
	  }
	  public void setCriteriaSeqNbr(Long a_lCriteriaSeqNbr) {
	    this._lCriteriaSeqNbr = a_lCriteriaSeqNbr;
	  }

  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }

  public Long getSeqNbr() {
	    return _lSeqNbr;
	  }
	  public void setSeqNbr(Long a_lSeqNbr) {
	    this._lSeqNbr = a_lSeqNbr;
	  }
  public String getPoints() {
		return _strPoints;
	}

	public void setPoints(String a_strPoints) {
		this._strPoints = a_strPoints;
	}

	public String getFomPercent() {
		return _strFomPercent;
	}

	public void setFomPercent(String a_strFomPercent) {
		this._strFomPercent = a_strFomPercent;
	}

	public String getToPercent() {
		return _strToPercent;
	}

	public void setToPercent(String a_strToPercent) {
		this._strToPercent = a_strToPercent;
	}

public String getParameter() {
    return _strParameter;
  }
  public void setParameter(String a_strParameter) {
    this._strParameter = a_strParameter;
  }




  public String toString(){
    String retValue =  " Parameter : " + _strParameter +
    " StatusFlag : " + _strStatusFlag +"_strPoints :" + _strPoints +"_strFomPercent :"+ _strFomPercent +
    "_strToPercent :"+_strToPercent + "_lSeqNbr :"+ _lSeqNbr +"_lCriteriaSeqNbr :"+ _lCriteriaSeqNbr;
    retValue = retValue + "_hmGpaMst:" + _hmGpaMst + "\n";
    return retValue;
  }


}
