/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : CHANNEL MANAGEMENT
*  FILENAME			: GpaResult.java
*  AUTHOR			: Sunaina Bhat
*  VERSION			: 1.0
*  CREATION DATE    : July 01, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Segmentation Master</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Arun
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.gpa.util;
import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class GpaResult extends UserData implements Serializable
{

   private HashMap _hmGpaMst;

   private String _strDesignation = null;
   private Short _nFreqOfCalc;
   private Short _nFreqOfProd;
   private  String _strParameter = null;
   private  String _strSegmention = null;
   private  String _strWeightage1 = null;
   private  String _strWeightage2 = null;
   private String _strWeightage3 = null;
   private  String _strStatusFlag = null;
   private GregorianCalendar _dtEffFrom = null;
   private GregorianCalendar _dtEffTo = null;
   protected Long _lSeqNbr = null;
   
   //<!-- Modified by Prabhat for July_PH2_SMGPA start -->
   
   private int cumulativeNcumulative;
   
   //<!-- Modified by Prabhat for July_PH2_SMGPA End -->

  public GpaResult()
  {

  }

  
  //<!-- Modified by Prabhat for July_PH2_SMGPA start -->
  
  /**
 * @return the cumulativeNcumulative
 */
public int getCumulativeNcumulative() {
	return cumulativeNcumulative;
}




/**
 * @param cumulativeNcumulative the cumulativeNcumulative to set
 */
public void setCumulativeNcumulative(int cumulativeNcumulative) {
	this.cumulativeNcumulative = cumulativeNcumulative;
}

//<!-- Modified by Prabhat for July_PH2_SMGPA End -->


public HashMap getGpaMst() {
    return _hmGpaMst;
  }

  public void setSegmentMst(HashMap a_hmGpaMst) {
    this._hmGpaMst = a_hmGpaMst;
  }
  public Long getSeqNbr() {
	    return _lSeqNbr;
	  }
	  public void setSeqNbr(Long a_lSeqNbr) {
	    this._lSeqNbr = a_lSeqNbr;
	  }
  public String getDesignation() {
	    return _strDesignation;
	  }
	  public void setDesignation(String _strDesignation) {
	    this._strDesignation = _strDesignation;
	  }
	  public Short getFreqOfProd() {
			return _nFreqOfProd;
		}

		public void setFreqOfProd(Short freqOfProd) {
			this._nFreqOfProd = freqOfProd;
		}

		public Short getFreqOfCalc() {
	        return _nFreqOfCalc;
	    }
	    public void setFreqOfCalc(Short freqOfCalc) {
	        _nFreqOfCalc = freqOfCalc;
	    }

  public String getParameter() {
    return _strParameter;
  }
  public void setParameter(String _strParameter) {
    this._strParameter = _strParameter;
  }
  public String getWeightage1() {
    return _strWeightage1;
  }
  public void setWeightage1(String _strWeightage1) {
    this._strWeightage1 = _strWeightage1;
  }
  public String getWeightage2() {
    return _strWeightage2;
  }

  public void setWeightage2(String _strWeightage2) {
	    this._strWeightage2 = _strWeightage2;
	  }

  public String getWeightage3() {
	    return _strWeightage3;
	  }

	  public void setWeightage3(String _strWeightage3) {
		    this._strWeightage3 = _strWeightage3;
		  }
	  public String getStatusFlag() {
		    return _strStatusFlag;
		  }
		  public void setStatusFlag(String _strStatusFlag) {
		    this._strStatusFlag = _strStatusFlag;
		  }
  public void setSegmention(String _strSegmention) {
    this._strSegmention = _strSegmention;
  }
  public String getSegmention() {
    return _strSegmention;
  }
  public GregorianCalendar getDtEffFrom() {
	    return _dtEffFrom;
	  }
	  public void setDtEffFrom(GregorianCalendar a_dtEffFrom) {
	    this._dtEffFrom = a_dtEffFrom;
	  }
	  public GregorianCalendar getDtEffTo() {
	    return _dtEffTo;
	  }
	  public void setDtEffTo(GregorianCalendar a_dtEffTo) {
	    this._dtEffTo = a_dtEffTo;
	  }
  public String toString(){
    String retValue = "_strDesignation : " + _strDesignation + " _nFreqOfCalc : " + _nFreqOfCalc +" _nFreqOfProd : " + _nFreqOfProd +
                      " Parameter : " + _strParameter +" _strSegmention : " + _strSegmention + "_strWeightage1 : " + _strWeightage1 + " _strWeightage2 : " + _strWeightage2 + " _strWeightage3 : " + _strWeightage3
					  +"_strStatusFlag :" +_strStatusFlag + "_lSeqNbr: "+_lSeqNbr
					  + " _dtEffFrom : " + _dtEffFrom + " _dtEffTo : " + _dtEffTo;
    retValue = retValue + "_hmGpaMst:" + _hmGpaMst + "\n";
    return retValue;
  }


}

