/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: SegmentCriteriaResult.java
*  AUTHOR			: Arun Kumar
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 05, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
* Arun_Everest_Segmentation
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Segmentation Master</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Arun
 * @version 1.0
 */



package com.mastek.eElixir.channelmanagement.gpa.util;
import java.io.Serializable;
import java.util.HashMap;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class GpaStandardResult extends UserData implements Serializable
{

   private HashMap _hmGpaMst;

   private  String _strParameter = null;

   private  String _strStatusFlag = null;

   private String _strTarget = null;

   private String _strFomMonth =null;

   private String _strToMonth = null;

   protected Long _lSeqNbr = null;

   protected Long _lStandardSeqNbr = null;


  public GpaStandardResult()
  {

  }

  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }

  public String getParameter() {
    return _strParameter;
  }
  public void setParameter(String a_strParameter) {
    this._strParameter = a_strParameter;
  }

  public Long getSeqNbr() {
	    return _lSeqNbr;
	  }
	  public void setSeqNbr(Long a_lSeqNbr) {
	    this._lSeqNbr = a_lSeqNbr;
	  }

	  public Long getStandardSeqNbr() {
		    return _lStandardSeqNbr;
		  }
		  public void setStandardSeqNbr(Long a_lStandardSeqNbr) {
		    this._lStandardSeqNbr = a_lStandardSeqNbr;
		  }





  public String toString(){
    String retValue =  " Parameter : " + _strParameter +" _lSeqNbr : " + _lSeqNbr+
    " _strFomMonth : " + _strFomMonth+ " _strToMonth : " + _strToMonth+" _strTarget : " + _strTarget+
    " StatusFlag : " + _strStatusFlag + "_lStandardSeqNbr :" + _lStandardSeqNbr;
    retValue = retValue + "_hmGpaMst:" + _hmGpaMst + "\n";
    return retValue;
  }

public String getTarget() {
	return _strTarget;
}

public void setTarget(String a_strTarget) {
	this._strTarget = a_strTarget;
}

public String getFomMonth() {
	return _strFomMonth;
}

public void setFomMonth(String a_strFomMonth) {
	this._strFomMonth = a_strFomMonth;
}

public String getToMonth() {
	return _strToMonth;
}

public void setToMonth(String a_strToMonth) {
	this._strToMonth = a_strToMonth;
}


}
