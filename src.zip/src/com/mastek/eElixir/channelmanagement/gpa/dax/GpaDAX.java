package com.mastek.eElixir.channelmanagement.gpa.dax;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.sql.Connection;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import com.mastek.eElixir.common.util.DBConnection;


import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardResult;

import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentCriteriaDetailsResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentCriteriaResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SqlRepositoryIF;

public class GpaDAX extends DAX
{
	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
	GpaResult _oGpaResult = null;

    /**
     * Constructor
     */
    public GpaDAX()
    {
    }
    /**
     *
     * @param a_strParameter
     * @return
     * @throws EElixirException
     */
	 public GpaStandardMasterResult searchGpaStandards(long a_strSeqNbr,String a_strParameter) throws EElixirException
	    {
		 log.debug("**********************************************************");
		 log.debug("a_strSeqNbr"+a_strSeqNbr);
		 log.debug("a_strParameter"+a_strParameter);
		 log.debug("**********************************************************");
		 GpaStandardResult _oGpaStandardResult = null;
		 GpaStandardMasterResult _oGpaStandardMasterResult = null;
		 ResultSet rsSearchGpa = null;

         PreparedStatement _pstmtFindPrimaryKey = null;
         ArrayList _oGpaList = new ArrayList();
         try
         {
        	 _oGpaStandardMasterResult = new GpaStandardMasterResult();

             log.debug("MasterDAX--in searchGpaStandards  :--- " +
            		 a_strSeqNbr);

             String strSelectSubChannelQuery =getSQLString("Select",
                     CHMConstants.GPA_STANDARD_SEARCH);
             log.debug(strSelectSubChannelQuery);

             if (_pstmtFindPrimaryKey == null)
             {
                 _pstmtFindPrimaryKey = getPreparedStatement(strSelectSubChannelQuery);
             }

             log.debug(_pstmtFindPrimaryKey + "");
             _pstmtFindPrimaryKey.setLong(1, a_strSeqNbr);
              rsSearchGpa = executeQuery(_pstmtFindPrimaryKey);
             log.debug("sunaina");
             _oGpaStandardMasterResult.setParameter(a_strParameter);
             log.debug("VALUE OF PARAMETER"+_oGpaStandardMasterResult.getParameter());
             _oGpaStandardMasterResult.setSeqNumb(new Long(a_strSeqNbr));
             while (rsSearchGpa.next())
             {
            	 _oGpaStandardResult = new GpaStandardResult();

               	 log.debug("before display condition");
               	_oGpaStandardResult.setIsDirty(DataConstants.DISPLAY_MODE);
            	 log.debug("after display condition");
            	 _oGpaStandardResult.setSeqNbr(new Long(rsSearchGpa.getLong("LGPASEQNBR")));
            	 log.debug("_oGpaStandardResult.getSeqNbr()"+_oGpaStandardResult.getSeqNbr());
            	 _oGpaStandardResult.setStandardSeqNbr(new Long(rsSearchGpa.getLong("LSTSEQNBR")));
            	 log.debug("_oGpaStandardResult.setStandardSeqNbr()"+_oGpaStandardResult.getStandardSeqNbr());


            	 _oGpaStandardResult.setStatusFlag(DataConstants.UPDATE_MODE);
            	 _oGpaStandardResult.setFomMonth(rsSearchGpa.getString("NFROMMONTH"));
            	 log.debug("_oGpaStandardResult.setFomMonth"+_oGpaStandardResult.getFomMonth());
            	 _oGpaStandardResult.setToMonth(rsSearchGpa.getString("NTOMONTH"));
            	 log.debug("_oGpaStandardResult.setToMonth"+_oGpaStandardResult.getToMonth());
            	 _oGpaStandardResult.setTarget(rsSearchGpa.getString("NTARGET"));
            	 log.debug(" _oGpaStandardResult.setTarget"+_oGpaStandardResult.getTarget());



                   if(rsSearchGpa.getTimestamp("DTUPDATED")!=null)
	            	 {

                	   _oGpaStandardResult.setTsDtUpdated(rsSearchGpa.getTimestamp("DTUPDATED"));
                   		log.debug("DTUPDATED"+_oGpaStandardResult.getDtUpdated());
	            	 }
	            	 else
	            	 {
	            		 _oGpaStandardResult.setTsDtUpdated(null);
	            		 log.debug("DTUPDATED"+_oGpaStandardResult.getDtUpdated());
	            	 }

                    log.debug("Sunaina Bhat");
                   	_oGpaList.add(_oGpaStandardResult);
             }
             log.debug("_oGpaList"+_oGpaList.size());
             _oGpaStandardMasterResult.setGpaStandResult(_oGpaList);

             return _oGpaStandardMasterResult;
         }
         catch (SQLException sqlex)
         {
             log.exception(sqlex.getMessage());
             throw new EElixirException(sqlex, "jan805");
         }
         catch (EElixirException eex)
         {
             log.exception(eex.getMessage());
             throw new EElixirException(eex, "jan805");
         }
         finally
         {
             try
             {
                 if (_pstmtFindPrimaryKey != null)
                 {
                     _pstmtFindPrimaryKey.close();
                 }
             }
             catch (SQLException sqlex)
             {
                 log.exception(sqlex.getMessage());
                 throw new EElixirException(sqlex, "jan805");
             }
         }

	    }

	 public GpaCriteriaMasterResult searchGpaCriteria(long a_strSeqNbr,String a_strParameter) throws EElixirException
	    {
		 log.debug("**********************************************************");
		 log.debug("a_strSeqNbr"+a_strSeqNbr);
		 log.debug("a_strParameter"+a_strParameter);
		 log.debug("**********************************************************");
		 GpaCriteriaResult _oGpaCriteriaResult = null;
		 GpaCriteriaMasterResult _oGpaCriteriaMasterResult = null;
		 ResultSet rsSearchGpa = null;

         PreparedStatement _pstmtFindPrimaryKey = null;
         ArrayList _oGpaList = new ArrayList();
         try
         {
        	 _oGpaCriteriaMasterResult = new GpaCriteriaMasterResult();

             log.debug("MasterDAX--in searchGpaStandards  :--- " +
            		 a_strSeqNbr);

             String strSelectSubChannelQuery =getSQLString("Select",
                     CHMConstants.GPA_BY_CRITERIASEQNUMB);
             log.debug(strSelectSubChannelQuery);

             if (_pstmtFindPrimaryKey == null)
             {
                 _pstmtFindPrimaryKey = getPreparedStatement(strSelectSubChannelQuery);
             }

             log.debug(_pstmtFindPrimaryKey + "");
             _pstmtFindPrimaryKey.setLong(1, a_strSeqNbr);
              rsSearchGpa = executeQuery(_pstmtFindPrimaryKey);
             log.debug("sunaina");
             _oGpaCriteriaMasterResult.setParameter(a_strParameter);
             log.debug("VALUE OF PARAMETER"+_oGpaCriteriaMasterResult.getParameter());
             _oGpaCriteriaMasterResult.setSeqNumb(new Long(a_strSeqNbr));
        	 while (rsSearchGpa.next())
             {
            	 _oGpaCriteriaResult = new GpaCriteriaResult();
            	 _oGpaCriteriaResult.setParameter(a_strParameter);
            	 log.debug("hi u are in rsSearchGpa.next");

               	 log.debug("before display condition");
               	_oGpaCriteriaResult.setIsDirty(DataConstants.DISPLAY_MODE);
            	 log.debug("after display condition");
            	 _oGpaCriteriaResult.setSeqNbr(new Long(rsSearchGpa.getLong("LGPASEQNBR")));
            	 log.debug("_oGpaCriteriaResult.getSeqNbr()"+_oGpaCriteriaResult.getSeqNbr());
            	 _oGpaCriteriaResult.setCriteriaSeqNbr(new Long(rsSearchGpa.getLong("LCTSEQNBR")));
            	 log.debug("_oGpaCriteriaResult.setCriteriaSeqNbr()"+_oGpaCriteriaResult.getCriteriaSeqNbr());


            	 _oGpaCriteriaResult.setStatusFlag(DataConstants.UPDATE_MODE);
            	 _oGpaCriteriaResult.setPoints(rsSearchGpa.getString("NPOINTS"));
            	 log.debug("_oGpaCriteriaResult.setPoints"+_oGpaCriteriaResult.getPoints());
            	 _oGpaCriteriaResult.setFomPercent(rsSearchGpa.getString("DPERCFROM"));
            	 log.debug("_oGpaCriteriaResult.setFomPercent"+_oGpaCriteriaResult.getFomPercent());
            	 _oGpaCriteriaResult.setToPercent(rsSearchGpa.getString("DPERCTO"));
            	 log.debug(" _oGpaCriteriaResult.setToPercent"+_oGpaCriteriaResult.getToPercent());



                   if(rsSearchGpa.getTimestamp("DTUPDATED")!=null)
	            	 {

                	   _oGpaCriteriaResult.setTsDtUpdated(rsSearchGpa.getTimestamp("DTUPDATED"));
                   		log.debug("DTUPDATED"+_oGpaCriteriaResult.getDtUpdated());
	            	 }
	            	 else
	            	 {
	            		 _oGpaCriteriaResult.setTsDtUpdated(null);
	            		 log.debug("DTUPDATED"+_oGpaCriteriaResult.getDtUpdated());
	            	 }

                    log.debug("Sunaina Bhat");
                   	_oGpaList.add(_oGpaCriteriaResult);
             }
             log.debug("_oGpaList"+_oGpaList.size());
             _oGpaCriteriaMasterResult.setGpaCriteriaResult(_oGpaList);
             log.debug("results are set");
             return _oGpaCriteriaMasterResult;
         }
         catch (SQLException sqlex)
         {
             log.exception(sqlex.getMessage());
             throw new EElixirException(sqlex, "p8106");
         }
         catch (EElixirException eex)
         {
             log.exception(eex.getMessage());
             throw new EElixirException(eex, "p8106");
         }
         finally
         {
             try
             {
                 if (_pstmtFindPrimaryKey != null)
                 {
                     _pstmtFindPrimaryKey.close();
                 }
             }
             catch (SQLException sqlex)
             {
                 log.exception(sqlex.getMessage());
                 throw new EElixirException(sqlex, "p8106");
             }
         }

	    }

	 /**
	     * Description getSQLString takes querytype and key and returns query
	     * @return query string
	     * @param a_strSQLType SQL Type i.e Select , Insert , Delete , Update
	     * @param a_strKey String
	     * @throws EElixirException
	     */
	   private String getSQLString(String a_strSQLType, String a_strKey)
	       throws EElixirException
	   {
	       SqlRepositoryIF sqlRFIF = null;
	       String strSql = "";

	       try
	       {
	           sqlRFIF = CHMSqlRepository.getSqlRepository();
	           strSql = sqlRFIF.getSQLString(a_strKey, a_strSQLType);
	       }
	       catch (EElixirException eex)
	       {
	           log.debug("GPADax--sql ex" + eex);
	           log.exception(eex.getMessage());
	           throw new EElixirException(eex, "P3019"); // could not get sql string
	       }

	       return strSql;
	   }
	   /**
	    *
	    * @param a_strDesignation
	    * @return
	    * @throws EElixirException
	    */
	   public ArrayList searchDesignationGpa(String a_strDesignation ) throws EElixirException
	    {
		   ResultSet rsSearchGpa = null;
	         PreparedStatement _pstmtFindPrimaryKey = null;
	         ArrayList _oGpaList = new ArrayList();
	         try
	         {
	             log.debug("MasterDAX--in searchDesignationGpa  :--- " +
	            		 a_strDesignation);

	             String strSelectSubChannelQuery =getSQLString("Select",
	                     CHMConstants.FIND_GPA_BY_DESIGNATION);
	             log.debug(strSelectSubChannelQuery);

	             if (_pstmtFindPrimaryKey == null)
	             {
	                 _pstmtFindPrimaryKey = getPreparedStatement(strSelectSubChannelQuery);
	             }

	             log.debug(_pstmtFindPrimaryKey + "");
	             _pstmtFindPrimaryKey.setString(1, a_strDesignation);
	              rsSearchGpa = executeQuery(_pstmtFindPrimaryKey);
	             log.debug("sunaina");
	             while (rsSearchGpa.next())
	             {
	            	 log.debug("hi u are in rsSearchGpa.next");
	            	 _oGpaResult = new GpaResult();
	               	 log.debug("before display condition");
	            	 _oGpaResult.setIsDirty(DataConstants.DISPLAY_MODE);
	            	 log.debug("after display condition");
	            	 _oGpaResult.setSeqNbr(new Long(rsSearchGpa.getLong("LGPASEQNBR")));
	            	 log.debug("_oGpaResult.getSeqNbr()"+_oGpaResult.getSeqNbr());

	            	 _oGpaResult.setDesignation(rsSearchGpa.getString(
	    			 "STRDESGNCD"));

	            	 _oGpaResult.setStatusFlag(DataConstants.UPDATE_MODE);

	            	 log.debug("STRdesignation"+_oGpaResult.getDesignation());
	            	 _oGpaResult.setFreqOfCalc(new Short(rsSearchGpa.getString(
	    			 "NFREQUENCY")));
	            	 log.debug("NFREQUENCY"+_oGpaResult.getFreqOfCalc());
	            	 _oGpaResult.setFreqOfProd(new Short(rsSearchGpa.getString(
	    			 "NPRODNFREQ")));
	            	 log.debug("NPRODNFREQ"+_oGpaResult.getFreqOfProd());
	            	 _oGpaResult.setParameter(rsSearchGpa.getString(
	            			 "STRPARAMCD"));
	            	 log.debug("STRPARAMCD"+_oGpaResult.getParameter());
	            	 _oGpaResult.setWeightage1(rsSearchGpa.getString("NWEIGHTAGE1"));
	            	 log.debug("weightage1"+_oGpaResult.getWeightage1());
	            	 _oGpaResult.setWeightage2(rsSearchGpa.getString("NWEIGHTAGE2"));
	            	 log.debug("weightage1"+_oGpaResult.getWeightage2());
	            	 _oGpaResult.setWeightage3(rsSearchGpa.getString("NWEIGHTAGE3"));
	            	 _oGpaResult.setSegmention(rsSearchGpa.getString("NSEGMENTAPPL"));
	            	 log.debug("NSEGMENTAPPL"+_oGpaResult.getSegmention());

	            	 if(rsSearchGpa.getTimestamp("DTEFFFROM")!=null)
	                   	{
	            		 _oGpaResult.setDtEffFrom(DateUtil.retGregorian(
	            				 rsSearchGpa.getTimestamp("DTEFFFROM")));
	            		 log.debug("DTEFFFROM"+_oGpaResult.getDtEffFrom());
	                   	}
	                   	else
	                   	{
	                   	 log.debug("DTEFFFROM"+_oGpaResult.getDtEffFrom());
	                   		_oGpaResult.setDtEffFrom(null);
	                   	}
	                   	if(rsSearchGpa.getTimestamp("DTEFFTO")!=null)
	                   	{
	                   		_oGpaResult.setDtEffTo(DateUtil.retGregorian(
	                   				rsSearchGpa.getTimestamp("DTEFFTO")));
	                   		log.debug("DTEFFTO"+_oGpaResult.getDtEffTo());
	                   	}
	                   	else
	                   	{
	                   		_oGpaResult.setDtEffTo(null);
	                   		log.debug("DTEFFTO"+_oGpaResult.getDtEffTo());
	                   	}
	                   if(rsSearchGpa.getTimestamp("DTUPDATED")!=null)
		            	 {

	                   		_oGpaResult.setTsDtUpdated(rsSearchGpa.getTimestamp("DTUPDATED"));
	                   		log.debug("DTUPDATED"+_oGpaResult.getDtUpdated());
		            	 }
		            	 else
		            	 {
		            		 _oGpaResult.setTsDtUpdated(null);
		            		 log.debug("DTUPDATED"+_oGpaResult.getDtUpdated());
		            	 }

	                   //Modified by Prabhat for July_PH2_SMGPA start
	                   _oGpaResult.setCumulativeNcumulative(rsSearchGpa.getInt("NISCUMLATIVE"));
	                	 log.debug("NISCUMLATIVE "+_oGpaResult.getCumulativeNcumulative());
	                	 //Modified by Prabhat for July_PH2_SMGPA End
	                   	_oGpaList.add(_oGpaResult);
	             }

	             return _oGpaList;
	         }
	         catch (SQLException sqlex)
	         {
	             log.exception(sqlex.getMessage());
	             throw new EElixirException(sqlex, "p8107");
	         }
	         catch (EElixirException eex)
	         {
	             log.exception(eex.getMessage());
	             throw new EElixirException(eex, "p8107");
	         }
	         finally
	         {
	             try
	             {
	                 if (_pstmtFindPrimaryKey != null)
	                 {
	                     _pstmtFindPrimaryKey.close();
	                 }
	             }
	             catch (SQLException sqlex)
	             {
	                 log.exception(sqlex.getMessage());
	                 throw new EElixirException(sqlex, "p8107");
	             }
	         }

	    }

	   public Long getNextSeqNbr() throws EElixirException
	   {
	       Statement stmtNextSeq = null;
	       long lSeqNo;

	       try
	       {
	           String strNextSeqQuery = getSQLString("Select", CHMConstants.GPA_SEQUENCENO );
	           log.debug("strNextSeqQuery"+strNextSeqQuery);

	           stmtNextSeq = getStatement();

	           ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
	           rsSeqNo.next();
	           lSeqNo = rsSeqNo.getLong(1);
	           log.debug(lSeqNo + "lSeqNo****************");

	           return new Long(lSeqNo);
	       } catch (SQLException sqlex)
	       {
	           log.exception(sqlex.getMessage());
	           throw new EElixirException(sqlex, "P9006");
	       } catch (EElixirException eex)
	       {
	           log.exception(eex.getMessage());
	           throw new EElixirException(eex, "P9006");
	       } finally
	       {
	           try
	           {
	               if (stmtNextSeq != null)
	               {
	            	   stmtNextSeq.close();
	               }
	           } catch (SQLException sqlex)
	           {
	               log.exception(sqlex.getMessage());
	               throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
	           }
	       }
	   }

	   public Long getStandardNextSeqNo() throws EElixirException
	   {
	       Statement stmtNextSeq = null;
	       long lSeqNo;

	       try
	       {
	           String strNextSeqQuery = getSQLString("Select", CHMConstants.GPA_STANDARD_SEQUENCENO );
	           log.debug("StandardNextSeqNo"+strNextSeqQuery);

	           stmtNextSeq = getStatement();

	           ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
	           rsSeqNo.next();
	           lSeqNo = rsSeqNo.getLong(1);
	           log.debug(lSeqNo + "lSeqNo****************");

	           return new Long(lSeqNo);
	       } catch (SQLException sqlex)
	       {
	           log.exception(sqlex.getMessage());
	           throw new EElixirException(sqlex, "P9006");
	       } catch (EElixirException eex)
	       {
	           log.exception(eex.getMessage());
	           throw new EElixirException(eex, "P9006");
	       } finally
	       {
	           try
	           {
	               if (stmtNextSeq != null)
	               {
	            	   stmtNextSeq.close();
	               }
	           } catch (SQLException sqlex)
	           {
	               log.exception(sqlex.getMessage());
	               throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
	           }
	       }
	   }

	   public Long getCriteriaNextSeqNo() throws EElixirException
	   {
	       Statement stmtNextSeq = null;
	       long lSeqNo;

	       try
	       {
	           String strNextSeqQuery = getSQLString("Select", CHMConstants.GPA_CRITERIA_SEQUENCENO );
	           log.debug("CriteriaNextSeqNo"+strNextSeqQuery);

	           stmtNextSeq = getStatement();

	           ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
	           rsSeqNo.next();
	           lSeqNo = rsSeqNo.getLong(1);
	           log.debug(lSeqNo + "lSeqNo****************");

	           return new Long(lSeqNo);
	       } catch (SQLException sqlex)
	       {
	           log.exception(sqlex.getMessage());
	           throw new EElixirException(sqlex, "P9006");
	       } catch (EElixirException eex)
	       {
	           log.exception(eex.getMessage());
	           throw new EElixirException(eex, "P9006");
	       } finally
	       {
	           try
	           {
	               if (stmtNextSeq != null)
	               {
	            	   stmtNextSeq.close();
	               }
	           } catch (SQLException sqlex)
	           {
	               log.exception(sqlex.getMessage());
	               throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
	           }
	       }
	   }

	   public boolean findGpaprimarykey(long a_lgpaseqnbr) throws EElixirException
	   {
	       ResultSet rsSearchGpa = null;
	       PreparedStatement pstmtFindPrimaryKey = null;

	       try
	       {
	           String strSelectQuery = getSQLString("Select", CHMConstants.FIND_Gpa_BY_PRIMARYKEY);
	           log.debug("strSelectQuery**********"+strSelectQuery);

	           if (pstmtFindPrimaryKey == null)
	           {
	               pstmtFindPrimaryKey = getPreparedStatement(strSelectQuery);
	           }

	           pstmtFindPrimaryKey.setLong(1, a_lgpaseqnbr);

	           rsSearchGpa = executeQuery(pstmtFindPrimaryKey);

	           if (rsSearchGpa.next())
	           {
	               return true;
	           } else
	           {
	               return false;
	           }
	       } catch (SQLException sqlex)
	       {
	           log.exception(sqlex.getMessage());
	           throw new EElixirException(sqlex, "p8108");
	       } catch (EElixirException eex)
	       {
	           log.exception(eex.getMessage());
	           throw new EElixirException(eex, "p8108");
	       } finally
	       {
	           try
	           {
	               if (rsSearchGpa != null)
	               {
	            	   rsSearchGpa.close();
	               }

	               if (pstmtFindPrimaryKey != null)
	               {
	                   pstmtFindPrimaryKey.close();
	               }
	           } catch (SQLException sqlex)
	           {
	               log.exception(sqlex.getMessage());
	               throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
	           }
	       }
	   }
	   public Long createGpa(GpaResult a_oGpaResult)
	   throws EElixirException
	   {
	     PreparedStatement pstmtCreateGpa = null;
	      Long lprdsegseqnbr;

	     try
	     {
		   String strInsertGpaQuery = getSQLString("Insert",CHMConstants.GPA_INSERT );
		   log.debug("strInsertGpaQuery"+strInsertGpaQuery);
		   pstmtCreateGpa = getPreparedStatement(strInsertGpaQuery);
	       lprdsegseqnbr = getNextSeqNbr();
	       GregorianCalendar dtEffFrom=a_oGpaResult.getDtEffFrom();
           GregorianCalendar dtEffTo=a_oGpaResult.getDtEffTo();

	       int iPos = 0;
	       pstmtCreateGpa.setLong(++iPos,lprdsegseqnbr.longValue());
	       pstmtCreateGpa.setString(++iPos,
	    		   a_oGpaResult.getDesignation());
	       pstmtCreateGpa.setString(++iPos,
	    		   a_oGpaResult.getParameter());
	       pstmtCreateGpa.setString(++iPos,
	    		   a_oGpaResult.getWeightage1());
	       pstmtCreateGpa.setString(++iPos,
	    		   a_oGpaResult.getWeightage2());
	       pstmtCreateGpa.setString(++iPos,
	    		   a_oGpaResult.getWeightage3());
	       pstmtCreateGpa.setString(++iPos,
	    		   a_oGpaResult.getSegmention());
	       if (dtEffFrom != null)
           {
	    	   pstmtCreateGpa.setTimestamp(++iPos, DateUtil.retTimestamp(dtEffFrom));
           }
	       if (dtEffTo != null)
           {
	    	   pstmtCreateGpa.setTimestamp(++iPos, DateUtil.retTimestamp(dtEffTo));
           }
	       //Amid_Updated strCreatedBy Start
	       pstmtCreateGpa.setString(++iPos, a_oGpaResult.getUserId());
	       //Amid_Updated strCreatedBy End
	       pstmtCreateGpa.setShort(++iPos,
	    		   a_oGpaResult.getFreqOfCalc().shortValue());
	       pstmtCreateGpa.setShort(++iPos,
	    		   a_oGpaResult.getFreqOfProd().shortValue());


	       //Modified by Prabhat for July_PH2_SMGPA start
	       pstmtCreateGpa.setInt(++iPos, a_oGpaResult.getCumulativeNcumulative());
	       //Modified by Prabhat for July_PH2_SMGPAJuly_PH2_SMGPA End	


	       executeUpdate(pstmtCreateGpa);
	       log.debug("lprdsegseqnbr!!!!!!!!!!!"+lprdsegseqnbr);
	       return lprdsegseqnbr;
	     }
	      catch (SQLException sqlex)
	      {
	       sqlex.printStackTrace();
	       log.fatal(sqlex.getMessage());
	       throw new EElixirException(sqlex, "p8109");
	      }
	      catch (EElixirException eex)
	     {
	       eex.printStackTrace();
	       log.fatal(eex.getMessage());
	       throw new EElixirException(eex, "p8109");
	     }
	     finally
	     {
	        try
	        {
	           if (pstmtCreateGpa != null)
	           {
	        	   pstmtCreateGpa.close();
	           }
	        }
	         catch (SQLException sqlex)
	         {
	           sqlex.printStackTrace();
	           log.fatal(sqlex.getMessage());
	           throw new EElixirException(sqlex, "p8109");
	        }
	     }
	  }
/**
 *
 * @param a_lprdsegseqnbr
 * @return
 * @throws EElixirException
 */

	   public GpaResult getGpa(long a_lprdsegseqnbr)
	   throws EElixirException
	   {
	   ResultSet rsSearchGpa = null;
	   PreparedStatement pstmtSearchSegment= null;

	   GpaResult  _oGpaResult = new GpaResult();
	   try
	   {
	       String strSelectGpaQuery = getSQLString("Select",
	               CHMConstants.SEARCH_GPA_BY_PK);
	       log.debug("SEARCH_Gpa "+strSelectGpaQuery);
	       log.debug("SegmenatDAX--primary key is " + a_lprdsegseqnbr);
	       pstmtSearchSegment = getPreparedStatement(strSelectGpaQuery);
	       pstmtSearchSegment.setLong(1, a_lprdsegseqnbr);
	       rsSearchGpa = executeQuery(pstmtSearchSegment);
	       log.debug("BenefitDAX--Query executed properly");

	       if (rsSearchGpa.next())
	       {
	    	   _oGpaResult.setIsDirty(DataConstants.DISPLAY_MODE);
          	 _oGpaResult.setDesignation(rsSearchGpa.getString(
  			 "STRDESGNCD"));
          	 log.debug("STRPARAMCD"+_oGpaResult.getDesignation());
          	_oGpaResult.setFreqOfCalc(new Short(rsSearchGpa.getString(
			 "NFREQUENCY")));
       	    log.debug("NFREQUENCY"+_oGpaResult.getFreqOfCalc());
       	   _oGpaResult.setFreqOfProd(new Short(rsSearchGpa.getString(
			 "NPRODNFREQ")));
       	    log.debug("NPRODNFREQ"+_oGpaResult.getFreqOfProd());
          	 _oGpaResult.setParameter(rsSearchGpa.getString(
          			 "STRPARAMCD"));
          	 log.debug("STRPARAMCD"+_oGpaResult.getParameter());
          	 _oGpaResult.setWeightage1(rsSearchGpa.getString("NWEIGHTAGE1"));
          	 log.debug("weightage1"+_oGpaResult.getWeightage1());
          	 _oGpaResult.setWeightage2(rsSearchGpa.getString("NWEIGHTAGE2"));
          	 log.debug("weightage1"+_oGpaResult.getWeightage2());
          	 _oGpaResult.setWeightage3(rsSearchGpa.getString("NWEIGHTAGE3"));
          	 _oGpaResult.setSegmention(rsSearchGpa.getString("NSEGMENTAPPL"));
          	 log.debug("NSEGMENTAPPL"+_oGpaResult.getSegmention());

          	 if(rsSearchGpa.getTimestamp("DTEFFFROM")!=null)
                 	{
          		 _oGpaResult.setDtEffFrom(DateUtil.retGregorian(
          				 rsSearchGpa.getTimestamp("DTEFFFROM")));
          		 log.debug("DTEFFFROM"+_oGpaResult.getDtEffFrom());
                 	}
                 	else
                 	{
                 	 log.debug("DTEFFFROM"+_oGpaResult.getDtEffFrom());
                 		_oGpaResult.setDtEffFrom(null);
                 	}
                 	if(rsSearchGpa.getTimestamp("DTEFFTO")!=null)
                 	{
                 		_oGpaResult.setDtEffTo(DateUtil.retGregorian(
                 				rsSearchGpa.getTimestamp("DTEFFTO")));
                 		log.debug("DTEFFTO"+_oGpaResult.getDtEffTo());
                 	}
                 	else
                 	{
                 		_oGpaResult.setDtEffTo(null);
                 		log.debug("DTEFFTO"+_oGpaResult.getDtEffTo());
                 	}
                 if(rsSearchGpa.getTimestamp("DTUPDATED")!=null)
	            	 {

                 		_oGpaResult.setTsDtUpdated(rsSearchGpa.getTimestamp("DTUPDATED"));
                 		log.debug("DTUPDATED"+_oGpaResult.getDtUpdated());
	            	 }
	            	 else
	            	 {
	            		 _oGpaResult.setTsDtUpdated(null);
	            		 log.debug("DTUPDATED"+_oGpaResult.getDtUpdated());
	            	 }

                 //Modified by Prabhat for July_PH2_SMGPA start
                 _oGpaResult.setCumulativeNcumulative(rsSearchGpa.getInt("NISCUMLATIVE"));
              	 log.debug("NISCUMLATIVE "+_oGpaResult.getCumulativeNcumulative());
              	 //Modified by Prabhat for July_PH2_SMGPA End

	       }
	       return _oGpaResult;
	   }
	   catch (SQLException sqlex)
	   {
	       log.exception(sqlex.getMessage());
	       throw new EElixirException(sqlex, "p8110");
	   }
	   catch (EElixirException eex)
	   {
	       log.exception(eex.getMessage());
	       throw new EElixirException(eex, "p8110");
	   }
	   finally
	   {
	       try
	       {
	           if (rsSearchGpa != null)
	           {
	        	   rsSearchGpa.close();
	           }

	           if (pstmtSearchSegment != null)
	           {
	          	 pstmtSearchSegment.close();
	           }
	       }
	       catch (SQLException sqlex)
	       {
	           log.exception(sqlex.getMessage());
	           throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
	       }
	   }

	 }
	   public int deleteGpa(GpaResult oGpaResult)
	   throws EElixirException
	{
	   PreparedStatement _pstmtSegment = null;
	   try
	   {

	       String strdeleteGpa = getSQLString("Delete",
	               CHMConstants.GPA_DELETE);
	       log.debug("GpaDAX--query is  " +
	    		   strdeleteGpa);

	       _pstmtSegment = getPreparedStatement(strdeleteGpa);
	        log.debug(" oGpaResult.getSegSeqNbr().longValue()"+oGpaResult.getSeqNbr());
	       _pstmtSegment.setLong(1,
	    		   oGpaResult.getSeqNbr().longValue());

	      int iRemoveGpa= executeUpdate(_pstmtSegment);
	      log.debug("iRemoveGpa*******************"+iRemoveGpa);
	       return iRemoveGpa;
	   }
	   catch (SQLException sqlex)
	   {
	       log.debug("GpaDAX------deleteGpa()----- DAX---SQL");
	       log.exception(sqlex.getMessage());

	       throw new EElixirException("p8111");
	   }
	   catch (EElixirException eex)
	   {
	       log.debug("GpaDAX------deleteGpa()----- DAX--- EE");
	       log.exception(eex.getMessage());
	       throw new EElixirException("p8111");
	   }
	   finally
	   {
	       try
	       {
	           if (_pstmtSegment != null)
	           {
	          	 _pstmtSegment.close();
	           }
	       }
	       catch (SQLException sqlex)
	       {
	           log.exception(sqlex.getMessage());
	           throw new EElixirException(sqlex, "p8111");
	       }
	   }
	}
	   public void updateGpaStandard(GpaStandardMasterResult a_oGpaStandardMasterResult)throws EElixirException
	   {
		   if(a_oGpaStandardMasterResult.getGpaStandResult()!=null)
		   {
			   for(int i=0;i<a_oGpaStandardMasterResult.getGpaStandResult().size();i++)
			   {
				  GpaStandardResult a_oGpaStandardResult=
					 (GpaStandardResult)  a_oGpaStandardMasterResult.getGpaStandResult().get(i);
				   if(a_oGpaStandardResult.getStatusFlag().equals(DataConstants.INSERT_MODE))
				   {
					   log.debug("SegmentDax1-->Status flag is--> "+a_oGpaStandardResult.getStatusFlag());
					   createStandardGpa(a_oGpaStandardResult,a_oGpaStandardMasterResult);
				   }
				   else if(a_oGpaStandardResult.getStatusFlag().equals(DataConstants.UPDATE_MODE))
				   {
					   log.debug("SegmentDax2-->Status flag is--> "+a_oGpaStandardResult.getStatusFlag());
					   updateGpaStandard(a_oGpaStandardResult,a_oGpaStandardMasterResult);
				   }
				   else if(a_oGpaStandardResult.getStatusFlag().equals(DataConstants.DELETE_MODE))
				   {
					   log.debug("SegmentDax3-->Status flag is--> "+a_oGpaStandardResult.getStatusFlag());
					   deleteGpaStandard(a_oGpaStandardResult,a_oGpaStandardMasterResult);
				   }
			   }
		   }

	   }
	   public void updateGpaStandard(GpaStandardResult a_oGpaStandardResult,GpaStandardMasterResult _oGpaStandardMasterResult)throws EElixirException
	   {
		   PreparedStatement pstmtUpdateGpaStandard = null;
            log.debug("updateeeeeeeeeeeeeeeeee mode********************************");
	        try
	        {
	            String strUpdateQuery = getSQLString("Update",
	                    CHMConstants.GPA_STANDARD_UPDATE);
	            pstmtUpdateGpaStandard = getPreparedStatement(strUpdateQuery);
	            log.debug("-query is ->"+strUpdateQuery);
	            String strTarget = a_oGpaStandardResult.getTarget();
	            String strFromMonth = a_oGpaStandardResult.getFomMonth();
	            String strToMonth = a_oGpaStandardResult.getToMonth();
	            String strUpdatedBy= a_oGpaStandardResult.getUserId();
	            Long lgpaseqnbr = _oGpaStandardMasterResult.getSeqNumb();
	            Long lstseqnbr = a_oGpaStandardResult.getStandardSeqNbr();
	            log.debug("a_oGpaStandardResult.getStandardSeqNbr()-> " +lstseqnbr);


	            pstmtUpdateGpaStandard.setString(1, strTarget);
	            pstmtUpdateGpaStandard.setString(2, strFromMonth);
	            pstmtUpdateGpaStandard.setString(3, strToMonth);
	            pstmtUpdateGpaStandard.setString(4, strUpdatedBy);
	            pstmtUpdateGpaStandard.setLong(5, lgpaseqnbr.longValue());
	            pstmtUpdateGpaStandard.setLong(6, lstseqnbr.longValue());
	            int iUpdate = executeUpdate(pstmtUpdateGpaStandard);
	            log.debug("No of rows updated in UpdateSegmentcriteria() is "+iUpdate);

	        }
	        catch (SQLException sqlex)
	        {
	            log.exception(sqlex.getMessage());

	            throw new EElixirException(sqlex, "p8112");
	        }
	        catch (EElixirException eex)
	        {
	            log.exception(eex.getMessage());
	            throw new EElixirException(eex, "p8112");
	        }
	        finally
	        {
	            try
	            {
	                if (pstmtUpdateGpaStandard != null)
	                {
	                	pstmtUpdateGpaStandard.close();
	                }
	            }
	            catch (SQLException sqlex)
	            {
	                log.exception(sqlex.getMessage());
	                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
	            }
	        }

	   }

	   public void deleteGpaStandard(GpaStandardResult a_oGpaStandardResult,GpaStandardMasterResult _oGpaStandardMasterResult)
	   throws EElixirException
	   {
		     PreparedStatement _pstmtSegment = null;
		     log.debug("DELETEEEEEEEEEEEEEEEEEEE mode********************************");
		      try
		      {

		          String strdeleteSegment = getSQLString("Delete",
		                  CHMConstants.GPASTANDARD_DELETE);
		          log.debug("GpaDAX----deleteGpaStandard()--query is  " +
		         		 strdeleteSegment);
		          Long lgpaseqnbr = _oGpaStandardMasterResult.getSeqNumb();
		          log.debug(" Sequence number 1------> "+_oGpaStandardMasterResult.getSeqNumb());
		          Long lstseqnbr = a_oGpaStandardResult.getStandardSeqNbr();
		          log.debug(" Sequence number 2------> "+ a_oGpaStandardResult.getStandardSeqNbr());

		          _pstmtSegment = getPreparedStatement(strdeleteSegment);

		          _pstmtSegment.setLong(1,lgpaseqnbr.longValue());

		          _pstmtSegment.setLong(2,lstseqnbr.longValue());

		         int iRemoveGpaStandard= executeUpdate(_pstmtSegment);
		         log.debug(" iRemoveGpaStandard"+iRemoveGpaStandard);

		      }
		      catch (SQLException sqlex)
		      {
		          log.debug("GpaDAX------deleteGpaStandard()----- DAX---SQL");
		          log.exception(sqlex.getMessage());

		          throw new EElixirException("jan813");
		      }
		      catch (EElixirException eex)
		      {
		          log.debug("GpaDAX------deleteGpaStandard()----- DAX--- EE");
		          log.exception(eex.getMessage());
		          throw new EElixirException("jan813");
		      }
		      finally
		      {
		          try
		          {
		              if (_pstmtSegment != null)
		              {
		             	 _pstmtSegment.close();
		              }
		          }
		          catch (SQLException sqlex)
		          {
		              log.exception(sqlex.getMessage());
		              throw new EElixirException(sqlex, "jan813");
		          }
		      }

	   }


	   public Long createStandardGpa(GpaStandardResult a_oGpaStandardResult,GpaStandardMasterResult a_oGpaStandardMasterResult)throws EElixirException
	   {
		   log.debug("U ARE IN INSERT MODEEEEEEEEEEE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		   PreparedStatement pstmtCreateGpaStandard = null;
		      Long lstseqnbr;

		     try
		     {
			   String strInsertSegmentMstQuery = getSQLString("Insert",CHMConstants.GPA_STANDARD_INSERT);
			   log.debug("strInsertSegmentMstQuery"+strInsertSegmentMstQuery);
			   pstmtCreateGpaStandard = getPreparedStatement(strInsertSegmentMstQuery);
			   lstseqnbr = getStandardNextSeqNo();
			   log.debug("sunainananananan"+lstseqnbr);

		       int iPos = 0;
		      log.debug("start inserting");
		       pstmtCreateGpaStandard.setLong(++iPos, a_oGpaStandardMasterResult.getSeqNumb().longValue());
		       log.debug("a_oGpaStandardResult.getSeqNbr().longValue()"+a_oGpaStandardMasterResult.getSeqNumb().longValue());
		       pstmtCreateGpaStandard.setLong(++iPos,lstseqnbr.longValue());
		       log.debug("lstseqnbr.longValue()"+lstseqnbr.longValue());
		       pstmtCreateGpaStandard.setString(++iPos,
		    		   a_oGpaStandardResult.getTarget());
		       log.debug("a_oGpaStandardResult.getTarget()"+a_oGpaStandardResult.getTarget());
		       pstmtCreateGpaStandard.setString(++iPos,
		    		   a_oGpaStandardResult.getFomMonth());
		       log.debug("a_oGpaStandardResult.getFomMonth()"+a_oGpaStandardResult.getFomMonth());
		       pstmtCreateGpaStandard.setString(++iPos,
		    		   a_oGpaStandardResult.getToMonth());
		       log.debug("a_oGpaStandardResult.getToMonth()"+a_oGpaStandardResult.getToMonth());
		       pstmtCreateGpaStandard.setString(++iPos, a_oGpaStandardResult.getUserId());
		       log.debug("a_oGpaStandardResult.getUserId()"+a_oGpaStandardResult.getUserId());


		       executeUpdate(pstmtCreateGpaStandard);
		       log.debug("lstseqnbr1111111111111111"+lstseqnbr);
		       return lstseqnbr;
		     }
		      catch (SQLException sqlex)
		      {
		       sqlex.printStackTrace();
		       log.fatal(sqlex.getMessage());
		       throw new EElixirException(sqlex, "p7136");
		      }
		      catch (EElixirException eex)
		     {
		       eex.printStackTrace();
		       log.fatal(eex.getMessage());
		       throw new EElixirException(eex, "p7136");
		     }
		     finally
		     {
		        try
		        {
		           if (pstmtCreateGpaStandard != null)
		           {
		        	   pstmtCreateGpaStandard.close();
		           }
		        }
		         catch (SQLException sqlex)
		         {
		           sqlex.printStackTrace();
		           log.fatal(sqlex.getMessage());
		           throw new EElixirException(sqlex, "p7136");
		        }
		     }

	   }
	   public int updateGpaDes(GpaResult _oGpaResult)
	   throws EElixirException
	   {
	     PreparedStatement pstmtUpdateGpa = null;
	     log.debug("U ARE IN UPDATE MODEEEEEEEEEEE");


	   try
	   {
	       String strUpdateQuery = getSQLString("Update",
	               CHMConstants.GPA_UPDATE );
	       pstmtUpdateGpa = getPreparedStatement(strUpdateQuery);
	       log.debug("-query is ->"+strUpdateQuery);
	       log.debug("statusflag is "+_oGpaResult.getStatusFlag());
	       Long lgpaseqnbr = _oGpaResult.getSeqNbr();
	       GregorianCalendar dtEffFrom=_oGpaResult.getDtEffFrom();
           GregorianCalendar dtEffTo=_oGpaResult.getDtEffTo();

	       pstmtUpdateGpa.setString(1, _oGpaResult.getParameter());
	       pstmtUpdateGpa.setString(2, _oGpaResult.getWeightage1());
	       pstmtUpdateGpa.setString(3, _oGpaResult.getWeightage2());
	       pstmtUpdateGpa.setString(4, _oGpaResult.getWeightage3());
	       pstmtUpdateGpa.setString(5, _oGpaResult.getSegmention());
	       pstmtUpdateGpa.setTimestamp(6,DateUtil.retTimestamp(dtEffFrom));
	       pstmtUpdateGpa.setTimestamp(7,DateUtil.retTimestamp(dtEffTo));
	       pstmtUpdateGpa.setShort(8, _oGpaResult.getFreqOfCalc().shortValue());
	       pstmtUpdateGpa.setShort(9, _oGpaResult.getFreqOfProd().shortValue());
	       pstmtUpdateGpa.setString(10, _oGpaResult.getUserId());
	     //Modified by Prabhat for July_PH2_SMGPA start
	       pstmtUpdateGpa.setInt(11, _oGpaResult.getCumulativeNcumulative());
	     //Modified by Prabhat for July_PH2_SMGPA End
	       pstmtUpdateGpa.setLong(12, lgpaseqnbr.longValue());

	       int iUpdate = executeUpdate(pstmtUpdateGpa);


	       return iUpdate;
	   }
	   catch (SQLException sqlex)
	   {
	       log.exception(sqlex.getMessage());
	       throw new EElixirException(sqlex, "jan815");
	   }
	   catch (EElixirException eex)
	   {
	       log.exception(eex.getMessage());
	       throw new EElixirException(eex, "jan815");
	   }
	   finally
	   {
	       try
	       {
	           if (pstmtUpdateGpa != null)
	           {
	        	   pstmtUpdateGpa.close();
	           }
	       }
	       catch (SQLException sqlex)
	       {
	           log.exception(sqlex.getMessage());
	           throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
	       }
	    }
	 }

	   public void updateGpaCriteria(GpaCriteriaMasterResult a_oGpaCriteriaMasterResult)throws EElixirException
	   {
		   if(a_oGpaCriteriaMasterResult.getGpaCriteriaResult()!=null)
		   {
			   for(int i=0;i<a_oGpaCriteriaMasterResult.getGpaCriteriaResult().size();i++)
			   {
				   GpaCriteriaResult a_oGpaCriteriaResult =
					 (GpaCriteriaResult)  a_oGpaCriteriaMasterResult.getGpaCriteriaResult().get(i);
				   if(a_oGpaCriteriaResult.getStatusFlag().equals(DataConstants.INSERT_MODE))
				   {
					   log.debug("GPADax1-->Status flag is--> "+a_oGpaCriteriaResult.getStatusFlag());
					   createCriteriaGpa(a_oGpaCriteriaResult,a_oGpaCriteriaMasterResult);
				   }
				   else if(a_oGpaCriteriaResult.getStatusFlag().equals(DataConstants.UPDATE_MODE))
				   {
					   log.debug("GPADax2-->Status flag is--> "+a_oGpaCriteriaResult.getStatusFlag());
					   updateGpaCriteria(a_oGpaCriteriaResult,a_oGpaCriteriaMasterResult);
				   }
				   else if(a_oGpaCriteriaResult.getStatusFlag().equals(DataConstants.DELETE_MODE))
				   {
					   log.debug("GPADax3-->Status flag is--> "+a_oGpaCriteriaResult.getStatusFlag());
					   deleteGpaStandard(a_oGpaCriteriaResult,a_oGpaCriteriaMasterResult);
				   }
			   }
		   }

	   }

	   public void deleteGpaStandard(GpaCriteriaResult a_oGpaCriteriaResult,GpaCriteriaMasterResult a_oGpaCriteriaMasterResult)
	   throws EElixirException
	   {
		     PreparedStatement _pstmtSegment = null;
		     log.debug("DELETEEEEEEEEEEEEEEEEEEE mode********************************");
		      try
		      {

		          String strdeleteSegment = getSQLString("Delete",
		                  CHMConstants.GPACRITERIA_DELETE);
		          log.debug("GpaDAX----deleteGpaStandard()--query is  " +
		         		 strdeleteSegment);
		          Long lgpaseqnbr = a_oGpaCriteriaMasterResult.getSeqNumb();
		          log.debug(" Sequence number 1------> "+a_oGpaCriteriaMasterResult.getSeqNumb());
		          Long lstseqnbr = a_oGpaCriteriaResult.getCriteriaSeqNbr();
		          log.debug(" Sequence number 2------> "+lstseqnbr);

		          _pstmtSegment = getPreparedStatement(strdeleteSegment);

		          _pstmtSegment.setLong(1,lgpaseqnbr.longValue());

		          _pstmtSegment.setLong(2,lstseqnbr.longValue());

		         int iRemoveGpaCriteria= executeUpdate(_pstmtSegment);
		         log.debug(" iRemoveGpaCriteria"+iRemoveGpaCriteria);

		      }
		      catch (SQLException sqlex)
		      {
		          log.debug("GpaDAX------deleteGpaStandard()----- DAX---SQL");
		          log.exception(sqlex.getMessage());

		          throw new EElixirException("jan816");
		      }
		      catch (EElixirException eex)
		      {
		          log.debug("GpaDAX------deleteGpaStandard()----- DAX--- EE");
		          log.exception(eex.getMessage());
		          throw new EElixirException("jan816");
		      }
		      finally
		      {
		          try
		          {
		              if (_pstmtSegment != null)
		              {
		             	 _pstmtSegment.close();
		              }
		          }
		          catch (SQLException sqlex)
		          {
		              log.exception(sqlex.getMessage());
		              throw new EElixirException(sqlex, "jan816");
		          }
		      }

	   }

	   public Long createCriteriaGpa(GpaCriteriaResult a_oGpaCriteriaResult,GpaCriteriaMasterResult a_oGpaCriteriaMasterResult)throws EElixirException
	   {
		   log.debug("U ARE IN INSERT MODEEEEEEEEEEE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		   PreparedStatement pstmtCreateGpaCriteria = null;
		      Long lstseqnbr;

		     try
		     {
			   String strInsertSegmentMstQuery = getSQLString("Insert",CHMConstants.GPA_CRITERIA_INSERT);
			   log.debug("strInsertSegmentMstQuery"+strInsertSegmentMstQuery);
			   pstmtCreateGpaCriteria = getPreparedStatement(strInsertSegmentMstQuery);
			   lstseqnbr = getCriteriaNextSeqNo();
			   log.debug("Criteria Sequence Number"+lstseqnbr);

		       int iPos = 0;
		      log.debug("start inserting");
		      pstmtCreateGpaCriteria.setLong(++iPos, a_oGpaCriteriaMasterResult.getSeqNumb().longValue());
		       log.debug("a_oGpaStandardResult.getSeqNbr().longValue()"+a_oGpaCriteriaMasterResult.getSeqNumb().longValue());
		       pstmtCreateGpaCriteria.setLong(++iPos,lstseqnbr.longValue());
		       log.debug("lstseqnbr.longValue()"+lstseqnbr.longValue());
		       pstmtCreateGpaCriteria.setString(++iPos,
		    		   a_oGpaCriteriaResult.getPoints());
		       log.debug("  a_oGpaCriteriaResult.getPoints()"+  a_oGpaCriteriaResult.getPoints());
		       pstmtCreateGpaCriteria.setString(++iPos,
		    		   a_oGpaCriteriaResult.getFomPercent());
		       log.debug(" a_oGpaCriteriaResult.getFomPercent()"+ a_oGpaCriteriaResult.getFomPercent());
		       pstmtCreateGpaCriteria.setString(++iPos,
		    		   a_oGpaCriteriaResult.getToPercent());
		       log.debug("a_oGpaCriteriaResult.getToPercent()"+a_oGpaCriteriaResult.getToPercent());
		       pstmtCreateGpaCriteria.setString(++iPos, a_oGpaCriteriaResult.getUserId());
		       log.debug("a_oGpaCriteriaResult.getUserId()"+a_oGpaCriteriaResult.getUserId());


		       executeUpdate(pstmtCreateGpaCriteria);
		       log.debug("lstseqnbr1111111111111111"+lstseqnbr);
		       return lstseqnbr;
		     }
		      catch (SQLException sqlex)
		      {
		       sqlex.printStackTrace();
		       log.fatal(sqlex.getMessage());
		       throw new EElixirException(sqlex, "jan817");
		      }
		      catch (EElixirException eex)
		     {
		       eex.printStackTrace();
		       log.fatal(eex.getMessage());
		       throw new EElixirException(eex, "jan817");
		     }
		     finally
		     {
		        try
		        {
		           if (pstmtCreateGpaCriteria != null)
		           {
		        	   pstmtCreateGpaCriteria.close();
		           }
		        }
		         catch (SQLException sqlex)
		         {
		           sqlex.printStackTrace();
		           log.fatal(sqlex.getMessage());
		           throw new EElixirException(sqlex, "jan817");
		        }
		     }

	   }

	   public void updateGpaCriteria(GpaCriteriaResult a_oGpaCriteriaResult,GpaCriteriaMasterResult a_oGpaCriteriaMasterResult )throws EElixirException
	   {
		   PreparedStatement pstmtUpdateGpaCriteria = null;
            log.debug("updateeeeeeeeeeeeeeeeee mode********************************");
	        try
	        {
	            String strUpdateQuery = getSQLString("Update",
	                    CHMConstants.GPA_CRITERIA_UPDATE);
	            pstmtUpdateGpaCriteria = getPreparedStatement(strUpdateQuery);
	            log.debug("-query is ->"+strUpdateQuery);
	            String strFromPercent = a_oGpaCriteriaResult.getFomPercent();
	            String strPoints  = a_oGpaCriteriaResult.getPoints();
	            String strToPercent  = a_oGpaCriteriaResult.getToPercent();
	            String strUpdatedBy= a_oGpaCriteriaResult.getUserId();
	            Long lgpaseqnbr = a_oGpaCriteriaMasterResult.getSeqNumb();
	            Long lstseqnbr = a_oGpaCriteriaResult.getCriteriaSeqNbr();
	            log.debug("a_oGpaCriteriaResult.getCriteriaSeqNbr()-> " +lstseqnbr);


	            pstmtUpdateGpaCriteria.setString(1, strPoints);
	            pstmtUpdateGpaCriteria.setString(2, strFromPercent);
	            pstmtUpdateGpaCriteria.setString(3, strToPercent);
	            pstmtUpdateGpaCriteria.setString(4, strUpdatedBy);
	            pstmtUpdateGpaCriteria.setLong(5, lgpaseqnbr.longValue());
	            pstmtUpdateGpaCriteria.setLong(6, lstseqnbr.longValue());
	            int iUpdate = executeUpdate(pstmtUpdateGpaCriteria);
	            log.debug("No of rows updated in UpdateGpacriteria() is "+iUpdate);

	        }
	        catch (SQLException sqlex)
	        {
	            log.exception(sqlex.getMessage());

	            throw new EElixirException(sqlex, "jan818");
	        }
	        catch (EElixirException eex)
	        {
	            log.exception(eex.getMessage());
	            throw new EElixirException(eex, "jan818");
	        }
	        finally
	        {
	            try
	            {
	                if (pstmtUpdateGpaCriteria != null)
	                {
	                	pstmtUpdateGpaCriteria.close();
	                }
	            }
	            catch (SQLException sqlex)
	            {
	                log.exception(sqlex.getMessage());
	                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
	            }
	        }

	   }



	   public void copyDesignationGpa(String a_strDesignation,String a_strInputDesg,String a_strUserId) throws EElixirException
	   {
         log.debug("u are in dax");
		   CallableStatement cs = null;
			try {
				String procString = getSQLString("Select",CHMConstants.GPA_DESIGNATION_COPY );
		  			log.debug("in callProcedures");
		  			log.debug("got proc string as " + procString);
					if (cs == null) {
						cs = getCallableStatement("call " + procString + " ");
					}

			cs.setString(1,a_strDesignation);
			cs.setString(2, a_strInputDesg);
            cs.setString(3, a_strUserId);
            cs.registerOutParameter(4, Types.INTEGER);
			cs.registerOutParameter(5, Types.VARCHAR);
			cs.registerOutParameter(6, Types.INTEGER);
			cs.registerOutParameter(7, Types.VARCHAR);
			log.debug("GPADAX--PROCEDURE");
			cs.execute();
			int errorCode = cs.getInt(6);
			log.debug("Error Code for the process " + errorCode);
			String strErrorString = cs.getString(7);
			log.debug("Error String for the process " + strErrorString);
			if (errorCode != 0) {
				log.debug("Could not Execute the GPA Procedure");
				throw new EElixirException("P8172",strErrorString,false);

			}

			log.exit("GPADAX","copyDesignationGpa","Exit");
			}catch(SQLException sqlex)
			{
			  log.exception(sqlex.getMessage());
			  throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
			}
			catch(EElixirException eex)
			{
				log.debug("in copyDesignationGpa exception");
			   log.exception(eex.getMessage());
			    throw eex;
			}
			finally
			{
			   try
			   {
				  if(cs!= null)
					 cs.close();
			   }
			   catch(SQLException sqlex)
			   {
				  log.exception(sqlex.getMessage());
				  throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
			   }
			}
	   }
	   }


