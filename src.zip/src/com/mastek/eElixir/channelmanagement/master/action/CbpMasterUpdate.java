/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME					: CbpMasterUpdate
 *  AUTHOR					: Santosh Pandya	
 *  VERSION					: 1.0
 *  CREATION DATE		    : May 15, 2008
 *  COMPANY				    : Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *Santosh_CBPMaster Starts   
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult;
import com.mastek.eElixir.channelmanagement.master.util.CbpResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

public class CbpMasterUpdate extends Action {

	/**
	 * Constructer
	 */

	public CbpMasterUpdate() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :
	 *            ResultObject object.
	 * @roseuid 3B94961803CB
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		CHMSL remoteCHMSL = null;
		try {

			setCbpMaster(request);
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			remoteCHMSL.updateCbpMaster(_oCbpMasterList);			
			_oCbpMasterList = remoteCHMSL.searchCbpMaster(request
					.getParameter("strChannelType"));

			setResult(_oCbpMasterList);
		} catch (FinderException fex) {
			request.setAttribute("ResultObject", _oCbpMasterList);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oCbpMasterList);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oCbpMasterList);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log
					.debug("In CbpUpdate eelixir exception before setting result"
							+ eLex);
			if (eLex.getCustomErrorCode().equalsIgnoreCase("P1100")) {
				try {
					_oCbpMasterList = remoteCHMSL
							.searchChannelSegments(request
									.getParameter("cChannelType"));
					setResult(_oCbpMasterList);
				} catch (RemoteException rex) {
					request.setAttribute("ResultObject", _oCbpMasterList);
					throw new EElixirException(rex, "P1006");
				} catch (FinderException cex) {
					request.setAttribute("ResultObject", _oCbpMasterList);
					throw new EElixirException(cex, "P1007");
				}
			}
			request.setAttribute("ResultObject", _oCbpMasterList);
			throw eLex;
		}

	}

	private void setCbpMaster(HttpServletRequest a_oRequest) {	
		
		String strChannelType = a_oRequest.getParameter("strChannelType");		
		String strAgencyCode[] = a_oRequest.getParameterValues("strAgencyCode");
		
		//String strAgencyName[] = a_oRequest.getParameterValues("strAgencyName");
		String strCbpBasis[] = a_oRequest.getParameterValues("strCbpBasis");
		String strCbpMul[] = a_oRequest.getParameterValues("strCbpMul");
		String[] dtEffFrom = a_oRequest.getParameterValues("dtEffFrom");
		String[] dtEffTo = a_oRequest.getParameterValues("dtEffTo");
		String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
		String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");
		String SeqNumb[] = a_oRequest.getParameterValues("SeqNumb");
		/* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation START */
		String[] strIncExc = a_oRequest.getParameterValues("nIncExclValue");
		/* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation END */
		
		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String) session.getAttribute("username");
		/* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation START */
		int len = SeqNumb.length;
		String[] strWtDef =  a_oRequest.getParameterValues("nInactiveValue");
		log.debug("setCbpMaster : " + strWtDef + strWtDef.length);
		/* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation END */
		
		if (statusFlag != null) {
			for (int i = 0; i < statusFlag.length; i++) {
				if (!(statusFlag[i].equals(DataConstants.CLEAR_MODE))) {

					_oCbpResult = new CbpResult();

					_oCbpResult.setChannelType(strChannelType);		
					
					StringTokenizer tempAgencyCode = new StringTokenizer(strAgencyCode[i],"-");
					String strAgCd =  null;					
					if(tempAgencyCode.countTokens() > 1){
						strAgCd =(String)tempAgencyCode.nextElement();									
					}else{
						strAgCd = strAgencyCode[i];
					}					
					_oCbpResult.setAgencyCode(strAgCd);
					_oCbpResult.setAgencyName(null);
					_oCbpResult.setCbBasis(strCbpBasis[i]);
					_oCbpResult.setCbpMul(new Double(strCbpMul[i]));
					_oCbpResult.setDtEffFrom(DateUtil.retGCDate(dtEffFrom[i]));
					_oCbpResult.setDtEffTo(DateUtil.retGCDate(dtEffTo[i]));
					_oCbpResult.setStatusFlag(statusFlag[i]);


					if (SeqNumb[i] != null && !SeqNumb[i].trim().equals("")) {
						_oCbpResult.setCbpSeqNbr(new Long(SeqNumb[i]));

					} else {
						_oCbpResult.setCbpSeqNbr(null);
					}
					
					if (dtUpdated[i] != null && !dtUpdated[i].trim().equals("")) {
						_oCbpResult.setTsDtUpdated(Timestamp
								.valueOf(dtUpdated[i]));
					}
					_oCbpResult.setUserId(_strUserId);					
					
					/* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation START */
					if("1".equals(strWtDef[i]))
					{
						log.debug("Inside if");
						_oCbpResult.set_nIsWeightageDefined(new Short("1"));
					}
					else
					{
						log.debug("Inside else");
						
						/* code changed by vishalS dt. 15/11/11 start */
						
						_oCbpResult.set_nIsWeightageDefined(new Short("2"));
						
						/* code changed by vishalS dt. 15/11/11 end */
					
					}
					
					if(strIncExc[i] != null && !strIncExc[i].trim().equals(""))
					{
						_oCbpResult.setIncExclValue(new Short(strIncExc[i]));
					}
					else
					{
						_oCbpResult.setIncExclValue(new Short("0"));
					}
					
					log.debug("WT Def :"+ _oCbpResult.get_nIsWeightageDefined());
					log.debug("strWtDef[i] : "+ strWtDef[i]);
					/* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation END */
					_oCbpMasterList.add(_oCbpResult);

				}
			}
		}
		
	}

	// class level variable declarations.
	CbpResult _oCbpResult = null;

	ArrayList _oCbpMasterList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
