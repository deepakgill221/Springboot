/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : NewDesignationQuestionMapListSearch.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_desigquest_map.doc
*  CREATION DATE                  : 17/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2003.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;


public class DesignationQuestionMapListSearch extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * @Constructor
     */
    public DesignationQuestionMapListSearch()
    {
    }

    /**
     * This method makes a remote call to the Session bean which in turn makes a local
     * call to all other bean and get the Persistency ArrayList Object
     * @param: request - Request object.
     * @throws EElixirException
     */
    public void process(HttpServletRequest request) throws EElixirException
    {
        ArrayList alresultobjectlist = null;
        ArrayList alPTFResult = new ArrayList();
        request.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);

        try
        {
            SearchData oSearchData = new SearchData();
            CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
            String cChannelType = request.getParameter("cChannelType");
            String strDesgnCd = request.getParameter("strDesgnCd");
            if ((cChannelType != null) && !cChannelType.trim().equals(""))
            {
                oSearchData.setTask1(cChannelType);
            }
            if ((strDesgnCd != null) && !strDesgnCd.trim().equals(""))
            {
                oSearchData.setTask2(strDesgnCd);
            }
            alresultobjectlist = remoteCHMSL.searchDesignationQuestionMap(oSearchData);
            setResult(alresultobjectlist);
            request.setAttribute("questionlist", alPTFResult);
            request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
        }

        catch (FinderException rex)
        {
			_oLogger.fatal(getClass().getName(), "Process", rex.getMessage());        	
            request.setAttribute("ResultObject", alresultobjectlist);
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
			_oLogger.fatal(getClass().getName(), "Process", cex.getMessage());        	
            request.setAttribute("ResultObject", alresultobjectlist);
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
			_oLogger.fatal(getClass().getName(), "Process", rex.getMessage());        	
            request.setAttribute("ResultObject", alresultobjectlist);
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException cex)
        {
			_oLogger.fatal(getClass().getName(), "Process", cex.getMessage());        	
            request.setAttribute("ResultObject", alresultobjectlist);
            throw cex;
        }
    }
}
