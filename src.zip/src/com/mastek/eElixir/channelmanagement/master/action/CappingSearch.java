/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : CappingSearch.java
*  AUTHOR           : Manisha Rajbanshi
*  VERSION          : 1.0
*  CREATION DATE    : Sep 20, 2011
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_BONUS_DETAILS
*
*
*  MODIFICATION HISTORY:-
*
* 1.12.2011 Ankita Singh     Changes for Capping Setup Seva Issue# 142160
**********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.CappingResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.BonusResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class CappingSearch extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor for BonusProductSearch 
     */
    public CappingSearch()
    {
    }

    /**
     * The Process Method is used to retrieve single record
     * @param a_oRequest HttpServletRequest
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
    	ArrayList arrCappingResult = null;
        Long lCapHdrSeqNbr = null;
        /*Added by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: START */
        ArrayList arrChannelProdSeg = null;
        /*Added by Ankita Singh on 1.12.2011 for Capping Seva Issue#142160: END */

        try
        {
        	 _oLogger.debug("CappingSearch--Start");
        	HttpSession session = a_oRequest.getSession();
            a_oRequest.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);

            CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
            //lCapHdrSeqNbr = new Long(a_oRequest.getParameter("lCapHdrSeqNbr"));

            //Firing the Search Method On Remote Interface
            _oLogger.debug("CappingSearch--Start before");
            arrCappingResult = oRemoteCHMSL.searchCapping();
            _oLogger.debug("CappingSearch--result accessed");
            
                        
            /*Added by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: START */
            _oLogger.debug("CappingSearch--Start before ChannelProdSeg Call");
            arrChannelProdSeg = oRemoteCHMSL.searchChannelProdSeg();
            _oLogger.debug("CappingSearch--Start after ChannelProdSeg Call");
            String strAllChannels = (String)arrChannelProdSeg.get(0);
            String strProdSegCount = (String)arrChannelProdSeg.get(1);
            _oLogger.debug("CappingSearch--After setting channel and prodseg");
            /*Added by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: END */
            _oLogger.debug("CappingSearch--All Channels "+ strAllChannels);
            _oLogger.debug("CappingSearch--strProdSegCount "+ strProdSegCount);
            
            /*String delimiter = "[,]";
            String[] arrlStr = strAllChannels.split(delimiter);*/
            
            /*ArrayList arrlChannels = new ArrayList(); 
            for(int i =0;i<arrlStr.length;i++)
            {
            	String chn="";
            	chn = arrlStr[i];
            	arrlChannels.add(chn);
            }*/
            
            session.setAttribute("AllChannels",strAllChannels);
            session.setAttribute("StrProdSegCount",strProdSegCount);
            //Setting the Result Object
            _oLogger.debug("CappingSearch--After setting attribute");
            /*Moved by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: START */
            CappingResult oCapRes = (CappingResult)arrCappingResult.get(0);
            /*Moved by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: END */
            _oLogger.debug("CappingSearch--After getting Capping result");
            setResult(arrCappingResult);
            _oLogger.debug("CappingSearch--result is set");
            //a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
            
            
        }
        catch (RemoteException rex)
        {
			_oLogger.fatal(getClass().getName(),"process","RemoteException "+rex.getMessage());
           // a_oRequest.setAttribute("ResultObject", oCappingResult);
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
			_oLogger.fatal(getClass().getName(),"process","CreateException "+cex.getMessage());
           // a_oRequest.setAttribute("ResultObject", oCappingResult);
            throw new EElixirException(cex, "P1007");
        }
        catch (EElixirException eex)
        {
			_oLogger.fatal(getClass().getName(),"process","EElixirException "+eex.getMessage());
            //a_oRequest.setAttribute("ResultObject", oCappingResult);
            throw eex;
        }
        catch (Exception ex)
        {
			_oLogger.fatal(getClass().getName(),"process","Exception "+ex.getMessage());
           // a_oRequest.setAttribute("ResultObject", oCappingResult);
            throw new EElixirException(ex, "P1001");
        }
    }
}
