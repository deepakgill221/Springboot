/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME     : CHANNEL MANAGEMENT
 *  FILENAME        : NewPaymentCycleCreate.java
 *  AUTHOR          : Vikrant Chitre
 *  VERSION         : 1.0
 *  CREATION DATE   : Aug 20, 2003
 *  COMPANY         : Mastek Ltd.
 *  COPYRIGHT       : COPYRIGHT (C) 2003.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION        DATE                  BY                        REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.master.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;

public class NewPaymentCycleCreate extends Action
{

   /**
    * Default Constructor for class
    */
   public NewPaymentCycleCreate()
   {
   }

   /**
   * blank process method to follow the MVC architecture
   * @param : a_oRequest - Request object.
   * @throws EElixirException
   */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
		 a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
   }
}
