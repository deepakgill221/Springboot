/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FinancialYearUpdate.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * FinancialYearUpdate is the Action Class for updating a FinancialYear.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.FinancialYearFetch;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class FinancialYearUpdate extends Action
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the BenefitUpdate class
   */
  public FinancialYearUpdate()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ArrayList arrFinancialYearResult = null;
    FinancialYearFetch oFinancialYearFetch = new FinancialYearFetch();
    CHMSL remoteCHMSL = null;
    try{
      remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      log.debug("FinancialYearUpdate--Before fetching parameters");
      arrFinancialYearResult = oFinancialYearFetch.fetchFinancialYear(a_oRequest);
      log.debug("FinancialYearUpdate--After fetching parameters");

      log.debug("FinancialYearUpdate--before update FinancialYear");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      remoteCHMSL.updateFinancialYear(arrFinancialYearResult);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      log.debug("FinancialYearUpdate--before search FinancialYear");
      arrFinancialYearResult = remoteCHMSL.searchFinancialYear();
      log.debug("FinancialYearUpdate--after search FinancialYear");
      setResult(arrFinancialYearResult);
      log.debug("FinancialYearUpdate--result accessed");

    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", arrFinancialYearResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", arrFinancialYearResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", arrFinancialYearResult);
      throw new EElixirException(fex, "P4305");
    }
    catch(EElixirException eex)
    {
      log.debug("FinancialYearUpdate--Inside catch of EElixir exception in process of FinancialYearUpdate");
      if (eex.getCustomErrorCode().equalsIgnoreCase("P1100"))
          {
            try
            {
              arrFinancialYearResult = remoteCHMSL.searchFinancialYear();
            }
            catch(RemoteException rex)
            {
              a_oRequest.setAttribute("ResultObject", arrFinancialYearResult);
              throw new EElixirException(rex, "P1006");
            }
            catch(FinderException fex)
            {
              a_oRequest.setAttribute("ResultObject", arrFinancialYearResult);
              throw new EElixirException(fex, "P1006");
            }
          }
          a_oRequest.setAttribute("ResultObject", arrFinancialYearResult);
          throw eex;
    }
  }

}