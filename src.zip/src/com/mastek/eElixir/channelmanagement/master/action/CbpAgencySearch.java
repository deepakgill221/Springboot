/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME		: CbpAgencySearch.java
 *  AUTHOR			: Santosh Pandya
 *  VERSION			: 1.0
 *  CREATION DATE	: June 2, 2008
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.master.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentAgencyResult;
import com.mastek.eElixir.channelmanagement.master.util.CbpResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class CbpAgencySearch extends Action {

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	/**
	 * Default Constructor
	 */
	public CbpAgencySearch() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean and populates the DVO
	 * 
	 * @param :
	 *            request - Request object.
	 * @roseuid 3B94961803CB
	 * @throws EElixirException
	 */
	public void process(HttpServletRequest request) throws EElixirException {

		CbpResult oResult = null;
		String strChannelType = null;
		try {

			CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome",
					CHMSLHome.class);

			oResult = remoteCHMSL.searchCbpChannel(request
					.getParameter("strChannelType"));
			oResult.setcurrRow(request.getParameter("currRow"));
			log.debug("CbpAgencySearch--process--Done");
			setResult(oResult);
		} catch (Exception e) {
			e.printStackTrace();
			throw new EElixirException(e.getMessage());
		}

	}

}