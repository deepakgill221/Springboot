/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : NewDesignationQuestionMapListSearch.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_desigquest_map.doc
*  CREATION DATE                  : 17/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2003.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.master.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.EElixirUtils;


 public class NewDesignationQuestionMapListSearch extends Action
 {

   /**
    * @roseuid 3B94961803B7
    */
   public NewDesignationQuestionMapListSearch()
   {

   }

   /**
    * blank process method to follow the MVC architecture, it just makes the xsl file available to the requested jsp at the beginning
    * @param : request - Request object.
    * @roseuid 3B94961803CB
    * @throws EElixirException
    */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
	   
	 EElixirUtils.reloadMaster(DataConstants.QUESTION_TEXT);
      a_oRequest.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
   }
 }