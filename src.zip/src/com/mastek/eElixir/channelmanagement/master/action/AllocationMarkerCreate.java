/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME     : CHANNEL MANAGEMENT
 *  FILENAME        : AllocationMarkerCreate.java
 *  AUTHOR          : Jayasimha Reddy
 *  VERSION         : 1.1
 *  CREATION DATE   : oct 14, 2005
 *  COMPANY         : Mastek Ltd.
 *  COPYRIGHT       : COPYRIGHT (C) 2005.
 * 
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION        DATE                  BY                        REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.GregorianCalendar;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.AllocationMarkerResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;

public class AllocationMarkerCreate extends Action
{
    //class level variable declarations.
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

	/**
	 * Constructor of the Allocation Marker Create class
	 */
    public AllocationMarkerCreate()
    {
		
    }

    /**
    * This method makes a remote call to the Session bean which in turn makes a local
    * call to all other bean .
    * @param  a_oRequest HttpServletRequest
    * @throws EElixirException
    */
    public void process(HttpServletRequest a_oRequest) throws EElixirException
    {
		AllocationMarkerResult oAllocationMarkerResult = null;

		try
		{
			a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
			CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

			oAllocationMarkerResult = getAllocationMarkerResult(a_oRequest);
			Long lAllocMarkerSeqNbr=oRemoteCHMSL.createAllocationMarker(oAllocationMarkerResult);
					            
			
			oAllocationMarkerResult = oRemoteCHMSL.searchAllocationMarker(lAllocMarkerSeqNbr);

			setResult(oAllocationMarkerResult);
			a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		}
		catch (RemoteException rex)
		{
			_oLogger.fatal("AllocationMarkerCreate----RemoteException");
			a_oRequest.setAttribute("ResultObject", oAllocationMarkerResult);
			throw new EElixirException(rex, "P1006");
		}
		catch (CreateException cex)
		{
			_oLogger.fatal("AllocationMarkerCreate----CreateException");
			a_oRequest.setAttribute("ResultObject", oAllocationMarkerResult);
			throw new EElixirException(cex, "P1006");
		}
		catch (FinderException cex)
		{
			_oLogger.fatal("AllocationMarkerCreate--inside finder exception");
			throw new EElixirException(cex, "P1006");
		}

		catch (EElixirException eex)
		{
			_oLogger.fatal("AllocationMarkerCreate--Inside catch of EElixir exception ");
			a_oRequest.setAttribute("ResultObject", oAllocationMarkerResult);
			throw eex;
		}

    }
    
	/**
		* Populates AllocationMarkerResult  Object from Request Object
		* @param a_oRequest HttpServletRequest
		* @return AllocationMarkerResult
		* @throws EElixirException
		*/
		private AllocationMarkerResult getAllocationMarkerResult(HttpServletRequest a_oRequest)
			throws EElixirException
		{
			AllocationMarkerResult oAllocationMarkerResult = new AllocationMarkerResult();
			
			
			String strPmtMode = a_oRequest.getParameter("nPmtMode");
			String strnIsDetorSumm = a_oRequest.getParameter("nIsDetorSumm");
			String strPmtBankcd = a_oRequest.getParameter("BankCode");
			String strAllocMarker = a_oRequest.getParameter("strAllocMarker");
				
			Integer nPmtMode = null;
			Integer nIsDetorSumm = null;
				
				
				
			if ((strPmtMode != null) && !strPmtMode.equals(""))
			{
				nPmtMode  = new Integer(strPmtMode );
			}
			
			if ((strnIsDetorSumm != null) && !strnIsDetorSumm.equals(""))
			{
				nIsDetorSumm   = new Integer(strnIsDetorSumm);
			}

			oAllocationMarkerResult.setPmtMode(nPmtMode);

			oAllocationMarkerResult.setIsDetorSumm(nIsDetorSumm);

			oAllocationMarkerResult.setPaymentBankCode(strPmtBankcd);

			oAllocationMarkerResult.setAllocationMarker(strAllocMarker);
			
			HttpSession session = a_oRequest.getSession();
			String strUserId = (String) session.getAttribute("username");
			oAllocationMarkerResult.setUserId(strUserId);
			
			return oAllocationMarkerResult;
		}
}