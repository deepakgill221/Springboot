/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BounceSearch.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1           4/1/2003          Jimmy Shah            Changes for the Audit of Menu Clicks
*
*
*--------------------------------------------------------------------------------
* FSD_FIN_68_Debiting_Bounce_charges_APRIL_REL_ANUP_19Feb2009 starts
*********************************************************************/

/**
 * ChannelSearch is the Action Class for Getting a Channel Detail,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       25/09/2002
 * @author    Anup Kumar
 * @version   1.0
 */

package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
public class BounceChargesSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor of the BenefitSearch class
   */
  public BounceChargesSearch()
  {

  }


  /**
   * Gets the detail for that Channel
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ArrayList arrBounceChargesResult = null;
    try{

      MenuAccessLog.createMenuAccessLog(a_oRequest);
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      arrBounceChargesResult = remoteCHMSL.searchBounce();
      log.debug("BounceChargesSearch--result accessed");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      setResult(arrBounceChargesResult);
      log.debug("BounceChargesSearch--result is set");
    }
    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "P4105");
    }
  }
}