/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : AllocationMarkerListSearch.java
*  AUTHOR           : Jayasimha Reddy
*  VERSION          : 1.1
*  CREATION DATE    : oct 18, 2005
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_ALLOCATIONMARKER_SEARCH
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
**********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class AllocationMarkerListSearch extends Action
{
	//class level variable declarations.
	private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor of the AllocationMarkerListSearch class
     */
    public AllocationMarkerListSearch()
    {
    }

    /**
     * This method is used to search the Allocation Marker records
     * @param a_oRequest HttpServletRequest object.
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
        try
        {
            a_oRequest.setAttribute("actiontype",
                DataConstants.ACTION_LISTSEARCH);

            String result = null;
            CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

            SearchData _oSearchData = new SearchData();
            _oSearchData.setTask1(a_oRequest.getParameter("nPmtMode"));
            _oSearchData.setTask2(a_oRequest.getParameter("strAllocMarker"));
            _oSearchData.setTask3(a_oRequest.getParameter("BankCode"));


            result = oRemoteCHMSL.searchAllocationMarker(_oSearchData);
            setResult(result);
        }
        catch (RemoteException rex)
        {
            _oLogger.fatal("AllocationMarkerListSearch----RemoteException");
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException rex)
        {
            _oLogger.fatal("AllocationMarkerListSearch----FinderException");
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            _oLogger.fatal("AllocationMarkerListSearch----CreateException");
            throw new EElixirException(cex, "P1006");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal("AllocationMarkerListSearch----EElixirException");
            throw eex;
        }
    }
}
