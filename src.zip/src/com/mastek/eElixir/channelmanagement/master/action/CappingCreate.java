/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : MY Agent
*  FILENAME			: CappingSetupDetails.java
*  AUTHOR			: Manisha Rajbanshi
*  VERSION			: 1.0
*  CREATION DATE	: Sep 20,2011
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------

*********************************************************************/



/**
 * CappingSetupDetails is the action class to select 
 * the DesignationExclusion that are applicable for the OtherBenefit Program
 * Created on Dec 23,2008
 * @author Amid P Sahu
 * Copyright (c) 2008 Mastek Ltd
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;

import com.mastek.eElixir.channelmanagement.master.util.CappingResult;
import com.mastek.eElixir.channelmanagement.master.util.TaxResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;


 public class CappingCreate extends Action
 {
	 private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);
     
     public CappingCreate()
     {
     }

     public void process(HttpServletRequest a_oRequest)  throws EElixirException
     {
         ArrayList arrlCapRes = new ArrayList();
         CappingResult oCapResult = null;
         HttpSession session = a_oRequest.getSession();
		 String strUserId = (String) session.getAttribute("username");

         try
         {
        	 _oLogger.debug("CappingCreate----Start");
        	 
        	 String[] strChannelType = a_oRequest.getParameterValues("cChannelType");
             String[] nAgencyCd = a_oRequest.getParameterValues("nAgencyCd");
    	     String[] strProdSegment = a_oRequest.getParameterValues("nProdSegment");
    	     String[] strFY= a_oRequest.getParameterValues("nFY");
    	     String[] strSingle= a_oRequest.getParameterValues("nSingle");
    	     // Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping START
    	     String[] strRY1= a_oRequest.getParameterValues("nRY1");
    	     String[] strRY2= a_oRequest.getParameterValues("nRY2");
    	     String[] strRYOth= a_oRequest.getParameterValues("nRYOth");
    	     // Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping END
    	     String[] strStatusFlag = a_oRequest.getParameterValues("strStatusFlagA");
    	     String[] lCapSeqNbr = a_oRequest.getParameterValues("nLCAPSEQNBR");
    	     
    	     _oLogger.debug("strChannelType List "+ strChannelType +"lCapSeqNbr List "+lCapSeqNbr);
    	     
    	     if (strChannelType != null)
             {
                 for (int i = 0; i < strChannelType.length; i++)
                 {
                	 _oLogger.debug("strStatusFlag[i] " + strStatusFlag[i]);
                	 if (!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE))
                	 {
                		 oCapResult = new CappingResult();
                		 oCapResult.setcChannelType(strChannelType[i]);
                		 oCapResult.setnAgencyCd(nAgencyCd[i]);
                		 oCapResult.setnProdSegment(new Short(strProdSegment[i]));
                		 oCapResult.setnFY(new Double(strFY[i]));
                		 oCapResult.setnSingle(new Double(strSingle[i]));
                		 // Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping START
                		 oCapResult.setnRY1(new Double(strRY1[i]));
                		 oCapResult.setnRY2(new Double(strRY2[i]));
                		 oCapResult.setnRYOth(new Double(strRYOth[i]));
                		 // Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping END
                		 oCapResult.setUserId(strUserId);
                		 oCapResult.setDtUpdated(DateUtil.retGCDate(DateUtil.getSystemDate()));
                		 oCapResult.setStrStatusFlag(strStatusFlag[i]);
                		 
                		 //if (!strStatusFlag[i].equals(DataConstants.INSERT_MODE) && lCapSeqNbr[i] != null && !lCapSeqNbr[i].trim().equals(""))
                		 if (!strStatusFlag[i].equals(DataConstants.INSERT_MODE))
                         {
                			 _oLogger.debug("lCapSeqNbr[i]" + lCapSeqNbr[i] + "strStatusFlag[i]  " + strStatusFlag[i]);
                			 _oLogger.debug("Mode is not insert " + !lCapSeqNbr[i].trim().equals("") +" "+ (lCapSeqNbr[i] == null));
                			                			 
                			if(!lCapSeqNbr[i].trim().equals(""))
                			 {
                				 _oLogger.debug("Inside If ");
                				 _oLogger.debug("Inside If YY"+ lCapSeqNbr[i]+"YY");
                				 oCapResult.setlCappingSeqNbr(new Long(lCapSeqNbr[i]));
                			 }
                			 else
                    		 {
                    			 _oLogger.debug("Inside Else");
                    			 oCapResult.setlCappingSeqNbr(null);
                    		 }
                         }
                		 
                		 arrlCapRes.add(oCapResult);
                	 }
                 }
                 CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
                
                 _oLogger.debug("CappingCreate----after getCapResult");
                 _oLogger.debug("Status Flag" + a_oRequest.getParameter("strStatusFlagA"));
                 oRemoteCHMSL.createCapping(arrlCapRes);
                 _oLogger.fatal("CappingCreate----after createCapping");
     			 arrlCapRes = oRemoteCHMSL.searchCapping();
     			 setResult(arrlCapRes);
     			
             }
 			 
         }
         catch (RemoteException rex)
         {
             _oLogger.fatal("CappingCreate----RemoteException");
             a_oRequest.setAttribute("ResultObject", arrlCapRes);
             throw new EElixirException(rex, "P1006");
         }
         catch (CreateException cex)
         {
             _oLogger.fatal("CappingCreate----CreateException");
             a_oRequest.setAttribute("ResultObject", arrlCapRes);
             throw new EElixirException(cex, "P1006");
         }
         catch (FinderException cex)
         {
             _oLogger.fatal("CappingCreate--inside finder exception");
             throw new EElixirException(cex, "P1006");
         }

         catch (EElixirException eex)
         {
             _oLogger.fatal("CappingCreate--Inside catch of EElixir exception ");
             a_oRequest.setAttribute("ResultObject", arrlCapRes);
             throw eex;
         }
     }
    
 }
