/********************************************************************
*
*  PROJECT          : MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : ProductCreate.java
*  AUTHOR           : Vikrant Chitre
*  VERSION          : 1.0
*  CREATION DATE    : Aug 09, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_PRODUCT_DETAILS
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
*  2.1            06/09/2003          Dipti F                   UT Rework
* 2.2		 10/12/2009	       Anup Kr.	     JAN_REL_FSD_Comm_Accounting_Change_Unit_Linked
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.dvo.ProductDetails;
import com.mastek.eElixir.channelmanagement.master.util.ProductResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;

public class ProductCreate extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor of the ProductCreate class
     */
    public ProductCreate()
    {
    }

    /**
     * This method makes a remote call to the CHM Session bean which in turn makes a local
     * call to all other bean and updates the Application
     * @param: a_oRequest - HttpServletRequest object.
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
        ProductResult oProductResult = null;
		CHMSL oRemoteCHMSL = null;
		boolean isUniqueProductCode = false;
        try
        {
			 _oLogger.fatal("IN ProductCreate ------ 1");
            oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
            a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
            //Populating ProductResult object from Request Object
            oProductResult = getProductResult(a_oRequest);
			 _oLogger.fatal("IN ProductCreate ------ 2");
            isUniqueProductCode = oRemoteCHMSL.isUniqueProductCode(oProductResult);
            if (!isUniqueProductCode)
            {
                _oLogger.fatal(" ProductCreate ------ Record already present in the system");
                throw new EElixirException("p4531");
            }

            //Firing Create Product Method
            oRemoteCHMSL.createProduct(oProductResult);
            //Retrieving Newly Created Record from Database
            String strProdCd = oProductResult.getProdCd();
            oProductResult =oRemoteCHMSL.searchProduct(strProdCd);

            //Setting the Result Object
            setResult(oProductResult);
			EElixirUtils.reloadMaster(DataConstants.PRODUCT_CODE_PLANTYPE_VERSION);
			EElixirUtils.reloadMaster(DataConstants.PRODUCT_CODE_VERSION);
			EElixirUtils.reloadMaster(DataConstants.PRODUCT_PLAN);
			EElixirUtils.reloadMaster(DataConstants.PRODUCT_CODE_MODE_TERM);
			EElixirUtils.reloadMaster(DataConstants.PRODUCT_CODE);
			/* code fix done by Anantha sevaTicket:121929 May-2010 REL
			 * Segmentation screen drop downs (Product Code and Rider Code) are not getting populated with new products
			 */
			EElixirUtils.reloadMaster(DataConstants.PRODUCT_CODE_VERSION1);
			EElixirUtils.reloadMaster(DataConstants.RIDER_CODE_VERSION);

            a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
        }
        catch (RemoteException rex)
        {
            _oLogger.fatal("ProductCreate----RemoteException"+rex.getMessage());
            a_oRequest.setAttribute("ResultObject", oProductResult);
			rex.printStackTrace();
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            _oLogger.fatal("ProductCreate----CreateException"+cex.getMessage());
			cex.printStackTrace();
            a_oRequest.setAttribute("ResultObject", oProductResult);
            throw new EElixirException(cex, "P1007");
        }
        catch (FinderException cex)
        {
            _oLogger.fatal("ProductCreate--inside finder exception"+cex.getMessage());
			cex.printStackTrace();
            throw new EElixirException(cex, "P1007");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal("ProductCreate--Inside catch of EElixir exception "+eex.getMessage());
			eex.printStackTrace();
            a_oRequest.setAttribute("ResultObject", oProductResult);
            throw eex;
        }
        catch (Exception eex)
        {
            _oLogger.fatal("ProductCreate--Inside catch of Exception "+eex.getMessage());
			eex.printStackTrace();
            a_oRequest.setAttribute("ResultObject", oProductResult);
            throw new EElixirException(eex, "P1007");
        }

    }

    /**
    * Populates ProductResult  Object from Request Object
    * @param a_oRequest HttpServletRequest
    * @return ProductResult
    * @throws EElixirException
    */
    private ProductResult getProductResult(HttpServletRequest a_oRequest)
        throws EElixirException
    {
        ProductResult oProductResult = new ProductResult();
        String strProdCd = a_oRequest.getParameter("strProdCd");
        String strProdDesc = a_oRequest.getParameter("strProdDesc");
        String strdtEffFrom = a_oRequest.getParameter("dtEffFrom");
        String strdtEffTo = a_oRequest.getParameter("dtEffTo");
        String strPlanType = a_oRequest.getParameter("nPlanType");
        String strTermType = a_oRequest.getParameter("nTermType");
        String strProdType = a_oRequest.getParameter("nProdType");        
        String strProdType_1 = a_oRequest.getParameter("nProdType_1");//Anup_JAN_REL_FSD_India_Mods_v1.0_Req_1
        String strRiderType = a_oRequest.getParameter("nRiderType");//Anup_JAN_REL_FSD_Comm_Accounting_Change_Unit_Linked        
        String strEPCAppl = a_oRequest.getParameter("nEPCAppl");//Anup_No_Commission_on_Employee_Policies_23_Apr_2010 
        String strIndGrpLife = a_oRequest.getParameter("nIndGrpLife");
        String strIsPar = a_oRequest.getParameter("nIsPar");
        String strPayCommonXPrm = a_oRequest.getParameter("nPayCommonXPrm");
        String strProdVer = a_oRequest.getParameter("iProdVer");
        String strCommBase = a_oRequest.getParameter("nCommBase");
        String strBaseUnit = a_oRequest.getParameter("iBaseUnit");
        String strIsEasy = a_oRequest.getParameter("nIsEasy");
		String strPmtMode = a_oRequest.getParameter("nPmtMode");
		String strProdLine = a_oRequest.getParameter("strProdLine");
		String strIndexType = a_oRequest.getParameter("nIndexTypeCd");//Ananth_FSIndexation_REL8.2
		String strCommBandCd=a_oRequest.getParameter("nCommBandCd");//Arun_RatchetedComm_Rel8.3_Phase2
		String strCommAccTyp = a_oRequest.getParameter("nCommAccTyp");//Ananth_FS_PremiumAccounting_HelthyFamily
		//Modified by Amid for FSD_AGN_66_Last five year commission not to be paid to agentv1.3 Start
		String strCommperiod = a_oRequest.getParameter("nCommperiod");
		
		String strMaxVijayPlan=a_oRequest.getParameter("nMaxVijayPlan"); //PrabhatFSD_Max_vijay_v1.2 Max vijay plan and topup limit
		String strTopUpCoverage=a_oRequest.getParameter("nTopUpCoverage"); //CR:FSD - Separate_Topup_Coverage_v1.2 added/modified by Nilkanth on 23-06-2011 
		
				/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping START */
		String strProdSegment=a_oRequest.getParameter("nProdSegment");
		/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping END */
		Short nCommperiod = null;
		//Modified by Amid for FSD_AGN_66_Last five year commission not to be paid to agentv1.3 Start
        GregorianCalendar dtEffFrom = null;
        GregorianCalendar dtEffTo = null;
        Short nPlanType = null;
        Short nTermType = null;
        Short nProdType = null;
        Short nIndGrpLife = null;
        Short nIsPar = null;
        Short nPayCommonXPrm = null;
        Integer iProdVer = null;
        Short nCommBase = null;
        Integer iBaseUnit = null;
        Short nIsEasy = null;
		Short nPmtMode = null;
		Short nIndexTypeCd=null;//Ananth_FSIndexation_REL8.2
		Short nCommBandCd=null;//Arun_RatchetedComm_Rel8.3_Phase2
		Short nCommAccTyp = null;//Ananth_FS_PremiumAccounting_HelthyFamily
		Short nProdType_1 = null;//Anup_JAN_REL_FSD_India_Mods_v1.0_Req_1
		Short nRiderType = null;//Anup_JAN_REL_FSD_Comm_Accounting_Change_Unit_Linked
		Short nEPCAppl = null;//Anup_No_Commission_on_Employee_Policies_23_Apr_2010
		Integer _nMaxVijayPlan=null; // PrabhatFSD_Max_vijay_v1.2 Max vijay plan and topup limit
		/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping START */
		Short nProdSegment = null;
		/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping END */

		// start CR:FSD - Separate_Topup_Coverage_v1.2 added/modified by Nilkanth on 23-06-2011 
		Short nTopUpCoverage = null;
		
		if ((strTopUpCoverage != null) && !strTopUpCoverage.equals(" "))
        {
			nTopUpCoverage = new Short(strTopUpCoverage);
        }
		
		// End CR:FSD - Separate_Topup_Coverage_v1.2 added/modified by Nilkanth on 23-06-2011
		
        if ((strdtEffFrom != null) && !strdtEffFrom.equals(""))
        {
            dtEffFrom = (DateUtil.retGCDate(strdtEffFrom));
        }

        if ((strdtEffTo != null) && !strdtEffTo.equals(""))
        {
            dtEffTo = (DateUtil.retGCDate(strdtEffTo));
        }

        if ((strPlanType != null) && !strPlanType.equals(""))
        {
            nPlanType = new Short(strPlanType);
        }

        if ((strTermType != null) && !strTermType.equals(""))
        {
            nTermType = new Short(strTermType);
        }

        if ((strProdType != null) && !strProdType.equals(""))
        {
            nProdType = new Short(strProdType);
        }
        //Anup_JAN_REL_FSD_India_Mods_v1.0_Req_1_Starts
        if ((strProdType_1 != null) && !strProdType_1.trim().equals(""))
        {
            nProdType_1 = new Short(strProdType_1);
        }
        //Anup_JAN_REL_FSD_India_Mods_v1.0_Req_1_Ends
        //Anup_JAN_REL_FSD_Comm_Accounting_Change_Unit_Linked_Starts       
        if ((strRiderType != null) && !strRiderType.trim().equals(""))
        {        	
        	nRiderType = new Short(strRiderType);
        }
        //Anup_JAN_REL_FSD_Comm_Accounting_Change_Unit_Linked_Ends
        //Anup_No_Commission_on_Employee_Policies_23_Apr_2010_Starts     
        if ((strEPCAppl != null) && !strEPCAppl.trim().equals(""))
        {        	
        	nEPCAppl = new Short(strEPCAppl);
        }
        //Anup_No_Commission_on_Employee_Policies_23_Apr_2010_Ends
        if ((strIndGrpLife != null) && !strIndGrpLife.equals(""))
        {
            nIndGrpLife = new Short(strIndGrpLife);
        }

        if ((strIsPar != null) && !strIsPar.equals(""))
        {
            nIsPar = new Short(strIsPar);
        }

        if ((strPayCommonXPrm != null) && !strPayCommonXPrm.equals(""))
        {
            nPayCommonXPrm = new Short(strPayCommonXPrm);
        }

        if ((strProdVer != null) && !strProdVer.equals(""))
        {
            iProdVer = new Integer(strProdVer);
        }

        if ((strCommBase != null) && !strCommBase.equals(""))
        {
            nCommBase = new Short(strCommBase);
        }

        if ((strBaseUnit != null) && !strBaseUnit.equals(""))
        {
            iBaseUnit = new Integer(strBaseUnit);
        }

        if ((strIsEasy != null) && !strIsEasy.equals(""))
        {
            nIsEasy = new Short(strIsEasy);
        }
		if ((strPmtMode != null) && !strPmtMode.equals(""))
		{
			nPmtMode = new Short(strPmtMode);
		}
		//Ananth_FSIndexation_REL8.2 Starts
		if ((strIndexType != null) && !strIndexType.equals(" "))
        {
			nIndexTypeCd = new Short(strIndexType);
        }
		//Ananth_FSIndexation_REL8.2 Ends      
      //Arun_RatchetedComm_Rel8.3_Phase2 Starts
		if ((strCommBandCd != null) && !strCommBandCd.equals(" "))
        {
			nCommBandCd = new Short(strCommBandCd);
        }
		//Arun_RatchetedComm_Rel8.3_Phase2 Ends  
		
//		Ananth_FS_PremiumAccounting_HelthyFamily starts
		if ((strCommAccTyp != null) && !strCommAccTyp.equals(" "))
        {
			nCommAccTyp = new Short(strCommAccTyp);
        }
//		Ananth_FS_PremiumAccounting_HelthyFamily ends 
		
		//Modified by Amid for FSD_AGN_66_Last five year commission not to be paid to agentv1.3 Start
		if ((strCommperiod != null) && !strCommperiod.equals("")&& !strCommperiod.equals("0"))
        {
            nCommperiod = new Short(strCommperiod);
        }
		oProductResult.setCommperiod(nCommperiod);
		
		//Modified by Amid for FSD_AGN_66_Last five year commission not to be paid to agentv1.3 End
		
		
		//PrabhatFSD_Max_vijay_v1.2 Max vijay plan  Start
		
		if(strMaxVijayPlan!=null && !strMaxVijayPlan.equals(""))
		{
			_nMaxVijayPlan=new Integer(strMaxVijayPlan);
		}
		
		oProductResult.setMaxVijayPlan(_nMaxVijayPlan);
		
		//PrabhatFSD_Max_vijay_v1.2 Max vijay plan  End
		
		/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping START */
		if(strProdSegment!=null && !strProdSegment.equals(""))
		{
			nProdSegment=new Short(strProdSegment);
		}
		/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping END */
		
        oProductResult.setProdCd(strProdCd);
        oProductResult.setProdDesc(strProdDesc);
        oProductResult.setDateEffFrom(dtEffFrom);
        oProductResult.setDateEffTo(dtEffTo);
        oProductResult.setPlanType(nPlanType);
        oProductResult.setTermType(nTermType);
        oProductResult.setProdType(nProdType);
        oProductResult.setIndGrpLife(nIndGrpLife);
        oProductResult.setIsPar(nIsPar);
        oProductResult.setPayCommonXPrm(nPayCommonXPrm);
        oProductResult.setProdVer(iProdVer);
        oProductResult.setCommBase(nCommBase);
        oProductResult.setBaseUnit(iBaseUnit);
        oProductResult.setIsEasy(nIsEasy);
		oProductResult.setPmtMode(nPmtMode);
		if(strProdLine != null && !(strProdLine.trim().equals("")))
		{
			oProductResult.setProdLine(strProdLine.trim());			
		}
		oProductResult.setIndexTypeCd(nIndexTypeCd);//Ananth_FSIndexation_REL8.2
		
		oProductResult.setCommBandCd(nCommBandCd);//Arun_RatchetedComm_Rel8.3_Phase2
		oProductResult.setCommAccTyp(nCommAccTyp); //Ananth_FS_PremiumAccounting_HelthyFamily
		oProductResult.setProdType_1(nProdType_1);//Anup_JAN_REL_FSD_India_Mods_v1.0_Req_1
		oProductResult.setRiderType(nRiderType);//Anup_JAN_REL_FSD_Comm_Accounting_Change_Unit_Linked
		oProductResult.setEPCAppl(nEPCAppl);//Anup_No_Commission_on_Employee_Policies_23_Apr_2010
		oProductResult.setTopUpCoverage(nTopUpCoverage);// CR:FSD - Separate_Topup_Coverage_v1.2 added/modified by Nilkanth on 23-06-2011
       /* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping START */
		oProductResult.setProdSegment(nProdSegment);
		/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping END */
        HttpSession session = a_oRequest.getSession();
        String strUserId = (String) session.getAttribute("username");
        oProductResult.setUserId(strUserId);
					 _oLogger.fatal("IN ProductCreate ------ 3");
        oProductResult.setDtUpdated(DateUtil.retGCDate(DateUtil.getSystemDate()));
		oProductResult.setProductDetails(getProductDetails(a_oRequest));
					 _oLogger.fatal("IN ProductCreate ------ 4");
        return oProductResult;
    }
		/**
		 * This method populates Product Details DVO array
		 * @param a_oRequest HttpServletRequest
		 * @return ProductDetails[]
		 * @throws EElixirException
		 */
		private ProductDetails[] getProductDetails(
			HttpServletRequest a_oRequest) throws EElixirException
		{
			ProductDetails[] oProductDetails = null;

			String dtUpdated1 = null;
			String strPolYearFrom1 = null;
			String strPolYearTo1 = null;
			String strChannelType1 = null;
			String strAcctCd1 = null;
			String strOSAcctCd1 = null;
			String strProvAcctCd1 = null;
			String strCommType1 = null;//Anup_MAY_REL_10_CR-Commission_accounting_for_Topup
			String stAgentStatusFlag1 = null;

			String[] strPolYearFrom = a_oRequest.getParameterValues(
					"nPolYearFrom");
			String[] strPolYearTo = a_oRequest.getParameterValues("nPolYearTo");
			String[] strChannelType = a_oRequest.getParameterValues(
					"cChannelType");
			String[] strAcctCd = a_oRequest.getParameterValues("strAcctCd");
			String[] strOSAcctCd = a_oRequest.getParameterValues("strOSAcctCd");
			String[] strProvAcctCd = a_oRequest.getParameterValues("strProvAcctCd");
			String[] strCommType = a_oRequest.getParameterValues("strCommType");//Anup_MAY_REL_10_CR-Commission_accounting_for_Topup			
			String[] strStatusFlag = a_oRequest.getParameterValues(
					"statusFlag");
			String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");

            _oLogger.debug("ProductCreate----In detail Seection 1");
			if ((strPolYearFrom != null) && (strPolYearFrom.length > 0))
			{
				oProductDetails = new ProductDetails[strPolYearFrom.length];
	            _oLogger.debug("ProductCreate----In detail Seection 2");
				for (int i = 0; i < strPolYearFrom.length; i++)
				{
					oProductDetails[i] = new ProductDetails();

					strPolYearFrom1 = strPolYearFrom[i];
					strPolYearTo1 = strPolYearTo[i];
					strChannelType1 = strChannelType[i].trim();
					strAcctCd1 = strAcctCd[i].trim();
					strOSAcctCd1 = strOSAcctCd[i].trim();
					strProvAcctCd1 = strProvAcctCd[i].trim();
					strCommType1 = strCommType[i].trim();//Anup_MAY_REL_10_CR-Commission_accounting_for_Topup

					if ((dtUpdated != null) && dtUpdated.length-1 >=i && (dtUpdated[i] != null) &&
							!dtUpdated[i].equals(""))
					{
						dtUpdated1 = dtUpdated[i];
					}
		            _oLogger.debug("ProductCreate----In detail Seection 3");
					stAgentStatusFlag1 = strStatusFlag[i];
					oProductDetails[i] = new ProductDetails();
					if (strPolYearFrom1!=null && !strPolYearFrom1.trim().equals(""))
					{
						oProductDetails[i].setPolYearFrom(new Short(strPolYearFrom1));
					}
					if (strPolYearTo1!=null && !strPolYearTo1.trim().equals(""))
					{
					oProductDetails[i].setPolYearTo(new Short(strPolYearTo1));
					}

					oProductDetails[i].setChannelType(strChannelType1);
					oProductDetails[i].setAcctCd(strAcctCd1);
					oProductDetails[i].setOSAcctCd(strOSAcctCd1);
					oProductDetails[i].setProvAcctCd(strProvAcctCd1);
					oProductDetails[i].setCommType(new Short(strCommType1));//Anup_MAY_REL_10_CR-Commission_accounting_for_Topup

		            _oLogger.debug("ProductCreate----In detail Seection Value of Operation ="+stAgentStatusFlag1.charAt(0) );

					oProductDetails[i].setStatusFlag(new Character(
							stAgentStatusFlag1.charAt(0)));
					if ((dtUpdated1 != null) && !dtUpdated1.trim().equals(""))
					{
						oProductDetails[i].setTsDtUpdated(Timestamp.valueOf(
								dtUpdated1));
					}
				}
			}
			return oProductDetails;
		}
}
