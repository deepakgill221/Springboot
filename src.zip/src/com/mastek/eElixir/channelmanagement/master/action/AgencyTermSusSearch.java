/********************************************************************
*
*  PROJECT			: MMMA
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: AgencyTermSusSearch.java
*  AUTHOR			: Jayasimha Reddy
*  VERSION			: 1.0
*  CREATION DATE	: Dec 07, 2009
*  COMPANY			: Cognizant Solutions Ltd
*  COPYRIGHT		: 

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * AgencyTermSusSearch is the Action Class for Getting a Agency Termination and Suspension Details,depending upon the
 * search data.
 * Date       07/12/2009
 * @author    Jayasimha Reddy
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
public class AgencyTermSusSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor of the AgencyTermSusSearch class
   */
  public AgencyTermSusSearch()
  {

  }


  /**
   * Gets the detail for that Channel
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ArrayList arrAgencyTermSusResult = null;
    try{

      MenuAccessLog.createMenuAccessLog(a_oRequest);
      
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      
      arrAgencyTermSusResult = remoteCHMSL.searchAgencyTermSusDtls();
      
      // arrAgencyTermSusResult = new ArrayList();
      
      log.debug("AgencyTermSusSearch--result accessed");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      setResult(arrAgencyTermSusResult);
      log.debug("AgencyTermSusSearch--result is set");
    }
    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "P4105");
    }
  }
}