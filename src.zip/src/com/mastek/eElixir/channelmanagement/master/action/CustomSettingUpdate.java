/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME				: CustomSettingUpdate
 *  AUTHOR					: Amid P Sahu
 *  VERSION					: 1.0
 *  CREATION DATE		    : Sep 02, 2009
 *  COMPANY				    : Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2009.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *   
 *--------------------------------------------------------------------------------
 *Amid_FSD_FYC & RYC Payment post Agent Termination
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.CustomSettingResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class CustomSettingUpdate extends Action {

	/**
	 * Constructer
	 */

	public CustomSettingUpdate() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :
	 *            ResultObject object.
	 * @roseuid 3B94961803CB
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		CHMSL remoteCHMSL = null;
		try {
			log.debug("inside process --------> ");
			setCustomSetting(request);
			String strnParameter = request.getParameter("nSParameter");
		      String strScreenName = request.getParameter("nScreenName");
		      log.debug("Amid strnParameter --------> "+strnParameter);
		      log.debug("Amid strScreenName --------> "+strScreenName); 
		      oCustomSettingResult = new CustomSettingResult();
		      if(strScreenName != null && !strScreenName.trim().equals(""))
		      {
		    	  oCustomSettingResult.setScreenName(new Short(strScreenName)); 
		    	  log.debug("oCustomSettingResult.setScreenName( --------> "+oCustomSettingResult.getScreenName());
		      }
		      if(strnParameter != null && !strnParameter.trim().equals(""))
		      {    	   
		    	  oCustomSettingResult.setParameter(new Short(strnParameter)); 
		    	  log.debug("oCustomSettingResult.setParameter( --------> "+oCustomSettingResult.getParameter());
		      }
			log.debug("Amid inside the process method");
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			remoteCHMSL.updateCustomSetting(_oCustomSettingList);
			_oCustomSettingList = remoteCHMSL.searchCustomSetting(oCustomSettingResult); 
			setResult(_oCustomSettingList);
		} catch (FinderException fex) {
			request.setAttribute("ResultObject", _oCustomSettingList);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oCustomSettingList);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oCustomSettingList);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log
					.debug("In CustomSettingUpdate eelixir exception before setting result"
							+ eLex);
			if (eLex.getCustomErrorCode().equalsIgnoreCase("P1100")) {
				try {
					 _oCustomSettingList = remoteCHMSL.searchCustomSetting(oCustomSettingResult); 
					setResult(_oCustomSettingList);
				} catch (RemoteException rex) {
					request.setAttribute("ResultObject", _oCustomSettingList);
					throw new EElixirException(rex, "P1006");
				} catch (FinderException cex) {
					request.setAttribute("ResultObject", _oCustomSettingList);
					throw new EElixirException(cex, "P1007");
				}

			}
			request.setAttribute("ResultObject", _oCustomSettingList);
			throw eLex;
		}

	}

	private void setCustomSetting(HttpServletRequest a_oRequest) {
		log.debug("inside process --------> ");
		String strParamCd[] = a_oRequest.getParameterValues("strParamCd");
		String strAgentTenureFrom[] = a_oRequest.getParameterValues("nAgentTenureFrom");
		String strAgentTenureTo[] = a_oRequest.getParameterValues("nAgentTenureTo");
		String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
		String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");
		String strDefaultValue[] =getIsDefaultValue(a_oRequest);
		String strCustomSettingSeqNbr[] = a_oRequest.getParameterValues("lCustomSettingSeqNbr");
		String strScreenName = a_oRequest.getParameter("nScreenName");
		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String) session.getAttribute("username");
		log.debug("inside process --------> ");

		if (statusFlag != null) {
			for (int i = 0; i < statusFlag.length; i++) {
				if (!(statusFlag[i].equals(DataConstants.CLEAR_MODE))) {
					_oCustomSettingResult = new CustomSettingResult();
					log.debug("Amid inside the setCustomSetting method befor seqno"+strCustomSettingSeqNbr[i]);
					log.debug("strCustomSettingSeqNbr[i]---> "+strCustomSettingSeqNbr[i]);
					if (strCustomSettingSeqNbr[i] != null && !strCustomSettingSeqNbr[i].trim().equals("")) {
						_oCustomSettingResult.setCustomSettingSeqNbr(new Long(strCustomSettingSeqNbr[i]));
						
					} else {
						_oCustomSettingResult.setCustomSettingSeqNbr(null);
					}
					log.debug("strParamCd[i]---> "+strParamCd[i]);
					if (strParamCd[i] != null && !strParamCd[i].trim().equals(""))
					{
							_oCustomSettingResult.setParameter(new Short(strParamCd[i]));
				    }
					log.debug("strScreenName---> "+strScreenName);
					if (strScreenName != null && !strScreenName.trim().equals(""))
					{
						_oCustomSettingResult.setScreenName(new Short(strScreenName));
					}
					log.debug("strAgentTenureFrom[i]---> "+strAgentTenureFrom[i]);
					if (strAgentTenureFrom[i] != null && !strAgentTenureFrom[i].trim().equals(""))
					{
						_oCustomSettingResult.setAgentTenureFrom(new Double(strAgentTenureFrom[i]));
					}
					log.debug("strAgentTenureTo[i]---> "+strAgentTenureTo[i]);
					if (strAgentTenureTo[i] != null && !strAgentTenureTo[i].trim().equals(""))
					{
						_oCustomSettingResult.setAgentTenureTo(new Double(strAgentTenureTo[i]));
					}
					log.debug("statusFlag[i]---> "+statusFlag[i]);
					if (statusFlag[i] != null && !statusFlag[i].trim().equals(""))
					{
						_oCustomSettingResult.setStatusFlag(statusFlag[i]);
					}
					log.debug("strDefaultValue[i]---> "+strDefaultValue[i]);
					if (strDefaultValue[i] != null && !strDefaultValue[i].trim().equals(""))
					{
						_oCustomSettingResult.setDfltValue(new Short(strDefaultValue[i]));
					}
					log.debug("dtUpdated[i]---> "+dtUpdated[i]);
					if (dtUpdated[i] != null && !dtUpdated[i].trim().equals("")) {
						_oCustomSettingResult.setTsDtUpdated(Timestamp
								.valueOf(dtUpdated[i]));
					}
					_oCustomSettingResult.setUserId(_strUserId);

					log.debug("Amid show all parameter: strScreenName-"
							+ strScreenName + " strParamCd type-" + strParamCd[i]
							+ "strAgentTenureFrom-" + strAgentTenureFrom[i] + " statusFlag-"
							+ statusFlag[i] + " dtUpdated-" + dtUpdated[i]+ " strDefaultValue-" + strDefaultValue[i]
							+ " strUserId- " + _strUserId);
					_oCustomSettingList.add(_oCustomSettingResult);

				}
			}
		}
	}
	 public String[] getIsDefaultValue(HttpServletRequest a_oRequest)
		{
		 log.debug("inside getIsDefaultValue --------> ");
		    String[] strIsDefaultValue = null;
		    ArrayList alIsDefaultValue = null;
		    if(a_oRequest.getParameter("strConDefaultValue") != null && !(a_oRequest.getParameter("strConDefaultValue").trim().equals("")))
		    {
				StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("strConDefaultValue"),"||");
				alIsDefaultValue = new ArrayList();
				while(st.hasMoreTokens())
				{
					alIsDefaultValue.add(st.nextToken());
				}
				log.debug("inside getIsDefaultValue >>alIsDefaultValue.size()----->"+alIsDefaultValue.size());
				if(alIsDefaultValue.size() > 0)
				{
					strIsDefaultValue = new String[alIsDefaultValue.size()];
				    for(int i=0;i<alIsDefaultValue.size();i++)
				    {
				    	strIsDefaultValue[i] = (String)alIsDefaultValue.get(i);
				    	log.debug("inside getIsDefaultValue --strIsDefaultValue[i]---->"+strIsDefaultValue[i]);

				    }
				}
		    }
		    return strIsDefaultValue;
		}

	// class level variable declarations.

	CustomSettingResult _oCustomSettingResult = null;
	CustomSettingResult oCustomSettingResult = null;

	ArrayList _oCustomSettingList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
