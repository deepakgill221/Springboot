/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CompanySearch.java
*  AUTHOR			: Jimmy Shah
*  VERSION			: 1.0
*  CREATION DATE	        : November 8, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1           4/1/2003          Jimmy Shah            Changes for the Audit of Menu Clicks
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.CompanyResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class CompanySearch extends Action
{

  /**
   * Constructor of the CompanySearch class
   */
  public CompanySearch()
  {

  }


  /**
   * Gets the Company Details
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    CompanyResult oCompanyResult = null;
    try{

      MenuAccessLog.createMenuAccessLog(a_oRequest);
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      oCompanyResult = remoteCHMSL.searchCompany();
      log.debug("result accessed");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      setResult(oCompanyResult);
      log.debug("result is set");
    }
    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "P4115");
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
  }


  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}