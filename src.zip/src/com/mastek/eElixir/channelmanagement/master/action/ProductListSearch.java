/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : ProductListSearch.java
*  AUTHOR           : Vikrant Chitre
*  VERSION          : 1.0
*  CREATION DATE    : Aug 08, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_PRODUCT_MASTER_SEARCH
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
**********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;


public class ProductListSearch extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor of the ProductListSearch class
     */
    public ProductListSearch()
    {
    }

    /**
     * This method is used to search the Product records
     * @param a_oRequest HttpServletRequest object.
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
        try
        {
            a_oRequest.setAttribute("actiontype",
                DataConstants.ACTION_LISTSEARCH);
            String oResult = null;
            CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

            SearchData oSearchData = new SearchData();
            oSearchData.setTask1(a_oRequest.getParameter("strProdCd"));
            oSearchData.setTask2(a_oRequest.getParameter("strProdDesc"));
            oSearchData.setTask3(a_oRequest.getParameter("dtEffFrom"));

            oResult = oRemoteCHMSL.searchProduct(oSearchData);
            setResult(oResult);
        }
        catch (RemoteException rex)
        {
            _oLogger.fatal("ProductListSearch----RemoteException");
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException rex)
        {
            _oLogger.fatal("ProductListSearch----FinderException");
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            _oLogger.fatal("ProductListSearch----CreateException");
            throw new EElixirException(cex, "P1007");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal("ProductListSearch----EElixirException");
            throw eex;
        }
    }
}