/********************************************************************
 *
 *  PROJECT                        : MNYL
 *  MODULE NAME                    : CHANNEL MANAGEMENT
 *  FILENAME                       : QuestionReplyListSearch.java
 *  AUTHOR                         : Dipti Fondekar
 *  VERSION                        : 1.0
 *  CREATION DATE                  : 21/08/2003
 *  SPECS NAME                     : cm_questionreply_search.jsp.doc
 *  COMPANY                        : Mastek Ltd.
 *  COPYRIGHT                      : COPYRIGHT (C) 2003.
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE   BY      REASON
 *--------------------------------------------------------------------------------
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;


public class NewQuestionReplyListSearch extends Action
{
	/**
	* Default Constructor
	*/
    public NewQuestionReplyListSearch()
    {
    }

    /**
     * blank process method to follow the MVC architecture, it just makes the xsl file available to the requested jsp at the beginning
     * @param : request - Request object.
     * @roseuid 3B94961803CB
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
        a_oRequest.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);
    }
}
