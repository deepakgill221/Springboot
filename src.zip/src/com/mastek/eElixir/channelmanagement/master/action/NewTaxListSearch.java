/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : NewTaxListSearch.java
*  AUTHOR           : Vikrant Chitre
*  VERSION          : 1.0
*  CREATION DATE    : Jul 19, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : NewTaxListSearch
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * This Action Class is Used to List the Tax Records
 */
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class NewTaxListSearch extends Action
{
    /**
     * Member Variables Declaration
     */
    private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor of the TaxListSearch class
     */
    public NewTaxListSearch()
    {
    }

    /**
     *
     * @param a_oRequest HttpServletRequest object.
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
        try
        {
            MenuAccessLog.createMenuAccessLog(a_oRequest);
            a_oRequest.setAttribute("actiontype",
                DataConstants.ACTION_LISTSEARCH);
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1006");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }
}
