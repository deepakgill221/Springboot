/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME  	: CHANNEL MANAGEMENT
*  FILENAME     	: TaxAdd.java
*  AUTHOR       	: Vikrant Chitre
*  VERSION      	: 1.0
*  CREATION DATE    : Jul 16, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_TAX_MASTER_DETAIL
*
*  MODIFICATION HISTORY:-
*
*--------------------------------------------------------------------------------
* VERSION        DATE                  BY                        REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class AllocationMarkerAdd extends Action
{
    //class level variable declarations.
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

	/**
	 * Constructor of the TaxAdd class
	 */
    public AllocationMarkerAdd()
    {
    }

    /**
    * This method makes a remote call to the Session bean which in turn makes a local
    * call to all other bean .
    * @param  a_oRequest HttpServletRequest
    * @throws EElixirException
    */
    public void process(HttpServletRequest a_oRequest) throws EElixirException
    {
        a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);

    }
}