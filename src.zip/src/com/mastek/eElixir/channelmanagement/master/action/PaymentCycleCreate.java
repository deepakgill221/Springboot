/********************************************************************
 *
 *  PROJECT         : MNYL
 *  MODULE NAME     : CHANNEL MANAGEMENT
 *  FILENAME        : PaymentCycleCreate.java
 *  AUTHOR          : Vikrant Chitre
 *  VERSION         : 1.0
 *  CREATION DATE   : Aug 20, 2003
 *  COMPANY         : Mastek Ltd.
 *  COPYRIGHT       : COPYRIGHT (C) 2003.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION        DATE                  BY                        REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.PaymentCycleResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;

public class PaymentCycleCreate extends Action
{
    private PaymentCycleResult _oPaymentCycleResult = null;
    private ArrayList _oPaymentCycleList = new ArrayList();
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Default constructor
     */
    public PaymentCycleCreate()
    {
    }

    /**
    * This method makes a remote call to the Session bean which in turn makes a local
    * call to all other bean .
    * @param : a_oRequest HttpServletRequest
    * @throws EElixirException
    */
    public void process(HttpServletRequest a_oRequest) throws EElixirException
    {
        a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);

        try
        {
            setPaymentCycle(a_oRequest);

            if (_oPaymentCycleList.size() > 0)
            {
                CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome",CHMSLHome.class);
                oRemoteCHMSL.createPaymentCycle(_oPaymentCycleList);
                EElixirUtils.reloadMaster(DataConstants.PAYMENT_CYCLE);
				_oPaymentCycleList = oRemoteCHMSL.searchPaymentCycleByDate(a_oRequest.getParameter("dtCycleEffDt"));
                setResult(_oPaymentCycleList);
                a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
            }
        }
        catch (FinderException fex)
        {
            a_oRequest.setAttribute("ResultObject", _oPaymentCycleList);
			_oLogger.fatal(getClass().getName(),"process","FinderException "+fex.getMessage());
            throw new EElixirException(fex, "P1007");
        }
        catch (RemoteException rex)
        {
            a_oRequest.setAttribute("ResultObject", _oPaymentCycleList);
			_oLogger.fatal(getClass().getName(),"process","RemoteException "+rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            a_oRequest.setAttribute("ResultObject", _oPaymentCycleList);
			_oLogger.fatal(getClass().getName(),"process","CreateException "+cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (EElixirException eLex)
        {
            a_oRequest.setAttribute("ResultObject", _oPaymentCycleList);
			_oLogger.fatal(getClass().getName(),"process","EElixirException "+eLex.getMessage());
            throw eLex;
        }
    }

	/**
	* This method sets the Payment Cycle object from Request
	* @param a_oRequest HttpServletRequest
	*/
    private void setPaymentCycle(HttpServletRequest a_oRequest)
    {
        HttpSession oSession = a_oRequest.getSession();
        String strUserId = (String) oSession.getAttribute("username");
        String strdtCycleEffDt = a_oRequest.getParameter("dtCycleEffDt");

        String[] strPeriodFrom = a_oRequest.getParameterValues("nPeriodFrom");
		String[] strPeriodTo = a_oRequest.getParameterValues("nPeriodTo");
		String[] strPmtDay = a_oRequest.getParameterValues("nPmtDay");
        String[] strStatusFlag = a_oRequest.getParameterValues("statusFlag");

        if (strStatusFlag != null)
        {
            for (int i = 0; i < strStatusFlag.length; i++)
            {
                if (!(strStatusFlag[i].equals(DataConstants.CLEAR_MODE)) &&
                        !(strStatusFlag[i].equals(DataConstants.DISPLAY_MODE)))
                {
                    _oPaymentCycleResult = new PaymentCycleResult();
                    _oPaymentCycleResult.setEffectiveDate(DateUtil.retGCDate(strdtCycleEffDt));
                    _oPaymentCycleResult.setPeriodFrom(new Short(strPeriodFrom[i]));
					_oPaymentCycleResult.setPeriodTo(new Short(strPeriodTo[i]));
					_oPaymentCycleResult.setPmtDay(new Short(strPmtDay[i]));
                    _oPaymentCycleResult.setStatusFlag(strStatusFlag[i]);
                    _oPaymentCycleResult.setUserId(strUserId);
                    _oPaymentCycleList.add(_oPaymentCycleResult);
                }
            }
        }
    }
}