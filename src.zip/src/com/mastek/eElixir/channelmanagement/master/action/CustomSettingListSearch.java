/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME					: CustomSettingListSearch.java
*  AUTHOR					: Amid P Sahu	
*  VERSION					: 1.0
*  CREATION DATE		    : Aug 24, 2009
*  COMPANY				    : Mastek Ltd.
*  COPYRIGHT			    : COPYRIGHT (C) 2008.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*Amid_FSD_FYC & RYC Payment post Agent Termination
*********************************************************************/


package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.CustomSettingResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;




/**
 * <p>Title: eElixir</p>
 * <p>Description: Action Class for retrieving the CSA/CPA </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */

public class CustomSettingListSearch extends Action
{

  /**
   * @Constructor
   */
  public CustomSettingListSearch(){
  }

  /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean and get the Segmentations ArrayList Object
   * @param: request - Request object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest request)  throws EElixirException
  {
	
    ArrayList _oCustomSettingList = null;
    request.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);
    try{
    	log.debug("action>>>>>>>>>>>>>>");
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      String strnParameter = request.getParameter("nSParameter");
      String strScreenName = request.getParameter("nScreenName");
      log.debug("Amid strnParameter --------> "+strnParameter);
      log.debug("Amid strScreenName --------> "+strScreenName); 
      CustomSettingResult oCustomSettingResult = new CustomSettingResult();
      if(strScreenName != null && !strScreenName.trim().equals(""))
      {
    	  oCustomSettingResult.setScreenName(new Short(strScreenName)); 
    	  log.debug("oCustomSettingResult.setScreenName( --------> "+oCustomSettingResult.getScreenName());
      }
      if(strnParameter != null && !strnParameter.trim().equals(""))
      {    	   
    	  oCustomSettingResult.setParameter(new Short(strnParameter)); 
    	  log.debug("oCustomSettingResult.setParameter( --------> "+oCustomSettingResult.getParameter());
      }
      _oCustomSettingList = remoteCHMSL.searchCustomSetting(oCustomSettingResult);          
      setResult(_oCustomSettingList);
      request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
    }
    catch(RemoteException rex)
    {
      request.setAttribute("ResultObject", _oCustomSettingList);
      throw new EElixirException(rex, "P1006");
    }
   catch(FinderException rex)
    {
      request.setAttribute("ResultObject", _oCustomSettingList);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      request.setAttribute("ResultObject", _oCustomSettingList);
      throw new EElixirException(cex, "P1007");
    }

    catch(EElixirException cex)
    {
      request.setAttribute("ResultObject", _oCustomSettingList);
      throw cex;
    }


  }
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}
