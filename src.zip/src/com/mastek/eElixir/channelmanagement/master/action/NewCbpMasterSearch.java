/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME     : CHANNEL MANAGEMENT
 *  FILENAME        : NewCbpMasterSearch.java
 *  AUTHOR          : Santosh Pandya
 *  VERSION         : 1.0
 *  CREATION DATE   : May 07, 2008
 *  COMPANY         : Mastek Ltd.
 *  COPYRIGHT       : COPYRIGHT (C) 2005.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION        DATE                  BY                        REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Logger;

public class NewCbpMasterSearch extends Action
{
    /**
     * Constructor for Class
     */
    public NewCbpMasterSearch()
    {
    }

    /**
     * blank process method to follow the MVC architecture
     * @param  a_oRequest HttpServletRequest
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
        try
        {
            MenuAccessLog.createMenuAccessLog(a_oRequest);
			a_oRequest.setAttribute("actiontype",
                DataConstants.ACTION_LISTSEARCH);
		}
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
    }
	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}