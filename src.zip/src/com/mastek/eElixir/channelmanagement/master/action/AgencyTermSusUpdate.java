/********************************************************************
*
*  PROJECT			: MMMA
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: AgencyTermSusUpdate.java
*  AUTHOR			: Jayasimha Reddy
*  VERSION			: 1.0
*  CREATION DATE	: October 20, 2002
*  COMPANY			: Cognizant Technology Solutions
*  COPYRIGHT 		: 

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/




package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.AgencyTermSusResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;


public class AgencyTermSusUpdate extends Action
{
  
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  
  ArrayList arrAgencyTermSusResult = new ArrayList();
  
  AgencyTermSusResult oAgencyTermSusResult = null ;

  /**
   * Constructor of the AgencyTermSusUpdate class
   */
  public AgencyTermSusUpdate()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    CHMSL remoteCHMSL = null;
    try{
      remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      
      log.debug("before setting rhe AgencyTermSusResult ");
      
      AgencyTermSusResult(a_oRequest);
      
      log.debug("after setting rhe AgencyTermSusResult " + arrAgencyTermSusResult);
      
      remoteCHMSL.updateAgencyTermSusDtls (arrAgencyTermSusResult);
      
      EElixirUtils.reloadMaster(DataConstants.CHANNEL_TYPE);
      
      arrAgencyTermSusResult = remoteCHMSL.searchAgencyTermSusDtls();
      
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      
      setResult(arrAgencyTermSusResult);
      
    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", arrAgencyTermSusResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", arrAgencyTermSusResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", arrAgencyTermSusResult);
      throw new EElixirException(fex, "P4105");
    }
    catch(EElixirException eex)
    {
      log.debug("In AgencyTermSusUpdate eelixir exception before setting result" + eex);
      a_oRequest.setAttribute("ResultObject", arrAgencyTermSusResult);
      throw eex;
    }
  }

	  public void AgencyTermSusResult(HttpServletRequest a_oRequest) 
	  {
		  
		  HttpSession session = a_oRequest.getSession();
	      String _strUserId = (String) session.getAttribute("username");
	      
	      String[] strStatusFlag = a_oRequest.getParameterValues("statusFlag"); 
	      String[] cChannelType = a_oRequest.getParameterValues("cChannelType");
	      String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated"); 
	      String[] nFYCPeriod = a_oRequest.getParameterValues("nFYCPeriod");
	      String[] nRYCPeriod = a_oRequest.getParameterValues("nRYCPeriod");
	      String[] nPmtHoldDays = a_oRequest.getParameterValues("nPmtHoldDays");
	      String[] strAgencyCd = a_oRequest.getParameterValues("strAgencyCd");
	      String[] strAgencyName = a_oRequest.getParameterValues("strAgencyName");
	      
	      
	      log.debug("strStatusFlag --->"+strStatusFlag+"<-----");
	      log.debug("cChannelType --->"+cChannelType+"<-----");
	      log.debug("dtUpdated --->"+dtUpdated+"<-----");
	      log.debug("nFYCPeriod --->"+nFYCPeriod+"<-----");
	      log.debug("nRYCPeriod --->"+nRYCPeriod+"<-----");
	      log.debug("nPmtHoldDays --->"+nPmtHoldDays+"<-----");
	      log.debug("strAgencyCd --->"+strAgencyCd+"<-----");
	      log.debug("strAgencyCd --->"+strAgencyName+"<-----");
	      
	      
	      
	      
	      for (int i = 0; i < cChannelType.length; i++)
	      {
	    	  
	          log.debug("I am inside for loop --->"+i+"<-----");
	          
	          log.debug("strStatusFlag --->"+strStatusFlag[i]+"<-----");
	    	  
	          if (!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE))
	          {
	        	  
	        	  log.debug("I am inside if block");
	        	  
	        	  oAgencyTermSusResult = new AgencyTermSusResult();
	        	  
	              
	        	 
	        	  oAgencyTermSusResult.setChannelType(new Character(cChannelType[i].trim()
	                                                                         .charAt(0)));
	        	  
	        	  log.debug("after setting the channel");
	        	  
	        	  oAgencyTermSusResult.setStatusFlag(strStatusFlag[i]);
	        	  
	        	  log.debug("after setting the status");
	        	  
	        	  oAgencyTermSusResult.setUserId(_strUserId);

	        	  log.debug("after setting the userid");
	        	  
	        	  oAgencyTermSusResult.setAgencyCd(strAgencyCd[i]);
	        	  
	        	  oAgencyTermSusResult.setAgencyName(strAgencyName[i]);
	
	        	  log.debug("after setting the agencycd");
	        	  
	              if ((nRYCPeriod != null) && (nRYCPeriod[i] != null) &&
	                      !nRYCPeriod[i].equals(""))
	              {
	            	  oAgencyTermSusResult.setRYCPeriod(new Short(nRYCPeriod[i].trim()));
	            	  
		        	  log.debug("after setting the RYC period");
	              }
	
	              
	              if ((nFYCPeriod != null) && (nFYCPeriod[i] != null) &&
	                      !nFYCPeriod[i].equals(""))
	              {
	            	  
	            	  oAgencyTermSusResult.setFYCPeriod(new Short(nFYCPeriod[i].trim()));
		        	  log.debug("after setting the FYC period");
	              }
	
	              if ((nPmtHoldDays != null) && (nPmtHoldDays[i] != null) &&
	                      !nPmtHoldDays[i].equals(""))
	              {
	            	  oAgencyTermSusResult.setPmtHoldDays(new Short(nPmtHoldDays[i].trim()));
	            	  
		        	  log.debug("after setting the pmt holdays");
	              }
	
	              if ((dtUpdated[i] != null) && !dtUpdated[i].trim().equals(""))
	              {
	            	  oAgencyTermSusResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated[i]));
            	  
		        	  log.debug("after setting the dtupdated");
	              }
	
	              log.debug("after setting rhe AgencyTermSusupdate oAgencyTermSusResult" + oAgencyTermSusResult.toString());	              
	              
	              arrAgencyTermSusResult.add(oAgencyTermSusResult);
	              
	              log.debug("after adding the result to arraylist");
	              
	          }
	      }
		  
	  } // End of AgencyTermSusResult method
}