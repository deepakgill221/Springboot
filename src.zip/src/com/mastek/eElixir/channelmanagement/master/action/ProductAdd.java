/********************************************************************
*
*  PROJECT          : MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : ProductAdd.java
*  AUTHOR           : Vikrant Chitre
*  VERSION          : 1.0
*  CREATION DATE    : Aug 09, 2003
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2003.
*  SPEC NAME        : CM_PRODUCT_DETAIL
*
*  MODIFICATION HISTORY:-
*
*--------------------------------------------------------------------------------
* VERSION        DATE                  BY                        REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class ProductAdd extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

	/**
	 * Constructor of the ProductAdd class
	 */
    public ProductAdd()
    {
    }

    /**
    * Uset to set request attribute as Create
    * @param : a_oRequest HttpServletRequest
    * @throws EElixirException
    */
    public void process(HttpServletRequest a_oRequest) throws EElixirException
    {
        a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
    }
}