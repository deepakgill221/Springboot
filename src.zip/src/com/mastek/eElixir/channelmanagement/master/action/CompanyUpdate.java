/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CompanyUpdate.java
*  AUTHOR			: Jimmy Shah
*  VERSION			: 1.0
*  CREATION DATE	        : November 8, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.0       23/1/2003     Amit N        To avoid unnecessary update getting fired
*1.1	   07/02/2003   Amit N        Incorporated Agent Code Length & Agency Code Length as per onsite directions
* 1.2      22/09/2003	Vikrant C	  Added PAN, TAN		
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.CompanyResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;


public class CompanyUpdate extends Action
{


  /**
   * Constructor of the CompanyUpdate class
   */
  public CompanyUpdate()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    CompanyResult oCompanyResult = null;
    CHMSL remoteCHMSL = null;
    try{
      remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

      log.debug("before create Company");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      oCompanyResult = getCompanyResult(a_oRequest);
      remoteCHMSL.updateCompany(oCompanyResult);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      oCompanyResult = remoteCHMSL.searchCompany();
      setResult(oCompanyResult);
      log.debug("result accessed");

    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oCompanyResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oCompanyResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", oCompanyResult);
      throw new EElixirException(fex, "P4115");
    }
    catch(EElixirException eex)
    {
      log.debug("Inside catch of EElixir exception in process of CompanyUpdate");
      if (eex.getCustomErrorCode().equalsIgnoreCase("P1100"))
       {
         try
         {
           log.debug("In CompanyUpdate exception before exceptionsearch ");
            oCompanyResult = remoteCHMSL.searchCompany();
           log.debug("In CompanyUpdate  exception result is set");
         }
         catch(RemoteException rex)
         {
           a_oRequest.setAttribute("ResultObject", oCompanyResult);
           throw new EElixirException(rex, "P1006");
         }
         catch(FinderException cex)
         {
           a_oRequest.setAttribute("ResultObject", oCompanyResult);
           throw new EElixirException(cex, "P1007");
         }
       }
       a_oRequest.setAttribute("ResultObject", oCompanyResult);
       throw eex;
    }
  }


  /**
   * Method populates CompanyResult object from Request
   * @param a_oRequest HttpServletRequest
   * @return CompanyResult
   * @throws EElixirException
   */
  public CompanyResult getCompanyResult(HttpServletRequest a_oRequest) throws EElixirException
  {
    CompanyResult oCompanyResult = new CompanyResult();
	Short nCmprMonth = null;
    String strCmprMonth = a_oRequest.getParameter("nCmprMonth").trim();
    if(strCmprMonth != null && !strCmprMonth.equals(""))
    {
      nCmprMonth = new Short(strCmprMonth);
    }

	Short nReplLimit = null;
    String strReplLimit = a_oRequest.getParameter("nReplLimit").trim();
    if(strReplLimit != null && !strReplLimit.equals(""))
    {
      nReplLimit = new Short(strReplLimit);
	  log.debug("CompanyUpdate ===getCompanyResult===nReplLimit"+nReplLimit);
    }

	GregorianCalendar dtEffFrom = null;
    String strEffFrom = a_oRequest.getParameter("dtEffFrom").trim();
    if(strEffFrom != null && !strEffFrom.equals(""))
    {
      dtEffFrom = DateUtil.retGCDate(strEffFrom);
    }

	Short nIsSinglePrm = null;
    String strIsSinglePrm = a_oRequest.getParameter("nIsSinglePrm").trim();
    if(strIsSinglePrm != null && !strIsSinglePrm.equals(""))
    {
      nIsSinglePrm = new Short(strIsSinglePrm);
    }

	Short nAgentLength = null;
    String strAgentLength = a_oRequest.getParameter("nAgentLength").trim();
    if(strAgentLength != null && !strAgentLength.equals(""))
    {
      nAgentLength = new Short(strAgentLength);
    }

	Short nAgencyLength = null;
    String strAgencyLength = a_oRequest.getParameter("nAgencyLength").trim();
    if(strAgencyLength != null && !strAgencyLength.equals(""))
    {
      nAgencyLength = new Short(strAgencyLength);
    }

    String dtUpdated = a_oRequest.getParameter("dtUpdated");
    if (dtUpdated != null && !dtUpdated.trim().equals(""))
    {
      oCompanyResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated));
    }

    String strPAN = a_oRequest.getParameter("strPAN").trim();
    String setTanNbr = a_oRequest.getParameter("strTanNbr").trim();
    String strMinConsumpAmnt = a_oRequest.getParameter("dMinConsumpAmnt").trim();


    HttpSession  session = a_oRequest.getSession();
    String  strUserId = (String)session.getAttribute("username");

	oCompanyResult.setCmprMonth(nCmprMonth);
	oCompanyResult.setReplLimit(nReplLimit);
	oCompanyResult.setEffFrom(dtEffFrom);
	oCompanyResult.setIsSinglePrm(nIsSinglePrm);
	oCompanyResult.setAgentLength(nAgentLength);
	oCompanyResult.setAgencyLength(nAgencyLength);
    oCompanyResult.setUserId(strUserId);
	oCompanyResult.setPAN(strPAN);
	oCompanyResult.setTanNbr(setTanNbr);
	
	
	oCompanyResult.setRegOffice(a_oRequest.getParameter("strRegOffice").trim());
	oCompanyResult.setHoOffice(a_oRequest.getParameter("strHoOffice").trim());
	oCompanyResult.setPhoneNo(a_oRequest.getParameter("strPhoneNo").trim());
	oCompanyResult.setFaxNo(a_oRequest.getParameter("strFaxNo").trim());	
	oCompanyResult.setServTaxNo(a_oRequest.getParameter("strServTaxNo").trim());
	oCompanyResult.setRemarks1(a_oRequest.getParameter("strRemarks1").trim());
	oCompanyResult.setRemarks2(a_oRequest.getParameter("strRemarks2").trim());
		
    if(strMinConsumpAmnt != null && !strMinConsumpAmnt.equals(""))
    {
	    oCompanyResult.setMinConsumpAmnt(new Double(strMinConsumpAmnt));
	}
	
	 // To avoid unnecessary update
      oCompanyResult.setHdrStatusFlag(a_oRequest.getParameter("hdrStatusFlag"));

    return oCompanyResult;
  }

  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}