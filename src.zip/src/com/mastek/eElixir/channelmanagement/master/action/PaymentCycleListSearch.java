/********************************************************************
 *
 *  PROJECT         : MNYL
 *  MODULE NAME     : CHANNEL MANAGEMENT
 *  FILENAME        : PaymentCycleListSearch.java
 *  AUTHOR          : Vikrant Chitre
 *  VERSION         : 1.0
 *  CREATION DATE   : Aug 20, 2003
 *  COMPANY         : Mastek Ltd.
 *  COPYRIGHT       : COPYRIGHT (C) 2003.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION        DATE                  BY                        REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class PaymentCycleListSearch extends Action
{
	private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * @Constructor for class
     */
    public PaymentCycleListSearch()
    {
    }

    /**
     * This method makes a remote call to the Session bean which in turn makes a local
     * call to all other bean and get the PaymentCycle ArrayList Object
     * @param: a_oRequest - HttpServletRequest 
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {

        ArrayList oPaymentCycleList = null;
        a_oRequest.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);

        try
        {
            CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
            oPaymentCycleList = oRemoteCHMSL.searchPaymentCycleByDate(a_oRequest.getParameter("dtCycleEffDt"));
            setResult(oPaymentCycleList);
            a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
        }
        catch (RemoteException rex)
        {
            a_oRequest.setAttribute("ResultObject", oPaymentCycleList);
			_oLogger.fatal(getClass().getName(),"process","RemoteException "+rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException rex)
        {
            a_oRequest.setAttribute("ResultObject", oPaymentCycleList);
			_oLogger.fatal(getClass().getName(),"process","FinderException "+rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            a_oRequest.setAttribute("ResultObject", oPaymentCycleList);
			_oLogger.fatal(getClass().getName(),"process","CreateException "+cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }

        catch (EElixirException cex)
        {
            a_oRequest.setAttribute("ResultObject", oPaymentCycleList);
			_oLogger.fatal(getClass().getName(),"process","EElixirException "+cex.getMessage());
            throw cex;
        }
    }
}
