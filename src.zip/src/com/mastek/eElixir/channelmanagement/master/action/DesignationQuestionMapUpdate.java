/********************************************************************
 *
 *  PROJECT                        : MNYL
 *  MODULE NAME                    : CHANNEL MANAGEMENT
 *  FILENAME                       : DesignationQuestionMapUpdate.java
 *  AUTHOR                         : Dipti Fondekar
 *  VERSION                        : 1.0
 *  CREATION DATE                  : 21/08/2003
 *  SPECS NAME                     : cm_desigquest_map.doc
 *  COMPANY                        : Mastek Ltd.
 *  COPYRIGHT                      : COPYRIGHT (C) 2003.
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE   BY      REASON
 *--------------------------------------------------------------------------------
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.DesignationQuestionMapResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;


public class DesignationQuestionMapUpdate extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    //class level variable declarations.
    DesignationQuestionMapResult _oDesignationQuestionMapResult = null;
    ArrayList _oDesignationQuestionMapList = new ArrayList();
    CHMSL remoteCHMSL = null;
    SearchData oSearchData;

    /**
     * @roseuid 3B94961803B7
     */
    public DesignationQuestionMapUpdate()
    {
    }

    /**
    * This method makes a remote call to the Session bean which in turn makes a local
    * call to all other bean .
    * @param : ResultObject object.
    * @roseuid 3B94961803CB
    * @throws EElixirException
    */
    public void process(HttpServletRequest request) throws EElixirException
    {
        ArrayList alresultobjectlist = null;
        ArrayList alPTFResult = new ArrayList();
        request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);

        try
        {
            oSearchData = new SearchData();
            setDesignationQuestionMap(request);

            String cChannelType = request.getParameter("cChannelType");
            String strDesgnCd = request.getParameter("strDesgnCd");

            remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
            remoteCHMSL.updateDesignationQuestionMap(_oDesignationQuestionMapList);

            if ((cChannelType != null) && !cChannelType.trim().equals(""))
            {
                oSearchData.setTask1(cChannelType);
            }

            if ((strDesgnCd != null) && !strDesgnCd.trim().equals(""))
            {
                oSearchData.setTask2(strDesgnCd);
            }

            alresultobjectlist = remoteCHMSL.searchDesignationQuestionMap(oSearchData);
            setResult(alresultobjectlist);
            request.setAttribute("questionlist", alPTFResult);
        }
        catch (FinderException fex)
        {
            _oLogger.fatal(getClass().getName(), "Process", fex.getMessage());
            request.setAttribute("ResultObject", _oDesignationQuestionMapList);
            throw new EElixirException(fex, "P1007");
        }

        catch (CreateException cex)
        {
            request.setAttribute("ResultObject", _oDesignationQuestionMapList);
            _oLogger.fatal(getClass().getName(), "Process", cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }

        catch (EElixirException eBex)
        {
            try
            {
                alresultobjectlist = remoteCHMSL.searchDesignationQuestionMap(oSearchData);
                request.setAttribute("ResultObject", alresultobjectlist);
                _oLogger.fatal(getClass().getName(), "Process",
                    eBex.getMessage());
                throw eBex;
            }
            catch (FinderException fex)
            {
                request.setAttribute("ResultObject", alresultobjectlist);
                _oLogger.fatal(getClass().getName(), "Process", fex.getMessage());
                throw new EElixirException(fex, "P1006");
            }
            catch (RemoteException rex)
            {
                request.setAttribute("ResultObject", alresultobjectlist);
                _oLogger.fatal(getClass().getName(), "Process", rex.getMessage());
                throw new EElixirException(rex, "P1006");
            }
        }

        catch (RemoteException rex)
        {
            request.setAttribute("ResultObject", _oDesignationQuestionMapList);
            _oLogger.fatal(getClass().getName(), "Process", rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }

    private void setDesignationQuestionMap(HttpServletRequest a_oRequest)
    {
        String[] lQuestSeqNbr = a_oRequest.getParameterValues("lQuestSeqNbr");
        String[] nQuestionOrder = a_oRequest.getParameterValues("nQuestOrder");
        String[] nIsActive = a_oRequest.getParameterValues("nIsActive");
        String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");

        String[] statusFlag = a_oRequest.getParameterValues("statusFlag");
        String cChannelType = a_oRequest.getParameter("cChannelType");
        String strDesgnCd = null;
        HttpSession session = a_oRequest.getSession();
        String strUserId = (String) session.getAttribute("username");

        if (a_oRequest.getParameter("strDesgnCd") != null)
        {
            strDesgnCd = a_oRequest.getParameter("strDesgnCd");
        }

        if (statusFlag != null)
        {
            for (int i = 0; i < statusFlag.length; i++)
            {
                if (!(statusFlag[i].equals(DataConstants.CLEAR_MODE)))
                {
                    _oDesignationQuestionMapResult = new DesignationQuestionMapResult();

                    _oDesignationQuestionMapResult.setChannelType(cChannelType);
                    _oDesignationQuestionMapResult.setDesignationCode(strDesgnCd);
                    _oDesignationQuestionMapResult.setQuestionId(new Long(
                            lQuestSeqNbr[i]));
                    _oDesignationQuestionMapResult.setQuestionOrder(new Double(
                            nQuestionOrder[i]));
                    _oDesignationQuestionMapResult.setIsActive(new Short(
                            nIsActive[i]));

                    _oDesignationQuestionMapResult.setStatusFlag(statusFlag[i]);
                    _oDesignationQuestionMapResult.setUserId(strUserId);

                    if ((dtUpdated[i] != null) &&
                            !dtUpdated[i].trim().equals(""))
                    {
                        _oDesignationQuestionMapResult.setConDtUpdated(Timestamp.valueOf(
                                dtUpdated[i]));
                    }

                    _oDesignationQuestionMapList.add(_oDesignationQuestionMapResult);
                }
            }
        }
    }
}
