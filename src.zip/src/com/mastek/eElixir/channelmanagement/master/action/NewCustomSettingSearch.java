/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME     : CHANNEL MANAGEMENT
 *  FILENAME        : NewCustomSettingSearch.java
 *  AUTHOR          : Amid P Sahu
 *  VERSION         : 1.0
 *  CREATION DATE   : Aug 24, 2009
 *  COMPANY         : Mastek Ltd.
 *  COPYRIGHT       : COPYRIGHT (C) 2009.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION        DATE                  BY                        REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *Amid_FSD_FYC & RYC Payment post Agent Termination
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;

public class NewCustomSettingSearch extends Action
{
    /**
     * Constructor for Class
     */
    public NewCustomSettingSearch()
    {
    }

    /**
     * blank process method to follow the MVC architecture
     * @param  a_oRequest HttpServletRequest
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
        try
        {
            MenuAccessLog.createMenuAccessLog(a_oRequest);
            a_oRequest.setAttribute("actiontype",
                DataConstants.ACTION_LISTSEARCH);
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
    }
}