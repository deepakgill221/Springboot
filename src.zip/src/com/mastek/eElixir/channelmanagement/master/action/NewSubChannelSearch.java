/********************************************************************
 *
 *  PROJECT					: PRUDENTIAL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME					: NewSubChannelSearch.java
 *  AUTHOR					: VINAYSHEEL BABER
 *  VERSION					: 1.0
 *  CREATION DATE		: October 22, 2002
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2002.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1           4/1/2003          Jimmy Shah            Changes for the Audit of Menu Clicks
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/


package com.mastek.eElixir.channelmanagement.master.action;

/**
 * Called at the beginnning of SubChannel Create
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author    Vinaysheel Baber
 * @version 1.0
 */

 import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;


 public class NewSubChannelSearch extends Action
 {

   /**
    * @roseuid 3B94961803B7
    */
   public NewSubChannelSearch()
   {

   }

   /**
    * blank process method to follow the MVC architecture, it just makes the xsl file available to the requested jsp at the beginning
    * @param : request - Request object.
    * @roseuid 3B94961803CB
    * @throws EElixirException
    */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     try
     {
       MenuAccessLog.createMenuAccessLog(a_oRequest);
       a_oRequest.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
     }
     catch(RemoteException rex)
     {
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       throw new EElixirException(cex, "P1007");
     }
     catch(EElixirException eex)
     {
       throw eex;
     }

   }
 }