/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BounceUpdate.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE	        : feb 20, 2009
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*FSD_FIN_68_Debiting_Bounce_charges_APRIL_REL_ANUP_19Feb2009
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * BounceUpdate is the Action Class for updating a Bounce.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.master.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.master.util.BounceFetch;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;


public class BounceChargesUpdate extends Action
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the BenefitUpdate class
   */
  public BounceChargesUpdate()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ArrayList arrBounceResult = null;
    BounceFetch oBounceFetch = new BounceFetch();
    CHMSL remoteCHMSL = null;
    try{
      remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      log.debug("BounceUpdate--Before fetching parameters");
      arrBounceResult = oBounceFetch.fetchBounce(a_oRequest);
      log.debug("BounceUpdate--After fetching parameters");

      log.debug("BounceUpdate--before update Bounce");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      remoteCHMSL.updateBounce(arrBounceResult);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      EElixirUtils.reloadMaster(DataConstants.CHANNEL_TYPE);
      log.debug("BounceUpdate--before search Bounce");
      arrBounceResult = remoteCHMSL.searchBounce();
      log.debug("BounceUpdate--after search Bounce");
      setResult(arrBounceResult);
      log.debug("BounceUpdate--result accessed");

    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", arrBounceResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", arrBounceResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", arrBounceResult);
      throw new EElixirException(fex, "P4105");
    }
    catch(EElixirException eex)
    {
      log.debug("In BounceUpdate eelixir exception before setting result" + eex);
      if (eex.getCustomErrorCode().equalsIgnoreCase("P1100"))
      {
        try
        {
          log.debug("In BounceUpdate exception before setting result");
          arrBounceResult = remoteCHMSL.searchBounce();
          log.debug("In BounceUpdate  exception result is set");
        }
        catch(RemoteException rex)
        {
          a_oRequest.setAttribute("ResultObject", arrBounceResult);
          throw new EElixirException(rex, "P1006");
        }
        catch(FinderException cex)
        {
          a_oRequest.setAttribute("ResultObject", arrBounceResult);
          throw new EElixirException(cex, "P1007");
        }

      }
      a_oRequest.setAttribute("ResultObject", arrBounceResult);
      throw eex;
    }
  }
  
  
  

}