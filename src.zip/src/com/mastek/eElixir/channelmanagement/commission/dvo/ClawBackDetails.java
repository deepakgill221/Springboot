/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ClawBackDetails.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for ClawBack Detail</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.commission.dvo;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class ClawBackDetails extends UserData implements Serializable
{
   private String _strPmtMode;
   private Short _nRngType;
   private Short _nRngFrom;
   private Short _nRngTo;
   private Double _dClawbackRate;

   protected Long _lAgrmtClawSeqNbr;
   protected String _strStatusFlag;

   /**
    * Constructor
   */
   public ClawBackDetails()
   {
   }
  public Double getClawbackRate() {
    return _dClawbackRate;
  }
  public void setClawbackRate(Double a_dClawbackRate) {
    this._dClawbackRate = a_dClawbackRate;
  }
  public Short getRngFrom() {
    return _nRngFrom;
  }
  public void setRngFrom(Short a_nRngFrom) {
    this._nRngFrom = a_nRngFrom;
  }
  public Short getRngTo() {
    return _nRngTo;
  }
  public void setRngTo(Short a_nRngTo) {
    this._nRngTo = a_nRngTo;
  }
  public Short getRngType() {
    return _nRngType;
  }
  public void setRngType(Short a_nRngType) {
    this._nRngType = a_nRngType;
  }
  public Long getlAgrmtClawSeqNbr() {
    return _lAgrmtClawSeqNbr;
  }
  public void setlAgrmtClawSeqNbr(Long a_lAgrmtClawSeqNbr) {
    this._lAgrmtClawSeqNbr = a_lAgrmtClawSeqNbr;
  }
  public String getPmtMode() {
    return _strPmtMode;
  }
  public void setPmtMode(String a_strPmtMode) {
    this._strPmtMode = a_strPmtMode;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }
  public String toString(){
    String retValue = "";
    retValue = retValue + "_strPmtMode:" + _strPmtMode + "\n";
    retValue = retValue + "_nRngType:" + _nRngType + "\n";
    retValue = retValue + "_nRngFrom:" + _nRngFrom + "\n";
    retValue = retValue + "_nRngTo:" + _nRngTo + "\n";
    retValue = retValue + "_lAgrmtClawSeqNbr:" + _lAgrmtClawSeqNbr + "\n";
    retValue = retValue + "_dClawbackRate:" + _dClawbackRate + "\n";
    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";
    return retValue;
  }
}
