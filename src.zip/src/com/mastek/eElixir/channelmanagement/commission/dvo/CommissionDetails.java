/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionDetails.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*1.1             23Jan2003         Pallav            added Maturity Age
*1.2       17Nov2009		Anup        Unit_Builder_PACE_Req1_JAN_REL_2010
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for StandardCommission Detail</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.commission.dvo;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class CommissionDetails extends UserData implements Serializable
{
   private Short _onTermFrom;
   private Short _onTermTo;
   private Short _onEntryAgeFrom;
   private Short _onEntryAgeTo;
   private Short _onMatAgeFrom;
   private Short _onMatAgeTo;
   private Short _onNbrOfLivesFrom;
   private Short _onNbrOfLivesTo;
   private Double _odSAFrom;
   private Double _odSATo;
   private Double _odBaseValeFrom;
   private Double _odBaseValeTo;
   private Short _onPolYearFrom;
   private Short _onPolYearTo;

   
/**
    * Standard/Trail Commission Attribute
    */
   private Double _odCommRate;

   /**
    * ORC / Trail Attribute
    */
   private String _strRepLinkCd;
   private Double _odSumAssuredFrom;
   private Double _odSumAssuredTo;
   protected Long _olAgrmtSCSeqNbr;
   private Short _nIsORCRatePresent;
   protected String _strStatusFlag;
   private Short _nCommPmtMode; //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010
   private Short _onPptTo; // Added by Aradhana FIN1107 12_oct_2017
   private Short _onPptFrom; // Added by Aradhana FIN1107 12_oct_2017
   /**
   * Constructor
   */
   public CommissionDetails()
   {

   }
  public Double getSAFrom() {
    return _odSAFrom;
  }
  public void setSAFrom(Double a_odSAFrom) {
    this._odSAFrom = a_odSAFrom;
  }
  public Double getSATo() {
    return _odSATo;
  }
  public void setSATo(Double a_odSATo) {
    this._odSATo = a_odSATo;
  }
  public Double getBaseValeFrom() {
    return _odBaseValeFrom;
  }
  public void setBaseValeFrom(Double a_odBaseValeFrom) {
    this._odBaseValeFrom = a_odBaseValeFrom;
  }
  public Double getBaseValeTo() {
    return _odBaseValeTo;
  }
  public void setBaseValeTo(Double a_odBaseValeTo) {
    this._odBaseValeTo = a_odBaseValeTo;
  }
  public Double getCommRate() {
    return _odCommRate;
  }
  public void setCommRate(Double a_odCommRate) {
    this._odCommRate = a_odCommRate;
  }
  public Double getSumAssuredFrom() {
    return _odSumAssuredFrom;
  }
  public void setSumAssuredFrom(Double a_odSumAssuredFrom) {
    this._odSumAssuredFrom = a_odSumAssuredFrom;
  }
  public Double getSumAssuredTo() {
    return _odSumAssuredTo;
  }
  public void setSumAssuredTo(Double a_odSumAssuredTo) {
    this._odSumAssuredTo = a_odSumAssuredTo;
  }
  public Short getEntryAgeFrom() {
    return _onEntryAgeFrom;
  }
  public void setEntryAgeFrom(Short a_onEntryAgeFrom) {
    this._onEntryAgeFrom = a_onEntryAgeFrom;
  }
  public Short getEntryAgeTo() {
    return _onEntryAgeTo;
  }
  public void setEntryAgeTo(Short a_onEntryAgeTo) {
    this._onEntryAgeTo = a_onEntryAgeTo;
  }
  public Short getMatAgeFrom() {
    return _onMatAgeFrom;
  }
  public void setMatAgeFrom(Short a_onMatAgeFrom) {
    this._onMatAgeFrom = a_onMatAgeFrom;
  }
  public Short getMatAgeTo() {
    return _onMatAgeTo;
  }
  public void setMatAgeTo(Short a_onMatAgeTo) {
    this._onMatAgeTo = a_onMatAgeTo;
  }
  public Short getNbrOfLivesFrom() {
    return _onNbrOfLivesFrom;
  }
  public void setNbrOfLivesFrom(Short a_onNbrOfLivesFrom) {
    this._onNbrOfLivesFrom = a_onNbrOfLivesFrom;
  }
  public Short getNbrOfLivesTo() {
    return _onNbrOfLivesTo;
  }
  public void setNbrOfLivesTo(Short a_onNbrOfLivesTo) {
    this._onNbrOfLivesTo = a_onNbrOfLivesTo;
  }
  public Short getPolYearFrom() {
    return _onPolYearFrom;
  }
  public void setPolYearFrom(Short a_onPolYearFrom) {
    this._onPolYearFrom = a_onPolYearFrom;
  }
  public Short getPolYearTo() {
    return _onPolYearTo;
  }
  public void setPolYearTo(Short a_onPolYearTo) {
    this._onPolYearTo = a_onPolYearTo;
  }
  public Short getTermFrom() {
    return _onTermFrom;
  }
  public void setTermFrom(Short a_onTermFrom) {
    this._onTermFrom = a_onTermFrom;
  }
  public Short getTermTo() {
    return _onTermTo;
  }
  public void setTermTo(Short a_onTermTo) {
    this._onTermTo = a_onTermTo;
  }
  public String getRepLinkCd() {
    return _strRepLinkCd;
  }
  public void setRepLinkCd(String a_strRepLinkCd) {
    this._strRepLinkCd = a_strRepLinkCd;
  }
  public Long getAgrmtSCSeqNbr() {
    return _olAgrmtSCSeqNbr;
  }
  public void setAgrmtSCSeqNbr(Long a_olAgrmtSCSeqNbr) {
    this._olAgrmtSCSeqNbr = a_olAgrmtSCSeqNbr;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }
   public Short getIsORCRatePresent() {
    return _nIsORCRatePresent;
  }
  public void setIsORCRatePresent(Short a_nIsORCRatePresent) {
    this._nIsORCRatePresent = a_nIsORCRatePresent;
  }
//Added by Aradhana FIN1107 12_oct_2017:START
	public Short getPptTo() {
		return _onPptTo;
	}
	public void setPptTo(Short onPptTo) {
		_onPptTo = onPptTo;
	}
	public Short getPptFrom() {
		return _onPptFrom;
	}
	public void setPptFrom(Short onPptFrom) {
		_onPptFrom = onPptFrom;
	}

  public String toString(){
    String retValue = "";
    retValue = retValue + "_onTermFrom:" + _onTermFrom + " ";
    retValue = retValue + "_onTermTo:" + _onTermTo + " ";
    retValue = retValue + "_onEntryAgeFrom:" + _onEntryAgeFrom + " ";
    retValue = retValue + "_onEntryAgeTo:" + _onEntryAgeTo + " ";
    retValue = retValue + "_onMatAgeFrom:" + _onMatAgeFrom + " ";
    retValue = retValue + "_onMatAgeTo:" + _onMatAgeTo + " ";
    retValue = retValue + "_onNbrOfLivesFrom:" + _onNbrOfLivesFrom + " ";
    retValue = retValue + "_onNbrOfLivesTo:" + _onNbrOfLivesTo + " ";
    retValue = retValue + "_odSAFrom:" + _odSAFrom + " ";
    retValue = retValue + "_odSATo:" + _odSATo + " ";

    retValue = retValue + "_odBaseValeFrom:" + _odBaseValeFrom + " ";
    retValue = retValue + "_odBaseValeTo:" + _odBaseValeTo + " ";
    retValue = retValue + "_onPolYearFrom:" + _onPolYearFrom + " ";
    retValue = retValue + "_onPolYearTo:" + _onPolYearTo + " ";
    retValue = retValue + "_odCommRate:" + _odCommRate + " ";
    retValue = retValue + "_olAgrmtSCSeqNbr:" + _olAgrmtSCSeqNbr + " ";

    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + " ";
    retValue = retValue + "_nIsORCRatePresent :" + _nIsORCRatePresent + " ";
    
    retValue = retValue + "_onPptTo :" + _onPptTo + " ";
    retValue = retValue + "_onPptFrom :" + _onPptFrom + " ";
    
    return retValue;
  }
//Added by Aradhana FIN1107 12_oct_2017:END
	//Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
	public Short getCommPmtMode() {
		return _nCommPmtMode;
	}
	public void setCommPmtMode(Short commPmtMode) {
		_nCommPmtMode = commPmtMode;
	}
	
	//Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Ends
	
}
