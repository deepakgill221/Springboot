/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMap.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.dvo;
import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;
/**
 * Holds the contract mapping data with agent/agency/channel
 */
 // extends added by Amit 11/1/2002
public class ContractMap extends UserData implements Serializable
{
   private String _strChannelType;
   private String _strAgentCode;
   private String _strContractType;
   private GregorianCalendar _dtEffFrom;
   private String _strContractNbr;
   private GregorianCalendar _dtEffTo;
   private Integer _iNStatus;
   private String _strStatusFlag;
   private String _strPKey;
   private String _strCDDesc;

   /**
    * @roseuid 3D9822BC016F
    */
   public ContractMap()
   {

   }
  public GregorianCalendar get_dtEffFrom() {
    return _dtEffFrom;
  }
  public void set_dtEffFrom(GregorianCalendar _dtEffFrom) {
    this._dtEffFrom = _dtEffFrom;
  }
  public GregorianCalendar get_dtEffTo() {
    return _dtEffTo;
  }
  public void set_dtEffTo(GregorianCalendar _dtEffTo) {
    this._dtEffTo = _dtEffTo;
  }
  public Integer get_iNStatus() {
    return _iNStatus;
  }
  public void set_iNStatus(Integer _iNStatus) {
    this._iNStatus = _iNStatus;
  }
  public String get_strAgentCode() {
    return _strAgentCode;
  }
  public void set_strAgencyCode(String _strAgentCode) {
    this._strAgentCode = _strAgentCode;
  }
  public String get_strChannelType() {
    return _strChannelType;
  }
  public void set_strChannelType(String _strChannelType) {
    this._strChannelType = _strChannelType;
  }
  public String get_strContractNbr() {
    return _strContractNbr;
  }
  public void set_strContractNbr(String _strContractNbr) {
    this._strContractNbr = _strContractNbr;
  }
  public String get_strContractType() {
    return _strContractType;
  }
  public void set_strContractType(String _strContractType) {
    this._strContractType = _strContractType;
  }
  public String get_strPKey() {
    return _strPKey;
  }
  public void set_strPKey(String _strPKey) {
    this._strPKey = _strPKey;
  }
  public String get_strStatusFlag() {
    return _strStatusFlag;
  }
  public void set_strStatusFlag(String _strStatusFlag) {
    this._strStatusFlag = _strStatusFlag;
  }
   public String get_strCDDesc()  {
	   return _strCDDesc;
	}
  public void set_strCDDesc(String _strCDDesc) {
		this._strCDDesc = _strCDDesc;
}
}
