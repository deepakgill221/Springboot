/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractProdValidate.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Commission</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.commission.dvo;

import java.io.Serializable;

public class ContractProdValidate implements Serializable
{
  protected Short _nCommBase;
  protected Short _nCommType;
  protected String _strProdCd;
  protected Integer _iProdVer;
  protected Integer _iBaseUnits;

   /**
   * Constructor
   */
   public ContractProdValidate()
   {

   }
  public Short getCommBase() {
    return _nCommBase;
  }
  public void setCommBase(Short a_nCommBase) {
    this._nCommBase = a_nCommBase;
  }
  public Short getCommType() {
    return _nCommType;
  }
  public void setCommType(Short a_nCommType) {
    this._nCommType = a_nCommType;
  }
  public Integer getBaseUnits() {
    return _iBaseUnits;
  }
  public void setBaseUnits(Integer a_iBaseUnits) {
    this._iBaseUnits = a_iBaseUnits;
  }
  public Integer getProdVer() {
    return _iProdVer;
  }
  public void setProdVer(Integer a_iProdVer) {
    this._iProdVer = a_iProdVer;
  }
  public String getProdCd() {
    return _strProdCd;
  }
  public void setProdCd(String a_strProdCd) {
    this._strProdCd = a_strProdCd;
  }
  public String toString(){
    String retValue = "";
    retValue = retValue + "_nCommBase:" + _nCommBase + "\n";
    retValue = retValue + "_nCommType:" + _nCommType + "\n";
    retValue = retValue + "_strProdCd:" + _strProdCd + "\n";
    retValue = retValue + "_iProdVer:" + _iProdVer + "\n";
    retValue = retValue + "_iBaseUnits:" + _iBaseUnits + "\n";
    return retValue;
  }
}
