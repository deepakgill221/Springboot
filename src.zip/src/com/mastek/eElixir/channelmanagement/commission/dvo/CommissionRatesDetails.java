/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: CommissionRatesDetails.java
*  AUTHOR			: Shameem
*  VERSION			: 1.0
*  CREATION DATE	: October 20, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Finder Fees Commission Rates Details</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Shameem Shaik
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.dvo;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class CommissionRatesDetails extends UserData implements Serializable
{
	
	/**
	* Finder Fees Details Seq. Num.
	*/
   protected Long _lFFDetailRSeqNbr = null;


   /**
	*  Finder Fees Defn Seq. Num.
	*/
   protected Long _lFFHDRSeqNbr = null;
   
   /**
	* Product Code
	*/
   protected String _strProductCode = null;
      protected Short _nPolYearFrom  = null;
   protected Short _nPolYearTo  = null;   
   protected Double _dRate  = null;
   protected Double _dReductionCommRate  = null;
   protected Double _dTopUpRate=null;
   protected String _strStatusFlag= null;
   
  
   public CommissionRatesDetails()
   {

   }
  

	/**
	 * @return
	 */
	public Long getFFDetailRSeqNbr() {
		return _lFFDetailRSeqNbr;
	}

	/**
	 * @return
	 */
	public Long getFFHDRSeqNbr() {
		return _lFFHDRSeqNbr;
	}
	
	/**
	 * @return
	 */
	public String getProductCode() {
		return _strProductCode;
	}
	
	/**
	 * @param long1
	 */
	public void setFFDetailRSeqNbr(Long a_lFFDetailRSeqNbr) {
		_lFFDetailRSeqNbr = a_lFFDetailRSeqNbr;
	}
	
	/**
	 * @param long1
	 */
	public void setFFHDRSeqNbr(Long a_lFFHDRSeqNbr) {
		_lFFHDRSeqNbr = a_lFFHDRSeqNbr;
	}
	
	/**
	 * @param string
	 */
	public void setProductCode(String a_strProductCode) {
		_strProductCode = a_strProductCode;
	}
	
	/**
	 * @return
	 */
	public Double getRate() {
		return _dRate;
	}

	/**
	 * @return
	 */
	public Short getPolYearFrom() {
		return _nPolYearFrom;
	}

	/**
	 * @return
	 */
	public Short getPolYearTo() {
		return _nPolYearTo;
	}

	/**
	 * @param long1
	 */
	public void setRate(Double a_dRate) {
		_dRate = a_dRate;
	}

	/**
	 * @param short1
	 */
	public void setPolYearFrom(Short a_nPolYearFrom) {
		_nPolYearFrom = a_nPolYearFrom;
	}

	/**
	 * @param short1
	 */
	public void setPolYearTo(Short a_nPolYearTo) {
		_nPolYearTo = a_nPolYearTo;
	}
	
	/**
	 * @return
	 */
	public String getStatusFlag() {
		return _strStatusFlag;
	}

	/**
	 * @param string
	 */
	public void setStatusFlag(String a_strStatusFlag) {
		_strStatusFlag = a_strStatusFlag;
	}
	
	/**
	 * @return
	 */
	public Double getReductionCommRate() {
		return _dReductionCommRate;
	}

	/**
	 * @param a_dReductionCommRate 
	 */
	public void setReductionCommRate(Double a_dReductionCommRate) {
		_dReductionCommRate = a_dReductionCommRate;
	}

	/**
		 * @return
		 */
		public Double getTopUpRate() {
			return _dTopUpRate;
		}

		/**
		 * @param a_dTopUpRate 
		 */
		public void setTopUpRate(Double a_dTopUpRate) {
			_dTopUpRate = a_dTopUpRate;
		}
	

	
	public String toString(){
	  String retValue = "";
	  retValue = retValue + "_lFFHDRSeqNbr:" + _lFFHDRSeqNbr + "\n";
	  retValue = retValue + "_lFFDetailRSeqNbr:" + _lFFDetailRSeqNbr + "\n";
	  retValue = retValue + "_strProductCode:" + _strProductCode + "\n";	  
	  retValue = retValue + "_nPolYearFrom:" + _nPolYearFrom + "\n";
	  retValue = retValue + "_nPolYearTo:" + _nPolYearTo + "\n";
	  retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";
	  retValue = retValue + "_dRate:" + _dRate + "\n";
	  retValue = retValue + "_dReductionCommRate	:" + _dReductionCommRate	+ "\n";
	  retValue = retValue + "_dTopUpRate	:" + _dTopUpRate	+ "\n";
	  
	  return retValue;
	}





}
