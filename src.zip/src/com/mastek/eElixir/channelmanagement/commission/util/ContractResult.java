package com.mastek.eElixir.channelmanagement.commission.util;

/**
 * <p>Title: eElixir</p>
 * <p>Description:This class contains the get and set methods for the Contract Fields </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class ContractResult extends UserData {

  /**
   * Attributes declaration
   */

  private String _strContractNumber = null;
  private GregorianCalendar _dtEffectiveDate = null;
  private Integer _iContractStatus = null;
  private CommissionResult _oCommissionResult = null;
  public ContractResult() {
  }

  public String getContractNumber() {
    return _strContractNumber;
  }
  public void setContractNumber(String a_strContractNumber) {
    this._strContractNumber = a_strContractNumber;
  }
  public GregorianCalendar getEffectiveDate() {
    return _dtEffectiveDate;
  }
  public void setEffectiveDate(GregorianCalendar a_dtEffectiveDate) {
    this._dtEffectiveDate = a_dtEffectiveDate;
  }

  public Integer getContractStatus() {
    return _iContractStatus;
  }
  public void setContractStatus(Integer a_iContractStatus) {
    this._iContractStatus = a_iContractStatus;
  }
  public CommissionResult getCommissionResult() {
    return _oCommissionResult;
  }
  public void setCommissionResult(CommissionResult a_oCommissionResult) {
    this._oCommissionResult = a_oCommissionResult;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_strContractNumber:" + _strContractNumber + "\n";
    retValue = retValue + "_dtEffectiveDate:" + _dtEffectiveDate + "\n";
    retValue = retValue + "_iContractStatus:" + _iContractStatus + "\n";
    retValue = retValue + "_oCommissionResult:" + _oCommissionResult + "\n";
    return retValue;
  }
}