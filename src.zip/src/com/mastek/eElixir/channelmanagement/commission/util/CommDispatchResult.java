/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME	    : CHANNEL MANAGEMENT
 *  FILENAME		: CommDispatchResult.java
 *  AUTHOR			: Amid P Sahu
 *  VERSION			: 1.0
 *  CREATION DATE   : Feb 19, 2009
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT	    : COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *									
 *
 *--------------------------------------------------------------------------------
 *Amid_Fin_156_Upload Of Commission Dispatch
 *********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for CSA/CPA</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class CommDispatchResult extends UserData implements Serializable {

	   private HashMap _hmCommDispatch;
	  // private ArrayList _alCommDispatchCriDetails;
	   protected Long _lCommDispatchSeqno = null;	
	   private  String _strModePayment = null;
	   private  String _strAccNo = null;
	   private  String _strFavourOf = null;
	   private  String _strAmtDispatch = null;
	   private String _strBankName = null;
	   private String _strModeOfDispatch = null;
	   private String _strRemarks = null;
	   private  String _strAwbNum = null;
	   private HashMap _alLocationCd = null;
	   private GregorianCalendar _dtDispatch = null;
	   
	  public CommDispatchResult()
	  {

	  }
    
	public HashMap getCommDispatch() {
		return _hmCommDispatch;
	}

	public void setCommDispatch(HashMap CommDispatch) {
		this._hmCommDispatch = CommDispatch;
	}
	

	public Long getCommDispatchSeqno() {
		return _lCommDispatchSeqno;
	}

	public void setCommDispatchSeqno(Long CommDispatchSeqno) {
		this._lCommDispatchSeqno = CommDispatchSeqno;
	}

	public String getModePayment() {
		return _strModePayment;
	}

	public void setModePayment(String modePayment) {
		this._strModePayment = modePayment;
	}

	public String getModeOfDispatch() {
		return _strModeOfDispatch;
	}

	public void setModeOfDispatch(String modeOfDispatch) {
		this._strModeOfDispatch = modeOfDispatch;
	}
	public String getAmtDispatch() {
		return _strAmtDispatch;
	}

	public void setAmtDispatch(String amtDispatch) {
		this._strAmtDispatch = amtDispatch;
	}

	public String getBankName() {
		return _strBankName;
	}

	public void setBankName(String bankName) {
		this._strBankName = bankName;
	}
	public String getRemarks() {
		return _strRemarks;
	}

	public void setRemarks(String remarks) {
		this._strRemarks = remarks;
	}

	public String getAccNo() {
		return _strAccNo;
	}

	public void setAccNo(String accNo) {
		this._strAccNo = accNo;
	}

	public String getFavourOf() {
		return _strFavourOf;
	}

	public void setFavourOf(String favourOf) {
		this._strFavourOf = favourOf;
	}

	public String getAwbNum() {
		return _strAwbNum;
	}

	public void setAwbNum(String awbNum) {
		this._strAwbNum = awbNum;
	}
	public HashMap getLocationCOde() {
		return _alLocationCd;
	}

	public void setLocationCOde(HashMap a_alLocationCd) {
		this._alLocationCd = a_alLocationCd;
	}
    public GregorianCalendar getDispatch() {
      return _dtDispatch;
    }

    public void setDispatch(GregorianCalendar _dtDispatch) {
      this._dtDispatch = _dtDispatch;
    }
	/*public ArrayList getCommDispatchCriDetails() {
		return _alCommDispatchCriDetails;
	}

	public void setCommDispatchCriDetails(ArrayList CommDispatchCriDetails) {
		this._alCommDispatchCriDetails = CommDispatchCriDetails;
	}
  */
	

}
