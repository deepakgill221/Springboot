/********************************************************************
 *
 *  PROJECT				: MAMM
 *  MODULE NAME			: CHANNEL MANAGEMENT
 *  FILENAME			: DisbursementSetupResult.java
 *  AUTHOR				: Vibhu Nigam
 *  VERSION				: 1.0
 *  CREATION DATE		: April 07, 2015
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT			: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class DisbursementSetupResult extends UserData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Default Constructor
	public DisbursementSetupResult() {

	}

	private int nPaymentMthd;
	private Double dDisbumAmntLmt;
	private String _strCreatedBy = null;
	private GregorianCalendar dtCreated = null;
	private String _strUpdatedBy = null;
	private GregorianCalendar dtUpdated = null;
	private String _strStatusFlag = null;
	private Long _strDisbumSeq = null;

	/**
	 * @return the _strDisbumSeq
	 */
	public Long getStrDisbumSeq() {
		return _strDisbumSeq;
	}

	/**
	 * @param _strDisbumSeq
	 *            the _strDisbumSeq to set
	 */
	public void setStrDisbumSeq(Long _strDisbumSeq) {
		this._strDisbumSeq = _strDisbumSeq;
	}

	/**
	 * @return the _strStatusFlag
	 */
	public String get_strStatusFlag() {
		return _strStatusFlag;
	}

	/**
	 * @param _strStatusFlag
	 *            the _strStatusFlag to set
	 */
	public void set_strStatusFlag(String _strStatusFlag) {
		this._strStatusFlag = _strStatusFlag;
	}

	/**
	 * @return the _strStatusFlag
	 */
	public String getstrStatusFlag() {
		return _strStatusFlag;
	}

	/**
	 * @param _strStatusFlag
	 *            the _strStatusFlag to set
	 */
	public void setstrStatusFlag(String _strStatusFlag) {
		this._strStatusFlag = _strStatusFlag;
	}

	/**
	 * @return the nPaymentMthd
	 */
	public int getnPaymentMthd() {
		return nPaymentMthd;
	}

	/**
	 * @param nPaymentMthd
	 *            the nPaymentMthd to set
	 */
	public void setnPaymentMthd(int nPaymentMthd) {
		this.nPaymentMthd = nPaymentMthd;
	}

	/**
	 * @return the dDisbumAmntLmt
	 */
	public Double getdDisbumAmntLmt() {
		return dDisbumAmntLmt;
	}

	/**
	 * @param dDisbumAmntLmt
	 *            the dDisbumAmntLmt to set
	 */
	public void setdDisbumAmntLmt(Double dDisbumAmntLmt) {
		this.dDisbumAmntLmt = dDisbumAmntLmt;
	}

	/**
	 * @return the _strCreatedBy
	 */
	public String get_strCreatedBy() {
		return _strCreatedBy;
	}

	/**
	 * @param _strCreatedBy
	 *            the _strCreatedBy to set
	 */
	public void set_strCreatedBy(String _strCreatedBy) {
		this._strCreatedBy = _strCreatedBy;
	}

	/**
	 * @return the dtCreated
	 */
	public GregorianCalendar getDtCreated() {
		return dtCreated;
	}

	/**
	 * @param dtCreated
	 *            the dtCreated to set
	 */
	public void setDtCreated(GregorianCalendar dtCreated) {
		this.dtCreated = dtCreated;
	}

	/**
	 * @return the _strUpdatedBy
	 */
	public String get_strUpdatedBy() {
		return _strUpdatedBy;
	}

	/**
	 * @param _strUpdatedBy
	 *            the _strUpdatedBy to set
	 */
	public void set_strUpdatedBy(String _strUpdatedBy) {
		this._strUpdatedBy = _strUpdatedBy;
	}

	/**
	 * @return the dtUpdated
	 */
	public GregorianCalendar getDtUpdated() {
		return dtUpdated;
	}

	/**
	 * @param dtUpdated
	 *            the dtUpdated to set
	 */
	public void setDtUpdated(GregorianCalendar dtUpdated) {
		this.dtUpdated = dtUpdated;
	}

}
