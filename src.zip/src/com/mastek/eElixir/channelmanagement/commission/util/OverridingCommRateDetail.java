/********************************************************************
*
*  PROJECT			: Amal
*  MODULE NAME		        : Customer Development
*  FILENAME			: OverridingCommRateDetail
*  AUTHOR			: Pallav
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 6, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for OverridingCommRate</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.commission.util;
import java.io.Serializable;
import java.sql.Timestamp;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class OverridingCommRateDetail extends UserData implements Serializable
{

  protected String _strSupDesgnCd = null;
  protected Long _lAgrmtORCSeqNbr = null;
  protected Long _lAgrmtRateSeqNbr = null;
  protected Double _dProdRangeFrom = null;
  protected Double _dProdRangeTo = null;
  protected Double _dORCRate = null;
  protected String _strStatusFlag;
  protected String _strProdDesgnCd = null;

  private Timestamp _tsDtUpdated = null;


  public OverridingCommRateDetail()
  {

  }

  public Double getORCRate() {
    return _dORCRate;
  }
  public void setORCRate(Double a_dORCRate) {
    this._dORCRate = a_dORCRate;
  }
  public Double getProdRangeFrom() {
    return _dProdRangeFrom;
  }
  public void setProdRangeFrom(Double a_dProdRangeFrom) {
    this._dProdRangeFrom = a_dProdRangeFrom;
  }
  public Double getProdRangeTo() {
    return _dProdRangeTo;
  }
  public void setProdRangeTo(Double a_dProdRangeTo) {
    this._dProdRangeTo = a_dProdRangeTo;
  }
  public Long getAgrmtORCSeqNbr() {
    return _lAgrmtORCSeqNbr;
  }
  public void setAgrmtORCSeqNbr(Long a_lAgrmtORCSeqNbr) {
    this._lAgrmtORCSeqNbr = a_lAgrmtORCSeqNbr;
  }
  public Long getAgrmtRateSeqNbr() {
    return _lAgrmtRateSeqNbr;
  }
  public void setAgrmtRateSeqNbr(Long a_lAgrmtRateSeqNbr) {
    this._lAgrmtRateSeqNbr = a_lAgrmtRateSeqNbr;
  }
  public String getSupDesgnCd() {
    return _strSupDesgnCd;
  }
  public void setSupDesgnCd(String a_strSupDesgnCd) {
    this._strSupDesgnCd = a_strSupDesgnCd;
  }

  public String getProdDesgnCd() {
    return _strProdDesgnCd;
  }
  public void setProdDesgnCd(String a_strProdDesgnCd) {
    this._strProdDesgnCd = a_strProdDesgnCd;
  }

  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }
  public Timestamp getTsDtUpdated() {
    return _tsDtUpdated;
  }
  public void setTsDtUpdated(Timestamp _tsDtUpdated) {
    this._tsDtUpdated = _tsDtUpdated;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_dORCRate:" + _dORCRate + "\n";
    retValue = retValue + "_dProdRangeFrom:" + _dProdRangeFrom + "\n";
    retValue = retValue + "_dProdRangeTo:" + _dProdRangeTo + "\n";
    retValue = retValue + "_lAgrmtORCSeqNbr:" + _lAgrmtORCSeqNbr + "\n";
    retValue = retValue + "_lAgrmtRateSeqNbr:" + _lAgrmtRateSeqNbr + "\n";
    retValue = retValue + "_strSupDesgnCd:" + _strSupDesgnCd + "\n";
    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";
    retValue = retValue + "_tsDtUpdated:" + _tsDtUpdated + "\n";
    retValue = retValue + "_strProdDesgnCd:" + _strProdDesgnCd + "\n";
    return retValue;
  }
}
