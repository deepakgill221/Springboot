/********************************************************************
*
*  PROJECT			: Amal
*  MODULE NAME		        : Customer Development
*  FILENAME			: OverridingCommRateFetch
*  AUTHOR			: Pallav
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 6, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * OverridingCommRateFetch is the Utility Class for fetching parameter for OverridingCommRate
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.util;

import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class OverridingCommRateFetch
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  //private Log log = new Log(BenefitFetch.class.getName(),Constants.CHM_MODULE);

  /**
   * Constructor of the OverridingCommRateFetch class
   */
  public OverridingCommRateFetch()
  {

  }

  /**
   * This Fetches all the paramater for OverridingCommRate except primary key
   * @param a_oRequest HttpServletRequest object.
   * @return ArrayList
   * @throws EElixirException
   */
  public ArrayList fetchOverridingCommRate(HttpServletRequest a_oRequest) {
    ArrayList arrOverridingCommRateResult = null;
    OverridingCommRateDetail oOverridingCommRateDetail = null;
    log.debug("OverridingCommRateFetch--Inside OverridingCommRate Fetch");
     HttpSession  session = a_oRequest.getSession();
     String  strUserId = (String)session.getAttribute("username");

    String[] strStatusFlag  = a_oRequest.getParameterValues("statusFlag"); //String
    String[] dProdRangeFrom  = a_oRequest.getParameterValues("dProdRangeFrom"); //String
    String[] lAgrmtRateSeqNbr = a_oRequest.getParameterValues("PKValue"); //String
    String[] dProdRangeTo   = a_oRequest.getParameterValues("dProdRangeTo"); //String
    String[] dORCRate  = a_oRequest.getParameterValues("dORCRate"); //String
    String[] strSupDesgnCd = a_oRequest.getParameterValues("strSupDesgnCd"); //String
    String lAgrmtORCSeqNbr   = a_oRequest.getParameter("strPKey"); //String
    String strProdDesgnCd = a_oRequest.getParameter("strProdDesgnCd"); //String
    String[] dtUpdated        = a_oRequest.getParameterValues("dtUpdated");

    //HttpSession session = a_oRequest.getSession();
    //String _strUserId = (String)session.getAttribute("username");

    if(strStatusFlag != null){
      for(int i = 0; i<strStatusFlag.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          arrOverridingCommRateResult = new ArrayList(10);
          break;
        }
      }
    }

    if(arrOverridingCommRateResult != null){
      for(int i = 0; i<strStatusFlag.length ; i++){
        log.debug("OverridingCommRateFetch--strStatusFlag[" + i + "].trim()" + strStatusFlag[i].trim());
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          oOverridingCommRateDetail = new OverridingCommRateDetail();
          oOverridingCommRateDetail.setAgrmtORCSeqNbr(new Long(lAgrmtORCSeqNbr));
          oOverridingCommRateDetail.setProdRangeFrom(new Double(dProdRangeFrom[i].trim()));
          oOverridingCommRateDetail.setProdRangeTo(new Double(dProdRangeTo[i].trim()));

          oOverridingCommRateDetail.setORCRate(new Double(dORCRate[i].trim()));
          oOverridingCommRateDetail.setSupDesgnCd(strSupDesgnCd[i].trim());
          oOverridingCommRateDetail.setProdDesgnCd(strProdDesgnCd.trim());

          oOverridingCommRateDetail.setStatusFlag(strStatusFlag[i]);
          oOverridingCommRateDetail.setUserId(strUserId);
          if(!lAgrmtRateSeqNbr[i].trim().equals("")){
            oOverridingCommRateDetail.setAgrmtRateSeqNbr(new Long(lAgrmtRateSeqNbr[i]));
          }
          if(dtUpdated[i] != null && ! dtUpdated[i].trim().equals("")){
            oOverridingCommRateDetail.setTsDtUpdated(Timestamp.valueOf(dtUpdated[i].trim()));
          }
          arrOverridingCommRateResult.add(oOverridingCommRateDetail);
        }
      }
    }
    return arrOverridingCommRateResult;
  }
}