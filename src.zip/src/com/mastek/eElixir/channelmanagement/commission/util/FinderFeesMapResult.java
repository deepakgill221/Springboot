/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : FINDER FEES
*  FILENAME			: FinderFeesListSearch.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: Nov 30, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;
/*
* Holds the FinderFeesMapResult Result Object
*/

public class FinderFeesMapResult extends UserData implements Serializable
{
  /**
   * @constructor
   */
  public FinderFeesMapResult()
  {

  }



   /*
	* Member Variables
	*/


   private String _strChannelType = null;   
   private Long _lFFMapSeqNbr = null;
   private Long _lUniqueMapSeqNbr = null;
   private String _strAgentCd = null;   
   private String _strAgentName = null;
   private GregorianCalendar _dtEffFrom = null;
   private String _strContractName = null;
   private GregorianCalendar _dtEffTo = null;
   private Short _nStatus = null;
   private Short _nContractType = null;
   private String _strStatusFlag = null;
   private String _strStatusDesc = null;
   private GregorianCalendar _dtFinderRuleEffFrom = null;
   
   private Long _lFFHdrSeqNbr = null;
   private Short _nIsProdSpecific = null; 
   

	/**
	 * @return
	 */
	public GregorianCalendar getEffFrom() {
		return _dtEffFrom;
	}
	
	/**
	 * @return
	 */
	public GregorianCalendar getEffTo() {
		return _dtEffTo;
	}
	
	/**
	 * @return
	 */
	public GregorianCalendar getFinderRuleEffFrom() {
		return _dtFinderRuleEffFrom;
	}
	
	/**
	 * @return
	 */
	public Long getFFMapSeqNbr() {
		return _lFFMapSeqNbr;
	}
	
	/**
	 * @return
	 */
	public Long getUniqueMapSeqNbr() {
		return _lUniqueMapSeqNbr;
	}
	
	/**
	 * @return
	 */
	public Short getContractType() {
		return _nContractType;
	}
	
	/**
	 * @return
	 */
	public Short getStatus() {
		return _nStatus;
	}
	
	/**
	 * @return
	 */
	public String getAgentCd() {
		return _strAgentCd;
	}
	
	/**
	 * @return
	 */
	public String getAgentName() {
		return _strAgentName;
	}
	
	/**
	 * @return
	 */
	public String getChannelType() {
		return _strChannelType;
	}
	
	/**
	 * @return
	 */
	public String getContractName() {
		return _strContractName;
	}
	
	/**
	 * @return
	 */
	public String getStatusDesc() {
		return _strStatusDesc;
	}
	
	/**
	 * @return
	 */
	public String getStatusFlag() {
		return _strStatusFlag;
	}
	
	/**
		 * @return
		 */
		public Long getFFHdrSeqNbr() {
			return _lFFHdrSeqNbr;
		}
	
	/**
		 * @return
		 */
		public Short getIsProdSpecific() {
			return _nIsProdSpecific;
		}
		
	/**
	 * @param calendar
	 */
	public void setEffFrom(GregorianCalendar a_dtEffFrom) {
		_dtEffFrom = a_dtEffFrom;
	}
	
	/**
	 * @param calendar
	 */
	public void setEffTo(GregorianCalendar a_dtEffTo) {
		_dtEffTo = a_dtEffTo;
	}
	
	/**
	 * @param calendar
	 */
	public void setFinderRuleEffFrom(GregorianCalendar a_dtFinderRuleEffFrom) {
		_dtFinderRuleEffFrom = a_dtFinderRuleEffFrom;
	}
	
	/**
	 * @param long1
	 */
	public void setFFMapSeqNbr(Long a_lFFMapSeqNbr) {
		_lFFMapSeqNbr = a_lFFMapSeqNbr;
	}
	
	/**
	 * @param long1
	 */
	public void setUniqueMapSeqNbr(Long a_lUniqueMapSeqNbr) {
		_lUniqueMapSeqNbr = a_lUniqueMapSeqNbr;
	}
	
	/**
	 * @param short1
	 */
	public void setContractType(Short a_nContractType) {
		_nContractType = a_nContractType;
	}
	
	/**
	 * @param short1
	 */
	public void setStatus(Short a_nStatus) {
		_nStatus = a_nStatus;
	}
	
	/**
	 * @param string
	 */
	public void setAgentCd(String a_strAgentCd) {
		_strAgentCd = a_strAgentCd;
	}
	
	/**
	 * @param string
	 */
	public void setAgentName(String a_strAgentName) {
		_strAgentName = a_strAgentName;
	}
	
	/**
	 * @param string
	 */
	public void setChannelType(String a_strChannelType) {
		_strChannelType = a_strChannelType;
	}
	
	/**
	 * @param string
	 */
	public void setContractName(String a_strContractName) {
		_strContractName = a_strContractName;
	}
	
	/**
	 * @param string
	 */
	public void setStatusDesc(String a_strStatusDesc) {
		_strStatusDesc = a_strStatusDesc;
	}
	
	/**
	 * @param string
	 */
	public void setStatusFlag(String a_strStatusFlag) {
		_strStatusFlag = a_strStatusFlag;
	}
	
	/**
	* @return
	 */
	public void setFFHdrSeqNbr(Long a_lFFHdrSeqNbr) {
		_lFFHdrSeqNbr=a_lFFHdrSeqNbr;
	}
	
	/**
	 * @return
	 */
	public void setIsProdSpecific(Short a_nIsProdSpecific) {
		 _nIsProdSpecific = a_nIsProdSpecific;
	}
	
	
	
	public String toString()
	 {
		String retValue = "";
		
		retValue = retValue + "_strChannelType	:" + _strChannelType + "\n";
		retValue = retValue + "_lFFMapSeqNbr	:" + _lFFMapSeqNbr + "\n";
		retValue = retValue + "_lUniqueMapSeqNbr:" + _lUniqueMapSeqNbr + "\n";
		retValue = retValue + "_strAgentCd		:" + _strAgentCd + "\n";
		retValue = retValue + "_strAgentName	:" + _strAgentName + "\n";
		retValue = retValue + "_dtEffFrom		:" + _dtEffFrom + "\n";
		retValue = retValue + "_strContractName	:" + _strContractName + "\n";
		retValue = retValue + "_dtEffTo			:" + _dtEffTo + "\n";
		retValue = retValue + "_nStatus			:" + _nStatus + "\n";
		retValue = retValue + "_nContractType	:" + _nContractType + "\n";
		retValue = retValue + "_strStatusFlag	:" + _strStatusFlag + "\n";
		retValue = retValue + "_strStatusDesc	:" + _strStatusDesc + "\n";
		retValue = retValue + "_dtFinderRuleEffFrom:" + _dtFinderRuleEffFrom + "\n";		 
		retValue = retValue + "_lFFHdrSeqNbr	:" + _lFFHdrSeqNbr + "\n";
		retValue = retValue + "_nIsProdSpecific	:" + _nIsProdSpecific + "\n";
		
		return retValue;
	   }		

}

