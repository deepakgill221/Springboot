/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: BenefitResult.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Benefit Result</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class FinderFeesResult extends UserData implements Serializable{
   
   
		/**
		* Sequence Number
		*/
	   protected Long _lFFHDRSeqNbr = null;

	   /**
		* Contract / Rule Name
		*/
	   protected String _strContractName = null;

	   /**
		* Trnascation Type
		*/
	   protected Short _nTransType = null;

	   /**
		* Effective From Date
		*/
	   protected GregorianCalendar _dtEffFrom = null;
	   
		/**
		* Product Specific 
		*/
	   protected Short _nIsProdSpecific = null;
	   
		/**
		* Status
		*/
	   protected Short _nStatus = null;
	   
		/**
		* Status
		*/
		protected Short _nBasis = null;
	   
		/**
		* Status
		*/
		protected ArrayList _alCommRatesDetails= null;
	   
		/**
		* UpdCommRatesFlag is used to know the boolean values to update the Update the Commission Rates. 
		*/
		protected String _strUpdCommRatesFlag = null;
		
		/**
			* Status
			*/
		protected ArrayList _alProductCodes= null;
		
		protected String _strIsFromSave=null;
	
		protected Timestamp _tsDtUpdated=null;
	   
		private HashMap _hBonusProductTypes=null;

		/**
		 * @return
		 */
		public Long getFFHDRSeqNbr() {
			return _lFFHDRSeqNbr;
		}

		/**
		 * @return
		 */
		public Short getIsProdSpecific() {
			return _nIsProdSpecific;
		}

		/**
		 * @return
		 */
		public Short getStatus() {
			return _nStatus;
		}

		/**
		 * @return
		 */
		public Short getTransType() {
			return _nTransType;
		}
	
		/**
		 * @return
		 */
		public String getContractName() {
			return _strContractName;
		}
		
		/**
		 * @return ArrayList containing the Commission Rates Details
		 */
		public ArrayList getCommRatesDetails() {
			return _alCommRatesDetails;
		}
		
		/**
		 * @return
		*/
		public GregorianCalendar getEffFrom() {
				return _dtEffFrom;
		}
	
		/**
		 * @param long1
		 */
		public void setFFHDRSeqNbr(Long a_lFFHDRSeqNbr) {
			_lFFHDRSeqNbr = a_lFFHDRSeqNbr;
		}
	
		/**
		 * @param short1
		 */
		public void setIsProdSpecific(Short a_nIsProdSpecific) {
			_nIsProdSpecific = a_nIsProdSpecific;
		}
	
		/**
		 * @param short1
		 */
		public void setStatus(Short a_nStatus) {
			_nStatus = a_nStatus;
		}
	
		/**
		 * @param short1
		 */
		public void setTransType(Short a_nTransType) {
			_nTransType = a_nTransType;
		}
	
		/**
		 * @param string
		 */
		public void setContractName(String a_strContractName) {
			_strContractName = a_strContractName;
		}
		
		/**
		 * @param calendar
		 */
		public void setEffFrom(GregorianCalendar a_dtEffFrom) {
			_dtEffFrom = a_dtEffFrom;
		}
		
		public void setCommRatesDetails(ArrayList a_alCommRatesDetails) {
			_alCommRatesDetails = a_alCommRatesDetails;
		}
		
		/**
		 * @return
		*/
		public String getUpdCommRatesFlag() {
			return _strUpdCommRatesFlag;
		}

		/**
		 * @param short1
		*/
		public void setUpdCommRatesFlag(String a_strUpdCommRatesFlag) {
			_strUpdCommRatesFlag = a_strUpdCommRatesFlag ;
		}
		
		/**
		 * @return
		 */
		public ArrayList getProductCodes() {
			return _alProductCodes;
		}
	
		/**
		 * @param list
		 */
		public void setProductCodes(ArrayList a_alProductCodes) {
			_alProductCodes = a_alProductCodes;
		}
		
		/**
		 * @return
		 */
		public String getIsFromSave() {
			return _strIsFromSave;
		}

		/**
		 * @param string
		 */
		public void setIsFromSave(String a_strIsFromSave) {
			_strIsFromSave = a_strIsFromSave;
		}

	   public Timestamp getTsDtUpdated()
	   {
		 return this._tsDtUpdated;
	   }
	   public void setTsDtUpdated(Timestamp _tsDtUpdated)
	   {
		 this._tsDtUpdated = _tsDtUpdated;
	   }
	
			/**
		 * @return
		 */
		public Short getBasis() {
			return _nBasis;
		}

		/**
		 * @param a_nBasis
		 */
		public void setBasis(Short a_nBasis) {
			_nBasis = a_nBasis;
		}

	/**
		*Sets BonusProducts Types
		*@param a_hBonusProductTypes Hashtable
		*/

		public void setBonusProductTypes (HashMap a_hBonusProductTypes)
		{
			_hBonusProductTypes=a_hBonusProductTypes;
	
		}

		/**
		*gets BonusProducts Types
		*@return Hashtable
		*/

		public HashMap getBonusProductTypes ()
		{
			return _hBonusProductTypes;
	
		}

		public String toString(){
		  String retValue = "";
		  retValue = retValue + "_lFFHDRSeqNbr:" + _lFFHDRSeqNbr + "\n";
		  retValue = retValue + "_strContractName:" + _strContractName + "\n";
		  retValue = retValue + "_nTransType:" + _nTransType + "\n";
		  retValue = retValue + "_dtEffFrom:" + _dtEffFrom + "\n";
		  retValue = retValue + "_nIsProdSpecific:" + _nIsProdSpecific + "\n";
		  retValue = retValue + "_nStatus:" + _nStatus + "\n";	
		  retValue = retValue + "_alCommRatesDetails:" + _alCommRatesDetails + "\n";
		  retValue = retValue + "_alProductCodes:" + _alProductCodes + "\n";
		  retValue = retValue + "_strIsFromSave:" + _strIsFromSave + "\n";
		  retValue = retValue + "_tsDtUpdated:" + _tsDtUpdated + "\n";
		  retValue = retValue + "_nBasis:" + _nBasis + "\n";
		
		
		  return retValue;
		}		

		
		

}
