/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : PolicyAckSL.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_policy_ackn_upd.doc.doc
*  CREATION DATE                  : 29/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;


public class PolicyAckResult extends UserData implements Serializable
{
    private String _strServAgentCd = null;
    private String _strPolNbr = null;
    private GregorianCalendar _dtPolIssue = null;
    private GregorianCalendar _dtPolAckn = null;
    private GregorianCalendar _dtPolAcknReceipt = null;
    private String _strPolicyHolderName = null;
    private Short _nTerm = null;
    private Short _nIsPolAcknProcess = null;
    private Double _dsa = null;
    private Double _dPrmAmnt = null;
    private String _nStatus = null;
    private Short _nAckDays = null;
    private String _strStatusFlag = null;


    public PolicyAckResult()
    {
    }

    /** State of object
     *   @return State of the object instance
     */
    public String toString()
    {
        return "_strServAgentCd : " + _strServAgentCd + "_strPolNbr : " +
        _strPolNbr + "_dtPolIssue : " + _dtPolIssue + "strPolicyHolderName : " +
        _strPolicyHolderName + "_nTerm : " + _nTerm + "_dsa : " + _dsa +
        "dPrmAmnt : " + _dPrmAmnt + " _nStatus  : " + _nStatus +
        " _nSelfContIndcr : " + " strStatusFlag : " + _strStatusFlag;
    }

    /**
     * Gets the Premium Amount
    * @return
    */
    public Double getPrmAmnt()
    {
        return _dPrmAmnt;
    }

    /**
    * Gets the SA Amt
    * @return
    */
    public Double getSa()
    {
        return _dsa;
    }

    /**
        * Gets the POlicy Issue Date
    * @return
    */
    public GregorianCalendar getPolIssue()
    {
        return _dtPolIssue;
    }

    /**
        * Gets the POlicy Issue Date
    * @return
    */
    public GregorianCalendar getPolAckn()
    {
        return _dtPolAckn;
    }

    /**
    * Gets the Acknowledgement Receipt Date
    * @return GregorianCalendar
    */
    public GregorianCalendar getPolAcknReceipt()
    {
        return _dtPolAcknReceipt;
    }

    /**
     * Get the Days
     * @return
     */
    public Short getAckDays()
    {
        return _nAckDays;
    }

    /**
     * Gets the Status
    * @return String
    */
    public String getStatus()
    {
        return _nStatus;
    }

    /**
     * Gets the Term
    * @return Short
    */
    public Short getTerm()
    {
        return _nTerm;
    }

    /**
     * Get the Status of The Clawback Process
    * @return Short
    */
    public Short getPolAcknProcess()
    {
        return _nIsPolAcknProcess;
    }

    /**
     * Get the Policy Holder Name
    * @return String
    */
    public String getPolicyHolderName()
    {
        return _strPolicyHolderName;
    }

    /**
     * Gets the Policy Number
    * @return String
    */
    public String getPolNbr()
    {
        return _strPolNbr;
    }

    /**
     * Get the Agent Code
     * @return String
     */
    public String getServAgentCd()
    {
        return _strServAgentCd;
    }

    /**
     * Sets the Agent Code
    * @param a_strServAgentCd
    */
    public void setServAgentCd(String a_strServAgentCd)
    {
        this._strServAgentCd = a_strServAgentCd;
    }

    /**
     * Sets the Policy Numebr
    * @param a_strPolNbr
    */
    public void setPolNbr(String a_strPolNbr)
    {
        this._strPolNbr = a_strPolNbr;
    }

    /**
     * Set the Policy Holder Name
    * @param a_strPolicyHolderName
    */
    public void setPolicyHolderName(String a_strPolicyHolderName)
    {
        this._strPolicyHolderName = a_strPolicyHolderName;
    }

    /**
     * Set the Term
    * @param a_nTerm
    */
    public void setTerm(Short a_nTerm)
    {
        this._nTerm = a_nTerm;
    }

    /**
     * Set the Acknowledgement Days
    * @param a_nAckDays
    */
    public void setAckDays(Short a_nAckDays)
    {
        this._nAckDays = a_nAckDays;
    }

    /**
     * Set the Acknowledgement Process Flag
    * @param a_nIsPolAcknProcess
    */
    public void setPolAcknProcess(Short a_nIsPolAcknProcess)
    {
        this._nIsPolAcknProcess = a_nIsPolAcknProcess;
    }

    /**
     * Set the Status
    * @param a_nStatus
    */
    public void setStatus(String a_nStatus)
    {
        this._nStatus = a_nStatus;
    }

    /**
     * Sets the Policy Issue Date
    * @param a_dtPolIssue
    */
    public void setPolIssue(GregorianCalendar a_dtPolIssue)
    {
        this._dtPolIssue = a_dtPolIssue;
    }

    /**
     * Sets the Policy Acknowledgement Date
    * @param a_dtPolAckn
    */
    public void setPolAckn(GregorianCalendar a_dtPolAckn)
    {
        this._dtPolAckn = a_dtPolAckn;
    }

    /**
    * Sets the Policy Acknowledgement Receipt Date
    * @param a_dtPolAcknReceipt
    */
    public void setPolAcknReceipt(GregorianCalendar a_dtPolAcknReceipt)
    {
        this._dtPolAcknReceipt = a_dtPolAcknReceipt;
    }

    /**
    * Sets the Sum Assured
    * @param a_dsa
    */
    public void setSa(Double a_dsa)
    {
        this._dsa = a_dsa;
    }

    /**
        * Sets the Premium Amount
    * @param a_dPrmAmnt
    */
    public void setPrmAmnt(Double a_dPrmAmnt)
    {
        this._dPrmAmnt = a_dPrmAmnt;
    }

    /**
        * Sets the Status Flag
    * @return String
    */
    public String getStatusFlag()
    {
        return _strStatusFlag;
    }

    /**
    * @param _strStatusFlag
    */
    public void setStatusFlag(String a_strStatusFlag)
    {
        this._strStatusFlag = a_strStatusFlag;
    }
}
