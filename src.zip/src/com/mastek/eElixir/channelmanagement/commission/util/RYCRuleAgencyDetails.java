/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleDesgDetails.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: October 29, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Benefit Result</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Mastek Ltd</p>
 * @author Srikanth Kolluri
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.commission.util;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class RYCRuleAgencyDetails extends UserData
{

    /**
     * Constructor for ApplicabilityDetails
     */
    public RYCRuleAgencyDetails()
    {
    }

	/**
	 * @return
	 */
	public Long getRYCAgencySeqNbr() {
		return _lRYCSeqNbr;
	}


	/**
	 * @return
	 */
	public Short getRYCAgency() {
		return _strRYCAgency;
	}

	/**
	 * @return
	 */
	public String getStatusFlag() {
		return _strStatusFlag;
	}

	/**
	 * @param a_lBonusDesgnSeqNbr
	 */
	public void setRYCAgencySeqNbr(Long a_lRYCSeqNbr) {
		_lRYCSeqNbr = a_lRYCSeqNbr;
	}

	/**
	 * @param string
	 */
	public void setRYCAgency(Short a_strRYCAgency) {
		_strRYCAgency = a_strRYCAgency;
	}

	/**
	 * @param string
	 */
	public void setStatusFlag(String a_strStatusFlag) {
		_strStatusFlag = a_strStatusFlag;
	}

	/**
	 * prints the Object
	 * @return String
	 */
	public String toString()
	{
		String retValue = "RYCRuleDesgDetails :: _lRYCSeqNbr : " + _lRYCSeqNbr +
			"\n _strRYCAgency : " + _strRYCAgency +
			"\n_strStatusFlag : " + _strStatusFlag;

		return retValue;
	}

	/**
	 * Member Variables Declaration
	 */
	protected Long _lRYCSeqNbr	= null;
	protected Short _strRYCAgency 	= null;
	protected String _strStatusFlag 		= null;


}
