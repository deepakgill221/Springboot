/********************************************************************
 *
 *  PROJECT			: PRUDENTIAL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME			: CommissionResult.java
 *  AUTHOR			: Pallav Laddha
 *  VERSION			: 1.0
 *  CREATION DATE	        : September 20, 2002
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *1.1             16Jan2003         Pallav            added payment Mode
 *1.2             23Jan2003         Pallav            added Term Type
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:This class contains the get and set methods for the StandardCommission Fields </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.commission.util;

import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.util.UserData;

public class CommissionResult extends UserData {
	protected Long _lComAgreementKey;
	protected Short _nCommBase;
	// added code for nPmtMode
	protected Short _nPmtMode;
	// added code for nTermType
	protected Short _nTermType;
	protected Short _nCommType;
	protected String _strCommClass;
	protected String _strProdCd;
	protected String _strBaseProdCd;
	protected Integer _iProdVer;
	protected Integer _iBaseProdVer;
	protected String _strCampaignCd;
	protected Integer _iBaseUnits;
	protected Short _nPlanType;
	protected Short _nBasePlanType;
	protected Short _nCommBandCd;// Arun_RatchetedComm_Rel8.3_Phase2
	// protected String _strDistribType;
	protected CommissionDetails[] _arrCommissionDetail;
	protected ClawBackDetails[] _arrClawBackDetail;
	protected Short _nIndexCommYrType;// Anup_Indexation_Changes_Jan_Release_v1.2

	// Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic
	// v1.1- Start
	protected String _nApplyMultiplier;
	protected String _nCompareMultiplierWith;
	protected String _nApplyMultiplierOn;
	protected Float _nMultiplierOf;
	protected Float _nCommMultiplierDtls;
	
	//new fields added as per ver 1.4
	protected String nCommMultpWtFlag;
	protected Float  nCommMultiplierWt;
	protected String nCommMultpWtFlagComp;
	protected Float  nIfWtCommMultiplier;
	protected Float  nRedWtCommMultiplierBy;
	protected Float  nIfWtCommMultiplierLt;
	protected Float  nThenApplyWtOf;

	public String getnCommMultpWtFlag() {
		return nCommMultpWtFlag;
	}

	public void setnCommMultpWtFlag(String nCommMultpWtFlag) {
		this.nCommMultpWtFlag = nCommMultpWtFlag;
	}

	public Float getnCommMultiplierWt() {
		return nCommMultiplierWt;
	}

	public void setnCommMultiplierWt(Float nCommMultiplierWt) {
		this.nCommMultiplierWt = nCommMultiplierWt;
	}

	public String getnCommMultpWtFlagComp() {
		return nCommMultpWtFlagComp;
	}

	public void setnCommMultpWtFlagComp(String nCommMultpWtFlagComp) {
		this.nCommMultpWtFlagComp = nCommMultpWtFlagComp;
	}

	public Float getnIfWtCommMultiplier() {
		return nIfWtCommMultiplier;
	}

	public void setnIfWtCommMultiplier(Float nIfWtCommMultiplier) {
		this.nIfWtCommMultiplier = nIfWtCommMultiplier;
	}

	public Float getnRedWtCommMultiplierBy() {
		return nRedWtCommMultiplierBy;
	}

	public void setnRedWtCommMultiplierBy(Float nRedWtCommMultiplierBy) {
		this.nRedWtCommMultiplierBy = nRedWtCommMultiplierBy;
	}

	public Float getnIfWtCommMultiplierLt() {
		return nIfWtCommMultiplierLt;
	}

	public void setnIfWtCommMultiplierLt(Float nIfWtCommMultiplierLt) {
		this.nIfWtCommMultiplierLt = nIfWtCommMultiplierLt;
	}

	public Float getnThenApplyWtOf() {
		return nThenApplyWtOf;
	}

	public void setnThenApplyWtOf(Float nThenApplyWtOf) {
		this.nThenApplyWtOf = nThenApplyWtOf;
	}

	public String get_nApplyMultiplier() {
		return _nApplyMultiplier;
	}

	public void set_nApplyMultiplier(String nApplyMultiplier) {
		_nApplyMultiplier = nApplyMultiplier;
	}

	public String get_nCompareMultiplierWith() {
		return _nCompareMultiplierWith;
	}

	public void set_nCompareMultiplierWith(String nCompareMultiplierWith) {
		_nCompareMultiplierWith = nCompareMultiplierWith;
	}

	public String get_nApplyMultiplierOn() {
		return _nApplyMultiplierOn;
	}

	public void set_nApplyMultiplierOn(String nApplyMultiplierOn) {
		_nApplyMultiplierOn = nApplyMultiplierOn;
	}
	
	public Float get_nMultiplierOf() {
		return _nMultiplierOf;
	}

	public void set_nMultiplierOf(Float nMultiplierOf) {
		_nMultiplierOf = nMultiplierOf;
	}

	public Float get_nCommMultiplierDtls() {
		return _nCommMultiplierDtls;
	}

	public void set_nCommMultiplierDtls(Float nCommMultiplierDtls) {
		_nCommMultiplierDtls = nCommMultiplierDtls;
	}
	// Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1- Ends


	/**
	 * Constructor
	 */
	public CommissionResult() {

	}

	public Short getBasePlanType() {
		return this._nBasePlanType;
	}

	public void setBasePlanType(Short a_nBasePlanType) {
		this._nBasePlanType = a_nBasePlanType;
	}

	public Short getPlanType() {
		return this._nPlanType;
	}

	public void setPlanType(Short a_nPlanType) {
		this._nPlanType = a_nPlanType;
	}

	public Integer getBaseProdVer() {
		return _iBaseProdVer;
	}

	public void setBaseProdVer(Integer a_iBaseProdVer) {
		this._iBaseProdVer = a_iBaseProdVer;
	}

	public String getCommClass() {
		return _strCommClass;
	}

	public void setCommClass(String a_strCommClass) {
		this._strCommClass = a_strCommClass;
	}

	public Integer getBaseUnits() {
		return _iBaseUnits;
	}

	public void setBaseUnits(Integer a_iBaseUnits) {
		this._iBaseUnits = a_iBaseUnits;
	}

	public Long getComAgreementKey() {
		return _lComAgreementKey;
	}

	public void setComAgreementKey(Long a_lComAgreementKey) {
		this._lComAgreementKey = a_lComAgreementKey;
	}

	public Short getCommBase() {
		return _nCommBase;
	}

	public void setCommBase(Short a_nCommBase) {
		this._nCommBase = a_nCommBase;
	}

	public Short getCommType() {
		return _nCommType;
	}

	public void setCommType(Short a_nCommType) {
		this._nCommType = a_nCommType;
	}

	public Short getPmtMode() {
		return _nPmtMode;
	}

	public void setPmtMode(Short a_nPmtMode) {
		this._nPmtMode = a_nPmtMode;
	}

	public Short getTermType() {
		return _nTermType;
	}

	public void setTermType(Short a_nTermType) {
		this._nTermType = a_nTermType;
	}

	/*
	 * public String getDistribType() { return _strDistribType; } public void
	 * setDistribType(String a_strDistribType) { this._strDistribType =
	 * a_strDistribType; }
	 */
	public String getCampaignCd() {
		return _strCampaignCd;
	}

	public void setCampaignCd(String a_strCampaignCd) {
		this._strCampaignCd = a_strCampaignCd;
	}

	public String getProdCd() {
		return _strProdCd;
	}

	public void setProdCd(String a_strProdCd) {
		this._strProdCd = a_strProdCd;
	}

	public String getBaseProdCd() {
		return _strBaseProdCd;
	}

	public void setBaseProdCd(String a_strBaseProdCd) {
		this._strBaseProdCd = a_strBaseProdCd;
	}

	public Integer getProdVer() {
		return _iProdVer;
	}

	public void setProdVer(Integer a_iProdVer) {
		this._iProdVer = a_iProdVer;
	}

	// Arun_RatchetedComm_Rel8.3_Phase2_Start _nCommBandCd
	public Short getCommBandCd() {
		return _nCommBandCd;
	}

	public void setCommBandCd(Short a_nCommBandCd) {
		this._nCommBandCd = a_nCommBandCd;
	}

	// Arun_RatchetedComm_Rel8.3_Phase2_End
	public CommissionDetails[] getCommissionDetail() {
		return _arrCommissionDetail;
	}

	public void setCommissionDetail(CommissionDetails[] a_arrCommissionDetail) {
		this._arrCommissionDetail = a_arrCommissionDetail;
	}

	public ClawBackDetails[] getClawBackDetail() {
		return _arrClawBackDetail;
	}

	public void setClawBackDetail(ClawBackDetails[] a_arrClawBackDetail) {
		this._arrClawBackDetail = a_arrClawBackDetail;
	}

	public String toString() {
		String retValue = "";
		retValue = retValue + "_olComAgreementKey:" + _lComAgreementKey + "\n";
		retValue = retValue + "_nCommBase:" + _nCommBase + "\n";
		retValue = retValue + "_nPmtMode:" + _nPmtMode + "\n";
		retValue = retValue + "_nTermType:" + _nTermType + "\n";
		retValue = retValue + "_nCommType:" + _nCommType + "\n";
		retValue = retValue + "_strCommClass:" + _strCommClass + "\n";
		retValue = retValue + "_strProdCd:" + _strProdCd + "\n";
		retValue = retValue + "_strBaseProdCd:" + _strBaseProdCd + "\n";
		retValue = retValue + "_oiProdVer:" + _iProdVer + "\n";

		retValue = retValue + "_strCampaignCd:" + _strCampaignCd + "\n";
		retValue = retValue + "_oiBaseUnits:" + _iBaseUnits + "\n";
		retValue = retValue + "_arrCommissionDetail[]:" + _arrCommissionDetail
				+ "\n";
		retValue = retValue + "_arrClawBackDetail[]:" + _arrClawBackDetail
				+ "\n";

		return retValue;
	}

	// Anup_Indexation_Changes_Jan_Release_v1.2_Starts
	public Short getIndexCommYrType() {
		return _nIndexCommYrType;
	}

	public void setIndexCommYrType(Short indexCommYrType) {
		_nIndexCommYrType = indexCommYrType;
	}
	// Anup_Indexation_Changes_Jan_Release_v1.2_Ends
}
