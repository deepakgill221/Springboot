/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: CommissionValidator.java
*  AUTHOR			: Sandeep Bangera
*  VERSION			: 1.0
*  CREATION DATE	: April 15, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Validates the standard commission in order to remove the validation from the client side 
 * 
 * Copyright (c) 2002 Mastek Ltd
 * Date       15/04/2003
 * @author    Sandeep Bangera
 * @version 1.0
 */
 
package com.mastek.eElixir.channelmanagement.commission.util;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class CommissionValidator
{
	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
	
	public CommissionValidator()
	{
	}
	
	public void validateCommission(CommissionDetails[] a_arrCommissionDetail, Short a_nCommBase) throws EElixirException
	{
		CommissionDetails iCommissionDetails = null;
		CommissionDetails jCommissionDetails = null;
		log.debug("CommissionValidator : validateCommission starts ");
		if (a_arrCommissionDetail != null)
		{
			for(int i=0;i<a_arrCommissionDetail.length;i++)
			{
				for(int j=0;j<a_arrCommissionDetail.length;j++)
				{
					if (i != j)
					{
						iCommissionDetails = a_arrCommissionDetail[i];
						jCommissionDetails = a_arrCommissionDetail[j];
						log.debug("CommissionValidator : i result stauts " + iCommissionDetails.getStatusFlag() + "  j result status" + jCommissionDetails.getStatusFlag());
						if (iCommissionDetails.getStatusFlag().equalsIgnoreCase(DataConstants.DELETE_MODE)){
						  break;
						}
						if (jCommissionDetails.getStatusFlag().equalsIgnoreCase(DataConstants.DELETE_MODE)){
						  continue;
						}
						if (iCommissionDetails.getStatusFlag().equalsIgnoreCase(DataConstants.UPDATE_MODE) || iCommissionDetails.getStatusFlag().equalsIgnoreCase(DataConstants.INSERT_MODE) || jCommissionDetails.getStatusFlag().equalsIgnoreCase(DataConstants.UPDATE_MODE) || jCommissionDetails.getStatusFlag().equalsIgnoreCase(DataConstants.INSERT_MODE))
						{
							log.debug("CommissionValidator : comparision between " + iCommissionDetails + "\n" + jCommissionDetails);
							//check for product term
							if (iCommissionDetails.getTermFrom().intValue() >= jCommissionDetails.getTermFrom().intValue() && iCommissionDetails.getTermFrom().intValue() <= jCommissionDetails.getTermTo().intValue())
							{
							}
							else if (!(iCommissionDetails.getTermTo().intValue() >= jCommissionDetails.getTermFrom().intValue() && iCommissionDetails.getTermTo().intValue() <= jCommissionDetails.getTermTo().intValue()))
							{
								continue;
							}
							//Added by Aradhana FIN1107 12_oct_2017:START
							// Check for PPT
							if (iCommissionDetails.getPptFrom().intValue() >= jCommissionDetails.getPptFrom().intValue() && iCommissionDetails.getPptFrom().intValue() <= jCommissionDetails.getPptTo().intValue())
							{
							}
							else if (!(iCommissionDetails.getPptTo().intValue() >= jCommissionDetails.getPptFrom().intValue() && iCommissionDetails.getPptTo().intValue() <= jCommissionDetails.getPptTo().intValue()))
							{
								continue;
							}
							//Added by Aradhana FIN1107 12_oct_2017:END
							// Check for Entry Age
							if (iCommissionDetails.getEntryAgeFrom().intValue() >= jCommissionDetails.getEntryAgeFrom().intValue() && iCommissionDetails.getEntryAgeFrom().intValue() <= jCommissionDetails.getEntryAgeTo().intValue())
							{
							}
							else if (!(iCommissionDetails.getEntryAgeTo().intValue() >= jCommissionDetails.getEntryAgeFrom().intValue() && iCommissionDetails.getEntryAgeTo().intValue() <= jCommissionDetails.getEntryAgeTo().intValue()))
							{
								continue;
							}
							// Check for Mat Age
							if (iCommissionDetails.getMatAgeFrom().intValue() >= jCommissionDetails.getMatAgeFrom().intValue() && iCommissionDetails.getMatAgeFrom().intValue() <= jCommissionDetails.getMatAgeTo().intValue())
							{
							}
							else if (!(iCommissionDetails.getMatAgeTo().intValue() >= jCommissionDetails.getMatAgeFrom().intValue() && iCommissionDetails.getMatAgeTo().intValue() <= jCommissionDetails.getMatAgeTo().intValue()))
							{
								continue;
							}
							// Check for Nbr Of Lives
							if (iCommissionDetails.getNbrOfLivesFrom().intValue() >= jCommissionDetails.getNbrOfLivesFrom().intValue() && iCommissionDetails.getNbrOfLivesFrom().intValue() <= jCommissionDetails.getNbrOfLivesTo().intValue())
							{
							}
							else if (!(iCommissionDetails.getNbrOfLivesTo().intValue() >= jCommissionDetails.getNbrOfLivesFrom().intValue() && iCommissionDetails.getNbrOfLivesTo().intValue() <= jCommissionDetails.getNbrOfLivesTo().intValue()))
							{
								continue;
							}

							// Check for SA Range
							if(a_nCommBase.shortValue() == DataConstants.PREMIUM_AND_SA){
								if (iCommissionDetails.getSAFrom().doubleValue() >= jCommissionDetails.getSAFrom().doubleValue() && iCommissionDetails.getSAFrom().doubleValue() <= jCommissionDetails.getSATo().doubleValue())
								{
								}
								else if (!(iCommissionDetails.getSATo().doubleValue() >= jCommissionDetails.getSAFrom().doubleValue() && iCommissionDetails.getSATo().doubleValue() <= jCommissionDetails.getSATo().doubleValue()))
								{
									continue;
								}
							}
							// Check for Basis Range
							if (iCommissionDetails.getBaseValeFrom().doubleValue() >= jCommissionDetails.getBaseValeFrom().doubleValue() && iCommissionDetails.getBaseValeFrom().doubleValue() <= jCommissionDetails.getBaseValeTo().doubleValue())
							{
							}
							else if (!(iCommissionDetails.getBaseValeTo().doubleValue() >= jCommissionDetails.getBaseValeFrom().doubleValue() && iCommissionDetails.getBaseValeTo().doubleValue() <= jCommissionDetails.getBaseValeTo().doubleValue()))
							{
								continue;
							}
							// Check for Policy Year
							if (iCommissionDetails.getPolYearFrom().intValue() >= jCommissionDetails.getPolYearFrom().intValue() && iCommissionDetails.getPolYearFrom().intValue() <= jCommissionDetails.getPolYearTo().intValue())
							{
							}
							else if (!(iCommissionDetails.getPolYearTo().intValue() >= jCommissionDetails.getPolYearFrom().intValue() && iCommissionDetails.getPolYearTo().intValue() <= jCommissionDetails.getPolYearTo().intValue()))
							{
								continue;
							}
							int temprow = i + 1;
							int temprow2 =j + 1;
							throw new EElixirException("p3050"," " + temprow + "," + temprow2, false);
						}
						else
						{
							log.debug("CommissionValidator : no comparision  for " + i + "  " + j);
						}				
						
					}
				}	
			}
		}
	}
} 