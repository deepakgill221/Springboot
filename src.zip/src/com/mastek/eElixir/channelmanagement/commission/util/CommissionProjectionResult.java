/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionProjectionResult.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : Jan 20, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:This class contains the get and set methods for the CommissionProjection Fields </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class CommissionProjectionResult extends UserData implements Serializable{
   protected Long _lComProjSeqNbr;
   protected String _strAgentCd;
   protected String _strAgentName;
   protected Integer _iCalYear;
   protected Short _nCalMonth;
   protected String _strProdCd;
   protected Integer _iProdVer;
   protected String _strCommClass;
   protected Short _nPmtMode;
   protected Short _nTerm;
   protected Short _nEntryAge;
   protected Short _nNbrOfLives;
   protected Short _nNbrOfPol;
   protected Double _dPrmAmt;
   protected Double _dSA;
   protected Short _nTermType;



   /**
    * Constructor
    */
   public CommissionProjectionResult()
   {

   }
  public String getCommClass() {
    return _strCommClass;
  }
  public void setCommClass(String a_strCommClass) {
    this._strCommClass = a_strCommClass;
  }

  public Short getPmtMode() {
    return _nPmtMode;
  }
  public void setPmtMode(Short a_nPmtMode) {
    this._nPmtMode = a_nPmtMode;
  }

  public String getProdCd() {
    return _strProdCd;
  }
  public void setProdCd(String a_strProdCd) {
    this._strProdCd = a_strProdCd;
  }
  public Integer getProdVer() {
    return _iProdVer;
  }
  public void setProdVer(Integer a_iProdVer) {
    this._iProdVer = a_iProdVer;
  }

  public Double getSA() {
    return _dSA;
  }
  public void setSA(Double a_dSA) {
    this._dSA = a_dSA;
  }
  public Long getComProjSeqNbr() {
    return _lComProjSeqNbr;
  }
  public void setComProjSeqNbr(Long a_lComProjSeqNbr) {
    this._lComProjSeqNbr = a_lComProjSeqNbr;
  }
  public Short getEntryAge() {
    return _nEntryAge;
  }
  public void setEntryAge(Short a_nEntryAge) {
    this._nEntryAge = a_nEntryAge;
  }
  public Short getNbrOfLives() {
    return _nNbrOfLives;
  }
  public void setNbrOfLives(Short a_nNbrOfLives) {
    this._nNbrOfLives = a_nNbrOfLives;
  }
  public Short getNbrOfPol() {
    return _nNbrOfPol;
  }
  public void setNbrOfPol(Short a_nNbrOfPol) {
    this._nNbrOfPol = a_nNbrOfPol;
  }
  public Double getPrmAmt() {
    return _dPrmAmt;
  }
  public void setPrmAmt(Double a_dPrmAmt) {
    this._dPrmAmt = a_dPrmAmt;
  }
  public Short getTerm() {
    return _nTerm;
  }
  public void setTerm(Short a_nTerm) {
    this._nTerm = a_nTerm;
  }
  public String getAgentCd() {
    return _strAgentCd;
  }
  public void setAgentCd(String a_strAgentCd) {
    this._strAgentCd = a_strAgentCd;
  }
  public String getAgentName() {
    return _strAgentName;
  }
  public void setAgentName(String a_strAgentName) {
    this._strAgentName = a_strAgentName;
  }
  public Short getCalMonth() {
    return _nCalMonth;
  }
  public void setCalMonth(Short a_nCalMonth) {
    this._nCalMonth = a_nCalMonth;
  }
  public Integer getCalYear() {
    return _iCalYear;
  }
  public void setCalYear(Integer a_iCalYear) {
    this._iCalYear = a_iCalYear;
  }

  public Short getTermType() {
    return _nTermType;
  }
  public void setTermType(Short a_nTermType) {
    this._nTermType = a_nTermType;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_lComProjSeqNbr:" + _lComProjSeqNbr + "\n";
    retValue = retValue + "_strAgentCd:" + _strAgentCd + "\n";
    retValue = retValue + "_strAgentName:" + _strAgentName + "\n";
    retValue = retValue + "_nPmtMode:" + _nPmtMode + "\n";

    retValue = retValue + "_strCommClass:" + _strCommClass + "\n";
    retValue = retValue + "_strProdCd:" + _strProdCd + "\n";
    retValue = retValue + "_oiProdVer:" + _iProdVer + "\n";

    retValue = retValue + "_iCalYear:" + _iCalYear + "\n";
    retValue = retValue + "_nCalMonth:" + _nCalMonth + "\n";
    retValue = retValue + "_nTerm:" + _nTerm + "\n";
    retValue = retValue + "_nEntryAge:" + _nEntryAge + "\n";
    retValue = retValue + "_nNbrOfLives:" + _nNbrOfLives + "\n";
    retValue = retValue + "_nNbrOfPol:" + _nNbrOfPol + "\n";
    retValue = retValue + "_dPrmAmt:" + _dPrmAmt + "\n";
    retValue = retValue + "_dSA:" + _dSA + "\n";
    retValue = retValue + "_nTermType:" + _nTermType + "\n";
    return retValue;
  }

}
