/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: FindeFeesFetch.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------

*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;


public class FinderFeesFetch
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the BenefitFetch class
   */
  public FinderFeesFetch()
  {

  }


  /**
   * This Fetches all the paramater for finder fees except primary key
   * @param a_oRequest HttpServletRequest object.
   * @return FinderFeesResult
   * @throws EElixirException
   */
  public FinderFeesResult fetchFinderFees(HttpServletRequest a_oRequest) {
	FinderFeesResult oFinderFeesResult = null;
	HttpSession session = a_oRequest.getSession();
	
	log.debug("FinderFeesFetch--Inside FinderFees Fetch");
	
	log.debug("spot 1 	:"+(String)session.getAttribute("username"));
	log.debug("spot 2 	:"+a_oRequest.getParameter("lFFHdrSeqNbr"));	
	log.debug("spot 3 	:"+a_oRequest.getParameter("strContractName"));
	log.debug("spot 4	:"+a_oRequest.getParameter("dtEffFrom"));
	log.debug("spot 5	:"+a_oRequest.getParameter("nStatus"));
	log.debug("spot 6	:"+a_oRequest.getParameter("nBasis"));
	log.debug("spot 7	:"+a_oRequest.getParameter("nIsProductSpecific"));
	log.debug("spot 8	:"+a_oRequest.getParameter("UpdCommRatesFlag"));	
	log.debug("spot 9	:"+a_oRequest.getParameter("IsFromSaveFlag"));
	log.debug("spot 10	:"+a_oRequest.getParameter("dtUpdated"));

	
	String _strUserId = (String)session.getAttribute("username");
		
	String dtUpdated = a_oRequest.getParameter("dtUpdated");
	log.debug("DT Updated "+ dtUpdated);
	
	String strContractName 		= a_oRequest.getParameter("strContractName").trim();
	Long lFFHDRSeqNbr=null;
	
	if(a_oRequest.getParameter("lFFHdrSeqNbr")!=null 
			&& !a_oRequest.getParameter("lFFHdrSeqNbr").trim().equals("")
				&& a_oRequest.getParameter("actiontype").equalsIgnoreCase(DataConstants.ACTION_UPDATE))
	{
			log.debug("seting Seq Nbr.............");
			lFFHDRSeqNbr	= new Long(a_oRequest.getParameter("lFFHdrSeqNbr").trim());
	}
	 
	
	GregorianCalendar dtEffFrom = DateUtil.retGCDate(a_oRequest.getParameter("dtEffFrom").trim());
	Short nStatus=null;
	if(a_oRequest.getParameter("nStatus")!= null && !a_oRequest.getParameter("nStatus").equals(""))
	{
		StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nStatus"),"|");
		nStatus = new Short(st.nextToken());					
	}
	
	Short nBasis=null;
	if(a_oRequest.getParameter("nBasis")!= null && !a_oRequest.getParameter("nBasis").equals(""))
	{
		nBasis	= new Short(a_oRequest.getParameter("nBasis").trim());
	}	
	
	// if null and new/updating record to create/update - default status is pending.
	log.debug("actiontype	:"+a_oRequest.getParameter("actiontype"));	
	
	if(nStatus==null && 
		a_oRequest.getParameter("actiontype").equalsIgnoreCase(DataConstants.ACTION_CREATE))
			//|| a_oRequest.getParameter("actiontype").equalsIgnoreCase(DataConstants.ACTION_UPDATE))
	{	
		nStatus=new Short(String.valueOf(DataConstants.STATUS_PENDING_ID));
	}	
	
	Short nIsProductSpecific=null;
	if(a_oRequest.getParameter("nIsProductSpecific")!= null && !a_oRequest.getParameter("nIsProductSpecific").equals(""))
	{
		nIsProductSpecific	= new Short(a_oRequest.getParameter("nIsProductSpecific").trim());
	}
	
	String strUpdCommRatesFlag = null;
	if(a_oRequest.getParameter("UpdCommRatesFlag")!= null && !a_oRequest.getParameter("UpdCommRatesFlag").equals(""))
	{
		strUpdCommRatesFlag = a_oRequest.getParameter("UpdCommRatesFlag");
	}		
	
	String strIsFromSaveFlag =null;
	if(a_oRequest.getParameter("IsFromSaveFlag")!= null && !a_oRequest.getParameter("IsFromSaveFlag").equals(""))
		{
			strIsFromSaveFlag = a_oRequest.getParameter("IsFromSaveFlag");
		}
		else
		{			
			strIsFromSaveFlag="Yes";
		}
	
		
	// This code is for capture values for deleting Finder Fees Product.
	String[] arrStatusFlag  = a_oRequest.getParameterValues("statusFlag");
	String[] arrProductCode = a_oRequest.getParameterValues("cProductCode");
	ArrayList alProductCodes=new ArrayList();
	
	if(arrStatusFlag!=null && arrProductCode!=null)
	{
	
		int iSize=arrStatusFlag.length;
		log.debug("arrStatusFlag.length :"+arrStatusFlag.length);
		log.debug("arrStatusFlag :"+arrStatusFlag.toString());
		log.debug("arrProductCode :"+arrProductCode.toString());
		log.debug("arrProductCode.length :"+arrProductCode.length);	
		
		if(iSize!=0)
		{	
			for(int i=0;i<iSize;i++)
			{	
				if(arrStatusFlag[i]!=null && arrStatusFlag[i].equalsIgnoreCase("D"))	
				{
					String sProdCode=arrProductCode[i];
					log.debug("arrProductCode[i] :"+sProdCode);				
					if(sProdCode!=null)
					{				
						log.debug("prod code stored :"+alProductCodes.add((String)sProdCode));
					}
				}	
			}
		}
		
		log.debug("alProductCodes :"+alProductCodes.size());
		
	}

	//Long lFormlDefnSeqNbr		= null;	
		

	oFinderFeesResult = new FinderFeesResult();
	
	if(a_oRequest.getParameter("lFFHdrSeqNbr")!=null 
				&& !a_oRequest.getParameter("lFFHdrSeqNbr").trim().equals("")
					&& a_oRequest.getParameter("actiontype").equalsIgnoreCase(DataConstants.ACTION_UPDATE))
	{
		log.debug("seting isDirty and Seq Nbr.............");
		oFinderFeesResult.setFFHDRSeqNbr(lFFHDRSeqNbr);
		//oFinderFeesResult.setIsDirty(DataConstants.UPDATE_MODE);
	}
	oFinderFeesResult.setContractName(strContractName);
	oFinderFeesResult.setEffFrom(dtEffFrom);
	oFinderFeesResult.setStatus(nStatus);
	oFinderFeesResult.setBasis(nBasis);
	oFinderFeesResult.setIsProdSpecific(nIsProductSpecific);
	oFinderFeesResult.setUserId(_strUserId);	
	oFinderFeesResult.setUpdCommRatesFlag(strUpdCommRatesFlag);
	oFinderFeesResult.setIsFromSave(strIsFromSaveFlag);
	
	if(arrStatusFlag!=null && arrProductCode!=null)
	{
		oFinderFeesResult.setProductCodes(alProductCodes);
	}	
	if(dtUpdated != null && !dtUpdated.trim().equals(""))
	{
		log.debug("DT Updated "+ dtUpdated);
		oFinderFeesResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated));
	 }
	
	log.debug("FinderFeesFetch--After fetching data -> oFinderFeesResult :"+oFinderFeesResult);
	
	return oFinderFeesResult;
  }


}