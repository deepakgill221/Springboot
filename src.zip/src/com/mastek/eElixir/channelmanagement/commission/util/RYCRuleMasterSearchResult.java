/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterSearchResult.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: October 29, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Benefit Result</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Mastek Ltd</p>
 * @author Srikanth Kolluri
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class RYCRuleMasterSearchResult extends UserData implements Serializable{
   
   
		/**
		* Sequence Number
		*/
	   protected Long _lFFHDRSeqNbr = null;

	   /**
		* Contract / Rule Name
		*/
	   protected String _strRYCRule = null;

	   /**
		* Trnascation Type
		*/
	   protected Short _nStatus = null;

	   /**
		* Effective From Date
		*/
	   protected GregorianCalendar _dtEffFrom = null;

		/**
		* Effective To Date
		*/

   	   protected GregorianCalendar _dtEffTo = null;


	  protected Timestamp _tsDtUpdated=null;
	   
		/**
		* Product Specific 
		*/
//Changed By Narendra to convert from Long to double to take Sum Assured
	   protected Double _dSumAssumed = null;


	   /**
		* Product Specific 
		*/
	   protected String _nChannelType = null;
	   
	   
		/**
		* period of years
		*/
	   protected Short _nPeriod = null;
	   
		/**
		* Start Year
		*/
		protected Short _nStartYear = null;
	   
		/**
		* End year
		*/

		protected Short _nEndYear = null;

		/**
		*Commission
		*/

		protected Short _nCommission = null;

		protected Short	_nInEx=null;

//Narendra CTS for RYC rule master details as part of to AGN-09 starts
		protected ArrayList _alRYCAgencyCodes= null;

		protected String _nRuleLevel = null;

//Narendra CTS for RYC rule master details as part of to AGN-09 ends
		protected ArrayList _alRYCDesgnCodes= null;

				
		protected ArrayList _alRYCPolicyCodes= null;
		
		protected double _aldRycRate;




		/**
		 * @return
		 */
		public Long getFFHDRSeqNbr() {
			return _lFFHDRSeqNbr;
		}

		/**
		 * @return
		 */
		public String getRYCRule() {
			return _strRYCRule;
		}

		/**
		 * @return
		 */
		public Short getStatus() {
			return _nStatus;
		}


		/**
		 * @return
		*/
		public GregorianCalendar getEffFrom() {
				return _dtEffFrom;
		}


		/**
		 * @return
		*/
		public GregorianCalendar getEffTo() {
				return _dtEffTo;
		}

		/**
		 * @return
		 */
//Changed By Narendra to convert from Long to double to take Sum Assured
		public Double getSumAssumed() {
			return _dSumAssumed;
		}


		/**
		 * @return
		 */
		public Short getPeriod() {
			return _nPeriod;
		}

		/**
		 * @return
		 */
		public Short getStartYear() {
			return _nStartYear;
		}

		/**
		 * @return
		 */
		public Short getEndYear() {
			return _nEndYear;
		}


		/**
		 * @return
		 */
		public Short getCommission() {
			return _nCommission;
		}


		/**
		 * @return
		 */
		public String getChannelType() {
			return _nChannelType;
		}


	   public Timestamp getTsDtUpdated()
	   {
		 return this._tsDtUpdated;
	   }
	   public void setTsDtUpdated(Timestamp _tsDtUpdated)
	   {
		 this._tsDtUpdated = _tsDtUpdated;
	   }

	   /**
		 * @return
		 */
		public ArrayList getRYCRuleDesgDetails() {
			return _alRYCDesgnCodes;
		}
	
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
		/**
		 * @return
		 */
		public ArrayList getRYCRuleAgencyDetails() {
			return _alRYCAgencyCodes;
		}


		/**
		 * @param list
		 */
		public void setRYCRuleAgencyDetails(ArrayList a_alRYCAgencyCodes) {
			_alRYCAgencyCodes = a_alRYCAgencyCodes;
		}


// Narendra CTS for RYC rule master details as part of to AGN-09 ends
		/**
		 * @param list
		 */
		public void setRYCRuleDesgDetails(ArrayList a_alRYCDesgnCodes) {
			_alRYCDesgnCodes = a_alRYCDesgnCodes;
		}

		 /**
		 * @return
		 */
		public ArrayList getRYCRulePolicyDetails() {
			return _alRYCPolicyCodes;
		}
	
		/**
		 * @param list
		 */
		public void setRYCRulePolicyDetails(ArrayList a_alRYCPolicyCodes) {
			_alRYCPolicyCodes = a_alRYCPolicyCodes;
		}
		
		


	
	
		/**
		 * @param long1
		 */
		public void setFFHDRSeqNbr(Long a_lFFHDRSeqNbr) {
			_lFFHDRSeqNbr = a_lFFHDRSeqNbr;
		}
	
		/**
		 * @param short1
		 */
		public void setRYCRule(String a_strRYCRule){
			_strRYCRule = a_strRYCRule;
		}


		/**
		 * @param short1
		 */
		public void setChannelType(String a_nChannelType){
			_nChannelType = a_nChannelType;
		}
	
		/**
		 * @param short1
		 */
		public void setStatus(Short a_nStatus) {
			_nStatus = a_nStatus;
		}


		public void setInExValue(Short a_nInEx) {
			_nInEx = a_nInEx;
		}


		public Short getInExValue()
		{
			return _nInEx;
		}





		public void setEffFrom(GregorianCalendar a_dtEffFrom) {
			_dtEffFrom = a_dtEffFrom;
		}


		public void setEffto(GregorianCalendar a_dtEffTo) {
			_dtEffTo = a_dtEffTo;
		}

//Changed By Narendra to convert from Long to double to take Sum Assured
		public void setSumAssumed(Double a_dSumAssumed)
		{
			_dSumAssumed=a_dSumAssumed;
		}

		public void setPeriod(Short a_nPeriod)
		{
			_nPeriod=a_nPeriod;
		}

		public void setStartYear(Short a_nStartYear)
		{
			_nStartYear=a_nStartYear;
		}
		public void setEndYear(Short a_nEndYear)
		{
			_nEndYear=a_nEndYear;
		}
		public void setCommission(Short a_nCommission)
		{
			_nCommission=a_nCommission;
		}
		
		public void setRycRate(double _dRycRate)
		{
			_aldRycRate=_dRycRate;
		}
		
		public double getRycRate()
		{
			return _aldRycRate;
		}
			
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
		public String getRuleLevel() {
			return _nRuleLevel;
		}

		public void setRuleLevel(String a_nRuleLevel)
		{
			_nRuleLevel=a_nRuleLevel;
		}
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
		public String toString(){
		  String retValue = "";
		  retValue = retValue + "_lFFHDRSeqNbr:" +_lFFHDRSeqNbr + "\n";
		  retValue = retValue + "_strRYCRule:" +_strRYCRule + "\n";
		  retValue = retValue + "_nStatus:" +_nStatus + "\n";
		  retValue = retValue + "_dtEffFrom:" +_dtEffFrom + "\n";
		  retValue = retValue + "_dtEffTo:" + _dtEffTo + "\n";
		  retValue = retValue + "_nSumAssumed:" +_dSumAssumed + "\n";
		  retValue = retValue + "_nPeriod:" +_nPeriod + "\n";
		  retValue = retValue + "_nStartYear:" +_nStartYear + "\n";
		  retValue = retValue + "_nEndYear:" +_nEndYear + "\n";
		  retValue = retValue + "_nCommission:" +_nCommission + "\n";
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
		  retValue = retValue + "_nRuleLevel:" +_nRuleLevel + "\n";
//Narendra CTS for RYC rule master details as part of to AGN-09 ends

		  return retValue;
		}		

		
		

}
