/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: OverrideCommRuleResult.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE	: September 09, 2009
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.
*  CODE TAG 		: Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for Override Commision rule </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Anup
 * @version 1.0
 */

// code done by pallav for Ashwini according to the way done by Prasad.

package com.mastek.eElixir.channelmanagement.commission.util;
import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class OverrideCommRuleResult extends UserData implements Serializable
{

   private HashMap _hmOverrideCommChannel;

  //Vinaysheel's variables
   private  String _cChannelType = null;
   private  String _strStatusFlag = null;
   private  String _strAgencyCode = null;
   private  String _strProdCode = null;
   private GregorianCalendar _dtEffFrom = null;
   private GregorianCalendar _dtEffTo = null;
   private Long _lCommRuleOverSeqNbr = null;
   private String _strAgencyName = null;

  public OverrideCommRuleResult()
  {

  }

  public HashMap getSubChannel() {
    return _hmOverrideCommChannel;
  }

  public void setSubChannel(HashMap a_hmOverrideCommChannel) {
    this._hmOverrideCommChannel = a_hmOverrideCommChannel;
  }

  public String getChannelType() {
    return _cChannelType;
  }
  public void setChannelType(String _cChannelType) {
    this._cChannelType = _cChannelType;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String _strStatusFlag) {
    this._strStatusFlag = _strStatusFlag;
  }
  

  public String toString(){
    String retValue = "ChannelType : " + _cChannelType + " _lCommRuleOverSeqNbr : " + _lCommRuleOverSeqNbr +
					  " StatusFlag : " + _strStatusFlag ;
    retValue = retValue + "_hmOverrideCommChannel:" + _hmOverrideCommChannel + "\n";
    return retValue;
  }

public GregorianCalendar getEffFrom() {
	return _dtEffFrom;
}

public void setEffFrom(GregorianCalendar effFrom) {
	_dtEffFrom = effFrom;
}

public GregorianCalendar getEffTo() {
	return _dtEffTo;
}

public void setEffTo(GregorianCalendar effTo) {
	_dtEffTo = effTo;
}

public Long getCommRuleOverSeqNbr() {
	return _lCommRuleOverSeqNbr;
}

public void setCommRuleOverSeqNbr(Long commRuleOverSeqNbr) {
	_lCommRuleOverSeqNbr = commRuleOverSeqNbr;
}

public String getAgencyCode() {
	return _strAgencyCode;
}

public void setAgencyCode(String agencyCode) {
	_strAgencyCode = agencyCode;
}

public String getProdCode() {
	return _strProdCode;
}

public void setProdCode(String prodCode) {
	_strProdCode = prodCode;
}

public String getAgencyName() {
	return _strAgencyName;
}

public void setAgencyName(String agencyName) {
	_strAgencyName = agencyName;
}


}
