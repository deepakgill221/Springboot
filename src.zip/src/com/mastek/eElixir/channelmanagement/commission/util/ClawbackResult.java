/********************************************************************
 *
 *  PROJECT					: PRUDENTIAL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME					: ClawbackResult
 *  AUTHOR					: VINAYSHEEL BABER
 *  VERSION					: 1.0
 *  CREATION DATE		: October 13, 2002
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT			: COPYRIGHT (C) 2002.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;


public class ClawbackResult extends UserData implements Serializable
{
   protected String _strServAgentCd = null;
   protected String _strPolNbr = null;
   protected GregorianCalendar _dtPolIssue = null;
   protected String _strPolicyHolderName = null;
   protected Short _nTerm = null;
   protected Double _dsa = null;
   protected Double _dPrmAmnt = null;
   protected String _nStatus = null;
   protected Short _nClawbackIndcr = null;
   protected String _strStatusFlag = null;



   /**
    * @roseuid 3DC0A71801E2
    */
   public ClawbackResult()
   {

   }


    /** State of object
     *   @return State of the object instance
     */
    public String toString () {
        return 	"_strServAgentCd : " + _strServAgentCd + "_strPolNbr : " + _strPolNbr + "_dtPolIssue : " + _dtPolIssue +
            "strPolicyHolderName : " + _strPolicyHolderName + "_nTerm : " + _nTerm  + "_dsa : " + _dsa +
        "dPrmAmnt : " + _dPrmAmnt +
        " _nStatus  : " + _nStatus + " _nClawbackIndcr : " + _nClawbackIndcr + " strStatusFlag : " + _strStatusFlag ;
    }


  public Double getPrmAmnt() {
    return _dPrmAmnt;
  }
  public Double getSa() {
    return _dsa;
  }
  public GregorianCalendar getPolIssue() {
    return _dtPolIssue;
  }

  public String getStatus() {
    return _nStatus;
  }
  public Short getTerm() {
    return _nTerm;
  }
  public String getPolicyHolderName() {
    return _strPolicyHolderName;
  }
  public String getPolNbr() {
    return _strPolNbr;
  }
  public String getServAgentCd() {
    return _strServAgentCd;
  }
  public void setServAgentCd(String _strServAgentCd) {
    this._strServAgentCd = _strServAgentCd;
  }
  public void setPolNbr(String _strPolNbr) {
    this._strPolNbr = _strPolNbr;
  }
  public void setPolicyHolderName(String _strPolicyHolderName) {
    this._strPolicyHolderName = _strPolicyHolderName;
  }
  public void setTerm(Short _nTerm) {
    this._nTerm = _nTerm;
  }
  public void setStatus(String _nStatus) {
    this._nStatus = _nStatus;
  }

  public void setPolIssue(GregorianCalendar _dtPolIssue) {
    this._dtPolIssue = _dtPolIssue;
  }
  public void setSa(Double _dsa) {
    this._dsa = _dsa;
  }
  public void setPrmAmnt(Double _dPrmAmnt) {
    this._dPrmAmnt = _dPrmAmnt;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String _strStatusFlag) {
    this._strStatusFlag = _strStatusFlag;
  }
  public Short getClawbackIndcr() {
    return _nClawbackIndcr;
  }
  public void setClawbackIndcr(Short _nClawbackIndcr) {
    this._nClawbackIndcr = _nClawbackIndcr;
  }


}
