/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractCopy.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 16, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.util;

/**
 * <p>Title: eElixir</p>
 * <p>Description:This class contains the get and set methods for the Contract Copy Fields </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class ContractCopyResult extends UserData {

  /**
   * Attributes declaration
   */

  private String _strContractNumber = null;
  private GregorianCalendar _dtEffectiveDate = null;
  private String _strApprovedContractNumber = null;
  private String _strYesNo = null;

  public ContractCopyResult() {
  }

  public String getContractNumber() {
    return _strContractNumber;
  }
  public void setContractNumber(String a_strContractNumber) {
    this._strContractNumber = a_strContractNumber;
  }
  public GregorianCalendar getEffectiveDate() {
    return _dtEffectiveDate;
  }
  public void setEffectiveDate(GregorianCalendar a_dtEffectiveDate) {
    this._dtEffectiveDate = a_dtEffectiveDate;
  }

  public String getApprovedContractNumber() {
    return _strApprovedContractNumber;
  }
  public void setApprovedContractNumber(String a_strApprovedContractNumber) {
    this._strApprovedContractNumber = a_strApprovedContractNumber;
  }
  public String getYesNo() {
    return _strYesNo;
  }
  public void setYesNo(String a_strYesNo) {
    this._strYesNo = a_strYesNo;
  }
  public String toString(){
    String retValue = "";
    retValue = retValue + "_strContractNumber:" + _strContractNumber + "\n";
    retValue = retValue + "_dtEffectiveDate:" + _dtEffectiveDate + "\n";
    retValue = retValue + "_strApprovedContractNumber:" + _strApprovedContractNumber + "\n";
    retValue = retValue + "_strYesNo:" + _strYesNo + "\n";
    return retValue;
  }
}