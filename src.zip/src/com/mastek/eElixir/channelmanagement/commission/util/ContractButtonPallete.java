/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractButtonPallete.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : Nov 12, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * ContractButtonPallete is the Util Class for deciding the button pallette
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.util;
import com.mastek.eElixir.channelmanagement.util.ButtonPallete;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
public class ContractButtonPallete
{
    private static ContractButtonPallete _oCButtonSingleton;
    private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

    private ContractButtonPallete()
    {
      log.debug("Fired ContractButtonPallete");
    }


 /**
  * returns singleton instance of CHMDAXFactory
  * @return CHMDAXFactory
  */
public static  ContractButtonPallete getInstance()
  {
    if (ContractButtonPallete._oCButtonSingleton == null)
       ContractButtonPallete._oCButtonSingleton  = new ContractButtonPallete();
    return ContractButtonPallete._oCButtonSingleton;
  }


    /**
    * Business consitions to set /reset buttons
    * @return ContractResult
    * @param a_oContractResult ContractResult
    */

    public ContractResult applyButtons(ContractResult a_oContractResult)
    {

      log.debug("ContractResult-applyButtons-Start"  );
      log.debug("ContractResult-applyButtons- Result Object is " +  a_oContractResult );
      ButtonPallete oButtonPallete = new ButtonPallete();
      log.debug("ContractResult-applyButtons- Creating Button Pallete instance " +  oButtonPallete );
            if(a_oContractResult.isNewInstance()){
              log.debug("ContractResult-inside newInstance" );
              oButtonPallete.setSubmit(true);
              oButtonPallete.setCancel(true);
            }
            else if ((a_oContractResult.getContractStatus().intValue() == DataConstants.STATUS_APPROVED_ID) || (a_oContractResult.getContractStatus().intValue() == DataConstants.STATUS_REJECTED_ID)){
              log.debug("ContractResult-inside else if" );
              oButtonPallete.setSubmit(false);
              oButtonPallete.setCancel(true);
              oButtonPallete.setApprove(true);
              oButtonPallete.setCopy(false);
            }
            else {
              log.debug("ContractResult-inside else part" );
              oButtonPallete.setSubmit(true);
              oButtonPallete.setCancel(true);
              oButtonPallete.setApprove(true);
              oButtonPallete.setCopy(true);
            }
            a_oContractResult.setButtonPallete(oButtonPallete);
      log.debug("ContractResult-applyButtons- Returninig ResultObject " +  a_oContractResult );
      log.debug("ButtonPallete-applyButtons- Returninig ResultObject " +  oButtonPallete );
            return a_oContractResult;
    }

}

