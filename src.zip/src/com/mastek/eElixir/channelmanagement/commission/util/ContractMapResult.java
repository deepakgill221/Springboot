/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMapResult.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 2.1       10/9/2003     Dipti F		UT Rework
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;
/*
* Holds the ContractMap Result Object
*/

public class ContractMapResult extends UserData implements Serializable
{
  /**
   * @constructor
   */
  public ContractMapResult()
  {

  }

   /*
    * Member Variables
    */
   private String _strCChannelType = null;
   //private String _strSubChannelType = null;
   private Long _lContMapSeqNbr = null;
   private Long _lUniqueMapSeqNbr = null;
   private String _strAgentCd = null;
   private String _strAgentName = null;
   private GregorianCalendar _dtEffFrom = null;
   private String _strContractNbr = null;
   private GregorianCalendar _dtEffTo = null;
   private Short _nStatus = null;
   private Short _nContractType = null;
   private String _strStatusFlag = null;
   private String _strStatusDesc = null;
   private GregorianCalendar contractDtEffFrom = null;
   private GregorianCalendar dtUpdated = null;


   public String toString()
   {
     return _strCChannelType + ":::" + _lContMapSeqNbr +  ":::" + _strAgentCd +  ":::" + "_strAgentName" + _strAgentName
             + ":::"+ _dtEffFrom +
          ":::" + _strContractNbr + ":::" +  _dtEffTo + ":::" +  _nStatus +  ":::" + _nContractType +
         ":::" + _strStatusFlag + ":::" + _strStatusDesc + ":::::" + _lUniqueMapSeqNbr + ":::";
   }
  public GregorianCalendar getContractDtEffFrom()
  {
    return this.contractDtEffFrom;
  }
  public void setContractDtEffFrom(GregorianCalendar _contractDtEffFrom)
  {
    this.contractDtEffFrom = _contractDtEffFrom;
  }
  public Long getUniqueMapSeqNbr()
  {
	  return _lUniqueMapSeqNbr;
  }
  public void setUniqueMapSeqNbr(Long a_lUniqueMapSeqNbr)
  {
	  this._lUniqueMapSeqNbr = a_lUniqueMapSeqNbr;
  }
  public GregorianCalendar getEffFrom() {
    return _dtEffFrom;
  }
  public GregorianCalendar getEffTo() {
    return _dtEffTo;
  }
  public Long getContMapSeqNbr() {
    return _lContMapSeqNbr;
  }
  public Short getContractType() {
    return _nContractType;
  }
  public Short getStatus() {
    return _nStatus;
  }
  public String getAgentCd() {
    return _strAgentCd;
  }
  public String getChannelType() {
    return _strCChannelType;
  }
  public String getContractNbr() {
    return _strContractNbr;
  }
  public void setContractNbr(String _strContractNbr) {
    this._strContractNbr = _strContractNbr;
  }
  public void setChannelType(String _strCChannelType) {
    this._strCChannelType = _strCChannelType;
  }
  public void setAgentCd(String _strAgentCd) {
    this._strAgentCd = _strAgentCd;
  }
  public void setStatus(Short _nStatus) {
    this._nStatus = _nStatus;
  }
  public void setContractType(Short _nContractType) {
    this._nContractType = _nContractType;
  }
  public void setContMapSeqNbr(Long _lContMapSeqNbr) {
    this._lContMapSeqNbr = _lContMapSeqNbr;
  }
  public void setEffTo(GregorianCalendar _dtEffTo) {
    this._dtEffTo = _dtEffTo;
  }
  public void setEffFrom(GregorianCalendar _dtEffFrom) {
    this._dtEffFrom = _dtEffFrom;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String _strStatusFlag) {
    this._strStatusFlag = _strStatusFlag;
  }
  public String getStatusDesc() {
    return _strStatusDesc;
  }
  public void setStatusDesc(String _strStatusDesc) {
    this._strStatusDesc = _strStatusDesc;
  }
    public String getAgentName() {
        return _strAgentName;
    }
    public void setAgentName(String _strAgentName) {
        this._strAgentName = _strAgentName;
    }
	public GregorianCalendar getDtUpdated() {
			return dtUpdated;
	}
	public void setDtUpdated(GregorianCalendar calendar) {
			dtUpdated = calendar;
	}
/*
   public void setSubChannelType(String _strSubChannelType)
   {
      this._strSubChannelType = _strSubChannelType;
   }
   public String getSubChannelType()
   {
      return this._strSubChannelType;
   }
*/

}

