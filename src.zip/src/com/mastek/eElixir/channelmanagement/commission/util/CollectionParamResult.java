/********************************************************************
 *
 *  PROJECT				: MAMM
 *  MODULE NAME			: CHANNEL MANAGEMENT
 *  FILENAME			: CollectionParamResult.java
 *  AUTHOR				: Varun Kathariya
 *  VERSION				: 1.0
 *  CREATION DATE		: May 23, 2014
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT			: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.util;

import java.io.Serializable;
import java.sql.Date;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;

// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2
public class CollectionParamResult extends UserData implements Serializable {

	// Default Constructor
	public CollectionParamResult() {

	}

	private String _strCollectionParamFlag = null;
	private Short _nStatus = null;
	private Short _nOldStatus = null;
	private Date dtBonusBatchRun = null;
	private Short _nOverideBonusProcessed = null;
	private String _strDtUpdated = null;
	private GregorianCalendar dtBusiness = null;
	private String _strCreatedBy = null;
	private GregorianCalendar dtCreated = null;
	private String _strUpdatedBy = null;
	private Short _nIsActive = null;

	public Short get_nOldStatus() {
		return _nOldStatus;
	}

	public void set_nOldStatus(Short nOldStatus) {
		_nOldStatus = nOldStatus;
	}

	public Short get_nIsActive() {
		return _nIsActive;
	}

	public void set_nIsActive(Short nIsActive) {
		_nIsActive = nIsActive;
	}

	public String get_strCollectionParamFlag() {
		return _strCollectionParamFlag;
	}

	public void set_strCollectionParamFlag(String strCollectionParamFlag) {
		_strCollectionParamFlag = strCollectionParamFlag;
	}

	public Short get_nStatus() {
		return _nStatus;
	}

	public void set_nStatus(Short nStatus) {
		_nStatus = nStatus;
	}

	public Date getDtBonusBatchRun() {
		return dtBonusBatchRun;
	}

	public void setDtBonusBatchRun(Date date) {
		this.dtBonusBatchRun = date;
	}

	public Short get_nOverideBonusProcessed() {
		return _nOverideBonusProcessed;
	}

	public void set_nOverideBonusProcessed(Short nOverideBonusProcessed) {
		_nOverideBonusProcessed = nOverideBonusProcessed;
	}

	public String get_strDtUpdated() {
		return _strDtUpdated;
	}

	public void set_strDtUpdated(String strDtUpdated) {
		_strDtUpdated = strDtUpdated;
	}

	public GregorianCalendar getDtBusiness() {
		return dtBusiness;
	}

	public void setDtBusiness(GregorianCalendar dtBusiness) {
		this.dtBusiness = dtBusiness;
	}

	public String get_strCreatedBy() {
		return _strCreatedBy;
	}

	public void set_strCreatedBy(String strCreatedBy) {
		_strCreatedBy = strCreatedBy;
	}

	public GregorianCalendar getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(GregorianCalendar dtCreated) {
		this.dtCreated = dtCreated;
	}

	public String get_strUpdatedBy() {
		return _strUpdatedBy;
	}

	public void set_strUpdatedBy(String strUpdatedBy) {
		_strUpdatedBy = strUpdatedBy;
	}

	@Override
	public String toString() {
		return "nStatus:" + _nStatus + " - " + "dtBonusBatchRun:"
				+ dtBonusBatchRun + " - nOverideBonusProcessed:" + _nOverideBonusProcessed + " - DtUpdated:"
				+ _strDtUpdated + " - UpdatedBy" + _strUpdatedBy + " - OldStatus:"+ _nOldStatus + " - _nIsActive:" + _nIsActive;
	}

}
