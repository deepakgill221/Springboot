/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionProjectionFetch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : Jan 21, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * CommissionProjectionFetch is the Utility Class for fetching parameter for CommissionProjection
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.util;

import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class CommissionProjectionFetch
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the CommissionProjectionFetch class
   */
  public CommissionProjectionFetch()
  {

  }

  /**
   * This Fetches all the paramater for CommissionProjection except primary key
   * @param a_oRequest HttpServletRequest object.
   * @return CommissionProjectionResult
   * @throws EElixirException
   */
  public CommissionProjectionResult fetchCommissionProjection(HttpServletRequest a_oRequest) {
    CommissionProjectionResult oCommissionProjectionResult = null;
    log.debug("CommissionProjectionFetch--Inside CommissionProjectionFetch Fetch");
    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");

    String strAgentCd       = a_oRequest.getParameter("strAgentCd");
    String strAgentName       = a_oRequest.getParameter("strAgentName");
    Integer iCalYear          = new Integer(a_oRequest.getParameter("iCalYear"));
    Short nCalMonth         = new Short(a_oRequest.getParameter("nCalMonth"));

    // Product is stored as Product Code | Product Version. It is seperated with a pipe character.
    // It has to be tokenized to get both the value.
    String strProdCdVer        = a_oRequest.getParameter("strProdCdVer");
    StringTokenizer st = new StringTokenizer(strProdCdVer,"|");
    String strProdCd = null;
    String strProdVer = null;
    while(st.hasMoreTokens()){
      strProdCd = (String)st.nextElement();
      break;
    }
    while(st.hasMoreTokens()){
      strProdVer = (String)st.nextElement();
    }
    Integer iProdVer = null;
    if(strProdVer != null){
      iProdVer = new Integer(strProdVer);
    }

    String strCommClass     = a_oRequest.getParameter("strCommClass");
    Short nPmtMode          = new Short(a_oRequest.getParameter("nPmtMode"));
    Short nTerm             = new Short(a_oRequest.getParameter("nTerm"));
    Short nEntryAge         = new Short(a_oRequest.getParameter("nEntryAge"));
    Short nNbrOfLives       = new Short(a_oRequest.getParameter("nNbrOfLives"));
    Short nNbrOfPol         = new Short(a_oRequest.getParameter("nNbrOfPol"));
    Double dPrmAmt          = new Double(a_oRequest.getParameter("dPrmAmt"));
    Double dSA              = new Double(a_oRequest.getParameter("dSA"));
    Short nTermType         = new Short(a_oRequest.getParameter("nTermType"));
    Long lComProjSeqNbr = null;
    if (!a_oRequest.getParameter("strPKey").trim().equals("") && a_oRequest.getParameter("strPKey")!=null)
    {
            lComProjSeqNbr = new Long (a_oRequest.getParameter("strPKey"));
    }



    log.debug("CommissionProjectionFetch--Fetched all details of CommissionProjection");

    oCommissionProjectionResult = new CommissionProjectionResult();

    oCommissionProjectionResult.setComProjSeqNbr(lComProjSeqNbr);
    oCommissionProjectionResult.setAgentCd(strAgentCd);
    oCommissionProjectionResult.setAgentName(strAgentName);
    oCommissionProjectionResult.setCalYear(iCalYear);
    oCommissionProjectionResult.setCalMonth(nCalMonth);
    oCommissionProjectionResult.setProdCd(strProdCd);
    oCommissionProjectionResult.setProdVer(iProdVer);
    oCommissionProjectionResult.setCommClass(strCommClass);
    oCommissionProjectionResult.setPmtMode(nPmtMode);
    oCommissionProjectionResult.setTerm(nTerm);
    oCommissionProjectionResult.setEntryAge(nEntryAge);
    oCommissionProjectionResult.setNbrOfLives(nNbrOfLives);
    oCommissionProjectionResult.setNbrOfPol(nNbrOfPol);
    oCommissionProjectionResult.setPrmAmt(dPrmAmt);
    oCommissionProjectionResult.setSA(dSA);
    oCommissionProjectionResult.setTermType(nTermType);
    oCommissionProjectionResult.setUserId(_strUserId);



    log.debug("CommissionProjectionFetch--Set details of CommissionProjection");
    return oCommissionProjectionResult;
  }
}

