/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: OverrideCommMaster.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE	: Sep 10, 2009
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.
*  CODETAG          : Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.commission.util.OverrideCommRuleResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This OverrideCommMaster interface provides method for retreving data from the
 * database through primaryKey  </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Anup Kumar
 * @version 1.0
 */



public interface OverrideCommMaster extends EJBObject
{
  /* This method gets the OverrideCommResult Object
  * @return OverrideCommResult
  */
  public OverrideCommRuleResult getOverrideCommResult() throws RemoteException, EElixirException;

  /* This method sets the OverrideCommResult Object
  * @param a_oOverrideCommResult ChannelResult
  */
  public void setOverrideCommResult(OverrideCommRuleResult a_oOverrideCommResult) throws RemoteException, EElixirException;

}