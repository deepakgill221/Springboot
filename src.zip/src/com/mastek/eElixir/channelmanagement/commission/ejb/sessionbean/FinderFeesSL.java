/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME			: CommissionSL.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.SearchData;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This FinderFeesSL interface provides method for getting the data from FinderFees bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface FinderFeesSL extends EJBObject
{
  /**
   * Creates the Data from the FinderFeesSLEJB
   * @param SearchDeata
   * @return String
   * @throws RemoteException, EJBException, EElixirException;
   */
  public String searchFinderFees(SearchData a_oResultObject) throws EElixirException , FinderException , RemoteException;
  
  public String searchFinderFees() throws EElixirException , FinderException , RemoteException;
  
  public FinderFeesResult searchFinderFees(long a_lbenseqnbr) throws EElixirException , FinderException , RemoteException;
  
  public long createFinderFees(FinderFeesResult a_oFinderFeesResult) throws EElixirException ,  RemoteException;
  
  public void updateFinderFees(FinderFeesResult a_oFinderFeesResult) throws RemoteException, EJBException, EElixirException;
  
  public void deleteFinderFees(Long a_lFFHdrSeqNbr)  throws RemoteException, FinderException, EElixirException;
  
  public void updateFFCommissionRates(FinderFeesResult a_oFinderFeesResult) throws RemoteException, EElixirException;
  
  public long createFinderFeesMap(ArrayList al_FinderFeesMapResult) throws RemoteException, CreateException, EElixirException;		
			 	 
  public void updateFinderFeesMap(ArrayList al_FinderFeesMapResult) throws RemoteException, CreateException, EElixirException;			 
			 
  public String searchFinderFeesMap(SearchData oSearchData) throws EElixirException , FinderException , RemoteException;
  
  public ArrayList searchFinderFeesMap(long _LFFMapSeqNbr)throws RemoteException , EElixirException, FinderException;
  //added by jim
  public FinderFeesResult searchFFCommissionRates(long a_lbenseqnbr,String a_strprdcd) throws EElixirException , FinderException , RemoteException;
  
  
  
}
