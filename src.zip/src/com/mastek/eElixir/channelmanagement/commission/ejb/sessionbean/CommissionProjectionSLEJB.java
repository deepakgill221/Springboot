/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionProjectionSLEJB.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : Jan 20, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;


import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.commission.dax.CommissionProjectionDAX;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.CommissionProjection;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.CommissionProjectionHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.CommissionProjectionPK;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionProjectionResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.ejb.sessionbean.CommonSL;
import com.mastek.eElixir.common.ejb.sessionbean.CommonSLHome;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: eElixir</p>
 * <p>Description: This CommissionProjectionSLEJB session bean acts as an interface for the CommissionProjection Entity bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class CommissionProjectionSLEJB implements SessionBean
{

  /**
   * Constructor of the CommissionProjectionSLEJB class
   */
  public CommissionProjectionSLEJB    ()
  {

  }

  /**
   * Called by the container to create a session bean instance. Its parameters typically
   * contain the information the client uses to customize the bean instance for its use.
   * It requires a matching pair in the bean class and its home interface.
   * @throws EElixirException
   * @throws CreateException
   */
  public void ejbCreate    () throws CreateException,  EElixirException
  {

  }

  /**
   * A container invokes this method before it ends the life of the session object. This
   * happens as a result of a client's invoking a remove operation, or when a container
   * decides to terminate the session object after a timeout. This method is called with
   * no transaction context.
   */
  public void ejbRemove    ()
  {

  }

  /**
   * The activate method is called when the instance is activated from its 'passive' state.
   * The instance should acquire any resource that it has released earlier in the ejbPassivate()
   * method. This method is called with no transaction context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * The passivate method is called before the instance enters the 'passive' state. The
   * instance should release any resources that it can re-acquire later in the ejbActivate()
   * method. After the passivate method completes, the instance must be in a state that
   * allows the container to use the Java Serialization protocol to externalize and store
   * away the instance's state. This method is called with no transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * Set the associated session context. The container calls this method after the instance
   * creation. The enterprise Bean instance should store the reference to the context
   * object in an instance variable. This method is called with no transaction context.
   * @param sc SessionContext
   */

  public void setSessionContext    (SessionContext sc)
  {
    this._EJBContext = sc;
  }



  /**
   * Gets the data based on the parameter of DVO
   * @param a_oResultObject Object
   * @return String XML format string object
   * @throws EElixirException
   * @throws FinderException
   */
  public String searchCommissionProjection(Object a_oResultObject) throws  FinderException, EElixirException
  {
    try{
      _oCommissionProjectionDAX = (CommissionProjectionDAX)getDAX();
      log.debug("CommissionProjectionSLEJB--before getCommissionProjection method of dax object");
      _strCon = _oCommissionProjectionDAX.getCommissionProjection(a_oResultObject);
      log.debug("CommissionProjectionSLEJB--after getCommissionProjection method of dax object");
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      Exception e= ejbex.getCausedByException();
      if (e instanceof EElixirException)
      {
        throw (EElixirException)e;
      }
      else
      {
        throw ejbex;
      }
    }
    catch(EElixirException eLex)
    {
      _EJBContext.setRollbackOnly();
      throw eLex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
    log.debug(_strCon);
    return _strCon;
  }

  /**
   * Gets the Data depending on the Seq No
   * @param a_lComProjSeqNbr long
   * @return CommissionProjectionResult
   * @throws FinderException
   * @throws EElixirException
   */
  public CommissionProjectionResult searchCommissionProjection(long a_lComProjSeqNbr) throws FinderException,EElixirException{
    CommissionProjectionResult oCommissionProjectionResult = null;
    try
    {
      _oCommissionProjectionHome = getCommissionProjectionHome();
       CommissionProjectionPK _oCommissionProjectionPK = new CommissionProjectionPK();
      _oCommissionProjectionPK.setComProjSeqNbr(a_lComProjSeqNbr);
      _oCommissionProjection = _oCommissionProjectionHome.findByPrimaryKey(_oCommissionProjectionPK);
      log.debug("CommissionProjectionSLEJB--Getting Result from CommissionProjection Bean");
      oCommissionProjectionResult =  _oCommissionProjection.getCommissionProjectionResult();
      log.debug("CommissionProjectionSLEJB--Result Obtained"+ oCommissionProjectionResult);
    }
    catch(FinderException fe)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--FinderException " + fe);
      throw new EElixirException(fe,"P3205");
    }
    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--RemoteEXception " + rex);
      throw new EElixirException(rex, "P1006");
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--EJBException " + ejbex);
      throw (EElixirException)ejbex.getCausedByException();
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--EElixirException " + eex);
      throw eex;
    }
    return oCommissionProjectionResult;
  }



  /**
   * Updates data into CommissionProjection
   * @param a_oCommissionProjectionResult CommissionProjectionResult
   * @throws FinderException
   * @throws EElixirException
   */
  public void updateCommissionProjection(CommissionProjectionResult a_oCommissionProjectionResult) throws FinderException,EElixirException{
    try
    {
      _oCommissionProjectionHome = getCommissionProjectionHome();
       CommissionProjectionPK _oCommissionProjectionPK = new CommissionProjectionPK();
      _oCommissionProjectionPK.setComProjSeqNbr(a_oCommissionProjectionResult.getComProjSeqNbr().longValue());
      _oCommissionProjection = _oCommissionProjectionHome.findByPrimaryKey(_oCommissionProjectionPK);
      CommissionProjectionResult con_CommissionProjectionResult = _oCommissionProjection.getCommissionProjectionResult();
      if (con_CommissionProjectionResult.getTsDtUpdated() != null && (!con_CommissionProjectionResult.getTsDtUpdated().equals(a_oCommissionProjectionResult.getTsDtUpdated())))
      {
        log.debug("concurrency failed thorwing exception");
        throw new EElixirException("P1100");
      }
      log.debug("CommissionProjectionSLEJB--Updating call to  CommissionProjection Bean");
      _oCommissionProjection.setCommissionProjectionResult(a_oCommissionProjectionResult);
    }
    catch(FinderException fe)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--FinderException " + fe);
      throw new EElixirException(fe,"P3205");
    }
    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--RemoteEXception " + rex);
      throw new EElixirException(rex, "P1006");
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--EJBException " + ejbex);
      throw (EElixirException)ejbex.getCausedByException();
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--EElixirException " + eex);
      throw eex;
    }
  }



  /**
   * Creates the Data from the CHMSLEJB
   * @param a_oCommissionProjectionResult CommissionProjectionResult
   * @return long
   * @throws EJBException
   * @throws EElixirException
   */
  public long createCommissionProjection(CommissionProjectionResult a_oCommissionProjectionResult) throws  EJBException, EElixirException
  {
    log.debug("CommissionProjectionSLEJB--In create CommissionProjection of CommissionProjectionSLEJB");
    long lComProjSeqNbr = 0;
    try
    {
      _oCommissionProjectionDAX = (CommissionProjectionDAX)getDAX();
      log.debug("CommissionProjectionSLEJB--before getCommissionProjection method of dax object");
      /* currently not reqd
      if(_oCommissionProjectionDAX.validateCommissionProjection(a_oCommissionProjectionResult)){
        log.debug("CommissionProjectionSLEJB--before throwing exception");
        throw new EElixirException("1");  //Throw Message for unique key
      }
      */
      //agency validation
      boolean isValid = true;
      isValid = validateActiveAgency(a_oCommissionProjectionResult.getAgentCd());
      if(!isValid){
        throw new EElixirException("P4540");
      }
      _oCommissionProjectionHome = getCommissionProjectionHome();
      _oCommissionProjection = _oCommissionProjectionHome.create(a_oCommissionProjectionResult);
      lComProjSeqNbr = ((CommissionProjectionPK)_oCommissionProjection.getPrimaryKey()).getComProjSeqNbr();
      log.debug("CommissionProjectionSLEJB--Key is " + lComProjSeqNbr);
    }
    catch (CreateException cex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(cex, "P3201");
    }
    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(rex, "P1006");
    }
    catch (FinderException fex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(fex, "P3205");
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw (EElixirException)ejbex.getCausedByException();
      //throw new EElixirException(ejbex, "P3025");
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionProjectionSLEJB--Inside catch of Eelixir exception in createCommissionProjection of CommissionProjectionSLEJB");
      throw eex;
    }
    finally {
		  try {
			  if (_oConnection != null) {
				  DBConnection.closeConnection(_oConnection);
			  }
		  } catch (EElixirException eElex) {
			  throw eElex;
		  }
	  }
    return lComProjSeqNbr;
  }

  public boolean validateActiveAgency(String strCode) throws EElixirException , FinderException
    {
      boolean isValid = false;
      try{
        _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
        ArrayList al_Type = new ArrayList();
            al_Type.add(new Integer(DataConstants.AGENCY));
            al_Type.add(new Integer(DataConstants.AGENT));
            al_Type.add(new Integer(DataConstants.AGENCYBRANCH));
        isValid = _oCommonSL.validateAgentAgency(strCode, al_Type);
        log.debug("---------------------------- isValid" + isValid);
        return isValid;

      }
      catch(CreateException cex)
      {
        throw new EElixirException(cex, "P1007");
      }
      catch(RemoteException rex)
      {
        throw new EElixirException(rex, "P1006");
      }
      catch(EElixirException eex)
      {
        throw eex;
      }
     }

     private CommonSL getCommonSL(String strHome, Class cHomeClass) throws RemoteException, CreateException, EElixirException
      {
        log.debug("Looking for CommonSLHome");
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        CommonSLHome oCommonSLHome = (CommonSLHome)objEJBHomeFactory
                                   .lookUpHome(oCHMPropertyUtil.getCHMProperty(strHome),
                                   cHomeClass);
        CommonSL  oCommonSL = oCommonSLHome.create();
        log.debug("CommonSLHome Created");
        return oCommonSL;
    }

  /**
  * Invoked by	the	session	bean to	look up	the	CommissionProjection EJB. for Deleting a CommissionProjection
  * @param  a_lComProjSeqNbr long
  * @throws RemoveException
  * @throws EElixirException
  * @throws EJBException
  */
 public void deleteCommissionProjection(long a_lComProjSeqNbr) throws RemoveException, EJBException, EElixirException
 {
       try
       {
         _oCommissionProjectionHome = getCommissionProjectionHome();
         CommissionProjectionPK oCommissionProjectionPK = new CommissionProjectionPK();
         log.debug("CommissionProjectionSLEJB--Inside Delete1 ");
         oCommissionProjectionPK.setComProjSeqNbr(a_lComProjSeqNbr);
         log.debug("CommissionProjectionSLEJB--Inside Delete2 ");
         CommissionProjection  oCommissionProjection	= _oCommissionProjectionHome.findByPrimaryKey(oCommissionProjectionPK);
         log.debug("CommissionProjectionSLEJB--Inside Delete3 ");
         oCommissionProjection.remove();
         log.debug("CommissionProjectionSLEJB--Inside Delete4");
       }
       catch(FinderException fex)
       {
         _EJBContext.setRollbackOnly();
         throw	new	EElixirException(fex, "P3205");
       }
       catch (RemoveException rex)
       {
         _EJBContext.setRollbackOnly();
         throw	new	EElixirException(rex, "P3207");
       }
       catch (RemoteException rex)
       {
         _EJBContext.setRollbackOnly();
         throw	new	EElixirException(rex, "P1006");
       }
       catch(EJBException ejbex){
         _EJBContext.setRollbackOnly();
         throw	(EElixirException)ejbex.getCausedByException();
       }
       catch(EElixirException eLex)
       {
         _EJBContext.setRollbackOnly();
         throw	eLex;
       }

 }

 /**
 * Invoked by	the	session	bean to	look up	the	CommissionProjection EJB. for Deleting a CommissionProjection
 * @param  a_oCommissionProjectionResult CommissionProjectionResult
 * @throws RemoveException
 * @throws EElixirException
 * @throws EJBException
 */
public void deleteCommissionProjection(CommissionProjectionResult a_oCommissionProjectionResult) throws RemoveException, EJBException, EElixirException
{
      try
      {
        // Upper part is to ensure that record exist
        _oCommissionProjectionHome = getCommissionProjectionHome();
        CommissionProjectionPK oCommissionProjectionPK = new CommissionProjectionPK();
        log.debug("CommissionProjectionSLEJB--Inside Delete1 ");
        oCommissionProjectionPK.setComProjSeqNbr(a_oCommissionProjectionResult.getComProjSeqNbr().longValue());
        log.debug("CommissionProjectionSLEJB--Inside Delete2 ");
         CommissionProjection  oCommissionProjection	= _oCommissionProjectionHome.findByPrimaryKey(oCommissionProjectionPK);

        _oCommissionProjectionDAX = (CommissionProjectionDAX)getDAX();
        log.debug("CommissionProjectionSLEJB--before getCommissionProjection method of dax object");
        _oCommissionProjectionDAX.updateDeleteFlagCommissionProjection(a_oCommissionProjectionResult);
      }
      catch(FinderException fex)
      {
        _EJBContext.setRollbackOnly();
        throw	new	EElixirException(fex, "P3205");
      }
      catch (RemoteException rex)
      {
        _EJBContext.setRollbackOnly();
        throw	new	EElixirException(rex, "P1006");
      }
      catch(EJBException ejbex){
        _EJBContext.setRollbackOnly();
        throw	(EElixirException)ejbex.getCausedByException();
      }
      catch(EElixirException eLex)
      {
        _EJBContext.setRollbackOnly();
        throw	eLex;
      }
      finally {
		  try {
			  if (_oConnection != null) {
				  DBConnection.closeConnection(_oConnection);
			  }
		  } catch (EElixirException eElex) {
			  throw eElex;
		  }
	  }

}


  /**
   * Gets the Dax object and sets the connection on it.
   * @return CommissionProjectionDAX
   * @throws EElixirException
   */
    private CommissionProjectionDAX getDAX() throws EElixirException
    {
      _oConnection = DBConnection.getConnection();
      CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
      CommissionProjectionDAX _oCommissionProjectionDAX = (CommissionProjectionDAX)theDAXFactory.createDAX(theDAXFactory.COMMISSIONPROJECTIONDAX);
      _oCommissionProjectionDAX.setConnection(_oConnection);

      return _oCommissionProjectionDAX;
    }

    /**
     * Gets the Home object.
     * @return CommissionProjectionHome
     * @throws EElixirException
     */
    private CommissionProjectionHome getCommissionProjectionHome() throws EElixirException
    {
      EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      log.debug("CommissionProjectionSLEJB--Before Lookup");
      CommissionProjectionHome oCommissionProjectionHome = (CommissionProjectionHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("CommissionProjectionHome"),CommissionProjectionHome.class);
      log.debug("CommissionProjectionSLEJB--Home LookUP _oCommissionProjectionHome:" + oCommissionProjectionHome);
      return oCommissionProjectionHome;
    }


/**
 * Attributes declaration
 */
  private Connection                _oConnection = null;
  private CommissionProjectionDAX   _oCommissionProjectionDAX;
  private String                    _strCon;
  public SessionContext             _EJBContext = null;
  public CommissionProjectionHome   _oCommissionProjectionHome;
  private CommissionProjection      _oCommissionProjection;
  public CommonSLHome               _oCommonSLHome;
  private CommonSL                  _oCommonSL;

  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}