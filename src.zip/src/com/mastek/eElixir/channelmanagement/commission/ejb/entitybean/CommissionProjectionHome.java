/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionProjectionHome.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : Jan 20, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.commission.util.CommissionProjectionResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This CommissionProjection home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


public interface CommissionProjectionHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @return CommissionProjection
   * @param primaryKey CommissionProjectionPK
   * @throws javax.ejb.RemoteException
   * @throws javax.ejb.FinderException
   * @throws javax.ejb.EElixirException
   */

  public CommissionProjection findByPrimaryKey   (CommissionProjectionPK primaryKey)
      throws FinderException, RemoteException, EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @return CommissionProjection
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   * @throws javax.ejb.EElixirException
   */
  public CommissionProjection create() throws CreateException, RemoteException, EElixirException;


  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class
   * @return CommissionProjection
   * @param a_oCommissionProjectionResult CommissionProjectionResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   * @throws javax.ejb.EElixirException
   */
  public CommissionProjection create(CommissionProjectionResult a_oCommissionProjectionResult) throws CreateException, RemoteException, EElixirException;


}