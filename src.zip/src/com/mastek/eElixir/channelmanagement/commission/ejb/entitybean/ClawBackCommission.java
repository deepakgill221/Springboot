/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ClawBackCommission.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBException;
import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This ClawBackCommission interface provides method for retreving data from the
 * database through primaryKey  </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface ClawBackCommission extends EJBObject
{
  /* This method gets the ClawBackDetails Object
  * @return ClawBackDetails
  */
  public ClawBackDetails getClawBackCommissionDetail() throws RemoteException, EElixirException;

  /* This method sets the ClawBackDetails Object
  * @param a_oClawBackDetails ClawBackDetails
  */
  public void setClawBackCommissionDetail(ClawBackDetails a_oClawBackDetails) throws RemoteException, EElixirException;

 /* This method updates the ClawBackDetails Object
  * @param a_oContractResult ContractResult
  */
  public void updateCommission(ContractResult a_oContractResult) throws RemoteException, EJBException, EElixirException ;
}