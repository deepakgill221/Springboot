/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : PolicyAckSLEJB.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_policy_ackn_upd.doc.doc
*  CREATION DATE                  : 29/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
* 1.1      04/09/2003   Dipti      Code Rework
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.commission.dax.PolicyAckDAX;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.PolicyAck;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.PolicyAckHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.PolicyAckPK;
import com.mastek.eElixir.channelmanagement.commission.util.PolicyAckResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;


public class PolicyAckSLEJB implements SessionBean
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Attributes declaration
     */
    private Connection _oConnection = null;
    public SessionContext _EJBContext = null;
    private PolicyAckHome _oPolicyAckHome;
    private PolicyAck _oPolicyAck;

    /**
     * Constructor of the PolicyAckSLEJB class
     */
    public PolicyAckSLEJB()
    {
    }

    /**
     * Called by the container to create a session bean instance. Its parameters typically
     * contain the information the client uses to customize the bean instance for its use.
     * It requires a matching pair in the bean class and its home interface.
     */
    public void ejbCreate() throws CreateException, EElixirException
    {
    }

    /**
     * A container invokes this method before it ends the life of the session object.This
     * happens as a result of a client's invoking a remove operation,or when a container
     * decides to terminate the session object after a timeout. This method is called with
     * no transaction context.
     */
    public void ejbRemove()
    {
    }

    /**
     * The activate method is called when  the instance is activated from its 'passive' state.
     * The instance should acquire any resource that it has released earlier in the ejbPassivate()
     * method. This method is  called with no transaction context.
     */
    public void ejbActivate()
    {
    }

    /**
     * The passivate method is called before the instance enters the 'passive' state.        The
     * instance should release any resources that  it can re-acquire laterin the ejbActivate()
     * method. After the passivate method  completes, the instance must be in a state that
     * allows the  container to use the Java Serializationprotocol to externalize and  store
     * away the instance's state.This method is called with no transaction context.
     */
    public void ejbPassivate()
    {
    }

    /**
     * Set the associated session context. The container calls this method after the instance
     * creation. The enterprise Bean instance should store the reference to the context
     * object in an instance variable. This method is called with  no transaction context.
     * @param        a_sc
     */
    public void setSessionContext(SessionContext a_sc)
    {
        this._EJBContext = a_sc;
    }

    /**
    * Gets the Data from the CHMSLEJB
    * @param SearchData
    * @return ArrayList
    * @throws EElixirException
       */
    public ArrayList searchPolicyAck(SearchData oSearchData)
        throws EElixirException, FinderException
    {
        ArrayList oPolicyAckList = null;

        try
        {
            PolicyAckDAX oPolicyAckDAX = getDAX();
            oPolicyAckList = oPolicyAckDAX.getPolicyAck(oSearchData);

            return oPolicyAckList;
        }
        catch (EJBException ejbex)
        {
            _oLogger.fatal(getClass().getName(), "searchPolicyAck",
                ejbex.getMessage());
            throw new EElixirException(ejbex, "P3039");
        }
        catch (EElixirException eLex)
        {
            _oLogger.fatal(getClass().getName(), "searchPolicyAck",
                eLex.getMessage());
            throw eLex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                _oLogger.fatal(getClass().getName(), "searchPolicyAck",
                    eElex.getMessage());
                throw eElex;
            }
        }
    }

    /**
     * updates Data from the CHMSLEJB
     * @param ArrayList a_oPolicyAckList
     * @return void
     * @throws EElixirException
      */
    public void updatePolicyAck(ArrayList a_oPolicyAckList)
        throws EElixirException
    {
        try
        {
            _oPolicyAckHome = getPolicyAckHome("PolicyAckHome",
                    PolicyAckHome.class);

            PolicyAckPK pkPolicyAck = null;
            PolicyAckDAX _oPolicyAckDAX = getDAX();

            for (int i = 0; i < a_oPolicyAckList.size(); i++)
            {
                PolicyAckResult oPolicyAckResult = (PolicyAckResult) a_oPolicyAckList.get(i);
                pkPolicyAck = new PolicyAckPK(oPolicyAckResult.getPolNbr(),
                        oPolicyAckResult.getServAgentCd());

                PolicyAck _objPolicyAck = _oPolicyAckHome.findByPrimaryKey(pkPolicyAck);
                Timestamp con_dtUpdated = _oPolicyAckDAX.getPolicyAckDtUpdated(oPolicyAckResult.getPolNbr());

                if ((con_dtUpdated != null) &&
                        (!con_dtUpdated.equals(
                            oPolicyAckResult.getTsDtUpdated())))
                {
                    throw new EElixirException("P1100");
                }

                _objPolicyAck.setPolicyAckResult(oPolicyAckResult);
            }
        }
        catch (FinderException fe)
        {
            _oLogger.fatal(getClass().getName(), "updatePolicyAck",
                fe.getMessage());
            _EJBContext.setRollbackOnly();
            throw new EElixirException(fe, "P3040");
        }

        catch (EJBException ejbex)
        {
            _oLogger.fatal(getClass().getName(), "updatePolicyAck",
                ejbex.getMessage());
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "updatePolicyAck",
                eex.getMessage());
            _EJBContext.setRollbackOnly();
            throw eex;
        }

        catch (RemoteException rex)
        {
            _oLogger.fatal(getClass().getName(), "updatePolicyAck",
                rex.getMessage());
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P3040");
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {                
                throw eElex;
            }
        }
    }

    /**
         * Get the Policy Ack Home
     * @param a_strHome
     * @param a_cHomeClass
     * @return PolicyAckHome
     * @throws EElixirException
     */
    private PolicyAckHome getPolicyAckHome(String a_strHome, Class a_cHomeClass)
        throws EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        PolicyAckHome _oPolicyAckHome = (PolicyAckHome) objEJBHomeFactory.lookUpHome(_oCHMPropertyUtil.getCHMProperty(
                    a_strHome), a_cHomeClass);

        return _oPolicyAckHome;
    }

    /**
     * Gets the Dax object and sets the connection on it.
     * @return PolicyAckDAX
     * @throws EElixirException
     */
    private PolicyAckDAX getDAX() throws EElixirException
    {
        _oConnection = DBConnection.getConnection();

        CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        PolicyAckDAX _oPolicyAckDAX = (PolicyAckDAX) theDAXFactory.createDAX(theDAXFactory.POLICYACKDAX);
        _oPolicyAckDAX.setConnection(_oConnection);

        return _oPolicyAckDAX;
    }
}
