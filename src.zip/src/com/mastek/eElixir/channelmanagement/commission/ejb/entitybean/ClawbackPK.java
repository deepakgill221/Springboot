/********************************************************************
*
*  PROJECT					: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME					: ClawbackPK.java
*  AUTHOR					: VINAYSHEEL BABER
*  VERSION					: 1.0
*  CREATION DATE		: October 13, 2002
*  COMPANY				: Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.io.Serializable;

   /**
    * <p>Title: eElixir</p>
    * <p>Description:This primary key class is for the ClawbackEJB which contains get & set
    *  methods for the primary key field Seq No</p>
    * <p>Copyright: Copyright (c) 2002</p>
    * <p>Company: Mastek Ltd</p>
    * @author Vinaysheel
    * @version 1.0
    */
   public class ClawbackPK implements Serializable
{

    /**
     * Referencing to object that represents the entity object.
     * @return integer value
     */
    public int hashCode    ()
    {
		int iHashCode = (_strPolNbr == null || _strServAgentCd == null)?0:_strPolNbr.hashCode() + _strServAgentCd.hashCode();
		return iHashCode;

    }

    /**
     * Method that compares two entity object references -- since the Java Object.equals(Object
     * obj) method is unspecified.
     * @return boolean
     */
    public boolean equals    (Object obj)
    {

      boolean bEqual=false;
	if(obj!=null && obj instanceof ClawbackPK)
	{
        bEqual=  this._strPolNbr.equals(((ClawbackPK)obj)._strPolNbr) && this._strServAgentCd.equals(((ClawbackPK)obj)._strServAgentCd);
	}	

      return bEqual;

    }

    /**
     * Own toString() method of a bean's PK class.
     * @return String
     */
    public String toString    ()
    {
      return this._strPolNbr + ":::" + this._strServAgentCd;
    }
  public String getPolNbr() {
    return _strPolNbr;
  }
  public String getServAgentCd() {
    return _strServAgentCd;
  }
  public void setPolNbr(String _strPolNbr) {
    this._strPolNbr = _strPolNbr;
  }
  public void setServAgentCd(String _strServAgentCd) {
    this._strServAgentCd = _strServAgentCd;
  }

    /**
     * Constructor
     */
    public ClawbackPK()
    {

    }

    /**
     * Constructor
     * @param a_strParamCd String, a_iParamTypeCd int
     */

    public ClawbackPK    ( String a_strPolNbr, String a_strServAgentCd)
    {
          this._strPolNbr = a_strPolNbr;
          this._strServAgentCd = a_strServAgentCd;
    }

    private String  _strPolNbr;
    private String  _strServAgentCd;
}