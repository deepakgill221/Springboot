/********************************************************************
*
*  PROJECT					: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME					: Clawback
*  AUTHOR					: VINAYSHEEL BABER
*  VERSION					: 1.0
*  CREATION DATE		: October 14, 2002
*  COMPANY				: Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.commission.util.ClawbackResult;
import com.mastek.eElixir.common.exception.EElixirException;



/**
 * <p>Title: eElixir</p>
 * <p>Description: This is a local interface for ClawbackEJB local entity bean.
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd.</p>
 * @author Vinaysheel
 * @version 1.0
 */


public interface Clawback extends EJBObject
{

 public ClawbackResult getClawbackResult() throws RemoteException, EElixirException;

 public void setClawbackResult(ClawbackResult a_oClawbackResult) throws RemoteException, EElixirException;

}