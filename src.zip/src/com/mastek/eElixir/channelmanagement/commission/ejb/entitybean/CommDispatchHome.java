/********************************************************************
*
*  PROJECT			:MNYL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: CommDispatchHome.java
*  AUTHOR			: Amid P Sahu
*  VERSION			: 1.0
*  CREATION DATE    : Feb 18, 2009
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2009.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 
*
*--------------------------------------------------------------------------------
*Amid_Fin_156_Upload Of Commission Dispatch
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This CsaCpa home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */


public interface CommDispatchHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @throws javax.ejb.FinderException
   */

  public CommDispatch findByPrimaryKey(CommDispatchPK primaryKey)
      throws FinderException, RemoteException, EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @return CommDispatchResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public CommDispatch create() throws CreateException, RemoteException, EElixirException;


  

}