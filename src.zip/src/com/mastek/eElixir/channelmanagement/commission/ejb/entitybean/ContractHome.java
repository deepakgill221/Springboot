/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractHome.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This Contract Local home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


public interface ContractHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @throws javax.ejb.FinderException
   */

  public Contract findByPrimaryKey   (ContractPK primaryKey)
      throws FinderException, RemoteException, EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public Contract create() throws CreateException, RemoteException, EElixirException;


  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class
   * @param a_oContractResult ContractResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public Contract create(ContractResult a_oContractResult) throws CreateException, RemoteException, EElixirException;


}