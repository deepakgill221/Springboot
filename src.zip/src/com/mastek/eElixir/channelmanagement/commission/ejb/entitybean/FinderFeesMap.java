/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: FinderFeesMap.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: Dec 03, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2004.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY           REASON
 *-------------------------------------------------------------------------------- 
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesMapResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description: This is a local interface for FinderFeesMappingEJB local entity bean.
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd.</p> 
 * @version 1.0
 */


public interface FinderFeesMap extends EJBObject
{
 /**
  * Gets the Data from the FinderFeesMappingSLEJB
  * @return Collection object
  * @throws EElixirExceptionException
  */


  //public Collection getFinderFeesMappingCollection();
  //public void setFinderFeesMappingCollection(Collection c);

  /* This method gets the FinderFeesMap ResultObject
  * @return AdjustmentResult
  */
  public FinderFeesMapResult getFinderFeesMapResult() throws RemoteException, EElixirException;

  /* This method sets the AdjustmentResult Object
  * @FinderFeesMapResult a_oFinderFeesMapResult
  */
  public void setFinderFeesMapResult(FinderFeesMapResult a_oFinderFeesMapResult) throws RemoteException, EElixirException;


}