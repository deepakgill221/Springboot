/********************************************************************
 *
 *  PROJECT			: Amal
 *  MODULE NAME		        : Customer Development
 *  FILENAME			: OverridingCommRatePK
 *  AUTHOR			: Pallav
 *  VERSION			: 1.0
 *  CREATION DATE	        : Mar 3, 2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;
import java.io.Serializable;
/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the Bean which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class OverridingCommRatePK implements Serializable
{
 // private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor
   */
  public OverridingCommRatePK    ()
  {
  }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode    ()
  {
    int iHashcode=0;
    if(new Long(_lAgrmtRateSeqNbr)!= null){
      iHashcode= new Long(_lAgrmtRateSeqNbr).hashCode();
      //log.debug("HashCode for UnitSeq:" + iHashcode);
    }
    return iHashcode;

  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * @param obj method is unspecified.
   * @return boolean
   */


  public boolean equals    (java.lang.Object obj)
  {
    boolean bEqual=false;
	if(obj!=null && obj instanceof OverridingCommRatePK)
	{
		if(obj instanceof OverridingCommRatePK){
		  bEqual = this._lAgrmtRateSeqNbr  ==  ((OverridingCommRatePK)obj)._lAgrmtRateSeqNbr;
		}
	}
    return bEqual;
  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public java.lang.String toString    ()
  {
    return null;
  }


  public long getAgrmtRateSeqNbr()
  {
    return this._lAgrmtRateSeqNbr;
  }

  /**
   *  Method to set value of the Seq No field
   *
   */
  public void setAgrmtRateSeqNbr(long a_lAgrmtRateSeqNbr)
  {
    this._lAgrmtRateSeqNbr = a_lAgrmtRateSeqNbr;
  }

  /**
   * Constructor
   * @param SeqNo long
   */

  public OverridingCommRatePK (long a_lAgrmtRateSeqNbr)
  {
    this._lAgrmtRateSeqNbr = a_lAgrmtRateSeqNbr;
  }

  private long _lAgrmtRateSeqNbr;
}