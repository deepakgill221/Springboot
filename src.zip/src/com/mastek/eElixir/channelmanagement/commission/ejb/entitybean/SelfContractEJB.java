/********************************************************************
 *
 *  PROJECT					: PRUDENTIAL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME					: SelfContractEJB
 *  AUTHOR					: VINAYSHEEL BABER
 *  VERSION					: 1.0
 *  CREATION DATE		: October 14, 2002
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2002.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.commission.dax.ContractDAX;
import com.mastek.eElixir.channelmanagement.commission.util.SelfContractResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: EElixir</p>
 * <p>Description: SelfContractEJB is the local entity bean .</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: MASTEK</p>
 * @author Vinaysheel
 * @version 1.0
 */

public class SelfContractEJB implements EntityBean
{

  /**
   * Constructor for SelfContractEJB class
   */
  public SelfContractEJB    ()
  {

  }

  /**
   * Matching method of the create() method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @return ActivityDocPK
   * @throws javax.ejb.CreateException
   */
  public SelfContractPK ejbCreate    () throws CreateException
  {
    SelfContractPK aapk = new SelfContractPK();

    return aapk;

  }


  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @throws javax.ejb.CreateException
   */
  public void ejbPostCreate    () throws CreateException
  {

  }

  /**
   * A container invokes this method when the instance is taken out of the pool of available
   * instances to become associated with a specific EJB object. This method transitions
   * the instance to the ready state. This method executes in an unspecified transaction
   * context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * A container invokes this method on an instance before the instance becomes disassociated
   * with a specific EJB object. After this method completes, the container will place
   * the instance into the pool of available instances. This method executes in an unspecified
   * transaction context.
   */
  public void ejbPassivate    ()
  {

  }




  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by loading it from the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */

  public void ejbLoad    ()
  {
    //This method is not implemented beacuse no need currently
  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by storing it to the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbStore    ()
  {

    log.debug("ejbstore fired");

    log.debug("ejbstore fired");
	/* CHANGE TO AVOID UPDATE  */
     if(this._oSelfContractResult != null && this._oSelfContractResult .getIsDirty().equals(DataConstants.UPDATE_MODE))
     {
       try
       {
         log.debug("in ejbejbsore");
         ContractDAX _oContractDAX = getDAX();
         _oContractDAX.updateSelfContract(_oSelfContractResult);
       }
       catch(EElixirException ex)
       {
         throw new EJBException(ex);
       }
       finally
       {
         try
         {
           if(_oConnection != null)
             DBConnection.closeConnection(_oConnection);
         }
         catch(EElixirException eex)
         {
           throw new EJBException(eex);
         }
       }
     }

  }




  /**
   * A container invokes this method before it removes the EJB object that is currently
   * associated with the instance. It is invoked when a client invokes a remove operation
   * on the enterprise Bean's home or remote interface. It transitions the instance from
   * the ready state to the pool of available instances. It is called in the transaction
   * context of the remove operation.
   * @throws javax.ejb.RemoveException
   */
  public void ejbRemove    () throws RemoveException
  {

  }

  /**
   * Set the associated entity context. The container invokes this method on an instance
   * after the instance has been created. This method is called in an unspecified transaction
   * context.
   */
  public void setEntityContext    (EntityContext ctx)
  {
    this.EJB_Context = ctx;
  }

  /**
   * Unset the associated entity context. The container calls this method before removing
   * the instance. This is the last method that the container invokes on the instance.
   * The Java garbage collector will  invoke the finalize() method on the instance. It
   * is called in an unspecified transaction context.
   */
  public void unsetEntityContext    ()
  {

  }

  /**
   * Invoked by the container on the instance when the container selects the instance to
   * execute a matching client-invoked find() method. It executes in the transaction
   * context determined by the transaction attribute of the matching find() method.
   * @return ApplicationPK
   * @throws javax.ejb.FinderException
   */

  public SelfContractPK ejbFindByPrimaryKey    (SelfContractPK scPK) throws  FinderException, EElixirException
  {

    try
    {
      ContractDAX _oContractDAX = getDAX();
      log.debug("calling dax in ejbFindByPrimaryKey" );
         boolean bFlag = _oContractDAX.searchSelfContract( scPK.getPolNbr(), scPK.getServAgentCd());
        if(bFlag)
        {
          log.debug("Returning SelfContractPK Primary Key");
          return scPK;
        }
        else
        {
          log.debug("Returning Exception");
          throw new FinderException("Primary key not found");
        }


    }
    catch(EElixirException eex)
    {
      throw eex;
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex)
      {
        throw eElex;
      }
    }



  }


  public SelfContractResult getSelfContractResult() throws  EElixirException
  {
    return this._oSelfContractResult;
  }

  public void setSelfContractResult(SelfContractResult a_oSelfContractResult) throws  EElixirException
  {
    this._oSelfContractResult = a_oSelfContractResult;
  }



  /**
   * gets SetupDAX
   * @return SetupDAX
   * @throws EElixirException
   */
  private ContractDAX getDAX() throws EElixirException
  {
    _oConnection = DBConnection.getConnection();
    CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
    ContractDAX _oContractDAX = (ContractDAX)theDAXFactory.createDAX(theDAXFactory.CONTRACTDAX);
    _oContractDAX.setConnection(_oConnection);

    return _oContractDAX;
  }




  /**
   * Attributes declaration
   */
  private EntityContext EJB_Context;
  private Connection _oConnection = null;
  private DataSource _oDatasource = null;
  private SelfContractResult _oSelfContractResult;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);




}