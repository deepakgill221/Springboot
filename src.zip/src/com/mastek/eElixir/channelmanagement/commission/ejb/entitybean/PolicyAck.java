/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : PolicyAck.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_policy_ackn_upd.doc.doc
*  CREATION DATE                  : 29/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.commission.util.PolicyAckResult;
import com.mastek.eElixir.common.exception.EElixirException;


public interface PolicyAck extends EJBObject
{
    /**
    * Gets the Policy Acknowledgement Result Object
    * @return PolicyAckResult
    * @throws RemoteException
    * @throws EElixirException
    */
    public PolicyAckResult getPolicyAckResult()
        throws RemoteException, EElixirException;

    /**
    * Sets the Policy Acknowledgement Result Object
    * @param a_oPolicyAckResult
    * @throws RemoteException
    * @throws EElixirException
    */
    public void setPolicyAckResult(PolicyAckResult a_oPolicyAckResult)
        throws RemoteException, EElixirException;
}
