/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Finder Fees
*  FILENAME			: FinderFeesEJB.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: November 10, 2002
*  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
*  1.1         30Jan             Pallav                Added delete functionality
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description: This RYCRuleMaster Entity bean retrive data from the database according to seach condition</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Mastek Ltd</p>
 * @author Srikanth Kolluri
 * @version 1.0
 */



public interface RYCRuleMaster extends EJBObject
{
  /* This method gets the RYCRuleMasterSearchResult Object
  * @return RYCRuleMasterSearchResult
  */
  public RYCRuleMasterSearchResult getRYCResultMaster() throws RemoteException, EElixirException;

  /* This method sets the RYCRuleMasterSearchResult Object
  * @param a_oRYCRuleMasterSearchResult RYCRuleMasterSearchResult
  */
  public void setRYCResultMaster(RYCRuleMasterSearchResult a_oRYCRuleMasterSearchResult) throws RemoteException, EElixirException;



}