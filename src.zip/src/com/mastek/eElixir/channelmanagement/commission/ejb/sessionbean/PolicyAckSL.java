/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : PolicyAckSL.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_policy_ackn_upd.doc
*  CREATION DATE                  : 29/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;
import javax.ejb.FinderException;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.SearchData;

 
public interface PolicyAckSL extends EJBObject
{
    /**
     * Gets the Data from the CHMSLEJB
     * @param SearchData
     * @return ArrayList
     * @throws EElixirException
       */
    public ArrayList searchPolicyAck(SearchData _oSearchData)
        throws EElixirException, FinderException, RemoteException;

    /**
     * updates Data from the CHMSLEJB
     * @param ArrayList a_oSelfPolicyAckList
     * @return void
     * @throws EElixirException
    */
    public void updatePolicyAck(ArrayList a_oSelfPolicyAckList)
        throws RemoteException, EElixirException;
}
