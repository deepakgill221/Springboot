/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Channel Management
*  FILENAME			: FinderFeesMapPK.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: Dec 03, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2004.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY           REASON
 *-------------------------------------------------------------------------------- 
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.io.Serializable;

   /**
	* <p>Title: eElixir</p>
	* <p>Description:This primary key class is for the FinderFeesMapBean </p>
	* <p>Copyright: Copyright (c) 2002</p>
	* <p>Company: Mastek Ltd</p>
	* @version 1.0
	*/
 public class FinderFeesMapPK implements Serializable
{

	/**
	 * Referencing to object that represents the entity object.
	 * @return integer value
	 */
	public int hashCode    ()
	{
	  int iHashcode=0;
	  if(new Long(_LFFMapSeqNbr)!= null)
	  iHashcode= new Long(_LFFMapSeqNbr).hashCode();
	  return iHashcode;

  }

	/**
	 * Method that compares two entity object references -- since the Java Object.equals(Object
	 * obj) method is unspecified.
	 * @return boolean
	 * @param obj Object
	 */
	public boolean equals    (Object obj)
	{
				boolean bEqual=false;
			if(obj!=null && obj instanceof FinderFeesMapPK)
			{
				long objKey = ((FinderFeesMapPK)obj).getLFFMapSeqNbr();
				if (this._LFFMapSeqNbr == objKey)
				{
				  bEqual = true;
				}
			}
				return bEqual;
	}

	/**
	 * Own toString() method of a bean's PK class.
	 * @return String
	 */
	public String toString    ()
	{
	   return _LFFMapSeqNbr + "";
	}

	/**
	 *  Method to access the _LFFMapSeqNbr  field
	 * @return long
	 *
	 */
	 public long getLFFMapSeqNbr()
	 {
			return this._LFFMapSeqNbr;
	 }

	/**
	 *  Method to set value of the _LFFMapSeqNbr field
	 *  @param _LFFMapSeqNbr long
	 */
	 public void setLFFMapSeqNbr(long a_LFFMapSeqNbr)
	 {
			this._LFFMapSeqNbr = a_LFFMapSeqNbr;
	 }

	/**
	 * Constructor
	 */
	public FinderFeesMapPK    ()
	{

	}

	/**
	 * Constructor
	 * @param a_LFFMapSeqNbr String
	 */

	public FinderFeesMapPK (long a_LFFMapSeqNbr)
	{
		 this._LFFMapSeqNbr = a_LFFMapSeqNbr;
	}

   private long _LFFMapSeqNbr;

}
