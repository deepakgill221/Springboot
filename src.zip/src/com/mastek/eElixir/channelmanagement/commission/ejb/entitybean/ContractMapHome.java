/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMapHome.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.commission.util.ContractMapResult;
import com.mastek.eElixir.common.exception.EElixirException;



/**
     * <p>Title: eElixir</p>
     * <p>Description:This is a home interface for ContractMap entity bean.</p>
     * <p>Copyright: Copyright (c) 2002</p>
     * <p>Company: Mastek Ltd</p>
     * @author Vinaysheel
     * @version 1.0
     */


public interface ContractMapHome extends EJBHome
{
    /**
     * Called by the client to find an EJB bean instance, usually find by primary key
     * @returns ContractMappingLocal reference
     * @param a_pkContractMapping ContractMappingPK primary key
     * @throws java.rmi.FinderException
     */

        public ContractMap findByPrimaryKey   (ContractMapPK a_pkContractMapping)
                throws FinderException, RemoteException, EElixirException;


    /**
     * Called by the client to create an EJB bean instance. It requires a matching pair in
     * the bean class, i.e. ejbCreate().
     * @returns ContractMappingLocal
     * @throws java.rmi.RemoteException
     * @throws javax.ejb.CreateException
     */
    public ContractMap create() throws CreateException, RemoteException;




    public ContractMap create(ContractMapResult a_oContractMapResult) throws CreateException, RemoteException, EElixirException;
}