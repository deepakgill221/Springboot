/********************************************************************
*
*  PROJECT					: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME					: SelfContractHome
*  AUTHOR					: VINAYSHEEL BABER
*  VERSION					: 1.0
*  CREATION DATE		: October 14, 2002
*  COMPANY				: Mastek Ltd.
*  COPYRIGHT			: COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.common.exception.EElixirException;


/**
     * <p>Title: eElixir</p>
     * <p>Description:This is a home interface for SelfContractpEJB local entity bean.</p>
     * <p>Copyright: Copyright (c) 2002</p>
     * <p>Company: Mastek Ltd</p>
     * @author Vinaysheel
     * @version 1.0
     */


public interface SelfContractHome extends EJBHome
{
    /**
     * Called by the client to find an EJB bean instance, usually find by primary key
     * @returns SelfContract reference
     * @param a_pkSelfContract SelfContractPK primary key
     * @throws FinderException
     */

        public SelfContract findByPrimaryKey   (SelfContractPK a_pkSelfContract)
                throws FinderException, RemoteException, EElixirException;



    public SelfContract create() throws CreateException, RemoteException;


}