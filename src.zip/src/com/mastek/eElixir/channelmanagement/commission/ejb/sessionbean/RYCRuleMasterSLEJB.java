/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterSLEJB.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: October 29, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.EJBException;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.commission.dax.RYCRuleMasterDAX;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.RYCRuleMaster;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.RYCRuleMasterHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.RYCRuleMasterPK;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.common.util.DBConnection;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;

import com.mastek.eElixir.common.util.SearchData;
/**
 * <p>Title: eElixir</p>
 * <p>Description: This RYCRuleMasterSLEJB session bean acts as an interface for the RYCRuleMasterSLEJB bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Sriaknth Kolluri
 * @version 1.0
 */

public class RYCRuleMasterSLEJB implements SessionBean
{

  /**
   * Constructor of the CommissionSLEJB class
   */
  public RYCRuleMasterSLEJB()
  {

  }

  /**
   * Called by the container to create a session bean instance. Its parameters typically
   * contain the information the client uses to customize the bean instance for its use.
   * It requires a matching pair in the bean class and its home interface.
   * @throws CreateException
   * @throws EElixirException
   */
  public void ejbCreate    () throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method before it ends the life of the session object. This
   * happens as a result of a client's invoking a remove operation, or when a container
   * decides to terminate the session object after a timeout. This method is called with
   * no transaction context.
   */
  public void ejbRemove    ()
  {

  }

  /**
   * The activate method is called when the instance is activated from its 'passive' state.
   * The instance should acquire any resource that it has released earlier in the ejbPassivate()
   * method. This method is called with no transaction context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * The passivate method is called before the instance enters the 'passive' state. The
   * instance should release any resources that it can re-acquire later in the ejbActivate()
   * method. After the passivate method completes, the instance must be in a state that
   * allows the container to use the Java Serialization protocol to externalize and store
   * away the instance's state. This method is called with no transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * Set the associated session context. The container calls this method after the instance
   * creation. The enterprise Bean instance should store the reference to the context
   * object in an instance variable. This method is called with no transaction context.
   * @param sc SessionContext
   */

  public void setSessionContext    (SessionContext sc)
  {
	this._EJBContext = sc;
  }
  
  
  public String searchRYCRuleMaster() throws  FinderException, EElixirException
	{
	  try{
		_oRYCRuleMasterDAX = (RYCRuleMasterDAX)getDAX();
		log.debug("RYCRuleMasterSLEJB--before searchRYCRuleMaster method of dax object");
		_strCon = _oRYCRuleMasterDAX.getRYCRuleMaster();
		log.debug("RYCRuleMasterSLEJB--after searchRYCRuleMaster method of dax object");
	  }
	  catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	  }
	  
	  log.debug("The Return String is"+_strCon);
	  return _strCon;
	}


	/**
		 * Gets the data for search criteria specified in SearchData Object
		 * @param SearchData a_oResultObject
		 * @return String
		 * @throws EElixirException
  */
	
	public String searchRYCRuleMaster(SearchData a_oResultObject)
			 throws FinderException, EElixirException, RemoteException
	{
		try{
		_oRYCRuleMasterDAX = (RYCRuleMasterDAX)getDAX();
		log.debug("RYCRuleMasterSLEJB--before searchRYCRuleMaster method of dax object");
		_strCon = _oRYCRuleMasterDAX.getRYCRuleMaster(a_oResultObject);
		log.debug("RYCRuleMasterSLEJB--after searchRYCRuleMaster method of dax object");
	  }
	  catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	  }
	  
	  log.debug("The Return String is"+_strCon);
	  return _strCon;
		
 }


	public RYCRuleMasterSearchResult searchRYCRuleMaster(long lRYCHdrSeqNbr)
			throws FinderException, EElixirException, RemoteException
	{
 	RYCRuleMasterSearchResult oRYCRuleMasterSearchResult = null;
	try{
		 _oRYCRuleMasterHome = getRYCRuleMasterHome();
		   RYCRuleMasterPK _oRYCRuleMasterPK = new RYCRuleMasterPK();
		  _oRYCRuleMasterPK.setRYCSeqNbr(lRYCHdrSeqNbr);
		  _oRYCRuleMaster = _oRYCRuleMasterHome.findByPrimaryKey(_oRYCRuleMasterPK);
		log.debug("RYCRuleMasterSLEJB--before searchRYCRuleMaster method entity");
		  oRYCRuleMasterSearchResult =  _oRYCRuleMaster.getRYCResultMaster();
		  log.debug("RYCRuleMasterSLEJB--Result Obtained"+ oRYCRuleMasterSearchResult);
		return oRYCRuleMasterSearchResult;
	}
	 catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	}
}

public long createRYCRuleMaster(RYCRuleMasterSearchResult a_RYCRuleMasterSearchResult)
		 throws EJBException, EElixirException
{		 
	log.debug("FinderFeesSLEJB--In create FinderFees of FinderFeesSLEJB");
	long seqNo = 0;
	 try
	 {
		 _oRYCRuleMasterHome = getRYCRuleMasterHome();
		  	_oRYCRuleMaster = _oRYCRuleMasterHome.create(a_RYCRuleMasterSearchResult);
		  	seqNo = ((RYCRuleMasterPK)_oRYCRuleMaster.getPrimaryKey()).getRYCSeqNbr();
		  	log.debug("RYCRuleMasterSLEJB--Key is " + seqNo);
		return seqNo;
	 }
	 catch (CreateException cex)
	{
		  _EJBContext.setRollbackOnly();
		  throw new EElixirException(cex, "P9007");
	}
	catch (RemoteException rex)
	{
		  _EJBContext.setRollbackOnly();
		  throw new EElixirException(rex, "P1006");
	}
	 catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	}
}
	

 public void updateRYCRuleMaster(RYCRuleMasterSearchResult a_RYCRuleMasterSearchResult)
        throws RemoteException, EElixirException
  {
   try
   {			
	   log.debug("RYCRuleMasterSLEJB updateRYCRuleMaster ");


		_oRYCRuleMasterHome = getRYCRuleMasterHome();

		log.debug("a_RYCRuleMasterSearchResult.getFFHDRSeqNbr()-->"+a_RYCRuleMasterSearchResult.getFFHDRSeqNbr());

		   RYCRuleMasterPK _oRYCRuleMasterPK = new RYCRuleMasterPK(a_RYCRuleMasterSearchResult.getFFHDRSeqNbr().longValue() );

		  _oRYCRuleMaster = _oRYCRuleMasterHome.findByPrimaryKey(_oRYCRuleMasterPK);

		  _oRYCRuleMaster.setRYCResultMaster(a_RYCRuleMasterSearchResult);

		log.debug("RYCRuleMasterSLEJB--before searchRYCRuleMaster method entity");

	
	} 
	catch (FinderException cex)
	{
		  _EJBContext.setRollbackOnly();
		  throw new EElixirException(cex, "P9007");
	}
	catch (RemoteException rex)
	{
		  _EJBContext.setRollbackOnly();
		  throw new EElixirException(rex, "P1006");
	}
	 catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	}
  }

	public void deleteRYCRuleMaster(Long rycHdrSeqNbr)
			 throws  EElixirException, RemoteException
	{
		try{
		_oRYCRuleMasterDAX = (RYCRuleMasterDAX)getDAX();
		log.debug("RYCRuleMasterSLEJB--before searchRYCRuleMaster method of dax object");
		 _oRYCRuleMasterDAX.deleteRYCRuleMaster(rycHdrSeqNbr);
		log.debug("RYCRuleMasterSLEJB--after searchRYCRuleMaster method of dax object");
	  }
	  catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	  }
	  
	  log.debug("The Return String is"+_strCon);
		
 }

	/**
	   * Gets the Dax object and sets the connection on it.
	   * @return RYCRuleMasterDAX
	   * @throws EElixirException
    */
	private RYCRuleMasterDAX getDAX() throws EElixirException
	{
		_oConnection = DBConnection.getConnection();
		CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
		RYCRuleMasterDAX _oRYCRuleMasterDAX = (RYCRuleMasterDAX)theDAXFactory.createDAX(CHMDAXFactory.RYCRuleMasterDAX);
		_oRYCRuleMasterDAX.setConnection(_oConnection);
		
		return _oRYCRuleMasterDAX;
	}	


	/**
		* Gets the Home object.
		* @return FinderFeesHome
		* @throws EElixirException
	*/
   	private RYCRuleMasterHome getRYCRuleMasterHome() throws EElixirException
   	{
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		log.debug("RYCRuleMasterHome--Before Lookup");
		RYCRuleMasterHome oRYCRuleMasterHome = (RYCRuleMasterHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("RYCRuleMasterHome"),RYCRuleMasterHome.class);
		log.debug("RYCRuleMasterHome--Home LookUP RYCRuleMasterHome:" + oRYCRuleMasterHome);
		return oRYCRuleMasterHome;
    }	
	
	
  /**
   * Attributes declaration
   */
  
  public SessionContext _EJBContext = null;
  private Connection _oConnection = null;
  private String _strCon;
  private RYCRuleMasterDAX _oRYCRuleMasterDAX;
  public RYCRuleMasterHome _oRYCRuleMasterHome;
  public RYCRuleMaster _oRYCRuleMaster;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  
}