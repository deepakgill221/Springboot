/********************************************************************
 *
 *  PROJECT			: PRUDENTIAL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME			: CommissionSLEJB.java
 *  AUTHOR			: Pallav Laddha
 *  VERSION			: 1.0
 *  CREATION DATE	        : September 20, 2002
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 **  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*1.1		07/04/2015		Vibhu Nigam		FIN838_AgentCommissionDisbursementLimitChange
*
*
*--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.commission.dax.CommissionDAX;
import com.mastek.eElixir.channelmanagement.commission.dax.ContractMapDAX;
import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ClawBackCommission;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ClawBackCommissionHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.CommDispatch;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.CommDispatchHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.CommDispatchPK;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.OverrideCommMaster;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.OverrideCommMasterHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.OverrideCommMasterPK;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.OverridingCommRate;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.OverridingCommRateHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.OverridingCommRatePK;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.StandardCommission;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.StandardCommissionHome;
import com.mastek.eElixir.channelmanagement.commission.util.CollectionParamResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.commission.util.DisbursementSetupResult;
import com.mastek.eElixir.channelmanagement.commission.util.OverrideCommRuleResult;
import com.mastek.eElixir.channelmanagement.commission.util.OverridingCommRateDetail;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAXFactory;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

/**
 * <p>Title: eElixir</p>
 * <p>Description: This Commission session bean acts as an interface for the Commission Entity bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class CommissionSLEJB implements SessionBean
{

  /**
   * Constructor of the CommissionSLEJB class
   */
  public CommissionSLEJB    ()
  {

  }

  /**
   * Called by the container to create a session bean instance. Its parameters typically
   * contain the information the client uses to customize the bean instance for its use.
   * It requires a matching pair in the bean class and its home interface.
   * @throws CreateException
   * @throws EElixirException
   */
  public void ejbCreate    () throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method before it ends the life of the session object. This
   * happens as a result of a client's invoking a remove operation, or when a container
   * decides to terminate the session object after a timeout. This method is called with
   * no transaction context.
   */
  public void ejbRemove    ()
  {

  }

  /**
   * The activate method is called when the instance is activated from its 'passive' state.
   * The instance should acquire any resource that it has released earlier in the ejbPassivate()
   * method. This method is called with no transaction context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * The passivate method is called before the instance enters the 'passive' state. The
   * instance should release any resources that it can re-acquire later in the ejbActivate()
   * method. After the passivate method completes, the instance must be in a state that
   * allows the container to use the Java Serialization protocol to externalize and store
   * away the instance's state. This method is called with no transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * Set the associated session context. The container calls this method after the instance
   * creation. The enterprise Bean instance should store the reference to the context
   * object in an instance variable. This method is called with no transaction context.
   * @param sc SessionContext
   */

  public void setSessionContext    (SessionContext sc)
  {
    this._EJBContext = sc;
  }


  /**
   * Creates Commission from ContractResult, Fetches CommissionResult passes to appropriate EntityBean
   * @param: a_oContractResult ContractResult
   * @throws  EJBException
   * @throws EElixirException
   */
  public void createCommission(ContractResult a_oContractResult) throws  EJBException, EElixirException
  {
    log.debug("CommissionSLEJB--In create Commission of CommissionSLEJB");
    try
    {
      EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	_oCommissionDAX = (CommissionDAX)getDAX();
      CommissionResult oCommissionResult = a_oContractResult.getCommissionResult();

      Short nCommType = oCommissionResult.getCommType();
	  //Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
      if(nCommType.shortValue() == DataConstants.STANDARD_COMMISSION || nCommType.intValue() == DataConstants.TRAIL_COMMISSION || nCommType.intValue() == DataConstants.INDEX_COMMISSION || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION){ // for standard commission, or Trail
	  /*
        log.debug("CommissionSLEJB--Before Lookup of entity bean");
        _oStandardCommissionHome = (StandardCommissionHome)objEJBHomeFactory
                                .lookUpHome(oCHMPropertyUtil.getCHMProperty("StandardCommissionHome"),StandardCommissionHome.class);
        log.debug("CommissionSLEJB--After Lookup");
        _oStandardCommission = _oStandardCommissionHome.create(oCommissionResult,nCommType.shortValue());
		*/
         _oCommissionDAX.createStandardCommission(oCommissionResult, nCommType.shortValue());
      }
      else if(nCommType.shortValue() == DataConstants.CLAWBACK_COMMISSION){ // for Clawback
	  /*
        log.debug("CommissionSLEJB--Before Lookup of entity bean");
        _oClawBackCommissionHome = (ClawBackCommissionHome)objEJBHomeFactory
                               .lookUpHome(oCHMPropertyUtil.getCHMProperty("ClawBackCommissionHome"),ClawBackCommissionHome.class);
        log.debug("CommissionSLEJB--After Lookup");
        _oClawBackCommission = _oClawBackCommissionHome.create(oCommissionResult);
		*/
         _oCommissionDAX.createClawBackCommission(oCommissionResult);
      }
    }
	/*
    catch (CreateException cex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(cex, "P3023");
    }
    catch(RemoteException rex){
      _EJBContext.setRollbackOnly();
      throw new EElixirException(rex, "P1006");
    }
	*/
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw new EElixirException(ejbex, "P3023");
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      throw eex;
    }
    finally
    {
        try
        {
            if (_oConnection != null)
            {
                DBConnection.closeConnection(_oConnection);
            }
        }
        catch (EElixirException eElex)
        {                
            throw eElex;
        }
    }

  }


  /**
   * Invoked by the session bean to look up the Commission EJB.
   * @param a_oContractResult ContractResult
   * @throws RemoteException
   * @throws EJBException
   */
/*
 This function is commented, now this functionality is used in dax
  public void updateCommission(ContractResult a_oContractResult) throws  RemoveException, EJBException
  {
    try
    {
      EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      String strCommType = a_oContractResult.getCommissionResult().getCommType();
      log.debug("CommissionSLEJB--Inside Update Commission");
      if(strCommType.trim().equals("0") || strCommType.trim().equals("2")){ // for standard commission, or Trail
        CommissionDetails[] arrCommissionDetail = a_oContractResult.getCommissionResult().getCommissionDetail();
        StandardCommissionHome  _oStandardCommissionHome = (StandardCommissionHome)oEJBHomeFactory
            .lookUpHome(oCHMPropertyUtil.getCHMProperty("StandardCommissionHome"),
            StandardCommissionHome.class);

        StandardCommissionPK oStandardCommissionPK = new StandardCommissionPK();
        for(int i=0; i<arrCommissionDetail.length; i++){
          log.debug("CommissionSLEJB--Status Flag" + arrCommissionDetail[i].getStatusFlag().trim());
          if(arrCommissionDetail[i].getStatusFlag().trim().equals(DataConstants.UPDATE_MODE)){
            log.debug("CommissionSLEJB--Inside Update1 " + arrCommissionDetail[i].getAgrmtSCSeqNbr().longValue());
            oStandardCommissionPK.setAgrmtSCSeqNbr(arrCommissionDetail[i].getAgrmtSCSeqNbr().longValue());
            log.debug("CommissionSLEJB--Inside Update2");
            StandardCommission  oStandardCommission = _oStandardCommissionHome.findByPrimaryKey(oStandardCommissionPK);
            log.debug("CommissionSLEJB--Inside Update3");
            oStandardCommission.setStandardCommissionDetail(arrCommissionDetail[i]);
            log.debug("CommissionSLEJB--Inside Update4");
          }
          else if(arrCommissionDetail[i].getStatusFlag().trim().equals(DataConstants.INSERT_MODE)){
            log.debug("CommissionSLEJB--Inside Insert1");
            CommissionDetails[] arrNewCommissionDetails = new CommissionDetails[1];
            arrNewCommissionDetails[0] = arrCommissionDetail[i];
            CommissionResult oCRNew = new CommissionResult();
            log.debug("CommissionSLEJB--Inside Insert2");
            oCRNew.setCommissionDetail(arrNewCommissionDetails);
            log.debug("CommissionSLEJB--Inside Insert3");
            _oStandardCommission = _oStandardCommissionHome.create(oCRNew);
            log.debug("CommissionSLEJB--Inside Insert4");

          }
          else if(arrCommissionDetail[i].getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
            log.debug("CommissionSLEJB--Inside Delete1 " + arrCommissionDetail[i].getAgrmtSCSeqNbr().longValue());
            oStandardCommissionPK.setAgrmtSCSeqNbr(arrCommissionDetail[i].getAgrmtSCSeqNbr().longValue());
            log.debug("CommissionSLEJB--Inside Delete2 " + arrCommissionDetail[i].getAgrmtSCSeqNbr().longValue());
            StandardCommission  oStandardCommission = _oStandardCommissionHome.findByPrimaryKey(oStandardCommissionPK);
            log.debug("CommissionSLEJB--Inside Delete3 " + arrCommissionDetail[i].getAgrmtSCSeqNbr().longValue());
            oStandardCommission.remove();
            log.debug("CommissionSLEJB--Inside Delete4");
          }
        }
      }
      else if(strCommType.trim().equals("4")){ // for Clawback
        ClawBackDetails[] arrClawBackDetail = a_oContractResult.getCommissionResult().getClawBackDetail();
        ClawBackCommissionHome  _oClawBackCommissionHome = (ClawBackCommissionHome)oEJBHomeFactory
            .lookUpHome(oCHMPropertyUtil.getCHMProperty("ClawBackCommissionHome"),
            ClawBackCommissionHome.class);

        ClawBackCommissionPK oClawBackCommissionPK = new ClawBackCommissionPK();
        for(int i=0; i<arrClawBackDetail.length; i++){
          if(arrClawBackDetail[i].getStatusFlag().trim().equals(DataConstants.UPDATE_MODE)){
            oClawBackCommissionPK.setAgrmtClawSeqNbr(arrClawBackDetail[i].getlAgrmtClawSeqNbr().longValue());
            ClawBackCommission  oClawBackCommission = _oClawBackCommissionHome.findByPrimaryKey(oClawBackCommissionPK);
            oClawBackCommission.setClawBackCommissionDetail(arrClawBackDetail[i]);
          }
          else if(arrClawBackDetail[i].getStatusFlag().trim().equals(DataConstants.INSERT_MODE)){
            ClawBackDetails[] arrNewClawBackDetails = new ClawBackDetails[1];
            arrNewClawBackDetails[0] = arrClawBackDetail[i];
            CommissionResult oCRNew = new CommissionResult();
            oCRNew.setClawBackDetail(arrNewClawBackDetails);
            _oStandardCommission = _oStandardCommissionHome.create(oCRNew);

          }
          else if(arrClawBackDetail[i].getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
            oClawBackCommissionPK.setAgrmtClawSeqNbr(arrClawBackDetail[i].getlAgrmtClawSeqNbr().longValue());
            ClawBackCommission  oClawBackCommission = _oClawBackCommissionHome.findByPrimaryKey(oClawBackCommissionPK);
            oClawBackCommission.remove();
          }
        }
      }
    }
    catch(FinderException fex)
    {
      _EJBContext.setRollbackOnly();
      throw new EJBException(fex.getMessage());
    }
    catch (CreateException cex)
    {
      _EJBContext.setRollbackOnly();
      throw new EJBException(cex.getMessage());
    }
    catch (RemoveException rex)
    {
      _EJBContext.setRollbackOnly();
      throw new EJBException(rex.getMessage());
    }
    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      throw new EJBException(rex.getMessage());
    }
    catch(EElixirException fex)
    {
      _EJBContext.setRollbackOnly();
      throw new EJBException(fex.getMessage());
    }

  }
  */

 /**
  * Invoked by the session bean to search an Commission bean ejb
  * @return CommissionDetails[] Standard Commission details
  * @param a_lCommAgrmtSeqNbr long
  * @throws EJBException
  * @throws FinderException
  * @throws EElixirException
  */
  public CommissionDetails[] searchStandardCommission(long a_lCommAgrmtSeqNbr, short a_nCommType) throws  EJBException, FinderException, EElixirException
  {
    CommissionDetails arrCommissionDetails[] = null;
    try{

      _oCommissionDAX = (CommissionDAX)getDAX();
      log.debug("CommissionSLEJB--before getStandardCommission method of dax object");
      arrCommissionDetails = _oCommissionDAX.getStandardCommission(a_lCommAgrmtSeqNbr,a_nCommType);
      log.debug("CommissionSLEJB--after getStandardCommission method of dax object");
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw new EElixirException(ejbex, "P3006");
    }
    catch(EElixirException eLex)
    {
      _EJBContext.setRollbackOnly();
      throw eLex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
    return arrCommissionDetails;
  }

  /**
   * Invoked by the session bean to search an Commission bean ejb
   * @return ClawBackDetails[] ClawBack Commission details
   * @param a_lCommAgrmtSeqNbr long
   * @throws EJBException
   * @throws FinderException
  * @throws EElixirException
   */
  public ClawBackDetails[] searchClawBackCommission(long a_lCommAgrmtSeqNbr) throws EJBException, FinderException, EElixirException
  {
    ClawBackDetails arrClawBackDetails[] = null;
    try{
      _oCommissionDAX = (CommissionDAX)getDAX();
      arrClawBackDetails = _oCommissionDAX.getClawBackCommission(a_lCommAgrmtSeqNbr);
      log.debug("CommissionSLEJB--arrClawBackDetails.length" +arrClawBackDetails.length);
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw new EElixirException(ejbex, "P3007");
    }
    catch(EElixirException eLex)
    {
      _EJBContext.setRollbackOnly();
      throw eLex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
    //setContractString(_strCon);
    return arrClawBackDetails;
  }



  /**
   * Invoked by the session bean to look up the Commission EJB.
   * @param a_oContractResult ContractResult
   * @throws CreateException
   * @throws EJBException
  * @throws EElixirException
   */
  public void updateCommission(ContractResult a_oContractResult) throws CreateException, EJBException, EElixirException
  {
    try
    {
      EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      Short nCommType = a_oContractResult.getCommissionResult().getCommType();
      log.debug("CommissionSLEJB--Inside Update Commission");
	  //Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
      if(nCommType.shortValue() == DataConstants.STANDARD_COMMISSION || nCommType.shortValue() == DataConstants.TRAIL_COMMISSION || nCommType.shortValue() == DataConstants.INDEX_COMMISSION || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION){ // for standard commission, or Trail
        //CommissionDetails[] arrCommissionDetail = a_oContractResult.getCommissionResult().getCommissionDetail();
        //StandardCommissionHome  _oStandardCommissionHome = (StandardCommissionHome)oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("StandardCommissionHome"), StandardCommissionHome.class);
        //_oStandardCommission = _oStandardCommissionHome.create();
        CommissionDetails[] arrCommissionDetail = a_oContractResult.getCommissionResult().getCommissionDetail();
        _oCommissionDAX = (CommissionDAX)getDAX();
        if (arrCommissionDetail != null)
        {
          for(int i=0;i< arrCommissionDetail.length;i++)
          {
             log.debug("CommissionSLEJB--Inside conc check sc seq nbr  " + arrCommissionDetail[i].getStatusFlag());
             if (!arrCommissionDetail[i].getStatusFlag().trim().equals(DataConstants.INSERT_MODE))
             {
				 //Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
                if (nCommType.shortValue() == DataConstants.STANDARD_COMMISSION || nCommType.shortValue() == DataConstants.TRAIL_COMMISSION || nCommType.shortValue() == DataConstants.INDEX_COMMISSION)
                {
                   log.debug("CommissionSLEJB--Inside conc check sc seq nbr  " + arrCommissionDetail[i].getAgrmtSCSeqNbr());
                   Timestamp con_dtUpdated = _oCommissionDAX.getStandardCommissionDtUpdated(arrCommissionDetail[i].getAgrmtSCSeqNbr());
                   log.debug("CommissionSLEJB--Inside conc check got timestamps as " + con_dtUpdated + " " + arrCommissionDetail[i].getTsDtUpdated());
                   if (con_dtUpdated != null && (!con_dtUpdated.equals(arrCommissionDetail[i].getTsDtUpdated())))
                   {
                      log.debug("concurrency failed thorwing exception");
                      throw new EElixirException("P1100");
                   }
                }
             }
          }
        }
        //_oStandardCommission.updateCommission(a_oContractResult);
		_oCommissionDAX.updateCommission(a_oContractResult);

      }
      else if(nCommType.shortValue() == DataConstants.CLAWBACK_COMMISSION){ // for Clawback
        ClawBackDetails[] arrClawBackDetail = a_oContractResult.getCommissionResult().getClawBackDetail();
        //ClawBackCommissionHome  oClawBackCommissionHome = (ClawBackCommissionHome)oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("ClawBackCommissionHome"), ClawBackCommissionHome.class);
        //_oClawBackCommission = oClawBackCommissionHome.create();
        ClawBackDetails[] arrClawBackDetails = a_oContractResult.getCommissionResult().getClawBackDetail();
        _oCommissionDAX = (CommissionDAX)getDAX();
        if (arrClawBackDetails  != null)
        {
          for(int i=0;i< arrClawBackDetails.length;i++)
          {
             log.debug("CommissionSLEJB--Inside conc check status flag " + arrClawBackDetails[i].getStatusFlag());
             if(!arrClawBackDetails[i].getStatusFlag().trim().equals(DataConstants.INSERT_MODE))
             {
                log.debug("CommissionSLEJB--Inside conc check clawback seq nbr  " + arrClawBackDetails[i].getlAgrmtClawSeqNbr());
                Timestamp con_dtUpdated = _oCommissionDAX.getClawBackCommissionDtUpdated(arrClawBackDetails[i].getlAgrmtClawSeqNbr());
                log.debug("CommissionSLEJB--Inside conc check got clawback timestamps as " + con_dtUpdated + " " + arrClawBackDetails[i].getTsDtUpdated());
                if (con_dtUpdated != null && (!con_dtUpdated.equals(arrClawBackDetails[i].getTsDtUpdated())))
                {
                   log.debug("concurrency failed thorwing exception");
                   throw new EElixirException("P1100");
                }
             }
          }
        }
        //_oClawBackCommission.updateCommission(a_oContractResult);
		_oCommissionDAX.updateCommission(a_oContractResult);
      }
    }
	/*
    catch (CreateException cex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(cex, "P3023");
    }
    catch(RemoteException rex){
      _EJBContext.setRollbackOnly();
      throw new EElixirException(rex, "P1006");
    }
	*/
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw new EElixirException(ejbex, "P3027");
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      throw eex;
    }
  }
//Amid_Fin_156_Upload Of Commission Dispatch_Starts
  public	String searchCommissionDispatch(SearchData	oSearchData) throws	EElixirException , FinderException
  {
    try
    {
    	_oCommissionDAX = (CommissionDAX)getDAX();      
        _strCon = _oCommissionDAX.getCommissionDispatch(oSearchData);
        log.debug("ContractSLEJB--after	getContract	method of dax object");
    }
    catch(EJBException ejbex){
      throw new EElixirException(ejbex, "P3033");
    }
    catch(EElixirException eLex)
    {
      throw eLex;
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex)
      {
        throw eElex;
      }
    }

    log.debug(_strCon);
    return _strCon;

  }
  public void updateCommDispatch(ArrayList a_alCommDispatchList) throws FinderException, EElixirException
  {
	  CommDispatchResult oCommDispatchResult = null;
		boolean bFlag=false;
      try
      {
    	  
    	  CommDispatchPK oCommDispatchPK=null;
          EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
          CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
          _oCommDispatchHome = (CommDispatchHome) oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
          "CommDispatchHome"), CommDispatchHome.class);
          
          if (a_alCommDispatchList != null)
          {
          	int iSize = a_alCommDispatchList.size();
              for (int i = 0; i < iSize; i++)
              {                	
            	  	 oCommDispatchResult = (CommDispatchResult) a_alCommDispatchList.get(i);   
              		 oCommDispatchPK = new CommDispatchPK(oCommDispatchResult.getCommDispatchSeqno());
              		 _oCommDispatch = _oCommDispatchHome.findByPrimaryKey(oCommDispatchPK);
              		/* CommDispatchResult oCommDispatchResult1 = _oCommDispatch.getCommDispatchResult();
                                   
                       if ((oCommDispatchResult1.getTsDtUpdated() != null) &&
                               (!oCommDispatchResult1.getTsDtUpdated().equals(oCommDispatchResult.getTsDtUpdated())))
                       {
                    	   log.fatal(
                               "concurrency failed thorwing exception");
                           throw new EElixirException("P1100");
                       }
                     */
                       _oCommDispatch.setCommDispatchResult(oCommDispatchResult);
              
              }
          }
      }
      catch (RemoteException rex)
      {
    	  log.fatal(getClass().getName(), "updateCommDispatch",
              "RemoteException " + rex.getMessage());
    	  _EJBContext.setRollbackOnly();
          throw new EElixirException(rex, "P1006");
      }
      catch (FinderException fex)
      {
    	  log.fatal(getClass().getName(), "updateCommDispatch",
              "FinderException " + fex.getMessage());
    	  _EJBContext.setRollbackOnly();
          throw new EElixirException(fex, "P7123");
      }
      catch (EJBException ejbex)
      {
    	  log.fatal(getClass().getName(), "updateCommDispatch",
              "EJBException " + ejbex.getMessage());
    	  _EJBContext.setRollbackOnly();
          throw (EElixirException) ejbex.getCausedByException();
      }
      catch (EElixirException eex)
      {
    	  log.fatal(getClass().getName(), "updateCommDispatch",
              "EElixirException " + eex.getMessage());
    	  _EJBContext.setRollbackOnly();
          throw eex;
      }
      finally
		{
			try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{
				log.fatal(getClass().getName(), "updateSegmentMaster",
					"EElixirException " + eElex.getMessage());
				throw new EElixirException(eElex, "P1005");
			}
		}
      
  }
  public	String deleteCommissionDispatch(SearchData	oSearchData) throws	EElixirException , FinderException
  {
    try
    {
    	_oCommissionDAX = (CommissionDAX)getDAX();  
    	log.debug("commissionSLEJB--before deleteCommissionDispatch	method of dax object");
        _strCon = _oCommissionDAX.deleteCommissionDispatch(oSearchData);
        log.debug("commissionSLEJB--after	deleteCommissionDispatch	method of dax object");
    }
    catch(EJBException ejbex){
      throw new EElixirException(ejbex, "P3033");
    }
    catch(EElixirException eLex)
    {
      throw eLex;
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex)
      {
        throw eElex;
      }
    }

    log.debug(_strCon);
    return _strCon;

  }

  //Amid_Fin_156_Upload Of Commission Dispatch_Ends
  /**
   * Gets the Dax object and sets the connection on it.
   * @return ContractDAX
   * @throws EElixirException
   */
    private CommissionDAX getDAX() throws EElixirException
    {
      _oConnection = DBConnection.getConnection();
      CHMDAXFactory theCHMDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
      CommissionDAX _oCommissionDAX = (CommissionDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.COMMISSIONDAX);
      _oCommissionDAX.setConnection(_oConnection);
       return _oCommissionDAX;
    }
/**
   * For getting OverridingCommRate depending on selected Overriding commission
   * @param a_lPriKey long
   * @return ArrayList
   * @throws FinderException
   * @throws EElixirException
   */
  public ArrayList searchOverridingCommRate(long a_lPriKey) throws FinderException,EElixirException{
    ArrayList arrOverridingCommRate = null ;
      try{
      _oCommissionDAX = (CommissionDAX)getDAX();
      arrOverridingCommRate = _oCommissionDAX.getAllOverridingCommRate(a_lPriKey);
      log.debug("CommissionSLEJB--arrClawBackDetails.length" +arrOverridingCommRate);
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw new EElixirException(ejbex, "P3007");
    }
    catch(EElixirException eLex)
    {
      _EJBContext.setRollbackOnly();
      throw eLex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
    //setContractString(_strCon);
    return arrOverridingCommRate;

  }

  public void updateOverridingCommRate(ArrayList a_arrOverridingCommRateResult) throws  EJBException, EElixirException
  {
    log.debug("CommissionSLEJB--In updateOverridingCommRate of CommissionSLEJB");
    OverridingCommRateDetail oOverridingCommRateDetail =  null;
    try
    {
      EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      log.debug("CommissionSLEJB--Before Lookup of entity bean");
      _oOverridingCommRateHome  = (OverridingCommRateHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("OverridingCommRateHome"),OverridingCommRateHome.class);
      log.debug("CommissionSLEJB--After Lookup" + _oOverridingCommRateHome);

      _oCommissionDAX = (CommissionDAX)getDAX();
      if(a_arrOverridingCommRateResult != null){
        for(int i=0; i< a_arrOverridingCommRateResult.size(); i++){
          oOverridingCommRateDetail = (OverridingCommRateDetail)a_arrOverridingCommRateResult.get(i);
          if(oOverridingCommRateDetail.getStatusFlag().trim().equals(DataConstants.INSERT_MODE)){
            if(_oCommissionDAX.validateDesignation(oOverridingCommRateDetail.getAgrmtORCSeqNbr().longValue(), oOverridingCommRateDetail.getSupDesgnCd())){
              _oOverridingCommRate = _oOverridingCommRateHome.create((OverridingCommRateDetail)a_arrOverridingCommRateResult.get(i));
            }
            else{
              throw new EElixirException("P3056");
            }
          }
          else if(oOverridingCommRateDetail.getStatusFlag().trim().equals(DataConstants.UPDATE_MODE)){
            if(_oCommissionDAX.validateDesignation(oOverridingCommRateDetail.getAgrmtORCSeqNbr().longValue(), oOverridingCommRateDetail.getSupDesgnCd())){
              OverridingCommRatePK ocrpk = new OverridingCommRatePK(oOverridingCommRateDetail.getAgrmtRateSeqNbr().longValue());
              // upk.setUnitDefnSeqNbr(oUnitResult.getUnitDefnSeqNbr().longValue());
              log.debug("CommissionSLEJB--" + oOverridingCommRateDetail);
              _oOverridingCommRate = _oOverridingCommRateHome.findByPrimaryKey(ocrpk);
              log.debug("CommissionSLEJB--" + _oOverridingCommRate.getOverridingCommRateResult());

              /*OverridingCommRateDetail conOverridingCommRateDetail = _oOverridingCommRate.getOverridingCommRateResult();
              if(conOverridingCommRateDetail.getTsDtUpdated() != null
                  && (!conOverridingCommRateDetail.getTsDtUpdated().equals(oOverridingCommRateDetail.getTsDtUpdated())))
              {
                log.debug("CommissionSLEJB---Update---Concurrency check failed");
                throw new EElixirBussinessException(Constants.ERR_CODE_CONCURRENCY);
              }*///todo add concurrency check for updates
              _oOverridingCommRate.setOverridingCommRateResult(oOverridingCommRateDetail);
            }
            else{
              throw new EElixirException("P3056");
            }
          }
          else if(oOverridingCommRateDetail.getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
            OverridingCommRatePK ocrpk = new OverridingCommRatePK(oOverridingCommRateDetail.getAgrmtRateSeqNbr().longValue());
          //  upk.setUnitDefnSeqNbr(oUnitResult.getUnitDefnSeqNbr().longValue());
            log.debug("CommissionSLEJB--Inside Delete1");
            _oOverridingCommRate = _oOverridingCommRateHome.findByPrimaryKey(ocrpk);
            log.debug("CommissionSLEJB--Inside Delete2");
            _oOverridingCommRate.remove();
          }
        }
      }
    }
    catch (CreateException cex)
    {

      throw new EElixirException(cex, "P3049");
    }
    catch(FinderException fe)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionSLEJB--FinderException " + fe);
       throw new EElixirException(fe, "P3049");
    }
    catch(RemoveException rvx)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(rvx, "P3049");
    }
    catch(RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(rex, "P3049");
    }
    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw new EElixirException(ejbex, "P3049");
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      log.debug("CommissionSLEJB--Inside catch of Eelixir exception in UpdateOverridingCommission of CommissionSLEJB");
      throw eex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
  }
  // <!--sunaina_Commision_Dispatch_CR_Starts-->
  public CommDispatchResult searchGetLocationCd(String strUserId)throws 
  RemoteException, FinderException, EElixirException
  {
	  CommDispatchResult resultObject = null;
	  try
		 {
		  _oCommissionDAX = (CommissionDAX)getDAX();
		  log.debug("CommissionDAX----searchGetLocationCd()--->GOT DAXXX"+strUserId);
		  resultObject = _oCommissionDAX.searchGetLocationCd(strUserId);
		  log.debug("CommissionDAX --> searchGetLocationCd" + resultObject);

		  return resultObject;
		 }
		catch(EJBException ejbex)
		{
		 throw new EElixirException(ejbex, "P4207");
		}
		catch(EElixirException eLex)
		{
		 throw eLex;
		}
		finally
		{
		 try
		 {
			if(_oConnection != null)
			   DBConnection.closeConnection(_oConnection);
		 }
		 catch(EElixirException eElex)
		 {
			throw eElex;
		 }
	   }
	  }
	  // <!--sunaina_Commision_Dispatch_CR_ENDED-->
  
  //Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Starts
  /**
   * Invoked by the session bean to call the DAX method.
   * @param  a_cChannelType String
   * @return ArrayList
   * @throws EElixirException
   */
 public ArrayList searchOverrideCommRuleList(String a_cChannelType)
     throws RemoteException, FinderException, EElixirException
 {
     try
     { 
    	 _oCommissionDAX = getDAX();
         return _oCommissionDAX.getCommRuleList(a_cChannelType);
     }
     catch (EJBException ejbex)
     {
         log.fatal(getClass().getName(), "searchOverrideCommRuleList ",
             "EJBException " + ejbex.getMessage());
         throw new EElixirException(ejbex, "dec200");
     }
     catch (EElixirException eLex)
     {
         log.fatal(getClass().getName(), "searchOverrideCommRuleList ",
             "EElixirException " + eLex.getMessage());
         throw eLex;
     }
     finally
     {
         try
         {
             if (_oConnection != null)
             {
                 DBConnection.closeConnection(_oConnection);
             }
         }
         catch (EElixirException eElex)
         {
             log.fatal(getClass().getName(), "searchOverrideCommRuleList ",
                 "EElixirException " + eElex.getMessage());
             throw eElex;
         }
     }
 } 
 
 
 /**
	 * for Updating Override Channel Type Commission Rule Master Information
	 * 
	 * @param a_oCommRuleList
	 * @throws FinderException
	 * @throws EElixirException
	 * @return void
	 * @author Anup Kumar
	 * 
	 */
	public void updateOverrideCommRule(ArrayList a_alOverrideCommMasterList)
			throws FinderException, RemoteException, EElixirException {
          
		OverrideCommRuleResult oOverrideCommRuleResult = null;		
		try {			
			OverrideCommMasterPK oOverrideCommMasterPK = new OverrideCommMasterPK();            
			EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil
					.getPropertyUtil();			
			_oOverrideCommMasterHome = (OverrideCommMasterHome) oEJBHomeFactory.lookUpHome(
					oCHMPropertyUtil.getCHMProperty("OverrideCommMasterHome"),
					OverrideCommMasterHome.class);
			
			String strStatus = null;
			_oCommissionDAX = (CommissionDAX) getDAX();			
			if (a_alOverrideCommMasterList != null) {
				
              int iSize = a_alOverrideCommMasterList.size();
				for (int i = 0; i < iSize; i++) {
					
					oOverrideCommRuleResult = (OverrideCommRuleResult) a_alOverrideCommMasterList.get(i);
					strStatus = oOverrideCommRuleResult.getStatusFlag();
					Long seq = oOverrideCommRuleResult.getCommRuleOverSeqNbr();								
					if (strStatus.trim().equals(DataConstants.INSERT_MODE)) {
						_oOverrideCommMasterHome.create(oOverrideCommRuleResult);						
					} else if (strStatus.trim().equals(
							DataConstants.UPDATE_MODE)) {	
						
						oOverrideCommMasterPK.setSegSeqNbr(oOverrideCommRuleResult.getCommRuleOverSeqNbr());
						
						_oOverrideCommMaster = _oOverrideCommMasterHome
								.findByPrimaryKey(oOverrideCommMasterPK);
						
						OverrideCommRuleResult oConOverrideCommRuleResult = _oOverrideCommMaster.getOverrideCommResult();
						
						if ((oConOverrideCommRuleResult.getTsDtUpdated() != null)
								&& (!oConOverrideCommRuleResult.getTsDtUpdated().equals(
										oOverrideCommRuleResult.getTsDtUpdated()))) {							
							log.fatal("concurrency failed throwing exception");
							throw new EElixirException("P1100");
						}						
						_oOverrideCommMaster.setOverrideCommResult(oOverrideCommRuleResult);
					} else if (strStatus.trim().equals(
							DataConstants.DELETE_MODE)) {
						_oCommissionDAX.deleteOverrideCommMaster(oOverrideCommRuleResult);
					}

				}
			}
		} catch (CreateException cex) {
			log.fatal(getClass().getName(), "updateOverrideCommMaster ",
					"CreateException " + cex.getMessage());
			_EJBContext.setRollbackOnly();
			throw new EElixirException(cex, "dec201");
		} catch (RemoteException rex) {
			log.fatal(getClass().getName(), "updateOverrideCommMaster ",
					"RemoteException " + rex.getMessage());
			_EJBContext.setRollbackOnly();
			throw new EElixirException(rex, "P1006");
		}catch (EJBException ejbex) {
			log.fatal(getClass().getName(), "updateOverrideCommMaster ",
					"EJBException " + ejbex.getMessage());
			_EJBContext.setRollbackOnly();
			throw (EElixirException) ejbex.getCausedByException();
		} catch (EElixirException eex) {
			log.fatal(getClass().getName(), "updateOverrideCommMaster ",
					"EElixirException " + eex.getMessage());
			_EJBContext.setRollbackOnly();
			throw eex;
		} finally {
			try {
				if (_oConnection != null) {
					DBConnection.closeConnection(_oConnection);
				}
			} catch (EElixirException eElex) {
				log.fatal(getClass().getName(), "updateOverrideCommMaster",
						"EElixirException " + eElex.getMessage());
				throw new EElixirException(eElex, "P1005");
			}
		}

	}
	
	
	/**
	   * Invoked by the session bean to call the DAX method.
	   * @param  a_cChannelType String
	   * @return ArrayList
	   * @throws EElixirException
	   */
	 public String searchProdCodeExists(String strAgencyCode,
     String strProdCd, String dtEffFrom)
	     throws RemoteException, FinderException, EElixirException
	 {	String  strProdCdExists = null;
	     try
	     { 
	    	 _oCommissionDAX = getDAX();
	    	 strProdCdExists = _oCommissionDAX.searchProdCodeExists(strAgencyCode,strProdCd,dtEffFrom);
	     }
	     catch (EJBException ejbex)
	     {
	         log.fatal(getClass().getName(), "searchOverrideCommRuleList ",
	             "EJBException " + ejbex.getMessage());
	         throw new EElixirException(ejbex, "dec202");
	     }
	     catch (EElixirException eLex)
	     {
	         log.fatal(getClass().getName(), "searchOverrideCommRuleList ",
	             "EElixirException " + eLex.getMessage());
	         throw eLex;
	     }
	     finally
	     {
	         try
	         {
	             if (_oConnection != null)
	             {
	                 DBConnection.closeConnection(_oConnection);
	             }
	         }
	         catch (EElixirException eElex)
	         {
	             log.fatal(getClass().getName(), "searchOverrideCommRuleList ",
	                 "EElixirException " + eElex.getMessage());
	             throw eElex;
	         }
	     }
	     return strProdCdExists;
	 } 
 //Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Ends
	 
	 // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Starts
	 public CollectionParamResult saveCollectionParams(CollectionParamResult collectionParamResult) throws FinderException, EElixirException,RemoteException
	 {
		 _oCommissionDAX = (CommissionDAX)getDAX();  
	     log.debug("commissionSLEJB--before saveCollectionParams method of dax object");
	     collectionParamResult = _oCommissionDAX.saveCollectionParams(collectionParamResult);
	     log.debug("commissionSLEJB--after saveCollectionParams	method of dax object");
		 return collectionParamResult;		 
	 } 
	 
	 public CollectionParamResult getCollectionParams() throws FinderException, EElixirException,RemoteException
	 {
		 _oCommissionDAX = (CommissionDAX)getDAX();  
	     log.debug("commissionSLEJB--before getCollectionParams method of dax object");
	     CollectionParamResult collectionParamResult = _oCommissionDAX.getCollectionParams();
	     log.debug("commissionSLEJB--after getCollectionParams	method of dax object");
		 return collectionParamResult;		 
	 } 
     // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Ends	 
	 
	// Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Starts
	public ArrayList getDisbursementSetup() throws FinderException,
			EElixirException, RemoteException {
		_oCommissionDAX = (CommissionDAX) getDAX();
		log.debug("CommissionSLEJB--getDisbursementSetup--Starts");
		ArrayList arrDisbursementSetup = _oCommissionDAX.getDisbursementSetup();
		log.debug("CommissionSLEJB--getDisbursementSetup--Ends");
		return arrDisbursementSetup;
	}

	public void SaveUpdateDisbumSetupDetails(ArrayList _oDisbumSetuplst)
			throws EJBException, EElixirException {
		log.debug("CommissionSLEJB--SaveUpdateDisbumSetupDetails--Starts");
		DisbursementSetupResult oDisbursementSetupResult = null;
		try {
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil
					.getPropertyUtil();
			_oOverridingCommRateHome = (OverridingCommRateHome) objEJBHomeFactory
					.lookUpHome(oCHMPropertyUtil
							.getCHMProperty("OverridingCommRateHome"),
							OverridingCommRateHome.class);
			_oCommissionDAX = (CommissionDAX) getDAX();
			String strStatus = null;
			if (_oDisbumSetuplst != null) {
				for (int i = 0; i < _oDisbumSetuplst.size(); i++) {
					oDisbursementSetupResult = (DisbursementSetupResult) _oDisbumSetuplst
							.get(i);
					strStatus = oDisbursementSetupResult.getstrStatusFlag();
					log.debug("CommissionSLEJB--SaveUpdateDisbumSetupDetails--Status Flag : "+strStatus);
					if (strStatus.trim().equals(DataConstants.INSERT_MODE)) {
						_oCommissionDAX
								.insertDisbumSetup(oDisbursementSetupResult);
					} else if (strStatus.trim().equals(
							DataConstants.UPDATE_MODE)) {
						_oCommissionDAX
								.updateDisbumSetup(oDisbursementSetupResult);
					} else if (strStatus.trim().equals(
							DataConstants.DELETE_MODE)) {
						_oCommissionDAX
								.deleteDisbumSetup(oDisbursementSetupResult);
					}

				}
			}
			log.debug("CommissionSLEJB--SaveUpdateDisbumSetupDetails--Ends");
		} catch (EJBException ejbex) {
			_EJBContext.setRollbackOnly();
			throw new EElixirException(ejbex, "P3049");
		} catch (EElixirException eex) {
			_EJBContext.setRollbackOnly();
			log.debug("CommissionSLEJB--Inside catch of Eelixir exception in SaveUpdateDisbumSetupDetails of CommissionSLEJB");
			throw eex;
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eElex) {
				throw new EElixirException(eElex, "P1005");
			}
		}
	}

	// Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Ends

  /**
   * Attributes declaration
   */
  private CommissionDAX _oCommissionDAX;
  public SessionContext _EJBContext = null;
  private StandardCommission  _oStandardCommission;
  private StandardCommissionHome  _oStandardCommissionHome;
  private ClawBackCommission  _oClawBackCommission;
  private ClawBackCommissionHome  _oClawBackCommissionHome;
  private Connection _oConnection = null;
  private String		   _strCon;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  private OverridingCommRate _oOverridingCommRate;
  private OverridingCommRateHome _oOverridingCommRateHome;
  private CommDispatchHome _oCommDispatchHome=null;
  private CommDispatch _oCommDispatch=null;
//Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 starts
  private OverrideCommMasterHome _oOverrideCommMasterHome;
  private OverrideCommMaster _oOverrideCommMaster = null;
//Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Ends

}