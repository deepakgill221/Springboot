/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME	    : CommDispatchEJB.java
 *  AUTHOR			: Amid P Sahu
 *  VERSION			: 1.0
 *  CREATION DATE   : Feb 18, 2009
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT	    : COPYRIGHT (C) 2009.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *  
 *--------------------------------------------------------------------------------
 *Amid_Fin_156_Upload Of Commission Dispatch
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.commission.dax.CommissionDAX;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.CommDispatchPK;
import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.channelmanagement.csacpa.dax.CsaCpaDAX;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;



/**
 * <p>Title: eElixir</p>
 * <p>Description: This CsaCpa Entity bean retrive data from the database according to seach condition</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */

public class CommDispatchEJB implements EntityBean
{
  /**
   * Attributes declaration
   */
  private EntityContext _oContext;
  private Connection _oConnection = null;
  private CommissionDAX  _oCommissionDAX;
  private CommDispatchResult _oCommDispatchResult= null;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


  /**
   * Constructor for CsaCpaEJB class
   */
  public CommDispatchEJB()
  {

  }

  /**
   * Matching method of the create() method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @return CommDispatchPK
   * @throws CreateException
   * @throws EElixirException
   */
  public CommDispatchPK ejbCreate() throws CreateException, EElixirException
  {
	  CommDispatchPK spk = new CommDispatchPK();

    return spk;

  }

  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate() throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method when the instance is taken out of the pool of available
   * instances to become associated with a specific EJB object. This method transitions
   * the instance to the ready state. This method executes in an unspecified transaction
   * context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * A container invokes this method on an instance before the instance becomes disassociated
   * with a specific EJB object. After this method completes, the container will place
   * the instance into the pool of available instances. This method executes in an unspecified
   * transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by loading it from the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbLoad    ()
  {
	  log.debug("BenefitEJB--ejbLoad() fired");
  }
  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by storing it to the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbStore()
  {    
	  log.debug("inside CommDispatchEJ>>ejbStore");
	try {
	      if(this._oCommDispatchResult != null && this._oCommDispatchResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
		  {	  
	    	   _oCommissionDAX = (CommissionDAX)getDAX();
	    	   log.debug("before calling the updateCommDispatch");
	    	  _oCommissionDAX.updateCommDispatch(_oCommDispatchResult);
	      }
		}
	catch(EElixirException ex)   {
	    log.debug("CommDispatchEJB--ejbStore exception" + ex);
		throw new EJBException(ex);
   }
  finally   {
        try
        {
          if(_oConnection != null)
            DBConnection.closeConnection(_oConnection);
        }
        catch(EElixirException eex)
        {
          throw new EJBException(eex);
        }
      }
    log.debug("CommDispatchEJB--ejbStore done");
  }

  /**
   * A container invokes this method before it removes the EJB object that is currently
   * associated with the instance. It is invoked when a client invokes a remove operation
   * on the enterprise Bean's home or remote interface. It transitions the instance from
   * the ready state to the pool of available instances. It is called in the transaction
   * context of the remove operation.
   * @throws javax.ejb.RemoveException
   */
  public void ejbRemove    ()
  {
  
  }  /**
   * Set the associated entity context. The container invokes this method on an instance
   * after the instance has been created. This method is called in an unspecified transaction
   * context.
   * @param sc
   */
  public void setEntityContext    (EntityContext ctx)
  {
    _oContext = ctx;
  }

  /**
   * Unset the associated entity context. The container calls this method before removing
   * the instance. This is the last method that the container invokes on the instance.
   * The Java garbage collector will  invoke the finalize() method on the instance. It
   * is called in an unspecified transaction context.
   */
  public void unsetEntityContext    ()
  {
    _oContext = null;
  }

  /**
   * Invoked by the container on the instance when the container selects the instance to
   * execute a matching client-invoked find() method. It executes in the transaction
   * context determined by the transaction attribute of the matching find() method.
   * @return CsaCpaCriteriaPK
   * @param a_CsaCpaCriteriaPK CsaCpaCriteriaPK
   * @throws javax.ejb.FinderException
   * @throws EElixirException
   */
  public CommDispatchPK ejbFindByPrimaryKey(CommDispatchPK a_CommDispatchPK) throws FinderException,EElixirException
  {
    try{
    	_oCommissionDAX = getDAX();
         boolean bFlag = _oCommissionDAX.findCommDispatchBySeqNo(a_CommDispatchPK.getCommDispatchSeqNbr().longValue());
        if(bFlag){
        	 log.debug("inside if before return a_CommDispatchSLEJB");
          return a_CommDispatchPK;
        }
       else
        throw new EElixirException("P7123"); 
     }
     catch(EElixirException eex)
     {
      throw new EJBException(eex);
     }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
  }


  /**
   * Gets the Dax object and sets the connection on it.
   * @return SegmentDAX
   * @throws EElixirException
   */
    private CommissionDAX getDAX() throws EElixirException
    {
    	_oConnection = DBConnection.getConnection();
        CHMDAXFactory theCHMDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        CommissionDAX _oCommissionDAX = (CommissionDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.COMMISSIONDAX);
        _oCommissionDAX.setConnection(_oConnection);
        return _oCommissionDAX;      
    }

  public CommDispatchResult getCommDispatchResult() throws  EElixirException
  {
    return _oCommDispatchResult;
  }

  public void setCommDispatchResult(CommDispatchResult a_oCommDispatchResult) throws  EElixirException
  {
    this._oCommDispatchResult = a_oCommDispatchResult;
  }


}