/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME		: OverrideCommMasterEJB.java
 *  AUTHOR			: Anup Kumar
 *  VERSION			: 1.0
 *  CREATION DATE	: Sep 10, 2009
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		: COPYRIGHT (C) 2002.
 *  CODETAG 		: Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *  
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import com.mastek.eElixir.channelmanagement.commission.dax.CommissionDAX;
import com.mastek.eElixir.channelmanagement.commission.util.OverrideCommRuleResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>
 * Title: eElixir
 * </p>
 * <p>
 * Description: This OverrideCommMaster Entity bean retrive data from the database
 * according to seach condition
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: Mastek Ltd
 * </p>
 * 
 * @author Anup Kumar
 * @version 1.0
 */

public class OverrideCommMasterEJB implements EntityBean {
	/**
	 * Attributes declaration
	 */
	private EntityContext _oContext;

	private Connection _oConnection = null;

	
	private CommissionDAX _oCommissionDAX;

	private OverrideCommRuleResult _oOverrideCommResult;

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	/**
	 * Constructor for OverrideCommMasterEJB class
	 */
	public OverrideCommMasterEJB() {

	}

	/**
	 * Matching method of the create() method of the bean's home interface. The
	 * container invokes an ejbCreate method to create an entity object. It
	 * executes in the transaction context determined by the
	 * transactionattribute of the matching create() method.
	 * 
	 * @return OverrideCommMasterPK
	 * @throws CreateException
	 * @throws EElixirException
	 */
	public OverrideCommMasterPK ejbCreate() throws CreateException, EElixirException {
		OverrideCommMasterPK apk = new OverrideCommMasterPK();

		return apk;

	}

	/**
	 * Matching method of the create(OverrideCommResult a_oOverrideCommResult)
	 * method of the bean's home interface. The container invokes an ejbCreate
	 * method to create an entity object. It executes in the transaction context
	 * determined by the transactionattribute of the matching create() method.
	 * 
	 * @param a_oOverrideCommResult
	 * @return OverrideCommMasterPK
	 * @throws javax.ejb.CreateException
	 * @throws EElixirException
	 * @author Anup Kumar
	 */
	public OverrideCommMasterPK ejbCreate(OverrideCommRuleResult a_oOverrideCommResult)
			throws CreateException, EElixirException {
		OverrideCommMasterPK _pkOverrideCommMasterPK = null;
		try {


			_oCommissionDAX = getDAX();			
			Long lOverrideCommseqnbt = _oCommissionDAX.createOverrideCommMaster(a_oOverrideCommResult);
			_pkOverrideCommMasterPK = new OverrideCommMasterPK();
			_pkOverrideCommMasterPK.setSegSeqNbr(lOverrideCommseqnbt);

		} catch (EElixirException eex) {
			throw eex;
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eElex) {
				throw new EElixirException(eElex, "P1005");
			}
		}
		return _pkOverrideCommMasterPK;
	}

	/**
	 * Matching method of ejbCreate. The container invokes the matching
	 * ejbPostCreate method on an instance after it invokes the ejbCreate method
	 * with the same arguments. It executes in the same transaction context as
	 * that of the matching ejbCreate method.
	 * 
	 * @throws javax.ejb.CreateException
	 * @throws EElixirException
	 */
	public void ejbPostCreate() throws CreateException, EElixirException {

	}

	/**
	 * Matching method of ejbCreate. The container invokes the matching
	 * ejbPostCreate method on an instance after it invokes the ejbCreate method
	 * with the same arguments. It executes in the same transaction context as
	 * that of the matching ejbCreate method.
	 * 
	 * @param _a_oOverrideCommResult
	 * @throws javax.ejb.CreateException
	 * @throws EElixirException
	 */
	public void ejbPostCreate(OverrideCommRuleResult a_oOverrideCommResult) throws CreateException,
			EElixirException {

	}

	/**
	 * A container invokes this method when the instance is taken out of the
	 * pool of available instances to become associated with a specific EJB
	 * object. This method transitions the instance to the ready state. This
	 * method executes in an unspecified transaction context.
	 */
	public void ejbActivate() {

	}

	/**
	 * A container invokes this method on an instance before the instance
	 * becomes disassociated with a specific EJB object. After this method
	 * completes, the container will place the instance into the pool of
	 * available instances. This method executes in an unspecified transaction
	 * context.
	 */
	public void ejbPassivate() {

	}

	/**
	 * A container invokes this method to instruct the instance to synchronize
	 * its state by loading it from the underlying database. This method always
	 * executes in the transaction context determined by the value of the
	 * transaction attribute in the deployment descriptor.
	 */
	public void ejbLoad() {
		OverrideCommMasterPK _OverrideCommMasterPK = (OverrideCommMasterPK) _oContext.getPrimaryKey();
		try {
			log.debug("Inside ejbLoad");
			//_oOverrideCommResult = new OverrideCommResult();			
			_oCommissionDAX = (CommissionDAX)getDAX();			
			_oOverrideCommResult = _oCommissionDAX.getSearchOverrideCommMaster(_OverrideCommMasterPK.getSegSeqNbr().longValue());			
			
		} catch (EElixirException eex) {
			throw new EJBException(eex);
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eex) {
				throw new EJBException(eex);
			}
		}
	}

	/**
	 * A container invokes this method to instruct the instance to synchronize
	 * its state by storing it to the underlying database. This method always
	 * executes in the transaction context determined by the value of the
	 * transaction attribute in the deployment descriptor.
	 */
	public void ejbStore() {
		log.debug("OverrideCommMasterEJB--ejbStore() fired");
		/* CHANGE TO AVOID UPDATE */
		try {
			if (this._oOverrideCommResult != null
					&& this._oOverrideCommResult.getIsDirty().equals(
							DataConstants.UPDATE_MODE)) {
				_oCommissionDAX = (CommissionDAX)getDAX();
				_oCommissionDAX.updateOverrideCommMaster(_oOverrideCommResult);
			}
		} catch (EElixirException ex) {
			log.debug("updateOverrideCommMaster--ejbStore exception" + ex);
			throw new EJBException(ex);
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eex) {
				throw new EJBException(eex);
			}
		}
	}

	/**
	 * A container invokes this method before it removes the EJB object that is
	 * currently associated with the instance. It is invoked when a client
	 * invokes a remove operation on the enterprise Bean's home or remote
	 * interface. It transitions the instance from the ready state to the pool
	 * of available instances. It is called in the transaction context of the
	 * remove operation.
	 * 
	 * @throws javax.ejb.RemoveException
	 */
	public void ejbRemove() {
		try {
			_oCommissionDAX = (CommissionDAX)getDAX();			
			_oCommissionDAX.deleteOverrideCommMaster(_oOverrideCommResult);
		} catch (EElixirException ex) {
			log.debug("OverrideCommMasterEJB----ejbRemove   ()--EEEx");
			throw new EJBException(ex);
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eex) {
				throw new EJBException(eex);
			}
		}
	}

	/**
	 * Set the associated entity context. The container invokes this method on
	 * an instance after the instance has been created. This method is called in
	 * an unspecified transaction context.
	 * 
	 * @param sc
	 */
	public void setEntityContext(EntityContext ctx) {
		_oContext = ctx;
	}

	/**
	 * Unset the associated entity context. The container calls this method
	 * before removing the instance. This is the last method that the container
	 * invokes on the instance. The Java garbage collector will invoke the
	 * finalize() method on the instance. It is called in an unspecified
	 * transaction context.
	 */
	public void unsetEntityContext() {
		_oContext = null;
	}

	/**
	 * Invoked by the container on the instance when the container selects the
	 * instance to execute a matching client-invoked find() method. It executes
	 * in the transaction context determined by the transaction attribute of the
	 * matching find() method.
	 * 
	 * @return ChannelPK
	 * @param a_ChannelPK
	 *            ChannelPK
	 * @throws javax.ejb.FinderException
	 * @throws EElixirException
	 */
	public OverrideCommMasterPK ejbFindByPrimaryKey(OverrideCommMasterPK a_OverrideCommMasterPK) throws FinderException,
			EElixirException {
		try {
			log.debug("Inside ejbFindByPrimaryKey");
			_oCommissionDAX = getDAX();
			boolean bFlag = _oCommissionDAX.findOverrideCommMaster(a_OverrideCommMasterPK
					.getSegSeqNbr().longValue());
			log.debug("Inside ejbFindByPrimaryKey>>bFlag>>"+bFlag);
			if (bFlag) {			
				return a_OverrideCommMasterPK;
			} else
				throw new EElixirException("dec203");
		} catch (EElixirException eex) {
			throw new EJBException(eex);
		} finally {
			try {
				if (_oConnection != null)
					DBConnection.closeConnection(_oConnection);
			} catch (EElixirException eElex) {
				throw new EElixirException(eElex, "P1005");
			}
		}
	}

	/**
	 * Gets the Dax object and sets the connection on it.
	 * 
	 * @return CommissionDAX
	 * @throws EElixirException
	 */
	private CommissionDAX getDAX() throws EElixirException {
		_oConnection = DBConnection.getConnection();
		CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory
				.getDAXFactory();
		CommissionDAX _oCommissionDAX = (CommissionDAX) theDAXFactory
				.createDAX(theDAXFactory.COMMISSIONDAX);
		_oCommissionDAX.setConnection(_oConnection);
		return _oCommissionDAX;
	}

	public OverrideCommRuleResult getOverrideCommResult()
			throws EElixirException {		
		return _oOverrideCommResult;
	}

	public void setOverrideCommResult(OverrideCommRuleResult a_oOverrideCommResult)
			throws EElixirException {		
		this._oOverrideCommResult = a_oOverrideCommResult;
	}

}