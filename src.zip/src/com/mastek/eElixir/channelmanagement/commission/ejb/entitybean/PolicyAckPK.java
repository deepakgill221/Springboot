/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : PolicyAckPK.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_policy_ackn_upd.doc.doc
*  CREATION DATE                  : 29/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.io.Serializable;


public class PolicyAckPK implements Serializable
{
    public String _strPolNbr;
    public String _strServAgentCd;

    /**
     * Constructor
     */
    public PolicyAckPK()
    {
    }

    /**
     * Constructor
     * @param a_strParamCd String, a_iParamTypeCd int
     */
    public PolicyAckPK(String a_strPolNbr, String a_strServAgentCd)
    {
        this._strPolNbr = a_strPolNbr;
        this._strServAgentCd = a_strServAgentCd;
    }

    /**
     * Referencing to object that represents the entity object.
     * @return integer value
     */
    public int hashCode()
    {
		int iHashCode = (_strPolNbr == null || _strServAgentCd == null)?0:_strPolNbr.hashCode() + _strServAgentCd.hashCode();
		return iHashCode;
    }

    /**
     * Method that compares two entity object references -- since the Java Object.equals(Object
     * obj) method is unspecified.
     * @return boolean
     */
    public boolean equals(Object obj)
    {
        boolean bEqual = false;

        if (obj!=null && obj instanceof PolicyAckPK)
        {
            bEqual = this._strPolNbr.equals(((PolicyAckPK) obj)._strPolNbr) &&
                this._strServAgentCd.equals(((PolicyAckPK) obj)._strServAgentCd);
        }

        return bEqual;
    }

    /**
     * Own toString() method of a bean's PK class.
     * @return String
     */
    public String toString()
    {
        return this._strPolNbr + ":::" + this._strServAgentCd;
    }
}
