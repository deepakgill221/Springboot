/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: FinderFeesMapEJB.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: Dec 03, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2004.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY           REASON
 *-------------------------------------------------------------------------------- 
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.commission.dax.FinderFeesMapDAX;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesMapResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: EElixir</p>
 * <p>Description: FinderFeesMappingEJB is the local entity bean implementation of a FinderFeesMapping.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: MASTEK</p>
 * @version 1.0
 */

public class FinderFeesMapEJB implements EntityBean
{

	/**
	 * Constructor for FinderFeesMappingEJB class
	 */
	public FinderFeesMapEJB    ()
	{

	}

	/**
	 * Matching method of the create() method of the bean's home interface. The container
	 * invokes an ejbCreate method to create an entity object. It executes in the transaction
	 * context determined by the transactionattribute of the matching create() method.
	 * @return FinderFeesMappingPK
	 * @throws javax.ejb.CreateException
	 */
	public FinderFeesMapPK ejbCreate    () throws CreateException
	{
	  FinderFeesMapPK cpk = new FinderFeesMapPK();

	  return cpk;

	}

	/**
	 * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
	 * on an instance after it invokes the ejbCreate method with the same arguments. It
	 * executes in the same transaction context as that of the matching ejbCreate method.
	 * @throws javax.ejb.CreateException
	 */
	public void ejbPostCreate    () throws CreateException
	{

	}
	/**
	 * A container invokes this method when the instance is taken out of the pool of available
	 * instances to become associated with a specific EJB object. This method transitions
	 * the instance to the ready state. This method executes in an unspecified transaction
	 * context.
	 */
	public void ejbActivate    ()
	{

	}

	/**
	 * A container invokes this method on an instance before the instance becomes disassociated
	 * with a specific EJB object. After this method completes, the container will place
	 * the instance into the pool of available instances. This method executes in an unspecified
	 * transaction context.
	 */
	public void ejbPassivate    ()
	{

	}

	/**
	 * A container invokes this method to instruct the instance to synchronize its state
	 * by loading it from the underlying database. This method always executes in the transaction
	 * context determined by the value of the transaction attribute in the deployment descriptor.
	 */
	public void ejbLoad    ()
	{
	   log.debug("FinderFeesMap - ejbload fired");
	   FinderFeesMapPK pkFinderFeesMap = (FinderFeesMapPK)EJB_Context.getPrimaryKey();
	   try
	   {
		 _oFinderFeesMapResult = new  FinderFeesMapResult();
		 FinderFeesMapDAX _oFinderFeesMapDAX = (FinderFeesMapDAX)getDAX();
		_oFinderFeesMapResult = _oFinderFeesMapDAX.getFinderFeesMap(pkFinderFeesMap.getLFFMapSeqNbr());
		log.debug("From date in ejbLoad" + DateUtil.retStrDate(_oFinderFeesMapResult.getEffFrom()));
	   }
	   catch(EElixirException ex)
	   {
		 throw new EJBException(ex.getMessage());
	   }
	   finally
	   {
		 try
		 {
		   if(_oConnection != null)
			 DBConnection.closeConnection(_oConnection);
		 }
		 catch(EElixirException eex)
		 {
		   throw new EJBException(eex);
		 }
	  }
	}

	/**
	 * A container invokes this method to instruct the instance to synchronize its state
	 * by storing it to the underlying database. This method always executes in the transaction
	 * context determined by the value of the transaction attribute in the deployment descriptor.
	 */
	public void ejbStore    ()
	{

	  log.debug("ejbstore fired");
	  /* CHANGE TO AVOID UPDATE  */
	  if(this._oFinderFeesMapResult != null && this._oFinderFeesMapResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
	  {
		try
		{
		  log.debug("in ejbejbsore");
		  log.debug("Contract name in ejbstore"+ _oFinderFeesMapResult.getContractName());
		  FinderFeesMapDAX _oFinderFeesMapDAX = getDAX();
		  _oFinderFeesMapDAX.updateFinderFeesMap(_oFinderFeesMapResult);		  
		  log.debug("From date in ejbstore" + DateUtil.retStrDate(_oFinderFeesMapResult.getEffFrom()));
		}
		catch(EElixirException ex)
		{
		  throw new EJBException(ex);
		}
		finally
		{
		  try
		  {
			if(_oConnection != null)
			  DBConnection.closeConnection(_oConnection);
		  }
		  catch(EElixirException eex)
		  {
			throw new EJBException(eex);
		  }
		}
	  }

	}

	/**
	 * A container invokes this method before it removes the EJB object that is currently
	 * associated with the instance. It is invoked when a client invokes a remove operation
	 * on the enterprise Bean's home or remote interface. It transitions the instance from
	 * the ready state to the pool of available instances. It is called in the transaction
	 * context of the remove operation.
	 * @throws javax.ejb.RemoveException
	 */
	public void ejbRemove    () throws RemoveException
	{

	}

	/**
	 * Set the associated entity context. The container invokes this method on an instance
	 * after the instance has been created. This method is called in an unspecified transaction
	 * context.
	 */
	public void setEntityContext    (EntityContext ctx)
	{
	  this.EJB_Context = ctx;
	}

	/**
	 * Unset the associated entity context. The container calls this method before removing
	 * the instance. This is the last method that the container invokes on the instance.
	 * The Java garbage collector will  invoke the finalize() method on the instance. It
	 * is called in an unspecified transaction context.
	 */
	public void unsetEntityContext    ()
	{

	}

	/**
	 * Invoked by the container on the instance when the container selects the instance to
	 * execute a matching client-invoked find() method. It executes in the transaction
	 * context determined by the transaction attribute of the matching find() method.
	 * @return ApplicationPK
	 * @throws javax.ejb.FinderException
	 */

	public FinderFeesMapPK ejbFindByPrimaryKey    (FinderFeesMapPK cmPK) throws  FinderException, EElixirException
	{

	  try{

		FinderFeesMapDAX _oFinderFeesMapDAX = getDAX();
		log.debug("calling dax" );
		//make a call to verify if primary key is present
		log.debug("Before callling DAX:"  + cmPK.getLFFMapSeqNbr() );
				boolean bFlag = _oFinderFeesMapDAX.searchFinderFeesMap(cmPK.getLFFMapSeqNbr());
		if(bFlag)
		{
		  log.debug("Returning FinderFeesMap Primary Key");
		  return cmPK;
		}
		else
		   throw new EElixirException("P3036"); // to be decided
	  }


		//this.setAdjustmentResult(oAdjustmentResult);

	  catch(EElixirException eex)
		{
		  throw eex;
		}
		finally{
		  try{
			if(_oConnection != null)
			  DBConnection.closeConnection(_oConnection);
		  }
		  catch(EElixirException eElex){
			throw new EElixirException(eElex, "P1005");
		  }
		}


 }


 private FinderFeesMapDAX getDAX() throws EElixirException
 {
		_oConnection = DBConnection.getConnection();
		CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
		FinderFeesMapDAX _oFinderFeesMapDAX = (FinderFeesMapDAX)theDAXFactory.createDAX(CHMDAXFactory.FINDERFEESMAPDAX);
		_oFinderFeesMapDAX.setConnection(_oConnection);

	   return _oFinderFeesMapDAX;
  }
	/**
	 * Gets the Data from the FinderFeesMappingSlEJB
	 * @param Request HttpServletRequest
	 * @return Collection object
	 * @throws EElixirException
	 */



  public FinderFeesMapPK ejbCreate(FinderFeesMapResult a_oFinderFeesMapResult) throws CreateException, EElixirException
  {
	try
	{
	   FinderFeesMapDAX _oFinderFeesMapDAX = getDAX();
	   _oFinderFeesMapDAX.insertFinderFeesMap(a_oFinderFeesMapResult);
	   FinderFeesMapPK  cmpk = new FinderFeesMapPK(a_oFinderFeesMapResult.getFFMapSeqNbr().longValue());
	   return cmpk;
	}
	catch(EElixirException eex)
	{
	  log.debug("In FINDERFEESMAPEJB ELIXIR EXCEPTION");
	  throw eex;
	}
	finally{
	  try{
		if(_oConnection != null)
		  DBConnection.closeConnection(_oConnection);
	  }
	  catch(EElixirException eElex)
	  {
		throw new EElixirException(eElex,"P1005");
	  }
	}

  }

  public void ejbPostCreate(FinderFeesMapResult a_oFinderFeesMapResult) throws CreateException, EElixirException
  {
	;

  }

  public FinderFeesMapResult getFinderFeesMapResult() throws  EElixirException
  {
	return this._oFinderFeesMapResult;
  }

  public void setFinderFeesMapResult(FinderFeesMapResult a_oFinderFeesMapResult) throws EElixirException
  {
	this._oFinderFeesMapResult = a_oFinderFeesMapResult;
  }

  /**
   * Attributes declaration
   */
  private EntityContext EJB_Context;
  private Connection _oConnection = null;
  private DataSource _oDatasource = null;
  private FinderFeesMapDAX  _oFinderFeesMappingDAX;
  private FinderFeesMapResult _oFinderFeesMapResult;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);




}


