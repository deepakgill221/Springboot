/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: StandardCommissionPK.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.io.Serializable;

/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the StandardCommissionPK which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
  */
   public class StandardCommissionPK implements Serializable
{

    /**
     * Referencing to object that represents the entity object.
     * @return integer value
     */
    public int hashCode    ()
    {
      int iHashcode=0;
      if(new Long(_lAgrmtSCSeqNbr)!= null)
      iHashcode= new Long(_lAgrmtSCSeqNbr).hashCode();
      return iHashcode;
    }

    /**
     * Method that compares two entity object references -- since the Java Object.equals(Object
     * obj) method is unspecified.
     * @return boolean
     */
    public boolean equals    (java.lang.Object obj)
    {
      boolean bEqual=false;
   	  if(obj!=null && obj instanceof StandardCommissionPK)
	  {
       if (this._lAgrmtSCSeqNbr  ==  ((StandardCommissionPK)obj)._lAgrmtSCSeqNbr)
       {
         bEqual = true;
       }
	  }
    return bEqual;
    }

    /**
     * Own toString() method of a bean's PK class.
     * @return String
     */
    public java.lang.String toString    ()
    {
    return null;
    }

    /**
     *  Method to access the Seq No field
     *
     */
     public long getAgrmtSCSeqNbr()
     {
      return this._lAgrmtSCSeqNbr;
     }

    /**
     *  Method to set value of the Seq No field
     *
     */
     public void setAgrmtSCSeqNbr(long a_lAgrmtSCSeqNbr)
     {
      this._lAgrmtSCSeqNbr = a_lAgrmtSCSeqNbr;
     }

    /**
     * Constructor
     */
    public StandardCommissionPK    ()
    {

    }

    /**
     * Constructor
     * @param a_lAgrmtSCSeqNbr long
     */

    public StandardCommissionPK    (long a_lAgrmtSCSeqNbr)
    {
      this._lAgrmtSCSeqNbr = a_lAgrmtSCSeqNbr;
    }

   private long _lAgrmtSCSeqNbr;


}