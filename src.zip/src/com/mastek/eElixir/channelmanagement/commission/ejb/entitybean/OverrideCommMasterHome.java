/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: OverrideCommMasterHome.java
*  AUTHOR			: Anup Kumar
*  VERSION			: 1.0
*  CREATION DATE	: Sep 10, 2009
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.
*  CODETAG 		: Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;
import com.mastek.eElixir.channelmanagement.commission.util.OverrideCommRuleResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This OverrideCommMaster home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Santosh Pandya
 * @version 1.0
 */


public interface OverrideCommMasterHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @throws javax.ejb.FinderException
   */

  public OverrideCommMaster findByPrimaryKey(OverrideCommMasterPK primaryKey)
      throws FinderException, RemoteException, EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @return OverrideCommMaster
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public OverrideCommMaster create() throws CreateException, RemoteException, EElixirException;


  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class
   * @param a_oOverrideCommResult OverrideCommResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public OverrideCommMaster create(OverrideCommRuleResult a_oOverrideCommRuleResult) throws CreateException, RemoteException, EElixirException;


}