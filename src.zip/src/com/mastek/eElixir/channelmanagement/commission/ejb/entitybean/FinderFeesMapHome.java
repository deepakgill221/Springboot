/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Channel Management
*  FILENAME			: FinderFeesMapHome.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: Dec 03, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2004.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY           REASON
 *-------------------------------------------------------------------------------- 
 *
 *********************************************************************/
 

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesMapResult;
import com.mastek.eElixir.common.exception.EElixirException;



/**
	 * <p>Title: eElixir</p>
	 * <p>Description:This is a home interface for FinderFeesMap entity bean.</p>
	 * <p>Copyright: Copyright (c) 2002</p>
	 * <p>Company: Mastek Ltd</p>
	 * @version 1.0
	 */


public interface FinderFeesMapHome extends EJBHome
{
	/**
	 * Called by the client to find an EJB bean instance, usually find by primary key
	 * @returns FinderFeesMappingLocal reference
	 * @param a_pkFinderFeesMapping FinderFeesMappingPK primary key
	 * @throws java.rmi.FinderException
	 */

	public FinderFeesMap findByPrimaryKey   (FinderFeesMapPK a_pkFinderFeesMapping)
				throws FinderException, RemoteException, EElixirException;


	/**
	 * Called by the client to create an EJB bean instance. It requires a matching pair in
	 * the bean class, i.e. ejbCreate().
	 * @returns FinderFeesMappingLocal
	 * @throws java.rmi.RemoteException
	 * @throws javax.ejb.CreateException
	 */
	public FinderFeesMap create() throws CreateException, RemoteException;




	public FinderFeesMap create(FinderFeesMapResult a_oFinderFeesMapResult) throws CreateException, RemoteException, EElixirException;
}