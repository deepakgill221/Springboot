/********************************************************************
 *
 *  PROJECT			: Amal
 *  MODULE NAME		        : Customer Development
 *  FILENAME			: OverridingCommRateEJB
 *  AUTHOR			: Pallav
 *  VERSION			: 1.0
 *  CREATION DATE	        : Mar 3, 2003
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.commission.dax.CommissionDAX;
import com.mastek.eElixir.channelmanagement.commission.util.OverridingCommRateDetail;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;



/**
 * <p>Title: eElixir</p>
 * <p>Description: This Unit Entity bean retrive data from the database according to seach condition</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class OverridingCommRateEJB implements EntityBean
{
  /**
   * Attributes declaration
   */
  private EntityContext _oContext;
  private Connection _oConnection = null;
  private DataSource _oDatasource = null;
  private CommissionDAX  _oCommissionDAX;
  private OverridingCommRateDetail _oOverridingCommRateDetail;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  private ArrayList _arrUnit;


  /**
   * Constructor for BenefitEJB class
   */
  public OverridingCommRateEJB    ()
  {

  }

  /**
   * Matching method of the create() method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @return OverridingCommRatePK
   * @throws CreateException
   * @throws EElixirException
   */
  public OverridingCommRatePK ejbCreate    () throws CreateException, EElixirException, RemoteException
  {
    OverridingCommRatePK ocrpk = new OverridingCommRatePK();

    return ocrpk;

  }

  /**
   * Matching method of the create(OverridingCommRateDetail a_oOverridingCommRateDetail) method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @param  a_oOverridingCommRateDetail OverridingCommRateDetail
   * @return OverridingCommRatePK
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public OverridingCommRatePK ejbCreate   (OverridingCommRateDetail a_oOverridingCommRateDetail) throws CreateException, EElixirException,RemoteException
  {
    OverridingCommRatePK ocrpk = null;
    //String strUser = null;
    //strUser = this._oContext.getCallerPrincipal().getName();
    try{
      _oCommissionDAX = getDAX();
      log.debug("OverridingCommRateEJB--before getUnit method of dax object");
      //a_oOverridingCommRateDetail.setUserId(strUser);
      long lAgrmtRateSeqNbr = _oCommissionDAX.createOverridingCommRate(a_oOverridingCommRateDetail);
      log.debug("OverridingCommRateEJB--after getUnit method of dax object");
      //upk = new OverridingCommRatePK(a_oOverridingCommRateDetail.getUnitId());
	  ocrpk = new OverridingCommRatePK(lAgrmtRateSeqNbr);
      //cpk.setBenSeqNbr(lbenseqnbr);
      //log.debug("OverridingCommRateEJB--Key in entiy bean is " + bpk.getBenSeqNbr());
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex, "P1005");
      }
    }
    return ocrpk;
  }

  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate    () throws CreateException, EElixirException
  {

  }


  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @param a_oOverridingCommRateDetail OverridingCommRateDetail
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate    (OverridingCommRateDetail a_oOverridingCommRateDetail) throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method when the instance is taken out of the pool of available
   * instances to become associated with a specific EJB object. This method transitions
   * the instance to the ready state. This method executes in an unspecified transaction
   * context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * A container invokes this method on an instance before the instance becomes disassociated
   * with a specific EJB object. After this method completes, the container will place
   * the instance into the pool of available instances. This method executes in an unspecified
   * transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by loading it from the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbLoad    ()
  {
    log.debug("OverridingCommRateEJB--ejbLoad() fired");
    OverridingCommRatePK ocrPK = (OverridingCommRatePK)_oContext.getPrimaryKey();
    try
    {
      //_oOverridingCommRateDetail = new  OverridingCommRateDetail();
      _oCommissionDAX = (CommissionDAX)getDAX();
      log.debug("OverridingCommRateEJB--Before Calling getOverridingCommRate on CommissionDAX");
      log.debug("OverridingCommRateEJB-- Inside load for seqNo");
      _oOverridingCommRateDetail = _oCommissionDAX.getOverridingCommRate(ocrPK.getAgrmtRateSeqNbr());
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eex)
      {
        throw new EJBException(eex);
      }
    }
  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by storing it to the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbStore    ()
  {
    log.debug("OverridingCommRateEJB--ejbStore() fired");
    //String strUser = null;
    //strUser = this._oContext.getCallerPrincipal().getName();
	/* CHANGE TO AVOID UPDATE  */
    if(this._oOverridingCommRateDetail != null && this._oOverridingCommRateDetail.getIsDirty().equals(DataConstants.UPDATE_MODE))
    {
    try
      {
      log.debug("OverridingCommRateEJB--inside ejbStore");
      _oCommissionDAX = (CommissionDAX)getDAX();
      log.debug("OverridingCommRateEJB--after getting dax" + _oOverridingCommRateDetail);
      //_oOverridingCommRateDetail.setUserId(strUser);
      _oCommissionDAX.updateOverridingCommRate(_oOverridingCommRateDetail);
      log.debug("OverridingCommRateEJB--After updating OverridingCommRate");
      }
      catch(EElixirException ex)
      {
        throw new EJBException(ex);
      }
      finally
      {
        try
        {
          if(_oConnection != null)
            DBConnection.closeConnection(_oConnection);
        }
        catch(EElixirException eex)
        {
          throw new EJBException(eex);
        }
      }
    }
  }

  /**
   * A container invokes this method before it removes the EJB object that is currently
   * associated with the instance. It is invoked when a client invokes a remove operation
   * on the enterprise Bean's home or remote interface. It transitions the instance from
   * the ready state to the pool of available instances. It is called in the transaction
   * context of the remove operation.
   * @throws javax.ejb.RemoveException
   */
  public void ejbRemove    ()
  {

    log.debug("OverridingCommRateEJB--ejbRemove() fired");
    try
    {
      _oCommissionDAX = getDAX();
      _oCommissionDAX.removeOverridingCommRate(((OverridingCommRatePK)(_oContext.getPrimaryKey())).getAgrmtRateSeqNbr());
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eex)
      {
        throw new EJBException(eex);
      }
    }
  }

  /**
   * Set the associated entity context. The container invokes this method on an instance
   * after the instance has been created. This method is called in an unspecified transaction
   * context.
   * @param ctx EntityContext
   */
  public void setEntityContext    (EntityContext ctx)
  {
    _oContext = ctx;
  }

  /**
   * Unset the associated entity context. The container calls this method before removing
   * the instance. This is the last method that the container invokes on the instance.
   * The Java garbage collector will  invoke the finalize() method on the instance. It
   * is called in an unspecified transaction context.
   */
  public void unsetEntityContext    ()
  {
    _oContext = null;
  }

  /**
   * Invoked by the container on the instance when the container selects the instance to
   * execute a matching client-invoked find() method. It executes in the transaction
   * context determined by the transaction attribute of the matching find() method.
   * @return OverridingCommRatePK
   * @param a_OverridingCommRatePK OverridingCommRatePK
   * @throws javax.ejb.FinderException
   * @throws EElixirException
   */
  public OverridingCommRatePK ejbFindByPrimaryKey    (OverridingCommRatePK a_OverridingCommRatePK) throws FinderException,EElixirException, RemoteException
  {
    try{
      log.debug("OverridingCommRateEJB--Inside Findby primary key of OverridingCommRateEJB");
      _oCommissionDAX = getDAX();
      boolean bFlag = _oCommissionDAX.findOverridingCommRate(a_OverridingCommRatePK.getAgrmtRateSeqNbr());
      log.debug("OverridingCommRateEJB--After find OverridingCommRate of Seq No" + a_OverridingCommRatePK.getAgrmtRateSeqNbr());
      if(bFlag){
        log.debug("OverridingCommRateEJB--Returning OverridingCommRate Primary Key");
        return a_OverridingCommRatePK;
      }
      else
        throw new EElixirException("P3052"); //@todo change this error code
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw eElex;
      }
    }
  }


  /**
  * Method to generate the ContractList  depending on the search criteria
  * entered by the user.
  * @param a_lPriKey long
  * @return ArrayList
  * @throws EElixirException
  */
  /*public ArrayList ejbHomeGetAllOverridingCommRate(long a_lPriKey) throws EElixirException
  {
    ArrayList arrOverridingCommRate = null;
    try
    {
      _oCommissionDAX = getDAX();
      arrOverridingCommRate = _oCommissionDAX.getAllOverridingCommRate(a_lPriKey);
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex)
      {
        throw eElex;
      }
    } // end of finally block
    return arrOverridingCommRate;
  }*/



  /**
   * Gets the Dax object and sets the connection on it.
   * @return CommissionDAX
   * @throws EElixirException
   */
  private CommissionDAX getDAX() throws EElixirException
  {
      try{
          if(_oConnection == null || _oConnection.isClosed()){
              _oConnection = DBConnection.getConnection();
          }
          log.debug("_oConnection:" + _oConnection);
          _oCommissionDAX = new CommissionDAX();
          _oCommissionDAX.setConnection(_oConnection);
      }
      catch(SQLException sqlEx)
      {
          throw new EElixirException(sqlEx, sqlEx.getMessage());
      }
      return _oCommissionDAX;
  }

  public OverridingCommRateDetail getOverridingCommRateResult() throws  EElixirException
  {
    return _oOverridingCommRateDetail;
  }

  public void setOverridingCommRateResult(OverridingCommRateDetail a_oOverridingCommRateDetail) throws  EElixirException
  {
    this._oOverridingCommRateDetail = a_oOverridingCommRateDetail;
  }


}