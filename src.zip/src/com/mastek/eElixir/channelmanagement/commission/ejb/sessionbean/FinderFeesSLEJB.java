/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Finder Fees
*  FILENAME			: FinderFeesSLEJB.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: November 10, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.EJBException;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.commission.dax.FinderFeesDAX;
import com.mastek.eElixir.channelmanagement.commission.dax.FinderFeesMapDAX;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesMapResult;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.FinderFees;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.FinderFeesHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.FinderFeesMap;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.FinderFeesMapHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.FinderFeesMapPK;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.FinderFeesPK;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.common.util.DBConnection;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;

import com.mastek.eElixir.common.util.SearchData;
/**
 * <p>Title: eElixir</p>
 * <p>Description: This FinderFees session bean acts as an interface for the FinderFees bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class FinderFeesSLEJB implements SessionBean
{

  /**
   * Constructor of the CommissionSLEJB class
   */
  public FinderFeesSLEJB()
  {

  }

  /**
   * Called by the container to create a session bean instance. Its parameters typically
   * contain the information the client uses to customize the bean instance for its use.
   * It requires a matching pair in the bean class and its home interface.
   * @throws CreateException
   * @throws EElixirException
   */
  public void ejbCreate    () throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method before it ends the life of the session object. This
   * happens as a result of a client's invoking a remove operation, or when a container
   * decides to terminate the session object after a timeout. This method is called with
   * no transaction context.
   */
  public void ejbRemove    ()
  {

  }

  /**
   * The activate method is called when the instance is activated from its 'passive' state.
   * The instance should acquire any resource that it has released earlier in the ejbPassivate()
   * method. This method is called with no transaction context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * The passivate method is called before the instance enters the 'passive' state. The
   * instance should release any resources that it can re-acquire later in the ejbActivate()
   * method. After the passivate method completes, the instance must be in a state that
   * allows the container to use the Java Serialization protocol to externalize and store
   * away the instance's state. This method is called with no transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * Set the associated session context. The container calls this method after the instance
   * creation. The enterprise Bean instance should store the reference to the context
   * object in an instance variable. This method is called with no transaction context.
   * @param sc SessionContext
   */

  public void setSessionContext    (SessionContext sc)
  {
	this._EJBContext = sc;
  }
  
  /**
		 * Gets the data for search criteria specified in SearchData Object
		 * @param SearchData a_oResultObject
		 * @return String
		 * @throws FinderException
		 * @throws EElixirException
  */
  public String searchFinderFees(SearchData a_oResultObject) throws  FinderException, EElixirException
	{
	  try{
		_oFinderFeesDAX = (FinderFeesDAX)getDAX();
		log.debug("FinderFeesSLEJB--before getFinderFees method of dax object");
		_strCon = _oFinderFeesDAX.getFinderFees(a_oResultObject);
		log.debug("FinderFeesSLEJB--after getFinderFees method of dax object");
	
	  }
	  catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	  }
	  log.debug(_strCon);
	  return _strCon;
	}
	
	/**
	   * Gets the data for distinct Finder Rules approved.
	   * @param 
	   * @return String
	   * @throws FinderException
	   * @throws EElixirException
	   * @throws RemoteException
	*/
	public String searchFinderFees() throws  FinderException, EElixirException, RemoteException
	{
	  try{
		_oFinderFeesDAX = (FinderFeesDAX)getDAX();
		log.debug("FinderFeesSLEJB--before getFinderFees method of dax object");
		_strCon = _oFinderFeesDAX.getFinderFees();
		log.debug("FinderFeesSLEJB--after getFinderFees method of dax object");
	
	  }
	  catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	  }
	  log.debug(_strCon);
	  return _strCon;
	}
	


	/**
	   * Gets the Data depending on the Seq No
	   * @param a_a_lffeeseqnbr long
	   * @return FinderFeesResult
	   * @throws FinderException
	   * @throws EElixirException
	   */
	public FinderFeesResult searchFinderFees(long a_lffeeseqnbr) throws EElixirException , FinderException
	{
		FinderFeesResult oFinderFeesResult = null;
		try
		{		  
		  _oFinderFeesHome = getFinderFeesHome();
		   FinderFeesPK _oFinderFeesPK = new FinderFeesPK();
		  _oFinderFeesPK.setFFeesSeqNbr(a_lffeeseqnbr);
		  _oFinderFees = _oFinderFeesHome.findByPrimaryKey(_oFinderFeesPK);
		  log.debug("FinderFeesSLEJB--Getting Result from FinderFees Bean");
		  oFinderFeesResult =  _oFinderFees.getFinderFeesResult();
		  log.debug("FinderFeesSLEJB--Result Obtained"+ oFinderFeesResult);
		}
		catch(FinderException fe)
		{
		  _EJBContext.setRollbackOnly();
		  log.debug("FinderFeesSLEJB--FinderException " + fe);
		  throw new EElixirException(fe,"P9002");
		}
		catch (RemoteException rex)
		{
		  _EJBContext.setRollbackOnly();
		  log.debug("FinderFeesSLEJB--RemoteEXception " + rex);
		  throw new EElixirException(rex, "P1006");
		}
		catch(EJBException ejbex){
		  _EJBContext.setRollbackOnly();
		  log.debug("FinderFeesSLEJB--EJBException " + ejbex);
		  throw (EElixirException)ejbex.getCausedByException();
		}
		catch(EElixirException eex)
		{
		  _EJBContext.setRollbackOnly();
		  log.debug("FinderFeesSLEJB--EElixirException " + eex);
		  throw eex;
		}
		return oFinderFeesResult;
	  }  
	
	 /**
	   * Creates the Data from the CHMSLEJB
	   * @param a_oFinderFeesResult FinderFeesResult
	   * @return long
	   * @throws EJBException
	   * @throws EElixirException
	 */
	  public long createFinderFees(FinderFeesResult a_oFinderFeesResult) throws  EJBException, EElixirException
	  {
		FinderFeesResult FinderFeesResult = null;
		log.debug("FinderFeesSLEJB--In create FinderFees of FinderFeesSLEJB");
		long lffseqnbr = 0;
		try
		{		  
			_oFinderFeesHome = getFinderFeesHome();
		  	_oFinderFees = _oFinderFeesHome.create(a_oFinderFeesResult);
		  	lffseqnbr = ((FinderFeesPK)_oFinderFees.getPrimaryKey()).getFFeesSeqNbr();
		  	log.debug("FinderFeesSLEJB--Key is " + lffseqnbr);
		}
		catch (CreateException cex)
		{
		  _EJBContext.setRollbackOnly();
		  throw new EElixirException(cex, "P9007");
		}
		catch (RemoteException rex)
		{
		  _EJBContext.setRollbackOnly();
		  throw new EElixirException(rex, "P1006");
		}
			catch(EJBException ejbex){
		  _EJBContext.setRollbackOnly();
		  throw (EElixirException)ejbex.getCausedByException();
		 
		}
		catch(EElixirException eex)
		{
		  _EJBContext.setRollbackOnly();
		  log.debug("FinderFeesSLEJB--Inside catch of Eelixir exception in createFinderFees of FinderFeesSLEJB");
		  throw eex;
		}
		
		return lffseqnbr;
	 }
	 
	/**
	 * Invoked by the session bean to look up the FinderFeesEJB.
	 * @param  a_a_FinderFeesResult FinderFeesResult
	 * @throws RemoteException
	 * @throws EElixirException
	 */
	public void updateFinderFees(FinderFeesResult a_FinderFeesResult)
		throws RemoteException, EElixirException
	{
		try
		{				
			_oFinderFeesHome = getFinderFeesHome();
			
			log.debug(" in updateFinderFees --> a_FinderFeesResult :"+a_FinderFeesResult.getFFHDRSeqNbr());
		
			FinderFeesPK pkFinderFees = new FinderFeesPK(a_FinderFeesResult.getFFHDRSeqNbr().longValue());
			FinderFees oFinderFees = _oFinderFeesHome.findByPrimaryKey(pkFinderFees);							

			oFinderFees.setFinderFeesResult(a_FinderFeesResult);
		}
		catch (EJBException eex)
		{
			log.fatal(getClass().getName(),"updateFinderFees","EJBException "+eex.getMessage());
			Exception e = eex.getCausedByException();

			if (e instanceof EElixirException)
			{
				log.fatal(getClass().getName(),"updateFinderFees","EElixirException "+e.getMessage());
				throw (EElixirException) e;
			}
			else
			{
				log.fatal(getClass().getName(),"updateFinderFees","EJBException "+eex.getMessage());
				throw eex;
			}
		}
		catch (FinderException fe)
		{
			log.fatal(getClass().getName(),"updateFinderFees","FinderException "+fe.getMessage());
			throw new EElixirException(fe, "P4538");
		}
		catch (RemoteException rex)
		{
			log.fatal(getClass().getName(),"updateFinderFees","RemoteException "+rex.getMessage());
			throw new EElixirException(rex, "P1006");
		}
		catch (EElixirException eex)
		{
			log.fatal(getClass().getName(),"updateFinderFees","EElixirException "+eex.getMessage());
			throw eex;
		}
	}
	
	/**
	   * Deletes the Finder Rule from the database. 
	   * @param Long a_lFFHdrSeqNbr
	   * @return void 
	   * @throws EJBException
	   * @throws EElixirException
	 */
		
	public void deleteFinderFees(Long a_lFFHdrSeqNbr)
				throws RemoteException, FinderException, EElixirException	
	{
		try
		{
			FinderFeesDAX _oFinderFeesDAX = getDAX();
			_oFinderFeesDAX.deleteFinderFees(a_lFFHdrSeqNbr);
		}
		catch (EJBException ejbex)
		{
			log.fatal(getClass().getName(),"deleteFinderFees","EJBException "+ejbex.getMessage());
			throw new EElixirException(ejbex, "P4541");
		}
		catch (EElixirException eLex)
		{
			log.fatal(getClass().getName(),"deleteFinderFees","EElixirException "+eLex.getMessage());
			throw new EElixirException(eLex, "P4541");
		}
		finally
		{
			try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{
				log.fatal(getClass().getName(),"deleteFinderFees","EElixirException "+eElex.getMessage());
				throw eElex;
			}
		}
	} 
 
	/**
	   * Creates/Updates the Finder Rules Commission Rates to the database. 
	   * @param a_oFinderFeesResult FinderFeesResult
	   * @return void 
	   * @throws EJBException
	   * @throws EElixirException
	 */
  
	public void updateFFCommissionRates(FinderFeesResult a_FinderFeesResult)
		throws RemoteException, EElixirException, CreateException, FinderException
	{
		FinderFeesResult oFinderFeesResult = null;
			try
		{
			boolean bFlag = true;
			_oFinderFeesHome = getFinderFeesHome();
			
			log.debug("FinderFeesSLEJB -- > updateFFCommissionRates -- > invoking create()");
		    FinderFeesPK pkFinderFees = new FinderFeesPK(a_FinderFeesResult.getFFHDRSeqNbr().longValue());
			FinderFees oFinderFees = _oFinderFeesHome.findByPrimaryKey(pkFinderFees);							

			oFinderFees.setFinderFeesResult(a_FinderFeesResult);
			
			log.debug("FinderFeesSLEJB -- > updateFFCommissionRates -- >done create()");
			
			}
		catch (EJBException eex)
		{
			log.fatal(getClass().getName(),"updateFFCommissionRates","EJBException "+eex.getMessage());
			Exception e = eex.getCausedByException();

			if (e instanceof EElixirException)
			{
				log.fatal(getClass().getName(),"updateFFCommissionRates","EElixirException "+e.getMessage());
				throw (EElixirException) e;
			}
			else
			{
				log.fatal(getClass().getName(),"updateFFCommissionRates","EJBException "+eex.getMessage());
				throw eex;
			}
		}		
		catch (RemoteException rex)
		{
			log.fatal(getClass().getName(),"updateFFCommissionRates","RemoteException "+rex.getMessage());
			throw new EElixirException(rex, "P1006");
		}
		catch (EElixirException eex)
		{
			log.fatal(getClass().getName(),"updateFFCommissionRates","EElixirException "+eex.getMessage());
			throw eex;
		}
		
	}  
	
	/**
		* Inserts the Finder Rule Mapping details.
		* @param ArrayList al_FinderFeesMapResult
		* @return long
		* @throws CreateException, EElixirException
	*/	
	public long createFinderFeesMap(ArrayList al_FinderFeesMapResult) throws RemoteException,CreateException,EElixirException
	{
		try
		{
		   long _lFinderFeesMapSeqNbr =0;
		   long _lUniqueMapSeqNbr = 0;
		   if (al_FinderFeesMapResult != null)
		   {
				FinderFeesMapDAX _oFinderFeesMapDAX = getMapDAX();
				
		  		FinderFeesMapResult a_oFinderFeesMapResult = (FinderFeesMapResult)al_FinderFeesMapResult.get(0);
		  		
				log.debug("FinderFeesSLEJB--Before checkForActiveAgent--if agentcd is null or not null");
				if(a_oFinderFeesMapResult.getAgentCd() != null && !a_oFinderFeesMapResult.getAgentCd().equals(""))
				{
					log.debug("FinderFeesSLEJB--Before checkForActiveAgent");
					
					_oFinderFeesMapDAX.checkForActiveAgent(a_oFinderFeesMapResult.getAgentCd(), a_oFinderFeesMapResult.getChannelType());
					log.debug("FinderFeesSLEJB--After checkForActiveAgent");
				}
				
  				log.debug("FinderFeesSLEJB--After checkForActiveAgent--if agentcd is null or not null");
  				
				for (int i=0; i< al_FinderFeesMapResult.size();i++)
				{
					a_oFinderFeesMapResult = (FinderFeesMapResult)al_FinderFeesMapResult.get(i);
					if(a_oFinderFeesMapResult.getAgentCd() != null && !a_oFinderFeesMapResult.getAgentCd().equals(""))
					{
						log.debug("FinderFeesSLEJB--Before checkForDuplicateFinderFeesMap--if agentcd is not null");
						_oFinderFeesMapDAX.checkForDuplicateFinderFeesMap(a_oFinderFeesMapResult.getChannelType(), 
									a_oFinderFeesMapResult.getAgentCd(), a_oFinderFeesMapResult.getContractName());
					}
					else
					{
						log.debug("FinderFeesSLEJB--Before checkForDuplicateFinderFeesMap--if agentcd is  null");
						_oFinderFeesMapDAX.checkForDuplicateFinderFeesMap( 
								a_oFinderFeesMapResult.getChannelType(),a_oFinderFeesMapResult.getContractName());
								
						log.debug("FinderFeesSLEJB--After checkForDuplicateFinderFeesMap--if agentcd is  null");
					}
					
					log.debug("FinderFeesSLEJB--After checkForDuplicateFinderFeesMap");
				  
					// OVERLAPPING PRODUCTS CHECK
					log.debug("FinderFeesSLEJB--Before validateForProductOverlap..");
					_oFinderFeesMapDAX.validateForProductOverlap(a_oFinderFeesMapResult);					
					
					_lFinderFeesMapSeqNbr = _oFinderFeesMapDAX.getNextFinderFeesMapSeqNbr();
					log.debug("FinderFeesSLEJB--_lFinderFeesMapSeqNbr" + _lFinderFeesMapSeqNbr);
					
					if (i == 0)
					{
					_lUniqueMapSeqNbr = _lFinderFeesMapSeqNbr;
					
					}
					log.debug("FinderFeesSLEJB--_lUniqueMapSeqNbr" + _lUniqueMapSeqNbr);
					a_oFinderFeesMapResult.setUniqueMapSeqNbr(new Long(_lUniqueMapSeqNbr));
			  
					a_oFinderFeesMapResult.setFFMapSeqNbr(new Long(_lFinderFeesMapSeqNbr));
					log.debug("FinderFeesSLEJB ::::: Sequence Number	:"+a_oFinderFeesMapResult.getFFMapSeqNbr());
			  
					_oFinderFeesMapHome = getFinderFeesMapHome();
				    				
					FinderFeesMap _FinderFeesMap =   _oFinderFeesMapHome.create(a_oFinderFeesMapResult);
				    log.debug("FinderFeesSLEJB--after creating ");
			    
			 	}// end of for loop		 	
			 	
				_oFinderFeesMapDAX.insertTransStatus(_lUniqueMapSeqNbr, a_oFinderFeesMapResult.getUserId());
					log.debug("FinderFeesSLEJB--after insert status ");
			}
			return _lUniqueMapSeqNbr;

			 }
		 catch (CreateException cex)
		 {
			_EJBContext.setRollbackOnly();
		   throw new EElixirException(cex, "P3029");
		 }
		 catch(RemoteException rex){
			_EJBContext.setRollbackOnly();
		   throw new EElixirException(rex, "P3029");
		 }
		 catch(EJBException ejbex){
			_EJBContext.setRollbackOnly();
		   throw new EElixirException(ejbex, "P3029");
			 }
			 catch(EElixirException eex)
			 {
				_EJBContext.setRollbackOnly();
				throw eex;
			 }
			 finally
			 {
			   try
			   {
				 if(_oConnection != null)
				   DBConnection.closeConnection(_oConnection);
			   }
			   catch(EElixirException eElex)
			   {
				 throw eElex;
			   }
			 }	
	}// end of create FF Map Function
	
	
	public ArrayList searchFinderFeesMap(long a_LFFMapSeqNbr) throws  FinderException, EElixirException
	{	  
	  ArrayList al_FinderFeesMapResult = new ArrayList();
	  try
	  {
		  FinderFeesMapDAX _oFinderFeesMapDAX = getMapDAX();
		  
		  log.debug("FinderFeesSLEJB--before getFinderFees method	of dax object");
		  
		  al_FinderFeesMapResult = _oFinderFeesMapDAX.getFinderFeesMapList(a_LFFMapSeqNbr);
		  
		  log.debug("FinderFeesSLEJB--after	getFinderFees	method of dax object");
		  return al_FinderFeesMapResult;
	  }
	  catch(EJBException ejbex){
		throw new EElixirException(ejbex, "P3034");
	  }
	  catch(EElixirException eLex)
	  {
		throw eLex;
	  }
	  finally
	  {
		try
		{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex)
		{
		  throw eElex;
		}
	  }

	}

	/**
		 * Gets the data for search criteria specified in SearchData Object for Finder Fees Mapping
		 * @param SearchData a_oSearchData
		 * @return String
		 * @throws FinderException
		 * @throws EElixirException
  	*/
  	public String searchFinderFeesMap(SearchData oSearchData) throws  FinderException, EElixirException
	{
	  try{
			FinderFeesMapDAX _oFinderFeesMapDAX = getMapDAX();
		  
		 	log.debug("FinderFeesSLEJB--before getFinderFeesMap method	of dax object");
		 	
			_strCon = _oFinderFeesMapDAX.getFinderFeesMap(oSearchData);
			log.debug("FinderFeesSLEJB--after	getFinderFeesMap method of dax object");
	  }
	  catch(EJBException ejbex){
		_EJBContext.setRollbackOnly();
		Exception e= ejbex.getCausedByException();
		if (e instanceof EElixirException)
		{
		  throw (EElixirException)e;
		}
		else
		{
		  throw ejbex;
		}
	  }
	  catch(EElixirException eLex)
	  {
		_EJBContext.setRollbackOnly();
		throw eLex;
	  }
	  finally{
		try{
		  if(_oConnection != null)
			DBConnection.closeConnection(_oConnection);
		}
		catch(EElixirException eElex){
		  throw new EElixirException(eElex,"P1005");
		}
	  }
	  log.debug(_strCon);
	  return _strCon;
	}
	
	public void updateFinderFeesMap(ArrayList al_oFinderFeesMapResult)
				throws  CreateException,EElixirException
	{
	 try
	 {		
			 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			 log.debug("FinderFeesSLEJB--Before Lookup");
			 _oFinderFeesMapHome = (FinderFeesMapHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("FinderFeesMapHome"),FinderFeesMapHome.class);
			 log.debug(_oFinderFeesMapHome + "--");
			 log.debug("al_oFinderFeesMapResult  size :"+al_oFinderFeesMapResult.size());
			 log.debug("FinderFeesSLEJB--after lookup");
			 
			 
			 if (al_oFinderFeesMapResult != null)
			 {
			   for(int i=0;i< al_oFinderFeesMapResult.size();i++)
			   {
				 log.debug("FinderFeesSLEJB--looping for counter i = "+i);
				 FinderFeesMapResult a_oFinderFeesMapResult = (FinderFeesMapResult)al_oFinderFeesMapResult.get(i);
				 
				 FinderFeesMapPK pkFinderFeesMap = new FinderFeesMapPK(a_oFinderFeesMapResult.getFFMapSeqNbr().longValue());
				 log.debug(pkFinderFeesMap.toString() + "Contents of Primary  Key");
				 
				 FinderFeesMap _objFinderFeesMap = _oFinderFeesMapHome.findByPrimaryKey(pkFinderFeesMap);
				 log.debug("FinderFeesSLEJB--Before checking of contract effective date");
				 
				// FinderFeesMapDAX _oFinderFeesMapDAX = getMapDAX();
				 
				 // NOTE: COMMENTED BECOZ THERE IS NO EFF. TO DATE IN FF_DEFN. TABLE.
				 // _oFinderFeesMapDAX.validateFinderFeesEffectiveDate(a_oFinderFeesMapResult.getContractName(), a_oFinderFeesMapResult.getEffFrom());

				 //not sure if this is reqd. in update
/*
				 if(a_oFinderFeesMapResult.getAgentCd() != null && !a_oFinderFeesMapResult.getAgentCd().equals(""))
				 {
					 log.debug("FinderFeesSLEJB--Before checking of Product overlap in update");
					 _oFinderFeesMapDAX.validateForProductOverlap(a_oFinderFeesMapResult);
				 }
*/
				 log.debug("FinderFeesSLEJB--Before setting result in SL");
				 FinderFeesMapResult con_FinderFeesMapResult = _objFinderFeesMap.getFinderFeesMapResult();
				 log.debug("FinderFeesSLEJB--ejb obj" + con_FinderFeesMapResult);
				 
				 if (con_FinderFeesMapResult.getTsDtUpdated() != null && a_oFinderFeesMapResult.getTsDtUpdated()!=null && (!con_FinderFeesMapResult.getTsDtUpdated().equals(a_oFinderFeesMapResult.getTsDtUpdated())))
				 {
				   log.debug("concurrency failed thorwing exception");
				   throw new EElixirException("P1100");
				 }
				 _objFinderFeesMap.setFinderFeesMapResult(a_oFinderFeesMapResult);
				 
				 log.debug("FinderFeesSLEJB--result is set for i = "+i);
			   }
			 }
			 
		log.debug("FinderFeesSLEJB--done");
	 }
	 catch(FinderException fe)
	 {
		_EJBContext.setRollbackOnly();
	   throw new EElixirException(fe,"P3030");
	 }
	 catch(RemoteException rex)
	 {
	   _EJBContext.setRollbackOnly();
	   throw new EElixirException(rex, "P3030");
	 }
	 catch(EJBException ejbex)
	 {
	   _EJBContext.setRollbackOnly();
	   throw new EElixirException(ejbex, "P3030");
	 }
	 catch(EElixirException eex)
	 {
	   _EJBContext.setRollbackOnly();
	   throw eex;
		}
		finally
		{
		  try
		  {
			if(_oConnection != null)
			  DBConnection.closeConnection(_oConnection);
		  }
		  catch(EElixirException eElex)
		  {
			throw eElex;
		  }
	  }



   }
   //added by jim
   /**
		   * Gets the data for search criteria specified in SearchData Object
		   * @param long a_lbenseqnbr,String a_strprdcd
		   * @return FinderFeesResult
		   * @throws FinderException
		   * @throws EElixirException
	*/
	public FinderFeesResult searchFFCommissionRates(long a_lbenseqnbr,String a_strprdcd) throws  FinderException, EElixirException
	  {
		FinderFeesResult oFinderFeesResult=null;
		try{
		  _oFinderFeesDAX = (FinderFeesDAX)getDAX();
		  log.debug("FinderFeesSLEJB--before getFFCommissionRates method of dax object");
		  oFinderFeesResult = _oFinderFeesDAX.searchFFCommissionRates(a_lbenseqnbr,a_strprdcd);
		  log.debug("FinderFeesSLEJB--after getFFCommissionRates method of dax object");
		}
		catch(EJBException ejbex){
		  _EJBContext.setRollbackOnly();
		  Exception e= ejbex.getCausedByException();
		  if (e instanceof EElixirException)
		  {
			throw (EElixirException)e;
		  }
		  else
		  {
			throw ejbex;
		  }
		}
		catch(EElixirException eLex)
		{
		  _EJBContext.setRollbackOnly();
		  throw eLex;
		}
		finally{
		  try{
			if(_oConnection != null)
			  DBConnection.closeConnection(_oConnection);
		  }
		  catch(EElixirException eElex){
			throw new EElixirException(eElex,"P1005");
		  }
		}
			return oFinderFeesResult;
	  }
	
	
	/**
	   * Gets the Dax object and sets the connection on it.
	   * @return FinderFeesDAX
	   * @throws EElixirException
    */
	private FinderFeesDAX getDAX() throws EElixirException
	{
		_oConnection = DBConnection.getConnection();
		CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
		FinderFeesDAX _oFinderFeesDAX = (FinderFeesDAX)theDAXFactory.createDAX(CHMDAXFactory.FINDERFEESDAX);
		_oFinderFeesDAX.setConnection(_oConnection);
		
		return _oFinderFeesDAX;
	}	
	
	/**
	   * Gets the Dax object for MAPPING Functionality and sets the connection on it.
	   * @return FinderFeesDAX
	   * @throws EElixirException
	*/
	private FinderFeesMapDAX getMapDAX() throws EElixirException
	{
		_oConnection = DBConnection.getConnection();
		CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
		FinderFeesMapDAX _oFinderFeesMapDAX = (FinderFeesMapDAX)theDAXFactory.createDAX(CHMDAXFactory.FINDERFEESMAPDAX);
		_oFinderFeesMapDAX.setConnection(_oConnection);
	
		return _oFinderFeesMapDAX;
	}
	

	/**
		* Gets the Home object.
		* @return FinderFeesHome
		* @throws EElixirException
	*/
   	private FinderFeesHome getFinderFeesHome() throws EElixirException
   	{
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		log.debug("FinderFeesSLEJB--Before Lookup");
		FinderFeesHome oFinderFeesHome = (FinderFeesHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("FinderFeesHome"),FinderFeesHome.class);
		log.debug("FinderFeesSLEJB--Home LookUP _oFinderFeesHome:" + oFinderFeesHome);
		return oFinderFeesHome;
    }	
    
	/**
		* Gets the Home object for Finder Fees Map.
		* @return FinderFeesMapHome
		* @throws EElixirException
	*/
	private FinderFeesMapHome getFinderFeesMapHome() throws EElixirException
	{
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		log.debug("FinderFeesSLEJB--Before Lookup");
		FinderFeesMapHome oFinderFeesMapHome = (FinderFeesMapHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("FinderFeesMapHome"),FinderFeesMapHome.class);
		log.debug("FinderFeesSLEJB--Home LookUP oFinderFeesMapHome :" + oFinderFeesMapHome );
		return oFinderFeesMapHome;
	}
		

  /**
   * Attributes declaration
   */
  
  public SessionContext _EJBContext = null;
  private Connection _oConnection = null;
  private String           _strCon;
  private FinderFeesDAX      _oFinderFeesDAX;
  public FinderFeesHome _oFinderFeesHome;
  public FinderFeesMapHome _oFinderFeesMapHome;
  public FinderFees _oFinderFees;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  
}