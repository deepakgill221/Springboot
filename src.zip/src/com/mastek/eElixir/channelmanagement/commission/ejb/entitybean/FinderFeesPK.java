/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FinderFeesPK .java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : october 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;
import java.io.Serializable;

/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the FinderFeesBean which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class FinderFeesPK implements Serializable
{

  /**
   * Constructor
   */
  public FinderFeesPK     ()
  {
  }
  
  /**
	* Constructor
	* @param SeqNo long
	*/

   public FinderFeesPK(long a_lffseqnbr)
   {
	 this._lffseqnbr = a_lffseqnbr;
   }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode    ()
  {
	int iHashcode=0;
    if(new Long(_lffseqnbr)!= null)
    iHashcode= new Long(_lffseqnbr).hashCode();
    return iHashcode;

  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * obj) method is unspecified.
   * @return boolean
   */
  public boolean equals    (java.lang.Object obj)
  {
    boolean bEqual=false;
    if(obj!=null && obj instanceof FinderFeesPK )
 	{
		if (this._lffseqnbr  ==  ((FinderFeesPK )obj)._lffseqnbr)
		{
		  bEqual = true;
		}
	}
    return bEqual;

  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public java.lang.String toString    ()
  {
    return null;
  }

  /**
   *  Method to access the Seq No field
   *
   */
  public long getFFeesSeqNbr()
  {
    return this._lffseqnbr;
  }

  /**
   *  Method to set value of the Seq No field
   *
   */
  public void setFFeesSeqNbr(long a_lffseqnbr)
  {
    this._lffseqnbr = a_lffseqnbr;
  }

 

  private long _lffseqnbr;


}