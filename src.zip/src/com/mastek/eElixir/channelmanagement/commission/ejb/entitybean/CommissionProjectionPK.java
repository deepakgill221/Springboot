/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionProjectionPK.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : Jan 20, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;
import java.io.Serializable;

/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the CommissionProjectionBean which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class CommissionProjectionPK implements Serializable
{

  /**
   * Constructor
   */
  public CommissionProjectionPK    ()
  {
  }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode    ()
  {
    int iHashcode=0;
    if(new Long(_lComProjSeqNbr)!= null)
    iHashcode= new Long(_lComProjSeqNbr).hashCode();
    return iHashcode;

  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * obj) method is unspecified.
   * @param obj Object
   * @return boolean
   */
  public boolean equals    (java.lang.Object obj)
  {
    boolean bEqual=false;
	if(obj!=null && obj instanceof CommissionProjectionPK)
	{
		if (this._lComProjSeqNbr  ==  ((CommissionProjectionPK)obj)._lComProjSeqNbr)
		{
		  bEqual = true;
		}
	}
    return bEqual;

  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public java.lang.String toString    ()
  {
    return null;
  }

  /**
   *  Method to access the Seq No field
   * @return long
   */
  public long getComProjSeqNbr()
  {
    return this._lComProjSeqNbr;
  }

  /**
   *  Method to set value of the Seq No field
   * @param a_lComProjSeqNbr long
   */
  public void setComProjSeqNbr(long a_lComProjSeqNbr)
  {
    this._lComProjSeqNbr = a_lComProjSeqNbr;
  }

  /**
   * Constructor
   * @param a_lComProjSeqNbr long
   */

  public CommissionProjectionPK    (long a_lComProjSeqNbr)
  {
    this._lComProjSeqNbr = a_lComProjSeqNbr;
  }

  private long _lComProjSeqNbr;


}