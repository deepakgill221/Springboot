/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMapPK.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.io.Serializable;

   /**
    * <p>Title: eElixir</p>
    * <p>Description:This primary key class is for the ContractMapBean </p>
    * <p>Copyright: Copyright (c) 2002</p>
    * <p>Company: Mastek Ltd</p>
    * @author Vinaysheel
    * @version 1.0
    */
 public class ContractMapPK implements Serializable
{

    /**
     * Referencing to object that represents the entity object.
     * @return integer value
     */
    public int hashCode    ()
    {
      int iHashcode=0;
      if(new Long(_LContMapSeqNbr)!= null)
      iHashcode= new Long(_LContMapSeqNbr).hashCode();
      return iHashcode;

  }

    /**
     * Method that compares two entity object references -- since the Java Object.equals(Object
     * obj) method is unspecified.
     * @return boolean
     * @param obj Object
     */
    public boolean equals    (Object obj)
    {
                boolean bEqual=false;
			if(obj!=null && obj instanceof ContractMapPK)
			{
                long objKey = ((ContractMapPK)obj).getLContMapSeqNbr();
				if (this._LContMapSeqNbr == objKey)
				{
				  bEqual = true;
				}
			}
				return bEqual;
    }

    /**
     * Own toString() method of a bean's PK class.
     * @return String
     */
    public String toString    ()
    {
	   return _LContMapSeqNbr + "";
    }

    /**
     *  Method to access the _LContMapSeqNbr  field
     * @return long
     *
     */
     public long getLContMapSeqNbr()
     {
			return this._LContMapSeqNbr;
     }

    /**
     *  Method to set value of the _LContMapSeqNbr field
     *  @param _LContMapSeqNbr long
     */
     public void setLContMapSeqNbr(long a_LContMapSeqNbr)
     {
			this._LContMapSeqNbr = a_LContMapSeqNbr;
     }

    /**
     * Constructor
     */
    public ContractMapPK    ()
    {

    }

    /**
     * Constructor
     * @param a_LContMapSeqNbr String
     */

    public ContractMapPK (long a_LContMapSeqNbr)
    {
		 this._LContMapSeqNbr = a_LContMapSeqNbr;
    }

   private long _LContMapSeqNbr;

}
