/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterSL.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: October 29, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This RYCRuleMasterSL interface provides method for getting the data from RYCResult bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Srikanth Kolluri
 * @version 1.0
 */



public interface RYCRuleMasterSL extends EJBObject
{
  /**
   * Creates the Data from the FinderFeesSLEJB
   * @param SearchDeata
   * @return String
   * @throws RemoteException, EJBException, EElixirException;
   */
  public String searchRYCRuleMaster() throws EElixirException , FinderException , RemoteException;
  
  public String searchRYCRuleMaster(SearchData a_oResultObject)
			 throws FinderException, EElixirException, RemoteException;
  public RYCRuleMasterSearchResult searchRYCRuleMaster(long lRYCHdrSeqNbr)
			throws FinderException, EElixirException, RemoteException;
  public long createRYCRuleMaster(RYCRuleMasterSearchResult a_RYCRuleMasterSearchResult)
				 throws EJBException, EElixirException,RemoteException;
  public void updateRYCRuleMaster(RYCRuleMasterSearchResult a_RYCRuleMasterSearchResult)
				 throws EJBException, EElixirException,RemoteException;
  public void deleteRYCRuleMaster(Long rycHdrSeqNbr)
			 throws EJBException, EElixirException, RemoteException;
  
}
