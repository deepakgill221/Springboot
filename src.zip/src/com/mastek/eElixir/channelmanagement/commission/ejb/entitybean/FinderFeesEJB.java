/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Finder Fees
*  FILENAME			: FinderFeesEJB.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: November 10, 2002
*  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
*  1.1         30Jan             Pallav                Added delete functionality
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.commission.dax.FinderFeesDAX;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionRatesDetails;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;



/**
 * <p>Title: eElixir</p>
 * <p>Description: This FinderFees Entity bean retrive data from the database according to seach condition</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class FinderFeesEJB implements EntityBean
{
  /**
   * Attributes declaration
   */
  private EntityContext _oContext;
  private Connection _oConnection = null;
  private DataSource _oDatasource = null;
  private FinderFeesDAX  _oFinderFeesDAX;
  private FinderFeesResult _oFinderFeesResult;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


  /**
   * Constructor for FinderFeesEJB class
   */
  public FinderFeesEJB    ()
  {

  }

  /**
   * Matching method of the create() method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @return FinderFeesPK
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.FinderFeesPK ejbCreate    () throws CreateException, EElixirException
  {
    FinderFeesPK bpk = new FinderFeesPK();

    return bpk;

  }

  /**
   * Matching method of the create(FinderFeesResult a_oFinderFeesResult) method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @param  a_oFinderFeesResult FinderFeesResult
   * @return FinderFeesPK
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public FinderFeesPK ejbCreate(FinderFeesResult a_oFinderFeesResult) throws CreateException, EElixirException
  {
    FinderFeesPK ffpk = null;	
	
    try{
      _oFinderFeesDAX = getDAX();
      log.debug("FinderFeesEJB--before getFinderFees method of dax object");
	  //log.debug("FinderFeesEJB--getUpdCommRatesFlag()	:"+a_oFinderFeesResult.getUpdCommRatesFlag());     
      
       //long lffseqnbr = _oFinderFeesDAX.createFinderFees(a_oFinderFeesResult);  
      
      //log.debug("FinderFeesEJB-------------------------the value obained in Entity bean is ---"+ lffseqnbr);
      //ffpk = new FinderFeesPK();
      //ffpk.setFFeesSeqNbr(lffseqnbr);
      
	  _oFinderFeesDAX.createFinderFees(a_oFinderFeesResult);
      
	  ffpk = new FinderFeesPK(a_oFinderFeesResult.getFFHDRSeqNbr().longValue());
	  
      log.debug("FinderFeesEJB--Key in entiy bean is " + ffpk.getFFeesSeqNbr());
      log.debug("FinderFeesEJB--after getFinderFees method of dax object");
      
	  return ffpk;
	  
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex, "P1005");
      }
    }
    //log.debug("FinderFeesEJB--Key in entiy bean is again " + ffpk.getFFeesSeqNbr());
    
  }
  
  // added by shameem
  /*public FinderFeesPK ejbCreate(CommissionRatesDetails a_CommRatesDetails) throws  EElixirException
   {
	 FinderFeesPK ffpk = null;
	 try{
	   _oFinderFeesDAX = getDAX();
	   log.debug("FinderFeesEJB--before getFinderFees method of dax object");
	   long lffseqnbr = _oFinderFeesDAX.updateFFCommRates(a_CommRatesDetails);
	   
	   ffpk = new FinderFeesPK();
	   ffpk.setFFeesSeqNbr(lffseqnbr);	   
	 }
	 catch(EElixirException eex)
	 {
	   throw eex;
	 }
	 finally{
	   try{
		 if(_oConnection != null)
		   DBConnection.closeConnection(_oConnection);
	   }
	   catch(EElixirException eElex){
		 throw new EElixirException(eElex, "P1005");
	   }
	 }
	 
	 return ffpk;
   }*/

  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate    () throws CreateException, EElixirException
  {

  }


  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @param a_oFinderFeesResult FinderFeesResult
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate    (FinderFeesResult a_oFinderFeesResult) throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method when the instance is taken out of the pool of available
   * instances to become associated with a specific EJB object. This method transitions
   * the instance to the ready state. This method executes in an unspecified transaction
   * context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * A container invokes this method on an instance before the instance becomes disassociated
   * with a specific EJB object. After this method completes, the container will place
   * the instance into the pool of available instances. This method executes in an unspecified
   * transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by loading it from the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbLoad    ()
  {
    log.debug("FinderFeesEJB--ejbLoad() fired");
    FinderFeesPK finderfeesPK = (FinderFeesPK)_oContext.getPrimaryKey();
    try
    {
      _oFinderFeesResult = new  FinderFeesResult();
      _oFinderFeesDAX = (FinderFeesDAX)getDAX();
      log.debug("FinderFeesEJB--Before Calling getFinderFees on FinderFeesDAX");
      _oFinderFeesResult = _oFinderFeesDAX.getFinderFees(finderfeesPK.getFFeesSeqNbr());
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eex)
      {
        throw new EJBException(eex);
      }
    }
  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by storing it to the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbStore    ()
  {
    log.debug("FinderFeesEJB--ejbStore() fired");
	/* CHANGE TO AVOID UPDATE  */
	
	//log.debug("getUpdCommRatesFlag() :"+this._oFinderFeesResult.getUpdCommRatesFlag());
	//log.debug("getIsDirty() :"+this._oFinderFeesResult.getIsDirty());
	
	//if(this._oFinderFeesResult != null && this._oFinderFeesResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
    
    try
      {
		if(this._oFinderFeesResult != null)
		{
			//_oFinderFeesDAX = (FinderFeesDAX)getDAX(); 
       // _oFinderFeesDAX.updateFinderFees(_oFinderFeesResult);
       
       /*====================================================================== 
        * This code is to save the commission rates details 
        ========================================================================*/
        
	   		if(_oFinderFeesResult.getUpdCommRatesFlag()!=null 
					   && !_oFinderFeesResult.getUpdCommRatesFlag().equalsIgnoreCase("")	 
						   && _oFinderFeesResult.getUpdCommRatesFlag().equalsIgnoreCase("True"))
			 {
				log.debug("IF part of ejbStore -------------------->:");
				_oFinderFeesDAX = (FinderFeesDAX)getDAX();
				
				_oFinderFeesDAX.updateFFCommRates(_oFinderFeesResult);
			     
			 }
			 		
			if(_oFinderFeesResult.getUpdCommRatesFlag()!=null 
					   && !_oFinderFeesResult.getUpdCommRatesFlag().equalsIgnoreCase("")	 
						   && _oFinderFeesResult.getUpdCommRatesFlag().equalsIgnoreCase("False")
								&& _oFinderFeesResult.getIsDirty().equalsIgnoreCase(DataConstants.UPDATE_MODE)
						   )
			 {
				_oFinderFeesDAX = (FinderFeesDAX)getDAX();
				log.debug("ELSE part of ejbStore -------------------->:");
				_oFinderFeesDAX.updateFinderFees(_oFinderFeesResult);	
			 }
		}
			 
      }
      catch(EElixirException ex)
      {
      	log.debug("ejbstore -- > Exception here  :"+ex.toString());
        throw new EJBException(ex);
      }
      finally
      {
        try
        {
          if(_oConnection != null)
            DBConnection.closeConnection(_oConnection);
        }
        catch(EElixirException eex)
        {
          throw new EJBException(eex);
        }
      }
   
  }

  /**
   * A container invokes this method before it removes the EJB object that is currently
   * associated with the instance. It is invoked when a client invokes a remove operation
   * on the enterprise Bean's home or remote interface. It transitions the instance from
   * the ready state to the pool of available instances. It is called in the transaction
   * context of the remove operation.
   * @throws javax.ejb.RemoveException
   */
  public void ejbRemove    ()
  {
    log.debug("FinderFeesEJB--ejbRemove() fired");
    try
    {
      FinderFeesDAX oFinderFeesDAX = getDAX();
      //oFinderFeesDAX.removeFinderFees(((FinderFeesPK)(_oContext.getPrimaryKey())).getFFeesSeqNbr());
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eex)
      {
        throw new EJBException(eex);
      }
    }
  }

  /**
   * Set the associated entity context. The container invokes this method on an instance
   * after the instance has been created. This method is called in an unspecified transaction
   * context.
   * @param ctx EntityContext
   */
  public void setEntityContext    (EntityContext ctx)
  {
    _oContext = ctx;
  }

  /**
   * Unset the associated entity context. The container calls this method before removing
   * the instance. This is the last method that the container invokes on the instance.
   * The Java garbage collector will  invoke the finalize() method on the instance. It
   * is called in an unspecified transaction context.
   */
  public void unsetEntityContext    ()
  {
    _oContext = null;
  }

  /**
   * Invoked by the container on the instance when the container selects the instance to
   * execute a matching client-invoked find() method. It executes in the transaction
   * context determined by the transaction attribute of the matching find() method.
   * @param a_FinderFeesPK FinderFeesPK
   * @return FinderFeesPK
   * @throws javax.ejb.FinderException
   * @throws EElixirException
   */
  public FinderFeesPK ejbFindByPrimaryKey    (FinderFeesPK a_FinderFeesPK) throws FinderException,EElixirException
  {
    try{
      log.debug("FinderFeesEJB--Inside Findby primary key of FinderFeesEJB");
      _oFinderFeesDAX = getDAX();
      log.debug( "Inside Find by primary key " + a_FinderFeesPK.getFFeesSeqNbr() + "");	  
      boolean bFlag = _oFinderFeesDAX.findFinderFees(a_FinderFeesPK.getFFeesSeqNbr());
      log.debug( "After find FinderFees");
      if(bFlag){
        log.debug("FinderFeesEJB--Returning FinderFees Primary Key");
        return a_FinderFeesPK;
      }
      else
        throw new EElixirException("P9002"); // to be decided
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
  }


/**
 * Gets the Dax object and sets the connection on it.
 * @return FinderFeesDAX
 * @throws EElixirException
 */
  private FinderFeesDAX getDAX() throws EElixirException
  {
    _oConnection = DBConnection.getConnection();
    CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
    FinderFeesDAX _oFinderFeesDAX = (FinderFeesDAX)theDAXFactory.createDAX(CHMDAXFactory.FINDERFEESDAX);
    _oFinderFeesDAX.setConnection(_oConnection);

    return _oFinderFeesDAX;
  }


  public FinderFeesResult getFinderFeesResult() throws  EElixirException
  {
    return _oFinderFeesResult;
  }

  public void setFinderFeesResult(FinderFeesResult a_oFinderFeesResult) throws  EElixirException
  {
    this._oFinderFeesResult = a_oFinderFeesResult;
  }


}