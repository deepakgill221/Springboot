/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : CHANNEL MANAGEMENT
*  FILENAME			: CommDispatch.java
*  AUTHOR			: Amid P Sahu
*  VERSION			: 1.0
*  CREATION DATE    : Feb 19, 2009
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2009.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------

*
*--------------------------------------------------------------------------------
*Amid_Fin_156_Upload Of Commission Dispatch
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;
import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This CsaCpa interface provides method for retreving data from the
 * database through primaryKey  </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */

public interface CommDispatch extends EJBObject
{
  /* This method gets the CommDispatchResult Object
  * @return CommDispatchResult
  */
  public CommDispatchResult getCommDispatchResult() throws RemoteException, EElixirException;

  /* This method sets the CommDispatchResult Object
  * @param a_oCommDispatchResult ChannelResult
  */
  public void setCommDispatchResult(CommDispatchResult a_oCommDispatchResult) throws RemoteException, EElixirException;

}