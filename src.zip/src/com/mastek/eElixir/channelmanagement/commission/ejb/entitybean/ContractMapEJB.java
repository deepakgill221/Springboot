/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMapEJB.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.commission.dax.ContractMapDAX;
import com.mastek.eElixir.channelmanagement.commission.util.ContractMapResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: EElixir</p>
 * <p>Description: ContractMappingEJB is the local entity bean implementation of a ContractMapping.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: MASTEK</p>
 * @author Vinaysheel
 * @version 1.0
 */

public class ContractMapEJB implements EntityBean
{

    /**
     * Constructor for ContractMappingEJB class
     */
    public ContractMapEJB    ()
    {

    }

    /**
     * Matching method of the create() method of the bean's home interface. The container
     * invokes an ejbCreate method to create an entity object. It executes in the transaction
     * context determined by the transactionattribute of the matching create() method.
     * @return ContractMappingPK
     * @throws javax.ejb.CreateException
     */
    public ContractMapPK ejbCreate    () throws CreateException
    {
      ContractMapPK cpk = new ContractMapPK();

      return cpk;

    }

    /**
     * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
     * on an instance after it invokes the ejbCreate method with the same arguments. It
     * executes in the same transaction context as that of the matching ejbCreate method.
     * @throws javax.ejb.CreateException
     */
    public void ejbPostCreate    () throws CreateException
    {

    }
    /**
     * A container invokes this method when the instance is taken out of the pool of available
     * instances to become associated with a specific EJB object. This method transitions
     * the instance to the ready state. This method executes in an unspecified transaction
     * context.
     */
    public void ejbActivate    ()
    {

    }

    /**
     * A container invokes this method on an instance before the instance becomes disassociated
     * with a specific EJB object. After this method completes, the container will place
     * the instance into the pool of available instances. This method executes in an unspecified
     * transaction context.
     */
    public void ejbPassivate    ()
    {

    }

    /**
     * A container invokes this method to instruct the instance to synchronize its state
     * by loading it from the underlying database. This method always executes in the transaction
     * context determined by the value of the transaction attribute in the deployment descriptor.
     */
    public void ejbLoad    ()
    {
       log.debug("ContractMap - ejbload fired");
       ContractMapPK pkContractMap = (ContractMapPK)EJB_Context.getPrimaryKey();
       try
       {
         _oContractMapResult = new  ContractMapResult();
         ContractMapDAX _oContractMapDAX = (ContractMapDAX)getDAX();
        _oContractMapResult = _oContractMapDAX.getContractMap(pkContractMap.getLContMapSeqNbr());
        log.debug("From date in ejbLoad" + DateUtil.retStrDate(_oContractMapResult.getEffFrom()));
       }
       catch(EElixirException ex)
       {
         throw new EJBException(ex.getMessage());
       }
       finally
       {
         try
         {
           if(_oConnection != null)
             DBConnection.closeConnection(_oConnection);
         }
         catch(EElixirException eex)
         {
           throw new EJBException(eex);
         }
      }
    }

    /**
     * A container invokes this method to instruct the instance to synchronize its state
     * by storing it to the underlying database. This method always executes in the transaction
     * context determined by the value of the transaction attribute in the deployment descriptor.
     */
    public void ejbStore    ()
    {

      log.debug("ejbstore fired");
	  /* CHANGE TO AVOID UPDATE  */
      if(this._oContractMapResult != null && this._oContractMapResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
      {
        try
        {
          log.debug("in ejbejbsore");
          ContractMapDAX _oContractMapDAX = getDAX();
          _oContractMapDAX.updateContractMap(_oContractMapResult);
          log.debug("From date in ejbstore" + DateUtil.retStrDate(_oContractMapResult.getEffFrom()));
        }
        catch(EElixirException ex)
        {
          throw new EJBException(ex);
        }
        finally
        {
          try
          {
            if(_oConnection != null)
              DBConnection.closeConnection(_oConnection);
          }
          catch(EElixirException eex)
          {
            throw new EJBException(eex);
          }
        }
      }

    }

    /**
     * A container invokes this method before it removes the EJB object that is currently
     * associated with the instance. It is invoked when a client invokes a remove operation
     * on the enterprise Bean's home or remote interface. It transitions the instance from
     * the ready state to the pool of available instances. It is called in the transaction
     * context of the remove operation.
     * @throws javax.ejb.RemoveException
     */
    public void ejbRemove    () throws RemoveException
    {

    }

    /**
     * Set the associated entity context. The container invokes this method on an instance
     * after the instance has been created. This method is called in an unspecified transaction
     * context.
     */
    public void setEntityContext    (EntityContext ctx)
    {
      this.EJB_Context = ctx;
    }

    /**
     * Unset the associated entity context. The container calls this method before removing
     * the instance. This is the last method that the container invokes on the instance.
     * The Java garbage collector will  invoke the finalize() method on the instance. It
     * is called in an unspecified transaction context.
     */
    public void unsetEntityContext    ()
    {

    }

    /**
     * Invoked by the container on the instance when the container selects the instance to
     * execute a matching client-invoked find() method. It executes in the transaction
     * context determined by the transaction attribute of the matching find() method.
     * @return ApplicationPK
     * @throws javax.ejb.FinderException
     */

    public ContractMapPK ejbFindByPrimaryKey    (ContractMapPK cmPK) throws  FinderException, EElixirException
    {

      try{

        ContractMapDAX _oContractMapDAX = getDAX();
        log.debug("calling dax" );
        //make a call to verify if primary key is present
        log.debug("Before callling DAX:"  + cmPK.getLContMapSeqNbr() );
                boolean bFlag = _oContractMapDAX.searchContractMap(cmPK.getLContMapSeqNbr());
        if(bFlag)
        {
          log.debug("Returning ContractMap Primary Key");
          return cmPK;
        }
        else
           throw new EElixirException("P3036"); // to be decided
      }


        //this.setAdjustmentResult(oAdjustmentResult);

      catch(EElixirException eex)
        {
          throw eex;
        }
        finally{
          try{
            if(_oConnection != null)
              DBConnection.closeConnection(_oConnection);
          }
          catch(EElixirException eElex){
            throw new EElixirException(eElex, "P1005");
          }
        }


 }


 private ContractMapDAX getDAX() throws EElixirException
 {
        _oConnection = DBConnection.getConnection();
        CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        ContractMapDAX _oContractMapDAX = (ContractMapDAX)theDAXFactory.createDAX(theDAXFactory.CONTRACTMAPDAX);
        _oContractMapDAX.setConnection(_oConnection);

       return _oContractMapDAX;
  }
    /**
     * Gets the Data from the ContractMappingSlEJB
     * @param Request HttpServletRequest
     * @return Collection object
     * @throws EElixirException
     */



  public ContractMapPK ejbCreate(ContractMapResult a_oContractMapResult) throws CreateException, EElixirException
  {
    try
    {
       ContractMapDAX _oContractMapDAX = getDAX();
       _oContractMapDAX.insertContractMap(a_oContractMapResult);
       ContractMapPK  cmpk = new ContractMapPK(a_oContractMapResult.getContMapSeqNbr().longValue());
       return cmpk;
    }
    catch(EElixirException eex)
    {
      log.debug("In CONTRACTMAPEJB ELIXIR EXCEPTION");
      throw eex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex)
      {
        throw new EElixirException(eElex,"P1005");
      }
    }

  }

  public void ejbPostCreate(ContractMapResult a_oContractMapResult) throws CreateException, EElixirException
  {
    ;

  }

  public ContractMapResult getContractMapResult() throws  EElixirException
  {
    return this._oContractMapResult;
  }

  public void setContractMapResult(ContractMapResult a_oContractMapResult) throws EElixirException
  {
    this._oContractMapResult = a_oContractMapResult;
  }

  /**
   * Attributes declaration
   */
  private EntityContext EJB_Context;
  private Connection _oConnection = null;
  private DataSource _oDatasource = null;
  private ContractMapDAX  _oContractMappingDAX;
  private ContractMapResult _oContractMapResult;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);




}


