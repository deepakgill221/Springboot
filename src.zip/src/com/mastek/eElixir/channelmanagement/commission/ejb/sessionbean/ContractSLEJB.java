/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME			: ContractSLEJB.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION	DATE		: September	20,	2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT			: COPYRIGHT	(C)	2002.

*
*  MODIFICATION	HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*	03/10/2002		Heena Jain		Added searchContractMap(SearchData oSearchData)
*
*	03/10/2002		Heena Jain		Modified searchContractMap(SearchData oSearchData)-- called CONTRACTMAPDAX
*       26/10/2002		Pallav		        Code review bug fixed.

*--------------------------------------------------------------------------------
*
*********************************************************************/
package	com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;


import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.commission.dax.ContractDAX;
import com.mastek.eElixir.channelmanagement.commission.dax.ContractMapDAX;
import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.ContractProdValidate;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.Clawback;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ClawbackHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ClawbackPK;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.Contract;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ContractHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ContractMap;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ContractMapHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ContractMapPK;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ContractPK;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.SelfContract;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.SelfContractHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.SelfContractPK;
import com.mastek.eElixir.channelmanagement.commission.util.ClawbackResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractCopyResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractMapResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.commission.util.SelfContractResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAXFactory;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

/**
 * <p>Title: eElixir</p>
 * <p>Description: This	ContractSL session bean	acts as	an interface for the Contract Entity bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version	1.0
 */

public class ContractSLEJB implements SessionBean
{

  /**
   * Constructor of	the	ContractSLEJB class
   */
  public ContractSLEJB	  ()
  {

  }

  /**
   * Called	by the container to	create a session bean instance.	Its	parameters typically
   * contain the information the client	uses to	customize the bean instance	for	its	use.
   * It	requires a matching	pair in	the	bean class and its home	interface.
   */
  public void ejbCreate	   () throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method before	it ends	the	life of	the	session	object.	This
   * happens as	a result of	a client's invoking	a remove operation,	or when	a container
   * decides to	terminate the session object after a timeout. This method is called	with
   * no	transaction	context.
   */
  public void ejbRemove	   ()
  {

  }

  /**
   * The activate method is	called when	the	instance is	activated from its 'passive' state.
   * The instance should acquire any resource that it has released earlier in the ejbPassivate()
   * method. This method is	called with	no transaction context.
   */
  public void ejbActivate	 ()
  {

  }

  /**
   * The passivate method is called	before the instance	enters the 'passive' state.	The
   * instance should release any resources that	it can re-acquire later	in the ejbActivate()
   * method. After the passivate method	completes, the instance	must be	in a state that
   * allows	the	container to use the Java Serialization	protocol to	externalize	and	store
   * away the instance's state.	This method	is called with no transaction context.
   */
  public void ejbPassivate	  ()
  {

  }

  /**
   * Set the associated	session	context. The container calls this method after the instance
   * creation. The enterprise Bean instance	should store the reference to the context
   * object	in an instance variable. This method is	called with	no transaction context.
   * @param	sc
   */

  public void setSessionContext	   (SessionContext sc)
  {
        this._EJBContext = sc;
  }

  /**
   * Gets the Data depending on	the	Seq	No
   * @param	a_lCommAgrmtSeqNbr long
   * @return ContractResult
   * @throws FinderException
   * @throws EElixirException
   */
  public ContractResult	searchContract(long	a_lCommAgrmtSeqNbr)	throws FinderException,EElixirException{
        ContractResult oContractResult = null;
        try
        {
          EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
          CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
          log.debug("ContractSLEJB--Before	Lookup");
          _oContractHome = (ContractHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("ContractHome"),ContractHome.class);
          log.debug("ContractSLEJB--Home LookUP _oContractHome:" +	_oContractHome);

           ContractPK _oContractPk = new ContractPK(a_lCommAgrmtSeqNbr);
          //_oContractPk.setComAgreementKey(a_lCommAgrmtSeqNbr);
          _oContract = _oContractHome.findByPrimaryKey(_oContractPk);
          log.debug("ContractSLEJB--Getting Result	from Contract Bean");
          oContractResult =	 _oContract.getContractResult();
          log.debug("ContractSLEJB--Result	Obtained"+ oContractResult);
        }
        catch(FinderException fe)
        {
          _EJBContext.setRollbackOnly();
          log.debug("ContractSLEJB--FinderException " + fe);
          throw	new	EElixirException(fe,"P3024");
        }
        catch (RemoteException rex)
        {
          _EJBContext.setRollbackOnly();
          log.debug("ContractSLEJB--RemoteEXception " + rex);
          throw	new	EElixirException(rex, "P1006");
        }
        catch(EJBException ejbex){
          _EJBContext.setRollbackOnly();
          log.debug("ContractSLEJB--EJBException "	+ ejbex);
          throw	(EElixirException)ejbex.getCausedByException();
        }
        catch(EElixirException eex)
        {
          _EJBContext.setRollbackOnly();
          log.debug("ContractSLEJB--EElixirException "	+ eex);
          throw	eex;
        }

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("ContractSLEJB--before Lookup of	CommissionSLHome Home");
        CHMPropertyUtil	_oCHMPropertyUtil =	CHMPropertyUtil.getPropertyUtil();
        CommissionSLHome _oCommissionSLHome	= (CommissionSLHome)objEJBHomeFactory
                                                                                .lookUpHome(_oCHMPropertyUtil.getCHMProperty("CommissionSLHome"),
                                                                                CommissionSLHome.class);
        log.debug("ContractSLEJB--After Lookup	CommissionSLHome Home");
        CommissionDetails arrCommissionDetails[] = null;
        ClawBackDetails	arrClawBackDetails[] = null;
        Short	nCommType =	oContractResult.getCommissionResult().getCommType();
        try
        {
          CommissionSL oCommissionSL = _oCommissionSLHome.create();
          if(nCommType.shortValue() == DataConstants.STANDARD_COMMISSION || nCommType.shortValue() == DataConstants.TRAIL_COMMISSION ||nCommType.shortValue() == DataConstants.INDEX_COMMISSION || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION){ // for standard commission, or Trail
                arrCommissionDetails = oCommissionSL.searchStandardCommission(a_lCommAgrmtSeqNbr,nCommType.shortValue());
          }
          else if(nCommType.shortValue() ==DataConstants.CLAWBACK_COMMISSION){ //	for	Clawback
                arrClawBackDetails = oCommissionSL.searchClawBackCommission(a_lCommAgrmtSeqNbr);
                log.debug("ContractSLEJB--	arrClawBackDetails length "	+ arrClawBackDetails.length);
          }
        }
        catch (CreateException cex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(rex, "P1006");
        }
        catch(EJBException ejbex){
          _EJBContext.setRollbackOnly();
          throw	(EElixirException)ejbex.getCausedByException();
        }
        catch (EElixirException	eLex)
        {
          _EJBContext.setRollbackOnly();
          throw	eLex;
        }
      if(nCommType.intValue() == DataConstants.STANDARD_COMMISSION	|| nCommType.intValue()	== DataConstants.TRAIL_COMMISSION ||nCommType.intValue() == DataConstants.INDEX_COMMISSION || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION){	// for standard	commission,	or Trail
          oContractResult.getCommissionResult().setCommissionDetail(arrCommissionDetails);
        }
        else if(nCommType.intValue() ==	DataConstants.CLAWBACK_COMMISSION){	// for Clawback
          oContractResult.getCommissionResult().setClawBackDetail(arrClawBackDetails);
        }
        return oContractResult;
  }

  /**
   * Gets the data based on	the	parameter of DVO
   * @param	a_oResultObject	Object
   * @return String	XML	format string object
   * @throws EElixirException
   */
  public String	searchContract(Object a_oResultObject) throws  FinderException,	EElixirException
  {
        try{
          _oContractDAX = (ContractDAX)getDAX();
          log.debug("ContractSLEJB--before	getContract	method of dax object");
          _strCon =	_oContractDAX.getContract(a_oResultObject);
          log.debug("ContractSLEJB--after getContract method of dax object");
          //DBConnection.closeConnection(_oConnection);
        }
        catch(EJBException ejbex){
          _EJBContext.setRollbackOnly();
          throw	(EElixirException)ejbex.getCausedByException();
        }
        catch(EElixirException eLex)
        {
          _EJBContext.setRollbackOnly();
          throw	eLex;
        }
        finally{
          try{
            if(_oConnection != null)
              DBConnection.closeConnection(_oConnection);
          }
          catch(EElixirException eElex){
            throw new EElixirException(eElex,"P1005");
          }
        }

        log.debug(_strCon);
        return _strCon;
  }

  /**
   * Gets the data based on	the	parameter of DVO
   * @param	a_oContractProdValidate	ContractProdValidate
   * @return ContractProdValidate
   * @throws EElixirException
   */
  public ContractProdValidate getContractBaseUnit(ContractProdValidate a_oContractProdValidate)	throws	FinderException, EElixirException
  {
        ContractProdValidate oContractProdValidate = null;
        try{
          _oContractDAX = (ContractDAX)getDAX();
          log.debug("ContractSLEJB--before	getContract	method of dax object");
          oContractProdValidate	= _oContractDAX.getContractBaseUnit(a_oContractProdValidate);
          log.debug("ContractSLEJB--after getContract method of dax object");
          //DBConnection.closeConnection(_oConnection);
        }
        catch(EJBException ejbex){
          _EJBContext.setRollbackOnly();
          throw	(EElixirException)ejbex.getCausedByException();
        }
        catch(EElixirException eLex)
        {
          _EJBContext.setRollbackOnly();
          throw	eLex;
        }
        finally{
          try{
            if(_oConnection != null)
              DBConnection.closeConnection(_oConnection);
          }
          catch(EElixirException eElex){
            throw new EElixirException(eElex,"P1005");
          }
        }

        log.debug(_strCon);
        return oContractProdValidate;
  }

  /**
  *	Invoked	by the session bean	to look	up the Contract	EJB. for copying a contract
  *	@param a_oContractCopyResult ContractCopyResult
  *	@throws	EElixirException
  *	@throws	EJBException
         */
   public void copyContract(ContractCopyResult a_oContractCopyResult) throws FinderException,EElixirException
   {
         try
         {
			 /*
         EJBHomeFactory	objEJBHomeFactory =	EJBHomeFactory.getFactory();
         CHMPropertyUtil oCHMPropertyUtil =	CHMPropertyUtil.getPropertyUtil();
         log.debug("ContractSLEJB--Before Lookup");
         _oContractHome = (ContractHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("ContractHome"),ContractHome.class);
        // _oContractHome	= (ContractHome)objEJBHomeFactory.lookUpHome("com.mastek.eElixir.channelmanagement.commission.ejb.entitybean.ContractHome",ContractHome.class);

         log.debug("ContractSLEJB--After Lookup");

          _oContract = _oContractHome.create();
          _oContract.copyContract(a_oContractCopyResult);
		  */
		  _oContractDAX = (ContractDAX)getDAX();
		 _oContractDAX.copyContract(a_oContractCopyResult);
         }
		 /*
         catch (CreateException	cex)
         {
          _EJBContext.setRollbackOnly();
           throw new EElixirException(cex, "P1007");
         }
         catch (RemoteException	rex)
         {
          _EJBContext.setRollbackOnly();
           throw new EElixirException(rex, "P1006");
          }
		  */
         catch(EElixirException	eex)
         {
          _EJBContext.setRollbackOnly();
           log.exception(" Inside catch	of copyContract	of ContractSL" + eex.getMessage());
           throw eex;
        }finally{
        	try
    		{
    		if(_oConnection!=null)
    			DBConnection.closeConnection(_oConnection);
    		}catch(EElixirException eElex)
    		{
    			throw eElex;
       		}
        }
 }

  /**
   * Validates a contract, checks to see if	unique key constraint is validated or not.
   * @param	a_oContractResult ContractResult
   * @return boolean
   * @throws EElixirException
   * @throws FinderException
   */
  public boolean validateContract(ContractResult a_oContractResult)	throws EElixirException	, FinderException
  {
        boolean	isContractPresent =	false;
        try{
          _oContractDAX = (ContractDAX)getDAX();
          log.debug("ContractSLEJB--before	validateContract	method of dax object");
          isContractPresent	= _oContractDAX.validateContract(a_oContractResult);
          log.debug("ContractSLEJB--after validateContract  method of dax object");
          //DBConnection.closeConnection(_oConnection);
        }
        catch(EJBException ejbex){
          _EJBContext.setRollbackOnly();
          throw	(EElixirException)ejbex.getCausedByException();
        }
        catch(EElixirException eex)
        {
          _EJBContext.setRollbackOnly();
          throw	eex;
        }
        finally{
          try{
            if(_oConnection != null)
              DBConnection.closeConnection(_oConnection);
          }
          catch(EElixirException eElex){
            throw new EElixirException(eElex,"P1005");
          }
        }

        return isContractPresent;
  }

  /**
   * Creates the Data from the CHMSLEJB
   * @param	a_oContractResult ContractResult
   * @return long
   * @throws EJBException
   * @throws EElixirException
   */
  public long createCommissionContract(ContractResult a_oContractResult) throws	 EJBException, EElixirException
  {
        log.debug("ContractSLEJB--In create Contract of ContractSLEJB");
        long lComAgreementKey =	0;
        try
        {
          if(validateContract(a_oContractResult)){
                log.debug("ContractSLEJB--before throwing exception");
                throw new EElixirException("P4012");  //Changing to throw Record Already present instead of Unique constraint violated
          }
          EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
          CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
          log.debug("ContractSLEJB--Before	Lookup of entity bean");
          _oContractHome = (ContractHome)objEJBHomeFactory
                                         .lookUpHome(oCHMPropertyUtil.getCHMProperty("ContractHome"),ContractHome.class);
          log.debug("ContractSLEJB--After Lookup");

          _oContract = _oContractHome.create(a_oContractResult);
          lComAgreementKey = ((ContractPK)_oContract.getPrimaryKey()).getComAgreementKey();
          log.debug("ContractSLEJB--Key is	" +	lComAgreementKey);
        }
        catch (CreateException cex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(cex, "P3025");
        }
        catch (RemoteException rex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(rex, "P1006");
        }
        catch (FinderException fex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(fex, "P3024");
        }
        catch(EJBException ejbex){
          _EJBContext.setRollbackOnly();
          throw	(EElixirException)ejbex.getCausedByException();
          //throw new EElixirException(ejbex, "P3025");
        }
        catch(EElixirException eex)
        {
          _EJBContext.setRollbackOnly();
          log.debug("ContractSLEJB--Inside	catch of Eelixir exception in createCommission of ContractSLEJB");
          throw	eex;
        }
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("ContractSLEJB--before Lookup of	Commission Home");
        CHMPropertyUtil	oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        CommissionSLHome oCommissionSLHome = (CommissionSLHome)objEJBHomeFactory
                                                                                .lookUpHome(oCHMPropertyUtil.getCHMProperty("CommissionSLHome"),
                                                                                CommissionSLHome.class);
        log.debug("ContractSLEJB--After Lookup	Commission Home");
        try
        {
          CommissionSL	oCommissionSL =	oCommissionSLHome.create();
          log.debug("ContractSLEJB--creating Commission");
          a_oContractResult.getCommissionResult().setComAgreementKey(new Long(lComAgreementKey));
          oCommissionSL.createCommission(a_oContractResult);
          log.debug("ContractSLEJB--Commission	Created");
          log.debug("ContractSLEJB--lComAgreementKey:"	+ lComAgreementKey);
          //contractResult = searchContract(lComAgreementKey);
        }
        //catch	(FinderException fex)
        //{
        //	throw new EElixirException(fex,	"P3024");
        //}
        catch (CreateException cex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(cex, "P3023");
        }
        catch (RemoteException rex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(rex, "P1006");
        }
        catch(EJBException ejbex){
          _EJBContext.setRollbackOnly();
          throw	(EElixirException)ejbex.getCausedByException();
        }
        catch(EElixirException eLex){
          _EJBContext.setRollbackOnly();
          throw	eLex;
        }
        //return contractResult;
        return lComAgreementKey;
  }


   /**
   * Invoked by	the	session	bean to	look up	the	Contract EJB. for Deleting a contract
   * @param  a_lCommAgrmtSeqNbr long
   * @param a_oContractResult ContractResult
   * @throws RemoveException
   * @throws EJBException
   */
  public void deleteContract(long a_lCommAgrmtSeqNbr,ContractResult a_oContractResult) throws RemoveException, EJBException,	EElixirException
  {
        try
        {
          updateCommission(a_oContractResult);
          EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
          CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
          log.debug("ContractSLEJB--Inside	Update Commission");
          _oContractHome = (ContractHome)oEJBHomeFactory
                                         .lookUpHome(oCHMPropertyUtil.getCHMProperty("ContractHome"),ContractHome.class);

                ContractPK oContractPK = new ContractPK();
                log.debug("ContractSLEJB--Inside Delete1 ");
                oContractPK.setComAgreementKey(a_lCommAgrmtSeqNbr);
                log.debug("ContractSLEJB--Inside Delete2 ");
                Contract  oContract	= _oContractHome.findByPrimaryKey(oContractPK);
                log.debug("ContractSLEJB--Inside Delete3 ");
                oContract.remove();
                log.debug("ContractSLEJB--Inside Delete4");
        }
        catch(FinderException fex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(fex, "P3024");
        }
        catch(CreateException cex)
        {
          _EJBContext.setRollbackOnly();
          throw new EElixirException(cex, "P1007");
        }
        catch (RemoveException rex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(rex, "P3024");
        }
        catch (RemoteException rex)
        {
          _EJBContext.setRollbackOnly();
          throw	new	EElixirException(rex, "P1006");
        }
        catch(EJBException ejbex){
          _EJBContext.setRollbackOnly();
          throw	(EElixirException)ejbex.getCausedByException();
        }
        catch(EElixirException eLex)
        {
          _EJBContext.setRollbackOnly();
          throw	eLex;
        }

  }

  /**
   * Invoked by the session bean to look up the Commission EJB.
   * @param a_oContractResult ContractResult
   * @throws CreateException
   * @throws EJBException
  * @throws EElixirException
   */
  public void updateCommission(ContractResult a_oContractResult) throws CreateException, EJBException, EElixirException
  {
    try{
    EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
    log.debug("ContractSLEJB--before Lookup of	Commission Home");
    CHMPropertyUtil	oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
    _oCommissionSLHome = (CommissionSLHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("CommissionSLHome"),CommissionSLHome.class);
    log.debug("ContractSLEJB--after Lookup of	Commission Home");
      _oCommissionSL = _oCommissionSLHome.create();
    log.debug("ContractSLEJB--got Commissionsl" + _oCommissionSL);
      _oCommissionSL.updateCommission(a_oContractResult);
  }
    catch(CreateException cex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(cex, "P1007");
    }
    catch(RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      log.exception(rex.getMessage());
      throw new EElixirException(rex, "P1006");
     }
    catch(EJBException ejbex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(ejbex, "P1007");
    }
  }


// *********************************************************************************************************************//

// *********************************************************************************************************************//
// Code	added by Vinay
/**
* Invoked by the session bean to look up the Contract EJB. for Deleting	a contract
* @throws EElixirException
* @throws EJBException
   */
 public	String searchContract()	throws FinderException,EElixirException
 {
   String strContract =	null ;
   try
   {
/*   EJBHomeFactory objEJBHomeFactory	= EJBHomeFactory.getFactory();
   CHMPropertyUtil oCHMPropertyUtil	= CHMPropertyUtil.getPropertyUtil();
   log.debug("ContractSLEJB-searchContract-Before Lookup");
   _oContractHome = (ContractHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("ContractHome"),ContractHome.class);

   log.debug("ContractSLEJB-searchContract-After Lookup");

         _oContract	= _oContractHome.create();
   log.debug("ContractSLEJB-searchContract-After create");
*/
   //strContract = _oContract.getContract();
   strContract = getContract();
   log.debug("ContractSLEJB-searchContract-After getCotract");
         return	strContract;
   }
/*   catch (CreateException cex)
   {
          _EJBContext.setRollbackOnly();
         throw new EElixirException(cex, "P1007");
   }
   catch (RemoteException rex)
   {
          _EJBContext.setRollbackOnly();
         throw new EElixirException(rex, "P1006");
        }
  */ catch(EElixirException eex)
   {
          _EJBContext.setRollbackOnly();
         log.exception(eex.getMessage());
         throw eex;
  }
 }


  public String getContract() throws  EElixirException
  {
    log.debug("ContractEJB-in getContract");

	String result;
    try{
      log.debug("ContractEJB-in getContract-in try");
	  ContractDAX _oContractDAX = (ContractDAX)getDAX();
      log.debug("ContractEJB-in getContract-after setconnection");

      result = _oContractDAX.getContract();
      log.debug("ContractEJB-in getContract-after getContract");

      return result;
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
  }

//Method added by Vinay

    public long createContractMap(ArrayList al_ContractMapResult) throws CreateException,EElixirException
    {
      try
      {
        long _lContractMapSeqNbr =0;
        long _lUniqueMapSeqNbr = 0;
        if (al_ContractMapResult != null)
        {
          EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
          CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
          log.debug("ContractSLEJB--Before Lookup");
          _oConnection	= DBConnection.getConnection();
          DAXFactory theCHMDAXFactory = CHMDAXFactory.getDAXFactory();
          ContractMapDAX _oContractMapDAX = (ContractMapDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.CONTRACTMAPDAX);
          _oContractMapDAX.setConnection(_oConnection);
           ContractMapResult a_oContractMapResult = (ContractMapResult)al_ContractMapResult.get(0);
           log.debug("ContractSLEJB--Before checkForActiveAgent--if agentcd is null or not null");
           if(a_oContractMapResult.getAgentCd() != null && !a_oContractMapResult.getAgentCd().equals(""))
           {
             log.debug("ContractSLEJB--Before checkForActiveAgent");
             _oContractMapDAX.checkForActiveAgent(a_oContractMapResult.getAgentCd(), a_oContractMapResult.getChannelType());
             log.debug("ContractSLEJB--After checkForActiveAgent");
           }
           log.debug("ContractSLEJB--After checkForActiveAgent--if agentcd is null or not null");
          for (int i=0; i< al_ContractMapResult.size();i++)
          {
           a_oContractMapResult = (ContractMapResult)al_ContractMapResult.get(i);
           if(a_oContractMapResult.getAgentCd() != null && !a_oContractMapResult.getAgentCd().equals(""))
           {
             log.debug("ContractSLEJB--Before checkForDuplicateContractMap--if agentcd is not null");
             _oContractMapDAX.checkForDuplicateContractMap( a_oContractMapResult.getChannelType(), a_oContractMapResult.getAgentCd(), a_oContractMapResult.getContractNbr());
           }
           else
           {
             log.debug("ContractSLEJB--Before checkForDuplicateContractMap--if agentcd is  null");
             _oContractMapDAX.checkForDuplicateContractMap( a_oContractMapResult.getChannelType(), a_oContractMapResult.getContractNbr());
             log.debug("ContractSLEJB--After checkForDuplicateContractMap--if agentcd is  null");
           }
           log.debug("ContractSLEJB--After checkForDuplicateContractMap");
           // OVERLAPPING PRODUCTS CHECK
           log.debug("ContractSLEJB--After checkForDuplicateContractMap--if agentcd is not null");
           _oContractMapDAX.validateForProductOverlap(a_oContractMapResult);
           _lContractMapSeqNbr = _oContractMapDAX.getNextContractMapSeqNbr();
           log.debug("ContractSLEJB--_lContractMapSeqNbr" + _lContractMapSeqNbr);
           if (i == 0)
           {
             _lUniqueMapSeqNbr = _lContractMapSeqNbr;

           }
           log.debug("ContractSLEJB--_lUniqueMapSeqNbr" + _lUniqueMapSeqNbr);
           a_oContractMapResult.setUniqueMapSeqNbr(new Long(_lUniqueMapSeqNbr));
           a_oContractMapResult.setContMapSeqNbr(new Long(_lContractMapSeqNbr));
           //Added to solve the problem of TimeStamp
		   GregorianCalendar sysDate = DateUtil.retGCDate(DateUtil.getSystemDate());
		   a_oContractMapResult.setDtUpdated(sysDate);
		   log.debug(a_oContractMapResult.getContMapSeqNbr() +   "::::: Sequence Number");
           _oContractMapHome = (ContractMapHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("ContractMapHome"),ContractMapHome.class);
           ContractMap _oContractMap =   _oContractMapHome.create(a_oContractMapResult);
           log.debug("ContractSLEJB--after creating ");
          }
          _oContractMapDAX.insertTransStatus(_lUniqueMapSeqNbr, a_oContractMapResult.getUserId(),a_oContractMapResult.getDtUpdated());
           log.debug("ContractSLEJB--after insert status ");
        }
        return _lUniqueMapSeqNbr;
      }
      catch (CreateException cex)
      {
         _EJBContext.setRollbackOnly();
        throw new EElixirException(cex, "P3029");
      }
      catch(RemoteException rex){
         _EJBContext.setRollbackOnly();
        throw new EElixirException(rex, "P3029");
      }
      catch(EJBException ejbex){
         _EJBContext.setRollbackOnly();
        throw new EElixirException(ejbex, "P3029");
      }
      catch(EElixirException eex)
      {
         _EJBContext.setRollbackOnly();
         throw eex;
      }
      finally
      {
        try
        {
          if(_oConnection != null)
            DBConnection.closeConnection(_oConnection);
        }
        catch(EElixirException eElex)
        {
          throw eElex;
        }
      }


    }

    public void updateContractMap(ArrayList al_oContractMapResult)
            throws  CreateException,EElixirException
    {
     try
     {

             EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
             CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
             log.debug("ContractSLEJB--Before Lookup");
             _oContractMapHome = (ContractMapHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("ContractMapHome"),ContractMapHome.class);
             log.debug(_oContractMapHome + "");
             log.debug("ContractSLEJB--after lookup");
             if (al_oContractMapResult != null)
             {
               for(int i=0;i< al_oContractMapResult.size();i++)
               {
                 ContractMapResult a_oContractMapResult = (ContractMapResult)al_oContractMapResult.get(i);
                 ContractMapPK pkContractMap = new ContractMapPK(a_oContractMapResult.getContMapSeqNbr().longValue());
                 log.debug(pkContractMap.toString() + "Contents of Primary  Key");
                 ContractMap  _objContractMap = _oContractMapHome.findByPrimaryKey(pkContractMap);
                 log.debug("ContractSLEJB--Before checking of contract effective date");
                 _oConnection	= DBConnection.getConnection();
                 DAXFactory theCHMDAXFactory = CHMDAXFactory.getDAXFactory();
                 ContractMapDAX _oContractMapDAX = (ContractMapDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.CONTRACTMAPDAX);
                 _oContractMapDAX.setConnection(_oConnection);
                 _oContractMapDAX.validateContractEffectiveDate(a_oContractMapResult.getContractNbr(), a_oContractMapResult.getEffFrom());

                 //not sure if this is reqd. in update
/*
             if(a_oContractMapResult.getAgentCd() != null && !a_oContractMapResult.getAgentCd().equals(""))
             {
                 log.debug("ContractSLEJB--Before checking of Product overlap in update");
                 _oContractMapDAX.validateForProductOverlap(a_oContractMapResult);
             }
*/
                 log.debug("ContractSLEJB--Before setting result in SL");
                 ContractMapResult con_ContractMapResult = _objContractMap.getContractMapResult();
                 //log.debug("ContractSLEJB--ejb obj" + con_ContractMapResult);
                 if (con_ContractMapResult.getTsDtUpdated() != null && a_oContractMapResult.getTsDtUpdated()!=null && (!con_ContractMapResult.getTsDtUpdated().equals(a_oContractMapResult.getTsDtUpdated())))
                 {
                   log.debug("concurrency failed thorwing exception");
                   throw new EElixirException("P1100");
                 }
                 _objContractMap.setContractMapResult(a_oContractMapResult);
               }
             }
     }
     catch(FinderException fe)
     {
        _EJBContext.setRollbackOnly();
       throw new EElixirException(fe,"P3030");
     }
     catch(RemoteException rex)
     {
       _EJBContext.setRollbackOnly();
       throw new EElixirException(rex, "P3030");
     }
     catch(EJBException ejbex)
     {
       _EJBContext.setRollbackOnly();
       throw new EElixirException(ejbex, "P3030");
     }
     catch(EElixirException eex)
     {
       _EJBContext.setRollbackOnly();
       throw eex;
        }
        finally
        {
          try
          {
            if(_oConnection != null)
              DBConnection.closeConnection(_oConnection);
          }
          catch(EElixirException eElex)
          {
            throw eElex;
          }
      }



   }


public ArrayList searchContractMap(long a_LContMapSeqNbr) throws  FinderException, EElixirException
{
  ContractMapResult resultObject = null;
  ArrayList al_ContractMapResult = new ArrayList();
  try
  {
    /*EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
    CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
    log.debug("ContractSLEJB--Before Lookup");
    _oContractMapHome = (ContractMapHome)objEJBHomeFactory
                           .lookUpHome(_oCHMPropertyUtil.getCHMProperty("ContractMapHome"),ContractMapHome.class);
    log.debug("ContractSLEJB--After Lookup");

    ContractMapPK _oContractMapPk = new ContractMapPK();
    log.debug("ContractSLEJB--before putting in PK object: " + a_LContMapSeqNbr);
    _oContractMapPk.setLContMapSeqNbr(a_LContMapSeqNbr );
    _oContractMap = _oContractMapHome.findByPrimaryKey(_oContractMapPk);
    resultObject =  _oContractMap.getContractMapResult();*/
    _oConnection	= DBConnection.getConnection();
     DAXFactory theCHMDAXFactory = CHMDAXFactory.getDAXFactory();
     log.debug("ContractSLEJB--before creation of Contract dax object"+theCHMDAXFactory);
     ContractMapDAX _oContractMapDAX = (ContractMapDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.CONTRACTMAPDAX);
     log.debug("ContractSLEJB--after	creation of	Contract dax object");
     _oContractMapDAX.setConnection(_oConnection);
      log.debug("ContractSLEJB--before getContract method	of dax object");
      al_ContractMapResult = _oContractMapDAX.getContractMapList(a_LContMapSeqNbr);
      log.debug("ContractSLEJB--after	getContract	method of dax object");
      return al_ContractMapResult;
  }
  catch(EJBException ejbex){
    throw new EElixirException(ejbex, "P3034");
  }
  catch(EElixirException eLex)
  {
    throw eLex;
  }
  finally
  {
    try
    {
      if(_oConnection != null)
        DBConnection.closeConnection(_oConnection);
    }
    catch(EElixirException eElex)
    {
      throw eElex;
    }
  }

}




//*********************************************************************************************************************//

  /* uncomment this	before checking	in */

  public	String searchContractMap(SearchData	oSearchData) throws	EElixirException , FinderException
  {
    try
    {
      log.debug("ContractSLEJB--Inside searchContractMap SL");
      _oConnection	= DBConnection.getConnection();

      DAXFactory theCHMDAXFactory = CHMDAXFactory.getDAXFactory();
      log.debug("ContractSLEJB--before creation of Contract dax object"+theCHMDAXFactory);

      ContractMapDAX _oContractMapDAX = (ContractMapDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.CONTRACTMAPDAX);
      log.debug("ContractSLEJB--after	creation of	Contract dax object");

      _oContractMapDAX.setConnection(_oConnection);

      log.debug("ContractSLEJB--before getContract method	of dax object");
      _strCon = _oContractMapDAX.getContractMap(oSearchData);
      log.debug("ContractSLEJB--after	getContract	method of dax object");
    }
    catch(EJBException ejbex){
      throw new EElixirException(ejbex, "P3033");
    }
    catch(EElixirException eLex)
    {
      throw eLex;
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex)
      {
        throw eElex;
      }
    }

    log.debug(_strCon);
    return _strCon;

  }

 /*uncomment this before checking in */
  /* end of	searchContractMap */
//*********************************************************************************************************************//


//code for selfContract
/**
* Gets the Data from the CHMSLEJB
* @param SearchData
* @return ArrayList
* @throws EElixirException
   */
 public	ArrayList searchSelfContract(SearchData	oSearchData) throws	EElixirException , FinderException
 {
   ArrayList _oSelfContractList = null ;
   try
   {
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

     _oConnection = DBConnection.getConnection();
     log.debug("ContractSLEJB--after getconnection");
     DAXFactory theCHMDAXFactory = CHMDAXFactory.getDAXFactory();
     log.debug("ContractSLEJB--after getdaxfactory");
     ContractDAX _oContractDAX = (ContractDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.CONTRACTDAX);
     log.debug("ContractSLEJB--before setconnection");
     _oContractDAX.setConnection(_oConnection);
     log.debug("ContractSLEJB--after setconnection");
     _oSelfContractList = _oContractDAX.getSelfContract(oSearchData);


     return _oSelfContractList ;

   }
   catch(EJBException ejbex){
     throw new EElixirException(ejbex, "P3039");
   }
   catch(EElixirException eLex)
   {
     throw eLex;
   }
   finally
   {
     try
     {
       if(_oConnection != null)
         DBConnection.closeConnection(_oConnection);
     }
     catch(EElixirException eElex)
     {
       throw eElex;
     }
   }

 }

 /**
  * updates Data from the CHMSLEJB
  * @param ArrayList a_oSelfContractList
  * @return void
  * @throws EElixirException
   */

  public void updateSelfContract(ArrayList a_oSelfContractList) throws  EElixirException
  {
    try
    {
      _oSelfContractHome = getSelfContractHome("SelfContractHome", SelfContractHome.class);
      SelfContractPK pkSelfContract = null;
      //getting dax
      _oConnection = DBConnection.getConnection();
     log.debug("ContractSLEJB--after getconnection");
     DAXFactory theCHMDAXFactory = CHMDAXFactory.getDAXFactory();
     ContractDAX _oContractDAX = (ContractDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.CONTRACTDAX);
     _oContractDAX.setConnection(_oConnection);
     //got the dax
      for(int i = 0; i < a_oSelfContractList.size(); i++)
      {
        SelfContractResult oSelfContractResult = (SelfContractResult)a_oSelfContractList.get(i);
//        if(oSelfContractResult.getStatusFlag().equals(DataConstants.UPDATE_MODE))
//        {
          pkSelfContract = new SelfContractPK(oSelfContractResult.getPolNbr(), oSelfContractResult.getServAgentCd());
          log.debug(pkSelfContract.getPolNbr() + "::::" + pkSelfContract.getServAgentCd());
          SelfContract  _objSelfContract = _oSelfContractHome.findByPrimaryKey(pkSelfContract);
          Timestamp con_dtUpdated = _oContractDAX.getSelfContractDtUpdated(oSelfContractResult.getPolNbr());
          if (con_dtUpdated != null && (!con_dtUpdated.equals(oSelfContractResult.getTsDtUpdated())))
          {
            log.debug("concurrency failed thorwing exception");
            throw new EElixirException("P1100");
          }

          _objSelfContract.setSelfContractResult(oSelfContractResult);
//        }
      }




    }
    catch(FinderException fe)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(fe,"P3040");
    }

    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw (EElixirException)ejbex.getCausedByException();
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      throw eex;
    }

    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(rex, "P3040");
    }
    finally{
    	try
		{
		if(_oConnection!=null)
			DBConnection.closeConnection(_oConnection);
		}catch(EElixirException eElex)
		{
			throw eElex;
   		}
    }
  }

  private SelfContractHome getSelfContractHome(String strHome, Class cHomeClass) throws EElixirException
  {
     log.debug("ContractSLEJB--Looking for SelfContractHome");
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     SelfContractHome _oSelfContractHome = (SelfContractHome)objEJBHomeFactory
                                .lookUpHome(_oCHMPropertyUtil.getCHMProperty(strHome),cHomeClass);

     log.debug("ContractSLEJB--returning SelfContractHome");
     return _oSelfContractHome;
  }



//code for Clawback
/**
* Gets the Data from the CHMSLEJB
* @param SearchData
* @return ArrayList
* @throws EElixirException
   */
 public	ArrayList searchClawback(SearchData	oSearchData) throws	EElixirException , FinderException
 {
   ArrayList _oClawbackList = null ;
   try
   {
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

     _oConnection = DBConnection.getConnection();
     log.debug("ContractSLEJB--after getconnection");
     DAXFactory theCHMDAXFactory = CHMDAXFactory.getDAXFactory();
     log.debug("ContractSLEJB--after getdaxfactory");
     ContractDAX _oContractDAX = (ContractDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.CONTRACTDAX);
     log.debug("ContractSLEJB--before setconnection");
     _oContractDAX.setConnection(_oConnection);
     log.debug("ContractSLEJB--after setconnection");
     _oClawbackList = _oContractDAX.getClawback(oSearchData);


     return _oClawbackList ;

   }
   catch(EJBException ejbex){
     throw new EElixirException(ejbex, "P3041");
   }
   catch(EElixirException eLex)
   {
     throw eLex;
   }
   finally
   {
     try
     {
       if(_oConnection != null)
         DBConnection.closeConnection(_oConnection);
     }
     catch(EElixirException eElex)
     {
       throw eElex;
     }
   }

 }

 /**
  * updates Data from the CHMSLEJB
  * @param ArrayList a_oClawbackList
  * @return void
  * @throws EElixirException
   */

  public void updateClawback(ArrayList a_oClawbackList) throws  EElixirException
  {
    try
    {
      log.debug("ContractSLEJB--in updateClawback ");
      _oClawbackHome = getClawbackHome("ClawbackHome", ClawbackHome.class);
      log.debug("ContractSLEJB--in update UPDATE MODE");
      ClawbackPK pkClawback = null;
      //getting dax
      _oConnection = DBConnection.getConnection();
      log.debug("ContractSLEJB--after getconnection");
      DAXFactory theCHMDAXFactory = CHMDAXFactory.getDAXFactory();
      log.debug("ContractSLEJB--after getdaxfactory");
      ContractDAX _oContractDAX = (ContractDAX)theCHMDAXFactory.createDAX(CHMDAXFactory.CONTRACTDAX);
      log.debug("ContractSLEJB--before setconnection");
      _oContractDAX.setConnection(_oConnection);
      //got the dax
      for(int i = 0; i < a_oClawbackList.size(); i++)
      {
        ClawbackResult oClawbackResult = (ClawbackResult)a_oClawbackList.get(i);
//        if(oSelfContractResult.getStatusFlag().equals(DataConstants.UPDATE_MODE))
//        {
          pkClawback = new ClawbackPK(oClawbackResult.getPolNbr(), oClawbackResult.getServAgentCd());
          log.debug(pkClawback.getPolNbr() + "::::" + pkClawback.getServAgentCd());
          log.debug("ContractSLEJB--in updateclawback size befor firing findByPrimaryKey");
          Clawback  _objClawback = _oClawbackHome.findByPrimaryKey(pkClawback);
          Timestamp con_dtUpdated = _oContractDAX.getSelfContractDtUpdated(oClawbackResult.getPolNbr());
          //we are using the above method because the tables access is the same with the same primary key
          //so the same method is used.
          log.debug("ContractSLEJB--in updateselfcontract after pk conc ts " + con_dtUpdated  + " " + oClawbackResult.getTsDtUpdated());
          if (con_dtUpdated != null && (!con_dtUpdated.equals(oClawbackResult.getTsDtUpdated())))
          {
            log.debug("concurrency failed thorwing exception");
            throw new EElixirException("P1100");
          }
          _objClawback.setClawbackResult(oClawbackResult);
          log.debug("ContractSLEJB--in updateClawback size after setting result");
//        }
      }




    }
    catch(FinderException fe)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(fe,"P3042");
    }

    catch(EJBException ejbex){
      _EJBContext.setRollbackOnly();
      throw (EElixirException)ejbex.getCausedByException();
    }
    catch(EElixirException eex)
    {
      _EJBContext.setRollbackOnly();
      throw eex;
    }

    catch (RemoteException rex)
    {
      _EJBContext.setRollbackOnly();
      throw new EElixirException(rex, "P3042");
    }
    finally{
    	try
		{
		if(_oConnection!=null)
			DBConnection.closeConnection(_oConnection);
		}catch(EElixirException eElex)
		{
			throw eElex;
   		}
    }
  }

  private ClawbackHome getClawbackHome(String strHome, Class cHomeClass) throws EElixirException
  {
     log.debug("ContractSLEJB--Looking for ClawbackHome");
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     ClawbackHome _oClawbackHome = (ClawbackHome)objEJBHomeFactory
                                .lookUpHome(_oCHMPropertyUtil.getCHMProperty(strHome),cHomeClass);

     log.debug("ContractSLEJB--returning ClawbackHome");
     return _oClawbackHome;
  }

// Code	ends by	Vinay



/**
 * Gets the Dax object and sets the connection on it.
 * @return ContractDAX
 * @throws EElixirException
 */
  private ContractDAX getDAX() throws EElixirException
  {
    _oConnection = DBConnection.getConnection();
    CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
    ContractDAX _oContractDAX = (ContractDAX)theDAXFactory.createDAX(theDAXFactory.CONTRACTDAX);
    _oContractDAX.setConnection(_oConnection);

    return _oContractDAX;
  }


/**
 * Attributes declaration
 */
  private Connection	   _oConnection	= null;
  private ContractDAX	   _oContractDAX;
  private String		   _strCon;
  public SessionContext	   _EJBContext = null;
  public ContractHome	   _oContractHome;
  private Contract		   _oContract;
  private CommissionSL	   _oCommissionSL;
  private CommissionSLHome _oCommissionSLHome;
  public ContractMapHome   _oContractMapHome;
  private ContractMap	   _oContractMap;

  //for selfcontract
    private SelfContractHome _oSelfContractHome;
    private SelfContract _oSelfContract;

//for clawback
    private ClawbackHome _oClawbackHome;
    private Clawback _oClawback;

  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}