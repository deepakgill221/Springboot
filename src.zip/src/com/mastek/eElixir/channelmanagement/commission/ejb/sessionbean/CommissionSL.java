/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionSL.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*1.1		07/04/2015		Vibhu Nigam		FIN838_AgentCommissionDisbursementLimitChange
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.commission.util.CollectionParamResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.commission.util.DisbursementSetupResult;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.SearchData;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This CommissionSL interface provides method for getting the data from Commission bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface CommissionSL extends EJBObject
{
  /**
   * Creates the Data from the ContractSLEJB
   * @param a_oContractResult ContractResult
   * @return void
   * @throws RemoteException, EJBException, EElixirException;
   */
  public void createCommission(ContractResult a_oContractResult) throws RemoteException, EJBException, EElixirException;

  /**
   * Invoked to look up the ContractSLEJB.
   * @param a_oContractResult ContractResult
   * @throws RemoteException
   * @throws CreateException, RemoteException, EJBException;
   */
  public void updateCommission(ContractResult a_oContractResult) throws CreateException, RemoteException, EJBException, EElixirException;

  /**
   * Searches Standard Commission on basis of seq no
   * @return CommissionDetails[]
   * @param: a_lCommAgrmtSeqNbr long
   * @throws RemoteException
   * @throws EJBException
   * @throws FinderException
   */
  public CommissionDetails[] searchStandardCommission(long a_lCommAgrmtSeqNbr, short a_nCommType) throws RemoteException, EJBException, FinderException, EElixirException;

  /**
   * Searches ClawBack Commission on basis of seq no
   * @return ClawBackDetails
   * @param: a_lCommAgrmtSeqNbr long
   * @throws RemoteException
   * @throws EJBException
   * @throws FinderException
   */
  public ClawBackDetails[] searchClawBackCommission(long a_lCommAgrmtSeqNbr) throws RemoteException, EJBException, FinderException, EElixirException;

   /**
    * For getting OverridingCommRate depending on selected Overriding commission
    * @param a_lPriKey long
    * @return ArrayList
    * @throws FinderException
    * @throws EElixirException
    */
   public ArrayList searchOverridingCommRate(long a_lPriKey) throws FinderException, EElixirException,RemoteException;

      /**
    * For updating OverridingCommRate depending on selected Overriding commission
    * @param a_lPriKey long
    * @return ArrayList
    * @throws FinderException
    * @throws EElixirException
    */
   public void updateOverridingCommRate(ArrayList a_arrOverridingCommRateResult) throws EElixirException,RemoteException;
// Amid_Fin_156_Upload Of Commission Dispatch_Starts	
   public String searchCommissionDispatch(SearchData oSearchData) throws EElixirException , FinderException , RemoteException;
   public void updateCommDispatch(ArrayList a_alCommDispatchList)throws FinderException, RemoteException, EElixirException;
   public String deleteCommissionDispatch(SearchData oSearchData) throws EElixirException , FinderException , RemoteException;
// Amid_Fin_156_Upload Of Commission Dispatch_Ends
// <!--sunaina_Commision_Dispatch_CR_Started--> 
   public CommDispatchResult searchGetLocationCd(String strUserId)throws RemoteException, FinderException, EElixirException;
// <!--sunaina_Commision_Dispatch_CR_Ended-->
   
 
   
	/**Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Starts
	 * Gets the data based on the parameter of DVO
	 * @param  a_cChannelType Character
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws FinderException
	 * @throws EElixirException
	 */
   public ArrayList searchOverrideCommRuleList(String strChannelType)
       throws RemoteException, FinderException, EElixirException;
   public void updateOverrideCommRule(ArrayList a_oCommRuleList)
   throws FinderException, RemoteException, EElixirException;
   
   public String searchProdCodeExists(String strAgencyCode,
           String strProdCd, String dtEffFrom)  
   throws FinderException, RemoteException, EElixirException;
   //Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Ends
   
      
   /**
    * For updating collection Parameter screen
    * @param CollectionParamResult
    * @return CollectionParamResult
    * @throws FinderException
    * @throws EElixirException
    */
   // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Start
   public CollectionParamResult saveCollectionParams(CollectionParamResult collectionParamResult) throws FinderException, EElixirException,RemoteException;
   public CollectionParamResult getCollectionParams() throws FinderException, EElixirException,RemoteException;
   // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 End
   
   // Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Start
   public ArrayList getDisbursementSetup()throws RemoteException, EElixirException ;
   public void SaveUpdateDisbumSetupDetails(ArrayList _oDisbumSetuplst) throws EElixirException,RemoteException;
   // Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Ends
   
   
}