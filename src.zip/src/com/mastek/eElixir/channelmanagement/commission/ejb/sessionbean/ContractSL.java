/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractSL.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;

import com.mastek.eElixir.channelmanagement.commission.dvo.ContractProdValidate;
import com.mastek.eElixir.channelmanagement.commission.util.ContractCopyResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.SearchData;
/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This ContractSL Local interface provides method for getting the data from Contract bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 *
 *	Modified On		Modified By		Reason
 *	03/10/2002		Heena Jain		Added searchContractMap(SearchData oSearchData)
 */



public interface ContractSL extends EJBObject
{
  /**
   * Gets the data based on the parameter of DVO
   * @param a_oResultObject Object
   * @return String XML format string object
   * @throws EElixirException
   */
  public String searchContract(Object a_oResultObject) throws EElixirException , FinderException , RemoteException;

  /**
   * Gets the Data depending on the Seq No
   * @param a_lCommAgrmtSeqNbr long
   * @return ContractResult
   * @throws RemoteException
   * @throws FinderException
   * @throws EElixirException
   */
  public ContractResult searchContract(long a_lCommAgrmtSeqNbr) throws RemoteException , FinderException,EElixirException;

  /**
   * Creates the Data from the CHMSLEJB
   * @param a_oContractResult ContractResult
   * @return long
   * @throws RemoteException
   * @throws EJBException
   * @throws EElixirException
   */
  public long createCommissionContract(ContractResult a_oContractResult) throws RemoteException, EJBException, EElixirException;

  /**
   * Invoked by the session bean to look up the Contract EJB. for Deleting a contract
   * @param a_lCommAgrmtSeqNbr long
   * @param a_oContractResult ContractResult
   * @throws RemoteException
   * @throws RemoveException
   * @throws EJBException
   */
  public void deleteContract(long a_lCommAgrmtSeqNbr, ContractResult a_oContractResult) throws RemoteException, RemoveException, EJBException, EElixirException;


  /**
   * Validates a contract, checks to see if unique key constraint is validated or not.
   * @param a_oContractResult ContractResult
   * @return boolean
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public boolean validateContract(ContractResult a_oContractResult) throws EElixirException , FinderException, RemoteException;


  /**
   * Gets the Data from the CHMSLEJB
   * @param request HttpServletRequest
   * @return String
   * @throws EElixirException
   */
   // uncomment this before checking in
  public String searchContractMap(SearchData oSearchData) throws EElixirException , FinderException , RemoteException;
 //uncomment this before checking in

 /**
  * Gets the Data from the CHMSLEJB
  * @return String
  * @throws EElixirException
  */
 public String searchContract() throws EElixirException , FinderException , RemoteException;

 /**
  * Gets the data based on the parameter of DVO
  * @param a_oContractProdValidate ContractProdValidate
  * @return ContractProdValidate
  * @throws EElixirException
  */
  public ContractProdValidate getContractBaseUnit(ContractProdValidate a_oContractProdValidate) throws  FinderException, RemoteException, EElixirException;
  /**
  * Invoked by the session bean to look up the Contract EJB. for copying a contract
  * @param a_oContractCopyResult ContractCopyResult
  * @throws RemoteException
  * @throws EElixirException
  * @throws EJBException
     */
   public void copyContract(ContractCopyResult a_oContractCopyResult) throws FinderException,RemoteException, EElixirException;

   /**
    * Invoked by the session bean to look up the Commission EJB.
    * @param a_oContractResult ContractResult
    * @throws CreateException
    * @throws EJBException
   * @throws EElixirException
    */
    public void updateCommission(ContractResult a_oContractResult) throws CreateException, EJBException, EElixirException, RemoteException;


   //added by vinay

   public long createContractMap(ArrayList  al_ContractMapResult) throws RemoteException , CreateException,EElixirException;

  public ArrayList  searchContractMap(long _iLContMapSeqNbr)
	  throws RemoteException , EElixirException, FinderException;

  public void updateContractMap(ArrayList al_oContractMapResult) throws RemoteException , CreateException,EElixirException;


//code for SelfContract

/**
 * Gets the Data from the CHMSLEJB
 * @param SearchData
 * @return ArrayList
 * @throws EElixirException
   */
        public ArrayList searchSelfContract(SearchData _oSearchData) throws EElixirException , FinderException, RemoteException ;
        /**
         * updates Data from the CHMSLEJB
         * @param ArrayList a_oSelfContractList
         * @return void
         * @throws EElixirException
   */
        public void updateSelfContract(ArrayList a_oSelfContractList) throws RemoteException, EElixirException;


//code for Clawback

/**
 * Gets the Data from the CHMSLEJB
 * @param SearchData
 * @return ArrayList
 * @throws EElixirException
   */
        public ArrayList searchClawback(SearchData _oSearchData) throws EElixirException , FinderException, RemoteException ;
        /**
         * updates Data from the CHMSLEJB
         * @param ArrayList a_oClawbackList
         * @return void
         * @throws EElixirException
   */
        public void updateClawback(ArrayList a_oClawbackList) throws RemoteException, EElixirException;



}