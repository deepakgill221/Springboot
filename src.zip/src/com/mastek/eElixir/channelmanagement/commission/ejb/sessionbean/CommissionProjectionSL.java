/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionProjectionSL.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean;

import java.rmi.RemoteException;

import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;

import com.mastek.eElixir.channelmanagement.commission.util.CommissionProjectionResult;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This CommissionProjectionSL Local interface provides method for getting the data from CommissionProjection bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface CommissionProjectionSL extends EJBObject
{
  /**
   * Gets the data based on the parameter of DVO
   * @param a_oResultObject Object
   * @return String XML format string object
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public String searchCommissionProjection(Object a_oResultObject) throws EElixirException , FinderException , RemoteException;

  /**
   * Gets the Data depending on the Seq No
   * @param lbenseqnbr long
   * @return CommissionProjectionResult
   * @throws FinderException
   * @throws EElixirException
   * @throws RemoteException
   */
  public CommissionProjectionResult searchCommissionProjection(long lbenseqnbr) throws FinderException,EElixirException, RemoteException;
  /**
   * Creates the Data from the CHMSLEJB
   * @param a_oCommissionProjectionResult CommissionProjectionResult
   * @return long
   * @throws EJBException
   * @throws EElixirException
   * @throws RemoteException
   */
  public long createCommissionProjection(CommissionProjectionResult a_oCommissionProjectionResult) throws  EJBException, EElixirException, RemoteException;
  /**
   * Updates data into CommissionProjection
   * @param a_oCommissionProjectionResult CommissionProjectionResult
   * @throws FinderException
   * @throws EElixirException
   * @throws RemoteException
   */
  public void updateCommissionProjection(CommissionProjectionResult a_oCommissionProjectionResult) throws FinderException,EElixirException, RemoteException;
  /**
  * Invoked by	the	session	bean to	look up	the	CommissionProjection EJB. for Deleting a CommissionProjection
  * @param  a_lComProjSeqNbr long
  * @throws RemoveException
  * @throws EJBException
  * @throws EElixirException
  * @throws RemoteException
  */
 public void deleteCommissionProjection(long a_lComProjSeqNbr) throws RemoveException, RemoteException, EJBException, EElixirException;

 /**
 * Invoked by	the	session	bean to	look up	the	CommissionProjection EJB. for Deleting a CommissionProjection
 * @param  a_oCommissionProjectionResult CommissionProjectionResult
 * @throws RemoveException
 * @throws EJBException
 * @throws EElixirException
 * @throws RemoteException
 */
 public void deleteCommissionProjection(CommissionProjectionResult a_oCommissionProjectionResult) throws RemoveException, RemoteException, EJBException, EElixirException;
}