/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMap.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.commission.util.ContractMapResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description: This is a local interface for ContractMappingEJB local entity bean.
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd.</p>
 * @author Vinaysheel
 * @version 1.0
 */


public interface ContractMap extends EJBObject
{
 /**
  * Gets the Data from the ContractMappingSLEJB
  * @return Collection object
  * @throws EElixirExceptionException
  */


  //public Collection getContractMappingCollection();
  //public void setContractMappingCollection(Collection c);

  /* This method gets the ContractMap ResultObject
  * @return AdjustmentResult
  */
  public ContractMapResult getContractMapResult() throws RemoteException, EElixirException;

  /* This method sets the AdjustmentResult Object
  * @param a_oAdjustmentResult AdjustmentResult
  */
  public void setContractMapResult(ContractMapResult a_oContractMapResult) throws RemoteException, EElixirException;


}