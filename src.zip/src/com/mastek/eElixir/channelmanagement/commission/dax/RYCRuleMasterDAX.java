/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterDAX.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: October 29, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashMap;


import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DAXIF;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleAgencyDetails;//Narendra CTS for RYC rule master details as part of to AGN-09
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleDesgDetails;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRulePolicyDetails;




  /**
   * <p>Title: eElixir</p>
   * <p>Description:The DAX implementaion for the RYCRuleMaster object </p>
   * <p>Copyright: Copyright (c) 2005</p>
   * <p>Company: Mastek Ltd</p>
   * @author Sriaknth Kolluri
   * @version 1.0
   */

 public class RYCRuleMasterDAX extends DAX implements DAXIF
 {
   public CHMSqlRepository theCHMSqlRepository= null;

   /**
	* Constructor
	*/

   public RYCRuleMasterDAX()
   {

   }


   public String getRYCRuleMaster() throws EElixirException
	{
		log.debug("FinderFeesDAX--Inside getOtherFinderFees of DAX");

		PreparedStatement pstmtSearchRYCRule= null;
		Statement st = null ;
		StringBuffer sb = new StringBuffer();
		 ResultSet rsSearch=null;
				
		try
		{		
		  log.debug("RYCRuleMasterDAX--before getsqlstring");
		  String strSearchRYCRuleQuery = getSQLString("Select",CHMConstants.RYC_RULES_SEARCH);
		
		  log.debug("strSearchRYCRuleMasterDAXQuery :"+strSearchRYCRuleQuery);

		  log.debug("Getting pre.stmt");

		  pstmtSearchRYCRule = getPreparedStatement(strSearchRYCRuleQuery);

		  log.debug("pstmtSearchRYCRule--->"+pstmtSearchRYCRule);

			rsSearch = executeQuery(pstmtSearchRYCRule);
		
		  log.debug("RYCRuleMasterDAX--before returnin");
		  
  		return XMLConverter.getXMLString(rsSearch);

		 }
		
		 catch(Exception sqlex)
		{
		 throw new EElixirException("P3024");
		}
		finally
		{
		try
		  {
			if(pstmtSearchRYCRule != null)
			pstmtSearchRYCRule.close();
		  }
		catch(SQLException sqlex)
		 {
		  log.exception(sqlex.getMessage());
		  throw new EElixirException("P3024");
		 }
		}

	}


	public String getRYCRuleMaster(SearchData a_oResultObject) throws EElixirException
	{
	
			log.debug("RYCRuleMasterDAX--Inside getRYCRuleMaster(searchdata) of DAX");

			PreparedStatement pstmtSearchRYCRule = null;
			HashMap hmQueryMap = new HashMap();
			SearchData oSearchData = (SearchData) a_oResultObject;
			log.debug("RYCRuleMasterDAX--Search Data" + oSearchData);

			try
			{
				String rycRule = oSearchData.getTask1();
				String nstatus = oSearchData.getTask2();
				String cChannelType = oSearchData.getTask3();

				GregorianCalendar dtEffFrom = oSearchData.getTaskDate1();
				GregorianCalendar dtEffTo = oSearchData.getTaskDate2();

				log.debug("rycRule "+rycRule);
				log.debug("nstatus "+nstatus);
				log.debug("cChannelType "+cChannelType);
				log.debug("dtEffFrom "+dtEffFrom);
				log.debug("dtEffTo "+dtEffTo);
				
				log.debug("RYCRuleMasterDAX--after Search Data");

				String strSearchRYCRuleQuery = getSQLString("Select",
						CHMConstants.RYC_RULES_SEARCH);						

				hmQueryMap.put("Main", strSearchRYCRuleQuery);

				strSearchRYCRuleQuery = " AND STRRYCRULE = ? ";
				hmQueryMap.put("STRRYCRULE", strSearchRYCRuleQuery);			

				strSearchRYCRuleQuery = " AND NSTATUS =  ? ";
				hmQueryMap.put("NSTATUS", strSearchRYCRuleQuery);
				

				strSearchRYCRuleQuery = " AND DTEFFFROM >=  ? ";
	            hmQueryMap.put("DTEFFFROM", strSearchRYCRuleQuery);
	
		        strSearchRYCRuleQuery = " AND DTEFFTO <= ? ";
			    hmQueryMap.put("DTEFFTO", strSearchRYCRuleQuery);

				strSearchRYCRuleQuery = " AND cram.CCHANNELTYPE =  ? ";
			    hmQueryMap.put("CCHANNELTYPE", strSearchRYCRuleQuery);


				/*strSearchRYCRuleQuery = " AND CFD.DTEFFFROM =  ? ";
				hmQueryMap.put("DTEFFFROM", strSearchRYCRuleQuery);*/

				String strQuery = (String) hmQueryMap.get("Main");
				log.debug("RYCRuleMasterDAX--Strquery =" + strQuery);
				
				if ((rycRule != null) && !rycRule.trim().equals(""))
				{
					strQuery += (String) hmQueryMap.get("STRRYCRULE");
				}

				if ((nstatus != null) && !nstatus.trim().equals(""))
				{
					strQuery += (String) hmQueryMap.get("NSTATUS");
				}

				if (dtEffFrom != null)
				{
					strQuery += (String) hmQueryMap.get("DTEFFFROM");
				}
				if (dtEffTo != null)
				{
					strQuery += (String) hmQueryMap.get("DTEFFTO");
				}
				if ((cChannelType != null) && !cChannelType.trim().equals(""))
				{
					strQuery += (String) hmQueryMap.get("CCHANNELTYPE");
				}
				
			
				log.debug("RYCRuleMasterDAX--Strquery =" + strQuery);

				pstmtSearchRYCRule = getPreparedStatement(strQuery);

				log.debug("RYCRuleMasterDAX--Query Formed  " + strQuery);

				int iPosition = 0;
				
				// setting the paramtypecd for prod spec, status values				 	
				//pstmtSearchFinderFees.setInt(++iPosition, DataConstants.YES_NO);
				//pstmtSearchFinderFees.setInt(++iPosition, DataConstants.COMMON_STATUS);
				
				// setting rule name, status, eff date
				if ((rycRule != null) && !rycRule.trim().equals(""))
				{
					log.debug("RYCRuleMasterDAX--Adding rule name "+rycRule);
					pstmtSearchRYCRule.setString(++iPosition, rycRule.trim());
				}

				if ((nstatus != null) && !nstatus.trim().equals(""))
				{
					log.debug("RYCRuleMasterDAX--Adding status ");
					pstmtSearchRYCRule.setInt(++iPosition, Integer.parseInt(nstatus.trim()));
				}
				 if (dtEffFrom != null)
				 {
                log.debug("RYCRuleMasterDAX--Adding Effective Date From");
                pstmtSearchRYCRule.setTimestamp(++iPosition, DateUtil.retTimestamp(dtEffFrom));
				 }

				if (dtEffTo != null)
				{
                log.debug("RYCRuleMasterDAX--Adding Effective Date To");
                pstmtSearchRYCRule.setTimestamp(++iPosition, DateUtil.retTimestamp(dtEffTo));
				}
				if ((cChannelType != null) && !cChannelType.trim().equals(""))
				{
                log.debug("RYCRuleMasterDAX--Adding Channel Type ");
                pstmtSearchRYCRule.setString(++iPosition, cChannelType.trim());
			    }

				
				log.debug("above Runnint stmt");

				ResultSet rsSearch = executeQuery(pstmtSearchRYCRule);	
				
				log.debug("Returning value");
				
				return XMLConverter.getXMLString(rsSearch);
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());

				//throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
				throw new EElixirException(sqlex, "P9001");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9001");
			}
			finally
			{
				try
				{
					if (pstmtSearchRYCRule != null)
					{
						pstmtSearchRYCRule.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}


	/**
		  * findRYCRulesMaster finds whether the RYCRulesMaster is there or not
		  * @return boolean
		  * @param a_lffseqnbr long
		  * @throws EElixirException
		*/
		public boolean findRYCRulesMaster(long a_lffseqnbr) throws EElixirException
		{
			ResultSet rsSearchRYCRuleMaster = null;
			PreparedStatement pstmtFindPrimaryKey = null;

			try
			{
				String strSelectRYCRuleMasterQuery = getSQLString("Select",
						CHMConstants.FIND_RYC_RULE_BY_PRIMARYKEY);

				if (pstmtFindPrimaryKey == null)
				{
					pstmtFindPrimaryKey = getPreparedStatement(strSelectRYCRuleMasterQuery);
				}

				pstmtFindPrimaryKey.setLong(1, a_lffseqnbr);

				rsSearchRYCRuleMaster = executeQuery(pstmtFindPrimaryKey);

				if (rsSearchRYCRuleMaster.next())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());

				//throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
				throw new EElixirException(sqlex, "P9002");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9002");
			}
			finally
			{
				try
				{
					if (rsSearchRYCRuleMaster != null)
					{
						rsSearchRYCRuleMaster.close();
					}

					if (pstmtFindPrimaryKey != null)
					{
						pstmtFindPrimaryKey.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}


	public RYCRuleMasterSearchResult getRYCRulesMaster(long a_lffseqnbr)
			throws EElixirException
	{
			RYCRuleMasterSearchResult oRYCRuleMasterSearchResult = null;
			ResultSet rsSearchRYCRuleMaster = null;			

			PreparedStatement pstmtSearchRYCRuleMaster = null;			

			try			
			{
				String strRYCRuleMasterQuery = getSQLString("Select", CHMConstants.RYC_RULESEQ_SEARCH);
				log.debug("IN DAX method");
				log.debug("RYCRuleMasterDAX--search query is " + strRYCRuleMasterQuery);
				log.debug("RYCRuleMasterDAX--primary key is " + a_lffseqnbr);
				pstmtSearchRYCRuleMaster = getPreparedStatement(strRYCRuleMasterQuery);
				pstmtSearchRYCRuleMaster.setLong(1, a_lffseqnbr);

				log.debug("RYCRuleMasterDAX -- > retrieving RYCRuleMaster Header Data......... ");				 
				rsSearchRYCRuleMaster = executeQuery(pstmtSearchRYCRuleMaster);
				log.debug("RYCRuleMasterDAX--Query executed properly");
				oRYCRuleMasterSearchResult = new RYCRuleMasterSearchResult();				  

				if (rsSearchRYCRuleMaster.next())
				{
					oRYCRuleMasterSearchResult.setIsDirty(DataConstants.DISPLAY_MODE);
					oRYCRuleMasterSearchResult.setFFHDRSeqNbr(new Long(rsSearchRYCRuleMaster.getLong("LRYCSEQNBR")));
//Changed By Narendra to convert from Long to double to take Sum Assured
					oRYCRuleMasterSearchResult.setSumAssumed(new Double(rsSearchRYCRuleMaster.getString("DSA")));
					oRYCRuleMasterSearchResult.setStartYear(new Short(rsSearchRYCRuleMaster.getString("NSTARTPERIOD")));
					oRYCRuleMasterSearchResult.setEndYear(new Short(rsSearchRYCRuleMaster.getString("NENDPERIOD")));
					oRYCRuleMasterSearchResult.setPeriod(new Short(rsSearchRYCRuleMaster.getString("NPRIORYEARS")));
					oRYCRuleMasterSearchResult.setInExValue(new Short(rsSearchRYCRuleMaster.getString("NPOLINCLEXCL")));
					oRYCRuleMasterSearchResult.setTsDtUpdated(rsSearchRYCRuleMaster.getTimestamp("DTUPDATED")); 
					oRYCRuleMasterSearchResult.setStatus(new Short(rsSearchRYCRuleMaster.getString("NSTATUS")));
					oRYCRuleMasterSearchResult.setEffFrom(DateUtil.retGregorian(rsSearchRYCRuleMaster.getTimestamp("DTEFFFROM")));
					oRYCRuleMasterSearchResult.setEffto(DateUtil.retGregorian(rsSearchRYCRuleMaster.getTimestamp("DTEFFTO")));
					oRYCRuleMasterSearchResult.setRYCRule(rsSearchRYCRuleMaster.getString("STRRYCRULE"));
					oRYCRuleMasterSearchResult.setChannelType(rsSearchRYCRuleMaster.getString("CCHANNELTYPE"));
					oRYCRuleMasterSearchResult.setRycRate(rsSearchRYCRuleMaster.getDouble("DRYCRATE"));
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
					oRYCRuleMasterSearchResult.setRuleLevel(new String(rsSearchRYCRuleMaster.getString("NRYCRULELEVEL")));
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
				}
				log.debug("seq method ending");
				log.debug("Result set in DAX  "+oRYCRuleMasterSearchResult);
				
				log.debug("Calling getRYCRuleDesgnDetails");

				getRYCRuleDesgnDetails(oRYCRuleMasterSearchResult);
//Narendra CTS for RYC rule master details as part of to AGN-09 starts

				getRYCRuleAgencyDetails(oRYCRuleMasterSearchResult);

//Narendra CTS for RYC rule master details as part of to AGN-09 ends
				getRYCRulePolicyDetails(oRYCRuleMasterSearchResult);

			
				return oRYCRuleMasterSearchResult;
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P9008");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9008");
			}
			finally
			{
				try
				{
					if (rsSearchRYCRuleMaster != null)
					{
						rsSearchRYCRuleMaster.close();
					}

					if (pstmtSearchRYCRuleMaster != null)
					{
						pstmtSearchRYCRuleMaster.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}

	}


	public RYCRuleMasterSearchResult getRYCRuleDesgnDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult)throws EElixirException
	{
			ResultSet rsSearchRYCRuleDesgnMaster = null;			
			PreparedStatement pstmtSearchRYCRuleMasterDesgn = null;	
			RYCRuleDesgDetails oRYCRuleDesgDetails=null;
	        ArrayList alRYCRuleDesgDetails = new ArrayList();


			try			
			{
				String strRYCRuleMasterQuery = getSQLString("Select", CHMConstants.RYC_RULEDESGN_SEARCH);
				log.debug("IN DAX method");
				log.debug("RYCRuleMasterDAX--search query is " + strRYCRuleMasterQuery);
				pstmtSearchRYCRuleMasterDesgn = getPreparedStatement(strRYCRuleMasterQuery);
				pstmtSearchRYCRuleMasterDesgn.setLong(1, oRYCRuleMasterSearchResult.getFFHDRSeqNbr().longValue());

				log.debug("RYCRuleMasterDAX -- > retrieving RYCRuleMaster Details Data......... ");				 
				rsSearchRYCRuleDesgnMaster = executeQuery(pstmtSearchRYCRuleMasterDesgn);
				log.debug("RYCRuleMasterDAX--Query executed properly");

				while(rsSearchRYCRuleDesgnMaster.next())
				{
					oRYCRuleDesgDetails=new RYCRuleDesgDetails();
					oRYCRuleDesgDetails.setRYCDesgn(rsSearchRYCRuleDesgnMaster.getString("STRDESGNCD"));
					oRYCRuleDesgDetails.setRYCDesgnSeqNbr(new Long(rsSearchRYCRuleDesgnMaster.getLong("LRYCDESGNSEQNBR")));
	                oRYCRuleDesgDetails.setStatusFlag(DataConstants.DISPLAY_MODE);
					alRYCRuleDesgDetails.add(oRYCRuleDesgDetails);

				}
				log.debug("alRYCRuleDesgDetails--->"+alRYCRuleDesgDetails);
				oRYCRuleMasterSearchResult.setRYCRuleDesgDetails(alRYCRuleDesgDetails);
				log.debug("seq method ending");
				log.debug("Result set in DAX  "+oRYCRuleMasterSearchResult);
				
				return oRYCRuleMasterSearchResult;
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P9008");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9008");
			}
			finally
			{
				try
				{
					if (rsSearchRYCRuleDesgnMaster != null)
					{
						rsSearchRYCRuleDesgnMaster.close();
					}

					if (pstmtSearchRYCRuleMasterDesgn != null)
					{
						pstmtSearchRYCRuleMasterDesgn.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
	}
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
	public RYCRuleMasterSearchResult getRYCRuleAgencyDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult)throws EElixirException
	{
			ResultSet rsSearchRYCRuleAgencyMaster = null;
			PreparedStatement pstmtSearchRYCRuleMasterAgency = null;
			RYCRuleAgencyDetails oRYCRuleAgencyDetails=null;
	        ArrayList alRYCRuleAgencyDetails = new ArrayList();


			try
			{
				String strRYCRuleMasterQuery = getSQLString("Select", CHMConstants.RYC_RULEAGENCY_SEARCH);
				log.debug("IN DAX method");
				log.debug("RYCRuleMasterDAX--search query is " + strRYCRuleMasterQuery);
				pstmtSearchRYCRuleMasterAgency = getPreparedStatement(strRYCRuleMasterQuery);
				pstmtSearchRYCRuleMasterAgency.setLong(1, oRYCRuleMasterSearchResult.getFFHDRSeqNbr().longValue());

				log.debug("RYCRuleMasterDAX -- > retrieving RYCRuleMaster Details Data......... ");
				rsSearchRYCRuleAgencyMaster = executeQuery(pstmtSearchRYCRuleMasterAgency);
				log.debug("RYCRuleMasterDAX--Query executed properly");

				while(rsSearchRYCRuleAgencyMaster.next())
				{
					oRYCRuleAgencyDetails=new RYCRuleAgencyDetails();
					oRYCRuleAgencyDetails.setRYCAgency(new Short(rsSearchRYCRuleAgencyMaster.getShort("NAGENCYTYPE")));
					oRYCRuleAgencyDetails.setRYCAgencySeqNbr(new Long(rsSearchRYCRuleAgencyMaster.getLong("LRYCAGENCYSEQNBR")));
	                oRYCRuleAgencyDetails.setStatusFlag(DataConstants.DISPLAY_MODE);
					alRYCRuleAgencyDetails.add(oRYCRuleAgencyDetails);

				}
				log.debug("alRYCRuleAgencyDetails--->"+alRYCRuleAgencyDetails);
				oRYCRuleMasterSearchResult.setRYCRuleAgencyDetails(alRYCRuleAgencyDetails);
				log.debug("seq method ending");
				log.debug("Result set in DAX  "+oRYCRuleMasterSearchResult);

				return oRYCRuleMasterSearchResult;
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P9008");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9008");
			}
			finally
			{
				try
				{
					if (rsSearchRYCRuleAgencyMaster!= null)
					{
						rsSearchRYCRuleAgencyMaster.close();
					}

					if (pstmtSearchRYCRuleMasterAgency  != null)
					{
						pstmtSearchRYCRuleMasterAgency .close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
	}
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
	public RYCRuleMasterSearchResult getRYCRulePolicyDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult)throws EElixirException
	{
			log.debug("RYCRuleMasterDAX--->getRYCRulePolicyDetails");
			ResultSet rsSearchRYCRulePolicyMaster = null;			
			PreparedStatement pstmtSearchRYCRuleMasterPolicy = null;	
			RYCRulePolicyDetails oRYCRulePolicyDetails=null;
	        ArrayList alRYCRulePolicyDetails = new ArrayList();


			try			
			{
				String strRYCRuleMasterQuery = getSQLString("Select", CHMConstants.RYC_RULEPOLICY_SEARCH);
				log.debug("IN DAX method");
				log.debug("RYCRuleMasterDAX--search query is " + strRYCRuleMasterQuery);
				pstmtSearchRYCRuleMasterPolicy = getPreparedStatement(strRYCRuleMasterQuery);
				pstmtSearchRYCRuleMasterPolicy.setLong(1, oRYCRuleMasterSearchResult.getFFHDRSeqNbr().longValue());

				log.debug("RYCRuleMasterDAX -- > retrieving RYCRuleMaster Details Data......... ");				 
				rsSearchRYCRulePolicyMaster = executeQuery(pstmtSearchRYCRuleMasterPolicy);
				log.debug("RYCRuleMasterDAX--Query executed properly");

				while(rsSearchRYCRulePolicyMaster.next())
				{
					oRYCRulePolicyDetails=new RYCRulePolicyDetails();
					oRYCRulePolicyDetails.setRYCPolicy(new Long(rsSearchRYCRulePolicyMaster.getLong("NPOLSTATUS")));
					oRYCRulePolicyDetails.setRYCPolicySeqNbr(new Long(rsSearchRYCRulePolicyMaster.getLong("LRYCPOLSTATSEQNBR")));
	                oRYCRulePolicyDetails.setStatusFlag(DataConstants.DISPLAY_MODE);
					alRYCRulePolicyDetails.add(oRYCRulePolicyDetails);

				}
				oRYCRuleMasterSearchResult.setRYCRulePolicyDetails(alRYCRulePolicyDetails);
				log.debug("seq method ending");
				log.debug("Result set in DAX  "+oRYCRuleMasterSearchResult);
				
				return oRYCRuleMasterSearchResult;
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P9008");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9008");
			}
			finally
			{
				try
				{
					if (rsSearchRYCRulePolicyMaster != null)
					{
						rsSearchRYCRulePolicyMaster.close();
					}

					if (pstmtSearchRYCRuleMasterPolicy != null)
					{
						pstmtSearchRYCRuleMasterPolicy.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
	}







	public long createRYCRuleMaster(RYCRuleMasterSearchResult a_oRYCRuleMasterSearchResult)
										throws EElixirException
	{
			PreparedStatement pstmtCreateRYCRuleMaster = null;
			ArrayList alRYCAgencyDetails = null;//Narendra CTS for RYC rule master details as part of to AGN-09
	        ArrayList alRYCRuleDesgDetails = null;
			ArrayList alRYCRulePolicyDetails = null;
		
			long lffseqnbr;
			String strCreatedBy = null;

			try
			{
				String rycRule = a_oRYCRuleMasterSearchResult.getRYCRule();

				String channelType = a_oRYCRuleMasterSearchResult.getChannelType();
				
				GregorianCalendar dtEffFrom = a_oRYCRuleMasterSearchResult.getEffFrom();	

				GregorianCalendar dtEffTo = a_oRYCRuleMasterSearchResult.getEffTo();				
				
				Short nStatus = a_oRYCRuleMasterSearchResult.getStatus();
//Changed By Narendra to convert from Long to double to take Sum Assured
				Double dSumAssumed = a_oRYCRuleMasterSearchResult.getSumAssumed();

				Short nPeriod = a_oRYCRuleMasterSearchResult.getPeriod();
				
				Short nStartYear = a_oRYCRuleMasterSearchResult.getStartYear();				
				
				Short nEndYear = a_oRYCRuleMasterSearchResult.getEndYear();

				Short radioInExclude = a_oRYCRuleMasterSearchResult.getInExValue();
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
				String nRYCRuleLevel = a_oRYCRuleMasterSearchResult.getRuleLevel();
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
				double dRycRate= a_oRYCRuleMasterSearchResult.getRycRate();


				String strUserId=a_oRYCRuleMasterSearchResult.getUserId();

				log.debug("radioInExclude---->"+radioInExclude+"<-------------");

				// Before inserting a new record this function generates a new Seq no, on which the
				// new record is inserted.
				 long lRYCRuleSeqNbr = getNextRYCRuleSeqNbr();



				log.debug("RYCRuleMasterDAX--------------the dax created newkey----" +
					lRYCRuleSeqNbr);

				String strCreateRYCRuleMasterQuery = getSQLString("Insert",
						CHMConstants.RYCRULEMASTER_INSERT);

				log.debug("RYCRuleMasterDAX--strCreateRYCRuleMasterQuery =" + strCreateRYCRuleMasterQuery);
				pstmtCreateRYCRuleMaster = getPreparedStatement(strCreateRYCRuleMasterQuery);

				int iPos=0;
				pstmtCreateRYCRuleMaster.setLong(++iPos, lRYCRuleSeqNbr);
//Changed By Narendra to convert from Long to double to take Sum Assured
				pstmtCreateRYCRuleMaster.setDouble(++iPos, dSumAssumed.doubleValue());
				pstmtCreateRYCRuleMaster.setShort(++iPos,nStartYear.shortValue());				 				
				pstmtCreateRYCRuleMaster.setShort(++iPos,nEndYear.shortValue());				 				
				pstmtCreateRYCRuleMaster.setShort(++iPos,nPeriod.shortValue());
				pstmtCreateRYCRuleMaster.setShort(++iPos,radioInExclude.shortValue());
				pstmtCreateRYCRuleMaster.setString(++iPos, strUserId);
				pstmtCreateRYCRuleMaster.setShort(++iPos,nStatus.shortValue());		
				pstmtCreateRYCRuleMaster.setTimestamp(++iPos, DateUtil.retTimestamp(dtEffFrom));	
				pstmtCreateRYCRuleMaster.setTimestamp(++iPos, DateUtil.retTimestamp(dtEffTo));				
				pstmtCreateRYCRuleMaster.setString(++iPos, rycRule);
				pstmtCreateRYCRuleMaster.setString(++iPos, channelType);
				pstmtCreateRYCRuleMaster.setDouble(++iPos, dRycRate);
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
				pstmtCreateRYCRuleMaster.setString(++iPos,nRYCRuleLevel);
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
				int icount = executeUpdate(pstmtCreateRYCRuleMaster);
				log.debug("RYCRuleMasterDAX--" + icount);
				log.debug("RYCRuleMasterDAX-------------- storing newkey----" +lRYCRuleSeqNbr);
				
				a_oRYCRuleMasterSearchResult.setFFHDRSeqNbr(new Long(lRYCRuleSeqNbr));					
				
				log.debug("RYCRuleMasterDAX--End of createRYCRuleMaster Main Record");		
				
				log.debug("calling insertTransStatus");
				// inserting record in approaval transactions table.
				insertTransStatus(lRYCRuleSeqNbr, strUserId);
//Narendra CTS Updated code starts for RYC rule master details as part of to AGN-09
				if(new Short(nRYCRuleLevel).shortValue() != DataConstants.RYC_AGENCY)
				{

				alRYCRuleDesgDetails = a_oRYCRuleMasterSearchResult.getRYCRuleDesgDetails();
				log.debug("above if condition in dax");
					if(alRYCRuleDesgDetails != null && alRYCRuleDesgDetails.size() > 0){
						log.debug("alRYCRuleDesgDetails.size() : " + alRYCRuleDesgDetails.size());
						RYCRuleDesgDetails oRYCRuleDesgDetails = new RYCRuleDesgDetails();
						for(int i=0;i<alRYCRuleDesgDetails.size();i++){
							oRYCRuleDesgDetails = (RYCRuleDesgDetails)alRYCRuleDesgDetails.get(i);
							log.debug("oRYCRuleDesgDetails.toString() : " + oRYCRuleDesgDetails.toString());
							createRYCRuleDesgDetails(oRYCRuleDesgDetails,lRYCRuleSeqNbr,
							a_oRYCRuleMasterSearchResult.getUserId());
						} 
					}


						}
				else
				{
				alRYCAgencyDetails = a_oRYCRuleMasterSearchResult.getRYCRuleAgencyDetails();
				log.debug("above if condition in dax");
					if(alRYCAgencyDetails != null && alRYCAgencyDetails.size() > 0){
						log.debug("alRYCRuleDesgDetails.size() : " + alRYCAgencyDetails.size());
						RYCRuleAgencyDetails oRYCAgencyDetails = new RYCRuleAgencyDetails();
						log.debug("createing object ");
						for(int i=0;i<alRYCAgencyDetails.size();i++){
						    log.debug("In the loop on agency details"+alRYCAgencyDetails.size() );

							oRYCAgencyDetails = (RYCRuleAgencyDetails)alRYCAgencyDetails.get(i);

							log.debug("oRYCRuleAgencyDetails.toString() : " + oRYCAgencyDetails.toString());
							createRYCRuleAgencyDetails(oRYCAgencyDetails,lRYCRuleSeqNbr,
							a_oRYCRuleMasterSearchResult.getUserId());
						}
                     }

				}
//Narendra CTS Updated code ends for RYC rule master details as part of to AGN-09
				alRYCRulePolicyDetails = a_oRYCRuleMasterSearchResult.getRYCRulePolicyDetails();
				log.debug("above if condition in dax");
					if(alRYCRulePolicyDetails != null && alRYCRulePolicyDetails.size() > 0){
						log.debug("alRYCRulePolicyDetails.size() : " + alRYCRulePolicyDetails.size());
						RYCRulePolicyDetails oRYCRulePolicyDetails = new RYCRulePolicyDetails();
						for(int i=0;i<alRYCRulePolicyDetails.size();i++){
							oRYCRulePolicyDetails = (RYCRulePolicyDetails)alRYCRulePolicyDetails.get(i);
							log.debug("oRYCRulePolicyDetails.toString() : " + oRYCRulePolicyDetails.toString());
							createRYCRulePolicyDetails(oRYCRulePolicyDetails,lRYCRuleSeqNbr,
							a_oRYCRuleMasterSearchResult.getUserId());
						} 
					}
							   
				return lRYCRuleSeqNbr;
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());

				//throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
				throw new EElixirException(sqlex, "P9007");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw eex;
			}
			finally
			{
				try
				{
					if (pstmtCreateRYCRuleMaster != null)
					{
						pstmtCreateRYCRuleMaster.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}


	public void createRYCRuleDesgDetails(RYCRuleDesgDetails oRYCRuleDesgDetails,long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCDesgnCreate = null;
	try
		{
		log.debug("In createRYCRuleDesgDetails");
		  String strDesgnCd = oRYCRuleDesgDetails.getRYCDesgn();
		  
		  if(strDesgnCd != null && !strDesgnCd.equals("")){
		  
			  long lSeqDesgn = getNextRYCDesgnSeqNbr();
			  
			  log.debug("lSeqDesgn :in create ---->" + lSeqDesgn);		  
				
			  String strRYCDesgnQuery = getSQLString("Insert",CHMConstants.RYCRULEDESGN_INSERT);

			  log.debug("strRYCDesgnQuery---->"+strRYCDesgnQuery);
			  
			  
			  pstmtRYCDesgnCreate = getPreparedStatement(strRYCDesgnQuery);
	
			  int insertPos = 0;

			  pstmtRYCDesgnCreate.setString(++insertPos, strDesgnCd);

			pstmtRYCDesgnCreate.setString(++insertPos, a_strUserId);		
			  
			  if(lSeqDesgn != 0)
			  {
				pstmtRYCDesgnCreate.setLong(++insertPos, lSeqDesgn);			
			  }
	        
			  if(seqno!= 0)
			  {
				pstmtRYCDesgnCreate.setLong(++insertPos, seqno);
			  }
	
	
			  int insertedRows =  executeUpdate(pstmtRYCDesgnCreate);
			  log.debug(" insertedRows for Desgn is:"+insertedRows);
		  }
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */	  	
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCDesgnCreate != null)
				{
					pstmtRYCDesgnCreate.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */	  	
			  ex.printStackTrace();		  	
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}
	
//Narendra CTS for RYC rule master details as part of to AGN-09 starts

	public void createRYCRuleAgencyDetails(RYCRuleAgencyDetails oRYCRuleAgencyDetails,long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCAgencyCreate = null;
	try
		{
		log.debug("In createRYCRuleDesgDetails");
		  Short strAgencyCd = oRYCRuleAgencyDetails.getRYCAgency();

		  if(strAgencyCd != null && !strAgencyCd.equals("")){

			  long lSeqAgency = getNextRYCAgencySeqNbr();

			  log.debug("lSeqDesgn :in create ---->" + lSeqAgency);

			  String strRYCAgencyQuery = getSQLString("Insert",CHMConstants.RYCRULEAGENCY_INSERT);

			  log.debug("strRYCAgencyQuery---->"+strRYCAgencyQuery);


			  pstmtRYCAgencyCreate = getPreparedStatement(strRYCAgencyQuery);

			  int insertPos = 0;

			  pstmtRYCAgencyCreate.setShort(++insertPos, strAgencyCd.shortValue());

			  pstmtRYCAgencyCreate.setString(++insertPos, a_strUserId);

			  if(lSeqAgency != 0)
			  {
				  pstmtRYCAgencyCreate.setLong(++insertPos, lSeqAgency);
			  }

			  if(seqno!= 0)
			  {
				  pstmtRYCAgencyCreate.setLong(++insertPos, seqno);
			  }


			  int insertedRows =  executeUpdate(pstmtRYCAgencyCreate);
			  log.debug(" insertedRows for Desgn is:"+insertedRows);
		  }
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCAgencyCreate != null)
				{
					pstmtRYCAgencyCreate.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */
			  ex.printStackTrace();
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}
//Narendra CTS for RYC rule master details as part of to AGN-09 ends

	public void createRYCRulePolicyDetails(RYCRulePolicyDetails oRYCRulePolicyDetails,long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCPolicyCreate = null;
	try
		{
			log.debug("In createRYCRulePolicyDetails");
	
		  Long strPolicyCd = oRYCRulePolicyDetails.getRYCPolicy();
		  
			  long lSeqPolicy = getNextRYCPolicySeqNbr();
			  
			  log.debug("lSeqPolicy :in create ---->" + lSeqPolicy);		  
				
			  String strRYCPolicyQuery = getSQLString("Insert",CHMConstants.RYCRULEPOLICY_INSERT);

			  log.debug("strRYCPolicyQuery---->"+strRYCPolicyQuery);
			  
			  
			  pstmtRYCPolicyCreate = getPreparedStatement(strRYCPolicyQuery);
	
			  int insertPos = 0;

			  pstmtRYCPolicyCreate.setLong(++insertPos, strPolicyCd.longValue());

			pstmtRYCPolicyCreate.setString(++insertPos, a_strUserId);		
			  
			  if(lSeqPolicy != 0)
			  {
				pstmtRYCPolicyCreate.setLong(++insertPos, lSeqPolicy);			
			  }
	        
			  if(seqno!= 0)
			  {
				pstmtRYCPolicyCreate.setLong(++insertPos, seqno);
			  }
	
	
			  int insertedRows =  executeUpdate(pstmtRYCPolicyCreate);
			  log.debug(" insertedRows for Policy is:"+insertedRows);
	
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */	  	
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCPolicyCreate != null)
				{
					pstmtRYCPolicyCreate.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */	  	
			  ex.printStackTrace();		  	
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}



		public void insertTransStatus(long lRYCRuleSeqNbr, String strUser) throws EElixirException
		{
		  log.debug("RYCRuleMasterDAX: in inserttransstatus: seqnbr" + lRYCRuleSeqNbr + " userid " + strUser);
		  PreparedStatement pstmtApprovalInsert = null;
		
		  try
		  {
			 String strInsertApplication = getSQLString("Insert",CHMConstants.TRANSACTION_STATUS_INSERT);
			 log.debug("FinderFeesDAX: The Trans status query " + strInsertApplication);
		
			 pstmtApprovalInsert = getPreparedStatement(strInsertApplication);
		
			 pstmtApprovalInsert.setInt(1,DataConstants.TRANSACTOIN_RYCRULE);
			 log.debug("RYCRuleMasterDAX: set 1st param  " + DataConstants.TRANSACTOIN_RYCRULE);
		
			 pstmtApprovalInsert.setLong(2, lRYCRuleSeqNbr);
			 log.debug("RYCRuleMasterDAX: set 2nd param  " + lRYCRuleSeqNbr);
		
			 pstmtApprovalInsert.setInt(3,DataConstants.STATUS_PENDING_ID);
			 log.debug("RYCRuleMasterDAX: set 3rd param  " + DataConstants.STATUS_PENDING_ID);		
				
			 pstmtApprovalInsert.setString(4,""); //to be clarified
			 log.debug("RYCRuleMasterDAX: set 5th param  " );
		
			 pstmtApprovalInsert.setString(5, strUser); //to be clarified
			 log.debug("RYCRuleMasterDAX: set 6th param  "+strUser );
		
			 log.debug("brfore execute inserttransstatus");
			 int iInsertApplication = executeUpdate(pstmtApprovalInsert);
			log.debug("RYCRuleMasterDAX: Trans status Insert over");
		}
			catch(SQLException sqlex)	
			{
			   log.exception(sqlex.getMessage());
			   throw new EElixirException(sqlex, "P1010");
		   }
		   catch(EElixirException eex)
		   {
			  log.exception(eex.getMessage());
			 throw new EElixirException(eex,"P1010");
		   }
		}

	public void updateRYCRuleMaster(RYCRuleMasterSearchResult a_oRYCRuleMasterSearchResult)
			throws EElixirException
	{
			PreparedStatement pstmtUpdateRYCRuleMaster = null;
	        ArrayList alRYCRuleDesgDetails = null;
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
	        ArrayList alRYCRuleAgencyDetails = null;
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
	        ArrayList alRYCRulePolicyDetails = null;


			
			long lffseqnbr;
			String strCreatedBy = null;

			try
			{
				String rycRule = a_oRYCRuleMasterSearchResult.getRYCRule();

				String channelType = a_oRYCRuleMasterSearchResult.getChannelType();
				
				GregorianCalendar dtEffFrom = a_oRYCRuleMasterSearchResult.getEffFrom();	

				GregorianCalendar dtEffTo = a_oRYCRuleMasterSearchResult.getEffTo();				
//Changed By Narendra to convert from Long to double to take Sum Assured
				Double dSumAssumed = a_oRYCRuleMasterSearchResult.getSumAssumed();

				Short nPeriod = a_oRYCRuleMasterSearchResult.getPeriod();
				
				Short nStartYear = a_oRYCRuleMasterSearchResult.getStartYear();				
				
				Short nEndYear = a_oRYCRuleMasterSearchResult.getEndYear();


				String strUserId=a_oRYCRuleMasterSearchResult.getUserId();

				Long rycHdrSeqNbr=a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr();

				Short radioInExclude = a_oRYCRuleMasterSearchResult.getInExValue();
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
				String nRYCRuleLevel = a_oRYCRuleMasterSearchResult.getRuleLevel();
//Narendra CTS for RYC rule master details as part of to AGN-09 ends


				String strUpdateRYCRuleMasterQuery = getSQLString("Update",CHMConstants.RYCRULEMASTER_UPDATE);
				pstmtUpdateRYCRuleMaster = getPreparedStatement(strUpdateRYCRuleMasterQuery);

				int iPos=0;
//Changed By Narendra to convert from Long to double to take Sum Assured
				pstmtUpdateRYCRuleMaster.setDouble(++iPos, dSumAssumed.doubleValue());
				pstmtUpdateRYCRuleMaster.setShort(++iPos,nStartYear.shortValue());				 				
				pstmtUpdateRYCRuleMaster.setShort(++iPos,nEndYear.shortValue());				 				
				pstmtUpdateRYCRuleMaster.setShort(++iPos,nPeriod.shortValue());
				pstmtUpdateRYCRuleMaster.setShort(++iPos,radioInExclude.shortValue());
				pstmtUpdateRYCRuleMaster.setString(++iPos,strUserId);
				pstmtUpdateRYCRuleMaster.setTimestamp(++iPos, DateUtil.retTimestamp(dtEffFrom));	
				pstmtUpdateRYCRuleMaster.setTimestamp(++iPos, DateUtil.retTimestamp(dtEffTo));				
				pstmtUpdateRYCRuleMaster.setString(++iPos, rycRule);
				pstmtUpdateRYCRuleMaster.setString(++iPos, channelType);
				pstmtUpdateRYCRuleMaster.setDouble(++iPos,a_oRYCRuleMasterSearchResult.getRycRate() );
				
				pstmtUpdateRYCRuleMaster.setLong(++iPos,rycHdrSeqNbr.longValue() );
								int icount = executeUpdate(pstmtUpdateRYCRuleMaster);
				log.debug("RYCRuleMasterDAX--" + icount);
				
			
				log.debug("calling insertTransStatus");
//Narendra CTS Updated code starts for RYC rule master details as part of to AGN-09
				if(new Short(nRYCRuleLevel).shortValue() != DataConstants.RYC_AGENCY)
				{
				// inserting record in approaval transactions table.

				alRYCRuleDesgDetails = a_oRYCRuleMasterSearchResult.getRYCRuleDesgDetails();
				log.debug("above if condition in dax");
					if(alRYCRuleDesgDetails != null && alRYCRuleDesgDetails.size() > 0){

						log.debug("alRYCRuleDesgDetails.size() : " + alRYCRuleDesgDetails.size());
						addUpdateDeleteRYCRuleDesgDetails(a_oRYCRuleMasterSearchResult);
	
					}
				}
				else
				{
					alRYCRuleAgencyDetails = a_oRYCRuleMasterSearchResult.getRYCRuleAgencyDetails();
					log.debug("above if condition in dax");
						if(alRYCRuleAgencyDetails != null && alRYCRuleAgencyDetails.size() > 0){

							log.debug("alRYCRuleAgencyDetails.size() : " + alRYCRuleAgencyDetails.size());
							addUpdateDeleteRYCRuleAgencyDetails(a_oRYCRuleMasterSearchResult);
						}
				}

//Narendra CTS Updated code ends for RYC rule master details as part of to AGN-09
				alRYCRulePolicyDetails = a_oRYCRuleMasterSearchResult.getRYCRulePolicyDetails();
				log.debug("above if condition in dax");
					if(alRYCRulePolicyDetails != null && alRYCRulePolicyDetails.size() > 0){

						log.debug("alRYCRulePolicyDetails.size() : " + alRYCRulePolicyDetails.size());
						addUpdateDeleteRYCRulePolicyDetails(a_oRYCRuleMasterSearchResult);
	
					}
				
			}				
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());

				//throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
				throw new EElixirException(sqlex, "P9007");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw eex;
			}
			finally
			{
				try
				{
					if (pstmtUpdateRYCRuleMaster != null)
					{
						pstmtUpdateRYCRuleMaster.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}

	public void deleteRYCRuleMaster(Long rycHdrSeqNbr)
							 throws EElixirException
	{
		PreparedStatement pstmtRYCDelete = null;
		try
		{
		log.debug("In createRYCRuleDetails");

		  String strRYCQuery = getSQLString("Delete",CHMConstants.RYCRULE_DELETE);

		  log.debug("strRYCQuery---->"+strRYCQuery);
			  
		  pstmtRYCDelete = getPreparedStatement(strRYCQuery);
	
		 int insertPos = 0;

			if(rycHdrSeqNbr.longValue()!= 0)
			 {
				pstmtRYCDelete.setLong(++insertPos, rycHdrSeqNbr.longValue());
			  }
			  
			
			  int deletedRows =  executeUpdate(pstmtRYCDelete);
//Narendra CTS Updated code starts for RYC rule master details as part of to AGN-09
			  deleteRYCRuleSubDetails(CHMConstants.RYCRULE_DESGN_DELETE_HDR,rycHdrSeqNbr);

			  deleteRYCRuleSubDetails(CHMConstants.RYCRULE_POLICY_DELETE_HDR,rycHdrSeqNbr);

			  deleteRYCRuleSubDetails(CHMConstants.RYCRULE_AGENCY_DELETE_HDR,rycHdrSeqNbr);
//Narendra CTS Updated code ends for RYC rule master details as part of to AGN-09
			  log.debug(" deletedRows for  is:"+deletedRows);
		  
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */	  	
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCDelete != null)
				{
					pstmtRYCDelete.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */	  	
			  ex.printStackTrace();		  	
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}
		


	public void addUpdateDeleteRYCRuleDesgDetails(RYCRuleMasterSearchResult a_oRYCRuleMasterSearchResult)
		throws EElixirException
	{
		log.debug("addUpdateDeleteRYCRuledesgnDetails");
		ArrayList alRYCRuleDesgDetails = a_oRYCRuleMasterSearchResult.getRYCRuleDesgDetails();
		RYCRuleDesgDetails oRYCRuleDesgDetails = null; //new RYCRuleDesgDetails();
		log.debug("alRYCRuleDesgDetails.size() : " + alRYCRuleDesgDetails.size());
		int iSize=alRYCRuleDesgDetails.size();
		
		for (int i = 0; i < iSize; i++)
		{
		    oRYCRuleDesgDetails  = (RYCRuleDesgDetails ) alRYCRuleDesgDetails.get(i);
			String strStatusFlag = oRYCRuleDesgDetails.getStatusFlag();
			

			if (strStatusFlag == null)
			{
				strStatusFlag = DataConstants.UPDATE_MODE;
				log.debug("alRYCRuleDesgDetails.Status()UPdate:--->"+strStatusFlag);
			}

			if (strStatusFlag.equals(DataConstants.INSERT_MODE))
			{
			
				createRYCRuleDesgDetails(oRYCRuleDesgDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr().longValue(),
							a_oRYCRuleMasterSearchResult.getUserId());
				log.debug("alRYCRuleDesgDetails.Status()Insert:--->"+strStatusFlag);
			}

			if (strStatusFlag.equals(DataConstants.UPDATE_MODE))
			{
				log.debug("alRYCRuleDesgDetails.Status()Update:--->"+strStatusFlag);
			  updateRYCRuleDesgDetails(oRYCRuleDesgDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr(),
							a_oRYCRuleMasterSearchResult.getUserId());
			}

			if (strStatusFlag.equals(DataConstants.DELETE_MODE))
			{
				log.debug("alRYCRuleDesgDetails.Status() Delete:--->"+strStatusFlag);
				deleteRYCRuleDesgDetails(oRYCRuleDesgDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr(),
							a_oRYCRuleMasterSearchResult.getUserId());
			}
		}
	}


//Narendra CTS for RYC rule master details as part of to AGN-09 starts
	public void addUpdateDeleteRYCRuleAgencyDetails(RYCRuleMasterSearchResult a_oRYCRuleMasterSearchResult)
	throws EElixirException
{
	log.debug("addUpdateDeleteRYCRuleagencyDetails");
	ArrayList alRYCRuleAgencyDetails = a_oRYCRuleMasterSearchResult.getRYCRuleAgencyDetails();
	RYCRuleAgencyDetails oRYCRuleAgencyDetails = null; //new RYCRuleAgencyDetails();
	log.debug("alRYCRuleAgencyDetails.size() : " + alRYCRuleAgencyDetails.size());
	int iSize=alRYCRuleAgencyDetails.size();

	for (int i = 0; i < iSize; i++)
	{
		oRYCRuleAgencyDetails  = (RYCRuleAgencyDetails ) alRYCRuleAgencyDetails.get(i);
		String strStatusFlag = oRYCRuleAgencyDetails.getStatusFlag();


		if (strStatusFlag == null)
		{
			strStatusFlag = DataConstants.UPDATE_MODE;
			log.debug("alRYCRuleAgencyDetails.Status()UPdate:--->"+strStatusFlag);
		}

		if (strStatusFlag.equals(DataConstants.INSERT_MODE))
		{

			createRYCRuleAgencyDetails(oRYCRuleAgencyDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr().longValue(),
						a_oRYCRuleMasterSearchResult.getUserId());
			log.debug("alRYCRuleAgencyDetails.Status()Insert:--->"+strStatusFlag);
		}

		if (strStatusFlag.equals(DataConstants.UPDATE_MODE))
		{
			log.debug("alRYCRuleAgencyDetails.Status()Update:--->"+strStatusFlag);
			updateRYCRuleAgencyDetails(oRYCRuleAgencyDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr(),
						a_oRYCRuleMasterSearchResult.getUserId());
		}

		if (strStatusFlag.equals(DataConstants.DELETE_MODE))
		{
			log.debug("alRYCRuleAgencyDetails.Status() Delete:--->"+strStatusFlag);
			deleteRYCRuleAgencyDetails(oRYCRuleAgencyDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr(),
						a_oRYCRuleMasterSearchResult.getUserId());
		}
	}
}
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
	public void addUpdateDeleteRYCRulePolicyDetails(RYCRuleMasterSearchResult a_oRYCRuleMasterSearchResult)
		throws EElixirException
	{
	
		ArrayList alRYCRulePolicyDetails = a_oRYCRuleMasterSearchResult.getRYCRulePolicyDetails();
		RYCRulePolicyDetails oRYCRulePolicyDetails = null; //new RYCRulePolicyDetails();
	
		int iSize=alRYCRulePolicyDetails.size();
		log.debug("addUpdateDeleteRYCRulePolicyDetails.Status() iSize:--->"+iSize);
		for (int i = 0; i < iSize; i++)
		{
		    oRYCRulePolicyDetails  = (RYCRulePolicyDetails ) alRYCRulePolicyDetails.get(i);
			String strStatusFlag = oRYCRulePolicyDetails.getStatusFlag();
			log.debug("addUpdateDeleteRYCRulePolicyDetails.Status() strStatusFlag:--->"+strStatusFlag);

			if (strStatusFlag == null)
			{
	
				strStatusFlag = DataConstants.UPDATE_MODE;
				log.debug("addUpdateDeleteRYCRulePolicyDetails.Status() strStatusFlag:Update --->"+strStatusFlag);

			}

			if (strStatusFlag.equals(DataConstants.INSERT_MODE))
			{
				log.debug("addUpdateDeleteRYCRulePolicyDetails.Status() strStatusFlag:Insert--->"+strStatusFlag);

				createRYCRulePolicyDetails(oRYCRulePolicyDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr().longValue(),
							a_oRYCRuleMasterSearchResult.getUserId());
			}

			if (strStatusFlag.equals(DataConstants.UPDATE_MODE))
			{
				log.debug("addUpdateDeleteRYCRulePolicyDetails.Status() strStatusFlag:Update--->"+strStatusFlag);

	    	  updateRYCRulePolicyDetails(oRYCRulePolicyDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr(),
							a_oRYCRuleMasterSearchResult.getUserId());
			}

			if (strStatusFlag.equals(DataConstants.DELETE_MODE))
			{
				log.debug("addUpdateDeleteRYCRulePolicyDetails.Status() strStatusFlag:delete--->"+strStatusFlag);

				deleteRYCRulePolicyDetails(oRYCRulePolicyDetails,a_oRYCRuleMasterSearchResult.getFFHDRSeqNbr(),
							a_oRYCRuleMasterSearchResult.getUserId());
			}
		}
	}


	


	public void updateRYCRuleDesgDetails(RYCRuleDesgDetails oRYCRuleDesgDetails,Long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCDesgnUpdate = null;
	try
		{
			log.debug("Inside updateRYCRuleDesgDetails");
		  String strDesgnCd = oRYCRuleDesgDetails.getRYCDesgn();
		  log.debug("Inside updateRYCRuleDesgDetails-----strDesgnCd:-->"+strDesgnCd);
		  Long rycDesgnSeqNo=oRYCRuleDesgDetails.getRYCDesgnSeqNbr();
		  log.debug("Inside updateRYCRuleDesgDetails-----rycDesgnSeqNo:-->"+rycDesgnSeqNo);
		  
		  if(strDesgnCd != null && !strDesgnCd.equals(""))
			{
			
			  String strRYCDesgnQuery = getSQLString("Update",CHMConstants.RYCRULEDESGN_UPDATE);
			  log.debug("Inside updateRYCRuleDesgDetails Query-----:-->"+strRYCDesgnQuery);
			  pstmtRYCDesgnUpdate = getPreparedStatement(strRYCDesgnQuery);
			  log.debug("Inside updateRYCRuleDesgDetails Query-----strDesgnCd:-->"+strDesgnCd);
			  int insertPos = 0;
			  log.debug("Inside updateRYCRuleDesgDetails pstmtRYCDesgnUpdate:-->"+pstmtRYCDesgnUpdate);
			  pstmtRYCDesgnUpdate.setString(++insertPos, strDesgnCd);
			  pstmtRYCDesgnUpdate.setString(++insertPos, a_strUserId);
			
			  if(rycDesgnSeqNo.longValue() != 0)
			  {
				log.debug("Inside updateRYCRuleDesgDetails-----rycDesgnSeqNo:-->"+rycDesgnSeqNo);
				pstmtRYCDesgnUpdate.setLong(++insertPos, rycDesgnSeqNo.longValue());			
			  }
			  if(seqno.longValue()!= 0)
				  {
							 log.debug("Inside updateRYCRuleDesgDetails-----seqno:-->"+seqno);
							 pstmtRYCDesgnUpdate.setLong(++insertPos, seqno.longValue());
				  }
				log.debug("Inside updateRYCRuleDesgDetails pstmtRYCDesgnUpdate BEFORE EXECUTE:-->"+pstmtRYCDesgnUpdate);
			  int updatedRows =  executeUpdate(pstmtRYCDesgnUpdate);
			  log.debug("updatedRows:----->"+updatedRows);
			 
		  }
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */	  	
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCDesgnUpdate != null)
				{
					pstmtRYCDesgnUpdate.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */	  	
			  ex.printStackTrace();		  	
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}

//Narendra CTS for RYC rule master details as part of to AGN-09 starts

	public void updateRYCRuleAgencyDetails(RYCRuleAgencyDetails oRYCRuleAgencyDetails,Long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCAgencyUpdate = null;
	try
		{
			log.debug("Inside updateRYCRuleAgencyDetails");
		  Short strAgencyCd = oRYCRuleAgencyDetails.getRYCAgency();
		  log.debug("Inside updateRYCRuleAgencyDetails-----strAgencyCd:-->"+strAgencyCd);
		  Long rycAgencySeqNo=oRYCRuleAgencyDetails.getRYCAgencySeqNbr();
		  log.debug("Inside updateRYCRuleAgencyDetails-----rycAgencySeqNo:-->"+rycAgencySeqNo);

		  if(strAgencyCd != null && !strAgencyCd.equals(""))
			{

			  String strRYCAgencyQuery = getSQLString("Update",CHMConstants.RYCRULEAGENCY_UPDATE);
			  log.debug("Inside updateRYCRuleAgencyDetails Query-----:-->"+strRYCAgencyQuery);
			  pstmtRYCAgencyUpdate = getPreparedStatement(strRYCAgencyQuery);
			  log.debug("Inside updateRYCRuleAgencyDetails Query-----strAgencyCd:-->"+strAgencyCd);
			  int insertPos = 0;
			  log.debug("Inside updateRYCRuleAgencyDetails pstmtRYCAgencyUpdate:-->"+pstmtRYCAgencyUpdate);
			  pstmtRYCAgencyUpdate.setShort(++insertPos, strAgencyCd.shortValue());
			  pstmtRYCAgencyUpdate.setString(++insertPos, a_strUserId);

			  if(rycAgencySeqNo.longValue() != 0)
			  {
				log.debug("Inside updateRYCRuleAgencyDetails-----rycAgencySeqNo:-->"+rycAgencySeqNo);
				pstmtRYCAgencyUpdate.setLong(++insertPos, rycAgencySeqNo.longValue());
			  }
			  if(seqno.longValue()!= 0)
				  {
							 log.debug("Inside updateRYCRuleAgencyDetails-----seqno:-->"+seqno);
							 pstmtRYCAgencyUpdate.setLong(++insertPos, seqno.longValue());
				  }
				log.debug("Inside updateRYCRuleAgencyDetails pstmtRYCAgencyUpdate BEFORE EXECUTE:-->"+pstmtRYCAgencyUpdate);
			  int updatedRows =  executeUpdate(pstmtRYCAgencyUpdate);
			  log.debug("updatedRows:----->"+updatedRows);

		  }
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCAgencyUpdate != null)
				{
					pstmtRYCAgencyUpdate.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */
			  ex.printStackTrace();
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}

	public void deleteRYCRuleAgencyDetails(RYCRuleAgencyDetails oRYCRuleAgencyDetails,Long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCAgencyDelete = null;
		try
		{


		  Long rycAgencySeqNo=oRYCRuleAgencyDetails.getRYCAgencySeqNbr();

		  String strRYCAgencyQuery = getSQLString("Delete",CHMConstants.RYCRULEAGENCY_DELETE);



		  pstmtRYCAgencyDelete = getPreparedStatement(strRYCAgencyQuery);

		 int insertPos = 0;


		 if(strRYCAgencyQuery != null)
			   {
			 pstmtRYCAgencyDelete.setLong(++insertPos, rycAgencySeqNo.longValue());
		      }



			if(seqno.longValue()!= 0)
			 {
				pstmtRYCAgencyDelete.setLong(++insertPos, seqno.longValue());
			  }



			  int deletedRows =  executeUpdate(pstmtRYCAgencyDelete);

		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCAgencyDelete != null)
				{
					pstmtRYCAgencyDelete.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */
			  ex.printStackTrace();
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}
//	Narendra CTS for RYC rule master details as part of to AGN-09 ends
	public void deleteRYCRuleDesgDetails(RYCRuleDesgDetails oRYCRuleDesgDetails,Long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCDesgnDelete = null;
		try
		{
		

		  Long rycDesgnSeqNo=oRYCRuleDesgDetails.getRYCDesgnSeqNbr();
	
		  String strRYCDesgnQuery = getSQLString("Delete",CHMConstants.RYCRULEDESGN_DELETE);

		 
			  
		  pstmtRYCDesgnDelete = getPreparedStatement(strRYCDesgnQuery);
	
		 int insertPos = 0;


		 if(strRYCDesgnQuery != null)
			   {
				 pstmtRYCDesgnDelete.setLong(++insertPos, rycDesgnSeqNo.longValue());			
		      }
					   
					   
					   
			if(seqno.longValue()!= 0)
			 {
				pstmtRYCDesgnDelete.setLong(++insertPos, seqno.longValue());
			  }
			  
			  
	        
			  int deletedRows =  executeUpdate(pstmtRYCDesgnDelete);
			 
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */	  	
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCDesgnDelete != null)
				{
					pstmtRYCDesgnDelete.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */	  	
			  ex.printStackTrace();		  	
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}
	

public void deleteRYCRuleSubDetails(String a_strQryNm,Long rycHdrSeqNbr) throws EElixirException
{
		PreparedStatement pstmtRYCDelete = null;
		try
		{
		

		  String strRYCQuery = getSQLString("Delete",a_strQryNm);

		  log.debug("strRYCQuery---->"+strRYCQuery);
			  
		  pstmtRYCDelete = getPreparedStatement(strRYCQuery);
	
		 int insertPos = 0;

			if(rycHdrSeqNbr.longValue()!= 0)
			 {
				pstmtRYCDelete.setLong(++insertPos, rycHdrSeqNbr.longValue());
			  }
			  
			
			  int deletedRows =  executeUpdate(pstmtRYCDelete);
			 
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */	  	
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCDelete != null)
				{
					pstmtRYCDelete.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */	  	
			  ex.printStackTrace();		  	
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}
	

	public void updateRYCRulePolicyDetails(RYCRulePolicyDetails oRYCRulePolicyDetails,Long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCPolicyUpdate = null;
	try
		{
			

		  Long strPolicyCd = oRYCRulePolicyDetails.getRYCPolicy();
		  log.debug("updateRYCRulePolicyDetails strPolicyCd:--->"+strPolicyCd);

		  Long rycPolicySeqNo=oRYCRulePolicyDetails.getRYCPolicySeqNbr();
		  log.debug("updateRYCRulePolicyDetails rycPolicySeqNo:--->"+rycPolicySeqNo);
		   String strRYCPolicyQuery = getSQLString("Update",CHMConstants.RYCRULEPOLICY_UPDATE);

		   log.debug("updateRYCRulePolicyDetails strRYCPolicyQuery:--->"+strRYCPolicyQuery);
			  
			  
			  pstmtRYCPolicyUpdate = getPreparedStatement(strRYCPolicyQuery);
			log.debug("updateRYCRulePolicyDetails pstmtRYCPolicyUpdate :--->"+pstmtRYCPolicyUpdate);
	
			  int insertPos = 0;
			log.debug("updateRYCRulePolicyDetails strPolicyCd set:--->"+strPolicyCd);
			  pstmtRYCPolicyUpdate.setLong(++insertPos, strPolicyCd.longValue());

			pstmtRYCPolicyUpdate.setString(++insertPos, a_strUserId);
				
			 
			  if(rycPolicySeqNo.longValue() != 0)
			  {
				log.debug("updateRYCRulePolicyDetails rycPolicySeqNo:Set--->"+rycPolicySeqNo);
				pstmtRYCPolicyUpdate.setLong(++insertPos, rycPolicySeqNo.longValue());			
			  }
				if(seqno.longValue()!= 0)
				 {
						   log.debug("updateRYCRulePolicyDetails seqno:--->"+seqno);
						   pstmtRYCPolicyUpdate.setLong(++insertPos, seqno.longValue());
				 }
			log.debug("updateRYCRulePolicyDetails pstmtRYCPolicyUpdate BEFORE UPDATE:--->"+pstmtRYCPolicyUpdate);
			  int updatedRows =  executeUpdate(pstmtRYCPolicyUpdate);
			log.debug("updateRYCRulePolicyDetails updatedRows:-->"+updatedRows);
			 
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */	  	
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCPolicyUpdate != null)
				{
					pstmtRYCPolicyUpdate.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */	  	
			  ex.printStackTrace();		  	
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}


	
	
	public void deleteRYCRulePolicyDetails(RYCRulePolicyDetails oRYCRulePolicyDetails,Long seqno,
			String a_strUserId) throws EElixirException
	{
		PreparedStatement pstmtRYCPolicyDelete = null;
		try
		{
		
		  Long rycPolicySeqNo=oRYCRulePolicyDetails.getRYCPolicySeqNbr();

		
		  String strRYCPolicyQuery = getSQLString("Delete",CHMConstants.RYCRULEPOLICY_DELETE);

		
			  
		  pstmtRYCPolicyDelete = getPreparedStatement(strRYCPolicyQuery);
	
		 int insertPos = 0;
		 
		 if(strRYCPolicyQuery != null)
			 {
				 pstmtRYCPolicyDelete.setLong(++insertPos, rycPolicySeqNo.longValue());			
			 }

			if(seqno.longValue()!= 0)
			 {
				pstmtRYCPolicyDelete.setLong(++insertPos, seqno.longValue());
			  }
			  
			  
	        
			  int deletedRows =  executeUpdate(pstmtRYCPolicyDelete);
			 
		}
		catch (SQLException sqlex)
		{
		  /**
		   * @todo remove later -- for debugging
		   */	  	
		  sqlex.printStackTrace();
			log.fatal("SQLException "+sqlex.getMessage());
			throw new EElixirException(sqlex, "P4540");
		}
		finally
		{
			try
			{
				if (pstmtRYCPolicyDelete != null)
				{
					pstmtRYCPolicyDelete.close();
				}
			}
			catch (SQLException ex)
			{
			  /**
			   * @todo remove later -- for debugging
			   */	  	
			  ex.printStackTrace();		  	
				log.fatal("SQLException "+ex.getMessage());
				throw new EElixirException(ex, "P8076");
			}
		}

	}
	


	protected long getNextRYCRuleSeqNbr() throws EElixirException
	{
    Statement stmtRYCRule = null;
    long lSeqNo;
    try
    {
      String strNextSeqQuery = getSQLString("Select",CHMConstants.RYCRULE_SEQ);

      stmtRYCRule = getStatement();
      ResultSet rsSeqNo = stmtRYCRule.executeQuery(strNextSeqQuery);
      rsSeqNo.next();
      lSeqNo = rsSeqNo.getLong(1);
      log.debug(lSeqNo + "");
      return lSeqNo;
    }
    catch(SQLException sqlex){
      sqlex.printStackTrace();
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
    }
    finally
    {
      try
      {
        if(stmtRYCRule != null)
          stmtRYCRule.close();
      }
      catch(SQLException sqlex){
        sqlex.printStackTrace();
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
      }
    }
  }


   protected long getNextRYCDesgnSeqNbr() throws EElixirException
   {
    Statement stmtNextSeq = null;
    long lSeqNo;
    try
    {
      String strNextSeqQuery = getSQLString("Select",CHMConstants.RYCRULEDESGN_SEQUENCE);

      stmtNextSeq = getStatement();
      ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
      rsSeqNo.next();
      lSeqNo = rsSeqNo.getLong(1);
      log.debug(lSeqNo + "");
      return lSeqNo;
    }
    catch(SQLException sqlex){
      sqlex.printStackTrace();
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
    }
    finally
    {
      try
      {
        if(stmtNextSeq != null)
          stmtNextSeq.close();
      }
      catch(SQLException sqlex){
        sqlex.printStackTrace();
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
      }
    }
  }
// Narendra CTS for RYC rule master details as part of to AGN-09 starts

   protected long getNextRYCAgencySeqNbr() throws EElixirException
   {
    Statement stmtNextSeq = null;
    long lSeqNo;
    try
    {
      String strNextSeqQuery = getSQLString("Select",CHMConstants.RYCRULEAGENCY_SEQUENCE);

      stmtNextSeq = getStatement();
      ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
      rsSeqNo.next();
      lSeqNo = rsSeqNo.getLong(1);
      log.debug(lSeqNo + "");
      return lSeqNo;
    }
    catch(SQLException sqlex){
      sqlex.printStackTrace();
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
    }
    finally
    {
      try
      {
        if(stmtNextSeq != null)
          stmtNextSeq.close();
      }
      catch(SQLException sqlex){
        sqlex.printStackTrace();
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
      }
    }
  }

// Narendra CTS for RYC rule master details as part of to AGN-09 ends

  protected long getNextRYCPolicySeqNbr() throws EElixirException
   {
    Statement stmtNextSeq = null;
    long lSeqNo;
    try
    {
      String strNextSeqQuery = getSQLString("Select",CHMConstants.RYCRULEPOLICY_SEQUENCE);

      stmtNextSeq = getStatement();
      ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
      rsSeqNo.next();
      lSeqNo = rsSeqNo.getLong(1);
      log.debug(lSeqNo + "");
      return lSeqNo;
    }
    catch(SQLException sqlex){
      sqlex.printStackTrace();
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
    }
    finally
    {
      try
      {
        if(stmtNextSeq != null)
          stmtNextSeq.close();
      }
      catch(SQLException sqlex){
        sqlex.printStackTrace();
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
      }
    }
  }





				
  private String getSQLString(String strSQLType,String strKey) throws EElixirException
   {
	SqlRepositoryIF _oSqlRepositoryIF = CHMSqlRepository.getSqlRepository();
	String strSql =_oSqlRepositoryIF.getSQLString(strKey,strSQLType);
	return strSql;
   }



  /* get FinderFees Map */


   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
	private Collection appColl;
	private ArrayList _oFinderFeesMapAList;
	private PreparedStatement _ChannelFinderFeesMappingPreparedStatement = null;

 }
