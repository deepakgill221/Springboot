/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMapDAX.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 2.1       10/9/2003     Dipti F		UT Rework
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.commission.util.ContractMapResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DAXIF;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;

  /**
   * <p>Title: eElixir</p>
   * <p>Description:The DAX implementaion for the ContractMap object </p>
   * <p>Copyright: Copyright (c) 2002</p>
   * <p>Company: Mastek Ltd</p>
   * @author Diptik
   * @version 1.0
   */

 public class ContractMapDAX extends DAX implements DAXIF
 {
   public CHMSqlRepository theCHMSqlRepository= null;

   /**
    * Constructor
    */

   public ContractMapDAX()
   {

   }

   /**
     * Inserts contractmapping details into database
     * @param request HttpServletRequest
     * @return Collection of ContractMappingDVO object
     * @throws EElixirException
    */
   public void insertContractMap(ContractMapResult a_oContractMapResult) throws EElixirException
   {
     PreparedStatement pstmtCreateContractMap = null;
     String strContractMapSeqQuery, strContractMapInitialStatusQuery;
     // added by amit 11/1/2002
     String strCreatedBy = a_oContractMapResult.getUserId();
     ResultSet rs;

     try
     {
       String strCreateContractMapQuery = getSQLString("Insert",CHMConstants.CONTRACT_MAPPING_INSERT);
       log.debug(strCreateContractMapQuery);
       pstmtCreateContractMap = getPreparedStatement(strCreateContractMapQuery);
       log.debug("Query Formed  " + strCreateContractMapQuery);

       log.debug("Channeltype:::" +  a_oContractMapResult.getChannelType().trim());
       pstmtCreateContractMap.setString(1,a_oContractMapResult.getChannelType().trim());

       log.debug("SEQ NBR:::" +  a_oContractMapResult.getContMapSeqNbr().longValue());
       pstmtCreateContractMap.setLong(2, a_oContractMapResult.getContMapSeqNbr().longValue());

       log.debug("AGENT CODE:::" +  a_oContractMapResult.getAgentCd().trim());
       if(a_oContractMapResult.getAgentCd() != null && !a_oContractMapResult.getAgentCd().trim().equals(""))
       {
         pstmtCreateContractMap.setString(3, a_oContractMapResult.getAgentCd().trim().toUpperCase());
       }
       else
       {
         pstmtCreateContractMap.setNull(3, java.sql.Types.VARCHAR);
       }

   //    log.debug("CONTRACT TYPE:::" +  a_oContractMapResult.getContractType().shortValue());
   //    pstmtCreateContractMap.setShort(4, a_oContractMapResult.getContractType().shortValue());

       log.debug("DT EFF FROM:::" + DateUtil.retStrDate(a_oContractMapResult.getEffFrom()));
       pstmtCreateContractMap.setTimestamp(4, DateUtil.retTimestamp(a_oContractMapResult.getEffFrom()));

       log.debug("CONTRACT NBR:::" + a_oContractMapResult.getContractNbr().trim());
       pstmtCreateContractMap.setString(5, a_oContractMapResult.getContractNbr().trim());


       if(a_oContractMapResult.getEffTo() == null)
       {
       //  pstmtCreateContractMap.setString(7, DataConstants.MAX_DATE_LIMIT);
         log.debug("DT TO WHEN DT TO IS NULL:::" + DataConstants.MAX_DATE_LIMIT);
         log.debug("DT TO WHEN DT TO IS NULL:::" + DateUtil.retTimestamp(DateUtil.retGCDate(DataConstants.MAX_DATE_LIMIT)));
         pstmtCreateContractMap.setTimestamp(6, DateUtil.retTimestamp(DateUtil.retGCDate(DataConstants.MAX_DATE_LIMIT)));
       }
       else
       {
         log.debug("DT TO WHEN DT TO IS NOT NULL:::" + DateUtil.retTimestamp(a_oContractMapResult.getEffTo()));
         pstmtCreateContractMap.setTimestamp(6, DateUtil.retTimestamp(a_oContractMapResult.getEffTo()));
       }

       log.debug("STATUS PENDING ID:::" + DataConstants.STATUS_PENDING_ID);
       pstmtCreateContractMap.setInt(7, DataConstants.STATUS_PENDING_ID);
       // added by Amit 11/1/2002

       log.debug("USER ID:::" + a_oContractMapResult.getUserId());
       pstmtCreateContractMap.setString(8,a_oContractMapResult.getUserId());
       pstmtCreateContractMap.setString(9,a_oContractMapResult.getUserId());

	   pstmtCreateContractMap.setTimestamp(10,
					 DateUtil.retTimestamp(a_oContractMapResult.getDtUpdated()));
	   log.debug("*************Value of date Updated in CHM_CONTRACT_MAP is " + a_oContractMapResult.getDtUpdated());
       pstmtCreateContractMap.setLong(11,a_oContractMapResult.getUniqueMapSeqNbr().longValue());
       log.debug("before execute" + pstmtCreateContractMap.toString());
       executeUpdate(pstmtCreateContractMap);

     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3029");
     }

     finally
     {
       try
       {
         if(pstmtCreateContractMap != null)
           pstmtCreateContractMap.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, "P3029");
       }
     }

   }


   public long getNextContractMapSeqNbr() throws EElixirException
   {
     try
     {
       String strContractMapSeqQuery = getSQLString("Select",CHMConstants.CONTRACT_MAPPING_SEQ);
       ResultSet   rs = executeQuery(strContractMapSeqQuery);
       rs.next();
       return rs.getLong(1);
     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex,"P3043");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw new EElixirException(eex,"P3043");
     }

    }

   public void checkForActiveAgent(String a_StrAgentCd, String a_CChannelType) throws EElixirException
   {
     ResultSet rs;
     String  strActiveAgentQuery = getSQLString("Select",CHMConstants.CONTRACT_MAP_AGENT_SEARCH);
      log.debug("strActiveAgentQuery");

      PreparedStatement pstmtContractMapAgentQuery = getPreparedStatement(strActiveAgentQuery);
      log.debug("after getting prepared stmt");
      try
      {
        pstmtContractMapAgentQuery.setString(1, a_StrAgentCd);
        pstmtContractMapAgentQuery.setString(2, a_StrAgentCd);
        pstmtContractMapAgentQuery.setString(3, a_CChannelType);
        pstmtContractMapAgentQuery.setInt(4, DataConstants.AGENCY_AGENT_STATUS);
        pstmtContractMapAgentQuery.setInt(5, DataConstants.ACTIVE_AGENT_AGENCY_STATUS);
        rs = executeQuery(pstmtContractMapAgentQuery);
        if(rs.next())
        {
          log.debug("Active agent found");
        }
        else
        {
          log.debug("Agent not found");
          throw new EElixirException("P3035");
        }
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex,"P3044");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P3044");
      }
   }

   public void insertTransStatus(long _iLContMapSeqNbr, String strUser,GregorianCalendar date) throws EElixirException
   {
     log.debug("ContractMapDax: in inserttransstatus: seqnbr" + _iLContMapSeqNbr + " userid " + strUser);
     PreparedStatement pstmtApprovalInsert = null;

     try
     {
        String strInsertApplication = getSQLString("Insert",CHMConstants.TRANSACTION_STATUS_INSERT_MAP);
        log.debug("ContractMapDAX: The Trans status query " + strInsertApplication);

        pstmtApprovalInsert = getPreparedStatement(strInsertApplication);

        pstmtApprovalInsert.setInt(1,DataConstants.TRANSACTIONS_CONTRACT_MAP);
        log.debug("ContractMapDAX: set 1st param  " + DataConstants.TRANSACTIONS_CONTRACT_MAP);

        pstmtApprovalInsert.setLong(2, _iLContMapSeqNbr);
        log.debug("ContractMapDAX: set 2nd param  " + _iLContMapSeqNbr);

        pstmtApprovalInsert.setInt(3,DataConstants.STATUS_PENDING_ID);
        log.debug("ContractMapDAX: set 3rd param  " + DataConstants.STATUS_PENDING_ID);

//        pstmtApprovalInsert.setTimestamp(4,DateUtil.retTimestamp(DateUtil.retGCDate(DateUtil.getSystemDate())));
        log.debug("ContractMapDAX: set 4th param  " + DataConstants.STATUS_PENDING_ID);

        pstmtApprovalInsert.setString(4,""); //to be clarified
        log.debug("ContractMapDAX: set 5th param  " );

        pstmtApprovalInsert.setString(5, strUser); //to be clarified
        log.debug("ContractMapDAX: set 6th param  "+strUser );
		pstmtApprovalInsert.setTimestamp(6,DateUtil.retTimestamp(date));
		log.debug("************* Value of dtUpdated in chm_trans_status_h is " + DateUtil.retTimestamp(date));

        log.debug("brfore execute inserttransstatus");
        int iInsertApplication = executeUpdate(pstmtApprovalInsert);
       log.debug("ContractMapDAX: Trans status Insert over");
   }
       catch(SQLException sqlex)	
       {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, "P1010");
      }
      catch(EElixirException eex)
      {
         log.exception(eex.getMessage());
        throw new EElixirException(eex,"P1010");
      }
   }


   public void checkForDuplicateContractMap(String a_strChannelType,  String a_strAgentCode,  String a_strContractNbr) throws EElixirException
   {
     PreparedStatement pstmtCheckDuplicateContractMap = null;
     ResultSet rs ;
     try
     {
       log.debug("before getsqlstring");

       String strCheckDuplicateContractMapQuery = getSQLString("Select",CHMConstants.CONTRACT_MAP_DUPLICATE_CHECK);

       log.debug(strCheckDuplicateContractMapQuery);

       pstmtCheckDuplicateContractMap = getPreparedStatement(strCheckDuplicateContractMapQuery);
       log.debug("Query Formed  " + pstmtCheckDuplicateContractMap);
       log.debug("a_strChannelType  " + a_strChannelType);
       log.debug("a_strAgentCode " + a_strAgentCode);
       log.debug("a_strContractNbr " + a_strContractNbr);

       pstmtCheckDuplicateContractMap.setString(1,a_strChannelType);
       pstmtCheckDuplicateContractMap.setString(2,a_strAgentCode);
       pstmtCheckDuplicateContractMap.setString(3,a_strContractNbr);
       pstmtCheckDuplicateContractMap.setInt(4,DataConstants.STATUS_APPROVED_ID);
       rs = executeQuery(pstmtCheckDuplicateContractMap);
       if(rs.next())
       {
         throw new EElixirException("P3037");
       }

     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3037");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw new EElixirException(eex,"P3037");
     }
     finally
     {
       try
       {
         if(pstmtCheckDuplicateContractMap != null)
           pstmtCheckDuplicateContractMap.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, "P3037");
       }
     }

   }


   public void checkForDuplicateContractMap(String a_strChannelType,  String a_strContractNbr) throws EElixirException
   {
     PreparedStatement pstmtCheckDuplicateContractMap = null;
     ResultSet rs ;
     try
     {
       log.debug("before getsqlstring");

       String strCheckDuplicateContractMapQuery = getSQLString("Select",CHMConstants.CONTRACT_MAP_DUPLICATE_CHECK_FOR_CHANNEL);

       log.debug(strCheckDuplicateContractMapQuery);

       pstmtCheckDuplicateContractMap = getPreparedStatement(strCheckDuplicateContractMapQuery);
       log.debug("Query Formed  " + pstmtCheckDuplicateContractMap);
       log.debug("a_strChannelType  " + a_strChannelType);
       log.debug("a_strContractNbr " + a_strContractNbr);

       pstmtCheckDuplicateContractMap.setString(1,a_strChannelType);
       pstmtCheckDuplicateContractMap.setString(2,a_strContractNbr);
       pstmtCheckDuplicateContractMap.setInt(3,DataConstants.STATUS_APPROVED_ID);
       rs = executeQuery(pstmtCheckDuplicateContractMap);
       if(rs.next())
       {
         throw new EElixirException("P3048");
       }

     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3048");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw new EElixirException(eex,"P3048");
     }
     finally
     {
       try
       {
         if(pstmtCheckDuplicateContractMap != null)
           pstmtCheckDuplicateContractMap.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, "P3048");
       }
     }

   }



   public void updateContractMap(ContractMapResult a_oContractMapResult) throws EElixirException
   {
     PreparedStatement pstmtUpdateContractMap = null;
     try
           {
             log.debug("before getsqlstring");

             String strUpdateContractMapQuery = getSQLString("Update",CHMConstants.CONTRACT_MAPPING_UPDATE);

             log.debug(strUpdateContractMapQuery);

             pstmtUpdateContractMap = getPreparedStatement(strUpdateContractMapQuery);
             log.debug("Query Formed  " + pstmtUpdateContractMap);
          //   log.debug("strContractType  " + a_oContractMapResult.getContractType());
             log.debug("dtEffFrom " + a_oContractMapResult.getEffFrom());
             log.debug("dtEffTo " + a_oContractMapResult.getEffTo());
             log.debug("pKey " + a_oContractMapResult.getContMapSeqNbr());

           //  pstmtUpdateContractMap.setShort(1, a_oContractMapResult.getContractType().shortValue());
             log.debug(DateUtil.retTimestamp(a_oContractMapResult.getEffFrom()) + "in DAX from date");
             pstmtUpdateContractMap.setTimestamp(1,DateUtil.retTimestamp(a_oContractMapResult.getEffFrom()));
             pstmtUpdateContractMap.setTimestamp(2,DateUtil.retTimestamp(a_oContractMapResult.getEffTo()));
             // added by Amit 11/1/2002
             pstmtUpdateContractMap.setString(3,a_oContractMapResult.getUserId());
             pstmtUpdateContractMap.setLong(4, a_oContractMapResult.getContMapSeqNbr().longValue());
             executeUpdate(pstmtUpdateContractMap);
           }
           catch(SQLException sqlex){
             log.exception(sqlex.getMessage());
             throw new EElixirException(sqlex, "P3030");
           }
           catch(EElixirException eex)
           {
             log.exception(eex.getMessage());
             throw new EElixirException(eex,"P3030");
           }
           finally
           {
             try
             {
               if(pstmtUpdateContractMap != null)
                 pstmtUpdateContractMap.close();
             }
             catch(SQLException sqlex)
             {
               log.exception(sqlex.getMessage());
               throw new EElixirException(sqlex, "P3030");
             }
           }

         }

//Delete functionality has been removed, so this is commented//
/*
         private void deleteContractMap(ContractMap a_oContractMap) throws EElixirException
         {
           PreparedStatement pstmtDeleteContractMap = null;
           try
           {
             if(! ( (_oContractMap.get_iNStatus()).intValue() == DataConstants.STATUS_APPROVED_ID))
             {
               log.debug("before getsqlstring");
               String strDeleteContractMapQuery = getSQLString("Delete",CHMConstants.CONTRACT_MAPPING_DELETE);
               log.debug(strDeleteContractMapQuery);
               pstmtDeleteContractMap = getPreparedStatement(strDeleteContractMapQuery);
               log.debug("Query Formed  " + pstmtDeleteContractMap);
               log.debug("pKey " + _oContractMap.get_strPKey());
               pstmtDeleteContractMap.setLong(1,Long.parseLong(_oContractMap.get_strPKey()));
               executeUpdate(pstmtDeleteContractMap);
             }
           }
           catch(SQLException sqlex)
           {
             log.exception(sqlex.getMessage());
             throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
           }
           catch(EElixirException eex)
           {
             log.exception(eex.getMessage());
             throw new EElixirException(eex,"P3031");
           }
           finally
           {
             try
             {
               if(pstmtDeleteContractMap != null)
                 pstmtDeleteContractMap.close();
             }
             catch(SQLException sqlex)
             {
               log.exception(sqlex.getMessage());
               throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
             }
           }

         }


    */

   /**
    * Gets the SQL string from the document Object
    * @param strSQLType
    * @param strKey
    * @return strSql
    * @throws EElixirException
    */

   private String getSQLString(String strSQLType,String strKey) throws EElixirException
   {
    SqlRepositoryIF _oSqlRepositoryIF = CHMSqlRepository.getSqlRepository();
    String strSql =_oSqlRepositoryIF.getSQLString(strKey,strSQLType);
    return strSql;
   }

   public  void populateDVOs()
   {

   }

   protected  Object getEntityDVO()
   {
     return null;
   }

   protected  Collection getEntityDVOCollection()
   { return null;
   }


     /**
    * searchContractMap
    * @return boolean
    * @param a_LContMapSeqNbr long
    * @throws EElixirException
    */
   public boolean searchContractMap(long a_LContMapSeqNbr) throws EElixirException
   {
     ResultSet rsSearchContMap = null;
     PreparedStatement _pstmtFindPrimaryKey = null;
     try
     {
       String strSelectContMapQuery = getSQLString("Select",CHMConstants.CONTRACT_MAPPING_SEARCH_SQL);

       if(_pstmtFindPrimaryKey == null)
       {
         _pstmtFindPrimaryKey = getPreparedStatement(strSelectContMapQuery);
       }
       log.debug("In Dax: " + a_LContMapSeqNbr);
       _pstmtFindPrimaryKey.setLong(1, a_LContMapSeqNbr);


       rsSearchContMap = executeQuery(_pstmtFindPrimaryKey);
       if(rsSearchContMap.next())
       {
         return true;
       }
       else
       {
         return false;
       }
     }
     catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, "P3033");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3033");
    }
    finally
    {
      try
      {
        if(_pstmtFindPrimaryKey != null)
          _pstmtFindPrimaryKey.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, "P3033");
      }
    }

 }


 /**
  * getAgentDetails
  * @return AgentResult
  * @param: a_strAgentCd String
  * @throws EElixirException
  */
 public ArrayList getContractMapList(long a_LContMapSeqNbr) throws EElixirException
 {
   log.debug("in getContractMap of AdjustmentDax");
   ResultSet rsSearchContractMap = null;
   ContractMapResult _oContractMapResult = null;
   PreparedStatement _pstmtSearchContractMap = null;
   ArrayList alContractMapResult = new ArrayList();
   try
   {
     String strSelectContractMapQuery = getSQLString("Select",CHMConstants.CONTRACTMAPSEARCH);
     log.debug("The ContractMap search query is " + strSelectContractMapQuery);

     if(_pstmtSearchContractMap == null)
     {
       _pstmtSearchContractMap = getPreparedStatement(strSelectContractMapQuery);
     }

     _pstmtSearchContractMap.setLong(1, a_LContMapSeqNbr);
     _pstmtSearchContractMap.setInt(2, DataConstants.COMMON_STATUS);

     log.debug("The ContractMap seqnbr passed is  " + a_LContMapSeqNbr);
     rsSearchContractMap = executeQuery(_pstmtSearchContractMap);
     log.debug("query executed properly");
     while(rsSearchContractMap.next())
     {
       _oContractMapResult = new ContractMapResult();
       _oContractMapResult.setChannelType(rsSearchContractMap.getString(1));
       _oContractMapResult.setContMapSeqNbr(new Long(rsSearchContractMap.getLong(2)));
       _oContractMapResult.setAgentCd(rsSearchContractMap.getString(3));
       if(rsSearchContractMap.wasNull())
       {
         _oContractMapResult.setAgentCd(null);
       }
   //    _oContractMapResult.setContractType(new Short( rsSearchContractMap.getShort(4)));
   //    if(rsSearchContractMap.wasNull())
   //    {
   //      _oContractMapResult.setContractType(null);
   //    }
       _oContractMapResult.setEffFrom(DateUtil.retGregorian(rsSearchContractMap.getTimestamp(4)));
       _oContractMapResult.setContractNbr(rsSearchContractMap.getString(5));
       _oContractMapResult.setEffTo(DateUtil.retGregorian(rsSearchContractMap.getTimestamp(6)));
       if(rsSearchContractMap.wasNull())
       {
         _oContractMapResult.setEffTo(null);
       }
       _oContractMapResult.setStatus(new Short(rsSearchContractMap.getShort(7)));
       _oContractMapResult.setStatusDesc(rsSearchContractMap.getString(8));
       _oContractMapResult.setUserId(rsSearchContractMap.getString(9));
       _oContractMapResult.setAgentName(rsSearchContractMap.getString(10));
       _oContractMapResult.setUniqueMapSeqNbr(new Long(rsSearchContractMap.getLong("LUNIQUEMAPSEQNBR")));
       _oContractMapResult.setContractDtEffFrom(DateUtil.retGregorian(rsSearchContractMap.getTimestamp("HDRDTEFFFROM")));
       _oContractMapResult.setStatusFlag(DataConstants.DISPLAY_MODE);
       _oContractMapResult.setTsDtUpdated(rsSearchContractMap.getTimestamp("dtupdated"));
       //_oContractMapResult.setSubChannelType(rsSearchContractMap.getString("STRSUBCHANNELTYPE"));
       alContractMapResult.add(_oContractMapResult);
       log.debug("ContractMapDax : added ContractMapResult "+_oContractMapResult);
     }
     log.debug("returning arraylist size "+ alContractMapResult.size());
     return alContractMapResult;

   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     throw new EElixirException(sqlex, "P3034");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P3034");
   }
   finally
   {
     try
     {
       if(_pstmtSearchContractMap != null)
         _pstmtSearchContractMap.close();
     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3034");
     }
   }

 }


 /**
  * getAgentDetails
  * @return AgentResult
  * @param: a_strAgentCd String
  * @throws EElixirException
  */
 public ContractMapResult getContractMap(long a_LContMapSeqNbr) throws EElixirException
 {
   log.debug("in getContractMap of Contract map DAX");
   ResultSet rsSearchContractMap = null;
   ContractMapResult _oContractMapResult = null;
   PreparedStatement _pstmtSearchContractMap = null;
   try
   {
     String strSelectContractMapQuery = getSQLString("Select",CHMConstants.CONTRACT_MAP_SEARCH_BY_PRIMARY_KEY);
     log.debug("The ContractMap search query is " + strSelectContractMapQuery);

     if(_pstmtSearchContractMap == null)
     {
       _pstmtSearchContractMap = getPreparedStatement(strSelectContractMapQuery);
     }

     _pstmtSearchContractMap.setLong(1, a_LContMapSeqNbr);
     _pstmtSearchContractMap.setInt(2, DataConstants.COMMON_STATUS);

     log.debug("The ContractMap seqnbr passed is  " + a_LContMapSeqNbr);
     rsSearchContractMap = executeQuery(_pstmtSearchContractMap);
     log.debug("query executed properly");
     if(rsSearchContractMap.next())
     {
       _oContractMapResult = new ContractMapResult();
       _oContractMapResult.setChannelType(rsSearchContractMap.getString(1));
       _oContractMapResult.setContMapSeqNbr(new Long(rsSearchContractMap.getLong(2)));
       _oContractMapResult.setAgentCd(rsSearchContractMap.getString(3));
       if(rsSearchContractMap.wasNull())
       {
         _oContractMapResult.setAgentCd(null);
       }
   //    _oContractMapResult.setContractType(new Short( rsSearchContractMap.getShort(4)));
   //    if(rsSearchContractMap.wasNull())
   //    {
   //      _oContractMapResult.setContractType(null);
   //    }
       _oContractMapResult.setEffFrom(DateUtil.retGregorian(rsSearchContractMap.getTimestamp(4)));
       _oContractMapResult.setContractNbr(rsSearchContractMap.getString(5));
       _oContractMapResult.setEffTo(DateUtil.retGregorian(rsSearchContractMap.getTimestamp(6)));
       if(rsSearchContractMap.wasNull())
       {
         _oContractMapResult.setEffTo(null);
       }
       _oContractMapResult.setStatus(new Short(rsSearchContractMap.getShort(7)));
       _oContractMapResult.setStatusDesc(rsSearchContractMap.getString(8));
       _oContractMapResult.setUserId(rsSearchContractMap.getString(9));
       _oContractMapResult.setAgentName(rsSearchContractMap.getString(10));
       _oContractMapResult.setUniqueMapSeqNbr(new Long(rsSearchContractMap.getLong("LUNIQUEMAPSEQNBR")));
       _oContractMapResult.setTsDtUpdated(rsSearchContractMap.getTimestamp("dtupdated"));
       _oContractMapResult.setStatusFlag(DataConstants.DISPLAY_MODE);


       log.debug("ContractMapDax : added ContractMapResult "+_oContractMapResult);
     }
     log.debug("returning contract map result obj"+ _oContractMapResult);
     return _oContractMapResult;

   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     throw new EElixirException(sqlex, "P3034");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P3034");
   }
   finally
   {
     try
     {
       if(_pstmtSearchContractMap != null)
         _pstmtSearchContractMap.close();
     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3034");
     }
   }

 }


 public void validateContractEffectiveDate(String strContractNbr, GregorianCalendar _dtEffFrom) throws EElixirException
 {
   PreparedStatement pstmtSearchContract= null;
   Statement st = null ;
   StringBuffer sb = new StringBuffer();
   GregorianCalendar _contractDt = null;


   try
   {


    log.debug("before getsqlstring");
     String strSearchContractQuery = getSQLString("Select",CHMConstants.CONTRACT_EFFECTIVE_DATE_CHECK);

     log.debug(strSearchContractQuery);
     pstmtSearchContract = getPreparedStatement(strSearchContractQuery);
     pstmtSearchContract.setInt(1,DataConstants.STATUS_APPROVED_ID);
     pstmtSearchContract.setInt(2, DataConstants.COMMON_STATUS);
     pstmtSearchContract.setString(3, strContractNbr.trim().toUpperCase());
      ResultSet rsSearch = executeQuery(pstmtSearchContract);
      if(rsSearch.next())
      {
        _contractDt = DateUtil.retGregorian(rsSearch.getTimestamp(2));
        if(_dtEffFrom.before( _contractDt))
        {
          throw new EElixirException("P3045");
        }
      }


   }

    catch(SQLException sqlex)
   {
    log.exception(sqlex.getMessage());
    throw new EElixirException("P3045");
   }
   finally
   {
   try
     {
       if(pstmtSearchContract != null)
          pstmtSearchContract.close();
     }
   catch(SQLException sqlex)
    {
     log.exception(sqlex.getMessage());
     throw new EElixirException("P3045");
    }
   }

 }


 /**
    * Searches for contract mapping on given parameters.
    * @param request HttpServletRequest
    * @return String
    * @throws EElixirException
    */

  public String getContractMap(SearchData oSearchData) throws EElixirException
  {
    PreparedStatement pstmtSearchContractMapping = null;
    Statement st = null ;
    StringBuffer sb = new StringBuffer();
    HashMap hmQueryMap = new HashMap();
    String strLikePrefix = "%";

    try
    {
      String strChannelType	= oSearchData.getTask1(); // Channel Type
    //FSD_AGN-97_Commission Mapping search changes ADDED BY SUNAINA
      String strProductCd = oSearchData.getTask10(); // Product Code
    //FSD_AGN-97_Commission Mapping search changes Ended BY SUNAINA
      String strAgentCode		= oSearchData.getTask2(); // Agent Code
      String strAgentName     = oSearchData.getTask3(); // Agent Name
      GregorianCalendar _dtEffdt 	= oSearchData.getTaskDate1(); // Effective Date
      String strMappingStatus = oSearchData.getTask4(); // Mapping Status
  //    String strSubChannelType = oSearchData.getTask5();

      String strSearchContractMappingQuery = getSQLString("Select",CHMConstants.CONTRACT_MAPPING);

      log.debug(strSearchContractMappingQuery);
      hmQueryMap.put("Main",strSearchContractMappingQuery);

      //check database column names here
    //  strSearchContractMappingQuery = " AND UPPER(m.STRSUBCHANNELTYPE) =  UPPER(?) " ;
    //  hmQueryMap.put("SubChannelType",strSearchContractMappingQuery);

      strSearchContractMappingQuery = " AND m.CCHANNELTYPE =  UPPER(?) " ;
      hmQueryMap.put("ChannelType",strSearchContractMappingQuery);

      //FSD_AGN-97_Commission Mapping search changes ADDED BY SUNAINA
      log.debug("before put Productcode");
      strSearchContractMappingQuery = " AND g.STRPRODCD LIKE UPPER(?) " ;
      hmQueryMap.put("ProductCode",strSearchContractMappingQuery);
      //FSD_AGN-97_Commission Mapping search changes Ended BY SUNAINA

      log.debug("before put agentcode");
      strSearchContractMappingQuery = " AND m.STRAGENTCD LIKE UPPER(?) " ;
      hmQueryMap.put("AgentCode",strSearchContractMappingQuery);

      strSearchContractMappingQuery = " AND UPPER(trim(a.STRLASTNAME||' '||a.STRFIRSTNAME)) LIKE UPPER(?) " ;
      hmQueryMap.put("AgentName",strSearchContractMappingQuery);

      strSearchContractMappingQuery = " AND m.DTEFFFROM =  ? " ;
      hmQueryMap.put("EffDate",strSearchContractMappingQuery);

      strSearchContractMappingQuery = " AND m.NSTATUS =  ? " ;
      hmQueryMap.put("MappingStatus",strSearchContractMappingQuery);

      String strQuery = (String)hmQueryMap.get("Main");
/*
      if (strSubChannelType != null && !strSubChannelType.trim().equals(""))
      {
         strQuery += (String)hmQueryMap.get("SubChannelType");
      }
*/
      if (strChannelType != null && !strChannelType.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("ChannelType");
      }
      //FSD_AGN-97_Commission Mapping search changes ADDED BY SUNAINA
      log.debug("before get productcode" + strProductCd);
      if (strProductCd != null && !strProductCd.equals("")) {
        strQuery += (String)hmQueryMap.get("ProductCode");
      }
      //FSD_AGN-97_Commission Mapping search changes Ended BY SUNAINA
      log.debug("before get agentcode" + strAgentCode);
      if (strAgentCode != null && !strAgentCode.equals("")) {
        strQuery += (String)hmQueryMap.get("AgentCode");
      }
      log.debug("before get agentname" + strAgentName);
      if (strAgentName!= null && !strAgentName.equals("")) {
        strQuery += (String)hmQueryMap.get("AgentName");
      }
      log.debug("before get agentdate" + _dtEffdt);
      if (_dtEffdt!= null && !_dtEffdt.toString().equals("")) {
        strQuery += (String)hmQueryMap.get("EffDate");
      }
      log.debug("before get agentmapstatus" + strMappingStatus);
      if (strMappingStatus!= null && !strMappingStatus.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("MappingStatus");
      }
      log.debug("before get afull query");
      pstmtSearchContractMapping = getPreparedStatement(strQuery);
      log.debug("Query Formed  " + strQuery);

      pstmtSearchContractMapping.setInt(1, DataConstants.COMMON_STATUS);

      int iPosition = 1 ;

    /*if (strSubChannelType != null && !strSubChannelType.trim().equals(""))
      {
        log.debug("Adding strSubChannelType Code " );
        pstmtSearchContractMapping.setString(++iPosition,strSubChannelType.trim());
      }*/

      if (strChannelType!= null && !strChannelType.trim().equals("")) {
        log.debug("\nAdding strChannelType Code " );
        pstmtSearchContractMapping.setString(++iPosition,strChannelType.trim());
      }

    //FSD_AGN-97_Commission Mapping search changes ADDED BY SUNAINA
      if (strProductCd!= null && !strProductCd.equals("")) {
          //String prefix = "%";
         // strProductCd = prefix.concat(strProductCd.trim());
         // strProductCd = strProductCd.concat(prefix);
         // pstmtSearchContractMapping.setString(++iPosition,(strLikePrefix.concat(strProductCd.trim())).concat(strLikePrefix) );
          pstmtSearchContractMapping.setString(++iPosition,strProductCd.trim());
        }
    //FSD_AGN-97_Commission Mapping search changes Ended BY SUNAINA

      if (strAgentCode!= null && !strAgentCode.equals("")) {
        log.debug("\nAdding strAgentCode Code " );
        String prefix = "%";
        strAgentCode = prefix.concat(strAgentCode.trim());
        strAgentCode = strAgentCode.concat(prefix);
        pstmtSearchContractMapping.setString(++iPosition, (strLikePrefix.concat(strAgentCode.trim())).concat(strLikePrefix) );
      }

      if (strAgentName!= null && !strAgentName.equals("")) {
        log.debug("\nAdding agent name" );
         pstmtSearchContractMapping.setString(++iPosition, (strLikePrefix.concat(strAgentName.trim())).concat(strLikePrefix) );
      }

      if (_dtEffdt!= null && !_dtEffdt.toString().equals("")) {
        log.debug("\nAdding eff date Code " );
        pstmtSearchContractMapping.setTimestamp(++iPosition,DateUtil.retTimestamp(_dtEffdt));
      }

      if (strMappingStatus!= null && !strMappingStatus.trim().equals("")) {
        log.debug("\nAdding strMappingStatus Code " );
        pstmtSearchContractMapping.setShort(++iPosition, Short.parseShort(strMappingStatus.trim()));
      }

      log.debug("before execute" + pstmtSearchContractMapping.toString());
      ResultSet rsSearch = executeQuery(pstmtSearchContractMapping);
      log.debug("before returnin");
      return XMLConverter.getXMLString(rsSearch);
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, "P3034");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3034");
    }
    finally
    {
      try
      {
        if(pstmtSearchContractMapping != null)
          pstmtSearchContractMapping.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, "P3034");
      }
    }
  }

  /**
   * validateForProductOverlap finds whether the agent has product overlap across multiple mapped contracts
   * @return void
   * @param String PersistencyResult
   * @throws EElixirException
   */
  public void validateForProductOverlap(ContractMapResult oContractMapResult)
          throws EElixirException
  {
      log.debug("ContractMapDAX----validateForProductOverlap()");
      ResultSet rsDuplicate = null;
      PreparedStatement _pstmtFindPrimaryKey = null;
      int _iESLRRecords = 0;
      try
      {
          log.debug("ContractMapDAX----validateForProductOverlap()--in try");
          String strSelectTargetRecords = getSQLString("Select",CHMConstants.CONTRACT_MAP_PRODUCT_OVERLAP_CHECK);
          log.debug("ContractMapDAX----validateForProductOverlap()--strSelectTargetRecords" + strSelectTargetRecords);
          if(oContractMapResult.getAgentCd() == null || oContractMapResult.getAgentCd().trim().equals(""))
          {
              strSelectTargetRecords = strSelectTargetRecords + " and a.CChannelType = ?  and a.strAgentCd is null )";
          }
          else
          {
              strSelectTargetRecords = strSelectTargetRecords + " and a.strAgentCd = ? )";
          }
          log.debug("ContractMapDAX----validateForProductOverlap()--strSelectTargetRecords after appending to query" + strSelectTargetRecords);

          if(_pstmtFindPrimaryKey == null)
          {
              log.debug("ContractMapDAX----validateForProductOverlap()--_pstmtFindPrimaryKey" + _pstmtFindPrimaryKey);
              _pstmtFindPrimaryKey = getPreparedStatement(strSelectTargetRecords);
              log.debug("ContractMapDAX----validateForProductOverlap()--_pstmtFindPrimaryKey" + _pstmtFindPrimaryKey);
          }
          _pstmtFindPrimaryKey.setString(1, oContractMapResult.getContractNbr());
          _pstmtFindPrimaryKey.setTimestamp(2, DateUtil.retTimestamp(oContractMapResult.getEffFrom()));

			 _pstmtFindPrimaryKey.setInt(3, DataConstants.STATUS_PENDING_ID);
		   _pstmtFindPrimaryKey.setInt(4, DataConstants.STATUS_APPROVED_ID);

          if(oContractMapResult.getAgentCd() == null || oContractMapResult.getAgentCd().trim().equals(""))
          {
              log.debug("ContractMapDAX----validateForProductOverlap()--adding channel type");
              _pstmtFindPrimaryKey.setString(5, oContractMapResult.getChannelType());
          }
          else
          {
              log.debug("ContractMapDAX----validateForProductOverlap()--adding agent code");
              _pstmtFindPrimaryKey.setString(5, oContractMapResult.getAgentCd());
          }

          log.debug("ContractMapDAX----validateForProductOverlap()--before firing query");

          rsDuplicate = executeQuery(_pstmtFindPrimaryKey);
          if(rsDuplicate.next())
          {
              log.debug("ContractMapDAX----validateForProductOverlap()--if rs.next");
              _iESLRRecords = rsDuplicate.getInt(1);

              log.debug("ContractMapDAX----validateForProductOverlap()--_iESLRRecords" + _iESLRRecords);
          }
          if(_iESLRRecords > 0)
          {
              throw new EElixirException("P3101");
          }
      }
      catch(SQLException sqlex){
          log.debug("ContractMapDAX-------validateForProductOverlap()----- DAX--- SQLEx");
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, "P3101");
      }
      catch(EElixirException eex)
      {
          log.debug("ContractMapDAX-------validateForProductOverlap()----- DAX--- EEEx");
          log.exception(eex.getMessage());
          throw new EElixirException(eex,"P3101");
      }
      finally
      {
          try
          {

              if(_pstmtFindPrimaryKey != null)
                  _pstmtFindPrimaryKey.close();

          }
          catch(SQLException sqlex)
          {
              log.exception(sqlex.getMessage());
              throw new EElixirException(sqlex, "P3101");
          }
      }
  }


  /* get Contract Map */


   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
    private Collection appColl;
    private ArrayList _oContractMapAList;
    private PreparedStatement _ChannelContractMappingPreparedStatement = null;

 }
