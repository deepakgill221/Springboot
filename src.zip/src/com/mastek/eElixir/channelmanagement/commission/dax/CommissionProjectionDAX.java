/********************************************************************
 *
 *  PROJECT                : PRUDENTIAL
 *  MODULE NAME                : CHANNEL MANAGEMENT
 *  FILENAME                : CommissionProjectionDAX.java
 *  AUTHOR                : Pallav
 *  VERSION                : 1.0
 *  CREATION DATE        : Jan 20,2003
 *  COMPANY                : Mastek Ltd.
 *  COPYRIGHT                : COPYRIGHT (C) 2002.
 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION DATE          BY        REASON
 *--------------------------------------------------------------------------------
 * 2.1     17/09/2003    Dipti F   UT Rework
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

// PACKAGE DEFNETION
package com.mastek.eElixir.channelmanagement.commission.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.commission.util.CommissionProjectionResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;


public class CommissionProjectionDAX extends DAX
{
    //  Member variables
    private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor
     */
    public CommissionProjectionDAX()
    {
    }

    /**
     * Description getSQLString takes querytype and key and returns query
     * @return query string
     * @param a_strSQLType SQL Type i.e Select
     * @param a_strKey String
     * @throws EElixirException
     */
    private String getSQLString(String a_strSQLType, String a_strKey)
        throws EElixirException
    {
        SqlRepositoryIF sqlRFIF = null;
        String strSql = "";

        try
        {
            sqlRFIF = CHMSqlRepository.getSqlRepository();
            strSql = sqlRFIF.getSQLString(a_strKey, a_strSQLType);
        }
        catch (EElixirException eex)
        {
            log.debug("CommissionProjectionDAX--sql ex" + eex);
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3019");
        }

        return strSql;
    }

    /**
     * Creates a CommissionProjection Entry in Database
     * @param a_oCommissionProjectionResult CommissionProjectionResult
     * @throws EElixirException
     * @return long
     */
    public long createCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws EElixirException
    {
        PreparedStatement pstmtCreateCommissionProjection = null;

        try
        {
            log.debug(
                "CommissionProjectionDAX-- > INSIDE CREATE CALLING SEQ NBR");

            long lComProjSeqNbr = getNextCommProjSeqNbr();
            log.debug("CommissionProjectionDAX-- > lComProjSeqNbr" +
                lComProjSeqNbr);

            String strAgentCd = a_oCommissionProjectionResult.getAgentCd();
            Integer iCalYear = a_oCommissionProjectionResult.getCalYear();
            Short nCalMonth = a_oCommissionProjectionResult.getCalMonth();
            String strProdCd = a_oCommissionProjectionResult.getProdCd();
            Integer iProdVer = a_oCommissionProjectionResult.getProdVer();
            String strCommClass = a_oCommissionProjectionResult.getCommClass();
            Short nPmtMode = a_oCommissionProjectionResult.getPmtMode();
            Short nTerm = a_oCommissionProjectionResult.getTerm();
            Short nEntryAge = a_oCommissionProjectionResult.getEntryAge();
            Short nNbrOfLives = a_oCommissionProjectionResult.getNbrOfLives();
            Short nNbrOfPol = a_oCommissionProjectionResult.getNbrOfPol();
            Double dPrmAmt = a_oCommissionProjectionResult.getPrmAmt();
            Double dSA = a_oCommissionProjectionResult.getSA();
            Short nTermType = a_oCommissionProjectionResult.getTermType();
            String strCreatedBy = a_oCommissionProjectionResult.getUserId();

            String strCreateQuery = getSQLString("Insert",
                    CHMConstants.COMMISSION_PROJECTION_INSERT);

            log.debug("CommissionProjectionDAX--strCreateQuery =" +
                strCreateQuery);
            pstmtCreateCommissionProjection = getPreparedStatement(strCreateQuery);

            pstmtCreateCommissionProjection.setLong(1, lComProjSeqNbr);
            pstmtCreateCommissionProjection.setString(2, strAgentCd);
            pstmtCreateCommissionProjection.setInt(3, iCalYear.intValue());
            pstmtCreateCommissionProjection.setShort(4, nCalMonth.shortValue());
            pstmtCreateCommissionProjection.setString(5, strProdCd);
            pstmtCreateCommissionProjection.setInt(6, iProdVer.intValue());
            pstmtCreateCommissionProjection.setString(7, strCommClass);
            pstmtCreateCommissionProjection.setShort(8, nPmtMode.shortValue());
            pstmtCreateCommissionProjection.setShort(9, nTerm.shortValue());
            pstmtCreateCommissionProjection.setShort(10, nEntryAge.shortValue());
            pstmtCreateCommissionProjection.setShort(11,
                nNbrOfLives.shortValue());
            pstmtCreateCommissionProjection.setShort(12, nNbrOfPol.shortValue());
            pstmtCreateCommissionProjection.setDouble(13, dPrmAmt.doubleValue());
            pstmtCreateCommissionProjection.setDouble(14, dSA.doubleValue());
            pstmtCreateCommissionProjection.setShort(15, nTermType.shortValue());
            pstmtCreateCommissionProjection.setInt(16, DataConstants.NOT_DELETED);
            pstmtCreateCommissionProjection.setInt(17, DataConstants.PROCESSED);
            pstmtCreateCommissionProjection.setString(18, strCreatedBy);

            int icount = executeUpdate(pstmtCreateCommissionProjection);
            log.debug("CommissionProjectionDAX--insertcount:" + icount);

            return lComProjSeqNbr;
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());
            throw new EElixirException(sqlex, "P3201");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3201");
        }
        finally
        {
            try
            {
                if (pstmtCreateCommissionProjection != null)
                {
                    pstmtCreateCommissionProjection.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Updates CommissionProjection
     * @param a_oCommissionProjectionResult CommissionProjectionResult
     * @throws EElixirException
     * @return int
     */
    public int updateCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws EElixirException
    {
        PreparedStatement pstmtUpdateCommissionProjection = null;

        try
        {
            Long lComProjSeqNbr = a_oCommissionProjectionResult.getComProjSeqNbr();
            String strAgentCd = a_oCommissionProjectionResult.getAgentCd();
            Integer iCalYear = a_oCommissionProjectionResult.getCalYear();
            Short nCalMonth = a_oCommissionProjectionResult.getCalMonth();
            String strProdCd = a_oCommissionProjectionResult.getProdCd();
            Integer iProdVer = a_oCommissionProjectionResult.getProdVer();
            String strCommClass = a_oCommissionProjectionResult.getCommClass();
            Short nPmtMode = a_oCommissionProjectionResult.getPmtMode();
            Short nTerm = a_oCommissionProjectionResult.getTerm();
            Short nEntryAge = a_oCommissionProjectionResult.getEntryAge();
            Short nNbrOfLives = a_oCommissionProjectionResult.getNbrOfLives();
            Short nNbrOfPol = a_oCommissionProjectionResult.getNbrOfPol();
            Double dPrmAmt = a_oCommissionProjectionResult.getPrmAmt();
            Double dSA = a_oCommissionProjectionResult.getSA();
            Short nTermType = a_oCommissionProjectionResult.getTermType();
            String strUpdatedBy = a_oCommissionProjectionResult.getUserId();

            String strUpdateQuery = getSQLString("Update",
                    CHMConstants.COMMISSION_PROJECTION_UPDATE);
            log.debug("CommissionProjectionDAX--strUpdateQuery =" +
                strUpdateQuery);
            pstmtUpdateCommissionProjection = getPreparedStatement(strUpdateQuery);

            //pstmtUpdateCommissionProjection.setString(1,strAgentCd);
            pstmtUpdateCommissionProjection.setInt(1, iCalYear.intValue());
            pstmtUpdateCommissionProjection.setShort(2, nCalMonth.shortValue());
            pstmtUpdateCommissionProjection.setString(3, strProdCd);
            pstmtUpdateCommissionProjection.setInt(4, iProdVer.intValue());
            pstmtUpdateCommissionProjection.setString(5, strCommClass);
            pstmtUpdateCommissionProjection.setShort(6, nPmtMode.shortValue());
            pstmtUpdateCommissionProjection.setShort(7, nTerm.shortValue());
            pstmtUpdateCommissionProjection.setShort(8, nEntryAge.shortValue());
            pstmtUpdateCommissionProjection.setShort(9, nNbrOfLives.shortValue());
            pstmtUpdateCommissionProjection.setShort(10, nNbrOfPol.shortValue());
            pstmtUpdateCommissionProjection.setDouble(11, dPrmAmt.doubleValue());
            pstmtUpdateCommissionProjection.setDouble(12, dSA.doubleValue());
            pstmtUpdateCommissionProjection.setShort(13, nTermType.shortValue());
            pstmtUpdateCommissionProjection.setInt(14, DataConstants.NOT_DELETED);
            pstmtUpdateCommissionProjection.setInt(15, DataConstants.PROCESSED);
            pstmtUpdateCommissionProjection.setString(16, strUpdatedBy);
            pstmtUpdateCommissionProjection.setLong(17,
                lComProjSeqNbr.longValue());

            int icount = executeUpdate(pstmtUpdateCommissionProjection);
            log.debug("CommissionProjectionDAX--updatecount:" + icount);

            return icount;
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P3202");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3202");
        }
        finally
        {
            try
            {
                if (pstmtUpdateCommissionProjection != null)
                {
                    pstmtUpdateCommissionProjection.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Updates Delete Flag of CommissionProjection to mark as deleted
     * @param a_oCommissionProjectionResult CommissionProjectionResult
     * @throws EElixirException
     * @return int
     */
    public int updateDeleteFlagCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws EElixirException
    {
        PreparedStatement pstmtUpdateCommissionProjection = null;

        try
        {
            Long lComProjSeqNbr = a_oCommissionProjectionResult.getComProjSeqNbr();
            String strUpdatedBy = a_oCommissionProjectionResult.getUserId();

            String strUpdateQuery = getSQLString("Update",
                    CHMConstants.COMMISSION_PROJECTION_DELETE_FLAG_UPDATE);
            log.debug("CommissionProjectionDAX--strUpdateQuery =" +
                strUpdateQuery);
            pstmtUpdateCommissionProjection = getPreparedStatement(strUpdateQuery);
            pstmtUpdateCommissionProjection.setInt(1, DataConstants.DELETED);
            pstmtUpdateCommissionProjection.setString(2, strUpdatedBy);
            pstmtUpdateCommissionProjection.setLong(3,
                lComProjSeqNbr.longValue());

            int icount = executeUpdate(pstmtUpdateCommissionProjection);
            log.debug("CommissionProjectionDAX--updatecount:" + icount);

            return icount;
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P3202");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3202");
        }
        finally
        {
            try
            {
                if (pstmtUpdateCommissionProjection != null)
                {
                    pstmtUpdateCommissionProjection.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * @return CommissionProjectionResult
     * @param a_lComProjSeqNbr long
     * @throws EElixirException
     */
    public CommissionProjectionResult getCommissionProjection(
        long a_lComProjSeqNbr) throws EElixirException
    {
        log.debug(
            "CommissionProjectionDAX-- in getCommissionProjection of CommissionProjectionDax");

        ResultSet rsSearchCommissionProjection = null;
        CommissionProjectionResult oCommissionProjectionResult = null;
        PreparedStatement pstmtSearchCommissionProjection = null;

        try
        {
            String strSelectCommissionProjectionQuery = getSQLString("Select",
                    CHMConstants.COMMISSION_PROJECTION_SEARCH_BY_PRIMARYKEY);
            log.debug("CommissionProjectionDAX--search query is " +
                strSelectCommissionProjectionQuery);
            pstmtSearchCommissionProjection = getPreparedStatement(strSelectCommissionProjectionQuery);
            pstmtSearchCommissionProjection.setLong(1, a_lComProjSeqNbr);
            rsSearchCommissionProjection = executeQuery(pstmtSearchCommissionProjection);
            log.debug("CommissionProjectionDAX--Query executed properly");

            if (rsSearchCommissionProjection.next())
            {
                oCommissionProjectionResult = new CommissionProjectionResult();
                oCommissionProjectionResult.setComProjSeqNbr(new Long(
                        a_lComProjSeqNbr));
                oCommissionProjectionResult.setAgentCd(rsSearchCommissionProjection.getString(
                        "strAgentCd"));
                oCommissionProjectionResult.setAgentName(rsSearchCommissionProjection.getString(
                        "strAgentName"));
                oCommissionProjectionResult.setCalYear(new Integer(
                        rsSearchCommissionProjection.getInt("iCalYear")));
                oCommissionProjectionResult.setCalMonth(new Short(
                        rsSearchCommissionProjection.getShort("nCalMonth")));
                oCommissionProjectionResult.setProdCd(rsSearchCommissionProjection.getString(
                        "strProdCd"));
                oCommissionProjectionResult.setProdVer(new Integer(
                        rsSearchCommissionProjection.getInt("iProdVer")));
                oCommissionProjectionResult.setCommClass(rsSearchCommissionProjection.getString(
                        "strCommClass"));
                oCommissionProjectionResult.setPmtMode(new Short(
                        rsSearchCommissionProjection.getShort("nPmtMode")));
                oCommissionProjectionResult.setTerm(new Short(
                        rsSearchCommissionProjection.getShort("nTerm")));
                oCommissionProjectionResult.setEntryAge(new Short(
                        rsSearchCommissionProjection.getShort("nEntryAge")));
                oCommissionProjectionResult.setNbrOfLives(new Short(
                        rsSearchCommissionProjection.getShort("nNbrOfLives")));
                oCommissionProjectionResult.setNbrOfPol(new Short(
                        rsSearchCommissionProjection.getShort("nNbrOfPol")));
                oCommissionProjectionResult.setPrmAmt(new Double(
                        rsSearchCommissionProjection.getDouble("dPrmAmt")));
                oCommissionProjectionResult.setSA(new Double(
                        rsSearchCommissionProjection.getDouble("dSA")));
                oCommissionProjectionResult.setTermType(new Short(
                        rsSearchCommissionProjection.getShort("nTermType")));
                oCommissionProjectionResult.setTsDtUpdated(rsSearchCommissionProjection.getTimestamp(
                        "dtupdated"));

                /* CHANGE TO AVOID UPDATE  */
                oCommissionProjectionResult.setIsDirty(DataConstants.DISPLAY_MODE);

                log.debug(
                    "CommissionProjectionDAX--CommissionProjectionResult filled");
            }

            return oCommissionProjectionResult;
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P3203");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3203");
        }
        finally
        {
            try
            {
                if (rsSearchCommissionProjection != null)
                {
                    rsSearchCommissionProjection.close();
                }

                if (pstmtSearchCommissionProjection != null)
                {
                    pstmtSearchCommissionProjection.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * @return boolean
     * @param a_oCommissionProjectionResult CommissionProjectionResult
     * @throws EElixirException
     */
    public boolean validateCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws EElixirException
    {
        log.debug(
            "CommissionProjectionDAX-- in validateCommissionProjection of CommissionProjectionDax");

        ResultSet rsValidateCommissionProjection = null;
        PreparedStatement pstmtValidateCommissionProjection = null;

        try
        {
            String strAgentCd = a_oCommissionProjectionResult.getAgentCd();
            Integer iCalYear = a_oCommissionProjectionResult.getCalYear();
            Short nCalMonth = a_oCommissionProjectionResult.getCalMonth();
            String strProdCd = a_oCommissionProjectionResult.getProdCd();
            Integer iProdVer = a_oCommissionProjectionResult.getProdVer();

            String strValidateCommissionProjectionQuery = getSQLString("Select",
                    CHMConstants.COMMISSION_PROJECTION_VALIDATE);
            log.debug("CommissionProjectionDAX--validate query is " +
                strValidateCommissionProjectionQuery);
            pstmtValidateCommissionProjection = getPreparedStatement(strValidateCommissionProjectionQuery);
            pstmtValidateCommissionProjection.setString(1, strAgentCd);
            pstmtValidateCommissionProjection.setInt(2, iCalYear.intValue());
            pstmtValidateCommissionProjection.setShort(3, nCalMonth.shortValue());
            pstmtValidateCommissionProjection.setString(4, strProdCd);
            pstmtValidateCommissionProjection.setInt(5, iProdVer.intValue());
            rsValidateCommissionProjection = executeQuery(pstmtValidateCommissionProjection);
            log.debug("CommissionProjectionDAX--Query executed properly");

            if (rsValidateCommissionProjection.next())
            {
                log.debug("CommissionProjectionDAX--true");

                return true;
            }
            else
            {
                log.debug("CommissionProjectionDAX--false");

                return false;
            }
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P3204");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3204");
        }
        finally
        {
            try
            {
                if (rsValidateCommissionProjection != null)
                {
                    rsValidateCommissionProjection.close();
                }

                if (pstmtValidateCommissionProjection != null)
                {
                    pstmtValidateCommissionProjection.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * findCommissionProjection
     * @return boolean
     * @param a_lComProjSeqNbr long
     * @throws EElixirException
     */
    public boolean findCommissionProjection(long a_lComProjSeqNbr)
        throws EElixirException
    {
        ResultSet rsSearchCommissionProjection = null;
        PreparedStatement pstmtFindPrimaryKey = null;

        try
        {
            String strSelectCommissionProjectionQuery = getSQLString("Select",
                    CHMConstants.FIND_COMMISSION_PROJECTION_BY_PRIMARYKEY);

            if (pstmtFindPrimaryKey == null)
            {
                pstmtFindPrimaryKey = getPreparedStatement(strSelectCommissionProjectionQuery);
            }

            pstmtFindPrimaryKey.setLong(1, a_lComProjSeqNbr);
            rsSearchCommissionProjection = executeQuery(pstmtFindPrimaryKey);
            log.debug("CommissionProjectionDAX--Query executed properly");
            log.debug("CommissionProjectionDAX--a_lComProjSeqNbr" +
                a_lComProjSeqNbr);

            if (rsSearchCommissionProjection.next())
            {
                log.debug("CommissionProjectionDAX--returning true");

                return true;
            }
            else
            {
                log.debug("CommissionProjectionDAX--returning false");

                return false;
            }
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P3205");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3205");
        }
        finally
        {
            try
            {
                if (rsSearchCommissionProjection != null)
                {
                    rsSearchCommissionProjection.close();
                }

                if (pstmtFindPrimaryKey != null)
                {
                    pstmtFindPrimaryKey.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * getCommissionProjection
     * @return String
     * @param a_oSearchData Object
     * @throws EElixirException
     */
    public String getCommissionProjection(Object a_oSearchData)
        throws EElixirException
    {
        PreparedStatement pstmtSearchCommProj = null;
        SearchData oSearchData = (SearchData) a_oSearchData;
        HashMap hmQueryMap = new HashMap();
        log.debug(
            "CommissionProjectionDAX--getCommissionProjection() searchdata--- > " +
            a_oSearchData.toString());

        try
        {
            log.debug(
                "CommissionProjectionDAX--Before getting the values from the SearchData");

            String strAgentCd = oSearchData.getTask1();
            String strAgentName = oSearchData.getTask2();
            String iCalYear = oSearchData.getTask3();
            String nCalMonth = oSearchData.getTask4();
            String strCommClass = oSearchData.getTask5();
            String strProdCd = oSearchData.getTask6();
            String strProdVer = oSearchData.getTask7();

            String strSearchCommissionProjectionQuery = getSQLString("Select",
                    CHMConstants.COMMISSION_PROJECTION_LIST_SEARCH);
            hmQueryMap.put("Main", strSearchCommissionProjectionQuery);

            strSearchCommissionProjectionQuery = " AND ccp.strAgentCd like ? ";
            hmQueryMap.put("AgentCd", strSearchCommissionProjectionQuery);

            strSearchCommissionProjectionQuery = " AND UPPER(cam.strLastName||' '||cam.strFirstName) like  ? ";
            hmQueryMap.put("AgentName", strSearchCommissionProjectionQuery);

            strSearchCommissionProjectionQuery = " AND ccp.iCalYear =  ? ";
            hmQueryMap.put("CalYear", strSearchCommissionProjectionQuery);

            strSearchCommissionProjectionQuery = " AND ccp.nCalMonth =  ? ";
            hmQueryMap.put("CalMonth", strSearchCommissionProjectionQuery);

            strSearchCommissionProjectionQuery = " AND ccp.strCommClass =  ? ";
            hmQueryMap.put("CommClass", strSearchCommissionProjectionQuery);

            strSearchCommissionProjectionQuery = " AND ccp.strProdCd =  ? ";
            hmQueryMap.put("ProdCd", strSearchCommissionProjectionQuery);

            strSearchCommissionProjectionQuery = " AND ccp.iProdVer =  ? ";
            hmQueryMap.put("ProdVer", strSearchCommissionProjectionQuery);

            //finished putting in hashmap
            log.debug(" the HASH MAP *********" + hmQueryMap);

            //building the query with "and" data
            String strQuery = (String) hmQueryMap.get("Main");

            if ((strAgentCd != null) && !strAgentCd.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("AgentCd");
            }

            if ((strAgentName != null) && !strAgentName.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("AgentName");
            }

            if ((iCalYear != null) && !iCalYear.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("CalYear");
            }

            if ((nCalMonth != null) && !nCalMonth.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("CalMonth");
            }

            if ((strCommClass != null) && !strCommClass.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("CommClass");
            }

            if ((strProdCd != null) && !strProdCd.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("ProdCd");
            }

            if ((strProdVer != null) && !strProdVer.trim().equals(""))
            {
                strQuery += (String) hmQueryMap.get("ProdVer");
            }

            log.debug("CommissionProjectionDAX--Query Formed = " + strQuery);
            pstmtSearchCommProj = getPreparedStatement(strQuery);
            pstmtSearchCommProj.setInt(1, DataConstants.COMMISSION_CLASS);
            pstmtSearchCommProj.setInt(2, DataConstants.DELETED);

            int iPosition = 2;

            if ((strAgentCd != null) && !strAgentCd.trim().equals(""))
            {
                pstmtSearchCommProj.setString(++iPosition,
                    DataConstants.LIKE_OPERATOR + strAgentCd.toUpperCase() +
                    DataConstants.LIKE_OPERATOR);
            }

            if ((strAgentName != null) && !strAgentName.trim().equals(""))
            {
                pstmtSearchCommProj.setString(++iPosition,
                    DataConstants.LIKE_OPERATOR + strAgentName.toUpperCase() +
                    DataConstants.LIKE_OPERATOR);
            }

            if ((iCalYear != null) && !iCalYear.trim().equals(""))
            {
                pstmtSearchCommProj.setInt(++iPosition,
                    Integer.parseInt(iCalYear.trim()));
            }

            if ((nCalMonth != null) && !nCalMonth.trim().equals(""))
            {
                pstmtSearchCommProj.setInt(++iPosition,
                    Integer.parseInt(nCalMonth.trim()));
            }

            if ((strCommClass != null) && !strCommClass.trim().equals(""))
            {
                pstmtSearchCommProj.setString(++iPosition, strCommClass);
            }

            if ((strProdCd != null) && !strProdCd.trim().equals(""))
            {
                pstmtSearchCommProj.setString(++iPosition, strProdCd);
            }

            if ((strProdVer != null) && !strProdVer.trim().equals(""))
            {
                pstmtSearchCommProj.setInt(++iPosition,
                    Integer.parseInt(strProdVer.trim()));
            }

            ResultSet rsSearch = executeQuery(pstmtSearchCommProj);

            return XMLConverter.getXMLString(rsSearch);
        }

        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());
            throw new EElixirException(sqlex, "P3206");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3206");
        }
        finally
        {
            try
            {
                if (pstmtSearchCommProj != null)
                {
                    pstmtSearchCommProj.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Removes the selected Contract
     * @return int No of rows removed
     * @param: a_lComProjSeqNbr long
     * @throws EElixirException
     */
    public int removeCommissionProjection(long a_lComProjSeqNbr)
        throws EElixirException
    {
        PreparedStatement pstmtRemoveCommissionProjection = null;

        try
        {
            log.debug(
                "CommissionProjectionDAX-- Inside remove CCommissionProjection");

            String strRemoveQuery = getSQLString("Delete",
                    CHMConstants.COMMISSION_PROJECTION_DELETE);
            pstmtRemoveCommissionProjection = getPreparedStatement(strRemoveQuery);
            pstmtRemoveCommissionProjection.setLong(1, a_lComProjSeqNbr);

            int iRemoveCommissionProjection = executeUpdate(pstmtRemoveCommissionProjection);
            log.debug("CommissionProjectionDAX-- removed CommissionProjection" +
                iRemoveCommissionProjection);

            return iRemoveCommissionProjection;
        }
        catch (SQLException sqlex)
        {
            log.exception(sqlex.getMessage());

            //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
            throw new EElixirException(sqlex, "P3207");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3207");
        }
        finally
        {
            try
            {
                if (pstmtRemoveCommissionProjection != null)
                {
                    pstmtRemoveCommissionProjection.close();
                }
            }
            catch (SQLException sqlex)
            {
                log.exception(sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }

    /**
     * Gets the next Seq no for Commission Projection
     * @throws EElixirException
     * @return long
     */
    public long getNextCommProjSeqNbr() throws EElixirException
    {
        try
        {
            log.debug(
                "CommissionProjectionDAX----getNextCommProjSeqNbr()--in try");

            String strQuery = getSQLString("Select",
                    CHMConstants.COMMISSION_PROJECTION_SEQNO);
            log.debug(
                "CommissionProjectionDAX----getNextCommProjSeqNbr()--strQuery" +
                strQuery);

            ResultSet rs = executeQuery(strQuery);
            log.debug(
                "CommissionProjectionDAX----getNextCommProjSeqNbr()--ResultSet");
            rs.next();
            log.debug(
                "CommissionProjectionDAX----getNextCommProjSeqNbr()--ResultSet.next done");

            return rs.getLong(1);
        }
        catch (SQLException sqlex)
        {
            log.debug(
                "CommissionProjectionDAX----getNextCommProjSeqNbr()--SQLException");
            log.exception(sqlex.getMessage());
            throw new EElixirException(sqlex, "P3208");
        }
        catch (EElixirException eex)
        {
            log.debug(
                "CommissionProjectionDAX----getNextCommProjSeqNbr()--EElixirException");
            log.exception(eex.getMessage());
            throw new EElixirException(eex, "P3208");
        }
    }
}
