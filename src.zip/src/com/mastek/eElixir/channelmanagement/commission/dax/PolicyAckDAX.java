/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : PolicyAckDAX.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_policy_ackn_upd.doc.doc
*  CREATION DATE                  : 29/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
* 1.1      04/09/2003   Dipti      Code Rework
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.commission.util.PolicyAckResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;


/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the Contract object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class PolicyAckDAX extends DAX
{
    /*
    /*
     *  Member variables
     */
    private static SqlRepositoryIF _oSqlRFIF = null;
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor
     */
    public PolicyAckDAX() throws EElixirException
    {
        _oSqlRFIF = CHMSqlRepository.getSqlRepository();
    }

    /**
      * Description Depending on SEarchData returns Arraylist of SelfContract
      * @return ArrayList
      * @param a_oSearchData SearchData
      * @throws EElixirException
      */
    public ArrayList getPolicyAck(SearchData a_oSearchData)
        throws EElixirException
    {
        ResultSet rsSearchPolicyAck = null;
        PreparedStatement _pstmtFindPrimaryKey = null;
        ArrayList _oPolicyAckList = new ArrayList();
        PolicyAckResult _oPolicyAckResult = null;
        StringBuffer sbSearchQuery = null;
        int iPosition = 0;
        short iAckDays = 0;
        int iProcess = 0;
        String strServAgent=null;
        ArrayList _oPolicyAckServAgentList = new ArrayList();
        try
        {
            String strPolNbr = a_oSearchData.getTask1().trim();
            //CR_Agent_Polack_update_217152 by Arun
            String strSearchServAgent=_oSqlRFIF.getSQLString(CHMConstants.SEARCH_POLICY_SERV_AGENT,
            "Select");
            _oLogger.debug("Search query for the serving agent code is "+strSearchServAgent);
            _pstmtFindPrimaryKey=getPreparedStatement(strSearchServAgent);
            _pstmtFindPrimaryKey.setString(1,strPolNbr.trim());
			 rsSearchPolicyAck = executeQuery(_pstmtFindPrimaryKey);
			 if (rsSearchPolicyAck.next())
             {            	
               strServAgent = rsSearchPolicyAck.getString("STRSERVAGENTCD");
             }
            else
            {
            	_oLogger.debug("Servicing Agent is not availabel for this policy");
            	throw new EElixirException("P9200");
            }
            _oLogger.debug("strServAgent is "+strServAgent);
            a_oSearchData.setTask2(strServAgent);
           // CR_Agent_Polack_update_217152
            String strServAgentCd = a_oSearchData.getTask2().trim();
            String strPolAckn = a_oSearchData.getTask3().trim();

            String strCompany = _oSqlRFIF.getSQLString(CHMConstants.POLICY_ACKN_DAYS,
                    "Select");
            _pstmtFindPrimaryKey = getPreparedStatement(strCompany);
			_pstmtFindPrimaryKey.setString(1,strServAgentCd);

            rsSearchPolicyAck = executeQuery(_pstmtFindPrimaryKey);

            if (rsSearchPolicyAck.next())
            {
                iAckDays = rsSearchPolicyAck.getShort(1);
            }

            sbSearchQuery = new StringBuffer(_oSqlRFIF.getSQLString(
                        CHMConstants.FIND_POLICYACK_BY_PRIMARYKEY_1, "Select"));

            if ((strPolNbr != null) && !strPolNbr.trim().equals(""))
            {
                sbSearchQuery.append(" AND a.strpolnbr = UPPER(?) ");
            }

            if ((strServAgentCd != null) && !strServAgentCd.trim().equals(""))
            {
                sbSearchQuery.append(" AND a.strservagentcd = UPPER(?) ");
            }

            if ((strPolAckn != null) && !strPolAckn.trim().equals(""))
            {
                sbSearchQuery.append(" AND a.dtPolAckn = ?");
            }
            _oLogger.debug("sbSearchQuery final query is "+sbSearchQuery);
            _pstmtFindPrimaryKey = getPreparedStatement(sbSearchQuery.toString());

            if ((strPolNbr != null) && !strPolNbr.trim().equals(""))
            {
                _pstmtFindPrimaryKey.setString(++iPosition, strPolNbr.trim());
            }

            if ((strServAgentCd != null) && !strServAgentCd.trim().equals(""))
            {
                _pstmtFindPrimaryKey.setString(++iPosition,
                    strServAgentCd.trim());
            }

            if ((strPolAckn != null) && !strPolAckn.trim().equals(""))
            {
                _pstmtFindPrimaryKey.setTimestamp(++iPosition,
                    DateUtil.retTimestamp(DateUtil.retGCDate(strPolAckn.trim())));
            }

            rsSearchPolicyAck = executeQuery(_pstmtFindPrimaryKey);

            while (rsSearchPolicyAck.next())
            {
                _oPolicyAckResult = new PolicyAckResult();
                _oPolicyAckResult.setAckDays(new Short(iAckDays));
                _oPolicyAckResult.setPolNbr(rsSearchPolicyAck.getString(
                        "strPolnbr"));
                _oPolicyAckResult.setPolIssue(DateUtil.retGregorian(
                        rsSearchPolicyAck.getTimestamp("dtPolIssue")));
                _oPolicyAckResult.setPolicyHolderName(rsSearchPolicyAck.getString(
                        "Name"));

                if (rsSearchPolicyAck.getString("Nterm") != null)
                {
                    _oPolicyAckResult.setTerm(new Short(
                            rsSearchPolicyAck.getShort("Nterm")));
                }

                if (rsSearchPolicyAck.getString("dSA") != null)
                {
                    _oPolicyAckResult.setSa(new Double(
                            rsSearchPolicyAck.getDouble("dSA")));
                }

                if (rsSearchPolicyAck.getString("Dprmamnt") != null)
                {
                    _oPolicyAckResult.setPrmAmnt(new Double(
                            rsSearchPolicyAck.getDouble("Dprmamnt")));
                }

                _oPolicyAckResult.setStatus(rsSearchPolicyAck.getString(
                        "nstatus"));

                if (rsSearchPolicyAck.getTimestamp("dtPolAckn") != null)
                {
                    _oPolicyAckResult.setPolAckn(DateUtil.retGregorian(
                            rsSearchPolicyAck.getTimestamp("dtPolAckn")));
                }

                if (rsSearchPolicyAck.getTimestamp("dtPolAcknReceipt") != null)
                {
                    _oPolicyAckResult.setPolAcknReceipt(DateUtil.retGregorian(
                            rsSearchPolicyAck.getTimestamp("dtPolAcknReceipt")));
                }

                _oPolicyAckResult.setPolAcknProcess(new Short(
                        rsSearchPolicyAck.getString("nispolacknProcess")));

                iProcess = _oPolicyAckResult.getPolAcknProcess().intValue();

				_oLogger.debug("Valie of Ip[rocess is "+iProcess);
                if ((_oPolicyAckResult.getPolAcknProcess() != null) &&
                        ((iProcess == DataConstants.PROCESS_RUN) || 
                        (iProcess == DataConstants.PROCESS_NOT_RUN)))
                {
                    _oPolicyAckResult.setStatusFlag(DataConstants.UPDATE_MODE);
					_oLogger.debug("Valie of Ip[rocess is  Update Flad");
                }
                else
                {
                    _oPolicyAckResult.setStatusFlag(DataConstants.DISPLAY_MODE);
					_oLogger.debug("Valie of Ip[rocess is  Dipslay Flad");
                }

                _oPolicyAckResult.setTsDtUpdated(rsSearchPolicyAck.getTimestamp(
                        "dtupdated"));
				_oLogger.debug("Value of Status Flag "+_oPolicyAckResult.getStatusFlag());
                _oPolicyAckList.add(_oPolicyAckResult);
            }
             _oPolicyAckServAgentList.add(0,strServAgentCd);
             _oPolicyAckServAgentList.add(1,_oPolicyAckList);
             return _oPolicyAckServAgentList;
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "getPolicyAck ",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P3039");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "getPolicyAck ",
                eex.getMessage());
            throw new EElixirException(eex, "P3039");
        }
        finally
        {
            try
            {
                if (_pstmtFindPrimaryKey != null)
                {
                    _pstmtFindPrimaryKey.close();
                }
            }
            catch (SQLException sqlex)
            {
                throw new EElixirException(sqlex, "P3039");
            }
        }
    }

    /**
      * Description Depending on SEarchData returns boolean
      * @return boolean
      * @param a_strPolNbr String
      * @param a_strServAgentCd String
      * @throws EElixirException
      */
    public boolean searchPolicyAck(String a_strPolNbr, String a_strServAgentCd)
        throws EElixirException
    {
        ResultSet rsSearchPolicyAck = null;
        PreparedStatement _pstmtFindPrimaryKey = null;
        String strSelectPolicyAckQuery = null;

        try
        {
            strSelectPolicyAckQuery = _oSqlRFIF.getSQLString(CHMConstants.FIND_POLICYACK_BY_PRIMARYKEY_2,
                    "Select");

            if (_pstmtFindPrimaryKey == null)
            {
                _pstmtFindPrimaryKey = getPreparedStatement(strSelectPolicyAckQuery);
            }

            _pstmtFindPrimaryKey.setString(1, a_strPolNbr.toUpperCase());
            _pstmtFindPrimaryKey.setString(2, a_strServAgentCd.toUpperCase());

            rsSearchPolicyAck = executeQuery(_pstmtFindPrimaryKey);

            if (rsSearchPolicyAck.next())
            {
                return true;
            }

            return false;
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "getPolicyAck ",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P3039");
        }
        catch (EElixirException eex)
        {
			_oLogger.fatal(getClass().getName(), "getPolicyAck ",
			eex.getMessage());
            throw new EElixirException(eex, "P3039");
        }
        finally
        {
            try
            {
                if (_pstmtFindPrimaryKey != null)
                {
                    _pstmtFindPrimaryKey.close();
                }
            }
            catch (SQLException sqlex)
            {
                throw new EElixirException(sqlex, "P3039");
            }
        }
    }

    /**
      * Description Updates PolicyAck
      * @param oPolicyAckResult PolicyAckResult
      * @throws EElixirException
      */
    public void updatePolicyAck(PolicyAckResult a_oPolicyAckResult)
        throws EElixirException
    {
        PreparedStatement pstmtPolicyAck = null;

        try
        {
            String strUpdatePolicyAck = _oSqlRFIF.getSQLString(CHMConstants.POLICYACK_UPDATE,
                    "Update");
            pstmtPolicyAck = getPreparedStatement(strUpdatePolicyAck);

            pstmtPolicyAck.setTimestamp(1,
                DateUtil.retTimestamp(a_oPolicyAckResult.getPolAckn()));
            pstmtPolicyAck.setTimestamp(2,
                DateUtil.retTimestamp(a_oPolicyAckResult.getPolAcknReceipt()));
            pstmtPolicyAck.setString(3, a_oPolicyAckResult.getUserId());
            pstmtPolicyAck.setString(4,
                a_oPolicyAckResult.getPolNbr().toUpperCase());
            pstmtPolicyAck.setString(5,
                a_oPolicyAckResult.getServAgentCd().toUpperCase());
            executeUpdate(pstmtPolicyAck);
        }
        catch (SQLException sqlex)
        {
            sqlex.printStackTrace();
            _oLogger.fatal(getClass().getName(), "updatePolicyAck",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "Error while updating PolicyAck",
                "P3040");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "updatePolicyAck",
                eex.getMessage());
            throw new EElixirException(eex, "P3040");
        }
        finally
        {
            try
            {
                if (pstmtPolicyAck != null)
                {
                    pstmtPolicyAck.close();
                }
            }
            catch (SQLException sqlex)
            {
                throw new EElixirException(sqlex, "P3040");
            }
        }
    }

    /**
    * This method gets the the dtupdated of Nominee
    * @return Timestamp
    * @param: Long lSeqNbr, String strAgentCd
    * @throws EElixirException
    */
    public Timestamp getPolicyAckDtUpdated(String a_strPolNbr)
        throws EElixirException
    {
        ResultSet rsSearch = null;
        PreparedStatement pstmtSearch = null;

        try
        {
            String strSelectAgencyQuery = _oSqlRFIF.getSQLString(CHMConstants.GET_POLICY_DETAILS_DTUPDATED,
                    "Select");
            pstmtSearch = getPreparedStatement(strSelectAgencyQuery);
            pstmtSearch.setString(1, a_strPolNbr);

            rsSearch = executeQuery(pstmtSearch);

            if (rsSearch.next())
            {
                return rsSearch.getTimestamp("dtupdated");
            }
            else
            {
                throw new EElixirException("P1100");
            }
        }
        catch (SQLException sqlex)
        {
            _oLogger.fatal(getClass().getName(), "getPolicyAckDtUpdated ",
                sqlex.getMessage());
            throw new EElixirException(sqlex, "P2036");
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "getPolicyAckDtUpdated ",
                eex.getMessage());
            throw eex;
        }
        finally
        {
            try
            {
                if (rsSearch != null)
                {
                    rsSearch.close();
                }
            }
            catch (SQLException sqlex)
            {
                _oLogger.fatal(getClass().getName(), "getPolicyAckDtUpdated ",
                    sqlex.getMessage());
                throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
            }
        }
    }
}
