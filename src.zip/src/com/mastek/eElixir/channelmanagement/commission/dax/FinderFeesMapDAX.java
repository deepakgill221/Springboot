/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Finder Fees
*  FILENAME			: FinderFeesMapDAX.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: Dec 03, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2004.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY           REASON
 *-------------------------------------------------------------------------------- 
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesMapResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DAXIF;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;

  /**
   * <p>Title: eElixir</p>
   * <p>Description:The DAX implementaion for the FinderFeesMap object </p>
   * <p>Copyright: Copyright (c) 2002</p>
   * <p>Company: Mastek Ltd</p>
   * @author Diptik
   * @version 1.0
   */

 public class FinderFeesMapDAX extends DAX implements DAXIF
 {
   public CHMSqlRepository theCHMSqlRepository= null;

   /**
	* Constructor
	*/

   public FinderFeesMapDAX()
   {

   }

   /**
	 * Inserts FinderFeesmapping details into database
	 * @param request HttpServletRequest
	 * @return Collection of FinderFeesMappingDVO object
	 * @throws EElixirException
	*/
   public void insertFinderFeesMap(FinderFeesMapResult a_oFinderFeesMapResult) throws EElixirException
   {
	 PreparedStatement pstmtCreateFinderFeesMap = null;
	 String strFinderFeesMapSeqQuery, strFinderFeesMapInitialStatusQuery;
	 
	 String strCreatedBy = a_oFinderFeesMapResult.getUserId();
	 ResultSet rs;

	 try
	 {
	   String strCreateFinderFeesMapQuery = getSQLString("Insert",CHMConstants.FINDERFEES_MAPPING_INSERT);	   
	   pstmtCreateFinderFeesMap = getPreparedStatement(strCreateFinderFeesMapQuery);
	   log.debug("Query Formed  " + strCreateFinderFeesMapQuery);   

	   int iPos=0;	
	   log.debug("SEQ NBR:::" +  a_oFinderFeesMapResult.getFFMapSeqNbr().longValue());
	   pstmtCreateFinderFeesMap.setLong(++iPos, a_oFinderFeesMapResult.getFFMapSeqNbr().longValue());
	   
	   log.debug("CONTRACT NBR:::" + a_oFinderFeesMapResult.getContractName().trim());
	   pstmtCreateFinderFeesMap.setString(++iPos, a_oFinderFeesMapResult.getContractName().trim());
	   
	   log.debug("DT EFF FROM:::" + DateUtil.retStrDate(a_oFinderFeesMapResult.getEffFrom()));
	   pstmtCreateFinderFeesMap.setTimestamp(++iPos, DateUtil.retTimestamp(a_oFinderFeesMapResult.getEffFrom()));
   
	   if(a_oFinderFeesMapResult.getEffTo() == null)
	   {
   	//  pstmtCreateFinderFeesMap.setString(7, DataConstants.MAX_DATE_LIMIT);
 		log.debug("DT TO WHEN DT TO IS NULL:::" + DataConstants.MAX_DATE_LIMIT);
 		log.debug("DT TO WHEN DT TO IS NULL:::" + DateUtil.retTimestamp(DateUtil.retGCDate(DataConstants.MAX_DATE_LIMIT)));
	 	pstmtCreateFinderFeesMap.setTimestamp(++iPos, DateUtil.retTimestamp(DateUtil.retGCDate(DataConstants.MAX_DATE_LIMIT)));
   	   }
   	   else
   	   {
	 	log.debug("DT TO WHEN DT TO IS NOT NULL:::" + DateUtil.retTimestamp(a_oFinderFeesMapResult.getEffTo()));
	 	pstmtCreateFinderFeesMap.setTimestamp(++iPos, DateUtil.retTimestamp(a_oFinderFeesMapResult.getEffTo()));
   	   }
	   
	   log.debug("Channeltype:::" +  a_oFinderFeesMapResult.getChannelType().trim());
	   pstmtCreateFinderFeesMap.setString(++iPos,a_oFinderFeesMapResult.getChannelType().trim());
   
	   log.debug("AGENT CODE:::" +  a_oFinderFeesMapResult.getAgentCd().trim());
	   if(a_oFinderFeesMapResult.getAgentCd() != null && !a_oFinderFeesMapResult.getAgentCd().trim().equals(""))
	   {
		 pstmtCreateFinderFeesMap.setString(++iPos, a_oFinderFeesMapResult.getAgentCd().trim().toUpperCase());
	   }
	   else
	   {
		 pstmtCreateFinderFeesMap.setNull(++iPos, java.sql.Types.VARCHAR);
	   }


	  

	   log.debug("STATUS PENDING ID:::" + DataConstants.STATUS_PENDING_ID);
	   pstmtCreateFinderFeesMap.setInt(++iPos, DataConstants.STATUS_PENDING_ID);
	   // added by Amit 11/1/2002

	   log.debug("USER ID:::" + a_oFinderFeesMapResult.getUserId());
	   pstmtCreateFinderFeesMap.setString(++iPos,a_oFinderFeesMapResult.getUserId());
	   pstmtCreateFinderFeesMap.setString(++iPos,a_oFinderFeesMapResult.getUserId());
	   pstmtCreateFinderFeesMap.setLong(++iPos,a_oFinderFeesMapResult.getUniqueMapSeqNbr().longValue());
	   
	   log.debug("before execute" + pstmtCreateFinderFeesMap.toString());
	   
	   int iUpdCnt=executeUpdate(pstmtCreateFinderFeesMap);
	   
	   log.debug("insertFinderFeesMap -- >iUpdCnt"+iUpdCnt);

	 }
	 catch(SQLException sqlex)
	 {
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex, "P3029");
	 }

	 finally
	 {
	   try
	   {
		 if(pstmtCreateFinderFeesMap != null)
		   pstmtCreateFinderFeesMap.close();
	   }
	   catch(SQLException sqlex)
	   {
		 log.exception(sqlex.getMessage());
		 throw new EElixirException(sqlex, "P3029");
	   }
	 }

   }


   public long getNextFinderFeesMapSeqNbr() throws EElixirException
   {
	 try
	 {
	   String strFinderFeesMapSeqQuery = getSQLString("Select",CHMConstants.FINDERFEES_MAPPING_SEQ_NO);
	   ResultSet   rs = executeQuery(strFinderFeesMapSeqQuery);
	   rs.next();
	   return rs.getLong(1);
	 }
	 catch(SQLException sqlex)
	 {
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex,"P3043");
	 }
	 catch(EElixirException eex)
	 {
	   log.exception(eex.getMessage());
	   throw new EElixirException(eex,"P3043");
	 }

	}

   public void checkForActiveAgent(String a_StrAgentCd, String a_CChannelType) throws EElixirException
   {
	  log.debug("FinderFeesMapDax -- > inside checkForActiveAgent()");
	  ResultSet rs;
	  String  strActiveAgentQuery = getSQLString("Select",CHMConstants.FINDERFEES_MAP_AGENT_SEARCH);
	  log.debug("strActiveAgentQuery");

	  PreparedStatement pstmtFinderFeesMapAgentQuery = getPreparedStatement(strActiveAgentQuery);
	  log.debug("after getting prepared stmt");
	  try
	  {
	  	log.debug("a_StrAgentCd :"+a_StrAgentCd);
		log.debug("a_CChannelType :"+a_CChannelType);		
		
		pstmtFinderFeesMapAgentQuery.setString(1, a_StrAgentCd);
		pstmtFinderFeesMapAgentQuery.setString(2, a_StrAgentCd);
		pstmtFinderFeesMapAgentQuery.setString(3, a_CChannelType);
		pstmtFinderFeesMapAgentQuery.setInt(4, DataConstants.AGENCY_AGENT_STATUS);
		pstmtFinderFeesMapAgentQuery.setInt(5, DataConstants.ACTIVE_AGENT_AGENCY_STATUS);
		pstmtFinderFeesMapAgentQuery.setInt(6, DataConstants.IS_IN_AGENCY);		
		rs = executeQuery(pstmtFinderFeesMapAgentQuery);
		if(rs.next())
		{
		  log.debug("Active agent found");
		}
		else
		{
		  log.debug("Agent not found");
		  throw new EElixirException("P3035");
		}
	  }
	  catch(SQLException sqlex)
	  {
		log.exception(sqlex.getMessage());
		throw new EElixirException(sqlex,"P3044");
	  }
	  catch(EElixirException eex)
	  {
		log.exception(eex.getMessage());
		throw new EElixirException(eex,"P3044");
	  }
   }

   public void insertTransStatus(long _lUniqueMapSeqNbr, String strUser) throws EElixirException
   {
	 log.debug("FinderFeesMapDax: in inserttransstatus: seqnbr" + _lUniqueMapSeqNbr + " userid " + strUser);
	 PreparedStatement pstmtApprovalInsert = null;

	 try
	 {
		String strInsertApplication = getSQLString("Insert",CHMConstants.TRANSACTION_STATUS_INSERT);
		log.debug("FinderFeesMapDAX: The Trans status query " + strInsertApplication);

		pstmtApprovalInsert = getPreparedStatement(strInsertApplication);

		pstmtApprovalInsert.setInt(1,DataConstants.TRANSACTIONS_FINDERFEES_MAP);
		log.debug("FinderFeesMapDAX: set 1st param  " + DataConstants.TRANSACTIONS_FINDERFEES_MAP);

		pstmtApprovalInsert.setLong(2, _lUniqueMapSeqNbr);
		log.debug("FinderFeesMapDAX: set 2nd param  " + _lUniqueMapSeqNbr);

		pstmtApprovalInsert.setInt(3,DataConstants.STATUS_PENDING_ID);
		log.debug("FinderFeesMapDAX: set 3rd param  " + DataConstants.STATUS_PENDING_ID);

//		  pstmtApprovalInsert.setTimestamp(4,DateUtil.retTimestamp(DateUtil.retGCDate(DateUtil.getSystemDate())));
		//log.debug("FinderFeesMapDAX: set 4th param  " + DataConstants.STATUS_PENDING_ID);

		pstmtApprovalInsert.setString(4,""); //to be clarified
		log.debug("FinderFeesMapDAX: set 5th param  " );

		pstmtApprovalInsert.setString(5, strUser); //to be clarified
		log.debug("FinderFeesMapDAX: set 6th param  "+strUser );

		log.debug("brfore execute inserttransstatus");
		int iInsertApplication = executeUpdate(pstmtApprovalInsert);
	   log.debug("FinderFeesMapDAX: Trans status Insert over");
   }
	   catch(SQLException sqlex)	
	   {
		  log.exception(sqlex.getMessage());
		  throw new EElixirException(sqlex, "P1010");
	  }
	  catch(EElixirException eex)
	  {
		 log.exception(eex.getMessage());
		throw new EElixirException(eex,"P1010");
	  }
   }


   public void checkForDuplicateFinderFeesMap(String a_strChannelType,  String a_strAgentCode,  String a_strContractName) throws EElixirException
   {
	 PreparedStatement pstmtCheckDuplicateFinderFeesMap = null;
	 ResultSet rs ;
	 try
	 {
	   log.debug("before getsqlstring");

	   String strCheckDuplicateFinderFeesMapQuery = getSQLString("Select",CHMConstants.FINDERFEES_MAP_DUPLICATE_CHECK);

	   log.debug(strCheckDuplicateFinderFeesMapQuery);

	   pstmtCheckDuplicateFinderFeesMap = getPreparedStatement(strCheckDuplicateFinderFeesMapQuery);
	   log.debug("Query Formed  " + pstmtCheckDuplicateFinderFeesMap);
	   log.debug("a_strChannelType  " + a_strChannelType);
	   log.debug("a_strAgentCode " + a_strAgentCode);
	   log.debug("a_strContractName " + a_strContractName);

	   pstmtCheckDuplicateFinderFeesMap.setString(1,a_strChannelType);
	   pstmtCheckDuplicateFinderFeesMap.setString(2,a_strAgentCode);
	   pstmtCheckDuplicateFinderFeesMap.setString(3,a_strContractName);
	   pstmtCheckDuplicateFinderFeesMap.setInt(4,DataConstants.STATUS_APPROVED_ID);
	   rs = executeQuery(pstmtCheckDuplicateFinderFeesMap);
	   if(rs.next())
	   {
		 throw new EElixirException("P3037");
	   }

	 }
	 catch(SQLException sqlex){
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex, "P3037");
	 }
	 catch(EElixirException eex)
	 {
	   log.exception(eex.getMessage());
	   throw new EElixirException(eex,"P3037");
	 }
	 finally
	 {
	   try
	   {
		 if(pstmtCheckDuplicateFinderFeesMap != null)
		   pstmtCheckDuplicateFinderFeesMap.close();
	   }
	   catch(SQLException sqlex)
	   {
		 log.exception(sqlex.getMessage());
		 throw new EElixirException(sqlex, "P3037");
	   }
	 }

   }


   public void checkForDuplicateFinderFeesMap(String a_strChannelType,  String a_strContractName) throws EElixirException
   {
	 PreparedStatement pstmtCheckDuplicateFinderFeesMap = null;
	 ResultSet rs ;
	 try
	 {
	   log.debug("before getsqlstring");

	   String strCheckDuplicateFinderFeesMapQuery = getSQLString("Select",CHMConstants.FINDERFEES_MAP_DUPLICATE_CHECK_FOR_CHANNEL);

	   log.debug(strCheckDuplicateFinderFeesMapQuery);

	   pstmtCheckDuplicateFinderFeesMap = getPreparedStatement(strCheckDuplicateFinderFeesMapQuery);
	   log.debug("Query Formed  " + pstmtCheckDuplicateFinderFeesMap);
	   log.debug("a_strChannelType  " + a_strChannelType);
	   log.debug("a_strContractName " + a_strContractName);

	   pstmtCheckDuplicateFinderFeesMap.setString(1,a_strChannelType);
	   pstmtCheckDuplicateFinderFeesMap.setString(2,a_strContractName);
	   pstmtCheckDuplicateFinderFeesMap.setInt(3,DataConstants.STATUS_APPROVED_ID);
	   rs = executeQuery(pstmtCheckDuplicateFinderFeesMap);
	   if(rs.next())
	   {
		 throw new EElixirException("P3048");
	   }

	 }
	 catch(SQLException sqlex){
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex, "P3048");
	 }
	 catch(EElixirException eex)
	 {
	   log.exception(eex.getMessage());
	   throw new EElixirException(eex,"P3048");
	 }
	 finally
	 {
	   try
	   {
		 if(pstmtCheckDuplicateFinderFeesMap != null)
		   pstmtCheckDuplicateFinderFeesMap.close();
	   }
	   catch(SQLException sqlex)
	   {
		 log.exception(sqlex.getMessage());
		 throw new EElixirException(sqlex, "P3048");
	   }
	 }

   }



   public void updateFinderFeesMap(FinderFeesMapResult a_oFinderFeesMapResult) throws EElixirException
   {
	 PreparedStatement pstmtUpdateFinderFeesMap = null;
	 try
		   {
			 log.debug("before getsqlstring");

			 String strUpdateFinderFeesMapQuery = getSQLString("Update",CHMConstants.FINDERFEES_MAPPING_UPDATE);

			 log.debug(strUpdateFinderFeesMapQuery);

			 pstmtUpdateFinderFeesMap = getPreparedStatement(strUpdateFinderFeesMapQuery);
			 log.debug("Query Formed  " + pstmtUpdateFinderFeesMap);
		  
			 log.debug("dtEffFrom " + DateUtil.retTimestamp(a_oFinderFeesMapResult.getEffFrom()));
			 log.debug("dtEffTo " + DateUtil.retTimestamp(a_oFinderFeesMapResult.getEffTo()));
			 log.debug("pKey " + a_oFinderFeesMapResult.getFFMapSeqNbr());
		   
			 
			 pstmtUpdateFinderFeesMap.setTimestamp(1,DateUtil.retTimestamp(a_oFinderFeesMapResult.getEffFrom()));
			 pstmtUpdateFinderFeesMap.setTimestamp(2,DateUtil.retTimestamp(a_oFinderFeesMapResult.getEffTo()));
			 // added by Amit 11/1/2002
			 pstmtUpdateFinderFeesMap.setString(3,a_oFinderFeesMapResult.getUserId());
			 pstmtUpdateFinderFeesMap.setLong(4, a_oFinderFeesMapResult.getFFMapSeqNbr().longValue());
			 int iUpd=executeUpdate(pstmtUpdateFinderFeesMap);
			 
			 log.debug("FFMapDAX  --> updateFinderFeesMap --> iUpd :"+iUpd);
			 
		   }
		   catch(SQLException sqlex){
			 log.exception(sqlex.getMessage());
			 throw new EElixirException(sqlex, "P3030");
		   }
		   catch(EElixirException eex)
		   {
			 log.exception(eex.getMessage());
			 throw new EElixirException(eex,"P3030");
		   }
		   finally
		   {
			 try
			 {
			   if(pstmtUpdateFinderFeesMap != null)
				 pstmtUpdateFinderFeesMap.close();
			 }
			 catch(SQLException sqlex)
			 {
			   log.exception(sqlex.getMessage());
			   throw new EElixirException(sqlex, "P3030");
			 }
		   }

		 }

//Delete functionality has been removed, so this is commented//
/*
		 private void deleteFinderFeesMap(FinderFeesMap a_oFinderFeesMap) throws EElixirException
		 {
		   PreparedStatement pstmtDeleteFinderFeesMap = null;
		   try
		   {
			 if(! ( (_oFinderFeesMap.get_iNStatus()).intValue() == DataConstants.STATUS_APPROVED_ID))
			 {
			   log.debug("before getsqlstring");
			   String strDeleteFinderFeesMapQuery = getSQLString("Delete",CHMConstants.CONTRACT_MAPPING_DELETE);
			   log.debug(strDeleteFinderFeesMapQuery);
			   pstmtDeleteFinderFeesMap = getPreparedStatement(strDeleteFinderFeesMapQuery);
			   log.debug("Query Formed  " + pstmtDeleteFinderFeesMap);
			   log.debug("pKey " + _oFinderFeesMap.get_strPKey());
			   pstmtDeleteFinderFeesMap.setLong(1,Long.parseLong(_oFinderFeesMap.get_strPKey()));
			   executeUpdate(pstmtDeleteFinderFeesMap);
			 }
		   }
		   catch(SQLException sqlex)
		   {
			 log.exception(sqlex.getMessage());
			 throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
		   }
		   catch(EElixirException eex)
		   {
			 log.exception(eex.getMessage());
			 throw new EElixirException(eex,"P3031");
		   }
		   finally
		   {
			 try
			 {
			   if(pstmtDeleteFinderFeesMap != null)
				 pstmtDeleteFinderFeesMap.close();
			 }
			 catch(SQLException sqlex)
			 {
			   log.exception(sqlex.getMessage());
			   throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
			 }
		   }

		 }


	*/

   /**
	* Gets the SQL string from the document Object
	* @param strSQLType
	* @param strKey
	* @return strSql
	* @throws EElixirException
	*/

   private String getSQLString(String strSQLType,String strKey) throws EElixirException
   {
	SqlRepositoryIF _oSqlRepositoryIF = CHMSqlRepository.getSqlRepository();
	String strSql =_oSqlRepositoryIF.getSQLString(strKey,strSQLType);
	return strSql;
   }

   public  void populateDVOs()
   {

   }

   protected  Object getEntityDVO()
   {
	 return null;
   }

   protected  Collection getEntityDVOCollection()
   { return null;
   }


	 /**
	* searchFinderFeesMap
	* @return boolean
	* @param a_LFFMapSeqNbr long
	* @throws EElixirException
	*/
   public boolean searchFinderFeesMap(long a_LFFMapSeqNbr) throws EElixirException
   {
	 ResultSet rsSearchContMap = null;
	 PreparedStatement _pstmtFindPrimaryKey = null;
	 try
	 {
	   String strSelectContMapQuery = getSQLString("Select",CHMConstants.FINDERFEES_MAPPING_SEARCH_SQL);

	   if(_pstmtFindPrimaryKey == null)
	   {
		 _pstmtFindPrimaryKey = getPreparedStatement(strSelectContMapQuery);
	   }
	   log.debug("In Dax: " + a_LFFMapSeqNbr);
	   _pstmtFindPrimaryKey.setLong(1, a_LFFMapSeqNbr);


	   rsSearchContMap = executeQuery(_pstmtFindPrimaryKey);
	   if(rsSearchContMap.next())
	   {
		 return true;
	   }
	   else
	   {
		 return false;
	   }
	 }
	 catch(SQLException sqlex){
	  log.exception(sqlex.getMessage());
	  throw new EElixirException(sqlex, "P3033");
	}
	catch(EElixirException eex)
	{
	  log.exception(eex.getMessage());
	  throw new EElixirException(eex,"P3033");
	}
	finally
	{
	  try
	  {
		if(_pstmtFindPrimaryKey != null)
		  _pstmtFindPrimaryKey.close();
	  }
	  catch(SQLException sqlex)
	  {
		log.exception(sqlex.getMessage());
		throw new EElixirException(sqlex, "P3033");
	  }
	}

 }


 /**
  * getAgentDetails
  * @return AgentResult
  * @param: a_strAgentCd String
  * @throws EElixirException
  */
 public ArrayList getFinderFeesMapList(long a_LFFMapSeqNbr) throws EElixirException
 {
   log.debug("in getFinderFeesMap of AdjustmentDax");
   ResultSet rsSearchFinderFeesMap = null;
   FinderFeesMapResult _oFinderFeesMapResult = null;
   PreparedStatement _pstmtSearchFinderFeesMap = null;
   ArrayList alFinderFeesMapResult = new ArrayList();
   
   try
   {
		String strSelectFinderFeesMapQuery = getSQLString("Select",CHMConstants.FINDERFEESMAPSEARCH);
		log.debug("The FinderFeesMap search query is " + strSelectFinderFeesMapQuery);
		
		if(_pstmtSearchFinderFeesMap == null)
		{
		  _pstmtSearchFinderFeesMap = getPreparedStatement(strSelectFinderFeesMapQuery);
		}
		
		_pstmtSearchFinderFeesMap.setLong(1, a_LFFMapSeqNbr);
		_pstmtSearchFinderFeesMap.setInt(2, DataConstants.COMMON_STATUS);
		
		log.debug("The FinderFeesMap seqnbr passed is  " + a_LFFMapSeqNbr);
		rsSearchFinderFeesMap = executeQuery(_pstmtSearchFinderFeesMap);
		log.debug("query executed properly");
	 
		 while(rsSearchFinderFeesMap.next())
		 {
		   _oFinderFeesMapResult = new FinderFeesMapResult();
		   
		   _oFinderFeesMapResult.setChannelType(rsSearchFinderFeesMap.getString(1));
		   _oFinderFeesMapResult.setFFMapSeqNbr(new Long(rsSearchFinderFeesMap.getLong(2)));
		   _oFinderFeesMapResult.setAgentCd(rsSearchFinderFeesMap.getString(3));
		   if(rsSearchFinderFeesMap.wasNull())
		   {
			 _oFinderFeesMapResult.setAgentCd(null);
		   }
	   
		   _oFinderFeesMapResult.setEffFrom(DateUtil.retGregorian(rsSearchFinderFeesMap.getTimestamp(4)));
		   _oFinderFeesMapResult.setContractName(rsSearchFinderFeesMap.getString(5));
		   _oFinderFeesMapResult.setEffTo(DateUtil.retGregorian(rsSearchFinderFeesMap.getTimestamp(6)));
		   if(rsSearchFinderFeesMap.wasNull())
		   {
			 _oFinderFeesMapResult.setEffTo(null);
		   }
		   _oFinderFeesMapResult.setStatus(new Short(rsSearchFinderFeesMap.getShort(7)));
		   _oFinderFeesMapResult.setStatusDesc(rsSearchFinderFeesMap.getString(8));
		   _oFinderFeesMapResult.setUserId(rsSearchFinderFeesMap.getString(9));
		   _oFinderFeesMapResult.setAgentName(rsSearchFinderFeesMap.getString(10));
		   _oFinderFeesMapResult.setUniqueMapSeqNbr(new Long(rsSearchFinderFeesMap.getLong("LUNIQUEMAPSEQNBR")));
		   _oFinderFeesMapResult.setFinderRuleEffFrom(DateUtil.retGregorian(rsSearchFinderFeesMap.getTimestamp("HDRDTEFFFROM")));
		   _oFinderFeesMapResult.setStatusFlag(DataConstants.DISPLAY_MODE);
		   _oFinderFeesMapResult.setTsDtUpdated(rsSearchFinderFeesMap.getTimestamp("dtupdated"));
		   _oFinderFeesMapResult.setIsProdSpecific(new Short(rsSearchFinderFeesMap.getShort("NISPRODUCTSPECIFIC")));
		   _oFinderFeesMapResult.setFFHdrSeqNbr(new Long(rsSearchFinderFeesMap.getLong("LFFHDRSEQNBR")));
		   
		   alFinderFeesMapResult.add(_oFinderFeesMapResult);
		   
		   log.debug("FinderFeesMapDax : added FinderFeesMapResult "+_oFinderFeesMapResult);
		 }
		 log.debug("returning arraylist size "+ alFinderFeesMapResult.size());
		 return alFinderFeesMapResult;

   }
   catch(SQLException sqlex){
	 log.exception(sqlex.getMessage());
	 throw new EElixirException(sqlex, "P3034");
   }
   catch(EElixirException eex)
   {
	 log.exception(eex.getMessage());
	 throw new EElixirException(eex,"P3034");
   }
   finally
   {
	 try
	 {
	   if(_pstmtSearchFinderFeesMap != null)
		 _pstmtSearchFinderFeesMap.close();
	 }
	 catch(SQLException sqlex)
	 {
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex, "P3034");
	 }
   }

 }


 /**
  * getAgentDetails
  * @return AgentResult
  * @param: a_strAgentCd String
  * @throws EElixirException
  */
 public FinderFeesMapResult getFinderFeesMap(long a_LFFMapSeqNbr) throws EElixirException
 {
   log.debug("in getFinderFeesMap of FinderFees map DAX");
   ResultSet rsSearchFinderFeesMap = null;
   FinderFeesMapResult _oFinderFeesMapResult = null;
   PreparedStatement _pstmtSearchFinderFeesMap = null;
   try
   {
	 String strSelectFinderFeesMapQuery = getSQLString("Select",CHMConstants.FINDERFEES_MAP_SEARCH_BY_PRIMARY_KEY);
	 log.debug("The FinderFeesMap search query is " + strSelectFinderFeesMapQuery);

	 if(_pstmtSearchFinderFeesMap == null)
	 {
	   _pstmtSearchFinderFeesMap = getPreparedStatement(strSelectFinderFeesMapQuery);
	 }

	 _pstmtSearchFinderFeesMap.setLong(1, a_LFFMapSeqNbr);
	 _pstmtSearchFinderFeesMap.setInt(2, DataConstants.COMMON_STATUS);

	 log.debug("The FinderFeesMap seqnbr passed is  " + a_LFFMapSeqNbr);
	 rsSearchFinderFeesMap = executeQuery(_pstmtSearchFinderFeesMap);
	 log.debug("query executed properly");
	 
	 if(rsSearchFinderFeesMap.next())
	 {
	   _oFinderFeesMapResult = new FinderFeesMapResult();
	   _oFinderFeesMapResult.setChannelType(rsSearchFinderFeesMap.getString(1));
	   _oFinderFeesMapResult.setFFMapSeqNbr(new Long(rsSearchFinderFeesMap.getLong(2)));
	   _oFinderFeesMapResult.setAgentCd(rsSearchFinderFeesMap.getString(3));
	   if(rsSearchFinderFeesMap.wasNull())
	   {
		 _oFinderFeesMapResult.setAgentCd(null);
	   }
   
	   _oFinderFeesMapResult.setEffFrom(DateUtil.retGregorian(rsSearchFinderFeesMap.getTimestamp(4)));
	   _oFinderFeesMapResult.setContractName(rsSearchFinderFeesMap.getString(5));
	   _oFinderFeesMapResult.setEffTo(DateUtil.retGregorian(rsSearchFinderFeesMap.getTimestamp(6)));
	   if(rsSearchFinderFeesMap.wasNull())
	   {
		 _oFinderFeesMapResult.setEffTo(null);
	   }
	   _oFinderFeesMapResult.setStatus(new Short(rsSearchFinderFeesMap.getShort(7)));
	   _oFinderFeesMapResult.setStatusDesc(rsSearchFinderFeesMap.getString(8));
	   _oFinderFeesMapResult.setUserId(rsSearchFinderFeesMap.getString(9));
	   _oFinderFeesMapResult.setAgentName(rsSearchFinderFeesMap.getString(10));
	   _oFinderFeesMapResult.setUniqueMapSeqNbr(new Long(rsSearchFinderFeesMap.getLong("LUNIQUEMAPSEQNBR")));
	   _oFinderFeesMapResult.setTsDtUpdated(rsSearchFinderFeesMap.getTimestamp("dtupdated"));
	   _oFinderFeesMapResult.setStatusFlag(DataConstants.DISPLAY_MODE);
	   _oFinderFeesMapResult.setIsDirty(DataConstants.DISPLAY_MODE);
	   


	   log.debug("FinderFeesMapDax : added FinderFeesMapResult "+_oFinderFeesMapResult);
	 }
	 log.debug("returning finderfees map result obj"+ _oFinderFeesMapResult);
	 return _oFinderFeesMapResult;

   }
   catch(SQLException sqlex){
	 log.exception(sqlex.getMessage());
	 throw new EElixirException(sqlex, "P3034");
   }
   catch(EElixirException eex)
   {
	 log.exception(eex.getMessage());
	 throw new EElixirException(eex,"P3034");
   }
   finally
   {
	 try
	 {
	   if(_pstmtSearchFinderFeesMap != null)
		 _pstmtSearchFinderFeesMap.close();
	 }
	 catch(SQLException sqlex)
	 {
	   log.exception(sqlex.getMessage());
	   throw new EElixirException(sqlex, "P3034");
	 }
   }

 }


 public void validateFinderFeesEffectiveDate(String strContractName, GregorianCalendar _dtEffFrom) throws EElixirException
 {
   PreparedStatement pstmtSearchFinderFees= null;
   Statement st = null ;
   StringBuffer sb = new StringBuffer();
   GregorianCalendar _finderfeesDt = null;
   
   try
   {
   		 log.debug("before getsqlstring");
		 String strSearchFinderFeesQuery = getSQLString("Select",CHMConstants.FINDERFEES_EFFECTIVE_DATE_CHECK);
		
		 log.debug("strSearchFinderFeesQuery :"+strSearchFinderFeesQuery);
		 pstmtSearchFinderFees = getPreparedStatement(strSearchFinderFeesQuery);
		 pstmtSearchFinderFees.setInt(1,DataConstants.STATUS_APPROVED_ID);
		 pstmtSearchFinderFees.setInt(2, DataConstants.COMMON_STATUS);
		 pstmtSearchFinderFees.setString(3, strContractName.trim().toUpperCase());
		 
		 ResultSet rsSearch = executeQuery(pstmtSearchFinderFees);
		 
		  if(rsSearch.next())
		  {
			_finderfeesDt = DateUtil.retGregorian(rsSearch.getTimestamp(2));
			if(_dtEffFrom.before( _finderfeesDt))
			{
			  throw new EElixirException("P3045");
			}
		  }
   }

	catch(SQLException sqlex)
   {
	log.exception(sqlex.getMessage());
	throw new EElixirException("P3045");
   }
   finally
   {
   try
	 {
	   if(pstmtSearchFinderFees != null)
		  pstmtSearchFinderFees.close();
	 }
   catch(SQLException sqlex)
	{
	 log.exception(sqlex.getMessage());
	 throw new EElixirException("P3045");
	}
   }

 }


 /**
	* Searches for finderfees mapping on given parameters.
	* @param request HttpServletRequest
	* @return String
	* @throws EElixirException
	*/

  public String getFinderFeesMap(SearchData oSearchData) throws EElixirException
  {
	PreparedStatement pstmtSearchFinderFeesMapping = null;
	Statement st = null ;
	StringBuffer sb = new StringBuffer();
	HashMap hmQueryMap = new HashMap();
	String strLikePrefix = "%";

	try
	{
	  String strChannelType		= oSearchData.getTask1(); // Channel Type
	  String strContractName	= oSearchData.getTask2(); // Contract/Mapping Rule Name
	  String strAgentCode		= oSearchData.getTask3(); // Agent Code
	  String strAgentName   	= oSearchData.getTask4(); // Agent Name
	  
	  GregorianCalendar _dtEffdt 	= oSearchData.getTaskDate1(); // Effective Date
	  String strMappingStatus = oSearchData.getTask5(); // Mapping Status  

	  String strSearchFinderFeesMappingQuery = getSQLString("Select",CHMConstants.FINDERFEESMAPLISTSEARCH );

	  log.debug(strSearchFinderFeesMappingQuery);
	  hmQueryMap.put("Main",strSearchFinderFeesMappingQuery);

	  //check database column names here

	  strSearchFinderFeesMappingQuery = " AND m.CCHANNELTYPE =  UPPER(?) " ;
	  hmQueryMap.put("ChannelType",strSearchFinderFeesMappingQuery);

	  strSearchFinderFeesMappingQuery = " AND UPPER(trim(m.STRCONTRACTNAME)) LIKE UPPER(?) " ;
	  hmQueryMap.put("ContractName",strSearchFinderFeesMappingQuery);
	  
	  strSearchFinderFeesMappingQuery = " AND m.STRAGENTCD LIKE UPPER(?) " ;
	  hmQueryMap.put("AgentCode",strSearchFinderFeesMappingQuery);

	  //strSearchFinderFeesMappingQuery = " AND UPPER(trim(a.STRLASTNAME||' '||a.STRFIRSTNAME)) LIKE UPPER(?) " ;
	  //hmQueryMap.put("AgentName",strSearchFinderFeesMappingQuery); 
	  

	  strSearchFinderFeesMappingQuery = " AND m.DTEFFFROM =  ? " ;
	  hmQueryMap.put("EffDate",strSearchFinderFeesMappingQuery);

	  strSearchFinderFeesMappingQuery = " AND m.NSTATUS =  ? " ;
	  hmQueryMap.put("MappingStatus",strSearchFinderFeesMappingQuery);

	  String strQuery = (String)hmQueryMap.get("Main");
	  
	  if (strChannelType != null && !strChannelType.trim().equals("")) {
		strQuery += (String)hmQueryMap.get("ChannelType");
	  }
	  
	  log.debug("before get ContractName" + strContractName);
	  if (strContractName!= null && !strContractName.equals("")) {
		strQuery += (String)hmQueryMap.get("ContractName");
	  }

	  log.debug("before get agentcode" + strAgentCode);
	  if (strAgentCode != null && !strAgentCode.equals("")) {
		strQuery += (String)hmQueryMap.get("AgentCode");
	  }
	  /*log.debug("before get agentname" + strAgentName);
	  if (strAgentName!= null && !strAgentName.equals("")) {
		strQuery += (String)hmQueryMap.get("AgentName");
	  }*/	  
			
	  log.debug("before get agentdate" + _dtEffdt);
	  if (_dtEffdt!= null && !_dtEffdt.toString().equals("")) {
		strQuery += (String)hmQueryMap.get("EffDate");
	  }
	  log.debug("before get agentmapstatus" + strMappingStatus);
	  if (strMappingStatus!= null && !strMappingStatus.trim().equals("")) {
		strQuery += (String)hmQueryMap.get("MappingStatus");
	  }
	  log.debug("before get afull query");
	  pstmtSearchFinderFeesMapping = getPreparedStatement(strQuery);
	  log.debug("Query Formed  " + strQuery);

	  pstmtSearchFinderFeesMapping.setInt(1, DataConstants.COMMON_STATUS);

	  int iPosition = 1 ;
	  	

	  if (strChannelType!= null && !strChannelType.trim().equals("")) {
		log.debug("\nAdding strChannelType Code " );
		pstmtSearchFinderFeesMapping.setString(++iPosition,strChannelType.trim());
	  }
	  
	  if (strContractName!= null && !strContractName.equals("")) {
		log.debug("\nAdding contract name" );
		pstmtSearchFinderFeesMapping.setString(++iPosition, (strLikePrefix.concat(strContractName.trim())).concat(strLikePrefix) );
	  }

	  if (strAgentCode!= null && !strAgentCode.equals("")) {
		log.debug("\nAdding strAgentCode Code " );
		String prefix = "%";
		strAgentCode = prefix.concat(strAgentCode.trim());
		strAgentCode = strAgentCode.concat(prefix);
		pstmtSearchFinderFeesMapping.setString(++iPosition, (strLikePrefix.concat(strAgentCode.trim())).concat(strLikePrefix) );
	  }

	  /*if (strAgentName!= null && !strAgentName.equals("")) {
		log.debug("\nAdding agent name" );
		 pstmtSearchFinderFeesMapping.setString(++iPosition, (strLikePrefix.concat(strAgentName.trim())).concat(strLikePrefix) );
	  }*/

	  if (_dtEffdt!= null && !_dtEffdt.toString().equals("")) {
		log.debug("\nAdding eff date Code " );
		pstmtSearchFinderFeesMapping.setTimestamp(++iPosition,DateUtil.retTimestamp(_dtEffdt));
	  }

	  if (strMappingStatus!= null && !strMappingStatus.trim().equals("")) {
		log.debug("\nAdding strMappingStatus Code " );
		pstmtSearchFinderFeesMapping.setShort(++iPosition, Short.parseShort(strMappingStatus.trim()));
	  }

	  log.debug("before execute" + pstmtSearchFinderFeesMapping.toString());
	  ResultSet rsSearch = executeQuery(pstmtSearchFinderFeesMapping);
	  log.debug("before returnin");
	  return XMLConverter.getXMLString(rsSearch);
	}
	catch(SQLException sqlex){
	  log.exception(sqlex.getMessage());
	  throw new EElixirException(sqlex, "P3034");
	}
	catch(EElixirException eex)
	{
	  log.exception(eex.getMessage());
	  throw new EElixirException(eex,"P3034");
	}
	finally
	{
	  try
	  {
		if(pstmtSearchFinderFeesMapping != null)
		  pstmtSearchFinderFeesMapping.close();
	  }
	  catch(SQLException sqlex)
	  {
	  	
		log.exception(sqlex.getMessage());
		throw new EElixirException(sqlex, "P3034");
	  }
	}
  }

  /**
   * validateForProductOverlap finds whether the agent has product overlap across multiple mapped finderfees
   * @return void
   * @param String PersistencyResult
   * @throws EElixirException
   */
  public void validateForProductOverlap(FinderFeesMapResult oFinderFeesMapResult)
		  throws EElixirException
  {
	  log.debug("FinderFeesMapDAX----validateForProductOverlap()");
	  ResultSet rsDuplicate = null;
	  PreparedStatement _pstmtFindPrimaryKey = null;
	  int _iESLRRecords = 0;
	  String strSelectTargetRecords ="";
	  
	  try
	  {
		  log.debug("FinderFeesMapDAX--> validateForProductOverlap()--in try");
		  log.debug("FinderFeesMapDAX--> Is Prod Spec Value   :"+oFinderFeesMapResult.getIsProdSpecific());
		  log.debug("FinderFeesMapDAX--> FF Hdr Seq Nbr Value :"+oFinderFeesMapResult.getFFHdrSeqNbr());
		  
		  // if product Specific 
		  if(oFinderFeesMapResult.getIsProdSpecific().shortValue()==new Integer(DataConstants.PRODUCT_SPEC).shortValue())
		  {
			strSelectTargetRecords = getSQLString("Select",CHMConstants.FINDERFEES_MAP_PRODUCT_SPEC_OVERLAP_CHECK);
		  }
		  
		  if(oFinderFeesMapResult.getIsProdSpecific().shortValue()==new Integer(DataConstants.NON_PRODUCT_SPEC).shortValue())
		  {		  
		  	strSelectTargetRecords = getSQLString("Select",CHMConstants.FINDERFEES_MAP_NON_PRODUCT_SPEC_OVERLAP_CHECK);
		  }		  
		  
		  if(oFinderFeesMapResult.getAgentCd() == null || oFinderFeesMapResult.getAgentCd().trim().equals(""))
		  {
		  	  strSelectTargetRecords = strSelectTargetRecords + " and a.CChannelType = ?  and a.strAgentCd is null )";
		  }
		  else
		  {
			  strSelectTargetRecords = strSelectTargetRecords + " and a.strAgentCd = ? )";
		  }
		  
		  strSelectTargetRecords = strSelectTargetRecords + " and c.lffhdrseqnbr= ? ";
		
		  log.debug("FinderFeesMapDAX--> strSelectTargetRecords :"+strSelectTargetRecords);

		  if(_pstmtFindPrimaryKey == null)	
		  {
			 _pstmtFindPrimaryKey = getPreparedStatement(strSelectTargetRecords);
			 log.debug("FinderFeesMapDAX--> _pstmtFindPrimaryKey	:" + _pstmtFindPrimaryKey);
		  }
		  	
		  log.debug("ContractName :"+oFinderFeesMapResult.getContractName());
		  log.debug("Eff From		:"+DateUtil.retTimestamp(oFinderFeesMapResult.getEffFrom()));
		
		  int iPos=0;
		  
		  if(oFinderFeesMapResult.getIsProdSpecific().shortValue()==new Integer(DataConstants.PRODUCT_SPEC).shortValue())
		  {
			_pstmtFindPrimaryKey.setString(++iPos, oFinderFeesMapResult.getContractName());
		  }	
		  
	 	  _pstmtFindPrimaryKey.setTimestamp(++iPos, DateUtil.retTimestamp(oFinderFeesMapResult.getEffFrom()));
	   	  _pstmtFindPrimaryKey.setInt(++iPos, DataConstants.STATUS_PENDING_ID);
	   	  _pstmtFindPrimaryKey.setInt(++iPos, DataConstants.STATUS_APPROVED_ID);

		  if(oFinderFeesMapResult.getAgentCd() == null || oFinderFeesMapResult.getAgentCd().trim().equals(""))
		  {			  
			log.debug("FinderFeesMapDAX----validateForProductOverlap()--adding channel type:"+oFinderFeesMapResult.getChannelType());
			_pstmtFindPrimaryKey.setString(++iPos, oFinderFeesMapResult.getChannelType());
		  }
		  else
		  {			  
			log.debug("FinderFeesMapDAX----validateForProductOverlap()--adding agent code:"+oFinderFeesMapResult.getAgentCd());
			_pstmtFindPrimaryKey.setString(++iPos, oFinderFeesMapResult.getAgentCd());
		  }
		  
		  // setting the FF Header Seq Nbr.
		  _pstmtFindPrimaryKey.setLong(++iPos, oFinderFeesMapResult.getFFHdrSeqNbr().longValue());
		  

		  log.debug("FinderFeesMapDAX----validateForProductOverlap()--before firing query");

		  rsDuplicate = executeQuery(_pstmtFindPrimaryKey);
		  
		  if(rsDuplicate.next())
		  {
			  log.debug("FinderFeesMapDAX----validateForProductOverlap()--if rs.next");
			  _iESLRRecords = rsDuplicate.getInt(1);

			  log.debug("FinderFeesMapDAX----validateForProductOverlap()--_iESLRRecords :" + _iESLRRecords);
		  }
		  if(_iESLRRecords > 0)
		  {
			  throw new EElixirException("P3101");
		  }
	  }
	  catch(SQLException sqlex){
		  log.debug("FinderFeesMapDAX-------validateForProductOverlap()----- DAX--- SQLEx");
		  log.exception(sqlex.getMessage());
		  throw new EElixirException(sqlex, "P3101");
	  }
	  catch(EElixirException eex)
	  {
		  log.debug("FinderFeesMapDAX-------validateForProductOverlap()----- DAX--- EEEx");
		  log.exception(eex.getMessage());
		  throw new EElixirException(eex,"P3101");
	  }
	  finally
	  {
		  try
		  {

			  if(_pstmtFindPrimaryKey != null)
				  _pstmtFindPrimaryKey.close();

		  }
		  catch(SQLException sqlex)
		  {
			  log.exception(sqlex.getMessage());
			  throw new EElixirException(sqlex, "P3101");
		  }
	  }
  }


  /* get FinderFees Map */


   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
	private Collection appColl;
	private ArrayList _oFinderFeesMapAList;
	private PreparedStatement _ChannelFinderFeesMappingPreparedStatement = null;

 }
