/********************************************************************
 *
 *  PROJECT			: PRUDENTIAL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME			: ContractDAX.java
 *  AUTHOR			: Pallav Laddha
 *  VERSION			: 1.0
 *  CREATION DATE	        : September 20, 2002
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *1.1             16Jan2003         Pallav            added payment Mode field for create
 *                                                  update, delete.
 *1.2             23Jan2003         Pallav            added Term Type
 *1.3			  11Mar2003		    VinayC			Making clwback indicator non mandatory
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.dax;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.commission.dvo.ContractProdValidate;
import com.mastek.eElixir.channelmanagement.commission.util.ClawbackResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractCopyResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.commission.util.SelfContractResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;

/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the Contract object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class ContractDAX extends DAX
{
  /**
   * Constructor
   */
  public ContractDAX()
  {

  }


  /**
   * Populates the resultset into XML string object
   * @param a_oResultObject Object
   * @return XML string object
   * @throws EElixirException
   */

  public String getContract(Object a_oResultObject) throws EElixirException
  {
    log.debug("ContractDAX--Inside getContract of DAX");
    PreparedStatement pstmtSearchContract = null;
    Statement st = null ;
    StringBuffer sb = new StringBuffer();
    HashMap hmQueryMap = new HashMap();
    SearchData oSearchData = (SearchData)a_oResultObject;
    log.debug("ContractDAX--Search Data" + oSearchData);
    try
    {
      String strContractNbr = oSearchData.getTask1();
      GregorianCalendar dtEffFrom = oSearchData.getTaskDate1();
      String nStatus = oSearchData.getTask3();
      String strProdCd = oSearchData.getTask2();
      log.debug("ContractDAX--after Search Data");
      String strSearchContractQuery = getSQLString("Select",CHMConstants.CONTRACT_DEFINITION);

      hmQueryMap.put("Main",strSearchContractQuery);

      log.debug("ContractDAX--Contract Number >>"+strContractNbr + "<<");
      log.debug("ContractDAX--Effective Date >>"+dtEffFrom + "<<");
      log.debug("ContractDAX--Contract Status >>"+strProdCd + "<<");

      strSearchContractQuery = " AND cah.strContractNbr LIKE ? " ;
      hmQueryMap.put("ContractNumber",strSearchContractQuery);

      strSearchContractQuery = " AND cah.dtEffFrom =  ? " ;
      hmQueryMap.put("EffectiveDate",strSearchContractQuery);

      strSearchContractQuery = " AND cah.nStatus =  ? " ;
      hmQueryMap.put("ContractStatus",strSearchContractQuery);

      strSearchContractQuery = " AND cah.strProdCd =  ? " ;
      hmQueryMap.put("ProductCode",strSearchContractQuery);

      String strQuery = (String)hmQueryMap.get("Main");
      log.debug("ContractDAX--Strquery =" + strQuery);
      if (strContractNbr != null && !strContractNbr.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("ContractNumber");
      }
      if (dtEffFrom!= null) {
        strQuery += (String)hmQueryMap.get("EffectiveDate");
      }
      if (nStatus!= null && !nStatus.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("ContractStatus");
      }
      if (strProdCd!= null && !strProdCd.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("ProductCode");
      }
      strQuery = strQuery + " order by cah.strContractNbr";
      log.debug("ContractDAX--Strquery =" + strQuery);
      pstmtSearchContract = getPreparedStatement(strQuery);
      log.debug("ContractDAX--Query Formed  " + strQuery);

      int iPosition = 0 ;
      // removed hardcoding from query
      pstmtSearchContract.setInt(++iPosition, DataConstants.COMMON_STATUS);
      pstmtSearchContract.setInt(++iPosition, DataConstants.COMMISSION_TYPE);
      pstmtSearchContract.setInt(++iPosition, DataConstants.COMMISSION_CLASS);
      pstmtSearchContract.setInt(++iPosition, DataConstants.PAYMENT_FREQUENCY);
      pstmtSearchContract.setInt(++iPosition, DataConstants.TERM_TYPE);
      pstmtSearchContract.setInt(++iPosition, DataConstants.CAMPAIGN_CD);

      if (strContractNbr!= null && !strContractNbr.trim().equals("")) {
        log.debug("ContractDAX--Adding Contract Number " );
        pstmtSearchContract.setString(++iPosition,"%" + strContractNbr.trim().toUpperCase() + "%");
      }
      if (dtEffFrom != null) {
        log.debug("ContractDAX--Adding Effective Date " );
        pstmtSearchContract.setTimestamp(++iPosition,DateUtil.retTimestamp(dtEffFrom));
      }
      if (nStatus != null && !nStatus.trim().equals("")) {
        log.debug("ContractDAX--Adding Contract Status " );
        pstmtSearchContract.setInt(++iPosition,Integer.parseInt(nStatus.trim()));
      }
      if (strProdCd != null && !strProdCd.trim().equals("")) {
        log.debug("ContractDAX--Adding Product Code " );
        pstmtSearchContract.setString(++iPosition,strProdCd.trim());
      }

      ResultSet rsSearch = executeQuery(pstmtSearchContract);
      return XMLConverter.getXMLString(rsSearch);
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3015");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3015");
    }
    finally
    {
      try
      {
        if(pstmtSearchContract != null)
          pstmtSearchContract.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

  /**
   * findContract finds whether the contract is there or not
   * @return boolean
   * @param a_oContractResult ContractResult
   * @throws EElixirException
   */
  public boolean validateContract(ContractResult a_oContractResult) throws EElixirException
  {
    ResultSet rsSearchContract = null;
    PreparedStatement pstmtFindUniqueKey = null;
    try
    {
      String strContractNumber = a_oContractResult.getContractNumber();
      GregorianCalendar dtEffectiveDate  = a_oContractResult.getEffectiveDate();
      //Integer oiContractStatus = a_oContractResult.getContractStatus();

      CommissionResult oCommissionResult = a_oContractResult.getCommissionResult();

      //String strCommBase     = oCommissionResult.getCommBase();
      Short nCommType        = oCommissionResult.getCommType();
      String strCommClass    = oCommissionResult.getCommClass();
      String strProdCd       = oCommissionResult.getProdCd();
	  String strBaseProdCd   = oCommissionResult.getBaseProdCd();
      Integer oiProdVer      = oCommissionResult.getProdVer();
      String strCampaignCd   = oCommissionResult.getCampaignCd();
      Short nPmtMode         = oCommissionResult.getPmtMode();
      Short nTermType        = oCommissionResult.getTermType();
      Integer iBaseProdVer	 = oCommissionResult.getBaseProdVer();
      //Integer oiBaseUnits    = oCommissionResult.getBaseUnits();
      // this functionality is removed
      //String strDistribType  = oCommissionResult.getDistribType();
	  log.debug("nCommType:" + nCommType);
	  log.debug("strCommClass:" + strCommClass);
	  log.debug("strProdCd:" + strProdCd);
	  log.debug("strBaseProdCd:" + strBaseProdCd);
	  log.debug("oiProdVer:" + oiProdVer);
	  log.debug("strCampaignCd:" + strCampaignCd);
	  log.debug("nPmtMode:" + nPmtMode);
	  log.debug("nTermType:" + nTermType);
	  log.debug("iBaseProdVer:" + iBaseProdVer);

      String strSelectContractQuery = getSQLString("Select",CHMConstants.CONTRACT_VALIDATE);
	  if(strCampaignCd == null || strCampaignCd.trim().equals("")){
		strSelectContractQuery = strSelectContractQuery + " AND strCampaignCd is Null";
	  }
	  else{
		strSelectContractQuery = strSelectContractQuery + " AND strCampaignCd = ?";
	  }

	  if(strBaseProdCd == null || strBaseProdCd.trim().equals("")){
		strSelectContractQuery = strSelectContractQuery + " AND strBaseProdCd is Null";
	  }
	  else{
		strSelectContractQuery = strSelectContractQuery + " AND strBaseProdCd = ?";
	  }
	  log.debug("strSelectContractQuery:" + strSelectContractQuery);


      if(pstmtFindUniqueKey == null)
      {
        pstmtFindUniqueKey = getPreparedStatement(strSelectContractQuery);
      }

      pstmtFindUniqueKey.setString(1,strContractNumber.trim().toUpperCase());
      pstmtFindUniqueKey.setTimestamp(2,DateUtil.retTimestamp(dtEffectiveDate));
      pstmtFindUniqueKey.setInt(3,nCommType.intValue());
      pstmtFindUniqueKey.setString(4,strCommClass);
      pstmtFindUniqueKey.setString(5,strProdCd.trim().toUpperCase());
      if(oiProdVer == null){
        pstmtFindUniqueKey.setInt(6,java.sql.Types.INTEGER);
      }
      else{
        pstmtFindUniqueKey.setInt(6,oiProdVer.intValue());
      }
      pstmtFindUniqueKey.setShort(7,nPmtMode.shortValue());
      pstmtFindUniqueKey.setShort(8,nTermType.shortValue());
	  if (iBaseProdVer != null)
	  {
		  pstmtFindUniqueKey.setInt(9,iBaseProdVer.intValue());
	  }
	  else
	  {
		  pstmtFindUniqueKey.setInt(9,java.sql.Types.INTEGER);
	  }
	  int pos = 10;
	  if(strCampaignCd == null || strCampaignCd.trim().equals("")){
		  log.debug("inside campaign if");
	      //pstmtFindUniqueKey.setNull(10,java.sql.Types.VARCHAR);
	  }
	  else{
		  log.debug("inside campaign else");
		  pstmtFindUniqueKey.setString(pos,strCampaignCd);
		  pos++;
	  }

	  if(strBaseProdCd == null || strBaseProdCd.trim().equals(""))
      {
		  log.debug("inside strbaseprod if");
	      //pstmtFindUniqueKey.setNull(11,java.sql.Types.VARCHAR);
      }
      else
      {
		  log.debug("inside strbaseprod else");
          pstmtFindUniqueKey.setString(pos,strBaseProdCd);
	  }

      //pstmtFindUniqueKey.setString(8,strDistribType.trim().toUpperCase());

      rsSearchContract = executeQuery(pstmtFindUniqueKey);
      if(rsSearchContract.next())
      {
        log.debug("ContractDAX--  Returning true");
        return true;
      }
      else
      {
        log.debug("ContractDAX--  Returning false");
        return false;
      }
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3016");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3016");
    }
    finally
    {
      try
      {
        if(rsSearchContract != null)
          rsSearchContract.close();

        if(pstmtFindUniqueKey != null)
          pstmtFindUniqueKey.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }




  /**
   * Inserts transaction for approval
   * @return int
   * @param lComAgreementKey long
   * @param strUpdatedBy String
   * @throws EElixirException
   */
  public int insertTransactionForApproval(long lComAgreementKey,String strUpdatedBy) throws EElixirException
  {
    PreparedStatement pstmtApprovalInsert = null;
    try
    {
        String strInsertApplication = getSQLString("Insert",CHMConstants.TRANSACTION_STATUS_INSERT);
        pstmtApprovalInsert = getPreparedStatement(strInsertApplication);
        log.debug("ContractDAX--AgentApplicationDAX: The Trans status query " + pstmtApprovalInsert);

        pstmtApprovalInsert.setInt(1,DataConstants.TRANSACTIONS_CONTRACT);
        pstmtApprovalInsert.setLong(2, lComAgreementKey);
        pstmtApprovalInsert.setInt(3,DataConstants.STATUS_PENDING_ID);
//        pstmtApprovalInsert.setTimestamp(4,DateUtil.retTimestamp(DateUtil.retGCDate(DateUtil.getSystemDate())));
        pstmtApprovalInsert.setString(4,""); //to be clarified
        pstmtApprovalInsert.setString(5,strUpdatedBy); //to be clarified

        int iInsertApplication = executeUpdate(pstmtApprovalInsert);
       log.debug("ContractDAX--AgentApplicationDAX: Trans status Insert over");
       return iInsertApplication;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3016");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3016");
    }
    finally
    {
      try
      {
        if(pstmtApprovalInsert != null)
          pstmtApprovalInsert.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }



  /**
   * findContract finds whether the contract is there or not
   * @return boolean
   * @param a_lCommAgrmtSeqNbr long
   * @throws EElixirException
   */
  public boolean findContract(long a_lCommAgrmtSeqNbr) throws EElixirException
  {
    ResultSet rsSearchContract = null;
    PreparedStatement pstmtFindPrimaryKey = null;
    try
    {
      String strSelectContractQuery = getSQLString("Select",CHMConstants.CONTRACT_SEARCH);
      if(pstmtFindPrimaryKey == null)
      {
        pstmtFindPrimaryKey = getPreparedStatement(strSelectContractQuery);
      }
      pstmtFindPrimaryKey.setLong(1,a_lCommAgrmtSeqNbr);

      rsSearchContract = executeQuery(pstmtFindPrimaryKey);
      if(rsSearchContract.next())
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3017");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"3017");
    }
    finally
    {
      try
      {
        if(rsSearchContract != null)
          rsSearchContract.close();

        if(pstmtFindPrimaryKey != null)
          pstmtFindPrimaryKey.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

  /**
   * getContract gets the Contract Details
   * @return ContractResult
   * @param: a_lCommAgrmtSeqNbr long
   * @throws EElixirException
   */
  public ContractResult getContract(long a_lCommAgrmtSeqNbr) throws EElixirException
  {
    ResultSet rsSearchContract = null;
    ContractResult oContractResult = null;
    CommissionResult oCommissionResult = null;
    PreparedStatement pstmtSearchContract = null;
    try
    {
      String strSelectContractQuery = getSQLString("Select",CHMConstants.CONTRACT_SELECTED_SEARCH);
      log.debug("ContractDAX--search query is "+ strSelectContractQuery);
      log.debug("ContractDAX--primary key is " + a_lCommAgrmtSeqNbr);
      if(pstmtSearchContract == null)
      {
        pstmtSearchContract = getPreparedStatement(strSelectContractQuery);
      }
      pstmtSearchContract.setLong(1,a_lCommAgrmtSeqNbr);

      rsSearchContract = executeQuery(pstmtSearchContract);
      log.debug("ContractDAX--Query executed properly");
      oContractResult = new ContractResult();
      oCommissionResult = new CommissionResult();
      if(rsSearchContract.next())
      {
        /* CHANGE TO AVOID UPDATE  */
		oContractResult.setIsDirty(DataConstants.DISPLAY_MODE);
		oContractResult.setCommissionResult(oCommissionResult);
        oContractResult.getCommissionResult().setComAgreementKey(new Long(rsSearchContract.getLong(1)));
        //log.debug(oContractResult.getCommissionResult().getComAgreementKey() + " got key");
        //log.debug(rsSearchContract.getString(2) + " second value");
        oContractResult.setContractNumber(rsSearchContract.getString(2));
        //log.debug(DateUtil.retGregorian(rsSearchContract.getTimestamp(3)));
        oContractResult.setEffectiveDate(DateUtil.retGregorian(rsSearchContract.getTimestamp(3)));
        oContractResult.setContractStatus(new Integer(rsSearchContract.getString(4)));
        oContractResult.getCommissionResult().setProdCd(rsSearchContract.getString(5));
        oContractResult.getCommissionResult().setProdVer(new Integer(rsSearchContract.getInt(6)));
        oContractResult.getCommissionResult().setCommType(new Short(rsSearchContract.getShort(7)));
        oContractResult.getCommissionResult().setCommClass(rsSearchContract.getString(8));
        oContractResult.getCommissionResult().setCampaignCd(rsSearchContract.getString(9));
        //oContractResult.getCommissionResult().setDistribType(rsSearchContract.getString(10));
        oContractResult.getCommissionResult().setBaseUnits(new Integer(rsSearchContract.getInt(10)));
        oContractResult.getCommissionResult().setCommBase((new Short(rsSearchContract.getShort(11))));
        oContractResult.getCommissionResult().setPmtMode((new Short(rsSearchContract.getShort(12))));
        oContractResult.getCommissionResult().setTermType((new Short(rsSearchContract.getShort(13))));
		oContractResult.getCommissionResult().setBaseProdCd(rsSearchContract.getString(14));
		oContractResult.getCommissionResult().setBaseProdVer(new Integer(rsSearchContract.getInt("IBASEPRODVER")));
		oContractResult.getCommissionResult().setBasePlanType(new Short(rsSearchContract.getShort("NBASEPLANTYPE")));
		oContractResult.getCommissionResult().setPlanType(new Short(rsSearchContract.getShort("NPLANTYPE")));
         oContractResult.setTsDtUpdated(rsSearchContract.getTimestamp("dtupdated"));
         oContractResult.getCommissionResult().setCommBandCd(new Short(rsSearchContract.getShort("NCOMMBAND")));
         oContractResult.getCommissionResult().setIndexCommYrType(new Short(rsSearchContract.getShort("NINDXCOMMYEAR")));
         
         //Varun: Added New Columns for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 Start
         oContractResult.getCommissionResult().set_nApplyMultiplier(rsSearchContract.getString("NAPPLYMULTIPLIER"));
         oContractResult.getCommissionResult().set_nCompareMultiplierWith(rsSearchContract.getString("NCOMPAREMULTIPLIERWITH"));
         oContractResult.getCommissionResult().set_nApplyMultiplierOn(rsSearchContract.getString("NAPPLYMULTIPLIERON"));
         oContractResult.getCommissionResult().set_nMultiplierOf(new Float(rsSearchContract.getFloat("NMULTIPLIEROF")));
         oContractResult.getCommissionResult().set_nCommMultiplierDtls(new Float(rsSearchContract.getFloat("NCOMMMULTIPLIERDTLS")));
         
         //new fields added
         oContractResult.getCommissionResult().setnCommMultpWtFlag(rsSearchContract.getString("NFLGCOMMMLTPLRWEGHTG"));
         oContractResult.getCommissionResult().setnCommMultiplierWt(rsSearchContract.getFloat("NCOMMMLTPLRWEGHTG"));
         oContractResult.getCommissionResult().setnCommMultpWtFlagComp(rsSearchContract.getString("NFLGWEGHTGCOMMMLTPLRCOMP"));
         oContractResult.getCommissionResult().setnIfWtCommMultiplier(rsSearchContract.getFloat("NWEGHTGCOMMMLTPLRGRTR"));
         oContractResult.getCommissionResult().setnRedWtCommMultiplierBy(rsSearchContract.getFloat("NRDUCWEGHTGCOMMMLTPLR"));
         oContractResult.getCommissionResult().setnIfWtCommMultiplierLt(rsSearchContract.getFloat("NWEGHTGCOMMMLTPLRLESS"));
         oContractResult.getCommissionResult().setnThenApplyWtOf(rsSearchContract.getFloat("NFURTHERWEGHTG"));
         //Varun: Added New Columns for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 End
        log.debug("ContractDAX--Contract filled");
      }
      log.debug("ContractDAX--Returning Contract Result");
      return oContractResult;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3018");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3018");
    }
    finally
    {
      try
      {
        if(rsSearchContract != null)
          rsSearchContract.close();

        if(pstmtSearchContract != null)
          pstmtSearchContract.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

// **********************************************************************************
//  Code for getting BaseUnit and CommBase

/**
 * getContractBaseUnit gets the BaseUnit and CommBase.
 * @return ContractProdValidate
 * @param a_oContractProdValidate ContractProdValidate
 * @throws EElixirException
 */
public ContractProdValidate getContractBaseUnit(ContractProdValidate a_oContractProdValidate) throws EElixirException
{
  log.debug("ContractDAX--Inside getContractBaseUnit result obj " + a_oContractProdValidate);

  ResultSet rsGetContractBaseUnit = null;
  ContractProdValidate oContractProdValidate = null;
  PreparedStatement pstmtGetContractBaseUnit = null;
  try
  {
    String strSelectContractQuery = getSQLString("Select",CHMConstants.CONTRACT_PRODUCT_COMMTYPE);
    pstmtGetContractBaseUnit = getPreparedStatement(strSelectContractQuery);
    log.debug(a_oContractProdValidate + "");
    pstmtGetContractBaseUnit.setInt(1,a_oContractProdValidate.getCommType().intValue());
    pstmtGetContractBaseUnit.setString(2,a_oContractProdValidate.getProdCd());
    if(a_oContractProdValidate.getProdVer() == null){
      pstmtGetContractBaseUnit.setInt(3,java.sql.Types.INTEGER);
    }
    else{
      pstmtGetContractBaseUnit.setInt(3,a_oContractProdValidate.getProdVer().intValue());
    }

    rsGetContractBaseUnit = executeQuery(pstmtGetContractBaseUnit);
    log.debug("ContractDAX--Query executed properly");
    oContractProdValidate = new ContractProdValidate();
    if(rsGetContractBaseUnit.next())
    {

      oContractProdValidate.setBaseUnits(new Integer(rsGetContractBaseUnit.getInt(1)));
      oContractProdValidate.setCommBase(new Short(rsGetContractBaseUnit.getShort(2)));

     log.debug("ContractDAX--Comm base, Base unit filled");
    }
    log.debug("ContractDAX--Returning Contract Result");
    return oContractProdValidate;
  }
  catch(SQLException sqlex){
    log.exception(sqlex.getMessage());
    //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3018");
  }
  catch(EElixirException eex)
  {
    log.exception(eex.getMessage());
    throw new EElixirException(eex,"P3018");
  }
  finally
  {
    try
    {
      if(rsGetContractBaseUnit != null)
        rsGetContractBaseUnit.close();

      if(pstmtGetContractBaseUnit != null)
        pstmtGetContractBaseUnit.close();
    }
    catch(SQLException sqlex)
    {
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
    }
  }
}


// *********************************************************************************





  /**
   * Description getSQLString takes querytype and key and returns query
   * @return query string
   * @param a_strSQLType SQL Type i.e Select , Insert , Delete , Update
   * @param a_strKey String
   * @throws EElixirException
   */
  private String getSQLString(String a_strSQLType,String a_strKey) throws EElixirException
  {
    SqlRepositoryIF sqlRFIF = null;
    String strSql = "";
    try
    {
      sqlRFIF = CHMSqlRepository.getSqlRepository();
      strSql=sqlRFIF.getSQLString(a_strKey,a_strSQLType);
    }
    catch(EElixirException eex)
    {
      log.debug("ContractDAX--sql ex"+ eex);
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3019");
    }
    return strSql;
  }

  /**
   * Inserts a new record
   * @param a_oContractResult ContractResult
   * @return long Returns the next seq no generated on Contract table
   * @throws EElixirException
   */
  public long createCommissionContract(ContractResult a_oContractResult) throws EElixirException
  {
    PreparedStatement pstmtCreateContract = null;
    ResultSet rsCreateContract = null;
    long lComAgreementKey;

    try
    {
      String strContractNumber = a_oContractResult.getContractNumber().toUpperCase();
      GregorianCalendar dtEffectiveDate  = a_oContractResult.getEffectiveDate();
      Integer oiContractStatus = a_oContractResult.getContractStatus();

	  // amit added 11/1/2002
	  String strCreatedBy = a_oContractResult.getUserId();

	  CommissionResult oCommissionResult = a_oContractResult.getCommissionResult();
      Short nCommBase = oCommissionResult.getCommBase();
      Short nPmtMode = oCommissionResult.getPmtMode();
      Short nTermType = oCommissionResult.getTermType();
      Short nCommType = oCommissionResult.getCommType();
      Short nCommBandCd = oCommissionResult.getCommBandCd();//Arun_RatchetedComm_Rel8.3_Phase2
      String strCommClass = oCommissionResult.getCommClass();
      String strProdCd = oCommissionResult.getProdCd();
	  String strBaseProdCd = oCommissionResult.getBaseProdCd();
      Integer oiProdVer = oCommissionResult.getProdVer();
      String strCampaignCd = oCommissionResult.getCampaignCd();
      Integer oiBaseUnits = oCommissionResult.getBaseUnits();
      Integer iBaseProdVer	= oCommissionResult.getBaseProdVer();
      Short nIndexCommYrType = oCommissionResult.getIndexCommYrType();
      
	  //Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 Start
      String nApplyMultiplier = oCommissionResult.get_nApplyMultiplier();
      String nApplyMultiplierOn = oCommissionResult.get_nApplyMultiplierOn();
      String nCompareMultiplierWith = oCommissionResult.get_nCompareMultiplierWith();
      Float nCommMultiplierDtls = oCommissionResult.get_nCommMultiplierDtls();
      Float nMultiplierOf = oCommissionResult.get_nMultiplierOf();  
      
      //new fields added
		String strCommMultpWtFlag = oCommissionResult.getnCommMultpWtFlag();
		Float strCommMultiplierWtPerc = oCommissionResult.getnCommMultiplierWt();
		String strCommMultpWtFlagComp = oCommissionResult.getnCommMultpWtFlagComp();
		Float strIfWtCommMultiplier = oCommissionResult.getnIfWtCommMultiplier();
		Float strRedWtCommMultiplierBy = oCommissionResult.getnRedWtCommMultiplierBy();
		Float strIfWtCommMultiplierLt  = oCommissionResult.getnIfWtCommMultiplierLt();
		Float strThenApplyWtOf = oCommissionResult.getnThenApplyWtOf();
	  //Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 End


        /**
       * Checks if the new contract number is already present. If not then insert the
       * Contract. If contract already exist then check if effdate and contract no is same,
       * if different then throw exception
       */
      log.debug("ContractDAX-- Execution for contract present start");
      String strContractPresentQuery = getSQLString("Select",CHMConstants.CONTRACT_PRESENT);
      log.debug(strContractPresentQuery);
      pstmtCreateContract = getPreparedStatement(strContractPresentQuery);
      pstmtCreateContract.setString(1,strContractNumber);
      rsCreateContract = executeQuery(pstmtCreateContract);
      log.debug("ContractDAX-- Execution for contract present complete");

      if(rsCreateContract.next())
      {
        String stCheckContractNumber = rsCreateContract.getString(1);
        GregorianCalendar gcCheckEffectiveDate = DateUtil.retGregorian(rsCreateContract.getTimestamp(2));
        int nStatus = rsCreateContract.getInt(3);
        log.debug(gcCheckEffectiveDate.get(gcCheckEffectiveDate.DATE) + "");
        log.debug(gcCheckEffectiveDate.get(gcCheckEffectiveDate.MONTH) + "");
        log.debug(gcCheckEffectiveDate.get(gcCheckEffectiveDate.YEAR) + "");
        log.debug(dtEffectiveDate.get(dtEffectiveDate.DATE) + "");
        log.debug(dtEffectiveDate.get(dtEffectiveDate.MONTH) + "");
        log.debug(dtEffectiveDate.get(dtEffectiveDate.YEAR) + "");
        if( !((gcCheckEffectiveDate.get(gcCheckEffectiveDate.DATE) == dtEffectiveDate.get(dtEffectiveDate.DATE)) &&
            (gcCheckEffectiveDate.get(gcCheckEffectiveDate.MONTH) == dtEffectiveDate.get(dtEffectiveDate.MONTH)) &&
            (gcCheckEffectiveDate.get(gcCheckEffectiveDate.YEAR) == dtEffectiveDate.get(dtEffectiveDate.YEAR))) ){
          throw new EElixirException("P3028");
        }
        if (nStatus != DataConstants.STATUS_PENDING_ID)
        {
	      throw new EElixirException("P3028");  //this contract is either aproved or rejected
        }
      }

      //String strDistribType = oCommissionResult.getDistribType();
      // Before inserting a new record this function generates a new Seq no, on which the
      // new record is inserted.
      lComAgreementKey = getNextComAgreementKey();
      log.debug("ContractDAX--------------the dax created newkey----"+ lComAgreementKey);

      String strCreateContractQuery = getSQLString("Insert",CHMConstants.CONTRACT_CREATE);
      /*
      log.debug("ContractDAX--\nContract Number >>"+strContractNumber + "<<");
      log.debug("ContractDAX--\nEffective Date >>"+dtEffectiveDate + "<<");
      log.debug("ContractDAX--\nContract Status >>"+oiContractStatus + "<<");
      log.debug("ContractDAX--\nCommission base >>"+strCommBase + "<<");
      log.debug("ContractDAX--\nCommission Type >>"+strCommType + "<<");
      log.debug("ContractDAX--\nCommission Class >>"+strCommClass + "<<");
      log.debug("ContractDAX--\nProduct Code >>"+strProdCd + "<<");
      log.debug("ContractDAX--\nProduct Version >>"+oiProdVer + "<<");
      log.debug("ContractDAX--\nMedical Group >>"+strCampaignCd + "<<");
      log.debug("ContractDAX--\nBase Unit >>"+oiBaseUnits + "<<");
      log.debug("ContractDAX--\nDistrib Type >>"+strDistribType + "<<");
      log.debug("ContractDAX--\nKey >>"+lComAgreementKey + "<<");
      */

      log.debug("ContractDAX--Strquery =" + strCreateContractQuery);
      pstmtCreateContract = getPreparedStatement(strCreateContractQuery);


      log.debug ("lComAgreementKey =" + lComAgreementKey);
	  pstmtCreateContract.setLong(1,lComAgreementKey);

      log.debug ("strContractNumber =" + strContractNumber);
	  pstmtCreateContract.setString(2,strContractNumber.trim().toUpperCase());

      log.debug ("dtEffectiveDate =" + dtEffectiveDate);
      pstmtCreateContract.setTimestamp(3,DateUtil.retTimestamp(dtEffectiveDate));

      log.debug ("oiContractStatus =" + oiContractStatus);
	  pstmtCreateContract.setInt(4,oiContractStatus.intValue());

	  log.debug ("nCommBase =" + nCommBase);
      pstmtCreateContract.setInt(5,nCommBase.intValue());

	  log.debug ("nCommType =" + nCommType);
      pstmtCreateContract.setInt(6,nCommType.intValue());

	  log.debug ("strCommClass =" + strCommClass);
      pstmtCreateContract.setString(7,strCommClass);

	  log.debug ("strProdCd =" + strProdCd);
      pstmtCreateContract.setString(8,strProdCd.trim().toUpperCase());

	  log.debug ("strBaseProdCd =" + strBaseProdCd);
	  //pstmtCreateContract.setString(9,strBaseProdCd.trim().toUpperCase());
  	  if(strBaseProdCd == null || strBaseProdCd.trim().equals("")){
	      pstmtCreateContract.setNull(9,java.sql.Types.VARCHAR);
	  }
	  else{
	      pstmtCreateContract.setString(9,strBaseProdCd);
	  }

      log.debug("ContractDAX--After setting few values");
      //java.sql.Types.INTEGER
      if(oiProdVer == null){
        pstmtCreateContract.setNull(10,java.sql.Types.INTEGER);
      }
      else{
        pstmtCreateContract.setInt(10,oiProdVer.intValue());
      }
      log.debug("ContractDAX--After setting few values1");
  	  if(strCampaignCd == null || strCampaignCd.trim().equals("")){
	      pstmtCreateContract.setNull(11,java.sql.Types.VARCHAR);
	  }
	  else{
	      pstmtCreateContract.setString(11,strCampaignCd);
	  }
      log.debug("ContractDAX--After setting few values2");
      pstmtCreateContract.setInt(12,oiBaseUnits.intValue());
      log.debug("ContractDAX--After setting few values3");
      pstmtCreateContract.setTimestamp(13,DateUtil.retTimestamp(DateUtil.retGCDate(DataConstants.MAX_DATE_LIMIT)));
      pstmtCreateContract.setInt(14,nPmtMode.shortValue());
      pstmtCreateContract.setInt(15,nTermType.shortValue());
	  // added amit 11/1/2002
	  pstmtCreateContract.setString(16,strCreatedBy);

	  if (iBaseProdVer != null)
	  {
	 	pstmtCreateContract.setInt(17,iBaseProdVer.intValue());
	  }
	  else
	  {
		  pstmtCreateContract.setNull(17,java.sql.Types.INTEGER);
	  }
	  //Arun_RatchetedComm_Rel8.3_Phase2_Start  
	  log.debug ("nCommBandCd =" + nCommBandCd);
	  if (iBaseProdVer != null)
	  {		 
	    pstmtCreateContract.setInt(18,nCommBandCd.intValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(18,java.sql.Types.INTEGER);
	  }
	  
	  //Arun_RatchetedComm_Rel8.3_Phase2_end
	  //Anup_Indexation_Changes_Jan_Release_v1.2_Starts
	  log.debug ("nIndexCommYrType =" + nIndexCommYrType);
	  if (nIndexCommYrType != null)
	  {		 
	    pstmtCreateContract.setShort(19,nIndexCommYrType.shortValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(19,java.sql.Types.INTEGER);
	  }
	  
	  //Anup_Indexation_Changes_Jan_Release_v1.2_Ends
	  
	  //Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 Start	  
	  if (nApplyMultiplier != null && !nApplyMultiplier.trim().equals(""))
	  {		 
	    pstmtCreateContract.setShort(20,Short.valueOf(nApplyMultiplier));
	  }
	  else
	  {
		pstmtCreateContract.setNull(20,java.sql.Types.SMALLINT);
	  }
	  if (nCompareMultiplierWith != null && !nCompareMultiplierWith.trim().equals(""))
	  {		 
	    pstmtCreateContract.setShort(21,Short.valueOf(nCompareMultiplierWith));
	  }
	  else
	  {
		pstmtCreateContract.setNull(21,java.sql.Types.SMALLINT);
	  }
	  if (nApplyMultiplierOn != null && !nApplyMultiplierOn.trim().equals(""))
	  {		 
	    pstmtCreateContract.setShort(22,Short.valueOf(nApplyMultiplierOn));
	  }
	  else
	  {
		pstmtCreateContract.setNull(22,java.sql.Types.SMALLINT);
	  }
	  if (nMultiplierOf != null)
	  {		 
	    pstmtCreateContract.setFloat(23,nMultiplierOf.floatValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(23,java.sql.Types.SMALLINT);
	  }
	  if (nCommMultiplierDtls != null)
	  {		 
	    pstmtCreateContract.setFloat(24,nCommMultiplierDtls.floatValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(24,java.sql.Types.SMALLINT);
	  }
	  
	  //new fields added
	  if (strCommMultpWtFlag != null && !"".equals(strCommMultpWtFlag.trim()))
	  {		 
	    pstmtCreateContract.setShort(25,Short.valueOf(strCommMultpWtFlag));
	  }
	  else
	  {
		pstmtCreateContract.setNull(25,java.sql.Types.SMALLINT);
	  }
	  
	  if (strCommMultiplierWtPerc != null)
	  {		 
	    pstmtCreateContract.setFloat(26,strCommMultiplierWtPerc.floatValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(26,java.sql.Types.SMALLINT);
	  }
	  
	  if (strCommMultpWtFlagComp != null && !"".equals(strCommMultpWtFlagComp.trim()))
	  {		 
	    pstmtCreateContract.setShort(27,Short.valueOf(strCommMultpWtFlagComp));
	  }
	  else
	  {
		pstmtCreateContract.setNull(27,java.sql.Types.SMALLINT);
	  }
	  if (strIfWtCommMultiplier != null)
	  {		 
	    pstmtCreateContract.setFloat(28,strIfWtCommMultiplier.floatValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(28,java.sql.Types.SMALLINT);
	  }
	  if (strRedWtCommMultiplierBy != null)
	  {		 
	    pstmtCreateContract.setFloat(29,strRedWtCommMultiplierBy.floatValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(29,java.sql.Types.SMALLINT);
	  }
	  if (strIfWtCommMultiplierLt != null)
	  {		 
	    pstmtCreateContract.setFloat(30,strIfWtCommMultiplierLt.floatValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(30,java.sql.Types.SMALLINT);
	  }
	  if (strThenApplyWtOf != null)
	  {		 
	    pstmtCreateContract.setFloat(31,strThenApplyWtOf.floatValue());
	  }
	  else
	  {
		pstmtCreateContract.setNull(31,java.sql.Types.SMALLINT);
	  }
	  
	  
	  //Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 End

	  log.debug("ContractDAX--After setting all values");
      //pstmtCreateContract.setString(12,strDistribType.trim().toUpperCase());


	  int icount = executeUpdate(pstmtCreateContract);
      log.debug("ContractDAX--" + icount);
      log.debug("ContractDAX--------------the dax created newkey----"+ lComAgreementKey);

      //INSERT INTO CHM_TRANS_STATUS TABLE
      log.debug("ContractDAX--BEFORE APPROVAL ENTRY");
      insertTransactionForApproval(lComAgreementKey,strCreatedBy);
      log.debug("ContractDAX--AFTER APPROVAL ENTRY");

      return lComAgreementKey;

    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw eex;
    }
    finally
    {
      try
      {
        if(pstmtCreateContract != null)
          pstmtCreateContract.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }


  /**
   * This function generates a new Seq no, on which the
   * new record is inserted.
   * @return long Returns the next seq no generated on Contract table
   * @throws EElixirException
   */
  protected long getNextComAgreementKey() throws EElixirException{
    Statement stmtNextSeqContract = null;
    long lSeqNo;
    try
    {
      String strNextSeqQuery = getSQLString("Select",CHMConstants.CONTRACT_SEQNO);

      stmtNextSeqContract = getStatement();
      ResultSet rsSeqNo = stmtNextSeqContract.executeQuery(strNextSeqQuery);
      rsSeqNo.next();
      lSeqNo = rsSeqNo.getLong(1);
      log.debug(lSeqNo + "");
      return lSeqNo;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3021");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3021");
    }
    finally
    {
      try
      {
        if(stmtNextSeqContract != null)
          stmtNextSeqContract.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }


  /**
   * Removes the selected Contract
   * @return int No of rows removed
   * @param: a_lCommAgrmtSeqNbr long
   * @throws EElixirException
   */
  public int removeContract(long a_lCommAgrmtSeqNbr) throws EElixirException
  {
    PreparedStatement pstmtRemoveContract = null;
    try
    {
      log.debug("ContractDAX-- Inside remove Contract");
      String strRemoveQuery = getSQLString("Delete",CHMConstants.CONTRACT_DELETE);
      pstmtRemoveContract = getPreparedStatement(strRemoveQuery);
      pstmtRemoveContract.setLong(1,a_lCommAgrmtSeqNbr);
      int iRemoveStandardCommission = executeUpdate(pstmtRemoveContract);
      return iRemoveStandardCommission;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3022");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3022");
    }
    finally
    {
      try
      {

        if(pstmtRemoveContract != null)
          pstmtRemoveContract.close();

      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }

  }

// ****************************************************************************
// Copy Contract Functionality,
/**
 * copyContract inserts a new record depending on the previous one.
 * On a particular contract No it fetches all the sequence No.
 * For every sequence no it generates new sequence no and
 * inserts a new record into Contract table.  For every Contract inserted
 * it copies a new Commission into table.
 * @param a_oContractCopyResult ContractCopyResult
 * @throws EElixirException
 */
public void copyContract(ContractCopyResult a_oContractCopyResult) throws EElixirException
{
  log.debug("ContractDAX-- INside Copy COntract Method");
  ResultSet rsCopyContract = null;
  PreparedStatement pstmtCopyContract = null;
  ArrayList arrSeq = new ArrayList(10);// currently set to 10 just as default capacity
  try
  {
    // contract no to be on new
    String strContractNumber = a_oContractCopyResult.getContractNumber().trim().toUpperCase();
      log.debug("ContractDAX--strContractNumber:" + strContractNumber);
    GregorianCalendar dtEffectiveDate  = a_oContractCopyResult.getEffectiveDate();
      log.debug("ContractDAX--dtEffectiveDate:" + dtEffectiveDate);
    String strApprovedContractNumber = a_oContractCopyResult.getApprovedContractNumber().trim();
      log.debug("ContractDAX--strApprovedContractNumber:" + strApprovedContractNumber);
    int iYesNo        = Integer.parseInt(a_oContractCopyResult.getYesNo().trim());
      log.debug("ContractDAX--iYesNo:" + iYesNo);

	String strCreatedBy = a_oContractCopyResult.getUserId();

	String strReplacementContractNumber = "";
    if(iYesNo == DataConstants.YES){
      strReplacementContractNumber = strApprovedContractNumber;
    }
      log.debug("ContractDAX-- After getting parameter Method");


      /**
       * Checks if the old contract number is having a ref contract no and is not rejected.
       * If it already has a ref no then cannot copy that contract to new contract.
       */
      String strContractNotRejectedQuery = getSQLString("Select",CHMConstants.CONTRACT_NOT_REJECTED);
      pstmtCopyContract = getPreparedStatement(strContractNotRejectedQuery);
      pstmtCopyContract.setString(1,strApprovedContractNumber);
      rsCopyContract = executeQuery(pstmtCopyContract);
      log.debug("ContractDAX-- Execution for contract not rejected complete");
      if(rsCopyContract.next())
      {
        throw new EElixirException("P3038");
      }


    /**
     * Checks if the new contract number is already present. If not then only copy of
     * that contract is done.
     */
    String strContractPresentQuery = getSQLString("Select",CHMConstants.CONTRACT_PRESENT);
    pstmtCopyContract = getPreparedStatement(strContractPresentQuery);
    pstmtCopyContract.setString(1,strContractNumber);
    rsCopyContract = executeQuery(pstmtCopyContract);
    log.debug("ContractDAX-- Execution for contract present complete");
    if(rsCopyContract.next())
    {
      throw new EElixirException("P3028");
    }

    /**
     * Finds all the contract number for the given approved Contract Number which has to be
     * copied to new one.
     */
    String strCopyContractQuery = getSQLString("Select",CHMConstants.CONTRACT_SEQUENCES);
    pstmtCopyContract = getPreparedStatement(strCopyContractQuery);
    pstmtCopyContract.setString(1,strApprovedContractNumber);

    rsCopyContract = executeQuery(pstmtCopyContract);
    log.debug("ContractDAX-- Execution for contract sequences complete");
    int icount = 0;
    while(rsCopyContract.next())
    {
      icount++;
       arrSeq.add(new Long(rsCopyContract.getLong(1)));
       log.debug("ContractDAX--seqnos:" + rsCopyContract.getLong(1));
    }

    log.debug("ContractDAX-- Array list filled" + icount);
    //Long[] larrSeq = (Long[])arrSeq.toArray();
    log.debug("ContractDAX-- Long array filled:" + arrSeq);
    icount = 0;
    for(int i=0; i<arrSeq.size(); i++){
      long lNextSeqNo = getNextComAgreementKey();
      log.debug("ContractDAX--new Seq No" + lNextSeqNo);
      /**
       * Gets the first Contract and copies to new one
       */
      log.debug("ContractDAX--First array element of seqno" + ((Long)arrSeq.get(i)).longValue());
      String strCopyContractInsert = getSQLString("Insert",CHMConstants.CONTRACT_COPY_INSERT);
      pstmtCopyContract = getPreparedStatement(strCopyContractInsert);
      pstmtCopyContract.setLong(1,lNextSeqNo);
      pstmtCopyContract.setString(2,strContractNumber);
      pstmtCopyContract.setTimestamp(3,DateUtil.retTimestamp(dtEffectiveDate));
      pstmtCopyContract.setString(4,strReplacementContractNumber);
      pstmtCopyContract.setString(5,strCreatedBy);
      pstmtCopyContract.setString(6,strApprovedContractNumber);
      pstmtCopyContract.setLong(7,((Long)arrSeq.get(i)).longValue());

      //pstmtCopyContract.setLong(6,larrSeq[i].longValue());

      icount = executeUpdate(pstmtCopyContract);
      log.debug("ContractDAX--icount of Contract" + icount);

      //INSERT INTO CHM_TRANS_STATUS TABLE
      insertTransactionForApproval(lNextSeqNo,strCreatedBy);

      // Copying Standard Commission If Present
      String strCopyCommissionSCInsert = getSQLString("Insert",CHMConstants.STANDARD_COMMISSION_COPY_INSERT);
      pstmtCopyContract = getPreparedStatement(strCopyCommissionSCInsert);
      pstmtCopyContract.setLong(1,lNextSeqNo);
      pstmtCopyContract.setString(2,strCreatedBy);
      pstmtCopyContract.setLong(3,((Long)arrSeq.get(i)).longValue());
      icount = executeUpdate(pstmtCopyContract);
      log.debug("ContractDAX--icount of Standard/Trail" + icount);
      //this is a call to the procedure for copying of Overriding commission
	  /* currently commented since Overriding commission is not a part of this functionality
       int output = copyOverridingCommission(lNextSeqNo,strCreatedBy,((Long)arrSeq.get(i)).longValue());
        if(output != 0){
          throw new EElixirException("P3028");
        }
		*/
      // Copying ClawBack Commission If Present
      String strCopyCommissionClawInsert = getSQLString("Insert",CHMConstants.CLAWBACK_COMMISSION_COPY_INSERT);
      pstmtCopyContract = getPreparedStatement(strCopyCommissionClawInsert);
      pstmtCopyContract.setLong(1,lNextSeqNo);
      pstmtCopyContract.setString(2,strCreatedBy);
      pstmtCopyContract.setLong(3,((Long)arrSeq.get(i)).longValue());

      icount = executeUpdate(pstmtCopyContract);
      log.debug("ContractDAX--icount of ClawBack" + icount);
    }
  }
  catch(SQLException sqlex){
    log.exception(sqlex.getMessage());
    throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
  }
  catch(EElixirException eex)
  {
    log.exception(eex.getMessage());
    throw eex;
  }
  finally
  {
    try
    {
      if(rsCopyContract != null)
        rsCopyContract.close();

      if(pstmtCopyContract != null)
        pstmtCopyContract.close();
    }
    catch(SQLException sqlex)
    {
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
    }
  }
  }
 /**
   * copyOverridingCommission inserts a new record depending on the previous one.
   * On a particular contract No it fetches all the sequence No.
   * For every sequence no it generates new sequence no and
   * inserts a new record into Overriding table and Overriding Commission rate table.
   * For every Overriding commission inserted it copies a new Overriding Commission into table.
   * @param lNextSeqNo long
   * @param strCreatedBy String
   * @param lSeqNo long
   * @return int
   * @throws EElixirException
   */
  public int copyOverridingCommission(long lNextSeqNo,String strCreatedBy,long lSeqNo) throws EElixirException{

    CallableStatement stmt = null;
    ResultSet rs = null;
    String strSQL = null;
    int iRetVal=-1;
    try
    {
      strSQL = getSQLString("Insert",CHMConstants.OVERRIDING_COMMISSION_COPY_INSERT );
      log.debug("ContractDAX-- inside stored procedure" + strSQL);
      stmt = getCallableStatement(strSQL);
      /**todo : set the stored proc parameters here*/
          /*register for the return value*/
      stmt.setLong(1,lSeqNo);
      stmt.setLong(2,lNextSeqNo);
      stmt.setString(3,strCreatedBy);
      stmt.registerOutParameter(4, java.sql.Types.INTEGER);
          /*register for the input parameter */
      stmt.registerOutParameter(5,java.sql.Types.INTEGER);
          /*register for the o/p parameter of error*/
      stmt.registerOutParameter(6, java.sql.Types.VARCHAR);
          /*execute the proc*/
      stmt.execute();
          /*get the return value*/
      iRetVal = stmt.getInt(5);
      log.debug("stmt.getInt(4)" + stmt.getInt(4));
      log.debug("stmt.getInt(5)" + stmt.getInt(5));
      log.debug("stmt.getInt(6)" + stmt.getString(6));
    }
    catch (SQLException sqlex)
    {
      log.fatal("ContractDAX-- Error"+ sqlex );
      throw new EElixirException(sqlex + "");
    }
    return iRetVal;
  }
// Copy Contract Functionality ends
// ****************************************************************************





//Added by Vinay

/**
 * Searches for contract .
 * @return String
 * @throws EElixirException
 */

public String getContract() throws EElixirException
{
PreparedStatement pstmtSearchContract= null;
Statement st = null ;
StringBuffer sb = new StringBuffer();


try
{


 log.debug("ContractDAX--before getsqlstring");
  String strSearchContractQuery = getSQLString("Select",CHMConstants.CONTRACT);

  log.debug(strSearchContractQuery);
  pstmtSearchContract = getPreparedStatement(strSearchContractQuery);
  pstmtSearchContract.setInt(1,DataConstants.STATUS_APPROVED_ID);
  pstmtSearchContract.setInt(2, DataConstants.COMMON_STATUS);
   ResultSet rsSearch = executeQuery(pstmtSearchContract);

        log.debug("ContractDAX--before returnin");
 return XMLConverter.getXMLString(rsSearch);
}

 catch(SQLException sqlex)
{
 log.exception(sqlex.getMessage());
 throw new EElixirException("P3024");
}
finally
{
try
  {
    if(pstmtSearchContract != null)
       pstmtSearchContract.close();
  }
catch(SQLException sqlex)
 {
  log.exception(sqlex.getMessage());
  throw new EElixirException("P3024");
 }
}

}



//code for selfcontract

 /**
   * Description Depending on SEarchData returns Arraylist of SelfContract
   * @return ArrayList
   * @param a_oSearchData SearchData
   * @throws EElixirException
   */
public ArrayList getSelfContract( SearchData a_oSearchData) throws EElixirException
 {
   ResultSet rsSearchSelfContract = null;
   PreparedStatement _pstmtFindPrimaryKey = null;
   ArrayList _oSelfContractList = new ArrayList();
   SelfContractResult _oSelfContractResult = null;
   String strSelectSelfContractQuery = null;
   try
   {
     log.debug("ContractDAX--in getSelfContract of ejb ");
     if(a_oSearchData.getTask1() != null && !(a_oSearchData.getTask1().trim().equals("")))
     {
       log.debug("ContractDAX--PolNbr not null and not space");
       strSelectSelfContractQuery = getSQLString("Select",CHMConstants.FIND_SELFCONTRACT_BY_PRIMARYKEY_1);
       log.debug(strSelectSelfContractQuery);
     }
     else
     {
       log.debug("ContractDAX--PolNbr null and space");
       strSelectSelfContractQuery = getSQLString("Select",CHMConstants.FIND_SELFCONTRACT_BY_PRIMARYKEY_2);
       log.debug(strSelectSelfContractQuery);
     }
     log.debug(strSelectSelfContractQuery);
     if(_pstmtFindPrimaryKey == null)
     {
       _pstmtFindPrimaryKey = getPreparedStatement(strSelectSelfContractQuery);
     }
     log.debug(_pstmtFindPrimaryKey + "");
     if(a_oSearchData.getTask1() != null && !(a_oSearchData.getTask1().trim().equals("")))
     {
       log.debug("ContractDAX--In if" + a_oSearchData.getTask1().trim() + ":::>>>" + a_oSearchData.getTask2().trim());
       _pstmtFindPrimaryKey.setString(1, a_oSearchData.getTask1().trim().toUpperCase());
       _pstmtFindPrimaryKey.setString(2, a_oSearchData.getTask2().trim().toUpperCase());
       _pstmtFindPrimaryKey.setInt(3, DataConstants.CLIENT_TYPE_PROPOSER);
       _pstmtFindPrimaryKey.setInt(4, DataConstants.POLICY_STATUS);
     }
     else
     {
       log.debug("ContractDAX--In else"  + ":::>>>" + a_oSearchData.getTask2().trim());
       _pstmtFindPrimaryKey.setString(1, a_oSearchData.getTask2().trim().toUpperCase());
       _pstmtFindPrimaryKey.setInt(2, DataConstants.CLIENT_TYPE_PROPOSER);
       _pstmtFindPrimaryKey.setInt(3, DataConstants.POLICY_STATUS);
     }


     rsSearchSelfContract = executeQuery(_pstmtFindPrimaryKey);
     while(rsSearchSelfContract.next())
     {
       log.debug("ContractDAX--in while");
       _oSelfContractResult = new SelfContractResult();
       log.debug(rsSearchSelfContract.getString(1));
       _oSelfContractResult.setPolNbr(rsSearchSelfContract.getString(1));
       log.debug(rsSearchSelfContract.getString(2));
       _oSelfContractResult.setPolIssue(DateUtil.retGregorian(rsSearchSelfContract.getTimestamp(2)));
//       _oContractMap.set_dtEffTo(DateUtil.retGregorian(rsSearchContractMap.getTimestamp(7)));
       log.debug(rsSearchSelfContract.getString(3));
       _oSelfContractResult.setPolicyHolderName(rsSearchSelfContract.getString(3));
       log.debug(rsSearchSelfContract.getString(4));
       _oSelfContractResult.setTerm( new Short(rsSearchSelfContract.getShort(4)) );
       log.debug(rsSearchSelfContract.getString(5));
       _oSelfContractResult.setSa(new Double(rsSearchSelfContract.getDouble(5)));
       log.debug(rsSearchSelfContract.getString(6));
       _oSelfContractResult.setPrmAmnt(new Double( rsSearchSelfContract.getDouble(6)));
       log.debug(rsSearchSelfContract.getString(7));
       _oSelfContractResult.setStatus(rsSearchSelfContract.getString(7));
       log.debug(rsSearchSelfContract.getString(8));
       _oSelfContractResult.setSelfContIndcr(new Short( rsSearchSelfContract.getShort(8)));
       log.debug(DataConstants.DISPLAY_MODE);
       _oSelfContractResult.setStatusFlag(DataConstants.DISPLAY_MODE);
       _oSelfContractResult.setTsDtUpdated(rsSearchSelfContract.getTimestamp("dtupdated"));
       log.debug("ContractDAX--before addibng while");
       _oSelfContractList.add(_oSelfContractResult);
     }
     log.debug("ContractDAX--before returning");
     return _oSelfContractList;
   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     throw new EElixirException(sqlex, "P3039");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P3039");
   }
   finally
   {
     try
     {

       if(_pstmtFindPrimaryKey != null)
         _pstmtFindPrimaryKey.close();

     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3039");
     }
   }

 }

 /**
   * Description Depending on SEarchData returns boolean
   * @return boolean
   * @param a_strPolNbr String
   * @param a_strServAgentCd String
   * @throws EElixirException
   */
 public boolean searchSelfContract( String a_strPolNbr, String a_strServAgentCd) throws EElixirException
  {
    ResultSet rsSearchSelfContract = null;
    PreparedStatement _pstmtFindPrimaryKey = null;
    String strSelectSelfContractQuery = null;
    try
    {
      log.debug("ContractDAX--in getSelfContract of ejb ");
        strSelectSelfContractQuery = getSQLString("Select",CHMConstants.FIND_SELFCONTRACT_BY_PRIMARYKEY_1);
      log.debug(strSelectSelfContractQuery);
      if(_pstmtFindPrimaryKey == null)
      {
        _pstmtFindPrimaryKey = getPreparedStatement(strSelectSelfContractQuery);
      }
      log.debug(_pstmtFindPrimaryKey + "");

        _pstmtFindPrimaryKey.setString(1, a_strPolNbr.toUpperCase());
        _pstmtFindPrimaryKey.setString(2, a_strServAgentCd.toUpperCase());
        _pstmtFindPrimaryKey.setInt(3, DataConstants.CLIENT_TYPE_PROPOSER);
       _pstmtFindPrimaryKey.setInt(4, DataConstants.POLICY_STATUS);



      rsSearchSelfContract = executeQuery(_pstmtFindPrimaryKey);
      if(rsSearchSelfContract.next())
      {
        return true;
      }
      return false;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, "P3039");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3039");
    }
    finally
    {
      try
      {

        if(_pstmtFindPrimaryKey != null)
          _pstmtFindPrimaryKey.close();

      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, "P3039");
      }
    }

  }
 /**
   * Description Updates selfContract
   * @param oSelfContractResult SelfContractResult
   * @throws EElixirException
   */
  public void updateSelfContract(SelfContractResult oSelfContractResult) throws EElixirException
  {
    PreparedStatement _pstmtSelfContract = null;
    try
    {

      String strUpdateSelfContract  = getSQLString("Update",CHMConstants.SELFCONTRACT_UPDATE);
      _pstmtSelfContract = getPreparedStatement(strUpdateSelfContract);

     _pstmtSelfContract.setShort(1, oSelfContractResult.getSelfContIndcr().shortValue());
     _pstmtSelfContract.setString(2, oSelfContractResult.getUserId());
     _pstmtSelfContract.setString(3, oSelfContractResult.getPolNbr().toUpperCase());
     _pstmtSelfContract.setString(4, oSelfContractResult.getServAgentCd().toUpperCase());

      executeUpdate(_pstmtSelfContract);
      log.debug("ContractDAX--query executed properly");


    }
    catch(SQLException sqlex){
      log.debug("ContractDAX--Error while updating selfContract------- DAX---SQL");
      sqlex.printStackTrace();
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex,"Error while updating selfContract", "P3040");
    }
    catch(EElixirException eex)
    {
      log.debug("ContractDAX--Error while update selfContract-------- DAX--- EE");
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3040");
    }
    finally
    {
      try
      {

        if(_pstmtSelfContract != null)
          _pstmtSelfContract.close();

      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, "P3040");
      }
    }
  }



//code for clawback
 /**
   * Description Depending on SEarchData returns Arraylist of SelfContract
   * @return ArrayList
   * @param a_oSearchData SearchData
   * @throws EElixirException
   */
public ArrayList getClawback( SearchData a_oSearchData) throws EElixirException
 {
   ResultSet rsSearchClawback = null;
   PreparedStatement _pstmtFindPrimaryKey = null;
   ArrayList _oClawbackList = new ArrayList();
   ClawbackResult _oClawbackResult = null;
   String strSelectClawbackQuery = null;
   try
   {
     log.debug("ContractDAX--in getClawback of ejb ");
     if(a_oSearchData.getTask1() != null && !(a_oSearchData.getTask1().trim().equals("")))
     {
       log.debug("ContractDAX--PolNbr not null and not space");
       strSelectClawbackQuery = getSQLString("Select",CHMConstants.FIND_CLAWBACK_BY_PRIMARYKEY_1);
       log.debug(strSelectClawbackQuery);
     }
     else
     {
       log.debug("ContractDAX--PolNbr null and space");
       strSelectClawbackQuery = getSQLString("Select",CHMConstants.FIND_CLAWBACK_BY_PRIMARYKEY_2);
       log.debug(strSelectClawbackQuery);
     }
     log.debug(strSelectClawbackQuery);
     if(_pstmtFindPrimaryKey == null)
     {
       _pstmtFindPrimaryKey = getPreparedStatement(strSelectClawbackQuery);
     }
     log.debug(_pstmtFindPrimaryKey + "");
     if(a_oSearchData.getTask1() != null && !(a_oSearchData.getTask1().trim().equals("")))
     {
       log.debug("ContractDAX--In if" + a_oSearchData.getTask1().trim() + ":::>>>" + a_oSearchData.getTask2().trim());
       _pstmtFindPrimaryKey.setString(1, a_oSearchData.getTask1().trim().toUpperCase());
       _pstmtFindPrimaryKey.setString(2, a_oSearchData.getTask2().trim().toUpperCase());
       _pstmtFindPrimaryKey.setInt(3, DataConstants.CLIENT_TYPE_PROPOSER);
       _pstmtFindPrimaryKey.setInt(4, DataConstants.POLICY_STATUS);
     }
     else
     {
       log.debug("ContractDAX--In else"  + ":::>>>" + a_oSearchData.getTask2().trim());
       _pstmtFindPrimaryKey.setString(1, a_oSearchData.getTask2().trim().toUpperCase());
       _pstmtFindPrimaryKey.setInt(2, DataConstants.CLIENT_TYPE_PROPOSER);
       _pstmtFindPrimaryKey.setInt(3, DataConstants.POLICY_STATUS);
     }


     rsSearchClawback = executeQuery(_pstmtFindPrimaryKey);
     while(rsSearchClawback.next())
     {
       log.debug("ContractDAX--in while");
       _oClawbackResult = new ClawbackResult();
       log.debug(rsSearchClawback.getString(1));
       _oClawbackResult.setPolNbr(rsSearchClawback.getString(1));
       log.debug(rsSearchClawback.getString(2));
       _oClawbackResult.setPolIssue(DateUtil.retGregorian(rsSearchClawback.getTimestamp(2)));
//       _oContractMap.set_dtEffTo(DateUtil.retGregorian(rsSearchContractMap.getTimestamp(7)));
       log.debug(rsSearchClawback.getString(3));
       _oClawbackResult.setPolicyHolderName(rsSearchClawback.getString(3));
       log.debug(rsSearchClawback.getString(4));
       _oClawbackResult.setTerm( new Short(rsSearchClawback.getShort(4)) );
       log.debug(rsSearchClawback.getString(5));
       _oClawbackResult.setSa(new Double(rsSearchClawback.getDouble(5)));
       log.debug(rsSearchClawback.getString(6));
       _oClawbackResult.setPrmAmnt(new Double( rsSearchClawback.getDouble(6)));
       log.debug(rsSearchClawback.getString(7));
       _oClawbackResult.setStatus(rsSearchClawback.getString(7));
       log.debug(rsSearchClawback.getString(8));
       _oClawbackResult.setClawbackIndcr(new Short( rsSearchClawback.getShort(8)));
       log.debug(DataConstants.DISPLAY_MODE);
       _oClawbackResult.setStatusFlag(DataConstants.DISPLAY_MODE);
       _oClawbackResult.setTsDtUpdated(rsSearchClawback.getTimestamp("dtupdated"));
       log.debug("ContractDAX--before addibng while");
       _oClawbackList.add(_oClawbackResult);
     }
     log.debug("ContractDAX--before returning");
     return _oClawbackList;
   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     throw new EElixirException(sqlex, "P3041");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P3041");
   }
   finally
   {
     try
     {

       if(_pstmtFindPrimaryKey != null)
         _pstmtFindPrimaryKey.close();

     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3041");
     }
   }

 }

 /**
   * Description Depending on SEarchData returns boolean
   * @return boolean
   * @param a_strPolNbr String
   * @param a_strServAgentCd String
   * @throws EElixirException
   */
public boolean searchClawback( String a_strPolNbr, String a_strServAgentCd) throws EElixirException
  {
    ResultSet rsSearchClawback = null;
    PreparedStatement _pstmtFindPrimaryKey = null;
    String strSelectClawbackQuery = null;
    try
    {
      log.debug("ContractDAX--in searchClawback of ejb ");
        strSelectClawbackQuery = getSQLString("Select",CHMConstants.FIND_CLAWBACK_BY_PRIMARYKEY_1);
      log.debug(strSelectClawbackQuery);
      if(_pstmtFindPrimaryKey == null)
      {
        _pstmtFindPrimaryKey = getPreparedStatement(strSelectClawbackQuery);
      }
      log.debug(_pstmtFindPrimaryKey + "");

        _pstmtFindPrimaryKey.setString(1, a_strPolNbr.toUpperCase());
        _pstmtFindPrimaryKey.setString(2, a_strServAgentCd.toUpperCase());
        _pstmtFindPrimaryKey.setInt(3, DataConstants.CLIENT_TYPE_PROPOSER);
       _pstmtFindPrimaryKey.setInt(4, DataConstants.POLICY_STATUS);



      rsSearchClawback = executeQuery(_pstmtFindPrimaryKey);
      if(rsSearchClawback.next())
      {
        return true;
      }
      return false;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, "P3041");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3041");
    }
    finally
    {
      try
      {

        if(_pstmtFindPrimaryKey != null)
          _pstmtFindPrimaryKey.close();

      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, "P3041");
      }
    }

  }
 /**
   * Description Updates selfContract
   * @param oClawbackResult ClawbackResult
   * @throws EElixirException
   */
 public void updateClawback(ClawbackResult oClawbackResult) throws EElixirException
  {
    PreparedStatement _pstmtClawback = null;
    try
    {

      String strUpdateClawback  = getSQLString("Update",CHMConstants.CLAWBACK_UPDATE);
      _pstmtClawback = getPreparedStatement(strUpdateClawback);

	  if (oClawbackResult.getClawbackIndcr() != null)	  {
     _pstmtClawback.setShort(1, oClawbackResult.getClawbackIndcr().shortValue());
	  }
	  else{
		_pstmtClawback.setNull(1, Types.SMALLINT);
	  }

     _pstmtClawback.setString(2, oClawbackResult.getUserId());
     _pstmtClawback.setString(3, oClawbackResult.getPolNbr().toUpperCase());
     _pstmtClawback.setString(4, oClawbackResult.getServAgentCd().toUpperCase());

      executeUpdate(_pstmtClawback);
      log.debug("ContractDAX--query executed properly");


    }
    catch(SQLException sqlex){
      log.debug("ContractDAX--Error while updating clawback------- DAX---SQL");
      sqlex.printStackTrace();
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex,"Error while updating clawback", "P3042");
    }
    catch(EElixirException eex)
    {
      log.debug("ContractDAX--Error while update clawback-------- DAX--- EE");
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3042");
    }
    finally
    {
      try
      {

        if(_pstmtClawback != null)
          _pstmtClawback.close();

      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, "P3042");
      }
    }
  }

public Timestamp getSelfContractDtUpdated(String strPolNbr) throws EElixirException
{
      ResultSet rsSearchContract = null;
      PreparedStatement pstmtSearchContract = null;
      Timestamp tsDtUpdated = null;
      try
      {
        String strSelectContractQuery = getSQLString("Select",CHMConstants.GET_SELF_CONTRACT_DTUPDATED);
        log.debug("ContractDAX--search query is "+ strSelectContractQuery);

        if(pstmtSearchContract == null)
        {
          pstmtSearchContract = getPreparedStatement(strSelectContractQuery);
        }
        pstmtSearchContract.setString(1,strPolNbr.toUpperCase());

        rsSearchContract = executeQuery(pstmtSearchContract);
        log.debug("ContractDAX--Query executed properly");
        if(rsSearchContract.next())
        {
          tsDtUpdated = rsSearchContract.getTimestamp("dtupdated");
        }
        log.debug("ContractDAX--Returning Contract Result");
        return tsDtUpdated;
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P3018");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P3018");
      }
      finally
      {
        try
        {
          if(rsSearchContract != null)
            rsSearchContract.close();

          if(pstmtSearchContract != null)
            pstmtSearchContract.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
    }
}

  /**
   * An Abstract implementation
   */
  public  void populateDVOs()
  {
  }

  /**
   * A temporary method just used for debugging, It checks the content of Resul set
   * @return void
   * @param: rs ResultSet
   */
  /*
  /**
  * Prepares the Sql Statement and returns the CallableStatement.
  * @param strSqlString
  * @return CallableStatement
  * @throws EElixirException
  */
  public CallableStatement getCallableStatement(String a_strSqlString)
          throws EElixirException
  {
     CallableStatement callableStatement =null;

     if(_oConnection == null)
        throw new EElixirException("Unable to get the Connection");

     try{
        callableStatement =_oConnection.prepareCall(a_strSqlString);
     }
     catch(SQLException sqlex){
        throw new EElixirException(sqlex,sqlex.getMessage());

     }
     return callableStatement;
  }

    /*
    /*
     *  Member variables
     */
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}