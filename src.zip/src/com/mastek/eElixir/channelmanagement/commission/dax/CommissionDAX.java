/********************************************************************
 *
 *  PROJECT			: PRUDENTIAL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME			: CommissionDAX.java
 *  AUTHOR			: Pallav Laddha
 *  VERSION			: 1.0
 *  CREATION DATE	        : September 20, 2002
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  		BY					REASON
 *--------------------------------------------------------------------------------
 *1.1       23Jan2003         	Pallav            	added  Maturity Age From and To
 *1.2       13/Nov/2009		 	Anup Kumar     		Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
 *1.3		07/04/2015 			Vibhu Nigam			FIN838_AgentCommissionDisbursementLimitChange
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.dax;
import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Vector;

import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.commission.util.CollectionParamResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.commission.util.DisbursementSetupResult;
import com.mastek.eElixir.channelmanagement.commission.util.OverrideCommRuleResult;
import com.mastek.eElixir.channelmanagement.commission.util.OverridingCommRateDetail;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;
import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;

/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the Commission object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class CommissionDAX extends DAX
{
  public CHMSqlRepository theCHMSqlRepository= null;

  /**
   * Constructor
   */
  public CommissionDAX()
  {
  }

  /**
   * Description getSQLString takes querytype and key and returns query
   * @return query string
   * @param a_strSQLType SQL Type i.e Select , Insert , Delete , Update
   * @param a_strKey String
   * @throws EElixirException
   */
  private String getSQLString(String a_strSQLType,String a_strKey) throws EElixirException
  {
    SqlRepositoryIF sqlRFIF = null;
    String strSql = "";
    try
    {
      sqlRFIF = CHMSqlRepository.getSqlRepository();
      strSql=sqlRFIF.getSQLString(a_strKey,a_strSQLType);
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3001");
    }
    return strSql;
  }

  /**
   * Creates a new record
   * @param a_oCommissionResult CommissionResult
   * @throws EElixirException
   */
  /*public void createStandardCommission(CommissionResult a_oCommissionResult) throws EElixirException
  {
    PreparedStatement pstmtCreateCommission = null;
    Statement st = null ;
    StringBuffer sb = new StringBuffer();
    int icount = 0;
    try
    {
      Long olComAgreementKey = a_oCommissionResult.getComAgreementKey();
      CommissionDetails[] arrCommissionDetails = a_oCommissionResult.getCommissionDetail();
      String strCreatedBy = a_oCommissionResult.getUserId();
      for(int i=0; i<arrCommissionDetails.length; i++){
        short nTermFrom = arrCommissionDetails[i].getTermFrom().shortValue();
        short nTermTo = arrCommissionDetails[i].getTermTo().shortValue();
        short nEntryAgeFrom = arrCommissionDetails[i].getEntryAgeFrom().shortValue();
        short nEntryAgeTo = arrCommissionDetails[i].getEntryAgeTo().shortValue();
        short nMatAgeFrom = arrCommissionDetails[i].getMatAgeFrom().shortValue();
        short nMatAgeTo = arrCommissionDetails[i].getMatAgeTo().shortValue();
        short nNbrOfLivesFrom = arrCommissionDetails[i].getNbrOfLivesFrom().shortValue();
        short nNbrOfLivesTo = arrCommissionDetails[i].getNbrOfLivesTo().shortValue();
        double dBaseValeFrom = arrCommissionDetails[i].getBaseValeFrom().doubleValue();
        double dBaseValeTo = arrCommissionDetails[i].getBaseValeTo().doubleValue();
        short nPolYearFrom = arrCommissionDetails[i].getPolYearFrom().shortValue();
        short nPolYearTo = arrCommissionDetails[i].getPolYearTo().shortValue();
        double dCommRate = arrCommissionDetails[i].getCommRate().doubleValue();
        long lAgreementSCKey = getNextAgreementKey(DataConstants.STANDARD_COMMISSION);
        String strCreateContractQuery = getSQLString("Insert",CHMConstants.STANDARD_COMMISSION_INSERT);

        log.debug("CommissionDAX--\nCommaggrement key >>"+olComAgreementKey + "<<");

        log.debug("CommissionDAX--\nTerm from >>"+nTermFrom + "<<");
        log.debug("CommissionDAX--\nTerm to >>"+nTermTo + "<<");
        log.debug("CommissionDAX--\nEntry Age from>>"+nEntryAgeFrom + "<<");
        log.debug("CommissionDAX--\nEntry Age to >>"+nEntryAgeTo + "<<");
        log.debug("CommissionDAX--\nMat Age from>>"+nMatAgeFrom + "<<");
        log.debug("CommissionDAX--\nMat Age to >>"+nMatAgeTo + "<<");
        log.debug("CommissionDAX--\nNbr of lives from >>"+nNbrOfLivesFrom + "<<");
        log.debug("CommissionDAX--\nNbr of lives to >>"+nNbrOfLivesTo + "<<");
        log.debug("CommissionDAX--\nBase Vale from >>"+dBaseValeFrom + "<<");
        log.debug("CommissionDAX--\nBase vale to >>"+dBaseValeTo + "<<");
        log.debug("CommissionDAX--\nPol Year from >>"+nPolYearFrom + "<<");
        log.debug("CommissionDAX--\nPol Year to >>"+nPolYearTo + "<<");
        log.debug("CommissionDAX--\nComm rate >>"+dCommRate + "<<");

        pstmtCreateCommission = getPreparedStatement(strCreateContractQuery);

        pstmtCreateCommission.setLong(1,olComAgreementKey.longValue());
        pstmtCreateCommission.setShort(2,nTermFrom);
        pstmtCreateCommission.setShort(3,nTermTo);
        pstmtCreateCommission.setShort(4,nEntryAgeFrom);
        pstmtCreateCommission.setShort(5,nEntryAgeTo);
        pstmtCreateCommission.setShort(6,nMatAgeFrom);
        pstmtCreateCommission.setShort(7,nMatAgeTo);
        pstmtCreateCommission.setShort(8,nNbrOfLivesFrom);
        pstmtCreateCommission.setShort(9,nNbrOfLivesTo);
        pstmtCreateCommission.setDouble(10,dBaseValeFrom);
        pstmtCreateCommission.setDouble(11,dBaseValeTo);
        pstmtCreateCommission.setShort(12,nPolYearFrom);
        pstmtCreateCommission.setShort(13,nPolYearTo);
        pstmtCreateCommission.setDouble(14,dCommRate);
        pstmtCreateCommission.setLong(15,lAgreementSCKey);
        pstmtCreateCommission.setString(16,strCreatedBy);
        icount = executeUpdate(pstmtCreateCommission);
        log.debug("CommissionDAX--" + icount);
      }
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3002");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3002");
    }
    finally
    {
      try
      {
        if(pstmtCreateCommission != null)
          pstmtCreateCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }*/
/**
   * Creates a new record
   * @param a_oCommissionResult CommissionResult
   * @param a_nCommType short
   * @return long
   * @throws EElixirException
   */
  public long createStandardCommission(CommissionResult a_oCommissionResult, short a_nCommType) throws EElixirException
  {
    PreparedStatement pstmtCreateCommission = null;
    //Statement st = null ;
    //StringBuffer sb = new StringBuffer();
    int icount = 0;
    long lRetKey = 0;
    try
    {
      Long olComAgreementKey = a_oCommissionResult.getComAgreementKey();
      CommissionDetails[] arrCommissionDetails = a_oCommissionResult.getCommissionDetail();
      String strCreatedBy = a_oCommissionResult.getUserId();
      for(int i=0; i<arrCommissionDetails.length; i++){
        short nTermFrom = arrCommissionDetails[i].getTermFrom().shortValue();
        short nTermTo = arrCommissionDetails[i].getTermTo().shortValue();
      //Added by Aradhana FIN1107 12_oct_2017:START
        short nPptFrom = 0;
        short nPptTo = 0;
      //Added by Aradhana FIN1107 12_oct_2017:END
        short nEntryAgeFrom = arrCommissionDetails[i].getEntryAgeFrom().shortValue();
        short nEntryAgeTo = arrCommissionDetails[i].getEntryAgeTo().shortValue();
        short nMatAgeFrom = arrCommissionDetails[i].getMatAgeFrom().shortValue();
        short nMatAgeTo = arrCommissionDetails[i].getMatAgeTo().shortValue();
        short nNbrOfLivesFrom = arrCommissionDetails[i].getNbrOfLivesFrom().shortValue();
        short nNbrOfLivesTo = arrCommissionDetails[i].getNbrOfLivesTo().shortValue();

        Double dSAFrom = arrCommissionDetails[i].getSAFrom();
        Double dSATo = arrCommissionDetails[i].getSATo();
        double dBaseValeFrom = arrCommissionDetails[i].getBaseValeFrom().doubleValue();
        double dBaseValeTo = arrCommissionDetails[i].getBaseValeTo().doubleValue();
        short nPolYearFrom = arrCommissionDetails[i].getPolYearFrom().shortValue();
        short nPolYearTo = arrCommissionDetails[i].getPolYearTo().shortValue();
        double dCommRate = 0;
        long lAgreementKey = 0;
        String strRepLinkCd = "";
        String strCreateContractQuery = "";
        Short nCommPmtMode= arrCommissionDetails[i].getCommPmtMode(); //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010
        if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
          strRepLinkCd = arrCommissionDetails[i].getRepLinkCd();
          lAgreementKey = getNextAgreementKey(DataConstants.OVERRIDING_COMMISSION);
          strCreateContractQuery = getSQLString("Insert",CHMConstants.OVERRIDING_COMMISSION_INSERT);
        }
        else{
         //Added by Aradhana FIN1107 10_JAN_2018:START
           nPptFrom = arrCommissionDetails[i].getPptFrom().shortValue();
           nPptTo = arrCommissionDetails[i].getPptTo().shortValue();
         //Added by Aradhana FIN1107 10_JAN_2018:END
          dCommRate = arrCommissionDetails[i].getCommRate().doubleValue();
          lAgreementKey = getNextAgreementKey(DataConstants.STANDARD_COMMISSION);
          strCreateContractQuery = getSQLString("Insert",CHMConstants.STANDARD_COMMISSION_INSERT);
        }
        lRetKey = lAgreementKey;

        log.debug("CommissionDAX--\nCommaggrement key >>"+olComAgreementKey + "<<");

        log.debug("CommissionDAX--\nTerm from >>"+nTermFrom + "<<");
        log.debug("CommissionDAX--\nTerm to >>"+nTermTo + "<<");
        //Added by Aradhana FIN1107 12_oct_2017:START
        log.debug("CommissionDAX--\nPpt from >>"+nPptFrom + "<<");
        log.debug("CommissionDAX--\nPpt to >>"+nPptTo + "<<");
        //Added by Aradhana FIN1107 12_oct_2017:END
        log.debug("CommissionDAX--\nEntry Age from>>"+nEntryAgeFrom + "<<");
        log.debug("CommissionDAX--\nEntry Age to >>"+nEntryAgeTo + "<<");
        log.debug("CommissionDAX--\nMat Age from>>"+nMatAgeFrom + "<<");
        log.debug("CommissionDAX--\nMat Age to >>"+nMatAgeTo + "<<");
        log.debug("CommissionDAX--\nNbr of lives from >>"+nNbrOfLivesFrom + "<<");
        log.debug("CommissionDAX--\nNbr of lives to >>"+nNbrOfLivesTo + "<<");
        log.debug("CommissionDAX--\nSA from >>"+dSAFrom + "<<");
        log.debug("CommissionDAX--\nSA to >>"+dSATo + "<<");
        log.debug("CommissionDAX--\nBase Value from >>"+dBaseValeFrom + "<<");
        log.debug("CommissionDAX--\nBase value to >>"+dBaseValeTo + "<<");
        log.debug("CommissionDAX--\nPol Year from >>"+nPolYearFrom + "<<");
        log.debug("CommissionDAX--\nPol Year to >>"+nPolYearTo + "<<");
        log.debug("CommissionDAX--\nstrCreatedBy>>"+strCreatedBy + "<<");
        log.debug("CommissionDAX--\nComm rate >>"+dCommRate + "<<");
        log.debug("CommissionDAX--\nn CommPmtMode >>"+nCommPmtMode + "<<");

        pstmtCreateCommission = getPreparedStatement(strCreateContractQuery);
        pstmtCreateCommission.setLong(1,olComAgreementKey.longValue());
        pstmtCreateCommission.setShort(2,nTermFrom);
        pstmtCreateCommission.setShort(3,nTermTo);
        pstmtCreateCommission.setShort(4,nEntryAgeFrom);
        pstmtCreateCommission.setShort(5,nEntryAgeTo);
        pstmtCreateCommission.setShort(6,nMatAgeFrom);
        pstmtCreateCommission.setShort(7,nMatAgeTo);
        pstmtCreateCommission.setShort(8,nNbrOfLivesFrom);
        pstmtCreateCommission.setShort(9,nNbrOfLivesTo);
	    if(dSAFrom == null){
			pstmtCreateCommission.setNull(10,java.sql.Types.DOUBLE);
		}
		else{
			pstmtCreateCommission.setDouble(10,dSAFrom.doubleValue());
		}

	    if(dSATo == null){
			pstmtCreateCommission.setNull(11,java.sql.Types.DOUBLE);
		}
		else{
			pstmtCreateCommission.setDouble(11,dSATo.doubleValue());
		}
        pstmtCreateCommission.setDouble(12,dBaseValeFrom);
        pstmtCreateCommission.setDouble(13,dBaseValeTo);
        pstmtCreateCommission.setShort(14,nPolYearFrom);
        pstmtCreateCommission.setShort(15,nPolYearTo);
        if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
          pstmtCreateCommission.setString(16,strRepLinkCd);
          pstmtCreateCommission.setInt(17,DataConstants.ORCRATE_NOT_PRESENT);
          pstmtCreateCommission.setLong(18,lAgreementKey);
          pstmtCreateCommission.setString(19,strCreatedBy);
        }
        else{
          pstmtCreateCommission.setDouble(16,dCommRate);
          pstmtCreateCommission.setLong(17,lAgreementKey);
          pstmtCreateCommission.setString(18,strCreatedBy);
         //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
          if(nCommPmtMode == null){			
        	  	pstmtCreateCommission.setNull(19,java.sql.Types.INTEGER);
    		}else{
    			pstmtCreateCommission.setShort(19,nCommPmtMode.shortValue());
    		}
          //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Ends
        //Added by Aradhana FIN1107 12_oct_2017:START
          pstmtCreateCommission.setShort(20,nPptFrom);
          pstmtCreateCommission.setShort(21,nPptTo); 
        //Added by Aradhana FIN1107 12_oct_2017:END
        }


        icount = executeUpdate(pstmtCreateCommission);
        log.debug("CommissionDAX--" + icount);
      }
    }
    catch(SQLException sqlex){
      log.fatal(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3002");
    }
    finally
    {
      try
      {
        if(pstmtCreateCommission != null)
          pstmtCreateCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.fatal(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
    return lRetKey;
  }

  /**
   * Creates a new record
   * @param a_oCommissionResult CommissionResult
   * @throws EElixirException
   */
  public void createClawBackCommission(CommissionResult a_oCommissionResult) throws EElixirException
  {
    PreparedStatement pstmtCreateCommission = null;
    //Statement st = null ;
   // StringBuffer sb = new StringBuffer();
    int icount = 0;
    try
    {
      Long olComAgreementKey = a_oCommissionResult.getComAgreementKey();
      ClawBackDetails[] arrClawBackDetails = a_oCommissionResult.getClawBackDetail();
      String strCreatedBy = a_oCommissionResult.getUserId();
      for(int i=0; i<arrClawBackDetails.length; i++){
        String strPmtMode = arrClawBackDetails[i].getPmtMode();
        short nRngType = arrClawBackDetails[i].getRngType().shortValue();
        short nRngFrom = arrClawBackDetails[i].getRngFrom().shortValue();
        short nRngTo = arrClawBackDetails[i].getRngTo().shortValue();
        double dClawbackRate = arrClawBackDetails[i].getClawbackRate().doubleValue();
        // Since now strPmtMode is converted to nPmtMode it is changed back to
        // nPmtMode but the changes is done only for Dax and repository and not in result object
        // this is an exceptional case and deviation from standard since time is less.
        short nPmtMode = Short.parseShort(strPmtMode.trim());
        long lAgreementClawKey = getNextAgreementKey(DataConstants.CLAWBACK_COMMISSION);
        String strCreateContractQuery = getSQLString("Insert",CHMConstants.CLAWBACK_COMMISSION_INSERT);

        log.debug("CommissionDAX--\nCommaggrement key >>"+strPmtMode + "<<");
        log.debug("CommissionDAX--\nTerm from >>"+nRngType + "<<");
        log.debug("CommissionDAX--\nTerm to >>"+nRngFrom + "<<");
        log.debug("CommissionDAX--\nEntry Age from>>"+nRngTo + "<<");
        log.debug("CommissionDAX--\nEntry Age to >>"+dClawbackRate + "<<");

        pstmtCreateCommission = getPreparedStatement(strCreateContractQuery);

        pstmtCreateCommission.setLong(1,olComAgreementKey.longValue());
        //pstmtCreateCommission.setString(2,strPmtMode);
        pstmtCreateCommission.setShort(2,nPmtMode);
        pstmtCreateCommission.setShort(3,nRngType);
        pstmtCreateCommission.setShort(4,nRngFrom);
        pstmtCreateCommission.setShort(5,nRngTo);
        pstmtCreateCommission.setDouble(6,dClawbackRate);
        pstmtCreateCommission.setLong(7,lAgreementClawKey);
        pstmtCreateCommission.setString(8,strCreatedBy);
        icount = executeUpdate(pstmtCreateCommission);
        log.debug("CommissionDAX--" + icount);
      }
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3003");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3003");
    }
    finally
    {
      try
      {
        if(pstmtCreateCommission != null)
          pstmtCreateCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }


  /**
   * Gets List of Standard Commission on a particular Contract Unique Seq no.
   * @return CommissionDetails[] Array of Commission
   * @param: a_lCommAgrmtSeqNbr long
   * @throws EElixirException
   */
  public CommissionDetails[] getStandardCommission(long a_lCommAgrmtSeqNbr, short a_nCommType) throws EElixirException
  {
    log.debug("CommissionDAX--In GetStandardCommission");
    ResultSet rsSearchStandardCommission = null;
    CommissionDetails[] arrCommissionDetails = null;
    PreparedStatement pstmtSearchStandardCommission = null;
    try
    {
      String strSelectQuery = "";
      if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
        strSelectQuery = getSQLString("Select",CHMConstants.OVERRIDING_COMMISSION_SELECTED_SEARCH);
      }
      else{
        strSelectQuery = getSQLString("Select",CHMConstants.STANDARD_COMMISSION_SELECTED_SEARCH);
      }

      log.debug("CommissionDAX--The query is " + strSelectQuery);
      if(pstmtSearchStandardCommission == null)
      {
        pstmtSearchStandardCommission = getPreparedStatement(strSelectQuery);
      }
      pstmtSearchStandardCommission.setLong(1,a_lCommAgrmtSeqNbr);
      log.debug("CommissionDAX--setting comm seq nbr as " + a_lCommAgrmtSeqNbr + "&&");
      rsSearchStandardCommission = executeQuery(pstmtSearchStandardCommission);

      Vector vCommissionDetail = new Vector();
      CommissionDetails oCommissionDetails = null;
      while(rsSearchStandardCommission.next())
      {
        oCommissionDetails = new CommissionDetails();
		/* CHANGE TO AVOID UPDATE  */
		oCommissionDetails.setIsDirty(DataConstants.DISPLAY_MODE);
        oCommissionDetails.setAgrmtSCSeqNbr(new Long(rsSearchStandardCommission.getLong(1)));
        oCommissionDetails.setTermFrom(new Short(rsSearchStandardCommission.getShort(2)));
        oCommissionDetails.setPolYearFrom(new Short(rsSearchStandardCommission.getShort(3)));
        oCommissionDetails.setNbrOfLivesFrom(new Short(rsSearchStandardCommission.getShort(4)));
        double d = rsSearchStandardCommission.getDouble(5);
        if(rsSearchStandardCommission.wasNull()){
           oCommissionDetails.setSAFrom(null);
        }
        else{
          oCommissionDetails.setSAFrom(new Double(d));
        }
        oCommissionDetails.setEntryAgeFrom(new Short(rsSearchStandardCommission.getShort(6)));
        oCommissionDetails.setMatAgeFrom(new Short(rsSearchStandardCommission.getShort(7)));
        oCommissionDetails.setBaseValeFrom(new Double(rsSearchStandardCommission.getDouble(8)));
        oCommissionDetails.setTermTo(new Short(rsSearchStandardCommission.getShort(9)));
        oCommissionDetails.setPolYearTo(new Short(rsSearchStandardCommission.getShort(10)));
        oCommissionDetails.setNbrOfLivesTo(new Short(rsSearchStandardCommission.getShort(11)));
        d = rsSearchStandardCommission.getDouble(12);
        if(rsSearchStandardCommission.wasNull()){
           oCommissionDetails.setSATo(null);
        }
        else{
          oCommissionDetails.setSATo(new Double(d));
        }
        oCommissionDetails.setEntryAgeTo(new Short(rsSearchStandardCommission.getShort(13)));
        oCommissionDetails.setMatAgeTo(new Short(rsSearchStandardCommission.getShort(14)));
        oCommissionDetails.setBaseValeTo(new Double(rsSearchStandardCommission.getDouble(15)));
         if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
            oCommissionDetails.setRepLinkCd(rsSearchStandardCommission.getString(16));
            oCommissionDetails.setIsORCRatePresent(new Short(rsSearchStandardCommission.getShort(17)));
            oCommissionDetails.setTsDtUpdated(rsSearchStandardCommission.getTimestamp(17));
         }
         else{
            oCommissionDetails.setCommRate(new Double(rsSearchStandardCommission.getDouble(16)));
             oCommissionDetails.setTsDtUpdated(rsSearchStandardCommission.getTimestamp("dtupdated"));
             // Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
             short nMode = rsSearchStandardCommission.getShort("npmtmode");
             if(rsSearchStandardCommission.wasNull()){
                oCommissionDetails.setCommPmtMode(null);
             }
             else{
               oCommissionDetails.setCommPmtMode(new Short(nMode));
             }
             log.debug("nMode-->>getCommPmtMode()-->>"+oCommissionDetails.getCommPmtMode());
             // Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Ends
           //Added by Aradhana FIN1107 23_oct_2017:START
             oCommissionDetails.setPptFrom(rsSearchStandardCommission.getShort("NPPTFROM"));
             oCommissionDetails.setPptTo(rsSearchStandardCommission.getShort("NPPTTO"));
           //Added by Aradhana FIN1107 23_oct_2017:END
         }
         
        vCommissionDetail.addElement(oCommissionDetails);
      }

      arrCommissionDetails = new CommissionDetails[vCommissionDetail.size()];
      log.debug("CommissionDAX--Successful QueryExecution");
      for(int count=0; count<vCommissionDetail.size(); count++){
        arrCommissionDetails[count] = new CommissionDetails();
        arrCommissionDetails[count] = (CommissionDetails)vCommissionDetail.elementAt(count);
      }
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P3004");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P3004");
      }
      finally
      {
        try
        {
          if(rsSearchStandardCommission != null)
            rsSearchStandardCommission.close();

          if(pstmtSearchStandardCommission != null)
            pstmtSearchStandardCommission.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
      log.debug("CommissionDAX--Checking Value " + arrCommissionDetails.length);
      return arrCommissionDetails;
  }




  /**
   * Gets List of ClawBack Commission on a particular Contract Unique Seq no.
   * @return ClawBackDetails[] Array of ClawBackDetails
   * @param: a_lCommAgrmtSeqNbr long
   * @throws EElixirException
   */
  public ClawBackDetails[] getClawBackCommission(long a_lCommAgrmtSeqNbr) throws EElixirException
  {
    ResultSet rsSearchClawBackCommission = null;
    ClawBackDetails[] arrClawBackDetails = null;;
    PreparedStatement pstmtSearchClawBackCommission = null;
    try
    {
      String strSelectQuery = getSQLString("Select",CHMConstants.CLAWBACK_COMMISSION_SELECTED_SEARCH);
      log.debug("CommissionDAX--The query is " + strSelectQuery);

      if(pstmtSearchClawBackCommission == null)
      {
        pstmtSearchClawBackCommission = getPreparedStatement(strSelectQuery);
      }
      pstmtSearchClawBackCommission.setLong(1,a_lCommAgrmtSeqNbr);
      rsSearchClawBackCommission = executeQuery(pstmtSearchClawBackCommission);
      Vector vClawBackDetail = new Vector();
      ClawBackDetails oClawBackDetails= null;
      while(rsSearchClawBackCommission.next())
      {
        oClawBackDetails = new ClawBackDetails();
		oClawBackDetails.setIsDirty(DataConstants.DISPLAY_MODE);
        oClawBackDetails.setlAgrmtClawSeqNbr(new Long(rsSearchClawBackCommission.getLong(1)));
        //oClawBackDetails.setPmtMode(rsSearchClawBackCommission.getString(2));
        oClawBackDetails.setPmtMode((rsSearchClawBackCommission.getShort(2) + "").trim());
        oClawBackDetails.setRngType(new Short(rsSearchClawBackCommission.getShort(3)));
        oClawBackDetails.setRngFrom(new Short(rsSearchClawBackCommission.getShort(4)));
        oClawBackDetails.setRngTo(new Short(rsSearchClawBackCommission.getShort(5)));
        oClawBackDetails.setClawbackRate(new Double(rsSearchClawBackCommission.getDouble(6)));
        oClawBackDetails.setTsDtUpdated(rsSearchClawBackCommission.getTimestamp("DTUPDATED"));
        vClawBackDetail.addElement(oClawBackDetails);
      }

      arrClawBackDetails = new ClawBackDetails[vClawBackDetail.size()];
      for(int count=0; count<vClawBackDetail.size(); count++){
        arrClawBackDetails[count] = new ClawBackDetails();
        arrClawBackDetails[count] = (ClawBackDetails)vClawBackDetail.elementAt(count);
      }
      log.debug("CommissionDAX--After successful completion of query");
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P3005");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P3005");
      }
      finally
      {
        try
        {
          if(rsSearchClawBackCommission != null)
            rsSearchClawBackCommission.close();

          if(pstmtSearchClawBackCommission != null)
            pstmtSearchClawBackCommission.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
      return arrClawBackDetails;
  }


  /**
   * Finds if Standard Commission exist on a particular Contract Unique Seq no.
   * @return boolean
   * @param a_lAgrmtSCSeqNbr long
   * @throws EElixirException
   */
  public boolean findStandardCommission(long a_lAgrmtSCSeqNbr) throws EElixirException
  {
    log.debug("CommissionDAX-- FindStandard Commission " + a_lAgrmtSCSeqNbr);
    ResultSet rsSearchStandardCommission = null;
    PreparedStatement pstmtFindStandardCommission = null;
    try
    {
      String strQuery = getSQLString("Select",CHMConstants.STANDARD_COMMISSION_SEARCH);

      if(pstmtFindStandardCommission == null)
      {
        pstmtFindStandardCommission = getPreparedStatement(strQuery);
      }
      pstmtFindStandardCommission.setLong(1,a_lAgrmtSCSeqNbr);


      rsSearchStandardCommission = executeQuery(pstmtFindStandardCommission);
      log.debug("CommissionDAX--After execution");
      if(rsSearchStandardCommission.next())
      {
        log.debug("CommissionDAX--returning true");
        return true;
      }
      else
      {
        log.debug("CommissionDAX--returning false");
        return false;
      }
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3006");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3006");
    }
    finally
    {
      try
      {
        if(rsSearchStandardCommission != null)
          rsSearchStandardCommission.close();

        if(pstmtFindStandardCommission != null)
          pstmtFindStandardCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }

  }


  /**
   * Finds if ClawBack Commission exist on a particular Contract Unique Seq no.
   * @return boolean
   * @param: a_lAgrmtClawSeqNbr long
   * @throws EElixirException
   */
  public boolean findClawBackCommission(long a_lAgrmtClawSeqNbr) throws EElixirException
  {
    ResultSet rsSearchClawBackCommission = null;
    PreparedStatement pstmtFindClawBackCommission = null;
    try
    {
      String strQuery = getSQLString("Select",CHMConstants.CLAWBACK_COMMISSION_SEARCH);

      if(pstmtFindClawBackCommission == null)
      {
        pstmtFindClawBackCommission = getPreparedStatement(strQuery);
      }
      pstmtFindClawBackCommission.setLong(1,a_lAgrmtClawSeqNbr);


      rsSearchClawBackCommission = executeQuery(pstmtFindClawBackCommission);
      if(rsSearchClawBackCommission.next())
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3007");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3007");
    }
    finally
    {
      try
      {
        if(rsSearchClawBackCommission != null)
          rsSearchClawBackCommission.close();

        if(pstmtFindClawBackCommission != null)
          pstmtFindClawBackCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }


  /**
   * Updates the Standard commission
   * @return int No of rows updated
   * @param: a_oCommissionDetails CommissionDetails
   * @throws EElixirException
   */
  public int updateStandardCommission(CommissionDetails a_oCommissionDetails,short a_nCommType) throws EElixirException
  {
    PreparedStatement pstmtUpdateStandardCommission = null;
    try
    {
      String strUpdateAgentQuery = "";
      short nTermFrom = a_oCommissionDetails.getTermFrom().shortValue();
      short nTermTo = a_oCommissionDetails.getTermTo().shortValue();
    //Added by Aradhana FIN1107 12_oct_2017:START
      short nPptFrom = 0;
      short nPptTo = 0;
    //Added by Aradhana FIN1107 12_oct_2017:END
      short nEntryAgeFrom = a_oCommissionDetails.getEntryAgeFrom().shortValue();
      short nEntryAgeTo = a_oCommissionDetails.getEntryAgeTo().shortValue();
      short nMatAgeFrom = a_oCommissionDetails.getMatAgeFrom().shortValue();
      short nMatAgeTo = a_oCommissionDetails.getMatAgeTo().shortValue();
      short nNbrOfLivesFrom = a_oCommissionDetails.getNbrOfLivesFrom().shortValue();
      short nNbrOfLivesTo = a_oCommissionDetails.getNbrOfLivesTo().shortValue();
	  Double dSAFrom = a_oCommissionDetails.getSAFrom();
   	  Double dSATo = a_oCommissionDetails.getSATo();
      double dBaseValeFrom = a_oCommissionDetails.getBaseValeFrom().doubleValue();
      double dBaseValeTo = a_oCommissionDetails.getBaseValeTo().doubleValue();
      short nPolYearFrom = a_oCommissionDetails.getPolYearFrom().shortValue();
      short nPolYearTo = a_oCommissionDetails.getPolYearTo().shortValue();
      double dCommRate = 0;
      String strRepLinkCd = "";
       if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
        strRepLinkCd = a_oCommissionDetails.getRepLinkCd();
        //nIsORCRatePresent = a_oCommissionDetails.getIsORCRatePresent().shortValue();
        strUpdateAgentQuery = getSQLString("Update",CHMConstants.OVERRIDING_COMMISSION_UPDATE);
      }
      else{
    	//Added by Aradhana FIN1107 10_JAn_2018:START
        nPptFrom = a_oCommissionDetails.getPptFrom().shortValue();
        nPptTo = a_oCommissionDetails.getPptTo().shortValue();
        //Added by Aradhana FIN1107 10_JAn_2018:END
        dCommRate = a_oCommissionDetails.getCommRate().doubleValue();
        strUpdateAgentQuery = getSQLString("Update",CHMConstants.STANDARD_COMMISSION_UPDATE);
      }
      pstmtUpdateStandardCommission = getPreparedStatement(strUpdateAgentQuery);
      long lAgrmtSCSeqNbr = a_oCommissionDetails.getAgrmtSCSeqNbr().longValue();
      // amit added 11/1/2002
      String strUpdatedBy = a_oCommissionDetails.getUserId();
      Short nCommPmtMode = a_oCommissionDetails.getCommPmtMode();

      pstmtUpdateStandardCommission.setShort(1,nTermFrom);
      pstmtUpdateStandardCommission.setShort(2,nTermTo);
      pstmtUpdateStandardCommission.setShort(3,nEntryAgeFrom);
      pstmtUpdateStandardCommission.setShort(4,nEntryAgeTo);
      pstmtUpdateStandardCommission.setShort(5,nMatAgeFrom);
      pstmtUpdateStandardCommission.setShort(6,nMatAgeTo);
      pstmtUpdateStandardCommission.setShort(7,nNbrOfLivesFrom);
      pstmtUpdateStandardCommission.setShort(8,nNbrOfLivesTo);
		if(dSAFrom == null){
			pstmtUpdateStandardCommission.setNull(9,java.sql.Types.DOUBLE);
		}
		else{
			pstmtUpdateStandardCommission.setDouble(9,dSAFrom.doubleValue());
		}

		if(dSATo == null){
			pstmtUpdateStandardCommission.setNull(10,java.sql.Types.DOUBLE);
		}
		else{
			pstmtUpdateStandardCommission.setDouble(10,dSATo.doubleValue());
		}
      pstmtUpdateStandardCommission.setDouble(11,dBaseValeFrom);
      pstmtUpdateStandardCommission.setDouble(12,dBaseValeTo);
      pstmtUpdateStandardCommission.setShort(13,nPolYearFrom);
      pstmtUpdateStandardCommission.setShort(14,nPolYearTo);
    
      if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
        pstmtUpdateStandardCommission.setString(15,strRepLinkCd);
        pstmtUpdateStandardCommission.setString(16,strUpdatedBy);
        pstmtUpdateStandardCommission.setLong(17,lAgrmtSCSeqNbr);
        //pstmtUpdateStandardCommission.setShort(14,nIsORCRatePresent);
      }
      else{
    	//Added by Aradhana FIN1107 12_oct_2017:START
          pstmtUpdateStandardCommission.setShort(15,nPptFrom);
          pstmtUpdateStandardCommission.setShort(16,nPptTo);
         //Added by Aradhana FIN1107 12_oct_2017:END
        pstmtUpdateStandardCommission.setDouble(17,dCommRate);
//      amit 11/1/2002
        pstmtUpdateStandardCommission.setString(18,strUpdatedBy);
        //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
        log.debug("nCommPmtMode --->> In update query");
        if(nCommPmtMode == null){			
  			pstmtUpdateStandardCommission.setNull(19,java.sql.Types.INTEGER);
  		}else{
  			pstmtUpdateStandardCommission.setShort(19,nCommPmtMode.shortValue());
  		}
        //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Ends
        pstmtUpdateStandardCommission.setLong(20,lAgrmtSCSeqNbr);
      
      }      
      int iUpdateStandardCommission = executeUpdate(pstmtUpdateStandardCommission);
      return iUpdateStandardCommission;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3008");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3008");
    }
    finally
    {
      try
      {
        if(pstmtUpdateStandardCommission != null)
          pstmtUpdateStandardCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

  /**
   * Updates the ClawBack commission
   * @return int No of rows updated
   * @param: a_oClawBackDetails ClawBackDetails
   * @throws EElixirException
   */
  public int updateClawBackCommission(ClawBackDetails a_oClawBackDetails) throws EElixirException
  {
    PreparedStatement pstmtUpdateClawBackCommission = null;
    try
    {
      String strUpdateQuery = getSQLString("Update",CHMConstants.CLAWBACK_COMMISSION_UPDATE);
      pstmtUpdateClawBackCommission = getPreparedStatement(strUpdateQuery);

      String strPmtMode = a_oClawBackDetails.getPmtMode();
      short nRngType = a_oClawBackDetails.getRngType().shortValue();
      short nRngFrom = a_oClawBackDetails.getRngFrom().shortValue();
      short nRngTo = a_oClawBackDetails.getRngTo().shortValue();
      double dClawbackRate = a_oClawBackDetails.getClawbackRate().doubleValue();
      // Since now strPmtMode is converted to nPmtMode it is changed back to
      // nPmtMode but the changes is done only for Dax and repository and not in result object
      // this is an exceptional case and deviation from standard since time is less.
      short nPmtMode = Short.parseShort(strPmtMode.trim());

      long lAgrmtClawSeqNbr = a_oClawBackDetails.getlAgrmtClawSeqNbr().longValue();
      String strUpdatedBy = a_oClawBackDetails.getUserId();

      //pstmtUpdateClawBackCommission.setString(1,strPmtMode);
      pstmtUpdateClawBackCommission.setShort(1,nPmtMode);
      pstmtUpdateClawBackCommission.setShort(2,nRngType);
      pstmtUpdateClawBackCommission.setShort(3,nRngFrom);
      pstmtUpdateClawBackCommission.setShort(4,nRngTo);
      pstmtUpdateClawBackCommission.setDouble(5,dClawbackRate);
      pstmtUpdateClawBackCommission.setString(6,strUpdatedBy);
      pstmtUpdateClawBackCommission.setLong(7,lAgrmtClawSeqNbr);

      int iUpdateClawBackCommission = executeUpdate(pstmtUpdateClawBackCommission);
      return iUpdateClawBackCommission;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3009");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3009");
    }
    finally
    {
      try
      {
        if(pstmtUpdateClawBackCommission != null)
          pstmtUpdateClawBackCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }



  /**
   * Removes the Standard commission
   * @return int No of rows removed
   * @param: a_oCommissionDetails CommissionDetails
   * @throws EElixirException
   */
  public int removeStandardCommission(CommissionDetails a_oCommissionDetails,short a_nCommType) throws EElixirException
  {
    PreparedStatement pstmtRemoveStandardCommission = null;
    PreparedStatement pstmtRemoveCommission = null;

    try
    {
      String strRemoveQuery = "";
      int iRemoveCommission = 0;
      if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
        // First deletes all the child record i.e OverridingCommRate table and then deletes the data from main table
        strRemoveQuery = getSQLString("Delete",CHMConstants.OVERRIDING_COMM_RATE_ALL_DELETE);
        pstmtRemoveCommission = getPreparedStatement(strRemoveQuery);
        long lAgrmtSeqNbr = a_oCommissionDetails.getAgrmtSCSeqNbr().longValue();
        pstmtRemoveCommission.setLong(1,lAgrmtSeqNbr);
        iRemoveCommission = executeUpdate(pstmtRemoveCommission);

        strRemoveQuery = getSQLString("Delete",CHMConstants.OVERRIDING_COMMISSION_DELETE);
      }
      else{
        strRemoveQuery = getSQLString("Delete",CHMConstants.STANDARD_COMMISSION_DELETE);
      }
      pstmtRemoveCommission = getPreparedStatement(strRemoveQuery);
      long lAgrmtSeqNbr = a_oCommissionDetails.getAgrmtSCSeqNbr().longValue();
      pstmtRemoveCommission.setLong(1,lAgrmtSeqNbr);
      iRemoveCommission = executeUpdate(pstmtRemoveCommission);
      return iRemoveCommission;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3010");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3010");
    }
    finally
    {
      try
      {

        if(pstmtRemoveStandardCommission != null)
          pstmtRemoveStandardCommission.close();

      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }

  }



  /**
   * Removes the ClawBack commission
   * @return int No of rows removed
   * @param: a_oClawBackDetails ClawBackDetails
   * @throws EElixirException
   */
  public int removeClawBackCommission(ClawBackDetails a_oClawBackDetails) throws EElixirException
  {
    PreparedStatement pstmtRemoveClawBackCommission = null;
    try
    {
      String strRemoveQuery = getSQLString("Delete",CHMConstants.CLAWBACK_COMMISSION_DELETE);
      pstmtRemoveClawBackCommission = getPreparedStatement(strRemoveQuery);
      long lAgrmtClawSeqNbr = a_oClawBackDetails.getlAgrmtClawSeqNbr().longValue();
      pstmtRemoveClawBackCommission.setLong(1,lAgrmtClawSeqNbr);
      int iRemoveClawBackCommission = executeUpdate(pstmtRemoveClawBackCommission);
      return iRemoveClawBackCommission;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3011");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3011");
    }
    finally
    {
      try
      {
        if(pstmtRemoveClawBackCommission != null)
          pstmtRemoveClawBackCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }


  /**
   * Depending on the type of commission and mode of operation like Update, Delete and Insert it
   * calls appropriate methods.
   * @param: a_oContractResult ContractResult
   * @throws EElixirException
   */
  public void updateCommission(ContractResult a_oContractResult) throws EElixirException
  {
    try
    {
      int nCommType = a_oContractResult.getCommissionResult().getCommType().intValue();
      short comm_type = a_oContractResult.getCommissionResult().getCommType().shortValue();
      log.debug("CommissionDAX--Inside Update Commission");
      // for standard commission, or Trail
	  //Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
      if(nCommType == DataConstants.STANDARD_COMMISSION || nCommType == DataConstants.TRAIL_COMMISSION || nCommType == DataConstants.INDEX_COMMISSION || nCommType == DataConstants.OVERRIDING_COMMISSION){
        CommissionDetails[] arrCommissionDetail = a_oContractResult.getCommissionResult().getCommissionDetail();
        for(int i=0; i<arrCommissionDetail.length; i++){
          log.debug("CommissionDAX--Status Flag" + arrCommissionDetail[i].getStatusFlag().trim());
          if(arrCommissionDetail[i].getStatusFlag().trim().equals(DataConstants.UPDATE_MODE)){
            log.debug("CommissionDAX--Inside Update " + arrCommissionDetail[i].getAgrmtSCSeqNbr().longValue());
            int z = updateStandardCommission(arrCommissionDetail[i],comm_type);
            log.debug("CommissionDAX--Update Complete for Standard/trail/overr count = " + z);
          }
          else if(arrCommissionDetail[i].getStatusFlag().trim().equals(DataConstants.INSERT_MODE)){
            log.debug("CommissionDAX--Inside Insert");
            long seqNo = insertStandardCommission(arrCommissionDetail[i],a_oContractResult.getCommissionResult().getComAgreementKey().longValue(),comm_type );
            arrCommissionDetail[i].setAgrmtSCSeqNbr(new Long(seqNo));
            log.debug("CommissionDAX--Insert Complete:"+arrCommissionDetail[i].getAgrmtSCSeqNbr());
          }
          else if(arrCommissionDetail[i].getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
            log.debug("CommissionDAX--Inside Delete " + arrCommissionDetail[i].getAgrmtSCSeqNbr().longValue());
            removeStandardCommission(arrCommissionDetail[i],comm_type);
            log.debug("CommissionDAX--Delete Complete");
          }
        }
      }
      else if(nCommType == DataConstants.CLAWBACK_COMMISSION){ // for Clawback
        ClawBackDetails[] arrClawBackDetail = a_oContractResult.getCommissionResult().getClawBackDetail();
        for(int i=0; i<arrClawBackDetail.length; i++){
          if(arrClawBackDetail[i].getStatusFlag().trim().equals(DataConstants.UPDATE_MODE)){
            log.debug("CommissionDAX--Inside Update " + arrClawBackDetail[i].getlAgrmtClawSeqNbr().longValue());
            updateClawBackCommission(arrClawBackDetail[i]);
            log.debug("CommissionDAX--Update Complete");
          }
          else if(arrClawBackDetail[i].getStatusFlag().trim().equals(DataConstants.INSERT_MODE)){
            log.debug("CommissionDAX--Inside Insert");
            long seqNo = insertClawBackCommission(arrClawBackDetail[i], a_oContractResult.getCommissionResult().getComAgreementKey().longValue() );
            arrClawBackDetail[i].setlAgrmtClawSeqNbr(new Long(seqNo));
            log.debug("CommissionDAX--Insert Complete");
          }
          else if(arrClawBackDetail[i].getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
            log.debug("CommissionDAX--Inside Delete " + arrClawBackDetail[i].getlAgrmtClawSeqNbr().longValue());
            removeClawBackCommission(arrClawBackDetail[i]);
            log.debug("CommissionDAX--Delete Complete");
          }
        }
      }

      //CommissionDetails[] commDetails =  a_oContractResult.getCommissionResult().getCommissionDetail();
      //for(int i = 0; i< commDetails.length ; i++)
      //{
        //log.debug("CommissionDAX--After update the details : ----------------"+ commDetails[i].getAgrmtSCSeqNbr() );
      //}
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
  }

  /**
   * Inserts a record record for Standard Commission
   * @return void
   * @param: a_oCommissionDetail CommissionDetails
   * @param: a_olComAgreementKey long
   * @throws EElixirException
   */
  public long insertStandardCommission(CommissionDetails a_oCommissionDetail, long a_olComAgreementKey,short a_nCommType) throws EElixirException
  {
    log.debug("CommissionDAX--inside insertStandardCommission" + a_olComAgreementKey);
    PreparedStatement pstmtCreateCommission = null;
    try
    {
      short nTermFrom = a_oCommissionDetail.getTermFrom().shortValue();
      short nTermTo = a_oCommissionDetail.getTermTo().shortValue();
    //Added by Aradhana FIN1107 23_oct_2017:START
      short nPptFrom = 0;
      short nPptTo = 0;
    //Added by Aradhana FIN1107 23_oct_2017:END
      short nEntryAgeFrom = a_oCommissionDetail.getEntryAgeFrom().shortValue();
      short nEntryAgeTo = a_oCommissionDetail.getEntryAgeTo().shortValue();
      short nMatAgeFrom = a_oCommissionDetail.getMatAgeFrom().shortValue();
      short nMatAgeTo = a_oCommissionDetail.getMatAgeTo().shortValue();
      short nNbrOfLivesFrom = a_oCommissionDetail.getNbrOfLivesFrom().shortValue();
      short nNbrOfLivesTo = a_oCommissionDetail.getNbrOfLivesTo().shortValue();
	  Double dSAFrom = a_oCommissionDetail.getSAFrom();
	  Double dSATo = a_oCommissionDetail.getSATo();
      double dBaseValeFrom = a_oCommissionDetail.getBaseValeFrom().doubleValue();
      double dBaseValeTo = a_oCommissionDetail.getBaseValeTo().doubleValue();
      short nPolYearFrom = a_oCommissionDetail.getPolYearFrom().shortValue();
      short nPolYearTo = a_oCommissionDetail.getPolYearTo().shortValue();
      double dCommRate = 0;
      String strCreatedBy = a_oCommissionDetail.getUserId();
      log.debug("CommissionDAX--Got Values");

       long lAgreementKey = 0;
       String strRepLinkCd = "";
       String strCreateContractQuery = "";
       Short nCommPmtMode = a_oCommissionDetail.getCommPmtMode();//Anup_Unit_Builder_PACE_Req1_JAN_REL_2010
      // short nIsORCRatePresent = 0;

       if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
        strRepLinkCd = a_oCommissionDetail.getRepLinkCd();
        lAgreementKey = getNextAgreementKey(DataConstants.OVERRIDING_COMMISSION);
        //nIsORCRatePresent = a_oCommissionDetail.getIsORCRatePresent().shortValue();
        strCreateContractQuery = getSQLString("Insert",CHMConstants.OVERRIDING_COMMISSION_INSERT);
      }
      else{
    	 //Added by Aradhana FIN1107 10_JAn_2018:START
         nPptFrom = a_oCommissionDetail.getPptFrom().shortValue();
         nPptTo = a_oCommissionDetail.getPptTo().shortValue();
        //Added by Aradhana FIN1107 10_JAn_2018:END
        dCommRate = a_oCommissionDetail.getCommRate().doubleValue();
        lAgreementKey = getNextAgreementKey(DataConstants.STANDARD_COMMISSION);
        strCreateContractQuery = getSQLString("Insert",CHMConstants.STANDARD_COMMISSION_INSERT);
      }

      log.debug("CommissionDAX--\nCommaggrement key >>"+a_olComAgreementKey + "<<");
     /*
      log.debug("CommissionDAX--\nTerm from >>"+nTermFrom + "<<");
      log.debug("CommissionDAX--\nTerm to >>"+nTermTo + "<<");
      log.debug("CommissionDAX--\nEntry Age from>>"+nEntryAgeFrom + "<<");
      log.debug("CommissionDAX--\nEntry Age to >>"+nEntryAgeTo + "<<");
      log.debug("CommissionDAX--\nNbr of lives from >>"+nNbrOfLivesFrom + "<<");
      log.debug("CommissionDAX--\nNbr of lives to >>"+nNbrOfLivesTo + "<<");
      log.debug("CommissionDAX--\nBase Vale from >>"+dBaseValeFrom + "<<");
      log.debug("CommissionDAX--\nBase vale to >>"+dBaseValeTo + "<<");
      log.debug("CommissionDAX--\nPol Year from >>"+nPolYearFrom + "<<");
      log.debug("CommissionDAX--\nPol Year to >>"+nPolYearTo + "<<");
      log.debug("CommissionDAX--\nComm rate >>"+dCommRate + "<<");
      */

      log.debug("CommissionDAX--Before query");
      pstmtCreateCommission = getPreparedStatement(strCreateContractQuery);
      log.debug("CommissionDAX--After query");
      pstmtCreateCommission.setLong(1,a_olComAgreementKey);
      pstmtCreateCommission.setShort(2,nTermFrom);
      pstmtCreateCommission.setShort(3,nTermTo);
      pstmtCreateCommission.setShort(4,nEntryAgeFrom);
      pstmtCreateCommission.setShort(5,nEntryAgeTo);
      pstmtCreateCommission.setShort(6,nMatAgeFrom);
      pstmtCreateCommission.setShort(7,nMatAgeTo);
      pstmtCreateCommission.setShort(8,nNbrOfLivesFrom);
      pstmtCreateCommission.setShort(9,nNbrOfLivesTo);
	    if(dSAFrom == null){
			pstmtCreateCommission.setNull(10,java.sql.Types.DOUBLE);
		}
		else{
			pstmtCreateCommission.setDouble(10,dSAFrom.doubleValue());
		}

	    if(dSATo == null){
			pstmtCreateCommission.setNull(11,java.sql.Types.DOUBLE);
		}
		else{
			pstmtCreateCommission.setDouble(11,dSATo.doubleValue());
		}
      pstmtCreateCommission.setDouble(12,dBaseValeFrom);
      pstmtCreateCommission.setDouble(13,dBaseValeTo);
      pstmtCreateCommission.setShort(14,nPolYearFrom);
      pstmtCreateCommission.setShort(15,nPolYearTo);
        if(a_nCommType == DataConstants.OVERRIDING_COMMISSION){
        pstmtCreateCommission.setString(16,strRepLinkCd);
        pstmtCreateCommission.setInt(17,DataConstants.ORCRATE_NOT_PRESENT);
        pstmtCreateCommission.setLong(18,lAgreementKey);
        pstmtCreateCommission.setString(19,strCreatedBy);
      }
      else{
        pstmtCreateCommission.setDouble(16,dCommRate);
        pstmtCreateCommission.setLong(17,lAgreementKey);
        pstmtCreateCommission.setString(18,strCreatedBy);
//      Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
        if(nCommPmtMode == null){			
      	  	pstmtCreateCommission.setNull(19,java.sql.Types.INTEGER);
  		}else{
  			pstmtCreateCommission.setShort(19,nCommPmtMode.shortValue());
  		}
        //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Ends
        //Added by Aradhana FIN1107 23_oct_2017:START
        pstmtCreateCommission.setShort(20,nPptFrom);
        pstmtCreateCommission.setShort(21,nPptTo);
        //Added by Aradhana FIN1107 23_oct_2017:END
      }


      int icount = executeUpdate(pstmtCreateCommission);
      log.debug("CommissionDAX--" + icount);
      return lAgreementKey;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3012");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3012");
    }
    finally
    {
      try
      {
        if(pstmtCreateCommission != null)
          pstmtCreateCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

  /**
   * Inserts a record record for ClawBack Commission
   * @return void
   * @param: a_oClawBackDetail ClawBackDetails
   * @param: a_olComAgreementKey long
   * @throws EElixirException
   */
  public long insertClawBackCommission(ClawBackDetails a_oClawBackDetail, long a_olComAgreementKey) throws EElixirException
  {
    PreparedStatement pstmtCreateCommission = null;
    //Statement st = null ;
    //StringBuffer sb = new StringBuffer();
    try
    {
      String strPmtMode = a_oClawBackDetail.getPmtMode();
      short nRngType = a_oClawBackDetail.getRngType().shortValue();
      short nRngFrom = a_oClawBackDetail.getRngFrom().shortValue();
      short nRngTo = a_oClawBackDetail.getRngTo().shortValue();
      double dClawbackRate = a_oClawBackDetail.getClawbackRate().doubleValue();
      // Since now strPmtMode is converted to nPmtMode it is changed back to
      // nPmtMode but the changes is done only for Dax and repository and not in result object
      // this is an exceptional case and deviation from standard since time is less.
      short nPmtMode = Short.parseShort(strPmtMode.trim());

      long lAgreementClawKey = getNextAgreementKey(DataConstants.CLAWBACK_COMMISSION);
      String strCreatedBy = a_oClawBackDetail.getUserId();
      String strCreateContractQuery = getSQLString("Insert",CHMConstants.CLAWBACK_COMMISSION_INSERT);

      log.debug("CommissionDAX--\nCommaggrement key >>"+strPmtMode + "<<");
       /*
       log.debug("CommissionDAX--\nTerm from >>"+nRngType + "<<");
       log.debug("CommissionDAX--\nTerm to >>"+nRngFrom + "<<");
       log.debug("CommissionDAX--\nEntry Age from>>"+nRngTo + "<<");
       log.debug("CommissionDAX--\nEntry Age to >>"+dClawbackRate + "<<");
       */
      pstmtCreateCommission = getPreparedStatement(strCreateContractQuery);

      pstmtCreateCommission.setLong(1,a_olComAgreementKey);
    //pstmtCreateCommission.setString(2,strPmtMode);
      pstmtCreateCommission.setShort(2,nPmtMode);
      pstmtCreateCommission.setShort(3,nRngType);
      pstmtCreateCommission.setShort(4,nRngFrom);
      pstmtCreateCommission.setShort(5,nRngTo);
      pstmtCreateCommission.setDouble(6,dClawbackRate);
      pstmtCreateCommission.setLong(7,lAgreementClawKey);
      pstmtCreateCommission.setString(8,strCreatedBy);

      int icount = executeUpdate(pstmtCreateCommission);
      log.debug("CommissionDAX--" + icount);
      return lAgreementClawKey;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3013");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3013");
    }
    finally
    {
      try
      {
        if(pstmtCreateCommission != null)
          pstmtCreateCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

  /**
   * This function generates a new Seq no, on which the
   * new record is inserted.
   * @param type String
   * @return long Returns the next seq no generated on Contract table
   * @throws EElixirException
   */
  protected long getNextAgreementKey(int type) throws EElixirException{
    Statement stmtNextSeqCommission = null;
    long lSeqNo;
    try
    {
      String strNextSeqQuery = null;
      if(type == DataConstants.STANDARD_COMMISSION){
        strNextSeqQuery = getSQLString("Select",CHMConstants.STANDARD_COMMISSION_SEQNO);
      }
      else if (type == DataConstants.CLAWBACK_COMMISSION){
        strNextSeqQuery = getSQLString("Select",CHMConstants.CLAWBACK_COMMISSION_SEQNO);
      }
       else if (type == DataConstants.OVERRIDING_COMMISSION){
        strNextSeqQuery = getSQLString("Select",CHMConstants.OVERRIDING_COMMISSION_SEQNO);
       }
       else if (type == DataConstants.OVERRIDING_COMM_RATE){
        strNextSeqQuery = getSQLString("Select",CHMConstants.OVERRIDING_COMM_RATE_SEQNO);
      }

      stmtNextSeqCommission = getStatement();
      ResultSet rsSeqNo = stmtNextSeqCommission.executeQuery(strNextSeqQuery);
      rsSeqNo.next();
      lSeqNo = rsSeqNo.getLong(1);
      log.debug("%%%%%"+lSeqNo + "");
      return lSeqNo;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3014");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3014");
    }
    finally
    {
      try
      {
        if(stmtNextSeqCommission != null)
          stmtNextSeqCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }



  /**
   * A temporary method just used for debugging, It checks the content of Resul set
   */
  /*
  public void display(ResultSet rs) throws EElixirException
  {
    log.debug("CommissionDAX--Inside display");
    try{
      while(rs.next()){
        log.debug("CommissionDAX--row1"+rs.getString(1));
        log.debug("CommissionDAX--Debug2"+rs.getString(1));
      }
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"Code");
    }
  }
  */

  public Timestamp getStandardCommissionDtUpdated(Long lAgrmtScSeqNbr) throws EElixirException
  {
    Timestamp dtUpdated = null;
    ResultSet rsSearchStandardCommission = null;
    PreparedStatement pstmtFindStandardCommission = null;
    try
    {
      String strQuery = getSQLString("Select",CHMConstants.GET_STANDARD_COMMISSION_DTUPDATED);
      if(pstmtFindStandardCommission == null)
      {
        pstmtFindStandardCommission = getPreparedStatement(strQuery);
      }
      pstmtFindStandardCommission.setLong(1,lAgrmtScSeqNbr.longValue());
      rsSearchStandardCommission = executeQuery(pstmtFindStandardCommission);
      log.debug("CommissionDAX--After execution");
      if(rsSearchStandardCommission.next())
      {
        dtUpdated = rsSearchStandardCommission.getTimestamp("dtUpdated");
      }
      else
      {
        log.debug("concurrency failed thorwing exception");
        throw new EElixirException("P1100");
      }
      return dtUpdated;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3006");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P3006");
    }
    finally
    {
      try
      {
        if(rsSearchStandardCommission != null)
          rsSearchStandardCommission.close();

        if(pstmtFindStandardCommission != null)
          pstmtFindStandardCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

  public Timestamp getClawBackCommissionDtUpdated(Long lAgrmtClawSeqNbr) throws EElixirException
    {
      Timestamp dtUpdated = null;
      ResultSet rsSearchStandardCommission = null;
      PreparedStatement pstmtFindStandardCommission = null;
      try
      {
        String strQuery = getSQLString("Select",CHMConstants.GET_CLAWBACK_COMMISSION_DTUPDATED);
        if(pstmtFindStandardCommission == null)
        {
          pstmtFindStandardCommission = getPreparedStatement(strQuery);
        }
        pstmtFindStandardCommission.setLong(1,lAgrmtClawSeqNbr.longValue());
        rsSearchStandardCommission = executeQuery(pstmtFindStandardCommission);
        log.debug("CommissionDAX--After execution");
        if(rsSearchStandardCommission.next())
        {
          dtUpdated = rsSearchStandardCommission.getTimestamp("dtUpdated");
        }
        else
        {
          log.debug("concurrency failed thorwing exception");
          throw new EElixirException("P1100");
        }
        return dtUpdated;
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P3006");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P3006");
      }
      finally
      {
        try
        {
          if(rsSearchStandardCommission != null)
            rsSearchStandardCommission.close();

          if(pstmtFindStandardCommission != null)
            pstmtFindStandardCommission.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }

  }

    /**
   * Creates a new record
   * @param a_oOverridingCommRateDetail OverridingCommRateDetail
   * @return long
   * @throws EElixirException
   */
  public long createOverridingCommRate(OverridingCommRateDetail a_oOverridingCommRateDetail) throws EElixirException
  {
    PreparedStatement pstmtCreateUpdateCommission = null;
    //Statement st = null ;
    //StringBuffer sb = new StringBuffer();
    int icount = 0;
    try
    {

      String strCreatedUpdatedBy = a_oOverridingCommRateDetail.getUserId();
      long lAgrmtORCSeqNbr = a_oOverridingCommRateDetail.getAgrmtORCSeqNbr().longValue();
      double dORCRate = a_oOverridingCommRateDetail.getORCRate().doubleValue();
      double dProdRangeFrom = a_oOverridingCommRateDetail.getProdRangeFrom().doubleValue();
      double dProdRangeTo = a_oOverridingCommRateDetail.getProdRangeTo().doubleValue();
      String strSupDesgnCd = a_oOverridingCommRateDetail.getSupDesgnCd();
      String strProdDesgnCd = a_oOverridingCommRateDetail.getProdDesgnCd();
      long lAgrmtRateSeqNbr = getNextAgreementKey(DataConstants.OVERRIDING_COMM_RATE);
      String strCreateQuery = getSQLString("Insert",CHMConstants.OVERRIDING_COMM_RATE_INSERT);

      log.debug("CommissionDAX--\n lAgrmtORCSeqNbr key >>"+lAgrmtORCSeqNbr + "<<");
      log.debug("CommissionDAX--\ndORCRate >>"+dORCRate + "<<");
      log.debug("CommissionDAX--\ndProdRangeFrom >>"+dProdRangeFrom + "<<");
      log.debug("CommissionDAX--\ndProdRangeTo>>"+dProdRangeTo + "<<");
      log.debug("CommissionDAX--\nstrSupDesgnCd >>"+strSupDesgnCd + "<<");
      log.debug("CommissionDAX--\nlAgrmtRateSeqNbr>>"+lAgrmtRateSeqNbr + "<<");

      pstmtCreateUpdateCommission = getPreparedStatement(strCreateQuery);

      pstmtCreateUpdateCommission.setLong(1,lAgrmtORCSeqNbr);
      pstmtCreateUpdateCommission.setLong(2,lAgrmtRateSeqNbr);
      pstmtCreateUpdateCommission.setDouble(3,dORCRate);
      pstmtCreateUpdateCommission.setDouble(4,dProdRangeFrom);
      pstmtCreateUpdateCommission.setDouble(5,dProdRangeTo);
      pstmtCreateUpdateCommission.setString(6,strSupDesgnCd);
      pstmtCreateUpdateCommission.setString(7,strProdDesgnCd);
      pstmtCreateUpdateCommission.setString(8,strCreatedUpdatedBy);
      icount = executeUpdate(pstmtCreateUpdateCommission);
      log.debug("CommissionDAX--" + icount);

      // Now updating Overriding commission table
      log.debug(" Now updating Overriding commission");
      String strUpdateQuery = getSQLString("Update",CHMConstants.OVERRIDING_COMM_RATE_PRESENT_UPDATE);
      pstmtCreateUpdateCommission = getPreparedStatement(strUpdateQuery);
      pstmtCreateUpdateCommission.setInt(1,DataConstants.ORCRATE_PRESENT);
      pstmtCreateUpdateCommission.setString(2,strCreatedUpdatedBy);
      pstmtCreateUpdateCommission.setLong(3,lAgrmtORCSeqNbr);
      icount = executeUpdate(pstmtCreateUpdateCommission);
      log.debug("Updated Overriding commission");

      return lAgrmtRateSeqNbr;
    }
    catch(SQLException sqlex){
      log.fatal(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3049"); //@todo change this error code
    }
    finally
    {
      try
      {
        if(pstmtCreateUpdateCommission != null)
          pstmtCreateUpdateCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.fatal(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }
public OverridingCommRateDetail getOverridingCommRate(long a_lAgrmtRateSeqNbr) throws EElixirException
  {
    ResultSet rsSearchCommission = null;
    OverridingCommRateDetail oOverridingCommRateDetail = null;;
    PreparedStatement pstmtSearchCommission = null;
    try
    {
      String strSelectQuery = getSQLString("Select",CHMConstants.OVERRIDING_COMM_RATE_SELECTED_SEARCH);
      log.debug("CommissionDAX--The query is " + strSelectQuery);

      pstmtSearchCommission = getPreparedStatement(strSelectQuery);

      pstmtSearchCommission.setLong(1,a_lAgrmtRateSeqNbr);
      rsSearchCommission = executeQuery(pstmtSearchCommission);
      if(rsSearchCommission.next())
      {
        oOverridingCommRateDetail = new OverridingCommRateDetail();
        oOverridingCommRateDetail.setIsDirty(DataConstants.DISPLAY_MODE);
        oOverridingCommRateDetail.setAgrmtORCSeqNbr(new Long(rsSearchCommission.getLong("LAGRMTORCSEQNBR")));
        oOverridingCommRateDetail.setAgrmtRateSeqNbr(new Long(rsSearchCommission.getLong("LAGRMTRATESEQNBR")));
        oOverridingCommRateDetail.setORCRate(new Double(rsSearchCommission.getDouble("DORCRATE")));
        oOverridingCommRateDetail.setProdRangeFrom(new Double(rsSearchCommission.getDouble("DPRODRANGEFROM")));
        oOverridingCommRateDetail.setProdRangeTo(new Double(rsSearchCommission.getDouble("DPRODRANGETO")));
        oOverridingCommRateDetail.setSupDesgnCd(rsSearchCommission.getString("STRSUPDESGNCD"));
        oOverridingCommRateDetail.setProdDesgnCd(rsSearchCommission.getString("STRPRODDESGNCD"));
        oOverridingCommRateDetail.setTsDtUpdated(rsSearchCommission.getTimestamp("DTUPDATED"));
      }
      log.debug("CommissionDAX--After successful completion of query");
    }
    catch(SQLException sqlex){
        log.fatal(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P3053"); //@todo change this error code
    }
    finally
      {
        try
        {
          if(rsSearchCommission != null)
            rsSearchCommission.close();

          if(pstmtSearchCommission != null)
            pstmtSearchCommission.close();
        }
        catch(SQLException sqlex)
        {
          log.fatal(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
      return oOverridingCommRateDetail;
  }

  /**
   * Updates a record
   * @param a_oOverridingCommRateDetail OverridingCommRateDetail
   * @throws EElixirException
   */
  public void updateOverridingCommRate(OverridingCommRateDetail a_oOverridingCommRateDetail) throws EElixirException
  {
    PreparedStatement pstmtUpdateCommission = null;
   // Statement st = null ;
   // StringBuffer sb = new StringBuffer();
    int icount = 0;
    try
    {

      String strUpdatedBy = a_oOverridingCommRateDetail.getUserId();
      long lAgrmtORCSeqNbr = a_oOverridingCommRateDetail.getAgrmtORCSeqNbr().longValue();
      double dORCRate = a_oOverridingCommRateDetail.getORCRate().doubleValue();
      double dProdRangeFrom = a_oOverridingCommRateDetail.getProdRangeFrom().doubleValue();
      double dProdRangeTo = a_oOverridingCommRateDetail.getProdRangeTo().doubleValue();
      String strSupDesgnCd = a_oOverridingCommRateDetail.getSupDesgnCd();
      String strProdDesgnCd = a_oOverridingCommRateDetail.getProdDesgnCd();
      long lAgrmtRateSeqNbr = a_oOverridingCommRateDetail.getAgrmtRateSeqNbr().longValue();
      String strUpdateQuery = getSQLString("Update",CHMConstants.OVERRIDING_COMM_RATE_UPDATE);


        log.debug("CommissionDAX--\n lAgrmtORCSeqNbr key >>"+lAgrmtORCSeqNbr + "<<");

        log.debug("CommissionDAX--\ndORCRate >>"+dORCRate + "<<");
        log.debug("CommissionDAX--\ndProdRangeFrom >>"+dProdRangeFrom + "<<");
        log.debug("CommissionDAX--\ndProdRangeTo>>"+dProdRangeTo + "<<");
        log.debug("CommissionDAX--\nstrSupDesgnCd >>"+strSupDesgnCd + "<<");
        log.debug("CommissionDAX--\nlAgrmtRateSeqNbr>>"+lAgrmtRateSeqNbr + "<<");


        pstmtUpdateCommission = getPreparedStatement(strUpdateQuery);


        pstmtUpdateCommission.setDouble(1,dORCRate);
        pstmtUpdateCommission.setDouble(2,dProdRangeFrom);
        pstmtUpdateCommission.setDouble(3,dProdRangeTo);
        pstmtUpdateCommission.setString(4,strSupDesgnCd);
        pstmtUpdateCommission.setString(5,strProdDesgnCd);
        pstmtUpdateCommission.setString(6,strUpdatedBy);
        pstmtUpdateCommission.setLong(7,lAgrmtRateSeqNbr);
        icount = executeUpdate(pstmtUpdateCommission);
        log.debug("CommissionDAX--" + icount);
    }
    catch(SQLException sqlex){
      log.fatal(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3050");
    }
    finally
    {
      try
      {
        if(pstmtUpdateCommission != null)
          pstmtUpdateCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.fatal(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

   public void removeOverridingCommRate(long a_lAgrmtRateSeqNbr) throws EElixirException
  {
    PreparedStatement pstmtRemoveCommission = null;
    //Statement st = null ;
    //StringBuffer sb = new StringBuffer();
    int icount = 0;
    try
    {
      String strRemoveQuery = getSQLString("Delete",CHMConstants.OVERRIDING_COMM_RATE_DELETE);
      log.debug("CommissionDAX--\n a_lAgrmtRateSeqNbr>>"+a_lAgrmtRateSeqNbr + "<<");
      pstmtRemoveCommission = getPreparedStatement(strRemoveQuery);
      pstmtRemoveCommission.setLong(1,a_lAgrmtRateSeqNbr);
      icount = executeUpdate(pstmtRemoveCommission);
      log.debug("CommissionDAX--" + icount);
    }
    catch(SQLException sqlex){
      log.fatal(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3051");
    }
    finally
    {
      try
      {
        if(pstmtRemoveCommission != null)
          pstmtRemoveCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.fatal(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }
  /**
   * Finds if Overriding Commission Rate exist on a particular Unique Seq no.
   * @return boolean
   * @param a_lAgrmtRateSeqNbr long
   * @throws EElixirException
   */
  public boolean findOverridingCommRate(long a_lAgrmtRateSeqNbr) throws EElixirException
  {
    ResultSet rsSearchCommission = null;
    PreparedStatement pstmtFindCommission = null;
    try
    {
      String strQuery = getSQLString("Select",CHMConstants.FIND_OVERRIDING_COMM_RATE_BY_PRIMARYKEY);
      pstmtFindCommission = getPreparedStatement(strQuery);
      pstmtFindCommission.setLong(1,a_lAgrmtRateSeqNbr);
      rsSearchCommission = executeQuery(pstmtFindCommission);
      if(rsSearchCommission.next())
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    catch(SQLException sqlex){
      log.fatal(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3052");
    }
    finally
    {
      try
      {
        if(rsSearchCommission != null)
          rsSearchCommission.close();

        if(pstmtFindCommission != null)
          pstmtFindCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.fatal(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }
 /**
   * Gets List of Overriding Commission Rate on a particular Overriding Commission Seq No
   * @return ArrayList
   * @param a_lAgrmtORCSeqNbr long
   * @throws EElixirException
   */
  public ArrayList getAllOverridingCommRate(long a_lAgrmtORCSeqNbr) throws EElixirException
  {
    ResultSet rsSearchCommission = null;
    ArrayList arrOverridingCommRateDetail = null;;
    PreparedStatement pstmtSearchCommission = null;
    try
    {
      String strSelectQuery = getSQLString("Select",CHMConstants.OVERRIDING_COMM_RATE_ALL_SEARCH);
      log.debug("CommissionDAX--The query is " + strSelectQuery);

      pstmtSearchCommission = getPreparedStatement(strSelectQuery);

      pstmtSearchCommission.setLong(1,a_lAgrmtORCSeqNbr);
      rsSearchCommission = executeQuery(pstmtSearchCommission);
      arrOverridingCommRateDetail = new ArrayList(10);
      int count = 0;
     while(rsSearchCommission.next())
      {
        OverridingCommRateDetail oOverridingCommRateDetail = new OverridingCommRateDetail();
        oOverridingCommRateDetail.setIsDirty(DataConstants.DISPLAY_MODE);
        oOverridingCommRateDetail.setAgrmtORCSeqNbr(new Long(rsSearchCommission.getLong("LAGRMTORCSEQNBR")));
        oOverridingCommRateDetail.setAgrmtRateSeqNbr(new Long(rsSearchCommission.getLong("LAGRMTRATESEQNBR")));
        oOverridingCommRateDetail.setORCRate(new Double(rsSearchCommission.getDouble("DORCRATE")));
        oOverridingCommRateDetail.setProdRangeFrom(new Double(rsSearchCommission.getDouble("DPRODRANGEFROM")));
        oOverridingCommRateDetail.setProdRangeTo(new Double(rsSearchCommission.getDouble("DPRODRANGETO")));
        oOverridingCommRateDetail.setSupDesgnCd(rsSearchCommission.getString("STRSUPDESGNCD"));
        oOverridingCommRateDetail.setProdDesgnCd(rsSearchCommission.getString("STRPRODDESGNCD"));
        oOverridingCommRateDetail.setTsDtUpdated(rsSearchCommission.getTimestamp("DTUPDATED"));
        arrOverridingCommRateDetail.add(oOverridingCommRateDetail);
        count++;
      }
      log.debug("CommissionDAX--After successful completion of query");
      if(count == 0){
        arrOverridingCommRateDetail = null;
      }
    }
    catch(SQLException sqlex){
        log.fatal(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P3054"); //@todo change this error code
    }
    finally
      {
        try
        {
          if(rsSearchCommission != null)
            rsSearchCommission.close();

          if(pstmtSearchCommission != null)
            pstmtSearchCommission.close();
        }
        catch(SQLException sqlex)
        {
          log.fatal(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
      return arrOverridingCommRateDetail;
  }
/**
   * Finds if Overriding Commission Rate exist on a particular Unique Seq no.
   * @return boolean
   * @param a_lAgrmtORCSeqNbr long
   * @param a_strSupDesgnCd String
   * @throws EElixirException
   */
  public boolean validateDesignation(long a_lAgrmtORCSeqNbr, String a_strSupDesgnCd) throws EElixirException
  {
    ResultSet rsValidateCommission = null;
    PreparedStatement pstmtValidateCommission = null;
    try
    {
      String strQuery = getSQLString("Select",CHMConstants.OVERRIDING_COMM_RATE_DESGN_VALIDATE);
      pstmtValidateCommission = getPreparedStatement(strQuery);
      pstmtValidateCommission.setLong(1,a_lAgrmtORCSeqNbr);
      pstmtValidateCommission.setString(2,a_strSupDesgnCd);
      rsValidateCommission = executeQuery(pstmtValidateCommission);
      if(rsValidateCommission.next())
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    catch(SQLException sqlex){
      log.fatal(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P3055");
    }
    finally
    {
      try
      {
        if(rsValidateCommission != null)
          rsValidateCommission.close();

        if(pstmtValidateCommission != null)
          pstmtValidateCommission.close();
      }
      catch(SQLException sqlex)
      {
        log.fatal(sqlex.getMessage());
      throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }
  public void populateDVOs(){
  }

//Amid_Fin_156_Upload Of Commission Dispatch_Starts
  
  /**
   * Searches for Commission Dispatch on given parameters.
   * @param request HttpServletRequest
   * @return String
   * @throws EElixirException
   */

 public String getCommissionDispatch(SearchData oSearchData) throws EElixirException
 {
   PreparedStatement pstmtSearchCommissionDispatch = null;
   Statement st = null ;
   StringBuffer sb = new StringBuffer();
   HashMap hmQueryMap = new HashMap();
   String strLikePrefix = "%";

   try
   {	
     String strAgentCd	= oSearchData.getTask2();  
     String strAgencyBrchCd	= oSearchData.getTask3();
     String nMonth = oSearchData.getTask4();
     String nYear = oSearchData.getTask5();
     String nCommission = oSearchData.getTask6(); 
     String sUserId = oSearchData.getTask7();     
     GregorianCalendar dtDispatch 	= oSearchData.getTaskDate1();     
     String strSearchCommissionDispatchQuery = getSQLString("Select",CHMConstants.COMMISSION_DISPATCH);
     hmQueryMap.put("Main",strSearchCommissionDispatchQuery);
     strSearchCommissionDispatchQuery = " AND strAgencyBrchCd LIKE UPPER(?)" ;
     hmQueryMap.put("strAgencyBrchCd",strSearchCommissionDispatchQuery);
     strSearchCommissionDispatchQuery = " AND strAgentcd LIKE UPPER(?) " ;
     hmQueryMap.put("strAgentcd",strSearchCommissionDispatchQuery);    
     //strSearchCommissionDispatchQuery = " AND dteff = DECODE(?,1,TO_DATE('15'||'-'||?||?,'DD-MON-YYYY'),2,LAST_DAY(TO_DATE(?||?,'MON-YYYY'))) " ;
     strSearchCommissionDispatchQuery = "AND (?=1 AND dtEff >= TO_DATE(? || ? || '01', 'YYYYMONDD') " +
     		                            "AND dtEff <= TO_DATE(? || ? || '15', 'YYYYMONDD') " +
     		                            "OR ?=2 AND dtEff >= TO_DATE(? || ? || '16', 'YYYYMONDD') " +
     		                            "AND dtEff <= LAST_DAY(TO_DATE(? || ? || '01', 'YYYYMONDD')))";	 
     hmQueryMap.put("nCommission",strSearchCommissionDispatchQuery);
     strSearchCommissionDispatchQuery = " AND DTDISPATCH = ? ";
     hmQueryMap.put("dtDispatch",strSearchCommissionDispatchQuery);
     String strQuery = (String)hmQueryMap.get("Main");

     if (strAgencyBrchCd != null && !strAgencyBrchCd.trim().equals("")) {
       strQuery += (String)hmQueryMap.get("strAgencyBrchCd");
     }   
     if (strAgentCd != null && !strAgentCd.equals("")) {
       strQuery += (String)hmQueryMap.get("strAgentcd");
     }    
     if (nCommission != null && !nCommission.trim().equals("")) {
       strQuery += (String)hmQueryMap.get("nCommission");
     } 
     if (dtDispatch != null  && !dtDispatch.toString().trim().equals("")) {
    	 strQuery += (String)hmQueryMap.get("dtDispatch");
     }     
     strQuery += " AND strAgencyBrchCd IN(" +
     		"SELECT a.strLocationCd " +
     		"FROM chm_sec_role_user_loc a, mms_location_m b, chm_sec_user_m c " +
     		"WHERE b.strLocationCd = a.strLocationCd " +
     		"AND a.lUserSeqNbr = c.lUserSeqNbr " +
     		"AND Upper(c.strUserId) = Upper(?) )";
     pstmtSearchCommissionDispatch = getPreparedStatement(strQuery);
    
     int iPosition = 0 ;

     if (strAgencyBrchCd!= null && !strAgencyBrchCd.trim().equals("")) {
       pstmtSearchCommissionDispatch.setString(++iPosition, (strLikePrefix.concat(strAgencyBrchCd.trim())).concat(strLikePrefix) );
      
     }
     if (strAgentCd!= null && !strAgentCd.equals("")) {
	         pstmtSearchCommissionDispatch.setString(++iPosition, (strLikePrefix.concat(strAgentCd.trim())).concat(strLikePrefix) );

       }

     if (nMonth!= null && !nMonth.equals("")) {
        pstmtSearchCommissionDispatch.setShort(++iPosition,Short.parseShort(nCommission.trim()) );
        pstmtSearchCommissionDispatch.setString(++iPosition,nYear.trim() );
        pstmtSearchCommissionDispatch.setString(++iPosition,nMonth.trim() );
        pstmtSearchCommissionDispatch.setString(++iPosition,nYear.trim() );
        pstmtSearchCommissionDispatch.setString(++iPosition,nMonth.trim() );
        pstmtSearchCommissionDispatch.setShort(++iPosition,Short.parseShort(nCommission.trim()) );
        pstmtSearchCommissionDispatch.setString(++iPosition,nYear.trim() );
        pstmtSearchCommissionDispatch.setString(++iPosition,nMonth.trim() );
        pstmtSearchCommissionDispatch.setString(++iPosition,nYear.trim() );
        pstmtSearchCommissionDispatch.setString(++iPosition,nMonth.trim() );        
     }
     if ((dtDispatch != null) && !dtDispatch.equals(""))
     {
    	 pstmtSearchCommissionDispatch.setTimestamp(++iPosition,
             DateUtil.retTimestamp(dtDispatch));
     }
     /**Code changed for SSO userid since SSO ID not present in chm_sec_user_m.
		 * for new uesr we need to fetch from chm_sec_user_Sso_map
		 * Code changed by suma on 06-Aug_2013 Start
		 */
     String strSSOQuery ="Select strssoid From   chm_sec_user_Sso_map Where " +
	     " upper(struserid) = UPPER(?)";
     PreparedStatement pstmt = getPreparedStatement(strSSOQuery);

    pstmt.setString(1,sUserId);

  ResultSet rsMap = pstmt.executeQuery();

   String ssoUserId = null;
  if (rsMap.next())
   {
	  ssoUserId = rsMap.getString("strssoid");
  }
     
    if(ssoUserId !=null && !ssoUserId.equals(""))
    {
    	sUserId = ssoUserId;
       pstmtSearchCommissionDispatch.setString(++iPosition,ssoUserId);
    }
     
    else{
    	 pstmtSearchCommissionDispatch.setString(++iPosition,sUserId);
     }
  
 // Code changed by suma on 06-Aug_2013 End
     ResultSet rsSearch = executeQuery(pstmtSearchCommissionDispatch);
     return XMLConverter.getXMLString(rsSearch);
   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     throw new EElixirException(sqlex, "P3034");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P3034");
   }
   finally
   {
     try
     {
       if(pstmtSearchCommissionDispatch != null)
         pstmtSearchCommissionDispatch.close();
     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3034");
     }
   }
 }
 public String deleteCommissionDispatch(SearchData oSearchData) throws EElixirException
 {
   PreparedStatement pstmtDeleteCommissionDispatch = null;
   Statement st = null ;  
   String flag = "true";
   PreparedStatement pstmCountCommDispatch = null;
    ResultSet rsCountCommDispatch = null;
	int iCount = 0;	
   try
   {   	 
	    GregorianCalendar dtUpload = oSearchData.getTaskDate3();     
	    String strCountCommDispatch = getSQLString("Select",CHMConstants.COUNT_COMMISSION_DISPATCH);  
	    pstmCountCommDispatch = getPreparedStatement(strCountCommDispatch);
		int iPosition = 0 ;        
	     if ((dtUpload != null) && !dtUpload.equals(""))
	     {
	    	 pstmCountCommDispatch.setTimestamp(++iPosition,
	             DateUtil.retTimestamp(dtUpload));
	     } 
	     rsCountCommDispatch = executeQuery(pstmCountCommDispatch);
	     rsCountCommDispatch.next();
		iCount = rsCountCommDispatch.getInt(1);
		log.debug("iCount>>"+iCount);
		if (iCount > 0) {	
			 flag = "true";
			 String strDeleteCommissionDispatchQuery = getSQLString("Delete",CHMConstants.DELETE_COMMISSION_DISPATCH);  
		     pstmtDeleteCommissionDispatch = getPreparedStatement(strDeleteCommissionDispatchQuery);  
		     iPosition = 0;
		     if ((dtUpload != null) && !dtUpload.equals(""))
		     {
		    	 pstmtDeleteCommissionDispatch.setTimestamp(++iPosition,
		             DateUtil.retTimestamp(dtUpload));
		     } 
			 executeUpdate(pstmtDeleteCommissionDispatch); 
			
		} else {
			 flag = "false";
		}
     
     return flag;
   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     throw new EElixirException(sqlex, "P3034");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P3034");
   }
   finally
   {
     try
     {
    	 if (rsCountCommDispatch != null) {
    		 rsCountCommDispatch.close();
		  }

		if (pstmCountCommDispatch != null) {
			pstmCountCommDispatch.close();
		}
       if(pstmtDeleteCommissionDispatch != null)
    	   pstmtDeleteCommissionDispatch.close();
     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, "P3034");
     }
   }
 }
 /**
	 * findSegMent finds whether the Segment is there or not
	 * 
	 * @return boolean
	 * @param rsSearchCommDispatch
	 *            long
	 * @throws EElixirException
	 */
	public boolean findCommDispatchBySeqNo(long a_lCommDispatchSeqNbr)
			throws EElixirException {
		ResultSet rsSearchCommDispatch = null;
		PreparedStatement pstmtFindPrimaryKey = null;

		try {
			String strSelectCommDispatchQuery = getSQLString("Select",
					CHMConstants.FIND_COMMDISPATCH_BY_SEQUENCENO);
			pstmtFindPrimaryKey = getPreparedStatement(strSelectCommDispatchQuery);
			pstmtFindPrimaryKey.setLong(1, a_lCommDispatchSeqNbr);
			rsSearchCommDispatch = executeQuery(pstmtFindPrimaryKey);
			if (rsSearchCommDispatch.next()) {
				log.debug("inside if before return");
				return true;
			} else {
				return false;
			}
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, "P8138");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8138");
		} finally {
			try {
				if (rsSearchCommDispatch != null) {
					rsSearchCommDispatch.close();
				}

				if (pstmtFindPrimaryKey != null) {
					pstmtFindPrimaryKey.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}
	/**
	 * Updates the Commission Dispatch 
	 * @return int No of rows updated
	 * @param: a_oCommDispatchResult CommDispatchResult
	 * @throws EElixirException
	 */
	public int updateCommDispatch(CommDispatchResult a_oCommDispatchResult)
			throws EElixirException {
		PreparedStatement pstmtUpdateCommDispatch = null;
		log.debug("inside updateCommDispatch");

		try {
			
			String strUpdateQuery = getSQLString("Update",CHMConstants.COMMDISPATCH_UPDATE);
			pstmtUpdateCommDispatch = getPreparedStatement(strUpdateQuery);			
			String strPmtMode = a_oCommDispatchResult.getModePayment();
			String strInstrNbr = a_oCommDispatchResult.getAccNo();
			String strInFavourOf = a_oCommDispatchResult.getFavourOf();
			String strDispachAmt = a_oCommDispatchResult.getAmtDispatch();
			String strBankName = a_oCommDispatchResult.getBankName();
			String strDispatchMode = a_oCommDispatchResult.getModeOfDispatch();
			String strRemarks = a_oCommDispatchResult.getRemarks();
			String strAwbNum = a_oCommDispatchResult.getAwbNum();
			String strUpdatedBy = a_oCommDispatchResult.getUserId();
			GregorianCalendar dtDispatch=a_oCommDispatchResult.getDispatch();
			long lCommDispatchSeqNbr = a_oCommDispatchResult.getCommDispatchSeqno().longValue();	
			pstmtUpdateCommDispatch.setString(1, strPmtMode);
			pstmtUpdateCommDispatch.setString(2, strInstrNbr);
			pstmtUpdateCommDispatch.setString(3, strInFavourOf);
			pstmtUpdateCommDispatch.setString(4, strDispachAmt);
			pstmtUpdateCommDispatch.setString(5, strBankName);
			pstmtUpdateCommDispatch.setString(6, strDispatchMode);
			pstmtUpdateCommDispatch.setString(7, strRemarks);
			pstmtUpdateCommDispatch.setString(8, strAwbNum);
			pstmtUpdateCommDispatch.setTimestamp(9, DateUtil.retTimestamp(dtDispatch));			
			pstmtUpdateCommDispatch.setLong(10, lCommDispatchSeqNbr);

			int iUpdate = executeUpdate(pstmtUpdateCommDispatch);
			return iUpdate;
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException(sqlex, "P8141");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8141");
		} finally {
			try {
				if (pstmtUpdateCommDispatch != null) {
					pstmtUpdateCommDispatch.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}

//Amid_Fin_156_Upload Of Commission Dispatch_Ends

//<!--sunaina_Commision_Dispatch_CR_Started-->	
	 public CommDispatchResult searchGetLocationCd(String strUserId)throws 
	  RemoteException, FinderException, EElixirException
	  {
		 ResultSet rsSearchdtRecepit = null;
	       PreparedStatement _pstmtSearchdtRecepit = null;
	       CommDispatchResult  oCommDispatchResult = null;
		   ArrayList alLocCode=null;
		   ArrayList alLocDesc = null;
		   HashMap hmLocation=null;
		  

	       try
	       {
	    	   oCommDispatchResult = new CommDispatchResult();
	    	   alLocCode=new ArrayList();
	    	   alLocDesc=new ArrayList();
	    	   hmLocation = new HashMap();
	         String strSelectSearchdtRecepit = getSQLString("Select",CHMConstants.FIND_LOCATION_CODE);
	         _pstmtSearchdtRecepit = getPreparedStatement(strSelectSearchdtRecepit);
	         
	         /**Code changed for SSO userid since SSO ID not present in chm_sec_user_m.
				 * for new uesr we need to fetch from chm_sec_user_Sso_map
				 * Code changed by suma on 06-Aug_2013 Start
				 */
	         String ssoUserId =null;
	         String strSSOQuery ="Select strssoid From   chm_sec_user_Sso_map Where " +
 		     " upper(struserid) = UPPER(?)";
	         PreparedStatement pstmt = getPreparedStatement(strSSOQuery);
				 
				 pstmt.setString(1,strUserId);
				 
				 ResultSet rsMap = pstmt.executeQuery();
					
					
					if (rsMap.next())
					{
						ssoUserId = rsMap.getString("strssoid");
					}
	         
	         
	         if(ssoUserId !=null && !ssoUserId.equals(""))
	         {
	        	 _pstmtSearchdtRecepit.setString(1,ssoUserId);
	         }else
	         {
	           _pstmtSearchdtRecepit.setString(1,strUserId);
	         }
	         
	      // Code changed by suma on 06-Aug_2013 End
			 log.debug(" iInstrCatCd *********" + strUserId);
	         log.debug("Standard Query for getting Designations is "+strSelectSearchdtRecepit);
			 rsSearchdtRecepit = executeQuery(_pstmtSearchdtRecepit);
	         while(rsSearchdtRecepit.next())
	         {
	           log.debug("\n inside if of resultset.next method code is "+rsSearchdtRecepit.getString("strLocationCd"));
	           alLocCode.add(rsSearchdtRecepit.getString("strLocationCd"));
	           log.debug("\n inside if of resultset.next method description is "+rsSearchdtRecepit.getString("strLocationName"));
	           alLocDesc.add(rsSearchdtRecepit.getString("strLocationName"));
	           hmLocation.put("Code",alLocCode);
	           hmLocation.put("Description",alLocDesc);
	        }
	         log.debug("\n Outside loop printing ArrayList "+alLocCode.size());
	         oCommDispatchResult.setLocationCOde(hmLocation);
	         
	         
	         log.debug("\n Before Returing printing ArrayList "+oCommDispatchResult.getLocationCOde());
	       
	        return oCommDispatchResult;

	       }
	       catch(SQLException sqlex)
	       {
	         throw new EElixirException(sqlex,"P8446");
	       }
	       finally
	       {
	         try
	         {
	           if(rsSearchdtRecepit != null)
	        	   rsSearchdtRecepit.close();

	           if(rsSearchdtRecepit != null)
	        	   rsSearchdtRecepit.close();
	         }
	         catch(SQLException sqlex)
	           {
	             throw new EElixirException(sqlex,"P8446");
	           }
	         }
	  }
//<!--sunaina_Commision_Dispatch_CR_ENDED-->
//	Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Starts
	 public ArrayList getCommRuleList(String a_cChannelType)
     throws EElixirException
 {
     ResultSet rsSearchCommRuleList = null;
     PreparedStatement _pstmtFindPrimaryKey = null;
     ArrayList _oCommRuleList = new ArrayList();
     OverrideCommRuleResult _oOverrideCommRuleResult = null;
     try
     {
         log.debug("Commission Dax--in getCommRuleList FOR Channel :---Starts " +
             a_cChannelType);

         String strSelectSubChannelQuery = getSQLString("Select",
                 CHMConstants.FIND_COMM_RULELIST_BY_CHANNELTYPE);
         log.debug(strSelectSubChannelQuery);

         if (_pstmtFindPrimaryKey == null)
         {
             _pstmtFindPrimaryKey = getPreparedStatement(strSelectSubChannelQuery);
         }

         log.debug(_pstmtFindPrimaryKey + "");
         _pstmtFindPrimaryKey.setString(1, a_cChannelType);

         rsSearchCommRuleList = executeQuery(_pstmtFindPrimaryKey);

         while (rsSearchCommRuleList.next())
         {
        	 _oOverrideCommRuleResult = new OverrideCommRuleResult();          
        	 
        	 _oOverrideCommRuleResult.setChannelType(a_cChannelType);
        	 _oOverrideCommRuleResult.setCommRuleOverSeqNbr(new Long (rsSearchCommRuleList.getLong(1)));
        	 _oOverrideCommRuleResult.setAgencyCode(rsSearchCommRuleList.getString(2));
        	 _oOverrideCommRuleResult.setProdCode(rsSearchCommRuleList.getString(3));
           	 _oOverrideCommRuleResult.setStatusFlag(DataConstants.UPDATE_MODE);
           	
        	 _oOverrideCommRuleResult.setEffFrom(DateUtil.retGregorian(rsSearchCommRuleList.getTimestamp(4)));             
        	 _oOverrideCommRuleResult.setEffTo(DateUtil.retGregorian(rsSearchCommRuleList.getTimestamp(5)));
        	 _oOverrideCommRuleResult.setTsDtUpdated(rsSearchCommRuleList.getTimestamp(
                     6));
        	 _oOverrideCommRuleResult.setAgencyName(rsSearchCommRuleList.getString(7));
             _oCommRuleList.add(_oOverrideCommRuleResult);
             log.debug("Commission Dax--in getCommRuleList FOR Channel :---Ends "); 
         }
         return _oCommRuleList;
     }
     catch (SQLException sqlex)
     {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, "dec204");
     }
     catch (EElixirException eex)
     {
         log.exception(eex.getMessage());
         throw new EElixirException(eex, "dec204");
     }
     finally
     {
         try
         {
             if (_pstmtFindPrimaryKey != null)
             {
                 _pstmtFindPrimaryKey.close();
             }
         }
         catch (SQLException sqlex)
         {
             log.exception(sqlex.getMessage());
             throw new EElixirException(sqlex, "dec204");
         }
     }
 }
	 
	 /**
		 * For finding Records by Primary Key
		 *
		 * @param a_lOverrideCommMasterseqnbr
		 * @return Boolean
		 * @throws EElixirException
		 *             Anup Kumar
		 */
		public boolean findOverrideCommMaster(long a_lOverrideCommmasterseqnbr)
				throws EElixirException {
			ResultSet rsDltOverrideCommMaster = null;
			PreparedStatement pstmtFindPrimaryKey = null;

			try {
				String strSelectBenefitQuery = getSQLString("Select",
						CHMConstants.FIND_COMM_RULE_BY_PRIMARYKEY);
				log.debug("strSelectBenefitQuery>>"+strSelectBenefitQuery);

				if (pstmtFindPrimaryKey == null) {
					pstmtFindPrimaryKey = getPreparedStatement(strSelectBenefitQuery);
				}

				pstmtFindPrimaryKey.setLong(1, a_lOverrideCommmasterseqnbr);
				rsDltOverrideCommMaster = executeQuery(pstmtFindPrimaryKey);

				if (rsDltOverrideCommMaster.next()) {
					return true;
				} else {
					return false;
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "dec205");
			} catch (EElixirException eex) {
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "dec205");
			} finally {
				try {
					if (rsDltOverrideCommMaster != null) {
						rsDltOverrideCommMaster.close();
					}

					if (pstmtFindPrimaryKey != null) {
						pstmtFindPrimaryKey.close();
					}
				} catch (SQLException sqlex) {
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}
		
		/**
		 * For Inserting Values into CHM_OverrideComm_M
		 *
		 * @param a_oOverrideCommResult
		 * @return lOverrideCommseqnbr
		 * @throws EElixirException
		 * @author Anup Kumar
		 */
		public Long createOverrideCommMaster(OverrideCommRuleResult a_oOverrideCommResult) throws EElixirException {

			PreparedStatement pstmtCreateOverrideCommMaster = null;
			Long lOverrideCommseqnbr;
			log.debug("inside ---> createOverrideCommMaster--Starts");
			try {
				String strInsertOverrideCommQuery = getSQLString("Insert",
						CHMConstants.COMM_RULE_MASTER_INSERT);
				log.debug("strInsertOverrideCommQuery --->>"+strInsertOverrideCommQuery);
				pstmtCreateOverrideCommMaster = getPreparedStatement(strInsertOverrideCommQuery);
				lOverrideCommseqnbr = getNextOverrideCommSeqNbr();
				int iPos = 0;			
				pstmtCreateOverrideCommMaster.setLong(++iPos, lOverrideCommseqnbr.longValue());	
				pstmtCreateOverrideCommMaster.setString(++iPos, a_oOverrideCommResult
						.getChannelType());				
				pstmtCreateOverrideCommMaster
						.setString(++iPos, a_oOverrideCommResult.getAgencyCode());			
				pstmtCreateOverrideCommMaster.setString(++iPos, a_oOverrideCommResult.getProdCode());				
				pstmtCreateOverrideCommMaster.setTimestamp(++iPos, DateUtil
						.retTimestamp(a_oOverrideCommResult.getEffFrom()));				
				pstmtCreateOverrideCommMaster.setTimestamp(++iPos, DateUtil
						.retTimestamp(a_oOverrideCommResult.getEffTo()));				
				pstmtCreateOverrideCommMaster.setString(++iPos, a_oOverrideCommResult.getUserId());                
				executeUpdate(pstmtCreateOverrideCommMaster);
				log.debug("inside ---> createOverrideCommMaster--Ends");
				return lOverrideCommseqnbr;

			} catch (SQLException sqlex) {
				sqlex.printStackTrace();
				log.fatal(sqlex.getMessage());
				throw new EElixirException(sqlex, "dec206");
			} catch (EElixirException eex) {
				eex.printStackTrace();
				log.fatal(eex.getMessage());
				throw new EElixirException(eex, "dec206");
			} finally {

				try {
					if (pstmtCreateOverrideCommMaster != null) {
						pstmtCreateOverrideCommMaster.close();
					}
				}

				catch (SQLException sqlex) {
					sqlex.printStackTrace();
					log.fatal(sqlex.getMessage());
					throw new EElixirException(sqlex, "dec206");
				}

			}

		}		
		
		/**
		 * For Getting next Sequence No. for Override Commission Rule Channel Type Master
		 * @return SeqNo
		 * @throws EElixirException
		 * @author Anup Kumar
		 */
		public Long getNextOverrideCommSeqNbr() throws EElixirException {
			Statement stmtNextSeqOverrideComm = null;
			long lSeqNo;

			try {
				log.debug("getNextOverrideCommSeqNbr---> Starts");
				String strNextSeqQuery = getSQLString("Select",
						CHMConstants.COMM_RULE_MASTER_SEQUENCENO);

				stmtNextSeqOverrideComm = getStatement();

				ResultSet rsSeqNo = stmtNextSeqOverrideComm.executeQuery(strNextSeqQuery);
				rsSeqNo.next();
				lSeqNo = rsSeqNo.getLong(1);
				log.debug(lSeqNo + "");

				return new Long(lSeqNo);
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P9006");
			} catch (EElixirException eex) {
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9006");
			} finally {
				try {
					if (stmtNextSeqOverrideComm != null) {
						stmtNextSeqOverrideComm.close();
					}
				} catch (SQLException sqlex) {
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}		
	
		/**
		 * For Getting ResultSet on the basis of a_lOverrideCommSeqNbr 
		 * for Override Commission Rule Channel Type Master
		 * @return OverrideCommRuleResult
		 * @throws EElixirException
		 * @author Anup Kumar
		 */
	public OverrideCommRuleResult getSearchOverrideCommMaster(long a_lOverrideCommSeqNbr)
	throws EElixirException {
	PreparedStatement _psSearchParameter = null;	
	ResultSet rsSearchParameter = null;	
	OverrideCommRuleResult oOverrideCommResult = new OverrideCommRuleResult();
	ArrayList alOverrideCommMaster = new ArrayList();
	try {
		String strSelectOverrideCommMaster = getSQLString("Select",
				CHMConstants.COMM_RULE_MASTER_RESULT_BY_SEQNO);
		log.debug("strSelectOverrideCommMaster>>"+strSelectOverrideCommMaster);
		
		_psSearchParameter = getPreparedStatement(strSelectOverrideCommMaster);

		_psSearchParameter.setLong(1, a_lOverrideCommSeqNbr);

		rsSearchParameter = executeQuery(_psSearchParameter);

		if (rsSearchParameter.next()) {
			
			oOverrideCommResult.setCommRuleOverSeqNbr(new Long(rsSearchParameter
					.getLong("LCOMMRULEOVERSEQNBR")));

			oOverrideCommResult.setChannelType(rsSearchParameter
					.getString("CHANNELTYPE"));

			oOverrideCommResult.setAgencyCode(rsSearchParameter
					.getString("STRAGENTCD"));

			oOverrideCommResult.setAgencyName(null);
			/*
			oCbpResult.setAgencyName(rsSearchParameter
					.getString("AGENCYNAME"));
					*/
			oOverrideCommResult.setProdCode(rsSearchParameter.getString("STRPRODCD"));
			
			if (rsSearchParameter.getTimestamp("DTEFFFROM") != null) {
				oOverrideCommResult.setEffFrom(DateUtil
						.retGregorian(rsSearchParameter
								.getTimestamp("DTEFFFROM")));

			} else {
				oOverrideCommResult.setEffFrom(null);
			}

			if (rsSearchParameter.getTimestamp("DTEFFTO") != null) {
				oOverrideCommResult.setEffTo(DateUtil
						.retGregorian(rsSearchParameter
								.getTimestamp("DTEFFTO")));

			} else {
				oOverrideCommResult.setEffTo(null);
			}

			oOverrideCommResult.setStatusFlag(DataConstants.UPDATE_MODE);

			if (rsSearchParameter.getTimestamp("DTUPDATED") != null) {
				oOverrideCommResult.setTsDtUpdated(rsSearchParameter
						.getTimestamp("DTUPDATED"));
			} else {
				oOverrideCommResult.setTsDtUpdated(null);
			}
		}
		return oOverrideCommResult;
	} catch (SQLException sqlex) {
		log.fatal(getClass().getName(), "getSearchOverrideCommMaster", sqlex
				.getMessage());
		throw new EElixirException(sqlex, "dec207");
	} catch (EElixirException eex) {
		log.fatal(getClass().getName(), "getSearchOverrideCommMaster", eex
				.getMessage());
		throw new EElixirException(eex, "dec207");
	} finally {
		try {
			if (_psSearchParameter != null) {
				_psSearchParameter.close();
			}
		} catch (SQLException sqlex) {
			log.fatal(getClass().getName(), "getSearchOverrideCommMaster", sqlex
					.getMessage());
			throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
		}
	}
}
	
	    /**
		 * For Updating records of
		 * Override Commission Rule Channel Type Master
		 * @return OverrideCommRuleResult
		 * @throws EElixirException
		 * @author Anup Kumar
		 */
	public int updateOverrideCommMaster(OverrideCommRuleResult _oOverrideCommResult) throws EElixirException {

		PreparedStatement pstmtUpdateOverrideCommMaster = null;

		try {
			String strUpdateQuery = getSQLString("Update",
					CHMConstants.COMM_RULE_MASTER_UPDATE);
			pstmtUpdateOverrideCommMaster = getPreparedStatement(strUpdateQuery);

			Long lOverrideCommSeqNbr = _oOverrideCommResult.getCommRuleOverSeqNbr();
			String strChannelType = _oOverrideCommResult.getChannelType();
			String strAgencyCode = _oOverrideCommResult.getAgencyCode();

			String strProdCode = _oOverrideCommResult.getProdCode();		
			Timestamp strDtEffFrom = DateUtil.retTimestamp(_oOverrideCommResult
					.getEffFrom());
			Timestamp strDtEffTo = DateUtil.retTimestamp(_oOverrideCommResult
					.getEffTo());
			String strUpdatedBy = _oOverrideCommResult.getUserId();

			log.debug("CommissionDAX--for override commission Before update "
					+ strChannelType + " " + strAgencyCode + " " + strProdCode
				    + " " + strDtEffFrom + " " + strDtEffTo
					+ " " + strUpdatedBy);
			pstmtUpdateOverrideCommMaster.setString(1, strChannelType);
			pstmtUpdateOverrideCommMaster.setString(2, strAgencyCode);
			pstmtUpdateOverrideCommMaster.setString(3, strProdCode);			
			pstmtUpdateOverrideCommMaster.setTimestamp(4, strDtEffFrom);
			pstmtUpdateOverrideCommMaster.setTimestamp(5, strDtEffTo);
			pstmtUpdateOverrideCommMaster.setString(6, strUpdatedBy);
			pstmtUpdateOverrideCommMaster.setLong(7, lOverrideCommSeqNbr.longValue());

			int iUpdate = executeUpdate(pstmtUpdateOverrideCommMaster);
			return iUpdate;
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, "dec208");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "dec208");
		} finally {
			try {
				if (pstmtUpdateOverrideCommMaster!= null) {
					pstmtUpdateOverrideCommMaster.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}

	 /**
	 * For Deleting records of
	 * Override Commission Rule Channel Type Master
	 * @return OverrideCommRuleResult
	 * @throws EElixirException
	 * @author Anup Kumar
	 */
	public int deleteOverrideCommMaster(OverrideCommRuleResult oOverrideCommResult) throws EElixirException {
		PreparedStatement _pstmtOverrideCommMaster = null;
		try {

			String strdeleteOverrideComm= getSQLString("Delete",
					CHMConstants.COMM_RULE_MASTER_DELETE);

			_pstmtOverrideCommMaster = getPreparedStatement(strdeleteOverrideComm);
			_pstmtOverrideCommMaster.setLong(1, oOverrideCommResult.getCommRuleOverSeqNbr().longValue());
			int iRemoveOverrideCommMaster = executeUpdate(_pstmtOverrideCommMaster);

			return iRemoveOverrideCommMaster;
		} catch (SQLException sqlex) {			
			log.exception(sqlex.getMessage());
			throw new EElixirException("dec209");
		} catch (EElixirException eex) {			
			log.exception(eex.getMessage());
			throw new EElixirException("dec209");
		} finally {
			try {
				if (_pstmtOverrideCommMaster != null) {
					_pstmtOverrideCommMaster.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "dec209");
			}
		}
	}
	
	
	 public String searchProdCodeExists(String strAgencyCode, String strProdCd,String dtEffFrom)
     throws EElixirException
     {      
	    PreparedStatement pstmt= null;
	    PreparedStatement pstmttemp= null;
	 	ResultSet rsSearch = null;
	 	String strSelSql =null;
	 	String a_oSearchRecord =null;	 	
	 	GregorianCalendar dtEffFromtemp = DateUtil.retGCDate(dtEffFrom) ;
	 	Timestamp strDtEffFrom = DateUtil.retTimestamp(dtEffFromtemp);
	 	int count = 0;
	 	
     try
     {       
         log.debug("searchProdCodeExists ---> starts");
         strSelSql = getSQLString("Select",CHMConstants.CHECK_VALID_PRODCD);
         log.debug("strSelSql :"+strSelSql);
         if(pstmttemp == null)
         {
        	 pstmttemp = getPreparedStatement(strSelSql);
         }	 
         log.debug("pstmttemp ---> pstmttemp");
         pstmttemp.setString(1,strProdCd.toUpperCase());
         rsSearch =executeQuery(pstmttemp);       
      
         if (rsSearch.next()) {        	
          count = rsSearch.getInt("ROWCOUNT1");          
         }        
         log.debug("query : "+strSelSql);
      
         strSelSql = getSQLString("Select",
                 CHMConstants.CHECK_PRODCODE_EXISTS);
         		log.debug(strSelSql);
	         if (pstmt == null)
	         {
	        	 pstmt = getPreparedStatement(strSelSql);
	         }	        
          pstmt.setString(1, strProdCd.toUpperCase());
          pstmt.setString(2, strAgencyCode.toUpperCase());
          pstmt.setTimestamp(3, strDtEffFrom);
          log.debug("strDtEffFrom: "+ strDtEffFrom);
          rsSearch = executeQuery(pstmt);   
          log.debug("Query executed Successfully");
          a_oSearchRecord = XMLConverter.getXMLString(rsSearch);
          a_oSearchRecord = XMLConverter.addTaginXML(a_oSearchRecord,"ROWCOUNT1",""+count);         
         
         log.debug("a_oSearchRecord: "+a_oSearchRecord);
     }
     catch (SQLException sqlex)
     {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, "dec210");
     }
     catch (EElixirException eex)
     {
         log.exception(eex.getMessage());
         throw new EElixirException(eex, "dec210");
     }
     finally
     {
         try
         {
             if (pstmt != null)
             {
            	 pstmt.close();
             }
             if (pstmttemp != null)
             {
            	 pstmttemp.close();
             }
         }
         catch (SQLException sqlex)
         {
             log.exception(sqlex.getMessage());
             throw new EElixirException(sqlex, "dec210");
         }
     }
     return a_oSearchRecord ;
 }
	
//	Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Ends
/*
  *  Member variables
*/
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Starts
  public CollectionParamResult saveCollectionParams(CollectionParamResult collectionParamResult) {
		PreparedStatement _pstmtCollectionParams = null;
		try {
				String strUpdateCollectionParam= getSQLString("Update",CHMConstants.COLLECTION_PARAM_UPDATE);
				_pstmtCollectionParams = getPreparedStatement(strUpdateCollectionParam);
				
				_pstmtCollectionParams.setLong(1, collectionParamResult.get_nStatus());				
				_pstmtCollectionParams.setString(2,collectionParamResult.get_strUpdatedBy());
				_pstmtCollectionParams.setLong(3, collectionParamResult.get_nIsActive());				
				_pstmtCollectionParams.setLong(4,collectionParamResult.get_nOldStatus());
				_pstmtCollectionParams.setLong(5,collectionParamResult.get_nOverideBonusProcessed());

				if (collectionParamResult.get_nIsActive()== 5){
					_pstmtCollectionParams.setLong(1, collectionParamResult.get_nStatus());
					_pstmtCollectionParams.setLong(4,collectionParamResult.get_nStatus());
					
				}
				if (collectionParamResult.get_nIsActive()== 10){
					_pstmtCollectionParams.setLong(1, collectionParamResult.get_nOldStatus());
					_pstmtCollectionParams.setLong(4,collectionParamResult.get_nOldStatus());
				}
				
				int iUpdateCollectionParam = executeUpdate(_pstmtCollectionParams);
				//If iUpdateCollectionParam = 0 then insert an entry into table
				if(iUpdateCollectionParam == 0){
					_pstmtCollectionParams = null;
					 String strInsertCollectionParam= getSQLString("Insert",CHMConstants.COLLECTION_PARAM_INSERT);				 
					_pstmtCollectionParams = getPreparedStatement(strInsertCollectionParam);
					_pstmtCollectionParams.setString(1,CHMConstants.COLLECTION_PARAM_FLAG);
					//The status would initially be pending.
					_pstmtCollectionParams.setLong(2, collectionParamResult.get_nStatus());
					//The status would initially be not processed i.e. 2.
					_pstmtCollectionParams.setLong(3, 2);					
					_pstmtCollectionParams.setString(4, collectionParamResult.get_strCreatedBy());
					//The status would initially be pending i.e 1.
					_pstmtCollectionParams.setLong(5, collectionParamResult.get_nIsActive());					
					_pstmtCollectionParams.setLong(6, collectionParamResult.get_nStatus());
					executeUpdate(_pstmtCollectionParams);
				}
			}catch (SQLException e) {
				e.printStackTrace();
				log.exception(e.getMessage());			
			} catch (EElixirException e) {
				e.printStackTrace();
				log.exception(e.getMessage());	
			}
			return getCollectionParams();
		}

	public CollectionParamResult getCollectionParams() {
		PreparedStatement _pstmtCollectionParams = null;
		ResultSet _rsCollectionParam = null;
		CollectionParamResult collectionParamResult = new CollectionParamResult();;
		
		try {
				String strSelectCollectionParam= getSQLString("Select",CHMConstants.COLLECTION_PARAM_SELECT);
				_pstmtCollectionParams = getPreparedStatement(strSelectCollectionParam);				
				_rsCollectionParam = executeQuery(_pstmtCollectionParams);
				while(_rsCollectionParam.next()){
					collectionParamResult.set_nStatus(_rsCollectionParam.getShort("NSTATUS"));
					collectionParamResult.set_nOverideBonusProcessed(_rsCollectionParam.getShort("NISPROCESS"));
					collectionParamResult.set_nIsActive(_rsCollectionParam.getShort("NISACTIVE"));
					collectionParamResult.set_strDtUpdated(_rsCollectionParam.getString("DTUPDATED"));
					collectionParamResult.set_strUpdatedBy(_rsCollectionParam.getString("STRUPDATEDBY"));
					collectionParamResult.setDtBonusBatchRun(_rsCollectionParam.getDate("DTBUSINESSUPD"));
					collectionParamResult.set_nOldStatus(_rsCollectionParam.getShort("NOLDSTATUS"));
				}
			}catch (EElixirException e) {
				e.printStackTrace();
				log.exception(e.getMessage());	
			} catch (SQLException e) {
				e.printStackTrace();
				log.exception(e.getMessage());
			}
			return collectionParamResult;
	}

	// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Ends

	// Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Starts
	public ArrayList getDisbursementSetup() throws EElixirException {
		PreparedStatement _pstmtDisbumSetupDtls = null;
		ResultSet _rsDisbumSetupDtls = null;
		DisbursementSetupResult oDisbursementSetup = null;
		ArrayList arrDisbursementSetup = new ArrayList(10);

		try {
			log.debug("CommissionDAX--getDisbursementSetup--Starts");
			String strSelectDisbumSetupDtls = getSQLString("Select",
					CHMConstants.DISBURSEMENT_SETUP_SELECT);
			log.debug("The Commission Dax Query for Fetching Disbursement Details:::::::::::"+strSelectDisbumSetupDtls);
			_pstmtDisbumSetupDtls = getPreparedStatement(strSelectDisbumSetupDtls);
			_rsDisbumSetupDtls = executeQuery(_pstmtDisbumSetupDtls);
			while (_rsDisbumSetupDtls.next()) {
				oDisbursementSetup = new DisbursementSetupResult();
				oDisbursementSetup.setnPaymentMthd(_rsDisbumSetupDtls
						.getInt("nPaymentMthd"));
				oDisbursementSetup.setdDisbumAmntLmt(_rsDisbumSetupDtls
						.getDouble("strDisbumAmntLmt"));
				oDisbursementSetup.setStrDisbumSeq(_rsDisbumSetupDtls
						.getLong("ldisbumseq"));
				arrDisbursementSetup.add(oDisbursementSetup);
				log.debug("CommissionDAX--getDisbursementSetup--Ends");
			}
		} catch (EElixirException e) {
			e.printStackTrace();
			log.exception(e.getMessage());
		} catch (SQLException e) {
			e.printStackTrace();
			log.exception(e.getMessage());
		}
		return arrDisbursementSetup;
	}

	public void updateDisbumSetup(
			DisbursementSetupResult a_oDisbursementSetupResult)
			throws EElixirException {
		PreparedStatement pstmtUpdateDsbmSetup = null;
		PreparedStatement _pstmtDisbumSetupDtls = null;
		ResultSet _rsDisbumSetupDtls = null;
		int iPaymentMthd =0 ;
		double dDisbumAmntLmtForSeq = 0.0;
		// Statement st = null ;
		// StringBuffer sb = new StringBuffer();
		int icount = 0;
		try {
			log.debug("CommissionDAX--updateDisbumSetup--Starts");
			int nPmtMthd = a_oDisbursementSetupResult.getnPaymentMthd();
			double dDisbumAmntLmt = a_oDisbursementSetupResult
					.getdDisbumAmntLmt();
			Long lDisbumSeq = a_oDisbursementSetupResult.getStrDisbumSeq();
			String strUpdatedBy = a_oDisbursementSetupResult.get_strUpdatedBy();
			String strDisbumSetupDtlsForSeq = getSQLString("Select",
					CHMConstants.DISBURSEMENT_SETUP_SELECT_FOR_PMT);
			log.debug("The Commission Dax Query for Fetching Disbursement Details in Update:::::::::::"+strDisbumSetupDtlsForSeq);
			_pstmtDisbumSetupDtls = getPreparedStatement(strDisbumSetupDtlsForSeq);
			_pstmtDisbumSetupDtls.setLong(1, lDisbumSeq);
			_rsDisbumSetupDtls = executeQuery(_pstmtDisbumSetupDtls);
			while (_rsDisbumSetupDtls.next()) {
				iPaymentMthd = _rsDisbumSetupDtls.getInt("nPaymentMthd");
				dDisbumAmntLmtForSeq = _rsDisbumSetupDtls.getDouble("strDisbumAmntLmt");
				
			}
			if(!((iPaymentMthd==nPmtMthd)&&(dDisbumAmntLmtForSeq==dDisbumAmntLmt))){
				String strUpdateQuery = getSQLString("Update",
						CHMConstants.DISBURSEMENT_SETUP_UPDATE);
				log.debug("The Commission Dax Query for Updating Disbursement Details:::::::::::"+strUpdateQuery);
				pstmtUpdateDsbmSetup = getPreparedStatement(strUpdateQuery);
				pstmtUpdateDsbmSetup.setInt(1, nPmtMthd);
				pstmtUpdateDsbmSetup.setInt(2, nPmtMthd);
				pstmtUpdateDsbmSetup.setDouble(3, dDisbumAmntLmt);
				pstmtUpdateDsbmSetup.setString(4, strUpdatedBy);
				pstmtUpdateDsbmSetup.setLong(5, lDisbumSeq);
				icount = executeUpdate(pstmtUpdateDsbmSetup);	
			}
			
			log.debug("CommissionDAX--updateDisbumSetup--Ends");
		} catch (SQLException sqlex) {
			log.fatal(sqlex.getMessage());
			throw new EElixirException(sqlex, "P3050");
		} finally {
			try {
				if (pstmtUpdateDsbmSetup != null)
					pstmtUpdateDsbmSetup.close();
			} catch (SQLException sqlex) {
				log.fatal(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}

	public void insertDisbumSetup(
			DisbursementSetupResult a_oDisbursementSetupResult)
			throws EElixirException {

		PreparedStatement pstmtInsertDisbumSetup = null;
		try {
			log.debug("CommissionDAX--insertDisbumSetup--Starts");
			String strInsertDisbumSetup = getSQLString("Insert",
					CHMConstants.DISBURSEMENT_SETUP_INSERT);
			log.debug("The Commission Dax Query for Inserting Disbursement Details:::::::::::" + strInsertDisbumSetup);
			pstmtInsertDisbumSetup = getPreparedStatement(strInsertDisbumSetup);
			int iPos = 0;
			pstmtInsertDisbumSetup.setInt(++iPos,
					a_oDisbursementSetupResult.getnPaymentMthd());
			pstmtInsertDisbumSetup.setInt(++iPos,
					a_oDisbursementSetupResult.getnPaymentMthd());
			pstmtInsertDisbumSetup.setDouble(++iPos,
					a_oDisbursementSetupResult.getdDisbumAmntLmt());
			pstmtInsertDisbumSetup.setString(++iPos,
					a_oDisbursementSetupResult.get_strUpdatedBy());
			executeUpdate(pstmtInsertDisbumSetup);
			log.debug("CommissionDAX--insertDisbumSetup--Ends");
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			log.fatal(sqlex.getMessage());
			throw new EElixirException(sqlex, "dec206");
		} catch (EElixirException eex) {
			eex.printStackTrace();
			log.fatal(eex.getMessage());
			throw new EElixirException(eex, "dec206");
		} finally {

			try {
				if (pstmtInsertDisbumSetup != null) {
					pstmtInsertDisbumSetup.close();
				}
			}

			catch (SQLException sqlex) {
				sqlex.printStackTrace();
				log.fatal(sqlex.getMessage());
				throw new EElixirException(sqlex, "dec206");
			}

		}

	}

	public int deleteDisbumSetup(
			DisbursementSetupResult a_oDisbursementSetupResult)
			throws EElixirException {
		PreparedStatement _pstmtdeleteDisbumSetup = null;
		try {
			log.debug("CommissionDAX--deleteDisbumSetup--Starts");
			String strdeleteDisbumSetup = getSQLString("Delete",
					CHMConstants.DISBURSEMENT_SETUP_DELETE);
			log.debug("The Commission Dax Query for Deleting Disbursement Details:::::::::::" + strdeleteDisbumSetup);
			_pstmtdeleteDisbumSetup = getPreparedStatement(strdeleteDisbumSetup);
			_pstmtdeleteDisbumSetup.setLong(1,
					a_oDisbursementSetupResult.getStrDisbumSeq());
			int ideleteDisbumSetup = executeUpdate(_pstmtdeleteDisbumSetup);
			log.debug("CommissionDAX--deleteDisbumSetup--Ends");
			return ideleteDisbumSetup;
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());
			throw new EElixirException("dec209");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException("dec209");
		} finally {
			try {
				if (_pstmtdeleteDisbumSetup != null) {
					_pstmtdeleteDisbumSetup.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "dec209");
			}
		}
	}

	// Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Ends
}
