/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Finder Fees
*  FILENAME			: FinderFeesDAX.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: November 10, 2004
*  COMPANY			: Mastek Ltd.
 *  COPYRIGHT                        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY           REASON
 *-------------------------------------------------------------------------------- 
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.dax;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionRatesDetails;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;


/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the FinderFees object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class FinderFeesDAX extends DAX
{
	/*
	*  Member variables
	*/
	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	/**
	 * Constructor
	 */
	public FinderFeesDAX()
	{
	}
    
    
	//added by shameem shaik
	/**
		 * Populates the resultset into XML string object
		 * @param a_oResultObject Object
		 * @return XML string object
		 * @throws EElixirException
	 */
    
	public String getFinderFees(SearchData a_oResultObject) throws EElixirException
		{
			log.debug("FinderFeesDAX--Inside getOtherFinderFees of DAX");

			PreparedStatement pstmtSearchFinderFees = null;
			HashMap hmQueryMap = new HashMap();
			SearchData oSearchData = (SearchData) a_oResultObject;
			log.debug("FinderFeesDAX--Search Data" + oSearchData);

			try
			{
				String strContractName = oSearchData.getTask1();
				GregorianCalendar dtEffFrom = oSearchData.getTaskDate1();
				String nStatus = oSearchData.getTask2();				
				
				log.debug("FinderFeesDAX--after Search Data");

				String strSearchFinderFeesQuery = getSQLString("Select",
						CHMConstants.FINDER_FEES_LIST_SEARCH);						

				hmQueryMap.put("Main", strSearchFinderFeesQuery);

				strSearchFinderFeesQuery = " AND UPPER(CFD.STRCONTRACTNAME) LIKE  UPPER(?) ";
				hmQueryMap.put("STRCONTRACTNAME", strSearchFinderFeesQuery);			

				strSearchFinderFeesQuery = " AND CSM2.NPARAMCD =  ? ";
				hmQueryMap.put("NSTATUS", strSearchFinderFeesQuery);				

				strSearchFinderFeesQuery = " AND CFD.DTEFFFROM =  ? ";
				hmQueryMap.put("DTEFFFROM", strSearchFinderFeesQuery);

				String strQuery = (String) hmQueryMap.get("Main");
				log.debug("FinderFeesDAX--Strquery =" + strQuery);
				
				if ((strContractName != null) && !strContractName.trim().equals(""))
				{
					strQuery += (String) hmQueryMap.get("STRCONTRACTNAME");
				}

				if ((nStatus != null) && !nStatus.trim().equals(""))
				{
					strQuery += (String) hmQueryMap.get("NSTATUS");
				}

				if (dtEffFrom != null)
				{
					strQuery += (String) hmQueryMap.get("DTEFFFROM");
				}
				
				strQuery = strQuery + " order by CFD.STRCONTRACTNAME";
				log.debug("FinderFeesDAX--Strquery =" + strQuery);
				pstmtSearchFinderFees = getPreparedStatement(strQuery);
				log.debug("FinderFeesDAX--Query Formed  " + strQuery);

				int iPosition = 0;
				
				// setting the paramtypecd for prod spec, status values				 	
				pstmtSearchFinderFees.setInt(++iPosition, DataConstants.YES_NO);
				pstmtSearchFinderFees.setInt(++iPosition, DataConstants.COMMON_STATUS);
				
				// setting rule name, status, eff date
				if ((strContractName != null) && !strContractName.trim().equals(""))
				{
					log.debug("FinderFeesDAX--Adding rule name");
					pstmtSearchFinderFees.setString(++iPosition,"%" + strContractName.trim()+ "%");
				}

				if ((nStatus != null) && !nStatus.trim().equals(""))
				{
					log.debug("FinderFeesDAX--Adding status ");
					pstmtSearchFinderFees.setInt(++iPosition, Integer.parseInt(nStatus.trim()));
				}

				if (dtEffFrom != null)
				{
					log.debug("FinderFeesDAX--Adding Effective Date From");
					pstmtSearchFinderFees.setTimestamp(++iPosition, DateUtil.retTimestamp(dtEffFrom));
				}				
			
				ResultSet rsSearch = executeQuery(pstmtSearchFinderFees);			 
						return XMLConverter.getXMLString(rsSearch);
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P9001");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9001");
			}
			finally
			{
				try
				{
					if (pstmtSearchFinderFees != null)
					{
						pstmtSearchFinderFees.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}
	/**
	 * Populates the resultset into XML string object for distinct approved Finder Rules.
	 * @param 
	 * @return XML string object
	 * @throws EElixirException
 	*/

	public String getFinderFees() throws EElixirException
	{
		log.debug("FinderFeesDAX--Inside getOtherFinderFees of DAX");

		PreparedStatement pstmtSearchFinderFees= null;
		Statement st = null ;
		StringBuffer sb = new StringBuffer();
				
		try
		{		
		  log.debug("FinderFeesDAX--before getsqlstring");
		  String strSearchFinderFeesQuery = getSQLString("Select",CHMConstants.FINDER_RULES);
		
		  log.debug("strSearchFinderFeesQuery :"+strSearchFinderFeesQuery);
		  pstmtSearchFinderFees = getPreparedStatement(strSearchFinderFeesQuery);
		  pstmtSearchFinderFees.setInt(1,DataConstants.STATUS_APPROVED_ID);
		  pstmtSearchFinderFees.setInt(2, DataConstants.COMMON_STATUS);
		  ResultSet rsSearch = executeQuery(pstmtSearchFinderFees);
		
		  log.debug("FinderFeesDAX--before returnin");
		  
		 return XMLConverter.getXMLString(rsSearch);
		}
		
		 catch(SQLException sqlex)
		{
		 log.exception(sqlex.getMessage());
		 throw new EElixirException("P3024");
		}
		finally
		{
		try
		  {
			if(pstmtSearchFinderFees != null)
			pstmtSearchFinderFees.close();
		  }
		catch(SQLException sqlex)
		 {
		  log.exception(sqlex.getMessage());
		  throw new EElixirException("P3024");
		 }
		}

	}
		
	/**
		 * getFinderFees gets the FinderFees Details
		 * @return FinderFeesResult
		 * @param a_lffseqnbr long
		 * @throws EElixirException
		 */
		public FinderFeesResult getFinderFees(long a_lffseqnbr)
			throws EElixirException
		{
			FinderFeesResult oFinderFeesResult = null;
			ResultSet rsSearchFinderFees = null;			
			ResultSet rsSearchFFProduct = null;
			ResultSet rsSearchFFCommRates = null;
			PreparedStatement pstmtSearchFinderFees = null;			
			PreparedStatement pstmtSearchFFProduct= null;
			PreparedStatement pstmtSearchFFCommRates= null;

			try			
			{
				// RETRIEVING THE MAIN HEADER DATA ================================================================
				String strFinderFeesQry = getSQLString("Select", CHMConstants.FINDERFEES_SEARCH);
				
				log.debug("FinderFeesDAX--search query is " + strFinderFeesQry);
				log.debug("FinderFeesDAX--primary key is " + a_lffseqnbr);
				pstmtSearchFinderFees = getPreparedStatement(strFinderFeesQry);
				pstmtSearchFinderFees.setLong(1, a_lffseqnbr);

				log.debug("FinderFeesDAX -- > retrieving FinderFees Header Data......... ");				 
				rsSearchFinderFees = executeQuery(pstmtSearchFinderFees);
				log.debug("FinderFeesDAX--Query executed properly");
				oFinderFeesResult = new FinderFeesResult();				  

				if (rsSearchFinderFees.next())
				{
					oFinderFeesResult.setIsDirty(DataConstants.DISPLAY_MODE);
					oFinderFeesResult.setFFHDRSeqNbr(new Long(rsSearchFinderFees.getLong("LFFHDRSEQNBR")));
					oFinderFeesResult.setContractName(rsSearchFinderFees.getString("STRCONTRACTNAME"));
					oFinderFeesResult.setTransType(new Short(rsSearchFinderFees.getString("NTRANSTYPE")));
					oFinderFeesResult.setEffFrom(DateUtil.retGregorian(rsSearchFinderFees.getTimestamp("DTEFFFROM")));
					oFinderFeesResult.setIsProdSpecific(new Short(rsSearchFinderFees.getString("NISPRODUCTSPECIFIC")));
					oFinderFeesResult.setStatus(new Short(rsSearchFinderFees.getString("NSTATUS")));				
					oFinderFeesResult.setBasis(new Short(rsSearchFinderFees.getString("NBASIS")));
					oFinderFeesResult.setTsDtUpdated(rsSearchFinderFees.getTimestamp("DTUPDATED")); 
 
				}
				//================================================================================================
				
				// RETRIEVING THE PRODUCT CODES DATA FOR THE RULE ================================================
				
				String strFFProductQry = getSQLString("Select", CHMConstants.FINDERFEES_PRODUCT_SEARCH);
				
				log.debug("FinderFeesDAX--search query for distinct products is :" + strFFProductQry);
				
				pstmtSearchFFProduct = getPreparedStatement(strFFProductQry);
				pstmtSearchFFProduct.setLong(1, a_lffseqnbr);

				log.debug("FinderFeesDAX -- > retrieving FinderFees Product Codes......... ");
				rsSearchFFProduct = executeQuery(pstmtSearchFFProduct);
				log.debug("FinderFeesDAX--FFProduct Query executed properly");				

				ArrayList alProductCodes=new ArrayList();	
			
				while (rsSearchFFProduct.next())
				{	
					log.debug("rsSearchFFProduct.getString(1) :"+rsSearchFFProduct.getString("strprodcd")+"--");
					
					if((rsSearchFFProduct.getString("strprodcd") != null) && !rsSearchFFProduct.getString("strprodcd").equals("") )
					{
						alProductCodes.add(new String(rsSearchFFProduct.getString("strprodcd")+"|"+rsSearchFFProduct.getString("DTOPUPPERC")));
						log.debug("inside not null product");
					
					}
					else
					{
						alProductCodes=null;
						log.debug("inside null product");	
					}											
				}
				
				// Array of Product Codes is added into the result object
				oFinderFeesResult.setProductCodes(alProductCodes);
				//=================================================================================================
				//calling function for ProductTypes
				
			  	oFinderFeesResult=getBonusProductTypeDetails(oFinderFeesResult);
				
				log.debug("FinderFeesDAX -- > in getFinderFees --> oFinderFeesResult	:"+oFinderFeesResult);
				
				return oFinderFeesResult;
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P9008");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9008");
			}
			finally
			{
				try
				{
					if (rsSearchFinderFees != null)
					{
						rsSearchFinderFees.close();
					}
				
					if (pstmtSearchFinderFees != null)
					{
						pstmtSearchFinderFees.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}

				
		//added by jim

	/**
			 * searchFFCommissionRates gets the CommissionRates Details
			 * @return FinderFeesResult
			 * @param long a_lbenseqnbr,String a_strprdcd
			 * @throws EElixirException
			 */
	public FinderFeesResult searchFFCommissionRates(long a_lbenseqnbr,String a_strprdcd)
				throws  EElixirException
	{
				CommissionRatesDetails oCommissionRatesDetails=null;
				FinderFeesResult oFinderFeesResult = null;
				ResultSet rsSearchFFCommRates = null;
				PreparedStatement pstmtSearchFFCommissionRates = null;	
				ArrayList alCommissionRatesDetails=null;
				
				
				try			
				{
					// RETRIEVING THE MAIN HEADER DATA ================================================================
					String strFFCommissionRatesQry = getSQLString("Select", CHMConstants.FF_COMMMISSION_RATES_SEARCH);
				
					log.debug("FinderFeesDAX--search query is " + strFFCommissionRatesQry);
					log.debug("FinderFeesDAX--sequence and product code " + a_lbenseqnbr+","+a_strprdcd);

					if(a_strprdcd == null || a_strprdcd.equals(""))
					{
						String str=" AND (STRPRODCD IS NULL) ORDER BY LFFDETAILSEQNBR ";
						strFFCommissionRatesQry =strFFCommissionRatesQry + str;
						
						pstmtSearchFFCommissionRates = getPreparedStatement(strFFCommissionRatesQry);
						
						
						pstmtSearchFFCommissionRates.setLong(1, a_lbenseqnbr);
						log.debug("i am in searchFFCommissionRates inside null product");
					}
					else
					{
						String str=" AND STRPRODCD=? ORDER BY LFFDETAILSEQNBR ";
						strFFCommissionRatesQry =strFFCommissionRatesQry + str;
						
						pstmtSearchFFCommissionRates = getPreparedStatement(strFFCommissionRatesQry);
						pstmtSearchFFCommissionRates.setLong(1, a_lbenseqnbr);
						pstmtSearchFFCommissionRates.setString(2, a_strprdcd);
						log.debug("i am in searchFFCommissionRates  inside not null product");
					}
					log.debug("FinderFeesDAX -- > retrieving searchFFCommissionRates  Data......... ");				 
					rsSearchFFCommRates = executeQuery(pstmtSearchFFCommissionRates);
					log.debug("FinderFeesDAX-- searchFFCommissionRates Query executed properly");
					oFinderFeesResult = new FinderFeesResult();	
					alCommissionRatesDetails=new ArrayList();	
					while(rsSearchFFCommRates.next())
					{
						oCommissionRatesDetails=new CommissionRatesDetails();
						oCommissionRatesDetails.setIsDirty(DataConstants.DISPLAY_MODE);
						oCommissionRatesDetails.setFFDetailRSeqNbr(new Long(rsSearchFFCommRates.getLong("LFFDETAILSEQNBR")));
						oCommissionRatesDetails.setFFHDRSeqNbr(new Long(rsSearchFFCommRates.getLong("LFFHDRSEQNBR")));
						if(rsSearchFFCommRates.getString("STRPRODCD")!=null && !rsSearchFFCommRates.getString("STRPRODCD").equals(""))
						{
							oCommissionRatesDetails.setProductCode(new String(rsSearchFFCommRates.getString("STRPRODCD")));
						}
						else
						{
							oCommissionRatesDetails.setProductCode(null);
						}
						oCommissionRatesDetails.setPolYearFrom(new Short(rsSearchFFCommRates.getShort("NPOLYEARFROM")));
						oCommissionRatesDetails.setPolYearTo(new Short(rsSearchFFCommRates.getShort("NPOLYEARTO")));
						oCommissionRatesDetails.setRate(new Double(rsSearchFFCommRates.getDouble("DRATE")));
						oCommissionRatesDetails.setReductionCommRate(new Double(rsSearchFFCommRates.getDouble("DCOMMRATE")));
						oCommissionRatesDetails.setTopUpRate(new Double(rsSearchFFCommRates.getDouble("DTOPUPPERC")));
						alCommissionRatesDetails.add(oCommissionRatesDetails);
					 
					}
					log.debug("before set finder fees");
					oFinderFeesResult.setCommRatesDetails(alCommissionRatesDetails);
					return oFinderFeesResult;
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, "P9008");
				}
				catch (EElixirException eex)
				{
					log.exception(eex.getMessage());
					throw new EElixirException(eex, "P9008");
				}
				finally
				{
					try
					{
						if (rsSearchFFCommRates != null)
						{
							rsSearchFFCommRates.close();
						}

						if (pstmtSearchFFCommissionRates != null)
						{
							pstmtSearchFFCommissionRates.close();
						}
					}
					catch (SQLException sqlex)
					{
						log.exception(sqlex.getMessage());
						throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
					}
				}
			}
		
		
		
		/**
		  * Inserts a new record
		  * @param a_oFinderFeesResult FinderFeesResult
		  * @return long Returns the next seq no generated on FinderFees table
		  * @throws EElixirException
		  */
		public void createFinderFees(FinderFeesResult a_oFinderFeesResult)
			throws EElixirException
		{
			PreparedStatement pstmtCreateFinderFees = null;
			
			long lffseqnbr;
			String strCreatedBy = null;

			try
			{
				String strContractName = a_oFinderFeesResult.getContractName();
				
				GregorianCalendar dtEffFrom = a_oFinderFeesResult.getEffFrom();				
				
				Short nIsProductSpecific = a_oFinderFeesResult.getIsProdSpecific();
				
				Short nTransType = a_oFinderFeesResult.getTransType();
				
				Short nStatus = a_oFinderFeesResult.getStatus();				
				
				Short nBasis = a_oFinderFeesResult.getBasis();
				
				strCreatedBy = a_oFinderFeesResult.getUserId();

				
				// Before inserting a new record this function generates a new Seq no, on which the
				// new record is inserted.
				lffseqnbr = getNextFinderFeesSeqNbr();
				log.debug("FinderFeesDAX--------------the dax created newkey----" +
					lffseqnbr);

				String strCreateFinderFeesQuery = getSQLString("Insert",
						CHMConstants.FINDERFEES_INSERT);

				log.debug("FinderFeesDAX--StrFinderFeesquery =" + strCreateFinderFeesQuery);
				pstmtCreateFinderFees = getPreparedStatement(strCreateFinderFeesQuery);

				int iPos=0;
				pstmtCreateFinderFees.setLong(++iPos, lffseqnbr);
				pstmtCreateFinderFees.setString(++iPos, strContractName);
				pstmtCreateFinderFees.setInt(++iPos, DataConstants.FINDERFEES_TRANSACTION_TYPE);				 				
				pstmtCreateFinderFees.setTimestamp(++iPos, DateUtil.retTimestamp(dtEffFrom));				
				pstmtCreateFinderFees.setShort(++iPos, nIsProductSpecific.shortValue());
				pstmtCreateFinderFees.setShort(++iPos, nStatus.shortValue());
				pstmtCreateFinderFees.setShort(++iPos, nBasis.shortValue());
				pstmtCreateFinderFees.setString(++iPos, strCreatedBy);

				int icount = executeUpdate(pstmtCreateFinderFees);
				log.debug("FinderFeesDAX--" + icount);
				log.debug("FinderFeesDAX-------------- storing newkey----" +lffseqnbr);
				
				a_oFinderFeesResult.setFFHDRSeqNbr(new Long(lffseqnbr));					
				
				log.debug("FinderFeesDAX--End of createFinderFees Main Record");		
				
				
				// inserting record in approaval transactions table.
				insertTransStatus(lffseqnbr, strCreatedBy);
							   
				//return lffseqnbr;
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());

				throw new EElixirException(sqlex, "P9007");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw eex;
			}
			finally
			{
				try
				{
					if (pstmtCreateFinderFees != null)
					{
						pstmtCreateFinderFees.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}
		
		
		/**
		 * creates Finder Fees record in Transaction History Table
		 * @param  
		 * @return void
		 * @throws EElixirException
		 */
	 	public void insertTransStatus(long lffseqnbr, String strUser) throws EElixirException
		{
		  log.debug("FinderFeesDAX: in inserttransstatus: seqnbr" + lffseqnbr + " userid " + strUser);
		  PreparedStatement pstmtApprovalInsert = null;
		
		  try
		  {
			 String strInsertApplication = getSQLString("Insert",CHMConstants.TRANSACTION_STATUS_INSERT);
			 log.debug("FinderFeesDAX: The Trans status query " + strInsertApplication);
		
			 pstmtApprovalInsert = getPreparedStatement(strInsertApplication);
		
			 pstmtApprovalInsert.setInt(1,DataConstants.TRANSACTIONS_FINDERFEES);
			 log.debug("FinderFeesDAX: set 1st param  " + DataConstants.TRANSACTIONS_FINDERFEES);
		
			 pstmtApprovalInsert.setLong(2, lffseqnbr);
			 log.debug("FinderFeesDAX: set 2nd param  " + lffseqnbr);
		
			 pstmtApprovalInsert.setInt(3,DataConstants.STATUS_PENDING_ID);
			 log.debug("FinderFeesDAX: set 3rd param  " + DataConstants.STATUS_PENDING_ID);		
				
			 pstmtApprovalInsert.setString(4,""); //to be clarified
			 log.debug("FinderFeesDAX: set 5th param  " );
		
			 pstmtApprovalInsert.setString(5, strUser); //to be clarified
			 log.debug("FinderFeesDAX: set 6th param  "+strUser );
		
			 log.debug("brfore execute inserttransstatus");
			 int iInsertApplication = executeUpdate(pstmtApprovalInsert);
			log.debug("FinderFeesDAX: Trans status Insert over");
		}
			catch(SQLException sqlex)	
			{
			   log.exception(sqlex.getMessage());
			   throw new EElixirException(sqlex, "P1010");
		   }
		   catch(EElixirException eex)
		   {
			  log.exception(eex.getMessage());
			 throw new EElixirException(eex,"P1010");
		   }
		}
		
		
		/**
		  * Inserts a new record
		  * @param a_oFinderFeesResult FinderFeesResult
		  * @return long Returns the next seq no generated on FinderFees table
		  * @throws EElixirException
		  */
		public void updateFinderFees(FinderFeesResult a_oFinderFeesResult)
			throws EElixirException
		{
			PreparedStatement pstmtCreateFinderFees = null;
		
			long lffseqnbr;
			String strUpdatedBy = null;

			try
			{
				lffseqnbr = a_oFinderFeesResult.getFFHDRSeqNbr().longValue();
				 
				String strContractName = a_oFinderFeesResult.getContractName();
			
				GregorianCalendar dtEffFrom = a_oFinderFeesResult.getEffFrom();				
									
				Short nTransType = a_oFinderFeesResult.getTransType();
					
				strUpdatedBy  = a_oFinderFeesResult.getUserId();

				String strCreateFinderFeesQuery = getSQLString("Update",
						CHMConstants.FINDERFEES_UPDATE);

				log.debug("FinderFeesDAX--StrFinderFeesquery =" + strCreateFinderFeesQuery);
				pstmtCreateFinderFees = getPreparedStatement(strCreateFinderFeesQuery);
				
				int iPos = 0;
				pstmtCreateFinderFees.setString(++iPos, strContractName);
				pstmtCreateFinderFees.setInt(++iPos, DataConstants.FINDERFEES_TRANSACTION_TYPE);				 				
				pstmtCreateFinderFees.setTimestamp(++iPos, DateUtil.retTimestamp(dtEffFrom));				
				pstmtCreateFinderFees.setString(++iPos, strUpdatedBy);
				pstmtCreateFinderFees.setLong(++iPos, lffseqnbr);

				int icount = executeUpdate(pstmtCreateFinderFees);
				log.debug("FinderFeesDAX--" + icount);
				log.debug("FinderFeesDAX-------------- updated findefeeS ----" +lffseqnbr);
				log.debug("FinderFeesDAX-------------- getIsFromSave----" +a_oFinderFeesResult.getIsFromSave());
			 
				// Retreving Arraylist of Product codes selected for deleting.
				ArrayList alProductCode=a_oFinderFeesResult.getProductCodes();				
				int iSize=0;
				
				if(alProductCode!=null)
					iSize=alProductCode.size();				
				
				for(int i=0;i<iSize;i++)
				{
					if(alProductCode.get(i)!=null)
						updateDeleteFinderFeesProduct(lffseqnbr,(String)alProductCode.get(i));
				}
			
				a_oFinderFeesResult.setFFHDRSeqNbr(new Long(lffseqnbr));					
			
				log.debug("FinderFeesDAX--End of updateFinderFees Main Record");


				//return lffseqnbr;
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());

				throw new EElixirException(sqlex, "P9007");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw eex;
			}
			finally
			{
				try
				{
					if (pstmtCreateFinderFees != null)
					{
						pstmtCreateFinderFees.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}
		
		
		/**
	   * deletes FinderFees record
	   * @param Long a_lFFHdrSeqNbr
	   * @throws EElixirException
	   */
		  public void updateDeleteFinderFeesProduct(long a_lFFHdrSeqNbr, String sProductCode) throws EElixirException
		  {
			  PreparedStatement pstFinderFeesProduct = null;
			  try
			  {
					String strDeleteProduct = getSQLString("Delete",CHMConstants.FINDERFEES_PRODUCT_DELETE);

					log.debug("FinderFeesDAX--strDeleteProduct =" + strDeleteProduct);
					pstFinderFeesProduct = getPreparedStatement(strDeleteProduct);
					
					pstFinderFeesProduct.setLong(1,a_lFFHdrSeqNbr);
					pstFinderFeesProduct.setString(2,sProductCode);
					
					int icount = executeUpdate(pstFinderFeesProduct);
					
					log.debug("FinderFeesDAX-- Delete FinderFees Product :" + icount);
			  }
			  catch (SQLException sqlex)
			  {
					log.fatal(getClass().getName(),"updateDeleteFinderFeesProduct","SQLException "+sqlex.getMessage());
					throw new EElixirException("P4541");
			  }
			  catch (EElixirException eex)
			  {
					log.fatal(getClass().getName(),"updateDeleteFinderFeesProduct","EElixirException "+eex.getMessage());
					throw new EElixirException("P4541");
			  }
			  finally
			  {
				  try
				  {
					  if (pstFinderFeesProduct != null)
					  {
						pstFinderFeesProduct.close();
					  }
				  }
				  catch (SQLException sqlex)
				  {
					  log.fatal(getClass().getName(),"updateDeleteFinderFeesProduct","SQLException "+sqlex.getMessage());
					  throw new EElixirException(sqlex, "P4541");
				  }
			  }
		  }
		
			
		/**
	   * deletes FinderFees record
	   * @param Long a_lFFHdrSeqNbr
	   * @throws EElixirException
	   */
		  public void deleteFinderFees(Long a_lFFHdrSeqNbr) throws EElixirException
		  {
			  PreparedStatement pstmtFinderFeesHeader = null;
			  try
			  {
			  	  // Deleting all Commission Rates Details from this particular record.
				  updateDeleteCommissionRatesTable(a_lFFHdrSeqNbr.longValue());
				
				  String strdeleteFinderFeesHeader = getSQLString("Delete",CHMConstants.FINDERFEES_DELETE);
		
				  pstmtFinderFeesHeader = getPreparedStatement(strdeleteFinderFeesHeader);
				  pstmtFinderFeesHeader.setLong(1, a_lFFHdrSeqNbr.longValue());
		
				  executeUpdate(pstmtFinderFeesHeader);
			  }
			  catch (SQLException sqlex)
			  {
					log.fatal(getClass().getName(),"deleteFinderFees","SQLException "+sqlex.getMessage());
				  	throw new EElixirException("P4541");
			  }
			  catch (EElixirException eex)
			  {
					log.fatal(getClass().getName(),"deleteFinderFees","EElixirException "+eex.getMessage());
				  	throw new EElixirException("P4541");
			  }
			  finally
			  {
				  try
				  {
					  if (pstmtFinderFeesHeader != null)
					  {
						pstmtFinderFeesHeader.close();
					  }
				  }
				  catch (SQLException sqlex)
				  {
					  log.fatal(getClass().getName(),"deleteFinderFees","SQLException "+sqlex.getMessage());
					  throw new EElixirException(sqlex, "P4541");
				  }
			  }
		  }
		
		
		private void updateDeleteCommissionRatesTable(long a_lffseqnbr) throws EElixirException
		{						
			PreparedStatement pstmtDeleteCommRates = null;						

			try
			{				
		 		String strDeleteCommRates = getSQLString("Delete",	CHMConstants.FINDERFEES_COMM_RATES_DELETE);

				log.debug("FinderFeesDAX--strDeleteCommRates =" + strDeleteCommRates);
				pstmtDeleteCommRates = getPreparedStatement(strDeleteCommRates);
				
				pstmtDeleteCommRates.setLong(1, a_lffseqnbr);
				
				int icount = executeUpdate(pstmtDeleteCommRates);
				
				log.debug("FinderFeesDAX-- Delete Comm. Rates :" + icount);

			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());

				throw new EElixirException(sqlex, "P9007");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw eex;
			}
			finally
			{
				try
				{
					if (pstmtDeleteCommRates != null)
					{
						pstmtDeleteCommRates.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		
		}
		
		
		
		public long updateFFCommRates(FinderFeesResult a_oFinderFeesResult)
			throws EElixirException
		{
			log.debug("=========================== >> FinderFeesDAX	<< ============================");
			log.debug("FinderFeesDAX	-- >  inside updateFFCommRates()	");
			PreparedStatement pstmtCreateFinderFees = null;

			long lffseqnbr;
			String strCreatedBy = null;
			ArrayList alCommRateDetails=null;
			CommissionRatesDetails oCommRatesDetails=null;

			try
			{ 
				alCommRateDetails = a_oFinderFeesResult.getCommRatesDetails();
				int iSize=alCommRateDetails.size();
				
				log.debug("alCommRateDetails.size	: "+iSize);
				
				if(alCommRateDetails!=null && iSize > 0)
				{
					// updating the commissions rates.
					
					for(int i=0;i<iSize;i++)
					{
						oCommRatesDetails=(CommissionRatesDetails)alCommRateDetails.get(i);
						
						if(oCommRatesDetails.getStatusFlag().equalsIgnoreCase(DataConstants.INSERT_MODE))
						{
							log.debug("invoking addCommRate ........ ");
							addCommRate(oCommRatesDetails);
						}
						if(oCommRatesDetails.getStatusFlag().equalsIgnoreCase(DataConstants.UPDATE_MODE))
						{
							log.debug("invoking updateCommRate ........ ");
							updateCommRate(oCommRatesDetails);
						}
						if(oCommRatesDetails.getStatusFlag().equalsIgnoreCase(DataConstants.DELETE_MODE))
						{
							log.debug("invoking deleteCommRate........ ");
							deleteCommRate(oCommRatesDetails);
						}
						
						
						
					}
						
				
				}
			// add code and their catch block here
			
			// returning the CHM_FINDERFEES_DEFN id for retrieving the details.
			lffseqnbr=a_oFinderFeesResult.getFFHDRSeqNbr().longValue();
			
			return lffseqnbr;
			}			
		    catch (EElixirException eex)
		    {
			   log.fatal(getClass().getName(),"updateFFCommRates","EElixirException "+eex.getMessage());
			   throw new EElixirException(eex, "p4528");
		    }
			finally
			{
				try
				{
					if (pstmtCreateFinderFees != null)
					{
						pstmtCreateFinderFees.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}
		
		
		public void addCommRate(CommissionRatesDetails oCommRatesDetails) throws EElixirException
		{
			log.debug("inside addCommRate ........ ");
			ResultSet rsCommRate = null;
			PreparedStatement pstCommRate= null;
			
			try{
			
				log.debug("Generating addCommRate  --> Comm Rate Seq ");
				// getting Sequence for PK
				String strFFCommRateSeq= getSQLString("Select",CHMConstants.FINDERFEES_RATE_SQUENCENO);			
				rsCommRate = executeQuery(strFFCommRateSeq);
				
				if(rsCommRate.next())
				{
					oCommRatesDetails.setFFDetailRSeqNbr(new Long(rsCommRate.getString(1)));					
				}
				else
					log.fatal("Sequence no not generated");
				
				log.debug("Inserting addCommRate .......  ");
				String strFFCommRate= getSQLString("Insert",CHMConstants.FINDERFEES_DETAIL_INSERT);			
				pstCommRate = getPreparedStatement(strFFCommRate);
				
				int iPos=0;
				pstCommRate.setLong(++iPos,oCommRatesDetails.getFFDetailRSeqNbr().longValue());
				pstCommRate.setLong(++iPos,oCommRatesDetails.getFFHDRSeqNbr().longValue());
				if(oCommRatesDetails.getProductCode()!= null || oCommRatesDetails.getProductCode()!="")
				{
				pstCommRate.setString(++iPos,oCommRatesDetails.getProductCode());
				}
				else
				{
					pstCommRate.setString(++iPos,null);
				}
				
				pstCommRate.setInt(++iPos,oCommRatesDetails.getPolYearFrom().intValue());
				pstCommRate.setInt(++iPos,oCommRatesDetails.getPolYearTo().intValue());
				pstCommRate.setDouble(++iPos,oCommRatesDetails.getRate().doubleValue());
				pstCommRate.setDouble(++iPos,oCommRatesDetails.getTopUpRate().doubleValue());
				pstCommRate.setDouble(++iPos,oCommRatesDetails.getReductionCommRate().doubleValue());
				pstCommRate.setString(++iPos,oCommRatesDetails.getUserId());
				
				int icount = executeUpdate(pstCommRate);
				log.debug("FinderFeesDAX --> addCommRate updated records :" + icount);
				
				log.debug("done inserting addCommRate .......  ");
			}
			catch (SQLException sqlex)
				   {
					   log.fatal(getClass().getName(),"addCommRate","SQLException "+sqlex.getMessage());
					   throw new EElixirException(sqlex, "P4540");
				   }
				   finally
				   {
					   try
					   {
						   if (pstCommRate != null)
						   {
							pstCommRate.close();
						   }
					   }
					   catch (SQLException ex)
					   {
						   log.fatal(getClass().getName(),"addCommRate","SQLException "+ex.getMessage());
						   throw new EElixirException(ex, "P8076");
					   }
				   }	
		
		}
		
		
		public void updateCommRate(CommissionRatesDetails oCommRatesDetails) throws EElixirException
		{
				log.debug("inside updateCommRate ........ ");
				ResultSet rsCommRate = null;
				PreparedStatement pstCommRate= null;
			
				try{				
					log.debug("Inserting updateCommRate .......  ");
					String strFFCommRate= getSQLString("Update",CHMConstants.FINDERFEES_DETAIL_UPDATE);
					log.debug("update strFFCommRate :"+strFFCommRate);
					pstCommRate = getPreparedStatement(strFFCommRate);
								
					int iPos=0;					
					pstCommRate.setInt(++iPos,oCommRatesDetails.getPolYearFrom().intValue());
					pstCommRate.setInt(++iPos,oCommRatesDetails.getPolYearTo().intValue());
					pstCommRate.setDouble(++iPos,oCommRatesDetails.getRate().doubleValue());
					pstCommRate.setDouble(++iPos,oCommRatesDetails.getReductionCommRate().doubleValue());
					pstCommRate.setDouble(++iPos,oCommRatesDetails.getTopUpRate().doubleValue());
					pstCommRate.setString(++iPos,oCommRatesDetails.getUserId());
					pstCommRate.setLong(++iPos,oCommRatesDetails.getFFDetailRSeqNbr().longValue());
					pstCommRate.setLong(++iPos,oCommRatesDetails.getFFHDRSeqNbr().longValue());					
					int icount = executeUpdate(pstCommRate);
					log.debug("FinderFeesDAX --> updateCommRate updated records :" + icount);
				
					log.debug("done updating updateCommRate .......  ");
				}
				catch (SQLException sqlex)
					   {
						   log.fatal(getClass().getName(),"updateCommRate","SQLException "+sqlex.getMessage());
						   throw new EElixirException(sqlex, "P4540");
					   }
					   finally
					   {
						   try
						   {
							   if (pstCommRate != null)
							   {
								pstCommRate.close();
							   }
						   }
						   catch (SQLException ex)
						   {
							   log.fatal(getClass().getName(),"updateCommRate","SQLException "+ex.getMessage());
							   throw new EElixirException(ex, "P8076");
						   }
					   }	
		
			}
			
			public void deleteCommRate(CommissionRatesDetails oCommRatesDetails) throws EElixirException
			{
					log.debug("inside deleteCommRate ........ ");
					ResultSet rsCommRate = null;
					PreparedStatement pstCommRate= null;
			
					try{
						
				
						log.debug("Inserting deleteCommRate .......  ");
						String strFFCommRate= getSQLString("Delete",CHMConstants.FINDERFEES_DETAIL_DELETE);			
						pstCommRate = getPreparedStatement(strFFCommRate);			
					
						pstCommRate.setLong(1,oCommRatesDetails.getFFDetailRSeqNbr().longValue());
						pstCommRate.setLong(2,oCommRatesDetails.getFFHDRSeqNbr().longValue());
					
						int icount = executeUpdate(pstCommRate);
						log.debug("FinderFeesDAX --> deleteCommRate updated records :" + icount);
				
						log.debug("done deleting deleteCommRate .......  ");
					}
					catch (SQLException sqlex)
						   {
							   log.fatal(getClass().getName(),"deleteCommRate","SQLException "+sqlex.getMessage());
							   throw new EElixirException(sqlex, "P4540");
						   }
						   finally
						   {
							   try
							   {
								   if (pstCommRate != null)
								   {
									pstCommRate.close();
								   }
							   }
							   catch (SQLException ex)
							   {
								   log.fatal(getClass().getName(),"deleteCommRate","SQLException "+ex.getMessage());
								   throw new EElixirException(ex, "P8076");
							   }
						   }	
		
				}
		
		
		
		/**
			  * Description getSQLString takes querytype and key and returns query
			  * @return query string
			  * @param a_strSQLType SQL Type i.e Select , Insert , Delete , Update
			  * @param a_strKey String
			  * @throws EElixirException
			  */
			private String getSQLString(String a_strSQLType, String a_strKey)
				throws EElixirException
			{
				SqlRepositoryIF sqlRFIF = null;
				String strSql = "";

				try
				{
					sqlRFIF = CHMSqlRepository.getSqlRepository();
					strSql = sqlRFIF.getSQLString(a_strKey, a_strSQLType);
				}
				catch (EElixirException eex)
				{
					log.debug("FinderFeesDAX--sql ex" + eex);
					log.exception(eex.getMessage());
					throw new EElixirException(eex, "P3019"); // could not get sql string
				}

				return strSql;
			}
			
			
		/**
		 * This function generates a new Seq no, on which the
		 * new record is inserted.
		 * @return long Returns the next seq no generated on FinderFeestable
		 * @throws EElixirException
		 */
	   protected long getNextFinderFeesSeqNbr() throws EElixirException
	   {
		   Statement stmtNextSeqFinderFees= null;
		   long lSeqNo;

		   try
		   {
			   String strNextSeqQuery = getSQLString("Select",
					   CHMConstants.FINDERFEES_SEQUENCENO);

			   stmtNextSeqFinderFees= getStatement();

			   ResultSet rsSeqNo = stmtNextSeqFinderFees.executeQuery(strNextSeqQuery);
			   rsSeqNo.next();
			   lSeqNo = rsSeqNo.getLong(1);
			   log.debug(lSeqNo + "");

			   return lSeqNo;
		   }
		   catch (SQLException sqlex)
		   {
			   log.exception(sqlex.getMessage());

			   throw new EElixirException(sqlex, "P9006");
		   }
		   catch (EElixirException eex)
		   {
			   log.exception(eex.getMessage());
			   throw new EElixirException(eex, "P9006");
		   }
		   finally
		   {
			   try
			   {
				   if (stmtNextSeqFinderFees!= null)
				   {
					   stmtNextSeqFinderFees.close();
				   }
			   }
			   catch (SQLException sqlex)
			   {
				   log.exception(sqlex.getMessage());
				   throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			   }
		   }
	   }
		
		
		/**
		  * findFinderFees finds whether the FinderFees is there or not
		  * @return boolean
		  * @param a_lffseqnbr long
		  * @throws EElixirException
		*/
		public boolean findFinderFees(long a_lffseqnbr) throws EElixirException
		{
			ResultSet rsSearchFinderFees = null;
			PreparedStatement pstmtFindPrimaryKey = null;

			try
			{
				String strSelectFinderFeesQuery = getSQLString("Select",
						CHMConstants.FIND_FINDERFEES_BY_PRIMARYKEY);

				if (pstmtFindPrimaryKey == null)
				{
					pstmtFindPrimaryKey = getPreparedStatement(strSelectFinderFeesQuery);
				}

				pstmtFindPrimaryKey.setLong(1, a_lffseqnbr);

				rsSearchFinderFees = executeQuery(pstmtFindPrimaryKey);

				if (rsSearchFinderFees.next())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			catch (SQLException sqlex)
			{
				log.exception(sqlex.getMessage());

				//throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
				throw new EElixirException(sqlex, "P9002");
			}
			catch (EElixirException eex)
			{
				log.exception(eex.getMessage());
				throw new EElixirException(eex, "P9002");
			}
			finally
			{
				try
				{
					if (rsSearchFinderFees != null)
					{
						rsSearchFinderFees.close();
					}

					if (pstmtFindPrimaryKey != null)
					{
						pstmtFindPrimaryKey.close();
					}
				}
				catch (SQLException sqlex)
				{
					log.exception(sqlex.getMessage());
					throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
				}
			}
		}
		
		/**
			 * Retrieves BonusProductTypeDetails
			 * @return FinderFeesResult
			 * @param a_oFinderFeesResult FinderFeesResult
			 * @throws EElixirException
			*/
			public FinderFeesResult getBonusProductTypeDetails(FinderFeesResult a_oFinderFeesResult)
				throws EElixirException
			{
				log.debug("FINDERFEESDAX --> inside getBonusProductTypeDetails...");
				ResultSet rsSearchBonusProductTypes = null;
				PreparedStatement pstmtSearchBonusProductTypes = null;
		
				HashMap ahBonusProductTypes  = new HashMap();
		
				String strProductCd = "";
				String strProductType="";
				try
				{
					String strSelectBonusProductTypesQuery = getSQLString("Select",CHMConstants.PRODUCTS_TYPE_DETAILS);
					pstmtSearchBonusProductTypes = getPreparedStatement(strSelectBonusProductTypesQuery);
			
					rsSearchBonusProductTypes= executeQuery(pstmtSearchBonusProductTypes);

					while (rsSearchBonusProductTypes.next())
					{
						strProductCd=rsSearchBonusProductTypes.getString("Code");
						strProductType=""+rsSearchBonusProductTypes.getInt("NTERMTYPE");
				
						if(strProductCd!=null && strProductType!=null)
						{
							ahBonusProductTypes.put(strProductCd,strProductType);
						}
					}
					log.debug("ahBonusProductTypes--------->"+ahBonusProductTypes);
					a_oFinderFeesResult.setBonusProductTypes(ahBonusProductTypes);
					return a_oFinderFeesResult;
				}
				catch (SQLException sqlex)
				{
					log.fatal(getClass().getName(),"getBonusProductTypeDetails","SQLException "+sqlex.getMessage());
					throw new EElixirException(sqlex, "P8076");
				}
				finally
				{
					try
					{
						if (rsSearchBonusProductTypes != null)
						{
							rsSearchBonusProductTypes.close();
						}
					}
					catch (SQLException sqlex)
					{
						log.fatal(getClass().getName(),"getBonusProductTypeDetails","SQLException "+sqlex.getMessage());
						throw new EElixirException(sqlex, "P8076");
					}
				}
			}



	    
}
