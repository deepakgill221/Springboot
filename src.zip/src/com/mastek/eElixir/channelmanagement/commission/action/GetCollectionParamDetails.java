/********************************************************************
 *
 *  PROJECT				: MAMM
 *  MODULE NAME			: CHANNEL MANAGEMENT
 *  FILENAME			: GetCollectionParamDetails.java
 *  AUTHOR				: Varun Kathariya
 *  VERSION				: 1.0
 *  CREATION DATE		: May 23, 2014
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT			: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.util.CollectionParamResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2
public class GetCollectionParamDetails extends Action {

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	public GetCollectionParamDetails() {

	}

	@Override
	public void process(HttpServletRequest aORequest) throws EElixirException {
		log.debug("Start GetCollectionParamDetails");		
		try {
			CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome",CHMSLHome.class);
			CollectionParamResult collectionParamResult =  remoteCHMSL.getCollectionParams();
			setResult(collectionParamResult);
			log.debug("End GetCollectionParamDetails");
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (CreateException e) {
			e.printStackTrace();
		}
	}

}
