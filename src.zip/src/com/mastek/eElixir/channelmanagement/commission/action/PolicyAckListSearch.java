/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : PolicyAckListSearch.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_policy_ackn_upd.doc.doc
*  CREATION DATE                  : 29/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
* 1.1      04/09/2003   Dipti      Code Rework
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;


public class PolicyAckListSearch extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * @Constructor
     */
    public PolicyAckListSearch()
    {
    }

    /**
     * This method makes a remote call to the Session bean which in turn makes a local
     * call to all other bean and get the Persistency ArrayList Object
     * @param: request - Request object.
     * @throws EElixirException
     */
    public void process(HttpServletRequest request) throws EElixirException
    {
        ArrayList oPolicyAckList = null;
       // CR_Agent_Polack_update_217152
        ArrayList oPolicyAckServAgentList=null;
        SearchData oSearchData = new SearchData();
        request.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);

        try
        {
            CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
            String strPolNbr = request.getParameter("strPolNbrHdr").trim();
            String strServAgentCd = request.getParameter("strServAgentCd");
            String strPolAckn = request.getParameter("dtPolAckn");
            oSearchData.setTask1(strPolNbr);
            oSearchData.setTask3(strPolAckn.trim());
            oPolicyAckServAgentList = remoteCHMSL.searchPolicyAck(oSearchData);
            oPolicyAckList=(ArrayList)oPolicyAckServAgentList.get(1);
            if (oPolicyAckList.size() == 0)
            {
                throw new EElixirException("p5117");
            }

            setResult(oPolicyAckServAgentList);
            request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
        }
        catch (RemoteException rex)
        {
            _oLogger.fatal(getClass().getName(), "Process", rex.getMessage());
            request.setAttribute("ResultObject", oPolicyAckServAgentList);
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException rex)
        {
            _oLogger.fatal(getClass().getName(), "Process", rex.getMessage());
            request.setAttribute("ResultObject", oPolicyAckServAgentList);
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            _oLogger.fatal(getClass().getName(), "Process", cex.getMessage());
            request.setAttribute("ResultObject", oPolicyAckServAgentList);
            throw new EElixirException(cex, "P1007");
        }

        catch (EElixirException cex)
        {
            _oLogger.fatal(getClass().getName(), "Process", cex.getMessage());
            request.setAttribute("ResultObject", oPolicyAckServAgentList);
            throw cex;
        }
    }
}
