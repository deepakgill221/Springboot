/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractDelete.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*1.1             16Jan2003         Pallav            added payment Mode
*1.2             23Jan2003         Pallav            added Term Type, and Maturity Age
*1.3             7Feb2003         Pallav            changed statusFlag as statusFlagC and statusFlagS
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Deletes the Contract
 * It also deletes in Commission depending upon the type of request send to it
 * Copyright (c) 2002 Mastek Ltd
 * Date       25/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractButtonPallete;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
public class ContractDelete extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor of the ContractUpdate class
   */
  public ContractDelete()
  {

  }

  /**
   * Depending upon the type of request it updates/Deletes/Inserts a row for commission.
   * It calls session bean for doing this operation. Main task is to fetch data from request object
   * call to all other bean and populates the DVO
   * @param a_oRequest  HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ContractResult oContractResult = null;
  try{
       CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      oContractResult = new ContractResult();
      CommissionResult oCommissionResult = new CommissionResult();

      String strContractNumber = a_oRequest.getParameter("strContractNbr");
      oContractResult.setContractNumber(strContractNumber);
      oContractResult.setEffectiveDate(DateUtil.retGCDate(a_oRequest.getParameter("dtEffFrom").trim()));

      int iContractStatus = DataConstants.STATUS_PENDING_ID; // for Pending
      if(a_oRequest.getParameter("nStatus") != null && (!a_oRequest.getParameter("nStatus").trim().equals(""))){
        iContractStatus = Integer.parseInt(a_oRequest.getParameter("nStatus"));
      }
      oContractResult.setContractStatus(new Integer(iContractStatus));
      log.debug(strContractNumber + " " + iContractStatus);

      String strComAgreementKey = a_oRequest.getParameter("hdnComAgreementKey");
      String strCommType = a_oRequest.getParameter("nCommType");
      Short nCommType = null;
       if(strCommType != null){
         nCommType = new Short(strCommType);
      }
      log.debug("ContractDelete--nCommType " + strCommType + " strComAgreementKey " + strComAgreementKey);
      oCommissionResult.setCommType(nCommType);


/*
      oContractResult.setCommissionResult(oCommissionResult);
      if(nCommType.intValue() == DataConstants.STANDARD_COMMISSION || nCommType.intValue() == DataConstants.TRAIL_COMMISSION){ // for standard commission, or Trail
        oCommissionResult.setCommissionDetail(standardCommissionParameterFetch(a_oRequest));
      }
      else if(nCommType.intValue()  == DataConstants.CLAWBACK_COMMISSION){ // for Clawback
        oCommissionResult.setClawBackDetail(clawBackParameterFetch(a_oRequest));
      }
      */

      String strCommBase = a_oRequest.getParameter("nCommBase");
      // added code for nPmtMode
      String strPmtMode = a_oRequest.getParameter("nPmtMode");
      // added code for nTermType
      String strTermType = a_oRequest.getParameter("nTermType");
      String strCommClass = a_oRequest.getParameter("strCommClass");
      Short nCommBase = null;
      Short nPmtMode = null;
      Short nTermType = null;
      if(strCommBase != null){
        nCommBase = new Short(strCommBase);
      }
      if(strPmtMode != null){
        nPmtMode = new Short(strPmtMode);
      }
      if(strTermType != null){
        nTermType = new Short(strTermType);
      }
      String strProdCdVer = a_oRequest.getParameter("strProdCdVer");
      log.debug(strCommBase + " " + nPmtMode + " " + nTermType + " " + strCommType + " " + strCommClass + " " + strProdCdVer);

      StringTokenizer st = new StringTokenizer(strProdCdVer,"|");
      String strProdCd = null;
      String strProdVer = null;
      while(st.hasMoreTokens()){
        strProdCd = (String)st.nextElement();
        break;
      }
      while(st.hasMoreTokens()){
        strProdVer = (String)st.nextElement();
      }
      Integer iProdVer = null;
      if(strProdVer != null){
        iProdVer = new Integer(strProdVer);
      }
      String strCampaignCd = a_oRequest.getParameter("strCampaignCd");
      String iBaseUnits = a_oRequest.getParameter("iBaseUnits");
      //String strDistribType = a_oRequest.getParameter("strDistribType");

      //log.debug(strProdCd + " " + strProdVer + " " + strCampaignCd + " " + iBaseUnits + " " + strDistribType);

      oCommissionResult.setCommBase(nCommBase);
      oCommissionResult.setPmtMode(nPmtMode);
      oCommissionResult.setTermType(nTermType);
      oCommissionResult.setCommType(nCommType);
      oCommissionResult.setCommClass(strCommClass);
      oCommissionResult.setProdCd(strProdCd);
      oCommissionResult.setProdVer(iProdVer);
      oCommissionResult.setCampaignCd(strCampaignCd);
      oCommissionResult.setBaseUnits(new Integer(iBaseUnits.trim()));
      //oCommissionResult.setDistribType(strDistribType);
      oCommissionResult.setComAgreementKey(new Long(strComAgreementKey.trim()));
      log.debug("ContractDelete--after getting all values of contract");
	  //Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
      if(nCommType.intValue() == DataConstants.STANDARD_COMMISSION || nCommType.intValue() == DataConstants.TRAIL_COMMISSION || nCommType.intValue() == DataConstants.INDEX_COMMISSION || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION){ // for standard commission, or Trail
        log.debug("ContractDelete--inside standard commission fetch");
        oCommissionResult.setCommissionDetail(standardCommissionParameterFetch(a_oRequest,nCommType.intValue()));
      }
      else if(nCommType.intValue()  == DataConstants.CLAWBACK_COMMISSION){ // for Clawback
        log.debug("ContractDelete--inside clawback commission fetch");
        oCommissionResult.setClawBackDetail(clawBackParameterFetch(a_oRequest));
      }
      log.debug("ContractDelete--after getting all values of Commission");
      oContractResult.setCommissionResult(oCommissionResult);

      log.debug("ContractDelete--before create commission");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      ContractButtonPallete oContractButtonPallete = ContractButtonPallete.getInstance();
      oContractResult = oContractButtonPallete.applyButtons(oContractResult);

      //remoteCHMSL.updateCommissionContract(oContractResult);
      remoteCHMSL.deleteContract(new Long(strComAgreementKey).longValue(), oContractResult);
      //a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);

      //a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      //oContractResult = remoteCHMSL.searchContract(Long.parseLong(strComAgreementKey.trim()));


      // for standard commission, or Trail
      /*
      //if(strCommType.trim().equals(DataConstants.STANDARD_COMMISSION) || strCommType.trim().equals(DataConstants.TRAIL_COMMISSION)){
        oContractResult.getCommissionResult().setCommissionDetail(removeDeleteFlagStandardCommission(oContractResult.getCommissionResult().getCommissionDetail()));
      }
      // for Clawback
      else if(strCommType.trim().equals(DataConstants.CLAWBACK_COMMISSION)){
        oContractResult.getCommissionResult().setClawBackDetail(removeDeleteFlagClawBackCommission(oContractResult.getCommissionResult().getClawBackDetail()));
      }
      */
      //setResult(oContractResult);
      log.debug("ContractDelete--result accessed");
    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(fex, "P3024");
    }
    catch(RemoveException rex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(rex, "P3022");
    }
    catch(EElixirException eex)
    {
      log.debug("ContractDelete--Inside catch of Eelixir exception in process of ContractDelete");
      //setResult(oContractResult);
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw eex;
    }
  }


  /**
   * This method fetches all the details of Standard Commission.
   * @return CommissionDetails[] Array of CommissionDetails
   * @param a_oRequest HttpServletRequest object.
   */
  private CommissionDetails[] standardCommissionParameterFetch(HttpServletRequest a_oRequest,int type){
    CommissionDetails[] arrCommissionDetails;
    String[] nTermFrom       = a_oRequest.getParameterValues("nTermFrom"); //short
    String[] strStatusFlag   = a_oRequest.getParameterValues("statusFlagS"); //double
    String[] lAgrmtSCSeqNbr  = a_oRequest.getParameterValues("PKValue"); //double
    String[] nTermTo         = a_oRequest.getParameterValues("nTermTo"); //short
    String[] nEntryAgeFrom   = a_oRequest.getParameterValues("nEntryAgeFrom"); //short
    String[] nEntryAgeTo     = a_oRequest.getParameterValues("nEntryAgeTo"); //short
    String[] nMatAgeFrom     = a_oRequest.getParameterValues("nMatAgeFrom"); //short
    String[] nMatAgeTo       = a_oRequest.getParameterValues("nMatAgeTo"); //short
    String[] nNbrOfLivesFrom = a_oRequest.getParameterValues("nNbrOfLivesFrom");  //short
    String[] nNbrOfLivesTo   = a_oRequest.getParameterValues("nNbrOfLivesTo"); //short
    String[] dSAFrom         = a_oRequest.getParameterValues("dSAFrom"); //double
    String[] dSATo           = a_oRequest.getParameterValues("dSATo"); // double
    String[] dBaseValeFrom   = a_oRequest.getParameterValues("dBaseValueFrom"); //double
    String[] dBaseValeTo     = a_oRequest.getParameterValues("dBaseValueTo"); // double
    String[] nPolYearFrom    = a_oRequest.getParameterValues("nPolYearFrom"); //short
    String[] nPolYearTo      = a_oRequest.getParameterValues("nPolYearTo"); //short
    String[] dCommRate       = a_oRequest.getParameterValues("dCommRate"); //double
    String[] strRepLinkCd    = a_oRequest.getParameterValues("strRepLinkCd"); //String
    String[] std_comm_dtUpdated = a_oRequest.getParameterValues("std_comm_dtUpdated"); //timestamp
    //Added by Aradhana FIN1107 23_Oct_2017: START
    String[] nPptFrom       = a_oRequest.getParameterValues("nPptFrom"); //short
    String[] nPptTo         = a_oRequest.getParameterValues("nPptTo"); //short
    //Added by Aradhana FIN1107 23_Oct_2017: END
	int nCB = (new Short(a_oRequest.getParameter("nCommBase"))).shortValue();
    log.debug(nTermFrom.length + "");
    int count = 0;
    for(int i = 0; i<nTermFrom.length ; i++){
      log.debug(strStatusFlag[i]);
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        count++;
      }
    }
    arrCommissionDetails = new CommissionDetails[count];
    log.debug("ContractDelete-- count " + count);
    count = 0;
    for(int i = 0; i<nTermFrom.length ; i++){
	  log.debug("ContractDelete-- i " + i);
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        arrCommissionDetails[count] = new CommissionDetails();

        arrCommissionDetails[count].setTermFrom(new Short(nTermFrom[i]));
        arrCommissionDetails[count].setTermTo(new Short(nTermTo[i]));
      
        arrCommissionDetails[count].setEntryAgeFrom(new Short(nEntryAgeFrom[i]));
        arrCommissionDetails[count].setEntryAgeTo(new Short(nEntryAgeTo[i]));
        arrCommissionDetails[count].setMatAgeFrom(new Short(nMatAgeFrom[i]));
        arrCommissionDetails[count].setMatAgeTo(new Short(nMatAgeTo[i]));
        arrCommissionDetails[count].setNbrOfLivesFrom(new Short(nNbrOfLivesFrom[i]));
        arrCommissionDetails[count].setNbrOfLivesTo(new Short(nNbrOfLivesTo[i]));
		if(nCB == DataConstants.PREMIUM_AND_SA){
	        arrCommissionDetails[count].setSAFrom(new Double(dSAFrom[i]));
		    arrCommissionDetails[count].setSATo(new Double(dSATo[i]));
		}
        arrCommissionDetails[count].setBaseValeFrom(new Double(dBaseValeFrom[i]));
        arrCommissionDetails[count].setBaseValeTo(new Double(dBaseValeTo[i]));
        arrCommissionDetails[count].setPolYearFrom(new Short(nPolYearFrom[i]));
        arrCommissionDetails[count].setPolYearTo(new Short(nPolYearTo[i]));
		  log.debug("ContractDelete-- till here 1st i " + i);
        if (std_comm_dtUpdated[i] != null && !std_comm_dtUpdated[i].trim().equals(""))
        {
          log.debug("~Setting timestamp as " + std_comm_dtUpdated[i]);
          arrCommissionDetails[count].setTsDtUpdated(Timestamp.valueOf(std_comm_dtUpdated[i]));
        }

        if(! strStatusFlag[i].trim().equals(DataConstants.INSERT_MODE)){
          arrCommissionDetails[count].setAgrmtSCSeqNbr(new Long(lAgrmtSCSeqNbr[i].trim()));
        }
        arrCommissionDetails[count].setStatusFlag(DataConstants.DELETE_MODE);
         if(type != DataConstants.OVERRIDING_COMMISSION){
        	 //Added by Aradhana FIN1107 23_Oct_2017: START
             arrCommissionDetails[count].setPptFrom(new Short(nPptFrom[i]));
             arrCommissionDetails[count].setPptTo(new Short(nPptTo[i]));
           //Added by Aradhana FIN1107 23_Oct_2017: END
          arrCommissionDetails[count].setCommRate(new Double(dCommRate[i]));
        }
        else{	
          arrCommissionDetails[count].setRepLinkCd(strRepLinkCd[i]);
        }
        count++;
        //log.debug(nTermFrom[i] + " " + nTermTo[i] + " " + nEntryAgeFrom[i] + " " + nEntryAgeTo[i] + " " + nNbrOfLivesFrom[i] + " " + nNbrOfLivesTo[i]);
        //log.debug(dBaseValeFrom[i] + " " + dBaseValeTo[i] + " " + nPolYearFrom[i] + " " + nPolYearTo[i] + " " + dCommRate[i]);
      }
	  log.debug("ContractDelete-- i " + i);
    }
    return arrCommissionDetails;
  }

  /**
   * This method fetches all the details of ClawBack Commission.
   * @return ClawBackDetails[] Array of ClawBackDetails
   * @param a_oRequest HttpServletRequest object.
   */
  private ClawBackDetails[] clawBackParameterFetch(HttpServletRequest a_oRequest){
    ClawBackDetails[] arrClawBackDetails;
    String[] strPmtMode = a_oRequest.getParameterValues("strPmtMode"); //short

    String[] nRngType =a_oRequest.getParameterValues("nRngType"); //short
    String[] nRngFrom = a_oRequest.getParameterValues("nRngFrom"); //short
    String[] nRngTo = a_oRequest.getParameterValues("nRngTo"); //short
    String[] dClawbackRate  = a_oRequest.getParameterValues("dClawbackRate");  //short

    String[] lAgrmtClawSeqNbr = a_oRequest.getParameterValues("PKValue"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlagC"); //double


    log.debug(strPmtMode.length + "");
    int count = 0;
    for(int i = 0; i<strPmtMode.length ; i++){
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        count++;
      }
    }
    arrClawBackDetails = new ClawBackDetails[count];
    count=0;
    for(int i = 0; i<strPmtMode.length ; i++){
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        arrClawBackDetails[count] = new ClawBackDetails();

        arrClawBackDetails[count].setPmtMode(strPmtMode[i]);
        arrClawBackDetails[count].setRngType(new Short(nRngType[i]));
        arrClawBackDetails[count].setRngFrom(new Short(nRngFrom[i]));
        arrClawBackDetails[count].setRngTo(new Short(nRngTo[i]));
        arrClawBackDetails[count].setClawbackRate(new Double(dClawbackRate[i]));
        if(! strStatusFlag[i].trim().equals(DataConstants.INSERT_MODE)){
          log.debug("ContractDelete--Inside Clawback fetch " + lAgrmtClawSeqNbr[i]);
          arrClawBackDetails[count].setlAgrmtClawSeqNbr(new Long(lAgrmtClawSeqNbr[i].trim()));
        }

        //arrClawBackDetails[count].setlAgrmtClawSeqNbr(new Long(lAgrmtClawSeqNbr[i].trim()));
        arrClawBackDetails[count].setStatusFlag(DataConstants.DELETE_MODE);
        count++;
      }
    }
    return arrClawBackDetails;
  }
}