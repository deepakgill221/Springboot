/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterCreate.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: November 02, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * Action Class for Inserting a list of RYCRuleMasterCreate 
 * Copyright (c) 2005 Mastek Ltd
 * Date       02/11/2005
 * @version 1.0
 */

// PACKAGE DEFNETION
package com.mastek.eElixir.channelmanagement.commission.action;


import java.rmi.RemoteException;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import java.util.ArrayList;


import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleAgencyDetails;//Narendra CTS for RYC rule master details as part of to AGN-09
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleDesgDetails;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRulePolicyDetails;




/**
 * This Action Class is to Create New RYCRuleMasterCreate Entry
 */

public class RYCRuleMasterCreate extends Action
{

  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the RYCRuleMasterCreate class
   */
  public RYCRuleMasterCreate()
  {

  }


  /**
   * This method makes a remote call to the CHM Session bean which in turn makes a local
   * call to all other bean and updates the Application
   * @param: a_oRequest - HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {

    RYCRuleMasterSearchResult oRYCRuleMasterSearchResult = null;

    try
    {
		log.debug("RYCRuleMasterCreate : Process");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);

      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      
	  //Populating RYCRuleMasterSearchResult object from Request Object
      oRYCRuleMasterSearchResult = getRYCRuleMasterResult(a_oRequest);

      //Firing Create RYCRulemaster Method
      long lRYCRuleSeqNbr = remoteCHMSL.createRYCRuleMaster(oRYCRuleMasterSearchResult);


	  log.debug("RYCRuleMasterCreate lRYCRuleSeqNbr"+lRYCRuleSeqNbr);

      //Retrieving Newly Created Record from Database
      oRYCRuleMasterSearchResult = remoteCHMSL.searchRYCRuleMaster(lRYCRuleSeqNbr);

	  log.debug("RYCRuleMasterCreate final values--->"+oRYCRuleMasterSearchResult);

      //Setting the Result Object
      setResult(oRYCRuleMasterSearchResult);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);


    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw new EElixirException(cex, "P1007");
    }

    catch(EElixirException eex)
    {
      log.debug("RYCRuleMasterCreate--Inside catch of EElixir exception ");
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw eex;
    }
	catch(Exception ee)
    {
		log.debug("Finder Exception");
		ee.printStackTrace();

    }
  }

  /**
   * A method to Populate RYCRuleMasterSearchResult object from the Request Object
   * @param a_oRequest HttpServletRequest
   * @return oRYCRuleMasterSearchResult
   * @throws EElixirException
   */
  private RYCRuleMasterSearchResult getRYCRuleMasterResult(HttpServletRequest a_oRequest) throws EElixirException
  {

    RYCRuleMasterSearchResult oRYCRuleMasterSearchResult = new RYCRuleMasterSearchResult();


    log.debug("strRYCRule" + a_oRequest.getParameter("strRYCRule"));
    log.debug("nChannelType" + a_oRequest.getParameter("nChannelType"));
    log.debug("dtEffFrom" + a_oRequest.getParameter("dtEffFrom"));
    log.debug("dtEffTo" + a_oRequest.getParameter("dtEffTo"));
    log.debug("strPeriodOfSA" + a_oRequest.getParameter("strPeriodOfSA"));
    log.debug("strSumAssumed" + a_oRequest.getParameter("strSumAssumed"));
    log.debug("strStartYear" + a_oRequest.getParameter("strStartYear"));
    log.debug("strEndYear" + a_oRequest.getParameter("strEndYear"));
    log.debug("nStatus" + a_oRequest.getParameter("nStatus"));

	  HttpSession  session = a_oRequest.getSession();
    String  strUserId = (String)session.getAttribute("username");
	log.debug("strUserId--->"+strUserId);



    String strRYCRule = a_oRequest.getParameter("strRYCRule").trim();
    String nChannelType = a_oRequest.getParameter("nChannelType").trim();

    String dtEffFrom = a_oRequest.getParameter("dtEffFrom").trim();
    GregorianCalendar dtEffFrom1 = null;
    if( dtEffFrom != null && !dtEffFrom.equals(""))
    {
      dtEffFrom1 = DateUtil.retGCDate(dtEffFrom.trim());
    }

	String dtEffTo = a_oRequest.getParameter("dtEffTo").trim();
    GregorianCalendar dtEffTo1 = null;
    if( dtEffTo != null && !dtEffTo.equals(""))
    {
      dtEffTo1 = DateUtil.retGCDate(dtEffTo.trim());
    }
//Changed By Narendra to convert from Long to double to take Sum Assured	
    Double strSumAssumed1 = null;
    String strSumAssumed = a_oRequest.getParameter("strSumAssumed").trim();
    if(strSumAssumed != null && !strSumAssumed.equals(""))
    {
      strSumAssumed1 = new Double(Double.parseDouble(strSumAssumed));
    }
//End by Narendra
	Short strPeriodOfSA1 = null;
    String strPeriodOfSA = a_oRequest.getParameter("strPeriodOfSA").trim();
    if(strPeriodOfSA != null && !strPeriodOfSA.equals(""))
    {
      strPeriodOfSA1 = new Short(Short.parseShort(strPeriodOfSA));
    }

	Short strStartYear1 = null;
    String strStartYear = a_oRequest.getParameter("strStartYear").trim();
    if(strStartYear != null && !strStartYear.equals(""))
    {
      strStartYear1 = new Short(Short.parseShort(strStartYear));
    }

	Short strEndYear1 = null;
    String strEndYear = a_oRequest.getParameter("strEndYear").trim();
    if(strEndYear != null && !strEndYear.equals(""))
    {
      strEndYear1 = new Short(Short.parseShort(strEndYear));
    }

	Short radioInExclude = null;
    String strRadioInExclude = a_oRequest.getParameter("radioInEx").trim();
	log.debug("strRadioInExclude---->"+strRadioInExclude);
    if(strRadioInExclude != null && !strRadioInExclude.equals(""))
    {
      radioInExclude = new Short(Short.parseShort(strRadioInExclude));
  	  log.debug("radioInExclude--->"+radioInExclude);

    }
	
	log.debug("above nstaus");
	Short nStatus = null;
	String sv=null;
	sv=a_oRequest.getParameter("nStatus").trim();
	log.debug("sv----->"+sv);
    if(sv!= null && !sv.equals(""))
	{
		log.debug("a");
		StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nStatus"),"|");
		nStatus = new Short(st.nextToken());					
	}

	if(nStatus==null && 
		a_oRequest.getParameter("actiontype").equalsIgnoreCase(DataConstants.ACTION_CREATE))
			//|| a_oRequest.getParameter("actiontype").equalsIgnoreCase(DataConstants.ACTION_UPDATE))
	{	
		nStatus=new Short(String.valueOf(DataConstants.STATUS_PENDING_ID));
	}	
	
	log.debug("ending nStatus value--->"+nStatus);
 
    oRYCRuleMasterSearchResult.setRYCRule(strRYCRule);
    oRYCRuleMasterSearchResult.setChannelType(nChannelType);
    oRYCRuleMasterSearchResult.setStatus(nStatus);
    oRYCRuleMasterSearchResult.setEffFrom(dtEffFrom1);
    oRYCRuleMasterSearchResult.setEffto(dtEffTo1);
    oRYCRuleMasterSearchResult.setSumAssumed(strSumAssumed1);
    oRYCRuleMasterSearchResult.setPeriod(strPeriodOfSA1);
    oRYCRuleMasterSearchResult.setStartYear(strStartYear1);
    oRYCRuleMasterSearchResult.setEndYear(strEndYear1);
	oRYCRuleMasterSearchResult.setUserId(strUserId);
	oRYCRuleMasterSearchResult.setInExValue(radioInExclude);
	
	if(a_oRequest.getParameter("dRycRate") != null && !a_oRequest.getParameter("dRycRate").equals(""))
		{
			oRYCRuleMasterSearchResult.setRycRate(Double.parseDouble(a_oRequest.getParameter("dRycRate")));
		}
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
		String strRYCRuleLevel = a_oRequest.getParameter("nRuleLevel");
		oRYCRuleMasterSearchResult.setRuleLevel(strRYCRuleLevel);
//Narendra CTS for RYC rule master details as part of to AGN-09 ends

	log.debug("calling setRYCRule--->");

	String inex=a_oRequest.getParameter("radioInEx");

//Narendra CTS for RYC rule master details as part of to AGN-09 starts
	if(new Short(strRYCRuleLevel).shortValue() != DataConstants.RYC_AGENCY)
	{
	   setRYCRuleDesgnDetails(oRYCRuleMasterSearchResult,a_oRequest);

	}
	else
	{
	setRYCRuleAgencyDetails(oRYCRuleMasterSearchResult,a_oRequest);

	}
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
	setRYCRulePolicyDetails(oRYCRuleMasterSearchResult,a_oRequest);
	
  
      return oRYCRuleMasterSearchResult;	
  }

  public void setRYCRuleDesgnDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult,HttpServletRequest a_oRequest)
	{
		log.debug("1");
		 ArrayList alRYCRuleDesgDetails = new ArrayList();
		String[] arrRYCDesgnCode = a_oRequest.getParameterValues("cRYCDesgn");
		String[] arrStatusFlag = a_oRequest.getParameterValues("statusFlag");
		
		log.debug("arrRYCDesgnCode----->"+arrRYCDesgnCode);
		log.debug("arrStatusFlag"+arrStatusFlag);
        
		RYCRuleDesgDetails oRYCRuleDesgDetails =null;
		int iSize = 0;
		if(arrRYCDesgnCode != null && arrRYCDesgnCode.length > 0){
			iSize = arrRYCDesgnCode.length;
		}
		log.debug("isize---->"+iSize);
		for (int i = 0; i < iSize; i++)
		{
			log.debug("3");
			oRYCRuleDesgDetails = new RYCRuleDesgDetails();
			if(arrRYCDesgnCode[i] != null && !arrRYCDesgnCode[i].equals(""))
			{
				oRYCRuleDesgDetails.setRYCDesgn(arrRYCDesgnCode[i]);
				log.debug("after setting arrBonusApplToDesgn with value:"+arrRYCDesgnCode[i]);
			}
			if(arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				oRYCRuleDesgDetails.setStatusFlag( arrStatusFlag[i]);
				log.debug("after setting arrStatusFlag with value:"+arrStatusFlag[i]);
			}
			if(arrRYCDesgnCode[i] != null && !arrRYCDesgnCode[i].equals("") && arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				alRYCRuleDesgDetails.add(oRYCRuleDesgDetails);
			}
			
			log.debug("oRYCRuleDesgDetails----->"+oRYCRuleDesgDetails);
			log.debug("alRYCRuleDesgDetails-------->"+alRYCRuleDesgDetails);
		}
		oRYCRuleMasterSearchResult.setRYCRuleDesgDetails(alRYCRuleDesgDetails);
	}
  //Narendra CTS for RYC rule master details as part of to AGN-09 starts
  public void setRYCRuleAgencyDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult,HttpServletRequest a_oRequest)
	{
		log.debug("1");
		 ArrayList alRYCRuleAgencyDetails = new ArrayList();

		String[] arrRYCAgencyCode = a_oRequest.getParameterValues("cRYCAgency");
		String[] arrStatusFlag = a_oRequest.getParameterValues("statusFlag");

		log.debug("arrRYCAgencyCode----->"+arrRYCAgencyCode);
		log.debug("arrStatusFlag"+arrStatusFlag);

		RYCRuleAgencyDetails oRYCRuleAgencyDetails =null;
		int iSize = 0;
		if(arrRYCAgencyCode != null && arrRYCAgencyCode.length > 0){
			iSize = arrRYCAgencyCode.length;
		}
		log.debug("isize---->"+iSize);
		for (int i = 0; i < iSize; i++)
		{
			log.debug("3");
			oRYCRuleAgencyDetails = new RYCRuleAgencyDetails();
			if(arrRYCAgencyCode[i] != null && !arrRYCAgencyCode[i].equals(""))
			{
				oRYCRuleAgencyDetails.setRYCAgency(new Short(arrRYCAgencyCode[i]));
				log.debug("after setting arrBonusApplToDesgn with value:"+arrRYCAgencyCode[i]);
			}
			if(arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				oRYCRuleAgencyDetails.setStatusFlag( arrStatusFlag[i]);
				log.debug("after setting arrStatusFlag with value:"+arrStatusFlag[i]);
			}
			if(arrRYCAgencyCode[i] != null && !arrRYCAgencyCode[i].equals("") && arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				alRYCRuleAgencyDetails.add(oRYCRuleAgencyDetails);
			}

			log.debug("oRYCRuleAgencyDetails----->"+oRYCRuleAgencyDetails);
			log.debug("oRYCRuleAgencyDetails-------->"+oRYCRuleAgencyDetails);
		}
		oRYCRuleMasterSearchResult.setRYCRuleAgencyDetails(alRYCRuleAgencyDetails);
	}
  //Narendra CTS for RYC rule master details as part of to AGN-09 ends



	 public void setRYCRulePolicyDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult,HttpServletRequest a_oRequest)
	{
		log.debug("IN setRYCRulePolicyDetails");
		 ArrayList alRYCRulePolicyDetails = new ArrayList();
		String[] arrRYCPolicyCode = a_oRequest.getParameterValues("cRYCPolicy");
		String[] arrStatusFlag = a_oRequest.getParameterValues("statusFlag1");
		
		log.debug("arrRYCPolicyCode----->"+arrRYCPolicyCode);
		log.debug("arrStatusFlag--->"+arrStatusFlag);
        
		RYCRulePolicyDetails oRYCRulePolicyDetails =null;
		int iSize = 0;
		if(arrRYCPolicyCode != null && arrRYCPolicyCode.length > 0){
			iSize = arrRYCPolicyCode.length;
		}
		log.debug("isize---->"+iSize);
		for (int i = 0; i < iSize; i++)
		{
			log.debug("3");
			oRYCRulePolicyDetails = new RYCRulePolicyDetails();
			if(arrRYCPolicyCode[i] != null && !arrRYCPolicyCode[i].equals(" "))
			{
				log.debug("in policy code");
				log.debug("value of arrRYCPolicyCode[i]---->"+arrRYCPolicyCode[i]);
				oRYCRulePolicyDetails.setRYCPolicy(Long.valueOf(arrRYCPolicyCode[i]));
				log.debug("after setting arrBonusApplToPolicy with value:"+arrRYCPolicyCode[i]);
			}
			if(arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				log.debug("in status flags");
				log.debug("arrStatusFlag[i]---->"+arrStatusFlag[i]);
				oRYCRulePolicyDetails.setStatusFlag(arrStatusFlag[i]);
				log.debug("after setting arrStatusFlag with value:"+arrStatusFlag[i]);
			}
			if(arrRYCPolicyCode[i] != null && !arrRYCPolicyCode[i].equals(" ") && arrStatusFlag[i] != null && !arrStatusFlag[i].equals("") )
			{
				alRYCRulePolicyDetails.add(oRYCRulePolicyDetails);
			}
				
		
			
			log.debug("oRYCRulePolicyDetails----->"+oRYCRulePolicyDetails);
			log.debug("alRYCRulePolicyDetails-------->"+alRYCRulePolicyDetails);
		}
		oRYCRuleMasterSearchResult.setRYCRulePolicyDetails(alRYCRulePolicyDetails);
	}
 
  }
