/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : FINDER FEES
*  FILENAME			: FinderFeesSearch.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class FinderFeesSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the FinderFeesListSearch class
   */
  public FinderFeesSearch()
  {

  }
	/**
	 * The Process Method is used to retrieve single record
	 * @param a_oRequest HttpServletRequest
	 * @throws EElixirException
	 */
	public void process(HttpServletRequest a_oRequest)
		throws EElixirException
	{
		FinderFeesResult oFinderFeesResult = null;
		Long lFFHdrSeqNbr = null;

		try
		{
			a_oRequest.setAttribute("actiontype",
				DataConstants.ACTION_LISTSEARCH);

			CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			lFFHdrSeqNbr = new Long(a_oRequest.getParameter("srch_lFFHdrSeqNbr"));

			//Firing the Search Method On Remote Interface
			oFinderFeesResult = oRemoteCHMSL.searchFinderFees(lFFHdrSeqNbr.longValue());

			//Setting the Result Object
			setResult(oFinderFeesResult);
			a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		}
		catch (RemoteException rex)
		{
			log.fatal(getClass().getName(),"process","RemoteException "+rex.getMessage());
			a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
			throw new EElixirException(rex, "P1006");
		}
		catch (CreateException cex)
		{
			log.fatal(getClass().getName(),"process","CreateException "+cex.getMessage());
			a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
			throw new EElixirException(cex, "P1007");
		}
		catch (EElixirException eex)
		{
			log.fatal(getClass().getName(),"process","EElixirException "+eex.getMessage());
			a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
			throw eex;
		}
		catch (Exception ex)
		{
			log.fatal(getClass().getName(),"process","Exception "+ex.getMessage());
			a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
			throw new EElixirException(ex, "P1001");
		}
	}
}
