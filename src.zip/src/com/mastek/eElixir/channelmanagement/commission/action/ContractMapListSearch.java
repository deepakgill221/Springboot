/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMapListSearch.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 2.1       10/9/2003     Dipti F		UT Rework
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Action Class for Getting a list of Contract Map,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author    Vinaysheel
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class ContractMapListSearch extends Action
{

   /**
    * @roseuid 3B94961803B7
    */

   public ContractMapListSearch()
   {

   }

   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean
   * @param : request - Request object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */


   public void process(HttpServletRequest request)  throws EElixirException
   {
     try
     {
       request.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
       String result = null;
       CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
       log.debug("CHMSLHOME created1");
       SearchData _oSearchData = new SearchData();
       String cChannelType  = request.getParameter("cChannelType");
       _oSearchData.setTask1(cChannelType);
       String strAgentCode = request.getParameter("strAgentCd");
       _oSearchData.setTask2(strAgentCode);
     //FSD_AGN-97_Commission Mapping search changes ADDED BY SUNAINA
       String strProductCd = request.getParameter("strProductCd");
       _oSearchData.setTask10(strProductCd);
     //FSD_AGN-97_Commission Mapping search changes Ended BY SUNAINA
       String strAgentName     = request.getParameter("atb_agent_name");
       _oSearchData.setTask3(strAgentName);
       if (request.getParameter("dtEffFrom") != null)
       {
         _oSearchData.setTaskDate1(DateUtil.retGCDate(request.getParameter("dtEffFrom").trim()));
       }
	   if(request.getParameter("nStatus")!= null && !request.getParameter("nStatus").equals(""))
	   {
		   StringTokenizer st = new StringTokenizer(request.getParameter("nStatus"),"|");
		   String nStatus = st.nextToken();
		   _oSearchData.setTask4(nStatus);	
	   }
       result = remoteCHMSL.searchContractMap(_oSearchData);
       setResult(result);
     }

     catch(RemoteException rex)
     {
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       throw new EElixirException(cex, "P1007");
     }
     catch(FinderException cex)
     {
       throw new EElixirException(cex, "P1007");
     }
     catch(Exception e)
     {
        e.printStackTrace();
     }

   }
   /**
    * Member Variables
    */

   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}

