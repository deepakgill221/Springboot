/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME				: CommDispatchUpdate.java
 *  AUTHOR					: Amid P Sahu
 *  VERSION					: 1.0
 *  CREATION DATE		    : Feb 02, 2009
 *  COMPANY				    : Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *   
 *--------------------------------------------------------------------------------
 *Amid_Fin_156_Upload Of Commission Dispatch
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class CommDispatchUpdate extends Action {

	/**
	 * Constructer
	 */

	public CommDispatchUpdate() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :
	 *            ResultObject object.
	 * @roseuid 3B94961803CB
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		CHMSL remoteCHMSL = null;
		String result = null;
		try {
			log.debug("Amid inside the process method");
			setCommDispatch(request);
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			remoteCHMSL.updateCommDispatch(_oCommDispatchList);	
			SearchData _oSearchData = new SearchData();      
		    String strAgentCode = request.getParameter("srh_strAgentCd");
		    _oSearchData.setTask2(strAgentCode);  
		    String strAgencyBrchCd = request.getParameter("srh_strAgencyBrchCd");
		    _oSearchData.setTask3(strAgencyBrchCd); 
	       if (request.getParameter("srh_dtDispatch") != null)
	       {
	         _oSearchData.setTaskDate1(DateUtil.retGCDate(request.getParameter("srh_dtDispatch").trim()));
	       }      
	       String nMonth = request.getParameter("srh_nMonth");
	       _oSearchData.setTask4(nMonth);      
	       String nYear = request.getParameter("srh_nYear");
	       _oSearchData.setTask5(nYear); 
	       String nCommission = request.getParameter("srh_nCommission");
	       _oSearchData.setTask6(nCommission);  
	       //code added by anup  for seva tkt# 73885 starts
	       HttpSession session = request.getSession();
	       String _strUserId = (String) session.getAttribute("username");
	       _oSearchData.setTask7(_strUserId);
	       // code added by anup  for seva tkt# 73885 ends
	       result = remoteCHMSL.searchCommissionDispatch(_oSearchData);
	       request.setAttribute("srh_strAgentCd",strAgentCode);
	       request.setAttribute("srh_strAgencyBrchCd",strAgencyBrchCd);
	       request.setAttribute("srh_dtDispatch",request.getParameter("dtDispatch"));
	       request.setAttribute("srh_nMonth",nMonth);
	       request.setAttribute("srh_nYear",nYear);
	       request.setAttribute("srh_nCommission",nCommission);
	       setResult(result);
			request.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
		} catch (FinderException fex) {
			request.setAttribute("ResultObject", _oCommDispatchList);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oCommDispatchList);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oCommDispatchList);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log.debug("In SegmentUpdate eelixir exception before setting result"
							+ eLex);
			
			request.setAttribute("ResultObject", _oCommDispatchList);
			throw eLex;
		}

	}

	private void setCommDispatch(HttpServletRequest a_oRequest) {
		
		String SeqNumb[] = a_oRequest.getParameterValues("lcommdispatchseqno");
		String strModePayment[] = a_oRequest.getParameterValues("str_mode_payment_td");
		String strAccNo[] = a_oRequest.getParameterValues("str_acc_no_td");
		String strFavourOf[] = a_oRequest.getParameterValues("str_favour_of_td");
		String strAmtDispatch[] = a_oRequest.getParameterValues("str_amt_dispatch_td");
		String strBankName[] = a_oRequest.getParameterValues("str_bank_name_td");		
		String strModeOfDispatch[] = a_oRequest.getParameterValues("str_mode_of_dispach_td");
		String strRemarks[] = a_oRequest.getParameterValues("str_remarks_td");
		String strAwbNum[] = a_oRequest.getParameterValues("str_awb_num_td");
		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String) session.getAttribute("username");
		String[] strDtDispatch  = a_oRequest.getParameterValues("str_dispatch_date_td");
		

		if (SeqNumb != null) {
			log.debug("Amid inside the setCommDispatch method befor SeqNumb.length>>"+SeqNumb.length);
			for (int i = 0; i < SeqNumb.length; i++) {
				
					_oCommDispatchResult = new CommDispatchResult();
					log.debug("Amid inside the setCommDispatch method befor seqno"+SeqNumb[i]);
					if (SeqNumb[i] != null && !SeqNumb[i].trim().equals("")) {
						_oCommDispatchResult.setCommDispatchSeqno(new Long(SeqNumb[i]));

					} else {
						_oCommDispatchResult.setCommDispatchSeqno(null);
					}
					log.debug("Amid inside the setCommDispatch method after seqno>>"+SeqNumb[i]);
					_oCommDispatchResult.setModePayment(strModePayment[i]);
					_oCommDispatchResult.setAccNo(strAccNo[i]);
					_oCommDispatchResult.setFavourOf(strFavourOf[i]);
					_oCommDispatchResult.setAmtDispatch(strAmtDispatch[i]);
					_oCommDispatchResult.setBankName(strBankName[i]);
					_oCommDispatchResult.setModeOfDispatch(strModeOfDispatch[i]);
					_oCommDispatchResult.setRemarks(strRemarks[i]);
					_oCommDispatchResult.setAwbNum(strAwbNum[i]);					
					_oCommDispatchResult.setUserId(_strUserId);
					if (strDtDispatch[i] != null && !strDtDispatch[i].trim().equals(""))
			          {
						_oCommDispatchResult.setDispatch(DateUtil.retGCDate(strDtDispatch[i].trim()));
			        		 log.debug("strDtDispatch"+_oCommDispatchResult.getDispatch());			            
			          }
					_oCommDispatchList.add(_oCommDispatchResult);
			}
		}
	}

	// class level variable declarations.

	CommDispatchResult _oCommDispatchResult = null;

	ArrayList _oCommDispatchList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
