/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: NewContractMapCreate.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

/**
 * Called at the beginnning of ContractMappingCreate
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author    Vinaysheel Baber
 * @version 1.0
 */

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;

public class NewContractMapCreate extends Action
{

   /**
    * @roseuid 3B94961803B7
    */
   public NewContractMapCreate()
   {

   }

   /**
   * blank process method to follow the MVC architecture, it just makes the xsl file available to the requested jsp at the beginning
   * @param : request - Request object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */
   public void process(HttpServletRequest request)  throws EElixirException
   {
	request.setAttribute("actiontype", DataConstants.ACTION_CREATE);
   }
}
