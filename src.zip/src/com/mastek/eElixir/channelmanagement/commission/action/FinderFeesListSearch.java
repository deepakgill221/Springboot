/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : FINDER FEES
*  FILENAME			: FinderFeesListSearch.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	: October 20, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get FinderFeesListSearch is the Action Class for Getting a list of FinderFees ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Shameem Shaik
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class FinderFeesListSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the FinderFeesListSearch class
   */
  public FinderFeesListSearch()
  {

  }

  /**
   * This method uses the search data and to populate FinderFees
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {

	String result =null;
	try{
		
	  CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
	  
	  // if strContractName is not defined from the requesting page then retrieve distinct approved records.
	  // This condition is used in displaying/adding Finder Fee Rules in Finder Rule Mapping --> New/Detials Screen.
	  if(a_oRequest.getParameter("strContractName")!=null)
	  {  
		  log.debug("FinderFeesListSearch -- > strContractName found");
		  
		  String strContractName = a_oRequest.getParameter("strContractName");	  
		  String dtEffFrom	= a_oRequest.getParameter("dtEffFrom")==null?"":a_oRequest.getParameter("dtEffFrom");
		  String nStatus	= ""; 
	
		  SearchData oSearchData = new SearchData();
		  oSearchData.setTask1(strContractName);
		  if(a_oRequest.getParameter("nStatus")!= null && !a_oRequest.getParameter("nStatus").equals(""))
			 {
				 StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nStatus"),"|");
				 nStatus = st.nextToken();
				 oSearchData.setTask2(nStatus);	
			 }	  
		  
		  if(!dtEffFrom.trim().equals("")){
			oSearchData.setTaskDate1(DateUtil.retGCDate(dtEffFrom.trim()));
		  }
		  else{
			oSearchData.setTaskDate1(null);
		  }
		  
			log.debug("strContractNumber :"+strContractName);
			log.debug("dtEffFrom :"+dtEffFrom);			
			log.debug("nStatus :"+a_oRequest.getParameter("nStatus"));
	
		  a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);
		  result = remoteCHMSL.searchFinderFees(oSearchData);
		  log.debug("FinderFeesResult--result accessed & result is :"+result);
	  }
	  else
	  {
		 log.debug("FinderFeesListSearch -- > strContractName not found; retrieving distinct approved Finder Rules");
		 result = remoteCHMSL.searchFinderFees();
		log.debug("FinderFeesResult--result accessed & result is :"+result);
	  }
	  
	  setResult(result);
	  log.debug("FinderFeesListSearch	-- > result is set");
	}


	catch(RemoteException rex)
	{
	  throw new EElixirException(rex, "P1006");
	}
	catch(CreateException cex)
	{
	  throw new EElixirException(cex, "P1007");
	}
	catch(FinderException fex)
	{
	  throw new EElixirException(fex, "P9002");
	}
  }


}