/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : FINDER FEES
*  FILENAME			: FinderFeesSearch.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------

**********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

public class FinderFeesDelete extends Action
{
	private FinderFeesResult oFinderFeesResult = null;
	private static final Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	/**
	 * Constructor for BonusDelete 
	 */
	public FinderFeesDelete()
	{
	}

	/**
	 * METHOD process calls the CHMEJB to delete Bonus
	 * @param  a_oRequest HttpServletRequest 
	 * @throws EELixirException
	 */
	public void process(HttpServletRequest a_oRequest)
		throws EElixirException
	{
		//setBonusHeader(a_oRequest);
		Long lFFHdrSeqNbr = null;
		try
		{
			a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);

			CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

			lFFHdrSeqNbr = new Long(a_oRequest.getParameter("lFFHdrSeqNbr"));
			oRemoteCHMSL.deleteFinderFees(lFFHdrSeqNbr);
			a_oRequest.setAttribute("actiontype", DataConstants.ACTION_DELETE);
		}
		catch (CreateException cex)
		{
			log.fatal(getClass().getName(),"process","CreateException "+cex.getMessage());
			a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
			throw new EElixirException(cex, "P1007");
		}
		catch (FinderException fex)
		{
			log.fatal(getClass().getName(),"process","FinderException "+fex.getMessage());
			a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
			throw new EElixirException(fex, "P1006");
		}
		catch (RemoteException rex)
		{
			log.fatal(getClass().getName(),"process","RemoteException "+rex.getMessage());
			a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
			throw new EElixirException(rex, "P1006");
		}

		catch (EElixirException eex)
		{
			log.fatal(getClass().getName(),"process","EElixirException "+eex.getMessage());
			a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
			throw eex;
		}
	}

	/**
	 * sets the header part
	 * @param  a_oRequest HttpServletRequest
	 */
	private void setFinderFeesHeader(HttpServletRequest a_oRequest)
	{
		FinderFeesResult oFinderFeesResult = null;
		log.debug("FinderFeesDelete --> Inside setFinderFeesHeader");	

		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String)session.getAttribute("username");	
	
		String strContractName 		= a_oRequest.getParameter("strContractName").trim();
		Long lFFHDRSeqNbr=null;
	
		if(a_oRequest.getParameter("lFFHdrSeqNbr")!=null 
				&& !a_oRequest.getParameter("lFFHdrSeqNbr").trim().equals(""))
		{		
				lFFHDRSeqNbr	= new Long(a_oRequest.getParameter("lFFHdrSeqNbr").trim());
		}
	 
	
		GregorianCalendar dtEffFrom = DateUtil.retGCDate(a_oRequest.getParameter("dtEffFrom").trim());
		Short nStatus=null;
		if(a_oRequest.getParameter("nStatus")!= null && !a_oRequest.getParameter("nStatus").equals(""))
		{
			StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nStatus"),"|");
			nStatus = new Short(st.nextToken());					
		}	
	
		// if null and new/updating record to create/update - default status is pending.
		log.debug("actiontype	:"+a_oRequest.getParameter("actiontype"));	
	
		if(nStatus==null && 
			a_oRequest.getParameter("actiontype").equalsIgnoreCase(DataConstants.ACTION_DELETE))
		{	
			nStatus=new Short(String.valueOf(DataConstants.STATUS_PENDING_ID));
		}	

		Short nIsProductSpecific	= new Short(a_oRequest.getParameter("nIsProductSpecific").trim());	
		
		Short nBasis	= new Short(a_oRequest.getParameter("nBasis").trim());
		

		oFinderFeesResult = new FinderFeesResult();
		
		oFinderFeesResult.setFFHDRSeqNbr(lFFHDRSeqNbr);
		oFinderFeesResult.setContractName(strContractName);
		oFinderFeesResult.setEffFrom(dtEffFrom);
		oFinderFeesResult.setStatus(nStatus);
		oFinderFeesResult.setBasis(nBasis);
		oFinderFeesResult.setIsProdSpecific(nIsProductSpecific);
		oFinderFeesResult.setUserId(_strUserId);	
		
	}
	
	
}