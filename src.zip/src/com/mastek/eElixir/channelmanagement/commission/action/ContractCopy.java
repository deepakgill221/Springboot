/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractCopy.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 16, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get ContractCopy is the Action Class for copying the existing contract to new
 * It is applicable for only new Contract.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.ContractCopyResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

public class ContractCopy extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the ContractListSearch class
   */
  public ContractCopy()
  {

  }

  /**
   * This method uses the search data and to populate Contract
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    Object contractResult = null;
    String result =null;
    try{
      log.debug("ContractCopy--Inside Contract Copy");
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      String strContractNumber = a_oRequest.getParameter("strContractNbr");
      if(strContractNumber != null){
        strContractNumber = strContractNumber.trim();
      }

      String dtEffFrom = a_oRequest.getParameter("dtEffFrom");
      if(dtEffFrom != null){
        dtEffFrom = dtEffFrom.trim();
      }
      String strContractNbrApproved = a_oRequest.getParameter("strContractNbrApproved");
      if(strContractNbrApproved != null){
        strContractNbrApproved = strContractNbrApproved.trim();
      }
      String strYesNo = a_oRequest.getParameter("strYesNo");
      if(strYesNo != null){
        strYesNo = strYesNo.trim();
      }
// amit added 11/1/2002
	  HttpSession  session = a_oRequest.getSession();
	  String  strUserId = (String)session.getAttribute("username");



      ContractCopyResult oContractCopyResult = new ContractCopyResult();
      // added by amit 11/1/2002
	  oContractCopyResult.setUserId(strUserId);

	  oContractCopyResult.setContractNumber(strContractNumber);
      if(!dtEffFrom.trim().equals("")){
        oContractCopyResult.setEffectiveDate(DateUtil.retGCDate(dtEffFrom.trim()));
      }
      else{
        oContractCopyResult.setEffectiveDate(null);
      }
      oContractCopyResult.setApprovedContractNumber(strContractNbrApproved);
      oContractCopyResult.setYesNo(strYesNo);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);
      remoteCHMSL.copyContract(oContractCopyResult);
      log.debug("ContractCopy--result accessed");
      setResult(oContractCopyResult);
      log.debug("ContractCopy--result is set");
    }


    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "P3024");
    }
    catch(EElixirException eex)
    {
      log.debug("ContractCopy--Inside catch of Eelixir exception in process of ContractCopy");
      //a_oRequest.setAttribute("ResultObject", oContractResult);
      throw eex;
    }
  }


}