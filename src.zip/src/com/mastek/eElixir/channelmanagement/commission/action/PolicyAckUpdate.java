/********************************************************************
*
*  PROJECT                        : MNYL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : PolicyAckUpdate.java
*  AUTHOR                         : Dipti Fondekar
*  VERSION                        : 1.0
*  SPECS NAME                     : cm_policy_ackn_upd.doc.doc
*  CREATION DATE                  : 29/08/2003
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE          BY        REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.PolicyAckResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;


public class PolicyAckUpdate extends Action
{
    
    PolicyAckResult _oPolicyAckResult = null;
    ArrayList _oPolicyAckList = new ArrayList();
	private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * @roseuid 3B94961803B7
     */
    public PolicyAckUpdate()
    {
    }

  
    /**
    * This method makes a remote call to the Session bean which in turn makes a local
    * call to all other bean .
    * @param : PolicyAck object.
    * @roseuid 3B94961803CB
    * @throws EElixirException
    */
    public void process(HttpServletRequest request) throws EElixirException
    {
        request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
        SearchData _oSearchData = new SearchData();
        CHMSL remoteCHMSL = null;
		String strPolNbr =null;
		String strServAgentCd =null;
		String strPolAckn =null;
        try
        {
            setPolicyAck(request);
            remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
            remoteCHMSL.updatePolicyAck(_oPolicyAckList);
            strPolNbr = request.getParameter("strPolNbrHdr");
            strServAgentCd = request.getParameter("strServAgentCd");
            strPolAckn = request.getParameter("dtPolAckn");
            _oSearchData.setTask1(strPolNbr.trim());
            _oSearchData.setTask2(strServAgentCd.trim());
            _oSearchData.setTask3(strPolAckn.trim());
            _oPolicyAckList = remoteCHMSL.searchPolicyAck(_oSearchData);
            setResult(_oPolicyAckList);
	     }
        catch (FinderException fex)
        {
			_oLogger.fatal(getClass().getName(), "Process", fex.getMessage());
            request.setAttribute("ResultObject", _oPolicyAckList);
            throw new EElixirException(fex, "P1007");
        }
        catch (RemoteException rex)
        {
			_oLogger.fatal(getClass().getName(), "Process", rex.getMessage());
            request.setAttribute("ResultObject", _oPolicyAckList);
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
            request.setAttribute("ResultObject", _oPolicyAckList);
			_oLogger.fatal(getClass().getName(), "Process", cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (EElixirException eex)
        {
            if (eex.getCustomErrorCode().equalsIgnoreCase("P1100"))
            {
                try
                {
	                strPolNbr = request.getParameter("strPolNbrHdr");
					strServAgentCd = request.getParameter(
                            "strServAgentCd");
					strPolAckn = request.getParameter("dtPolAckn");
					_oSearchData.setTask1(strPolNbr.trim());
				    _oSearchData.setTask2(strServAgentCd.trim());
				    _oSearchData.setTask3(strPolAckn.trim());
		   		    _oPolicyAckList = remoteCHMSL.searchPolicyAck(_oSearchData);
                }
                catch (RemoteException rex)
                {
                    request.setAttribute("ResultObject", _oPolicyAckList);
                    throw new EElixirException(rex, "P1006");
                }
                catch (FinderException cex)
                {
                    request.setAttribute("ResultObject", _oPolicyAckList);
                    throw new EElixirException(cex, "P1007");
                }
            }
			_oLogger.fatal(getClass().getName(), "Process", eex.getMessage());
            request.setAttribute("ResultObject", _oPolicyAckList);
            throw eex;
        }

        
    }

    private void setPolicyAck(HttpServletRequest a_oRequest)
    {
        HttpSession session = a_oRequest.getSession();
        String strUserId = (String) session.getAttribute("username");
        String strServAgentCd = a_oRequest.getParameter("strServAgentCd");
        String[] strPolNbr = a_oRequest.getParameterValues("strPolNbr");
        String[] statusFlag = a_oRequest.getParameterValues("statusFlag");
        String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");
        String[] dtPolAckn = a_oRequest.getParameterValues("dt_PolAckn_td");
        String[] dtPolAcknReceipt = a_oRequest.getParameterValues(
                "dt_PolAcknReceipt_td");
		
        if (statusFlag != null)
        {
			for (int i = 0; i < statusFlag.length; i++)
            {
                _oPolicyAckResult = new PolicyAckResult();
                if ((dtUpdated!=null && dtUpdated[i] != null) && !dtUpdated[i].trim().equals(""))
                {
                    _oPolicyAckResult.setTsDtUpdated(Timestamp.valueOf(
                            dtUpdated[i]));
                }
                if ((dtPolAcknReceipt !=null && dtPolAcknReceipt[i] != null) &&
                        !dtPolAcknReceipt[i].trim().equals(""))
                {
                    _oPolicyAckResult.setPolAcknReceipt(DateUtil.retGCDate(
                            dtPolAcknReceipt[i]));
                }
                if ((dtPolAckn !=null && dtPolAckn[i] != null) && !dtPolAckn[i].trim().equals(""))
                {
                    _oPolicyAckResult.setPolAckn(DateUtil.retGCDate(
                            dtPolAckn[i]));
                }
                _oPolicyAckResult.setPolNbr(strPolNbr[i].trim());
                _oPolicyAckResult.setServAgentCd(strServAgentCd.trim());
                _oPolicyAckResult.setStatusFlag(statusFlag[i]);
                _oPolicyAckResult.setUserId(strUserId);
                _oPolicyAckList.add(_oPolicyAckResult);
            }
        }
    }
}

