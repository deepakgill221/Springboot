/********************************************************************
 *
 *  PROJECT				: MAMM
 *  MODULE NAME			: CHANNEL MANAGEMENT
 *  FILENAME			: SaveUpdateDisbumSetupDetails.java
 *  AUTHOR				: Vibhu Nigam
 *  VERSION				: 1.0
 *  CREATION DATE		: April 07, 2015
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT			: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.DisbursementSetupResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class SaveUpdateDisbumSetupDetails extends Action {

	/**
	 * @Constructor
	 */
	public SaveUpdateDisbumSetupDetails() {
	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :HttpServletRequest request ResultObject object.
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		CHMSL remoteCHMSL = null;
		try {
			log.debug("SaveUpdateDisbumSetupDetails--Starts");
			getDisbumSetupDtls(request);
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			remoteCHMSL.SaveUpdateDisbumSetupDetails(_oDisbumSetuplst);
			_oDisbumSetuplst = remoteCHMSL.getDisbursementSetup();
			setResult(_oDisbumSetuplst);
			log.debug("SaveUpdateDisbumSetupDetails--Ends");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oDisbumSetuplst);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oDisbumSetuplst);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log.debug("In updateOverrideCommRule elixir exception before setting result"
					+ eLex);
			request.setAttribute("ResultObject", _oDisbumSetuplst);
			throw eLex;
		}

	}

	private void getDisbumSetupDtls(HttpServletRequest a_oRequest) {
		log.debug("SaveUpdateDisbumSetupDetails--getDisbumSetupDtls--Starts");
		String strPaymentMthd[] = a_oRequest
				.getParameterValues("strPaymentMthd");
		String strDisbumAmntLmt[] = a_oRequest
				.getParameterValues("strDisbumAmntLmt");
		String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
		String strDisbumSeq[] = a_oRequest.getParameterValues("strDisbumSeq");
		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String) session.getAttribute("username");
		for (int i = 0; i < strPaymentMthd.length; i++) {

			_oDisbursementSetupResult = new DisbursementSetupResult();
			_oDisbursementSetupResult.setnPaymentMthd(Integer
					.valueOf(strPaymentMthd[i]));
			_oDisbursementSetupResult.setdDisbumAmntLmt(Double
					.valueOf(strDisbumAmntLmt[i]));
			_oDisbursementSetupResult.setUserId(_strUserId);
			_oDisbursementSetupResult.set_strUpdatedBy(_strUserId);
			_oDisbursementSetupResult.setstrStatusFlag(statusFlag[i]);
			if (!(statusFlag[i].trim().equals(DataConstants.INSERT_MODE))) {
				_oDisbursementSetupResult.setStrDisbumSeq(Long
						.parseLong(strDisbumSeq[i]));
				log.debug("_oDisbursementSetupResult.setStrDisbumSeq::::::"
						+ Long.getLong(strDisbumSeq[i]));
				log.debug("_oDisbursementSetupResult.setStrDisbumSeq::::::"
						+ _oDisbursementSetupResult.getStrDisbumSeq());
			}
			_oDisbumSetuplst.add(_oDisbursementSetupResult);
		}
		log.debug("SaveUpdateDisbumSetupDetails--getDisbumSetupDtls--Starts");
	}

	// class level variable declarations.
	DisbursementSetupResult _oDisbursementSetupResult = null;

	ArrayList _oDisbumSetuplst = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
