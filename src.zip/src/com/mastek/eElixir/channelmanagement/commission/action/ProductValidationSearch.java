/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME				: CHANNEL MANAGEMENT
*  FILENAME					: ProductValidationSearch.java
*  AUTHOR					: Anup Kumar
*  VERSION					: 1.0
*  CREATION DATE			: Sep 07, 2009
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2002.
*  CODE TAG 				: Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;





public class ProductValidationSearch extends Action
{

    public ProductValidationSearch() 
    {
    }
    /**
     * This method will look up for the remote interface of remote session bean
     * and and then populate the request object with the appropriate dvo and will
     * then call the rquired method of the bean.
     * @param a_oRequest HttpServletRequest
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest) throws EElixirException
    {
    	String strAgencyCode=a_oRequest.getParameter("tempAgencyCode");    	
    	String strProdCode=a_oRequest.getParameter("tempProductCode");      
    	String dtEffFrom=a_oRequest.getParameter("tempdtEffFrom");  
        
    	CHMSL remoteCHMSL = null;
		String strProdValidResult=null;		
        try
		{			
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);        		
			strProdValidResult = remoteCHMSL.productCodeExists(strAgencyCode,strProdCode,dtEffFrom);			
			//strProdValidResult = XMLConverter.addTaginXML(strProdValidResult,"TCODE",tCode);			
			setResult(strProdValidResult);
        }
        catch(RemoteException rex)
        {
        	a_oRequest.setAttribute("ResultObject", strProdValidResult);
          throw new EElixirException(rex, "P1006");
        }        
        catch(CreateException cex)
        {
        	a_oRequest.setAttribute("ResultObject", strProdValidResult);
          throw new EElixirException(cex, "P1007");
        }

        catch(EElixirException cex)
        {
        	a_oRequest.setAttribute("ResultObject", strProdValidResult);
          throw cex;
        }      
    }

    //Class level parameters
    private Logger _oLog = Logger.getInstance(Constants.CHM_MODULE_ID);
}