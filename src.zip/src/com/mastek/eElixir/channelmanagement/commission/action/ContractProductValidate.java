/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractProductValidate.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get ContractListSearch is the Action Class for Getting a list of Contract ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.dvo.ContractProdValidate;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class ContractProductValidate extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the ContractListSearch class
   */
  public ContractProductValidate()
  {

  }

  /**
   * This method uses the search data and to populate Contract
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    Object contractResult = null;
    String result =null;
    try{
      log.debug("ContractProductValidate--Inside process of ContractProductValidate");
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      String strCommType = a_oRequest.getParameter("nCommType");
      String strProdCdVer = a_oRequest.getParameter("strProdCdVer");
      Short nCommType = null;
      if(strCommType != null){
        nCommType = new Short(strCommType);
      }
      StringTokenizer st = new StringTokenizer(strProdCdVer,"|");
      String strProdCd = null;
      String strProdVer = null;

	  log.debug ("strProdCdVer => " + strProdCdVer);

      while(st.hasMoreTokens()){
        strProdCd = (String)st.nextElement();
        break;
      }
      while(st.hasMoreTokens()){
        strProdVer = (String)st.nextElement();
	    }

      Integer iProdVer = null;
      if(strProdVer != null){
        iProdVer = new Integer(strProdVer);

      }

      
	  ContractProdValidate oContractProdValidate = new ContractProdValidate();
      oContractProdValidate.setCommType(nCommType);
      oContractProdValidate.setProdCd(strProdCd);
      oContractProdValidate.setProdVer(iProdVer);

	  log.debug ("nCommType :" + nCommType);
	  log.debug ("strProdCd :" + strProdCd);
	  log.debug ("iProdVer :" + iProdVer);

      //a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);

      oContractProdValidate = remoteCHMSL.getContractBaseUnit(oContractProdValidate);

      setResult(oContractProdValidate);
      log.debug("ContractProductValidate--result is set done");
    }


    catch(RemoteException rex)
    {
      rex.printStackTrace();
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      cex.printStackTrace();
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      fex.printStackTrace();
      throw new EElixirException(fex, "P3024");
    }
  }


}