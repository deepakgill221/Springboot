/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractCreate.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*1.1             16Jan2003         Pallav            added payment Mode
*1.2             23Jan2003         Pallav            added Term Type, and Maturity Age
*1.3             7Feb2003         Pallav            changed statusFlag as statusFlagC and statusFlagS
* 1.4    13/Nov/2009		 Anup Kumar     Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * ContractCreate is the Action Class for creating a new Contract.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionValidator;
import com.mastek.eElixir.channelmanagement.commission.util.ContractButtonPallete;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;


public class ContractCreate extends Action
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the ContractCreate class
   */
  public ContractCreate()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ContractResult oContractResult = null;
    //CommissionDetails[] arrCommissionDetails;
    try{
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      String strContractNumber = a_oRequest.getParameter("strContractNbr");
      int iContractStatus = DataConstants.STATUS_PENDING_ID; // for Pending
      oContractResult = new ContractResult();
      
   
      	
      oContractResult.setContractNumber(strContractNumber);
      oContractResult.setEffectiveDate(DateUtil.retGCDate(a_oRequest.getParameter("dtEffFrom").trim()));
      oContractResult.setContractStatus(new Integer(iContractStatus));
      log.debug(strContractNumber + " " + iContractStatus);
      //String strComAgreementKey = a_oRequest.getParameter("strComAgreementKey");
      String strCommBase = a_oRequest.getParameter("nCommBase");
      // added code for nPmtMode
      String strPmtMode = a_oRequest.getParameter("nPmtMode");
      // added code for nTermType
      String strTermType = a_oRequest.getParameter("nTermType");
      String strCommType = a_oRequest.getParameter("nCommType");
      String strCommClass = a_oRequest.getParameter("strCommClass");
      String strProdCdVer = a_oRequest.getParameter("strProdCdVer");
	  String strBaseProdCdVer = a_oRequest.getParameter("strBaseProdCdVer");
	  //Arun_RatchetedComm_Rel8.3_Phase2_Start  
	  String strCommBandCd =a_oRequest.getParameter("nCommBandCd");
	  log.debug("strCommBandCd is "+strCommBandCd);
	  //Arun_RatchetedComm_Rel8.3_Phase2_End
	  
	  //Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 Start
	  Float nMultiplierOf = null;
	  Float nCommMultiplierDtls = null;
	  String nApplyMultiplier = a_oRequest.getParameter("nApplyMultiplier");
	  String nCompareMultiplierWith = a_oRequest.getParameter("nCompareMultiplierWith");
	  String nApplyMultiplierOn = a_oRequest.getParameter("nApplyMultiplierOn");
	  String strMultiplierOf = a_oRequest.getParameter("strMultiplierOf");
	  String strCommMultiplierDtls = a_oRequest.getParameter("strCommMultiplierDtls");
	  
	  //new fields added
	  String nCommMultpWtFlag         = a_oRequest.getParameter("nCommMultpWtFlag");	  
	  String nCommMultpWtFlagComp     = a_oRequest.getParameter("nCommMultpWtFlagComp");
	  
	  Float strCommMultiplierWt      = null;
	  Float strIfWtCommMultiplier    = null;
	  Float strRedWtCommMultiplierBy = null;
	  Float strIfWtCommMultiplierLt  = null;
	  Float strThenApplyWtOf         = null;
	  
	  if(a_oRequest.getParameter("strCommMultiplierWt")!=null && !"".equals(a_oRequest.getParameter("strCommMultiplierWt").trim())){
		  strCommMultiplierWt = Float.valueOf(a_oRequest.getParameter("strCommMultiplierWt").trim());
	  }
	  if(a_oRequest.getParameter("strIfWtCommMultiplier")!=null && !"".equals(a_oRequest.getParameter("strIfWtCommMultiplier").trim())){
		  strIfWtCommMultiplier = Float.valueOf(a_oRequest.getParameter("strIfWtCommMultiplier").trim());
	  }
	  if(a_oRequest.getParameter("strRedWtCommMultiplierBy")!=null && !"".equals(a_oRequest.getParameter("strRedWtCommMultiplierBy").trim())){
		  strRedWtCommMultiplierBy = Float.valueOf(a_oRequest.getParameter("strRedWtCommMultiplierBy").trim());
	  }
	  if(a_oRequest.getParameter("strIfWtCommMultiplierLt")!=null && !"".equals(a_oRequest.getParameter("strIfWtCommMultiplierLt").trim())){
		  strIfWtCommMultiplierLt = Float.valueOf(a_oRequest.getParameter("strIfWtCommMultiplierLt").trim());
	  }
	  if(a_oRequest.getParameter("strThenApplyWtOf")!=null && !"".equals(a_oRequest.getParameter("strThenApplyWtOf").trim())){
		  strThenApplyWtOf = Float.valueOf(a_oRequest.getParameter("strThenApplyWtOf").trim());
	  }
	  
	  if(strMultiplierOf!=null && !strMultiplierOf.trim().equals("")){
		  nMultiplierOf = Float.valueOf(strMultiplierOf.trim());
	  }
	  if(strCommMultiplierDtls!=null && !strCommMultiplierDtls.trim().equals("")){
		  nCommMultiplierDtls = Float.valueOf(strCommMultiplierDtls.trim());
	  }
	  log.debug(nMultiplierOf + " -nMultiplierOf- " + nCommMultiplierDtls + " -nCommMultiplierDtls- " + nApplyMultiplier + " -strApplyMultiplier- " + nCompareMultiplierWith + " -strCompareMultiplierWith- " + nApplyMultiplierOn + " -strApplyMultiplierOn- ");
	  //Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 End
	  
	  String strBaseProd = null;
	  Integer iBaseProdVer = null;
      Short nCommType = null;
      Short nPmtMode = null;
      Short nTermType = null;
      Short nCommBase = null;
	  Short nCommBandCd = null; //Arun_RatchetedComm_Rel8.3_Phase2
      
      // added by amit 11/1/2002 ## to check for commision also
	  HttpSession  session = a_oRequest.getSession();
	  String  strUserId = (String)session.getAttribute("username");
	  log.debug("strUserId:" + strUserId);
      oContractResult.setUserId(strUserId);


      if(strCommType != null){
        nCommType = new Short(strCommType);
      }
      if(strCommBase != null){
        nCommBase = new Short(strCommBase);
      }
      if(strPmtMode != null){
        nPmtMode = new Short(strPmtMode);
      }
      if(strTermType != null){
        nTermType = new Short(strTermType);
      }
      if(strCommBandCd != null){
    	  nCommBandCd = new Short(strCommBandCd);
        }
      log.debug(nCommBase + " " + nPmtMode + " " + nTermType + " " + nCommType + " -- " + strCommClass + " " + strProdCdVer+"---"+nCommBandCd);

      // Product is stored as Product Code | Product Version. It is seperated with a pipe character.
      // It has to be tokenized to get both the value.
      StringTokenizer st = new StringTokenizer(strProdCdVer,"|");
      String strProdCd = null;
      String strProdVer = null;
      String strPlanType = null;
      String strBasePlanType = null;
      while(st.hasMoreTokens()){
        strProdCd = (String)st.nextElement();
        log.debug("Contract Create got product code " + strProdCd);
        break;
      }
      
      while(st.hasMoreTokens()){
          strPlanType = (String)st.nextElement();
          log.debug("Contract Create got plan type " + strPlanType);
          break;
	  }
	  
      while(st.hasMoreTokens()){
        strProdVer = (String)st.nextElement();
        log.debug("Contract Create got product version type " + strProdVer);
        break;
	  }
	  
	  Integer iProdVer = null;
	  if(strProdVer != null){
        iProdVer = new Integer(strProdVer);
      }
     
      st = null;
      st = new StringTokenizer(strBaseProdCdVer, "|");
      while(st.hasMoreTokens())
      {
	      strBaseProd = (String)st.nextElement();
	      log.debug("Contract Create got base product code " + strBaseProd);
	      break;
      }
      
      while(st.hasMoreTokens()){
          strBasePlanType = (String)st.nextElement();
          log.debug("Contract Create got base plan type " + strBasePlanType);
          break;
	  }
	  while(st.hasMoreTokens()){
          strProdVer = (String)st.nextElement();
          log.debug("Contract Create got base product version  " + strProdVer);
	  }
	  
	  if (strProdVer != null)
	  {
	   iBaseProdVer = new Integer(strProdVer);
   	  }
      
      String strCampaignCd = a_oRequest.getParameter("strCampaignCd");
      String iBaseUnits = a_oRequest.getParameter("iBaseUnits");
      //String strDistribType = a_oRequest.getParameter("strDistribType");

      log.debug(strProdCd + " " + strProdVer + " " + strCampaignCd + " " + iBaseUnits );

      CommissionResult oCommissionResult = new CommissionResult();
      oCommissionResult.setCommBase(nCommBase);
      oCommissionResult.setPmtMode(nPmtMode);
      oCommissionResult.setTermType(nTermType);
      oCommissionResult.setCommType(nCommType);
      oCommissionResult.setCommClass(strCommClass);
      oCommissionResult.setProdCd(strProdCd);
      oCommissionResult.setUserId(strUserId);
      oCommissionResult.setCommBandCd(nCommBandCd);//Arun_RatchetedComm_Rel8.3_Phase2
      if (strPlanType != null)
	  {
		  Short nPlanType = new Short(strPlanType);
		  oCommissionResult.setPlanType(nPlanType);
	  }
      
	  if (strBasePlanType != null)
	  {
		  Short nPlanType = new Short(strBasePlanType);
		  oCommissionResult.setBasePlanType(nPlanType);
	  }
	  
      if (strBaseProd != null)
      {
	  	oCommissionResult.setBaseProdCd(strBaseProd);
	  	log.debug("Added base product code as " + strBaseProd);
  	  }
  	  if (iBaseProdVer != null)
  	  {
	  	oCommissionResult.setBaseProdVer(iBaseProdVer);
	  	log.debug("Added base product version as " + iBaseProdVer);
  	  }
  	  
      oCommissionResult.setProdVer(iProdVer);
      oCommissionResult.setCampaignCd(strCampaignCd);
      oCommissionResult.setBaseUnits(new Integer(iBaseUnits.trim()));
      //oCommissionResult.setDistribType(strDistribType);
      //oCommissionResult.setComAgreementKey(strComAgreementKey);
		//Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
      if(nCommType.intValue() == DataConstants.STANDARD_COMMISSION || nCommType.intValue() == DataConstants.TRAIL_COMMISSION || nCommType.intValue() == DataConstants.INDEX_COMMISSION  || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION){ // for standard commission, or Trail
        log.debug("ContractCreate--inside standard commission fetch");
        oCommissionResult.setCommissionDetail(standardCommissionParameterFetch(a_oRequest,nCommType.intValue()));
      }
      else if(nCommType.intValue()  == DataConstants.CLAWBACK_COMMISSION){ // for Clawback
        log.debug("ContractCreate--inside clawback commission fetch");
        oCommissionResult.setClawBackDetail(clawBackParameterFetch(a_oRequest));
      }
      
	  //Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 Start
      oCommissionResult.set_nApplyMultiplier(nApplyMultiplier);
      oCommissionResult.set_nApplyMultiplierOn(nApplyMultiplierOn);
      oCommissionResult.set_nCompareMultiplierWith(nCompareMultiplierWith);
      oCommissionResult.set_nCommMultiplierDtls(nCommMultiplierDtls);
      oCommissionResult.set_nMultiplierOf(nMultiplierOf);
      
      //new fields added
      oCommissionResult.setnCommMultpWtFlag(nCommMultpWtFlag);
      oCommissionResult.setnCommMultiplierWt(strCommMultiplierWt);
      oCommissionResult.setnCommMultpWtFlagComp(nCommMultpWtFlagComp);
      oCommissionResult.setnIfWtCommMultiplier(strIfWtCommMultiplier);
      oCommissionResult.setnRedWtCommMultiplierBy(strRedWtCommMultiplierBy);
      oCommissionResult.setnIfWtCommMultiplierLt(strIfWtCommMultiplierLt);
      oCommissionResult.setnThenApplyWtOf(strThenApplyWtOf);
      
      
	  //Varun: Added for Release 15.1 - FSD_FIN802_New Comm Calculation Logic v1.1 End

      oContractResult.setCommissionResult(oCommissionResult);
      

      log.debug("ContractCreate--before create commission");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
      
         //this is added inorder to show that the current data from this page has to be displayed in the screen.
      oContractResult.setInstanceType(DataConstants.ACTION_UPDATE);
      log.debug("ContractAdd--before applying button pallette");
      ContractButtonPallete oContractButtonPalleteTemp = ContractButtonPallete.getInstance();
      oContractResult = oContractButtonPalleteTemp.applyButtons(oContractResult);
     //adding finished
     //Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
      if(nCommType.intValue() == DataConstants.STANDARD_COMMISSION || nCommType.intValue() == DataConstants.TRAIL_COMMISSION || nCommType.intValue() == DataConstants.INDEX_COMMISSION || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION)
	  { // for standard commission, or Trail
	  	log.debug("ContractUpdate--validating standard commission");
	  	CommissionValidator cmv = new CommissionValidator();
	  	cmv.validateCommission(oCommissionResult.getCommissionDetail(), oCommissionResult.getCommBase());
	  	log.debug("ContractUpdate--after validating standard commission");
  	  }
  	  
      long seqNo = remoteCHMSL.createCommissionContract(oContractResult);
      
      ContractButtonPallete oContractButtonPallete = ContractButtonPallete.getInstance();
      oContractResult = oContractButtonPallete.applyButtons(oContractResult);
      
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      log.debug("ContractCreate--after create commission seq nbr " + seqNo);
      oContractResult = remoteCHMSL.searchContract(seqNo);
      oContractResult = oContractButtonPallete.applyButtons(oContractResult);
      setResult(oContractResult);
      log.debug("ContractCreate--result accessed");

    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);      
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(fex, "P3024");
    }
    catch(EElixirException eex)
    {
      log.debug("ContractCreate--Inside catch of Eelixir exception in process of ContractCreate");
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw eex;
    }
  }

  /**
   * This method fetches all the details of Standard Commission.
   * @return CommissionDetails[] Array of CommissionDetails
   * @param a_oRequest HttpServletRequest object.
   */
  private CommissionDetails[] standardCommissionParameterFetch(HttpServletRequest a_oRequest,int type){
    CommissionDetails[] arrCommissionDetails;
    String[] nTermFrom        = a_oRequest.getParameterValues("nTermFrom"); //short
    String[] nTermTo          = a_oRequest.getParameterValues("nTermTo"); //short
    String[] nEntryAgeFrom    = a_oRequest.getParameterValues("nEntryAgeFrom"); //short
    String[] nEntryAgeTo      = a_oRequest.getParameterValues("nEntryAgeTo"); //short
    String[] nMatAgeFrom      = a_oRequest.getParameterValues("nMatAgeFrom"); //short
    String[] nMatAgeTo        = a_oRequest.getParameterValues("nMatAgeTo"); //short
    String[] nNbrOfLivesFrom  = a_oRequest.getParameterValues("nNbrOfLivesFrom");  //short
    String[] nNbrOfLivesTo    = a_oRequest.getParameterValues("nNbrOfLivesTo"); //short
    String[] dSAFrom          = a_oRequest.getParameterValues("dSAFrom"); //double
    String[] dSATo            = a_oRequest.getParameterValues("dSATo"); // double
    String[] dBaseValeFrom    = a_oRequest.getParameterValues("dBaseValueFrom"); //double
    String[] dBaseValeTo      = a_oRequest.getParameterValues("dBaseValueTo"); // double
    String[] nPolYearFrom     = a_oRequest.getParameterValues("nPolYearFrom"); //short
    String[] nPolYearTo       = a_oRequest.getParameterValues("nPolYearTo"); //short
    String[] dCommRate        = a_oRequest.getParameterValues("dCommRate"); //double
    String[] strStatusFlag    = a_oRequest.getParameterValues("statusFlagS"); //String
    String[] strRepLinkCd     = a_oRequest.getParameterValues("strRepLinkCd");
    String[] nCommPmtMode     = a_oRequest.getParameterValues("nCommPmtMode"); //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
  //Changed by Aradhana FIN1107 23_Oct_2017: START
    String[] nPptFrom        = a_oRequest.getParameterValues("nPptFrom"); //short
    String[] nPptTo          = a_oRequest.getParameterValues("nPptTo"); //short
  //Changed by Aradhana FIN1107 23_Oct_2017: END
    HttpSession  session = a_oRequest.getSession();
    String  strUserId = (String)session.getAttribute("username");
    log.debug("strUserId:" + strUserId);
	int nCB = (new Short(a_oRequest.getParameter("nCommBase"))).shortValue();

    int count = 0;
    log.debug(nTermFrom.length + "");
    for(int i = 0; i<nTermFrom.length ; i++){
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        count++;
      }
      log.debug(nTermFrom[i] + " 1 " + nTermTo[i] + " 2 " + nEntryAgeFrom[i] + " 3 " + nEntryAgeTo[i] + " 4 " + dSAFrom[i] + " 5 " + dSATo[i]);
      log.debug(dBaseValeFrom[i] + " 6 " + dBaseValeTo[i] + " 7 " + nPolYearFrom[i] + " 8 " + nPolYearTo[i] + " 9 " + dCommRate[i] + " 10 " + nMatAgeFrom[i] + " 11 " + nMatAgeTo[i]);
      log.debug( nPptFrom[i] + " 12 " + nPptTo[i]); //Added by Aradhana FIN1107 23_Oct_2017
      log.debug(strStatusFlag[i] + "STATUS FLAG");
    }

    arrCommissionDetails = new CommissionDetails[count];
    count = 0;
    for(int i = 0; i<nTermFrom.length ; i++){
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        arrCommissionDetails[count] = new CommissionDetails();
        arrCommissionDetails[count].setTermFrom(new Short(nTermFrom[i]));
        arrCommissionDetails[count].setTermTo(new Short(nTermTo[i])); 
        arrCommissionDetails[count].setEntryAgeFrom(new Short(nEntryAgeFrom[i]));
        arrCommissionDetails[count].setEntryAgeTo(new Short(nEntryAgeTo[i]));
        arrCommissionDetails[count].setMatAgeFrom(new Short(nMatAgeFrom[i]));
        arrCommissionDetails[count].setMatAgeTo(new Short(nMatAgeTo[i]));
        arrCommissionDetails[count].setNbrOfLivesFrom(new Short(nNbrOfLivesFrom[i]));
        arrCommissionDetails[count].setNbrOfLivesTo(new Short(nNbrOfLivesTo[i]));
		//Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
        if(type!= DataConstants.TRAIL_COMMISSION && type!= DataConstants.INDEX_COMMISSION)
        {
			if(nCB == DataConstants.PREMIUM_AND_SA){
				arrCommissionDetails[count].setSAFrom(new Double(dSAFrom[i]));
				arrCommissionDetails[count].setSATo(new Double(dSATo[i]));
			}
        }
        arrCommissionDetails[count].setBaseValeFrom(new Double(dBaseValeFrom[i]));
        arrCommissionDetails[count].setBaseValeTo(new Double(dBaseValeTo[i]));
        arrCommissionDetails[count].setPolYearFrom(new Short(nPolYearFrom[i]));
        arrCommissionDetails[count].setPolYearTo(new Short(nPolYearTo[i]));
         if(type != DataConstants.OVERRIDING_COMMISSION)
         {
        	//Changed by Aradhana FIN1107 23_Oct_2017: START
             arrCommissionDetails[count].setPptFrom(new Short(nPptFrom[i]));
             arrCommissionDetails[count].setPptTo(new Short(nPptTo[i]));
             //Changed by Aradhana FIN1107 23_Oct_2017: END
            arrCommissionDetails[count].setCommRate(new Double(dCommRate[i]));
         }
         else
         {
        	arrCommissionDetails[count].setRepLinkCd(strRepLinkCd[i]);
         }
        arrCommissionDetails[count].setUserId(strUserId);
        arrCommissionDetails[count].setStatusFlag(strStatusFlag[i]);
         //we need this status flag because the validation is done on the basis of status flag
        
        //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts 
        log.debug("Setting nCommPmtMode as " + nCommPmtMode[i]);
        if (nCommPmtMode[i] != null&& !nCommPmtMode[i].trim().equals(""))
        {
        arrCommissionDetails[count].setCommPmtMode(new Short(nCommPmtMode[i]));
        }
        // Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Ends
        count++;
      }
    }
    return arrCommissionDetails;
  }


  /**
   * This method fetches all the details of ClawBack Commission.
   * @return ClawBackDetails[] Array of ClawBackDetails
   * @param a_oRequest HttpServletRequest object.
   */
  private ClawBackDetails[] clawBackParameterFetch(HttpServletRequest a_oRequest){
    ClawBackDetails[] arrClawBackDetails;
    String[] strPmtMode = a_oRequest.getParameterValues("strPmtMode"); //short
    String[] nRngType =a_oRequest.getParameterValues("nRngType"); //short
    String[] nRngFrom = a_oRequest.getParameterValues("nRngFrom"); //short
    String[] nRngTo = a_oRequest.getParameterValues("nRngTo"); //short
    String[] dClawbackRate  = a_oRequest.getParameterValues("dClawbackRate");  //short
    String[] lAgrmtClawSeqNbr = a_oRequest.getParameterValues("PKValue"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlagC"); //double
    HttpSession  session = a_oRequest.getSession();
    String  strUserId = (String)session.getAttribute("username");

    log.debug(strPmtMode.length + "");
    int count = 0;
    for(int i = 0; i<strPmtMode.length ; i++){
      log.debug(strStatusFlag[i]);
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        count++;
      }
      log.debug(strPmtMode[i] + " 1 " + nRngType[i] + " 2 " + nRngFrom[i] + " 3 " + nRngTo[i] + " 4 " + dClawbackRate[i] + " 5 " + lAgrmtClawSeqNbr[i] + " 6 " + strStatusFlag[i]);
    }
    arrClawBackDetails = new ClawBackDetails[count];
    count = 0;
    for(int i = 0; i<strPmtMode.length ; i++){
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        arrClawBackDetails[count] = new ClawBackDetails();
        arrClawBackDetails[count].setPmtMode(strPmtMode[i]);
        arrClawBackDetails[count].setRngType(new Short(nRngType[i]));
        arrClawBackDetails[count].setRngFrom(new Short(nRngFrom[i]));
        arrClawBackDetails[count].setRngTo(new Short(nRngTo[i]));
        arrClawBackDetails[count].setClawbackRate(new Double(dClawbackRate[i]));
        arrClawBackDetails[count].setUserId(strUserId);
        count++;
        //arrClawBackDetails[i].setStatusFlag(strStatusFlag[i]);
      }
    }
    return arrClawBackDetails;
  }
}