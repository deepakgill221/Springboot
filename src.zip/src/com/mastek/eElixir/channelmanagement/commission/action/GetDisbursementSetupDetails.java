/********************************************************************
 *
 *  PROJECT				: MAMM
 *  MODULE NAME			: CHANNEL MANAGEMENT
 *  FILENAME			: GetDisbursementSetupDetails.java
 *  AUTHOR				: Vibhu Nigam
 *  VERSION				: 1.0
 *  CREATION DATE		: April 07, 2015
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT			: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class GetDisbursementSetupDetails extends Action {

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	public GetDisbursementSetupDetails() {

	}

	@Override
	public void process(HttpServletRequest aORequest) throws EElixirException {
		log.debug("GetDisbursementSetupDetails--Starts");
		ArrayList arrDisbursementSetupResult = null;
		try {
			MenuAccessLog.createMenuAccessLog(aORequest);
			CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome",
					CHMSLHome.class);
			arrDisbursementSetupResult = remoteCHMSL.getDisbursementSetup();
			aORequest.setAttribute("actiontype",
					DataConstants.ACTION_LISTSEARCH);
			setResult(arrDisbursementSetupResult);
			log.debug("GetDisbursementSetupDetails--Ends");
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (CreateException e) {
			e.printStackTrace();
		}
	}

}
