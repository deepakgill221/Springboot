/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: FINDER FEES
*  FILENAME			: FinderFeesMapAdd.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE    : Nov 30, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesMapResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

/**
 * Inserts finder rate mapping details in chm_finderfees_map
 * Copyright (c) 2002 Mastek Ltd 
 * @version 1.0
 */



public class FinderFeesMapCreate extends Action
{

   /**
	* @roseuid 3B94961803B7
	*/

   public FinderFeesMapCreate()
   {

   }

   /**
	* @return Object
	* @roseuid 3B94961803C1
	*/

   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean .
   * @param : ResultObject object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */


   public void process(HttpServletRequest request)  throws EElixirException
   {
	 log.debug("In CREATE CLASS******************");
	 
	 request.setAttribute("actiontype",DataConstants.ACTION_CREATE);
	 
	 HttpSession  session = request.getSession();
	 String  strUserId = (String)session.getAttribute("username"); 
	 
	 // retrieving the values from the screen.
	 String cChannelType = request.getParameter("cChannelType");	 
	 String strAgentCd = request.getParameter("strAgentCd");
   	 //String strContractType = request.getParameter("nContractType");
	 String[] strlFFHdrSeqNbr = request.getParameterValues("hdlffhdrseqnbr"); // shameem
	 String[] strlsProdSpecific= request.getParameterValues("hdlsProdSpecific"); // shameem	
	 String[] strContractName = request.getParameterValues("strFinderRule");
	 String[] dtEffDateFrom = request.getParameterValues("dtMappingEffFrom");
	 String[] dtEffDateTo = request.getParameterValues("dtMappingEffTo");
	 
	 ArrayList al_FinderFeesMapResult = new ArrayList();
	 try
	 {
	   if (strContractName != null && strContractName.length != 0)
	   {
		 for (int i =0; i<strContractName.length;i++)
		 {
			_oFinderFeesMapResult = new FinderFeesMapResult();
			
			_oFinderFeesMapResult.setChannelType(cChannelType);
			log.debug("FinderFeesMapCreate --> process -> cChannelType :"+cChannelType);		 
			_oFinderFeesMapResult.setAgentCd(strAgentCd.trim());
			log.debug("FinderFeesMapCreate --> process -> strAgentCd	:"+strAgentCd);
			
			_oFinderFeesMapResult.setFFHdrSeqNbr(new Long(strlFFHdrSeqNbr[i])); // shameem
			log.debug("FinderFeesMapCreate --> process -> strlFFHdrSeqNbr[i]	:"+strlFFHdrSeqNbr[i]);
			_oFinderFeesMapResult.setIsProdSpecific(new Short(strlsProdSpecific[i])); // shameem
			log.debug("FinderFeesMapCreate --> process -> strlsProdSpecific[i]	:"+strlsProdSpecific[i]);
						
			_oFinderFeesMapResult.setContractName(strContractName[i]);
			log.debug("FinderFeesMapCreate --> process -> strContractName[i]	:"+strContractName[i]);
			_oFinderFeesMapResult.setEffFrom(DateUtil.retGCDate(dtEffDateFrom[i]));
			log.debug("FinderFeesMapCreate --> process -> dtEffDateFrom[i]	:"+dtEffDateFrom[i]);			
			_oFinderFeesMapResult.setEffTo(DateUtil.retGCDate(dtEffDateTo[i]));
			log.debug("FinderFeesMapCreate --> process -> dtEffDateTo[i]	:"+dtEffDateTo[i]);
			_oFinderFeesMapResult.setUserId(strUserId);
			
			al_FinderFeesMapResult.add(_oFinderFeesMapResult);
		 }
	   }

	   CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);


	   setResult(_oFinderFeesMapResult);
	   log.debug("After EJBHomeFactory");
	   long _lUniqueMapSeqNbr= remoteCHMSL.createFinderFeesMap(al_FinderFeesMapResult);
	   
	   log.debug("CHMSLHOME created");
	   al_FinderFeesMapResult = remoteCHMSL.searchFinderFeesMap(_lUniqueMapSeqNbr);
	   
	   log.debug("result accessed");
	   setResult(al_FinderFeesMapResult);
	   
	   log.debug("result is set");
	   request.setAttribute("actiontype",DataConstants.ACTION_UPDATE);

	 }
	  catch(RemoteException rex)
	  {
		request.setAttribute("ResultObject", _oFinderFeesMapResult);
		throw new EElixirException(rex, "P1006");
	  }
	  catch(CreateException cex)
	  {
		request.setAttribute("ResultObject", _oFinderFeesMapResult);
		throw new EElixirException(cex, "P1007");
	  }
	  catch(FinderException cex)
	  {
		request.setAttribute("ResultObject", _oFinderFeesMapResult);
		throw new EElixirException(cex, "P1007");
	  }

	  log.debug("From CHMSLEJB");
	  //setResult(result);
   }

   //class level variable declarations.

   FinderFeesMapResult _oFinderFeesMapResult = null;
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}






