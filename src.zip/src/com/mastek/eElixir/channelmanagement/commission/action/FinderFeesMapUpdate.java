/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: FINDER FEES
*  FILENAME			: FinderFeesMapUpdate.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE    : Nov 30, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesMapResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;


/**
 * Updates contract mapping details in chm_contract_map
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author    Vinaysheel Baber
 * @version 1.0
 */


public class FinderFeesMapUpdate extends Action
{

   /**
	* @roseuid 3B94961803B7
	*/

   public FinderFeesMapUpdate()
   {

   }

   /**
	* @return Object
	* @roseuid 3B94961803C1
	*/

   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean .
   * @param : HttpServletRequest request.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */


   public void process(HttpServletRequest request)  throws EElixirException
   {
	 request.setAttribute("actiontype",DataConstants.ACTION_UPDATE);
	 HttpSession  session = request.getSession();
	 String  strUserId = (String)session.getAttribute("username");	 
	 log.debug("In UPDATE CLASS******************");
	 
	 //	retrieving the values from the screen.
	 String cChannelType = request.getParameter("cChannelType");	 
	 String strAgentCd = request.getParameter("strAgentCd");
	 String strStatusFlag = request.getParameter("statusFlag");
	 String strStatus = request.getParameter("nStatus");
	 long lFFMapSeqNbrPKey = Long.parseLong(request.getParameter("PKValue"));
	
	 String[] strPKey = request.getParameterValues("seqNbr"); // shameem
	 String[] strlffhdrseqnbr= request.getParameterValues("hdlffhdrseqnbr"); // shameem
	 String[] strlsProdSpecific= request.getParameterValues("hdlsProdSpecific"); // shameem	
	 String[] strContractName = request.getParameterValues("strFinderRule");
	 String[] dtEffDateFrom = request.getParameterValues("dtMappingEffFrom");
	 String[] dtEffDateTo = request.getParameterValues("dtMappingEffTo");
	 String[] dtUpdated = request.getParameterValues("ftr_dtUpdated");	    

	 ArrayList al_FinderFeesMapResult = new ArrayList();
	 	
	 
	 
	 
	 
	 
	 CHMSL remoteCHMSL = null;
	 
	 log.debug("FinderFeesMapUpdate - before try" + strContractName + "got pk value " + lFFMapSeqNbrPKey);
	 try
	 {
		   if (strContractName != null)
		   {
			 log.debug("FinderFeesMapUpdate - before for");
			 for(int i =0; i< strContractName.length;i++)
			 {
				   _oFinderFeesMapResult = new FinderFeesMapResult();
				   
				   _oFinderFeesMapResult.setChannelType(cChannelType);
				   log.debug("FinderFeesMapUpdate --> process -> cChannelType :"+cChannelType);		 
				   _oFinderFeesMapResult.setAgentCd(strAgentCd.trim());
				   log.debug("FinderFeesMapUpdate --> process -> strAgentCd	:"+strAgentCd);
				
					// storing the pk value for finder fees defn table seq. number for joining purpose.
				log.debug("FinderFeesMapUpdate --> process -> strlffhdrseqnbr[i]	:"+strlffhdrseqnbr[i]+"--");
				
					if(strlffhdrseqnbr[i]!=null && !strlffhdrseqnbr[i].equals(""))
					{
						_oFinderFeesMapResult.setFFHdrSeqNbr(new Long(strlffhdrseqnbr[i])); // shameem
					}else
					{
						_oFinderFeesMapResult.setFFHdrSeqNbr(new Long("0")); // shameem
					}
					 
				log.debug("FinderFeesMapUpdate --> process -> strlsProdSpecific[i]	:"+strlsProdSpecific[i]);
				if(strlsProdSpecific[i]!=null && !strlsProdSpecific[i].equals(""))
					{
						_oFinderFeesMapResult.setIsProdSpecific(new Short(strlsProdSpecific[i])); // shameem
					}
					else
					{
						_oFinderFeesMapResult.setIsProdSpecific(new Short("0")); // shameem					   
					}			   
				   			
				   _oFinderFeesMapResult.setContractName(strContractName[i]);
				   log.debug("FinderFeesMapUpdate --> process -> strContractName[i]	:"+strContractName[i]);
				   _oFinderFeesMapResult.setEffFrom(DateUtil.retGCDate(dtEffDateFrom[i]));
				   log.debug("FinderFeesMapUpdate --> process -> dtEffDateFrom[i]	:"+dtEffDateFrom[i]);			
				   _oFinderFeesMapResult.setEffTo(DateUtil.retGCDate(dtEffDateTo[i]));
				   log.debug("FinderFeesMapUpdate --> process -> dtEffDateTo[i]	:"+dtEffDateTo[i]);
				   		   
				   // storing the pk value of finder fees map records.		   
				   _oFinderFeesMapResult.setFFMapSeqNbr(new Long(strPKey[i]));
				   log.debug("FinderFeesMapUpdate --> process -> strPKey[i]	:"+strPKey[i]);		   
				   _oFinderFeesMapResult.setStatus(new Short(strStatus));
				   log.debug("FinderFeesMapUpdate --> process -> strStatus	:"+strStatus);
				   
				   
				   _oFinderFeesMapResult.setUserId(strUserId);
				   
				   if (dtUpdated[i] != null && !dtUpdated[i].trim().equals(""))
				   {
					 _oFinderFeesMapResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated[i]));
					 log.debug("FinderFeesMapUpdate --> process -> dtUpdated[i]	:"+dtUpdated[i]);
				   }
				   
				   al_FinderFeesMapResult.add(_oFinderFeesMapResult);
	 		}
		 }
		 
		 remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
		// if(strStatusFlag.equalsIgnoreCase(DataConstants.UPDATE_MODE))
		 //{
		   _oFinderFeesMapResult.setStatusFlag(DataConstants.UPDATE_MODE);
		   log.debug("After EJBHomeFactory");
		   remoteCHMSL.updateFinderFeesMap(al_FinderFeesMapResult);
		 //}
		 
		 log.debug("CHMSLHOME created");
		 al_FinderFeesMapResult = remoteCHMSL.searchFinderFeesMap(lFFMapSeqNbrPKey);
		 log.debug("result accessed");
		 setResult(al_FinderFeesMapResult);
		 log.debug("result is set");
		 request.setAttribute("actiontype",DataConstants.ACTION_UPDATE);
	   }
	   catch(RemoteException rex)
	   {
		 request.setAttribute("ResultObject", al_FinderFeesMapResult);
		 throw new EElixirException(rex, "P1006");
	   }
	   catch(CreateException cex)
	   {
		 request.setAttribute("ResultObject", al_FinderFeesMapResult);
		 throw new EElixirException(cex, "P1007");
	   }
	   catch(FinderException cex)
	   {
		request.setAttribute("ResultObject", al_FinderFeesMapResult);
		throw new EElixirException(cex, "P1007");
	   }
	   catch(EElixirException eex)
	   {
		 if (eex.getCustomErrorCode().equalsIgnoreCase("P1100"))
		 {
		   try
		   {
		   al_FinderFeesMapResult = remoteCHMSL.searchFinderFeesMap(lFFMapSeqNbrPKey);
		   }
		   catch(RemoteException rex)
		   {
			 request.setAttribute("ResultObject", al_FinderFeesMapResult);
			 throw new EElixirException(rex, "P1006");
		   }
		   catch(FinderException cex)
		   {
			 request.setAttribute("ResultObject", al_FinderFeesMapResult);
			 throw new EElixirException(cex, "P1007");
		   }
		 }
		 request.setAttribute("ResultObject", al_FinderFeesMapResult);
		 throw eex;
	   }
	   
	 }

	 //class level variable declarations.
	 FinderFeesMapResult _oFinderFeesMapResult = null;
	 private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
   }




