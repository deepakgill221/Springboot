/********************************************************************
*
*  PROJECT					: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME					: ClawbackUpdate
*  AUTHOR					: VINAYSHEEL BABER
*  VERSION					: 1.0
*  CREATION DATE		: October 13, 2002
*  COMPANY				: Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 1.1		11/3/2003	VinayC			Making clwback indicator non mandatory
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.ClawbackResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class ClawbackUpdate extends Action
{

   /**
    * @roseuid 3B94961803B7
    */

   public ClawbackUpdate()
   {

   }

   /**
    * @return Object
    * @roseuid 3B94961803C1
    */

   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean .
   * @param : SelfContract object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */

   public void process(HttpServletRequest request)  throws EElixirException
   {
     request.setAttribute("actiontype",DataConstants.ACTION_UPDATE);
     SearchData _oSearchData = new SearchData();
     CHMSL remoteCHMSL = null;
     try
     {
       setClawback(request);
       log.debug("after adding to collection");
       log.debug("After EJBHomeFactory");
       remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
       log.debug("CHMSLHOME created");
       remoteCHMSL.updateClawback(_oClawbackList);
       log.debug("result accessed");
       String strPolNbr = request.getParameter("strPolNbrHdr");
       String strServAgentCd = request.getParameter("strServAgentCd");
       log.debug("Primary key" +  strPolNbr + "::" + strServAgentCd);
       if(strPolNbr != null && !(strPolNbr.trim().equals("")))
       {
         _oSearchData.setTask1(strPolNbr.trim());
       }
       _oSearchData.setTask2(strServAgentCd.trim());
       _oClawbackList = remoteCHMSL.searchClawback(_oSearchData);

       //make a search here

       log.debug("before setting result");
       setResult(_oClawbackList);
       log.debug("result is set");
     }
     catch(FinderException fex)
     {
       request.setAttribute("ResultObject", _oClawbackList);
       throw new EElixirException(fex, "P1007");
     }
     catch(RemoteException rex)
     {
       request.setAttribute("ResultObject", _oClawbackList);
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       request.setAttribute("ResultObject", _oClawbackList);

       throw new EElixirException(cex, "P1007");
     }
     catch(EElixirException eex)
     {
       if (eex.getCustomErrorCode().equalsIgnoreCase("P1100"))
       {
         try
         {
           String strPolNbr = request.getParameter("strPolNbrHdr");
           String strServAgentCd = request.getParameter("strServAgentCd");
           log.debug("Primary key" +  strPolNbr + "::" + strServAgentCd);
           if(strPolNbr != null && !(strPolNbr.trim().equals("")))
           {
             _oSearchData.setTask1(strPolNbr.trim());
           }
           _oSearchData.setTask2(strServAgentCd.trim());
           _oClawbackList = remoteCHMSL.searchClawback(_oSearchData);
         }
         catch(RemoteException rex)
         {
            request.setAttribute("ResultObject", _oClawbackList);
           throw new EElixirException(rex, "P1006");
         }
         catch(FinderException cex)
         {
            request.setAttribute("ResultObject", _oClawbackList);
           throw new EElixirException(cex, "P1007");
         }
       }
        request.setAttribute("ResultObject", _oClawbackList);
       throw eex;
 }




 log.debug("\n\n\n\n\n...From CHMSLEJB ..\n\n\n\n\n");
 //setResult(result);
   }

   private void setClawback(HttpServletRequest a_oRequest)
   {

     HttpSession  session = a_oRequest.getSession();
     String  strUserId = (String)session.getAttribute("username");
     String strServAgentCd = a_oRequest.getParameter("strServAgentCd");
     String nClawbackIndcr[] = a_oRequest.getParameterValues("nClawbackIndcr");
     String strPolNbr[] = a_oRequest.getParameterValues("strPolNbr");
     String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
     String[] dtUpdated =  a_oRequest.getParameterValues("dtUpdated");
     if(statusFlag != null)
     {
       for(int i = 0; i < statusFlag.length; i++)
       {
//         if(!(statusFlag[i].equals(DataConstants.CLEAR_MODE)) && !(statusFlag[i].equals(DataConstants.DISPLAY_MODE)))
//         {
         _oClawbackResult = new ClawbackResult();
         if(dtUpdated[i] != null && !dtUpdated[i].trim().equals(""))
         {
           _oClawbackResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated[i]));
         }

         _oClawbackResult.setPolNbr(strPolNbr[i].trim());
         _oClawbackResult.setServAgentCd(strServAgentCd.trim());
		 //VinayC. Making indicator non mandatory
		 if (nClawbackIndcr[i] != null && !nClawbackIndcr[i].trim().equals(""))		 {
         _oClawbackResult.setClawbackIndcr(new Short(nClawbackIndcr[i]));
		 }

         _oClawbackResult.setStatusFlag(statusFlag[i]);
         _oClawbackResult.setUserId(strUserId);
         log.debug(strServAgentCd + "::" + strPolNbr[i] + "::"  + nClawbackIndcr[i] + "::" + statusFlag[i] + "::" + strUserId);

         _oClawbackList.add(_oClawbackResult);
//       }
       }
     }
   }

   //class level variable declarations.

   ClawbackResult _oClawbackResult = null;
   ArrayList _oClawbackList = new ArrayList() ;
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


}















