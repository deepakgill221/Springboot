/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME				: CHANNEL MANAGEMENT
*  FILENAME					: OverrideChannelListSearch.java
*  AUTHOR					: Anup Kumar
*  VERSION					: 1.0
*  CREATION DATE			: Sep 07, 2009
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2002.
*  CODE TAG 				: Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.OverrideCommRuleResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;




/**
 * <p>Title: eElixir</p>
 * <p>Description: Action Class for retrieving the Override Commission Rule List </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Anup Kumar
 * @version 1.0
 */

public class OverrideChannelLevelCommRulesUpdate extends Action
{

  /**
   * @Constructor
   */
  public OverrideChannelLevelCommRulesUpdate(){
  }

  /**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :HttpServletRequest request
	 *            ResultObject object.
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		CHMSL remoteCHMSL = null;
	     try {

			setCommRuleList(request);
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			remoteCHMSL.updateOverrideCommRule(_oOverrideCommList);			
			_oOverrideCommList = remoteCHMSL.searchOverrideCommRuleList(request
					.getParameter("cChannelType"));
			setResult(_oOverrideCommList);
		} catch (FinderException fex) {
			request.setAttribute("ResultObject", _oOverrideCommList);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oOverrideCommList);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oOverrideCommList);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log
					.debug("In updateOverrideCommRule elixir exception before setting result"
							+ eLex);
			if (eLex.getCustomErrorCode().equalsIgnoreCase("P1100")) {
				try {
					_oOverrideCommList = remoteCHMSL
							.searchOverrideCommRuleList(request
									.getParameter("cChannelType"));
					setResult(_oOverrideCommList);
				} catch (RemoteException rex) {
					request.setAttribute("ResultObject", _oOverrideCommList);
					throw new EElixirException(rex, "P1006");
				} catch (FinderException cex) {
					request.setAttribute("ResultObject", _oOverrideCommList);
					throw new EElixirException(cex, "P1007");
				}
			}
			request.setAttribute("ResultObject", _oOverrideCommList);
			throw eLex;
		}

	}

	private void setCommRuleList(HttpServletRequest a_oRequest) {	
		
		String strChannelType = a_oRequest.getParameter("cChannelType");		
		String strAgencyCode[] = a_oRequest.getParameterValues("strAgencyCode");		
		String strProdCode[] = a_oRequest.getParameterValues("strProductCode");
		String[] dtEffFrom = a_oRequest.getParameterValues("strdtEffFrom");
		String[] dtEffTo = a_oRequest.getParameterValues("strdtEffTo");
		String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
		String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");
		String SeqNumb[] = a_oRequest.getParameterValues("SeqNumb");		
		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String) session.getAttribute("username");
		if (statusFlag != null) {
			for (int i = 0; i < statusFlag.length; i++) {
				if (!(statusFlag[i].equals(DataConstants.CLEAR_MODE))) {

					_oOverrideCommRuleResult = new OverrideCommRuleResult();

					_oOverrideCommRuleResult.setChannelType(strChannelType);					
									
					_oOverrideCommRuleResult.setAgencyCode(strAgencyCode[i]);
					_oOverrideCommRuleResult.setAgencyName(null);
					_oOverrideCommRuleResult.setProdCode(strProdCode[i]);
					_oOverrideCommRuleResult.setEffFrom(DateUtil.retGCDate(dtEffFrom[i]));
					log.debug("dtEffTo[i]"+dtEffTo[i]);
					_oOverrideCommRuleResult.setEffTo(DateUtil.retGCDate(dtEffTo[i]));
					_oOverrideCommRuleResult.setStatusFlag(statusFlag[i]);


					if (SeqNumb[i] != null && !SeqNumb[i].trim().equals("")) {
						_oOverrideCommRuleResult.setCommRuleOverSeqNbr(new Long(SeqNumb[i]));

					} else {
						_oOverrideCommRuleResult.setCommRuleOverSeqNbr(null);
					}
					
					if (dtUpdated[i] != null && !dtUpdated[i].trim().equals("")) {
						log.debug("dtUpdated : "+dtUpdated[i]);
						_oOverrideCommRuleResult.setTsDtUpdated(Timestamp
								.valueOf(dtUpdated[i]));
					}
					_oOverrideCommRuleResult.setUserId(_strUserId);					
					_oOverrideCommList.add(_oOverrideCommRuleResult);

				}
			}
		}
		
	}

	// class level variable declarations.
	OverrideCommRuleResult _oOverrideCommRuleResult = null;

	ArrayList _oOverrideCommList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
