/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME				: Finder Fees Mapping
 *  FILENAME				: NewFinderFeesMapListSearch.java
 *  AUTHOR					: Shameem Shaik
 *  VERSION					: 1.0
 *  CREATION DATE			: Oct 29 2004
 *  COMPANY					: Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *-------------------------------------------------------------------------------- 
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * NewFinderFeesMapListSearch is the Action Class for Getting jsp page for first time ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       06/12/2002
 * @author    Sandeep Bangera
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;

public class NewFinderFeesMapListSearch extends Action
{
  public NewFinderFeesMapListSearch()
  {

  }


  /**
   * This is a dummy method, used only when page is loaded first time
   * @param : request - Request object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
	try
	{
	  MenuAccessLog.createMenuAccessLog(a_oRequest);
	  a_oRequest.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
	}
	catch(RemoteException rex)
	{
	  throw new EElixirException(rex, "P1006");
	}
	catch(CreateException cex)
	{
	  throw new EElixirException(cex, "P1007");
	}
	catch(EElixirException eex)
	{
	  throw eex;
	}
  }


}