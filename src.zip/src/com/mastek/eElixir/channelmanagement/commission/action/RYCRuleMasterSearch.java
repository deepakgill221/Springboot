/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterSearch.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: October 29, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * Action Class for Getting a list of RYCRuleMasterSearch Map,depending upon the
 * search data.
 * Copyright (c) 2005 Mastek Ltd
 * Date       29/10/2005
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class RYCRuleMasterSearch extends Action
{

   /**
	* @roseuid 3B94961803B7
	*/

   public RYCRuleMasterSearch()
   {

   }

   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean
   * @param : request - Request object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */


   public void process(HttpServletRequest request)  throws EElixirException
   {
	   RYCRuleMasterSearchResult oRYCRuleMasterSearchResult=null;

	 try
	 {
		
		log.debug("hai i am in RYCRuleMasterSearch");	
	
		CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
		
		log.debug("haa");

	  log.debug("CHMSLHOME created");
	
	  long _iLFFMapSeqNbr = Long.parseLong(request.getParameter("strPKey"));

	 log.debug("_iLFFMapSeqNbr :"+_iLFFMapSeqNbr);
	  
	 oRYCRuleMasterSearchResult = remoteCHMSL.searchRYCRuleMaster(_iLFFMapSeqNbr);
	  	  
	   log.debug("oRYCRuleMasterListSearch :"+oRYCRuleMasterSearchResult.getRYCRule());

  	  request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);

	  setResult(oRYCRuleMasterSearchResult);

	  log.debug("result is set");
	  
	}
	catch(RemoteException rex)
	{
	  throw new EElixirException(rex, "P1006");
	}
	catch(CreateException cex)
	{
	  throw new EElixirException(cex, "P1007");
	}
	catch(FinderException fex)
	{
	  throw new EElixirException(fex, "P9002");
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}

   }
   /**
	* Member Variables
	*/

   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}

