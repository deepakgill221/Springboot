/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME			: ApplicationIrdaRecordSearch.java
*  AUTHOR			: AMID P SAHU
*  VERSION			: 1.0
*  CREATION DATE	: October 7, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;


import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.recruitment.util.IrdaRecordResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class NewDeleteCommDispatch extends Action
{

  /**
   * @Constructor
   */
  public NewDeleteCommDispatch(){
  }

  /**
   * blank process method to follow the MVC architecture
   * @param  a_oRequest HttpServletRequest
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)
      throws EElixirException
  {
      try
      {
    	  _oLogger.debug("<<inside process methods>>");
          MenuAccessLog.createMenuAccessLog(a_oRequest);
		  a_oRequest.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);
	  }
      catch (RemoteException rex)
      {
          throw new EElixirException(rex, "P1006");
      }
      catch (CreateException cex)
      {
          throw new EElixirException(cex, "P1007");
      }
  }
  //Log log = new Log(ApplicationEducationSearch.class.getName(),Constants.CHM_MODULE);
  private Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

}