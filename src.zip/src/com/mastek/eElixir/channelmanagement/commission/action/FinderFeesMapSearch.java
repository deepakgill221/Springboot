/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME				: Finder Fees Mapping
 *  FILENAME				: FinderFeesMapSearch.java
 *  AUTHOR					: Shameem Shaik
 *  VERSION					: 1.0
 *  CREATION DATE			: Oct 29 2004
 *  COMPANY					: Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *-------------------------------------------------------------------------------- 
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesMapResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


/**
 * <p>Title: eElixir</p>
 * <p>Description: Action Class for retrieving the FinderFeesMap </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Vinaysheel Baber
 * @version 1.0
 */

public class FinderFeesMapSearch extends Action
{

  /**
   * @Constructor
   */
  public FinderFeesMapSearch(){
  }

  /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean and get the ApplicationResult Object
   * @param: request - Request object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest request)  throws EElixirException
  {
	log.debug("inside FinderFeesMapSearch process");
	
	request.setAttribute("actiontype",  DataConstants.ACTION_LISTSEARCH);
	FinderFeesMapResult _oFinderFeesMapResult = null;
	ArrayList al_searchFinderFeesMap = null;
	try
	{

	  CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

	  log.debug("CHMSLHOME created");
	  long _iLFFMapSeqNbr = Long.parseLong(request.getParameter("strPKey"));

	  log.debug("_iLFFMapSeqNbr :"+_iLFFMapSeqNbr);
	  al_searchFinderFeesMap = remoteCHMSL.searchFinderFeesMap(_iLFFMapSeqNbr);
	  	  
	  log.debug("al_searchFinderFeesMap :"+al_searchFinderFeesMap);

	  setResult(al_searchFinderFeesMap);
	  log.debug("result is set");
	  
	  request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
	}
	catch(RemoteException rex)
	{

	  throw new EElixirException(rex, "P1006");
	}
	catch(FinderException rex)
	{

	  throw new EElixirException(rex, "P1006");
	}
	catch(CreateException cex)
	{

	  throw new EElixirException(cex, "P1007");
	}



  }
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}




