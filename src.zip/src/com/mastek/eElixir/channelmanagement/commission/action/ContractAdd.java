/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractAdd.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.util.ContractButtonPallete;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
/**
 * ContractAdd is the Entry class for Creating Contract and Commission
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */
public class ContractAdd extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the ContractAdd class
   */
  public ContractAdd()
  {

  }


  /**
   * This is a dummy method, used only when entry page is loaded first time
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {

    ContractResult oContractResult = null;
    int iContractStatus = DataConstants.STATUS_PENDING_ID; // for Pending
    oContractResult = new ContractResult();
    oContractResult.setContractStatus(new Integer(iContractStatus));
    oContractResult.setInstanceType(DataConstants.ACTION_CREATE);
    log.debug("ContractAdd--before applying button pallette");
    ContractButtonPallete oContractButtonPallete = ContractButtonPallete.getInstance();
    oContractResult = oContractButtonPallete.applyButtons(oContractResult);
    log.debug("ContractAdd--getting button pallette " + oContractResult.getButtonPallete());
    a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
    setResult(oContractResult);
  }
}

