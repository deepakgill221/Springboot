/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractUpdate.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*1.1             16Jan2003         Pallav            added payment Mode
*1.2             23Jan2003         Pallav            added Term Type, and Maturity Age
*1.3             7Feb2003         Pallav            changed statusFlag as statusFlagC and statusFlagS
* 1.4     13/Nov/2009		 Anup Kumar     Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Updates the detail for a Contract. It is responsible for all the other operation as well.
 * It Updates, deletes and Inserts a row in Commission depending upon the type of request send to it
 * Copyright (c) 2002 Mastek Ltd
 * Date       25/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.dvo.ClawBackDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionDetails;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionValidator;
import com.mastek.eElixir.channelmanagement.commission.util.ContractButtonPallete;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
public class ContractUpdate extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor of the ContractUpdate class
   */
  public ContractUpdate()
  {

  }

  /**
   * Depending upon the type of request it updates/Deletes/Inserts a row for commission.
   * It calls session bean for doing this operation. Main task is to fetch data from request object
   * call to all other bean and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ContractResult oContractResult = null;
    String strComAgreementKey = null;
    CHMSL remoteCHMSL = null;
    try{

      remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

      oContractResult = new ContractResult();
      CommissionResult oCommissionResult = new CommissionResult();

      String strContractNumber = a_oRequest.getParameter("strContractNbr");
      oContractResult.setContractNumber(strContractNumber);
      oContractResult.setEffectiveDate(DateUtil.retGCDate(a_oRequest.getParameter("dtEffFrom").trim()));
      int iContractStatus  = DataConstants.STATUS_PENDING_ID; // for Pending
      if(a_oRequest.getParameter("nStatus") != null && (!a_oRequest.getParameter("nStatus").trim().equals(""))){
        iContractStatus = Integer.parseInt(a_oRequest.getParameter("nStatus"));
      }
      oContractResult.setContractStatus(new Integer(iContractStatus));
      log.debug(strContractNumber + " " + iContractStatus);

      strComAgreementKey = a_oRequest.getParameter("hdnComAgreementKey");
      String strCommBase = a_oRequest.getParameter("nCommBase");
      String strCommType = a_oRequest.getParameter("nCommType");
      // added code for nPmtMode
      String strPmtMode = a_oRequest.getParameter("nPmtMode");
      // added code for nTermType
      String strTermType = a_oRequest.getParameter("nTermType");
      String strCommClass = a_oRequest.getParameter("strCommClass");
      String strProdCdVer = a_oRequest.getParameter("strProdCdVer");
      String dtUpdated = a_oRequest.getParameter("dtUpdated");
      String strIndexCommYrType = a_oRequest.getParameter("nIndexCommYrType");//Anup_Indexation_Changes_Jan_Release_v1.2
      if (dtUpdated != null && !dtUpdated.trim().equals(""))
      {
        oContractResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated));
      }
      Short nCommType = null;
      Short nCommBase = null;
      Short nPmtMode = null;
      Short nTermType = null;
      Short nIndexCommYrType = null;
      String strBaseProdCdVer = a_oRequest.getParameter("strBaseProdCdVer");
       // added by amit 11/1/2002 ## to check for commision also
	  HttpSession  session = a_oRequest.getSession();
	  String  strUserId = (String)session.getAttribute("username");
      oContractResult.setUserId(strUserId);


      if(strCommType != null){
        nCommType = new Short(strCommType);
      }
      if(strCommBase != null){
        nCommBase = new Short(strCommBase);
      }
      if(strPmtMode != null){
        nPmtMode = new Short(strPmtMode);
      }
      if(strTermType != null){
    	  
        nTermType = new Short(strTermType);
      }
      //Anup_Indexation_Changes_Jan_Release_v1.2_Starts
      log.debug("strIndexCommYrType"+strIndexCommYrType);
      if(strIndexCommYrType != null&& !strIndexCommYrType.trim().equals("")){
    	  nIndexCommYrType = new Short(strIndexCommYrType);
        }
      //Anup_Indexation_Changes_Jan_Release_v1.2_Ends
      log.debug(nCommBase + " " + nPmtMode + " " + nTermType + " " + nCommType + " " + strCommClass + " " + strProdCdVer);
      log.debug("nIndexCommYrType"+nIndexCommYrType);
      StringTokenizer st = new StringTokenizer(strProdCdVer,"|");
      String strProdCd = null;
      String strProdVer = null;
      String strPlanType = null;
      String strBasePlanType = null;
       String strBaseProd = null;
	  Integer iBaseProdVer = null;
      while(st.hasMoreTokens()){
        strProdCd = (String)st.nextElement();
        break;
      }
       while(st.hasMoreTokens()){
          strPlanType = (String)st.nextElement();
          break;
	  }

      while(st.hasMoreTokens()){
        strProdVer = (String)st.nextElement();
       }
      Integer iProdVer = null;
      if(strProdVer != null){
        iProdVer = new Integer(strProdVer);
      }

      st = null;
      st = new StringTokenizer(strBaseProdCdVer, "|");
      while(st.hasMoreTokens())
      {
	      strBaseProd = (String)st.nextElement();
	      break;
      }

      while(st.hasMoreTokens()){
          strBasePlanType = (String)st.nextElement();
          break;
	  }


      while(st.hasMoreTokens()){
          strProdVer = (String)st.nextElement();
	  }

      String strCampaignCd = a_oRequest.getParameter("strCampaignCd");
      String iBaseUnits = a_oRequest.getParameter("iBaseUnits");
      // strDistribType commented for new functionality
      //String strDistribType = a_oRequest.getParameter("strDistribType");

      //log.debug(strProdCd + " " + strProdVer + " " + strCampaignCd + " " + iBaseUnits + " " + strDistribType);

      oCommissionResult.setCommBase(nCommBase);
      oCommissionResult.setPmtMode(nPmtMode);
      oCommissionResult.setTermType(nTermType);
      oCommissionResult.setCommType(nCommType);
      oCommissionResult.setCommClass(strCommClass);
      oCommissionResult.setProdCd(strProdCd);
      oCommissionResult.setProdVer(iProdVer);
      oCommissionResult.setCampaignCd(strCampaignCd);
       oCommissionResult.setUserId(strUserId);
      oCommissionResult.setBaseUnits(new Integer(iBaseUnits.trim()));
      oCommissionResult.setIndexCommYrType(nIndexCommYrType);//Anup_Indexation_Changes_Jan_Release_v1.2
      if (strPlanType != null)
	  {
		  Short nPlanType = new Short(strPlanType);
		  oCommissionResult.setPlanType(nPlanType);
	  }

	  if (strBasePlanType != null)
	  {
		  Short nPlanType = new Short(strBasePlanType);
		  oCommissionResult.setBasePlanType(nPlanType);
	  }
	   if (strBaseProd != null)
      {
	  	oCommissionResult.setBaseProdCd(strBaseProd);
	  	log.debug("Added base product code as " + strBaseProd);
  	  }
  	  if (iBaseProdVer != null)
  	  {
	  	oCommissionResult.setBaseProdVer(iBaseProdVer);
	  	log.debug("Added base product version as " + iBaseProdVer);
  	  }

      //oCommissionResult.setDistribType(strDistribType);
      oCommissionResult.setComAgreementKey(new Long(strComAgreementKey.trim()));
      log.debug("ContractUpdate--after getting all values of contract");

      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		//Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
      if(nCommType.intValue() == DataConstants.STANDARD_COMMISSION || nCommType.intValue() == DataConstants.TRAIL_COMMISSION || nCommType.intValue() == DataConstants.INDEX_COMMISSION || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION){ // for standard commission, or Trail
        oCommissionResult.setCommissionDetail(standardCommissionParameterFetch(a_oRequest,nCommType.intValue())); //standard comm details set
      }
      else if(nCommType.intValue() == DataConstants.CLAWBACK_COMMISSION){ // for Clawback
        oCommissionResult.setClawBackDetail(clawBackParameterFetch(a_oRequest));
      }
      log.debug("ContractUpdate--after getting all values of Commission");
      oContractResult.setCommissionResult(oCommissionResult);
      log.debug("ContractUpdate--before create commission");
      ContractButtonPallete oContractButtonPallete = ContractButtonPallete.getInstance();
      oContractResult = oContractButtonPallete.applyButtons(oContractResult);
      log.debug("ContractUpdate--after button pallete");
	  //Ananth_FSIndexation_REL8.2 INDEX_COMMISSION Check
	  if(nCommType.intValue() == DataConstants.STANDARD_COMMISSION || nCommType.intValue() == DataConstants.TRAIL_COMMISSION ||  nCommType.intValue() == DataConstants.INDEX_COMMISSION  || nCommType.intValue() == DataConstants.OVERRIDING_COMMISSION)
	  { // for standard commission, or Trail
	  	log.debug("ContractUpdate--validating standard commission");
	  	CommissionValidator cmv = new CommissionValidator();
	  	cmv.validateCommission(oCommissionResult.getCommissionDetail(), oCommissionResult.getCommBase());
	  	log.debug("ContractUpdate--after validating standard commission");
  	  }
      remoteCHMSL.updateCommissionContract(oContractResult);
      oContractResult = remoteCHMSL.searchContract(Long.parseLong(strComAgreementKey.trim()));

      oContractResult = oContractButtonPallete.applyButtons(oContractResult);
      setResult(oContractResult);
      log.debug("ContractUpdate--result accessed");
    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw new EElixirException(fex, "P3024");
    }
    catch(EElixirException eex)
    {
      log.debug("ContractUpdate--Inside catch of Eelixir exception in process of ContractUpdate");
      //setResult(oContractResult);
      if (eex.getCustomErrorCode().equalsIgnoreCase("P1100"))
      {
        try
        {
          ContractButtonPallete oContractButtonPallete = ContractButtonPallete.getInstance();
          oContractResult = remoteCHMSL.searchContract(Long.parseLong(strComAgreementKey.trim()));
          oContractResult = oContractButtonPallete.applyButtons(oContractResult);

        }
        catch(RemoteException rex)
        {
          a_oRequest.setAttribute("ResultObject", oContractResult);
          throw new EElixirException(rex, "P1006");
        }
        catch(FinderException cex)
        {
          a_oRequest.setAttribute("ResultObject", oContractResult);
          throw new EElixirException(cex, "P1007");
        }
      }
      a_oRequest.setAttribute("ResultObject", oContractResult);
      throw eex;
    }
  }


  /**
   * This method fetches all the details of Standard Commission.
   * @return CommissionDetails[] Array of CommissionDetails
   * @param a_oRequest HttpServletRequest object.
   */
  private CommissionDetails[] standardCommissionParameterFetch(HttpServletRequest a_oRequest,int type){
    CommissionDetails[] arrCommissionDetails;
    String[] nTermFrom = a_oRequest.getParameterValues("nTermFrom"); //short
    String[] nTermTo =a_oRequest.getParameterValues("nTermTo"); //short
    String[] nEntryAgeFrom = a_oRequest.getParameterValues("nEntryAgeFrom"); //short
    String[] nEntryAgeTo = a_oRequest.getParameterValues("nEntryAgeTo"); //short
    String[] nMatAgeFrom      = a_oRequest.getParameterValues("nMatAgeFrom"); //short
    String[] nMatAgeTo        = a_oRequest.getParameterValues("nMatAgeTo"); //short
    String[] nNbrOfLivesFrom  = a_oRequest.getParameterValues("nNbrOfLivesFrom");  //short
    String[] nNbrOfLivesTo  = a_oRequest.getParameterValues("nNbrOfLivesTo"); //short
    String[] dSAFrom          = a_oRequest.getParameterValues("dSAFrom"); //double
    String[] dSATo            = a_oRequest.getParameterValues("dSATo"); // double
    String[] dBaseValeFrom  = a_oRequest.getParameterValues("dBaseValueFrom"); //double
    String[] dBaseValeTo = a_oRequest.getParameterValues("dBaseValueTo"); // double
    String[] nPolYearFrom = a_oRequest.getParameterValues("nPolYearFrom"); //short
    String[] nPolYearTo = a_oRequest.getParameterValues("nPolYearTo"); //short
    String[] dCommRate = a_oRequest.getParameterValues("dCommRate"); //double
    String[] lAgrmtSCSeqNbr = a_oRequest.getParameterValues("PKValue"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlagS"); //double
    String[] std_comm_dtUpdated = a_oRequest.getParameterValues("std_comm_dtUpdated"); //timestamp
    String[] strRepLinkCd    = a_oRequest.getParameterValues("strRepLinkCd"); //String
  //Added by Aradhana FIN1107 23_Oct_2017: START
    String[] nPptFrom = a_oRequest.getParameterValues("nPptFrom"); //short
    String[] nPptTo =a_oRequest.getParameterValues("nPptTo"); //short
  //Added by Aradhana FIN1107 23_Oct_2017: END
    HttpSession  session = a_oRequest.getSession();
    String  strUserId = (String)session.getAttribute("username");
    String[] nCommPmtMode = a_oRequest.getParameterValues("nCommPmtMode"); //Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts
	int nCB = (new Short(a_oRequest.getParameter("nCommBase"))).shortValue();
	 

    log.debug(nTermFrom.length + "");
    int count = 0;
    for(int i = 0; i<nTermFrom.length ; i++){
      log.debug(strStatusFlag[i]);
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        count++;
      }
    }
    arrCommissionDetails = new CommissionDetails[count];
    log.debug("ContractUpdate-- count " + count);
    count = 0;
    for(int i = 0; i<nTermFrom.length ; i++){
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        arrCommissionDetails[count] = new CommissionDetails();
        arrCommissionDetails[count].setTermFrom(new Short(nTermFrom[i]));
        arrCommissionDetails[count].setTermTo(new Short(nTermTo[i]));
        arrCommissionDetails[count].setEntryAgeFrom(new Short(nEntryAgeFrom[i]));
        arrCommissionDetails[count].setEntryAgeTo(new Short(nEntryAgeTo[i]));
        arrCommissionDetails[count].setMatAgeFrom(new Short(nMatAgeFrom[i]));
        arrCommissionDetails[count].setMatAgeTo(new Short(nMatAgeTo[i]));
        arrCommissionDetails[count].setNbrOfLivesFrom(new Short(nNbrOfLivesFrom[i]));
        arrCommissionDetails[count].setNbrOfLivesTo(new Short(nNbrOfLivesTo[i]));
		if(nCB == DataConstants.PREMIUM_AND_SA){
			arrCommissionDetails[count].setSAFrom(new Double(dSAFrom[i]));
			arrCommissionDetails[count].setSATo(new Double(dSATo[i]));
		}
        arrCommissionDetails[count].setBaseValeFrom(new Double(dBaseValeFrom[i]));
        arrCommissionDetails[count].setBaseValeTo(new Double(dBaseValeTo[i]));
        arrCommissionDetails[count].setPolYearFrom(new Short(nPolYearFrom[i]));
        arrCommissionDetails[count].setPolYearTo(new Short(nPolYearTo[i]));
//        arrCommissionDetails[count].setCommRate(new Double(dCommRate[i]));
         if(type != DataConstants.OVERRIDING_COMMISSION){
        	//Added by Aradhana FIN1107 23_Oct_2017: START
             arrCommissionDetails[count].setPptFrom(new Short(nPptFrom[i]));
             arrCommissionDetails[count].setPptTo(new Short(nPptTo[i]));
           //Added by Aradhana FIN1107 23_Oct_2017: END  
        	 arrCommissionDetails[count].setCommRate(new Double(dCommRate[i]));
          }
          else{  
            arrCommissionDetails[count].setRepLinkCd(strRepLinkCd[i]);
            //arrCommissionDetails[count].setIsORCRatePresent(new Short(nIsORCRatePresent[i]));
          }
        arrCommissionDetails[count].setUserId(strUserId);
        if (std_comm_dtUpdated[i] != null && !std_comm_dtUpdated[i].trim().equals(""))
        {
          log.debug("Setting timestamp as " + std_comm_dtUpdated[i]);
          arrCommissionDetails[count].setTsDtUpdated(Timestamp.valueOf(std_comm_dtUpdated[i]));
        }
        if(! strStatusFlag[i].trim().equals(DataConstants.INSERT_MODE)){
          arrCommissionDetails[count].setAgrmtSCSeqNbr(new Long(lAgrmtSCSeqNbr[i].trim()));
        }
        arrCommissionDetails[count].setStatusFlag(strStatusFlag[i]);
        log.debug("setting status flag as " + strStatusFlag[i] + "%%%%%");
        // Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Starts 
        log.debug("Setting nCommPmtMode as " + nCommPmtMode[i]);
        if (nCommPmtMode[i] != null&& !nCommPmtMode[i].trim().equals(""))
        {
        arrCommissionDetails[count].setCommPmtMode(new Short(nCommPmtMode[i]));
        }
        // Anup_Unit_Builder_PACE_Req1_JAN_REL_2010_Ends
        count++;
        log.debug(nTermFrom[i] + " " + nTermTo[i] + " " + nEntryAgeFrom[i] + " " + nEntryAgeTo[i] + " " + dSAFrom[i] + " " + dSATo[i]);
        log.debug(dBaseValeFrom[i] + " " + dBaseValeTo[i] + " " + nPolYearFrom[i] + " " + nPolYearTo[i] + " " + dCommRate[i] + " " + nMatAgeFrom[i] + " " + nMatAgeTo[i]);
        log.debug(nPptFrom[i] + " " + nPptTo[i]); //Added by Aradhana FIN1107 23_Oct_2017
      }
    }
    return arrCommissionDetails;
  }

  /**
   * This method fetches all the details of ClawBack Commission.
   * @return ClawBackDetails[] Array of ClawBackDetails
   * @param a_oRequest HttpServletRequest object.
   */
  private ClawBackDetails[] clawBackParameterFetch(HttpServletRequest a_oRequest){
    ClawBackDetails[] arrClawBackDetails;
    String[] strPmtMode = a_oRequest.getParameterValues("strPmtMode"); //short
    String[] nRngType =a_oRequest.getParameterValues("nRngType"); //short
    String[] nRngFrom = a_oRequest.getParameterValues("nRngFrom"); //short
    String[] nRngTo = a_oRequest.getParameterValues("nRngTo"); //short
    String[] dClawbackRate  = a_oRequest.getParameterValues("dClawbackRate");  //short
    String[] lAgrmtClawSeqNbr = a_oRequest.getParameterValues("PKValue"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlagC"); //double
    String clawBack_dtUpdated[] = a_oRequest.getParameterValues("clawBack_dtUpdated"); //timestamp
    HttpSession  session = a_oRequest.getSession();
    String  strUserId = (String)session.getAttribute("username");

    log.debug(strPmtMode.length + "");
    int count = 0;
    for(int i = 0; i<strPmtMode.length ; i++){
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        count++;
      }
    }
    arrClawBackDetails = new ClawBackDetails[count];
    count=0;
    for(int i = 0; i<strPmtMode.length ; i++){
      if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
        arrClawBackDetails[count] = new ClawBackDetails();
        arrClawBackDetails[count].setPmtMode(strPmtMode[i]);
        arrClawBackDetails[count].setRngType(new Short(nRngType[i]));
        arrClawBackDetails[count].setRngFrom(new Short(nRngFrom[i]));
        arrClawBackDetails[count].setRngTo(new Short(nRngTo[i]));
        arrClawBackDetails[count].setClawbackRate(new Double(dClawbackRate[i]));
        if(! strStatusFlag[i].trim().equals(DataConstants.INSERT_MODE)){
          log.debug("ContractUpdate--Inside Clawback fetch " + lAgrmtClawSeqNbr[i]);
          arrClawBackDetails[count].setlAgrmtClawSeqNbr(new Long(lAgrmtClawSeqNbr[i].trim()));
        }
        arrClawBackDetails[count].setStatusFlag(strStatusFlag[i]);
        arrClawBackDetails[count].setUserId(strUserId);
        if (clawBack_dtUpdated[i] != null && !clawBack_dtUpdated[i].trim().equals(""))
        {
          arrClawBackDetails[count].setTsDtUpdated(Timestamp.valueOf(clawBack_dtUpdated[i]));
        }
        count++;
      }
    }
    return arrClawBackDetails;
  }

  /**
   * This method removes the Commission which Has StatusFlag set to D from the set of CommissionDetail
   * @return CommissionDetails[] Array of CommissionDetails
   * @param a_arrCommissionDetails CommissionDetails[] Array of CommissionDetails
   */
  private CommissionDetails[] removeDeleteFlagStandardCommission(CommissionDetails[] a_arrCommissionDetails){
    CommissionDetails[] arrCommissionDetails;
    int count = 0;
    for(int i = 0; i<a_arrCommissionDetails.length ; i++){
      log.debug(a_arrCommissionDetails[i].getStatusFlag());
      if(!a_arrCommissionDetails[i].getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
        count++;
      }
    }
    arrCommissionDetails = new CommissionDetails[count];
    count = 0;
    for(int i = 0; i<a_arrCommissionDetails.length ; i++){
      log.debug(a_arrCommissionDetails[i].getStatusFlag());
      if(!a_arrCommissionDetails[i].getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
        arrCommissionDetails[count] = a_arrCommissionDetails[i];
        count++;
      }
    }
    return arrCommissionDetails;
  }

  /**
   * This method removes the Commission which Has StatusFlag set to D from the set of ClawBackDetails
   * @return ClawBackDetails[] Array of ClawBackDetails
   * @param a_arrClawBackDetails ClawBackDetails[] Array of ClawBackDetails
   */
  private ClawBackDetails[] removeDeleteFlagClawBackCommission(ClawBackDetails[] a_arrClawBackDetails){
    ClawBackDetails[] arrClawBackDetails;
    int count = 0;
    for(int i = 0; i<a_arrClawBackDetails.length ; i++){
      log.debug(a_arrClawBackDetails[i].getStatusFlag());
      if(!a_arrClawBackDetails[i].getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
        count++;
      }
    }
    arrClawBackDetails = new ClawBackDetails[count];
    count = 0;
    for(int i = 0; i<a_arrClawBackDetails.length ; i++){
      log.debug(a_arrClawBackDetails[i].getStatusFlag());
      if(!a_arrClawBackDetails[i].getStatusFlag().trim().equals(DataConstants.DELETE_MODE)){
        arrClawBackDetails[count] = a_arrClawBackDetails[i];
        count++;
      }
    }
    return arrClawBackDetails;
  }
}