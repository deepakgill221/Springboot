/********************************************************************
*
*  PROJECT			: Amal
*  MODULE NAME		        : Customer Development
*  FILENAME			: OverridingCommRateUpdate
*  AUTHOR			: Pallav
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 6, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * OverridingCommRateUpdate is the Action Class for updating a OverridingCommRate.
 * Copyright (c) 2002 Mastek Ltd
 * Date       Mar 6, 2003
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.util.OverridingCommRateFetch;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;



public class OverridingCommRateUpdate extends Action
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the OverridingCommRateUpdate class
   */
  public OverridingCommRateUpdate()
  {

  }

  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ArrayList arrOverridingCommRateResult = null;
    OverridingCommRateFetch oOverridingCommRateFetch = new OverridingCommRateFetch();
    CHMSL remoteCHMSL = null;


    long lPriKey = 0;
    try{
      remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      log.debug("OverridingCommRateUpdate--Before fetching parameters");
      lPriKey = new Long((a_oRequest.getParameter("strPKey")).trim()).longValue();
      log.debug("OverridingCommRateUpdate--lPriKey:" + lPriKey);
      arrOverridingCommRateResult = oOverridingCommRateFetch.fetchOverridingCommRate(a_oRequest);
      log.debug("OverridingCommRateUpdate--After fetching parameters");

      log.debug("OverridingCommRateUpdate--before update OverridingCommRate");
      //arrOverridingCommRateResult.setUserId(_oUserObject.getUserId());
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      remoteCHMSL.updateOverridingCommRate(arrOverridingCommRateResult);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      //EElixirUtils.reloadMaster(DataConstants.CHANNEL_TYPE);
      log.debug("OverridingCommRateUpdate--before search OverridingCommRate");
      arrOverridingCommRateResult = remoteCHMSL.searchOverridingCommRate(lPriKey);
      log.debug("OverridingCommRateUpdate--after search OverridingCommRate");
      setResult(arrOverridingCommRateResult);
      log.debug("OverridingCommRateUpdate--result accessed");

    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", arrOverridingCommRateResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", arrOverridingCommRateResult);
      throw new EElixirException(fex, "P3052");
    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", arrOverridingCommRateResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(EElixirException eex)
    {
      log.debug("OverridingCommRateUpdate--Inside catch of EElixir exception in process of OverridingCommRateUpdate");
      a_oRequest.setAttribute("ResultObject", arrOverridingCommRateResult);

        //if update fails search for data in the database
        try
        {
          arrOverridingCommRateResult = remoteCHMSL.searchOverridingCommRate(lPriKey);
          log.debug("before setting result +EElixirBussinessException ");
          a_oRequest.setAttribute("ResultObject", arrOverridingCommRateResult);
          log.debug("result is set + EElixirBussinessException");
        }
        catch(FinderException fex)
        {
          a_oRequest.setAttribute("ResultObject", arrOverridingCommRateResult);
          throw new EElixirException(fex, "P1006");
        }
        catch(RemoteException rex)
        {
            throw eex;
        }
        throw eex;
    }
  }

}