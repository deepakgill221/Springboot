/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterUpdate.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: November 02, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * Action Class for Inserting a list of RYCRuleMasterUpdate 
 * Copyright (c) 2005 Mastek Ltd
 * Date       02/11/2005
 * @version 1.0
 */

// PACKAGE DEFNETION
package com.mastek.eElixir.channelmanagement.commission.action;


import java.rmi.RemoteException;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import java.util.ArrayList;


import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleAgencyDetails;//Narendra CTS for RYC rule master details as part of to AGN-09
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleDesgDetails;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRulePolicyDetails;




/**
 * This Action Class is to Create New RYCRuleMasterCreate Entry
 */

public class RYCRuleMasterUpdate extends Action
{

  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the RYCRuleMasterUpdate class
   */
  public RYCRuleMasterUpdate()
  {

  }


  /**
   * This method makes a remote call to the CHM Session bean which in turn makes a local
   * call to all other bean and updates the Application
   * @param: a_oRequest - HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {

    RYCRuleMasterSearchResult oRYCRuleMasterSearchResult = null;

    try
    {
		log.debug("RYCRuleMasterUpdate : Process");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);

      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      
	  //Populating RYCRuleMasterSearchResult object from Request Object
      oRYCRuleMasterSearchResult = getRYCRuleMasterResult(a_oRequest);


	   Long lRYCHdrSeqNbr = new Long(a_oRequest.getParameter("lFFHdrSeqNbr").trim());

	   log.debug("lRYCHdrSeqNbr----->"+lRYCHdrSeqNbr);

		log.debug("RYCRuleMasterUpdate----->process--->above calling update");
      //Firing Create RYCRulemaster Method
       remoteCHMSL.updateRYCRuleMaster(oRYCRuleMasterSearchResult);


		log.debug("RYCRuleMasterUpdate----->process--->above calling search");
      //Retrieving Newly Created Record from Database
      oRYCRuleMasterSearchResult = remoteCHMSL.searchRYCRuleMaster(lRYCHdrSeqNbr.longValue());

	  log.debug("RYCRuleMasterUpdate final values--->"+oRYCRuleMasterSearchResult);

      //Setting the Result Object
      setResult(oRYCRuleMasterSearchResult);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);


    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw new EElixirException(cex, "P1007");
    }

    catch(EElixirException eex)
    {
      log.debug("RYCRuleMasterUpdate--Inside catch of EElixir exception ");
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw eex;
    }
	catch(Exception ee)
    {
		log.debug("Finder Exception");
		ee.printStackTrace();

    }
  }

  /**
   * A method to Populate RYCRuleMasterSearchResult object from the Request Object
   * @param a_oRequest HttpServletRequest
   * @return oRYCRuleMasterSearchResult
   * @throws EElixirException
   */
  private RYCRuleMasterSearchResult getRYCRuleMasterResult(HttpServletRequest a_oRequest) throws EElixirException
  {

    RYCRuleMasterSearchResult oRYCRuleMasterSearchResult = new RYCRuleMasterSearchResult();

	
	 HttpSession  session = a_oRequest.getSession();
    String  strUserId = (String)session.getAttribute("username");
	

	Long lFFHdrSeqNbr1= null;
	
	String lFFHdrSeqNbr=a_oRequest.getParameter("lFFHdrSeqNbr").trim();
	
	
	if(lFFHdrSeqNbr !=null && !lFFHdrSeqNbr.equals(""))
   {
   		lFFHdrSeqNbr1=new Long(Long.parseLong(lFFHdrSeqNbr));
	}

    String strRYCRule = a_oRequest.getParameter("strRYCRule").trim();
    String nChannelType = a_oRequest.getParameter("nChannelType").trim();

    String dtEffFrom = a_oRequest.getParameter("dtEffFrom").trim();
    GregorianCalendar dtEffFrom1 = null;
    if( dtEffFrom != null && !dtEffFrom.equals(""))
    {
      dtEffFrom1 = DateUtil.retGCDate(dtEffFrom.trim());
    }

	String dtEffTo = a_oRequest.getParameter("dtEffTo").trim();
    GregorianCalendar dtEffTo1 = null;
    if( dtEffTo != null && !dtEffTo.equals(""))
    {
      dtEffTo1 = DateUtil.retGCDate(dtEffTo.trim());
    }
//Changed By Narendra to convert from Long to double to take Sum Assured
    Double strSumAssumed1 = null;
    String strSumAssumed = a_oRequest.getParameter("strSumAssumed").trim();
    if(strSumAssumed != null && !strSumAssumed.equals(""))
    {
      strSumAssumed1 = new Double(Double.parseDouble(strSumAssumed));
    }

	Short strPeriodOfSA1 = null;
    String strPeriodOfSA = a_oRequest.getParameter("strPeriodOfSA").trim();
    if(strPeriodOfSA != null && !strPeriodOfSA.equals(""))
    {
      strPeriodOfSA1 = new Short(Short.parseShort(strPeriodOfSA));
    }

	Short strStartYear1 = null;
    String strStartYear = a_oRequest.getParameter("strStartYear").trim();
    if(strStartYear != null && !strStartYear.equals(""))
    {
      strStartYear1 = new Short(Short.parseShort(strStartYear));
    }

	Short strEndYear1 = null;
    String strEndYear = a_oRequest.getParameter("strEndYear").trim();
    if(strEndYear != null && !strEndYear.equals(""))
    {
      strEndYear1 = new Short(Short.parseShort(strEndYear));
    }

	Short radioInExclude = null;
    String strRadioInExclude = a_oRequest.getParameter("radioInEx").trim();
	if(strRadioInExclude != null && !strRadioInExclude.equals(""))
    {
      radioInExclude = new Short(Short.parseShort(strRadioInExclude));
	}
	
	Short nStatus = null;
	String sv=null;
	sv=a_oRequest.getParameter("nStatus").trim();
	if(sv!= null && !sv.equals(""))
	{
		StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nStatus"),"|");
		nStatus = new Short(st.nextToken());					
	}

	if(nStatus==null && 
		a_oRequest.getParameter("actiontype").equalsIgnoreCase(DataConstants.ACTION_CREATE))
			
	{	
		nStatus=new Short(String.valueOf(DataConstants.STATUS_PENDING_ID));
	}	
	
	oRYCRuleMasterSearchResult.setFFHDRSeqNbr(lFFHdrSeqNbr1);
    oRYCRuleMasterSearchResult.setRYCRule(strRYCRule);
    oRYCRuleMasterSearchResult.setChannelType(nChannelType);
    oRYCRuleMasterSearchResult.setStatus(nStatus);
    oRYCRuleMasterSearchResult.setEffFrom(dtEffFrom1);
    oRYCRuleMasterSearchResult.setEffto(dtEffTo1);
    oRYCRuleMasterSearchResult.setSumAssumed(strSumAssumed1);
    oRYCRuleMasterSearchResult.setPeriod(strPeriodOfSA1);
    oRYCRuleMasterSearchResult.setStartYear(strStartYear1);
    oRYCRuleMasterSearchResult.setEndYear(strEndYear1);
	oRYCRuleMasterSearchResult.setUserId(strUserId);
	oRYCRuleMasterSearchResult.setInExValue(radioInExclude);
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
	String strRYCRuleLevel = a_oRequest.getParameter("nRuleLevel");
	log.debug("calling setRYCRule--->"+strRYCRuleLevel);
	oRYCRuleMasterSearchResult.setRuleLevel(strRYCRuleLevel);
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
	if(a_oRequest.getParameter("dRycRate") != null && !a_oRequest.getParameter("dRycRate").equals(""))
		{
	log.debug("i am inside the if condition");		
			oRYCRuleMasterSearchResult.setRycRate(Double.parseDouble(a_oRequest.getParameter("dRycRate")));
		}
	
//Narendra CTS for RYC rule master details as part of to AGN-09 starts
	if(new Short(strRYCRuleLevel).shortValue() != DataConstants.RYC_AGENCY)
	{
		setRYCRuleDesgnDetails(oRYCRuleMasterSearchResult,a_oRequest);
	}else
	{
	setRYCRuleAgencyDetails(oRYCRuleMasterSearchResult,a_oRequest);
	}
//Narendra CTS for RYC rule master details as part of to AGN-09 ends
	setRYCRulePolicyDetails(oRYCRuleMasterSearchResult,a_oRequest);

  
      return oRYCRuleMasterSearchResult;	
  }

  public void setRYCRuleDesgnDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult,HttpServletRequest a_oRequest)
	{
		 ArrayList alRYCRuleDesgDetails = new ArrayList();
		 
 		String[] arrlRYCDesgnSeqNbr = a_oRequest.getParameterValues("lRYCDesgnSeqNbr");
		String[] arrRYCDesgnCode = a_oRequest.getParameterValues("cRYCDesgn");
		String[] arrStatusFlag = a_oRequest.getParameterValues("statusFlag");
		
		RYCRuleDesgDetails oRYCRuleDesgDetails =null;
		int iSize = 0;
		if(arrRYCDesgnCode != null && arrRYCDesgnCode.length > 0){
			iSize = arrRYCDesgnCode.length;
		}
		for (int i = 0; i < iSize; i++)
		{
			log.debug("3");
			oRYCRuleDesgDetails = new RYCRuleDesgDetails();
			if(arrRYCDesgnCode[i] != null && !arrRYCDesgnCode[i].equals(""))
			{
				oRYCRuleDesgDetails.setRYCDesgn(arrRYCDesgnCode[i]);
				log.debug("Desig:------>"+arrRYCDesgnCode[i]);
			}
			if(arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				oRYCRuleDesgDetails.setStatusFlag(arrStatusFlag[i]);
				log.debug("Desig:Status------>"+arrStatusFlag[i]);
			}
			if(arrlRYCDesgnSeqNbr[i] != null && !arrlRYCDesgnSeqNbr[i].equals(""))
			{
				oRYCRuleDesgDetails.setRYCDesgnSeqNbr(Long.valueOf(arrlRYCDesgnSeqNbr[i]));
				log.debug("Desig:seq------>"+arrlRYCDesgnSeqNbr[i]);
			}
			if(arrRYCDesgnCode[i] != null && !arrRYCDesgnCode[i].equals("") && arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				alRYCRuleDesgDetails.add(oRYCRuleDesgDetails);
				log.debug("Desig:Setting------>");
			}
			
		}
		oRYCRuleMasterSearchResult.setRYCRuleDesgDetails(alRYCRuleDesgDetails);
	}
//Narendra CTS for RYC rule master details as part of to AGN-09 starts

   public void setRYCRuleAgencyDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult,HttpServletRequest a_oRequest)
	{
		 ArrayList alRYCRuleAgencyDetails = new ArrayList();

 		String[] arrlRYCAgencySeqNbr = a_oRequest.getParameterValues("lRYCAgencySeqNbr");
		String[] arrRYCAgencyCode = a_oRequest.getParameterValues("cRYCAgency");
		String[] arrStatusFlag = a_oRequest.getParameterValues("statusFlag");

		RYCRuleAgencyDetails oRYCRuleAgencyDetails =null;
		int iSize = 0;
		if(arrRYCAgencyCode != null && arrRYCAgencyCode.length > 0){
			iSize = arrRYCAgencyCode.length;
		}
		for (int i = 0; i < iSize; i++)
		{
			log.debug("3");
			oRYCRuleAgencyDetails = new RYCRuleAgencyDetails();
			if(arrRYCAgencyCode[i] != null && !arrRYCAgencyCode[i].equals(""))
			{
				oRYCRuleAgencyDetails.setRYCAgency(new Short(arrRYCAgencyCode[i]));
				log.debug("Agency:------>"+arrRYCAgencyCode[i]);
			}
			if(arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				oRYCRuleAgencyDetails.setStatusFlag(arrStatusFlag[i]);
				log.debug("Agency:Status------>"+arrStatusFlag[i]);
			}
			if(arrlRYCAgencySeqNbr[i] != null && !arrlRYCAgencySeqNbr[i].equals(""))
			{
				oRYCRuleAgencyDetails.setRYCAgencySeqNbr(Long.valueOf(arrlRYCAgencySeqNbr[i]));
				log.debug("Agency:seq------>"+arrlRYCAgencySeqNbr[i]);
			}
			if(arrRYCAgencyCode[i] != null && !arrRYCAgencyCode[i].equals("") && arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				alRYCRuleAgencyDetails.add(oRYCRuleAgencyDetails);
				log.debug("Agency:Setting------>");
			}

		}
		oRYCRuleMasterSearchResult.setRYCRuleAgencyDetails(alRYCRuleAgencyDetails);
	}

// Narendra CTS for RYC rule master details as part of to AGN-09 ends
	public void setRYCRulePolicyDetails(RYCRuleMasterSearchResult oRYCRuleMasterSearchResult,HttpServletRequest a_oRequest)
	{
		log.debug("1");
		 ArrayList alRYCRulePolicyDetails = new ArrayList();
		 
 		String[] arrlRYCPolicySeqNbr = a_oRequest.getParameterValues("lRYCPolicySeqNbr");
		String[] arrRYCPolicyCode = a_oRequest.getParameterValues("cRYCPolicy");
		String[] arrStatusFlag = a_oRequest.getParameterValues("statusFlag1");
		
		
		RYCRulePolicyDetails oRYCRulePolicyDetails =null;
		int iSize = 0;
		if(arrRYCPolicyCode != null && arrRYCPolicyCode.length > 0){
			iSize = arrRYCPolicyCode.length;
		}
		for (int i = 0; i < iSize; i++)
		{
			log.debug("3");
			oRYCRulePolicyDetails = new RYCRulePolicyDetails();
			if(arrRYCPolicyCode[i] != null && !arrRYCPolicyCode[i].equals(" "))
			{
				oRYCRulePolicyDetails.setRYCPolicy(Long.valueOf(arrRYCPolicyCode[i]));
				log.debug("after setting arrBonusApplToPolicy with value:--->"+arrRYCPolicyCode[i]);
			}
			if(arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				oRYCRulePolicyDetails.setStatusFlag(arrStatusFlag[i]);
				log.debug("after setting arrStatusFlag with value:--->"+arrStatusFlag[i]);
			}


			if(arrlRYCPolicySeqNbr[i] != null && !arrlRYCPolicySeqNbr[i].equals("") )
			{
				oRYCRulePolicyDetails.setRYCPolicySeqNbr(Long.valueOf(arrlRYCPolicySeqNbr[i]));
				log.debug("after setting arrlRYCPolicySeqNbr with value:--->"+arrlRYCPolicySeqNbr[i]);
			}
			if(arrRYCPolicyCode[i] != null && !arrRYCPolicyCode[i].equals(" ")&& arrStatusFlag[i] != null && !arrStatusFlag[i].equals(""))
			{
				alRYCRulePolicyDetails.add(oRYCRulePolicyDetails);
				log.debug("In Policy Set");
			}
			
			log.debug("oRYCRulePolicyDetails----->"+oRYCRulePolicyDetails);
			log.debug("alRYCRulePolicyDetails-------->"+alRYCRulePolicyDetails);
		}
		oRYCRuleMasterSearchResult.setRYCRulePolicyDetails(alRYCRulePolicyDetails);
	}

  }
