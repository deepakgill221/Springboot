/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterUpdate.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: November 02, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * Action Class for Inserting a list of RYCRuleMasterUpdate 
 * Copyright (c) 2005 Mastek Ltd
 * Date       02/11/2005
 * @version 1.0
 */

// PACKAGE DEFNETION
package com.mastek.eElixir.channelmanagement.commission.action;


import java.rmi.RemoteException;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import java.util.ArrayList;


import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleDesgDetails;



/**
 * This Action Class is to Create New RYCRuleMasterCreate Entry
 */

public class RYCRuleMasterDelete extends Action
{

  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the RYCRuleMasterUpdate class
   */
  public RYCRuleMasterDelete()
  {

  }


  /**
   * This method makes a remote call to the CHM Session bean which in turn makes a local
   * call to all other bean and updates the Application
   * @param: a_oRequest - HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {

    RYCRuleMasterSearchResult oRYCRuleMasterSearchResult = null;

    try
    {
		log.debug("RYCRuleMasterUpdate : Process");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);

      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      
	  Long lRYCHdrSeqNbr = new Long(a_oRequest.getParameter("lFFHdrSeqNbr").trim());

	   log.debug("lRYCHdrSeqNbr----->"+lRYCHdrSeqNbr);

		log.debug("RYCRuleMasterDelete----->process--->above calling update");
      //Firing Create RYCRulemaster Method
       remoteCHMSL.deleteRYCRuleMaster(lRYCHdrSeqNbr);


      //Setting the Result Object
       a_oRequest.setAttribute("actiontype", DataConstants.ACTION_DELETE);


    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw new EElixirException(cex, "P1007");
    }

    catch(EElixirException eex)
    {
      log.debug("RYCRuleMasterUpdate--Inside catch of EElixir exception ");
      a_oRequest.setAttribute("ResultObject", oRYCRuleMasterSearchResult);
      throw eex;
    }
	catch(Exception ee)
    {
		log.debug("Finder Exception");
		ee.printStackTrace();

    }
  }
}

 