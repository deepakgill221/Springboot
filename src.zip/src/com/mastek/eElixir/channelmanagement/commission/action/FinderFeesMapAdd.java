/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME		: FINDER FEES
*  FILENAME			: FinderFeesMapAdd.java
*  AUTHOR			: Shameem Shaik
*  VERSION			: 1.0
*  CREATION DATE    : Nov 30, 2004
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

/**
 * Called at the beginnning of FinderFeesMapCreate
 * Copyright (c) 2002 Mastek Ltd 
 * @author    Shameem Shaik
 * @version 1.0
 */

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;

public class FinderFeesMapAdd extends Action
{

   /**
	* @roseuid 3B94961803B7
	*/
   public FinderFeesMapAdd()
   {

   }

   /**
   * blank process method to follow the MVC architecture, it just makes the xsl file available to the requested jsp at the beginning
   * @param : request - Request object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */
   public void process(HttpServletRequest request)  throws EElixirException
   {
	request.setAttribute("actiontype", DataConstants.ACTION_CREATE);
   }
}
