/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Finder Fees
*  FILENAME			: FFCommissionRatesCreate.java
*  AUTHOR			: Jimmy K George
*  VERSION			: 1.0
*  CREATION DATE	: December 18,2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * FinderFeesCreate is the Action Class for creating a new FinderFeesCommissionRate.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/12/2005
 * @author    Jimmy K G
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionRatesDetails;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class FFCommissionRatesCreate extends Action
{
 
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the FinderFeesCreate class
   */
  public FFCommissionRatesCreate()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
	log.debug("===========================  FFCommissionCreate Process Start =====================================");
	FinderFeesResult oFinderFeesResult = null;
	CommissionRatesDetails oCommRatesDetails=null;
	long seqNo;
	String strprdcd=null;
	try{
	  CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
	  log.debug("process -- > fetching getFFCommissionRates()");
	  oFinderFeesResult = getFFCommissionRates(a_oRequest);
	  log.debug("process -- > done getFFCommissionRates()");
	  a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
	  log.debug("process -- > invoking updateFFCommissionRates()");	  
	  remoteCHMSL.updateFFCommissionRates(oFinderFeesResult);
	  log.debug("process -- > done updateFFCommissionRates()");
	  a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
	  log.debug("process -- > invoking  searchFFCommissionRates()");
	  seqNo=Long.parseLong(a_oRequest.getParameter("lFFHdrSeqNbr"));
	  strprdcd=a_oRequest.getParameter("cProductCode");
	  oFinderFeesResult = remoteCHMSL.searchFFCommissionRates(seqNo,strprdcd);
	  log.debug("process -- > done searchFFCommissionRates()");
	  log.debug("process -- > oFinderFeesResult"+oFinderFeesResult);
	  setResult(oFinderFeesResult);
	  

	}
	catch(RemoteException rex)
	{		
	  a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
	  throw new EElixirException(rex, "P1006");
	}
	catch(CreateException cex)
	{	
	  a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
	  throw new EElixirException(cex, "P1007");
	}
	catch(EElixirException eex)
	{	
	  log.debug("FFCommissionCreate--Inside catch of EElixir exception in process of FFCommissionCreate");
	  a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
	  throw eex;
	} catch (FinderException e) {
		
		e.printStackTrace();
	}
  }
  
  private FinderFeesResult getFFCommissionRates(HttpServletRequest a_oRequest)
		throws EElixirException
	{
		log.debug("==================  FFCommissionCreate -->getFFCommissionRates ==============================");
		HttpSession session = a_oRequest.getSession();
		String strUserId = (String) session.getAttribute("username");
		
		FinderFeesResult oFinderFeesResult = new FinderFeesResult();				
		
	    Long lFFHDRSeqNbr = new Long(a_oRequest.getParameter("lFFHdrSeqNbr"));
	    String cProductCode = a_oRequest.getParameter("cProductCode");  
		String strUpdCommRatesFlag = a_oRequest.getParameter("UpdCommRatesFlag");
		String dTopUpRate = a_oRequest.getParameter("dTopUpRate");
			   
	    String[] arrFFDetailRSeqNbr  = a_oRequest.getParameterValues("lFFDetailRSeqNbr");
	    String[] arrPolYearFrom = a_oRequest.getParameterValues("nPolYearFrom");
	    String[] arrPolYearTo  = a_oRequest.getParameterValues("nPolYearTo");
	    String[] arrStatusFlag = a_oRequest.getParameterValues("statusFlag2");
	    String[] arrRate = a_oRequest.getParameterValues("dRate");
		String[] arrReductionCommRate = a_oRequest.getParameterValues("dReductionCommRate");
		
	    log.debug("arrPolYearFrom.length 	:"+arrPolYearFrom.length);		
	    ArrayList alCommRatesDetails = new ArrayList();
		CommissionRatesDetails oCommRatesDetails=null;		
		log.debug("before alCommRatesDetails.size()	:"+alCommRatesDetails.size());
		
		int iSize =   arrPolYearFrom.length;
		for (int i = 0; i < iSize; i++)
		{
			log.debug("arrPolYearFrom["+i+"]	:"+arrPolYearFrom[i]);
			log.debug("arrPolYearTo["+i+"]		:"+arrPolYearTo[i]);
			log.debug("arrStatusFlag["+i+"]		:"+arrStatusFlag[i]);
			log.debug("arrRate["+i+"]			:"+arrRate[i]);
			log.debug("arrReductionCommRate["+i+"]	:"+arrReductionCommRate[i]);
			log.debug("arrFFDetailRSeqNbr["+i+"]	:"+arrFFDetailRSeqNbr[i]);
			log.debug("dTopUpRate["+i+"]	:"+dTopUpRate);
					
			oCommRatesDetails=new CommissionRatesDetails();
			oCommRatesDetails.setFFHDRSeqNbr(lFFHDRSeqNbr);
			
			if ((cProductCode != null) &&  !cProductCode.trim().equals(""))
			{
				oCommRatesDetails.setProductCode(cProductCode);
			}
			if ((cProductCode != null) &&  cProductCode.trim().equals(""))
			{
				oCommRatesDetails.setProductCode("");
			}
			
			if ((arrFFDetailRSeqNbr[i] != null) &&  !arrFFDetailRSeqNbr[i].trim().equals("")
						&& !arrFFDetailRSeqNbr[i].startsWith("temp"))
			{
				oCommRatesDetails.setFFDetailRSeqNbr(new Long(arrFFDetailRSeqNbr[i]));
			}
			else
			{
				// If creating new record, this id will be replaced by new generated sequence number from the table.
				oCommRatesDetails.setFFDetailRSeqNbr(new Long(arrFFDetailRSeqNbr[i].substring(4)));
			}
			if ((arrPolYearFrom[i] != null) &&  !arrPolYearFrom[i].trim().equals(""))					
			{
				oCommRatesDetails.setPolYearFrom(new Short(arrPolYearFrom[i]));
			}
			if ((arrPolYearTo[i] != null) &&  !arrPolYearTo[i].trim().equals(""))
			{			
				oCommRatesDetails.setPolYearTo(new Short(arrPolYearTo[i]));
			}			
			if ((arrStatusFlag[i] != null) &&  !arrStatusFlag[i].trim().equals(""))
			{
				oCommRatesDetails.setStatusFlag(new String(arrStatusFlag[i]));
			}
			if ((arrRate[i] != null) &&  !arrRate[i].trim().equals(""))
			{
				oCommRatesDetails.setRate(new Double(arrRate[i]));
			}			
			if ((arrReductionCommRate[i] != null) &&  !arrReductionCommRate[i].trim().equals(""))
			{
				oCommRatesDetails.setReductionCommRate(new Double(arrReductionCommRate[i]));
			}
			if((dTopUpRate != null) && !dTopUpRate.trim().equals(""))
			{
				oCommRatesDetails.setTopUpRate(new Double(dTopUpRate));
			}
			else
			{
				oCommRatesDetails.setTopUpRate(new Double(0.0));
			}
			oCommRatesDetails.setUserId(strUserId);
			
			alCommRatesDetails.add(oCommRatesDetails);			
			
		}// for end here	
		
		
		log.debug("after alCommRatesDetails.size()	:"+alCommRatesDetails.size());
		
		oFinderFeesResult.setFFHDRSeqNbr(lFFHDRSeqNbr);
		oFinderFeesResult.setUpdCommRatesFlag(strUpdCommRatesFlag);
		oFinderFeesResult.setCommRatesDetails(alCommRatesDetails);		
		
		log.debug("oFinderFeesResult.getFFHDRSeqNbr()		:"+oFinderFeesResult.getFFHDRSeqNbr());
		log.debug("oFinderFeesResult.getUpdCommRatesFlag()	:"+oFinderFeesResult.getUpdCommRatesFlag());
		log.debug("arrFFDetailRSeqNbr[0]	:"+((Object[])((ArrayList)oFinderFeesResult.getCommRatesDetails()).toArray()).toString());
		
		log.debug("==================  FFCommissionCreate -->getFFCommissionRates End ==========================");
		return oFinderFeesResult;
		
	}

}
