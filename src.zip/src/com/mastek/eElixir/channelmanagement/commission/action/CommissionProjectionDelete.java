/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionProjectionDelete.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : Jan 20, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * CommissionProjectionDelete is the Action Class for creating a new CommissionProjection.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.util.CommissionProjectionFetch;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionProjectionResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class CommissionProjectionDelete extends Action
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the CommissionProjectionDelete class
   */
  public CommissionProjectionDelete()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    CommissionProjectionResult oCommissionProjectionResult = null;
    CommissionProjectionFetch oCommissionProjectionFetch = new CommissionProjectionFetch();
    try{
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      log.debug("CommissionProjectionDelete--Before fetching parameters");
      oCommissionProjectionResult = oCommissionProjectionFetch.fetchCommissionProjection(a_oRequest);
      log.debug("CommissionProjectionDelete--After fetching parameters");
      log.debug("CommissionProjectionDelete--before create CommissionProjection");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
     remoteCHMSL.deleteCommissionProjection(oCommissionProjectionResult);


      //setResult(oCommissionProjectionResult);
      log.debug("CommissionProjectionDelete--result accessed");

    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oCommissionProjectionResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oCommissionProjectionResult);
      throw new EElixirException(cex, "P1007");
    }
    catch (FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", oCommissionProjectionResult);
      throw new EElixirException(fex, "P3205");
    }
    catch(RemoveException rex)
    {
      a_oRequest.setAttribute("ResultObject", oCommissionProjectionResult);
      throw new EElixirException(rex, "P3207");
    }
    catch(EElixirException eex)
    {
      log.debug("CommissionProjectionDelete--Inside catch of EElixir exception in process of CommissionProjectionDelete");
      a_oRequest.setAttribute("ResultObject", oCommissionProjectionResult);
      throw eex;
    }
  }

}