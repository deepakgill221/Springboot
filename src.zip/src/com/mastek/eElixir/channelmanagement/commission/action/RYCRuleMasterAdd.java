/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : RYC Rules
*  FILENAME			: RYCRuleMasterAdd.java
*  AUTHOR			: Srikanth Kolluri
*  VERSION			: 1.0
*  CREATION DATE	: November 01, 2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2005.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
/**
 * Action Class for Getting a list of RYCRuleMasterAdd Map,depending upon the
 * search data.
 * Copyright (c) 2005 Mastek Ltd
 * Date       01/11/2005
 * @version 1.0
 */
package com.mastek.eElixir.channelmanagement.commission.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class RYCRuleMasterAdd extends Action
{

  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


  /**
   * Constructor of the UnitAdd class
   */
  public RYCRuleMasterAdd()
  {

  }


  /**
   * This is a dummy method, used only when entry page is loaded first time
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {	
	a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);	
  }
}