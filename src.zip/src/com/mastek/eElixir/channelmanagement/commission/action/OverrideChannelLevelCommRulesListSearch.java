/********************************************************************
*
*  PROJECT					: MNYL
*  MODULE NAME				: CHANNEL MANAGEMENT
*  FILENAME					: OverrideChannelListSearch.java
*  AUTHOR					: Anup Kumar
*  VERSION					: 1.0
*  CREATION DATE			: Sep 07, 2009
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT				: COPYRIGHT (C) 2002.
*  CODE TAG 				: Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;




/**
 * <p>Title: eElixir</p>
 * <p>Description: Action Class for retrieving the Override Commission Rule List </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Anup Kumar
 * @version 1.0
 */

public class OverrideChannelLevelCommRulesListSearch extends Action
{

  /**
   * @Constructor
   */
  public OverrideChannelLevelCommRulesListSearch(){
  }

  /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean and get the Persistency ArrayList Object
   * @param: request - Request object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest request)  throws EElixirException
  {
    ArrayList _oCommRuleList = null;
    request.setAttribute("actiontype", DataConstants.ACTION_LISTSEARCH);
    try{

      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);

      log.debug("CHMSLHOME created");
      String cChannelType = request.getParameter("cChannelType");
      log.debug("Primary key" +  cChannelType);   
      _oCommRuleList = remoteCHMSL.searchOverrideCommRuleList(cChannelType);      
      setResult(_oCommRuleList);
      log.debug("result is set");
      request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
    }
    catch(RemoteException rex)
    {
      request.setAttribute("ResultObject", _oCommRuleList);
      throw new EElixirException(rex, "P1006");
    }
    catch(FinderException rex)
    {
      request.setAttribute("ResultObject", _oCommRuleList);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      request.setAttribute("ResultObject", _oCommRuleList);
      throw new EElixirException(cex, "P1007");
    }

    catch(EElixirException cex)
    {
      request.setAttribute("ResultObject", _oCommRuleList);
      throw cex;
    }


  }
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}
