/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: ContractListSearch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get ContractListSearch is the Action Class for Getting a list of Contract ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class ContractListSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the ContractListSearch class
   */
  public ContractListSearch()
  {

  }

  /**
   * This method uses the search data and to populate Contract
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    Object contractResult = null;
    String result =null;
    try{
      log.debug("ContractListSearch--In Process doing lookup");
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      log.debug("ContractListSearch--In Process Refrence Obtained " + remoteCHMSL);

      if(a_oRequest.getParameter("strContractNbr") != null)
      {
        String strContractNumber = a_oRequest.getParameter("strContractNbr");
        String dtEffFrom = a_oRequest.getParameter("dtEffFrom");
        
        String strProdCd = a_oRequest.getParameter("strProdCd");

        SearchData oSearchData = new SearchData();
        oSearchData.setTask1(strContractNumber);
        if(!dtEffFrom.trim().equals("")){
          oSearchData.setTaskDate1(DateUtil.retGCDate(dtEffFrom.trim()));
        }
        else{
          oSearchData.setTaskDate1(null);
        }
        if(a_oRequest.getParameter("nStatus")!= null && !a_oRequest.getParameter("nStatus").equals(""))
        {
			StringTokenizer st = new StringTokenizer(a_oRequest.getParameter("nStatus"),"|");
			String nStatus = st.nextToken();
			oSearchData.setTask3(nStatus);	
        }
        
        oSearchData.setTask2(strProdCd);
        contractResult = oSearchData;
        log.debug("ContractListSearch--Search Data Created " + oSearchData);
        a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);
        log.debug("ContractListSearch--Calling SearchContract " );
        result = remoteCHMSL.searchContract(contractResult);
        log.debug("ContractListSearch--Call SearchContract ended. Result is  " +  result );
      }
      else{
        log.debug("ContractListSearch--strContractNbr++++++++++not found");
        result = remoteCHMSL.searchContract();
      }
      log.debug("ContractListSearch--result accessed");
      setResult(result);
      log.debug("ContractListSearch--result is set");
    }
    catch(RemoteException rex)
    {
		rex.printStackTrace ();
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
		cex.printStackTrace ();
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
		fex.printStackTrace ();
      throw new EElixirException(fex, "P3024");
    }
  }


}