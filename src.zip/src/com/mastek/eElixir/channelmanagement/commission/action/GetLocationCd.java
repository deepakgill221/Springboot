/**
 * Get AgentAgencySearch  is the Action Class for Getting a list of Agencys ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       018/09/2002
 * @author    Nitin
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.moneymanagement.collections.util.RTFResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.moneymanagement.util.MMLookup;


public class GetLocationCd extends Action
{

   /**
    * Default Constructor
    */
   public GetLocationCd()
   {

   }

  /**
   * This method makes a remote call to the CHM Session bean which in turn makes a local
   * call to all other bean and creates the Application
   * @param: a_oRequest  HttpServletRequest.
   * @throws EElixirException
   */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
	   CommDispatchResult oCommDispatchResult = null;
	      SearchData oSearchData = new SearchData();
        try{

			a_oRequest.setAttribute("actiontype",DataConstants.ACTION_UPDATE);
			String strUserId = a_oRequest.getParameter("strUserId");
			log.debug("strUserId"+strUserId);
			//oSearchData.setTask1(strUserId);
			
			
			CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			oCommDispatchResult = remoteCHMSL.searchGetLocationCd(strUserId);
			setResult(oCommDispatchResult);
		  }
        catch(RemoteException rex)
   	 {
        	a_oRequest.setAttribute("ResultObject", oCommDispatchResult);
   		throw new EElixirException(rex, "MM900");
   	 }
   	 catch(FinderException rex)
   	 {
   		a_oRequest.setAttribute("ResultObject", oCommDispatchResult);
   		throw new EElixirException(rex, "MM900");
   	 }
   	 catch(CreateException cex)
   	 {
   		a_oRequest.setAttribute("ResultObject", oCommDispatchResult);
   		throw new EElixirException(cex, "MM901");
   	 }
   	 catch(EElixirException cex)
   	 {
   		a_oRequest.setAttribute("ResultObject", oCommDispatchResult);
   		throw cex;
   	 }
     }
	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}