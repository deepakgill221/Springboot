/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME				: Finder Fees Mapping
 *  FILENAME				: FinderFeesMapListSearch.java
 *  AUTHOR					: Shameem Shaik
 *  VERSION					: 1.0
 *  CREATION DATE			: Oct 29 2004
 *  COMPANY					: Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *-------------------------------------------------------------------------------- 
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * Action Class for Getting a list of FinderFees Map,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002 
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class FinderFeesMapListSearch extends Action
{

   /**
	* @roseuid 3B94961803B7
	*/

   public FinderFeesMapListSearch()
   {

   }

   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean
   * @param : request - Request object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */


   public void process(HttpServletRequest request)  throws EElixirException
   {
	 try
	 {
	   request.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
	   String result = null;
	   
	   CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
	   log.debug("CHMSLHOME created");
	   
	   SearchData _oSearchData = new SearchData();
	   String cChannelType  = request.getParameter("cChannelType");
	   _oSearchData.setTask1(cChannelType);
	   
	   String strContractName  = request.getParameter("strContractName");
	   _oSearchData.setTask2(strContractName);
	  
	   String strAgentCode = request.getParameter("strAgentCd");
	   _oSearchData.setTask3(strAgentCode);
	   
	   //String strAgentName     = request.getParameter("atb_agent_name");
	   //_oSearchData.setTask4(strAgentName);	   
	   
	   if (request.getParameter("dtEffFrom") != null)
	   {
		 _oSearchData.setTaskDate1(DateUtil.retGCDate(request.getParameter("dtEffFrom").trim()));
	   }
	   if(request.getParameter("nStatus")!= null && !request.getParameter("nStatus").equals(""))
	   {
		   StringTokenizer st = new StringTokenizer(request.getParameter("nStatus"),"|");
		   String nStatus = st.nextToken();
		   _oSearchData.setTask5(nStatus);	
	   }
	   result = remoteCHMSL.searchFinderFeesMap(_oSearchData);
	   setResult(result);
	 }

	 catch(RemoteException rex)
	 {
	   throw new EElixirException(rex, "P1006");
	 }
	 catch(CreateException cex)
	 {
	   throw new EElixirException(cex, "P1007");
	 }
	 catch(FinderException cex)
	 {
	   throw new EElixirException(cex, "P1007");
	 }
	 catch(Exception e)
	 {
		e.printStackTrace();
	 }

   }
   /**
	* Member Variables
	*/

   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}

