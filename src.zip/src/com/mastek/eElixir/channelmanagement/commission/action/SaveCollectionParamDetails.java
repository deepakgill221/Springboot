/********************************************************************
 *
 *  PROJECT				: MAMM
 *  MODULE NAME			: CHANNEL MANAGEMENT
 *  FILENAME			: SaveCollectionParamDetails.java
 *  AUTHOR				: Varun Kathariya
 *  VERSION				: 1.0
 *  CREATION DATE		: May 23, 2014
 *  COMPANY				: Mastek Ltd.
 *  COPYRIGHT			: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.commission.util.CollectionParamResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2
public class SaveCollectionParamDetails extends Action {
	
	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
	
	//Default Constructor
	public SaveCollectionParamDetails(){
		
	}

	@Override
	public void process(HttpServletRequest aORequest) throws EElixirException {
		log.debug("Start SaveCollectionParamDetails");
		String actionType = aORequest.getParameter("strAction");
		String strColnDtlsUpldParam = aORequest.getParameter("strColnDtlsUpldParam");
		String nOldStatus = aORequest.getParameter("nOldStatus");
		String nStatus = aORequest.getParameter("nStatus");
		String nIsProcessed = aORequest.getParameter("nIsProcessed");
		
		try {
			log.debug("Action to be processed: "+ actionType);			
			CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome",CHMSLHome.class);
			CollectionParamResult collectionParamResult = new CollectionParamResult();
			
			if(nIsProcessed!=null && !"".equals(nIsProcessed.trim())){
				collectionParamResult.set_nOverideBonusProcessed(Short.parseShort(nIsProcessed));
			}
			
			if(CHMConstants.COLLECTION_PARAM_SAVE.equalsIgnoreCase(actionType)){
				//Collection Param status i.e. Approved(5)/Pending(1)- default
				collectionParamResult.set_nIsActive((short)1);
				//This value comes up in request only when the field is not disabled
				collectionParamResult.set_nStatus(Short.parseShort(strColnDtlsUpldParam));
			}
			if(CHMConstants.COLLECTION_PARAM_APPROVE.equalsIgnoreCase(actionType)){
				//Collection Param status i.e. Approved(5)/Pending(0)- default
				collectionParamResult.set_nIsActive((short)5);
				collectionParamResult.set_nStatus(Short.parseShort(nStatus));
				//OverideBonusProcessed = 0 means override bonus is not processed (default 2)
				collectionParamResult.set_nOverideBonusProcessed((short) 2);
			}
			if(CHMConstants.COLLECTION_PARAM_REJECT.equalsIgnoreCase(actionType)){
				//Collection Param status i.e. Approved(5)/Pending(1)- default/Rejected(10)
				collectionParamResult.set_nIsActive((short)10);
				collectionParamResult.set_nStatus(Short.parseShort(nStatus));
			}
			
			if(nOldStatus!=null){
				collectionParamResult.set_nOldStatus(Short.parseShort(nOldStatus));
			}			
						
			collectionParamResult.set_strCreatedBy((String)aORequest.getSession().getAttribute("username"));
			collectionParamResult.set_strUpdatedBy((String)aORequest.getSession().getAttribute("username"));
			log.debug(collectionParamResult.toString());
			collectionParamResult =  remoteCHMSL.saveCollectionParams(collectionParamResult);
			setResult(collectionParamResult);
		} catch (RemoteException e) {
			e.printStackTrace();
			log.exception(e.getMessage());
		} catch (CreateException e) {
			e.printStackTrace();
			log.exception(e.getMessage());
		}
	}

}
