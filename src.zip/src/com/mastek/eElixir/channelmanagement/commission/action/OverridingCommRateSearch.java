/********************************************************************
*
*  PROJECT			: Amal
*  MODULE NAME		        : Customer Development
*  FILENAME			: OverridingCommRateSearch
*  AUTHOR			: Pallav
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 6, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * OverridingCommRateSearch is the Action Class for Getting a OverridingCommission Rate Detail,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       6Mar 2003
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class OverridingCommRateSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor of the OverridingCommRateSearch class
   */
  public OverridingCommRateSearch()
  {

  }


  /**
   * Gets the detail for that OverridingCommRate
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ArrayList arrOverridingCommRateResult = null;
    try{

      //MenuAccessLog.createMenuAccessLog(a_oRequest);
      long lPriKey = new Long(((String)a_oRequest.getParameter("strPKey")).trim()).longValue();
       CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      arrOverridingCommRateResult = remoteCHMSL.searchOverridingCommRate(lPriKey);
      log.debug("ChannelSearch--result accessed");
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      setResult(arrOverridingCommRateResult);
      log.debug("ChannelSearch--result is set");
    }
    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "P3052");
    }
  }
}