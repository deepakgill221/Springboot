/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME			: CHANNEL MANAGEMENT
*  FILENAME						: ContractMapCreate.java
*  AUTHOR						: VINAYSHEEL BABER
*  VERSION						: 1.0
*  CREATION DATE			: August 5, 2002
*  COMPANY					: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
* 2.1       10/9/2003     Dipti F		UT Rework
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.ContractMapResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

/**
 * Inserts contract mapping details in chm_contract_map
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author    Vinaysheel Baber
 * @version 1.0
 */



public class ContractMapCreate extends Action
{

   /**
    * @roseuid 3B94961803B7
    */

   public ContractMapCreate()
   {

   }

   /**
    * @return Object
    * @roseuid 3B94961803C1
    */

   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean .
   * @param : ResultObject object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */


   public void process(HttpServletRequest request)  throws EElixirException
   {
     request.setAttribute("actiontype",DataConstants.ACTION_CREATE);
     HttpSession  session = request.getSession();
     String  strUserId = (String)session.getAttribute("username");
     log.debug("In CREATE CLASS******************");
     String[] strContractNbr = request.getParameterValues("strCommissionRule");
     String cChannelType = request.getParameter("cChannelType");
     log.debug("Channel Type");
     String strAgentCd = request.getParameter("strAgentCd");
     log.debug("Agent Code");
     String strSubChannelType = request.getParameter("strSubChannelType");
     log.debug("Sub channel type" + strSubChannelType);

  //   String strContractType = request.getParameter("nContractType");
     String[] dtEffDateFrom = request.getParameterValues("dtMappingEffFrom");
     String[] dtEffDateTo = request.getParameterValues("dtMappingEffTo");
     ArrayList al = new ArrayList();
     try
     {
       if (strContractNbr != null && strContractNbr.length != 0)
       {
         for (int i =0; i<strContractNbr.length;i++)
         {
            _oContractMapResult = new ContractMapResult();
            _oContractMapResult.setChannelType(cChannelType);
            log.debug(cChannelType);
         //   _oContractMapResult.setSubChannelType(strSubChannelType);
            log.debug(strSubChannelType);
            _oContractMapResult.setAgentCd(strAgentCd.trim());
            log.debug(strAgentCd);
            _oContractMapResult.setEffFrom(DateUtil.retGCDate(dtEffDateFrom[i]));
            log.debug(dtEffDateFrom[i]);
            _oContractMapResult.setContractNbr(strContractNbr[i]);
            log.debug(strContractNbr[i]);
            _oContractMapResult.setEffTo(DateUtil.retGCDate(dtEffDateTo[i]));
            log.debug(dtEffDateTo[i]);
            _oContractMapResult.setUserId(strUserId);
            al.add(_oContractMapResult);
         }
       }

       CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);


       setResult(_oContractMapResult);
       log.debug("After EJBHomeFactory");
       long lContMapSeqNbrPKey = remoteCHMSL.createContractMap(al);
       log.debug("CHMSLHOME created");
       al = remoteCHMSL.searchContractMap(lContMapSeqNbrPKey);
       log.debug("result accessed");
       setResult(al);
       log.debug("result is set");
       request.setAttribute("actiontype",DataConstants.ACTION_UPDATE);

     }
      catch(RemoteException rex)
      {
        request.setAttribute("ResultObject", _oContractMapResult);
        throw new EElixirException(rex, "P1006");
      }
      catch(CreateException cex)
      {
        request.setAttribute("ResultObject", _oContractMapResult);
        throw new EElixirException(cex, "P1007");
      }
      catch(FinderException cex)
      {
        request.setAttribute("ResultObject", _oContractMapResult);
        throw new EElixirException(cex, "P1007");
      }

      log.debug("From CHMSLEJB");
      //setResult(result);
   }

   //class level variable declarations.

   ContractMapResult _oContractMapResult = null;
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}






