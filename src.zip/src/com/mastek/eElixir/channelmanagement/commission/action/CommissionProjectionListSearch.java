/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: CommissionProjectionListSearch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get CommissionProjectionListSearch is the Action Class for Getting a list of CommissionProjection ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class CommissionProjectionListSearch extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the CommissionProjectionListSearch class
   */
  public CommissionProjectionListSearch()
  {

  }

  /**
   * This method uses the search data and to populate CommissionProjection
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    String result =null;
    try{
      log.debug("CommissionProjectionListSearch--In Process doing lookup");
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      log.debug("CommissionProjectionListSearch--In Process Refrence Obtained " + remoteCHMSL);

      String strAgentCd = a_oRequest.getParameter("strAgentCd");
      String strAgentName = a_oRequest.getParameter("strAgentName");
      String iCalYear = a_oRequest.getParameter("iCalYear");
      String nCalMonth = a_oRequest.getParameter("nCalMonth");
      String strCommClass = a_oRequest.getParameter("strCommClass");
      String strProdCdVer = a_oRequest.getParameter("strProdCdVer");

      StringTokenizer st = new StringTokenizer(strProdCdVer,"|");
      String strProdCd = null;
      String strProdVer = null;
      while(st.hasMoreTokens()){
        strProdCd = (String)st.nextElement();
        break;
      }
      while(st.hasMoreTokens()){
        strProdVer = (String)st.nextElement();
      }

      SearchData oSearchData = new SearchData();
      oSearchData.setTask1(strAgentCd);
      oSearchData.setTask2(strAgentName);
      oSearchData.setTask3(iCalYear);
      oSearchData.setTask4(nCalMonth);
      oSearchData.setTask5(strCommClass);
      oSearchData.setTask6(strProdCd);
      oSearchData.setTask7(strProdVer);

      log.debug("CommissionProjectionListSearch--Search Data Created " + oSearchData);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);
      log.debug("CommissionProjectionListSearch--Calling SearchCommissionProjection " );
      result = remoteCHMSL.searchCommissionProjection(oSearchData);
      log.debug("CommissionProjectionListSearch--Call SearchCommissionProjection ended. Result is  " +  result );
      setResult(result);
      log.debug("CommissionProjectionListSearch--result is set");
    }
    catch(RemoteException rex)
    {
      rex.printStackTrace ();
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      cex.printStackTrace ();
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      fex.printStackTrace ();
      throw new EElixirException(fex, "P3205");
    }
  }


}