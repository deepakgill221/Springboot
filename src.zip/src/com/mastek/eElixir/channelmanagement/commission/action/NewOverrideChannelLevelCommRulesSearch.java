/********************************************************************
 *
 *  PROJECT					: MMMA
 *  MODULE NAME				: CHANNEL MANAGEMENT
 *  FILENAME				: NewOverrideChannelLevelCommRulesSearch.java
 *  AUTHOR					: Anup Kumar
 *  VERSION					: 1.0
 *  CREATION DATE			: September 04, 2009
 *  COMPANY					: Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2002.
 *	CODE TAG				: Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/


package com.mastek.eElixir.channelmanagement.commission.action;

/**
 * Called at the beginnning of Override Channel Level Commission Rules Create
 * Copyright (c) 2002 Mastek Ltd
 * Date       04/09/20089
 * @author    Anup kumar
 * @version 1.0
 */

 import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;


 public class NewOverrideChannelLevelCommRulesSearch extends Action
 {

   
   public NewOverrideChannelLevelCommRulesSearch()
   {

   }

   /**
    * blank process method to follow the MVC architecture, it just makes the xsl file available to the requested jsp at the beginning
    * @param : request - Request object.
    * @throws EElixirException
    */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     try
     {
       MenuAccessLog.createMenuAccessLog(a_oRequest);
       a_oRequest.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
     }
     catch(RemoteException rex)
     {
       throw new EElixirException(rex, "P1006");
     }
     catch(CreateException cex)
     {
       throw new EElixirException(cex, "P1007");
     }
     catch(EElixirException eex)
     {
       throw eex;
     }

   }
 }