/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME				: Finder Fees Mapping
 *  FILENAME				: FinderFeesMapListSearch.java
 *  AUTHOR					: Shameem Shaik
 *  VERSION					: 1.0
 *  CREATION DATE			: Oct 29 2004
 *  COMPANY					: Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *-------------------------------------------------------------------------------- 
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * Action Class for Getting a list of FinderFees Map,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002 
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;


import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class RYCRuleMasterListSearch extends Action
{

   /**
	* @roseuid 3B94961803B7
	*/

   public RYCRuleMasterListSearch()
   {

   }

   /**
   * This method makes a remote call to the Session bean which in turn makes a local
   * call to all other bean
   * @param : a_oRequest - Request object.
   * @roseuid 3B94961803CB
   * @throws EElixirException
   */


   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
	 try
	 {

	   a_oRequest.setAttribute("actiontype",DataConstants.ACTION_LISTSEARCH);
	   String result = null;
	   
	   CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
	   log.debug("CHMSLHOME created");

	   
			   SearchData _oSearchData = new SearchData();
    		  _oSearchData.setTask1(a_oRequest.getParameter("rycrule"));
			  _oSearchData.setTask2(a_oRequest.getParameter("nStatus"));	
   			  _oSearchData.setTask3(a_oRequest.getParameter("nChannelType"));
   			 
   	
			 if (a_oRequest.getParameter("dtEffFrom") != null)
			 {
				 _oSearchData.setTaskDate1(DateUtil.retGCDate(a_oRequest.getParameter("dtEffFrom").trim()));
			}
			else{
				_oSearchData.setTaskDate1(null);
			}


			if (a_oRequest.getParameter("dtEffTo") != null)
			 {
			 _oSearchData.setTaskDate2(DateUtil.retGCDate(a_oRequest.getParameter("dtEffTo").trim()));
			 }
			 else{
			_oSearchData.setTaskDate2(null);
			}

			 a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);
			result = remoteCHMSL.searchRYCRuleMaster(_oSearchData);
		
	  
		

	   setResult(result);
	 }

	 catch(RemoteException rex)
	 {
	   throw new EElixirException(rex, "P1006");
	 }
	 catch(CreateException cex)
	 {
	   throw new EElixirException(cex, "P1007");
	 }
	 catch(FinderException cex)
	 {
	   throw new EElixirException(cex, "P1007");
	 }
	 catch(Exception e)
	 {
		e.printStackTrace();
	 }

   }
   /**
	* Member Variables
	*/

   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}

