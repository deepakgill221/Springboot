/********************************************************************
*
*  PROJECT		: PRUDENTIAL
*  MODULE NAME		: CHANNEL MANAGEMENT
*  FILENAME		: CommissionProjectionAdd.java
*  AUTHOR		: Pallav
*  VERSION		: 1.0
*  CREATION DATE	: Jan 20,2003
*  COMPANY		: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * This Action Class is Used when User clicks New button on List Search Page
 * to Create New KPI Definition Entry.
 */

// PACKAGE DEFNETION
package com.mastek.eElixir.channelmanagement.commission.action;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;



public class CommissionProjectionAdd extends Action
{
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor
   */
  public CommissionProjectionAdd()
  {

  }


  /**
   * This is a dummy method, used only when entry page is loaded first time
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
  }
}