/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : Finder Fees
*  FILENAME			: FFCommissionRatesSearch.java
*  AUTHOR			: Jimmy K G
*  VERSION			: 1.0
*  CREATION DATE	: December 19-2005
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * FinderFeesCreate is the Action Class for creating a new FinderFees.
 * Copyright (c) 2002 Mastek Ltd
 * Date       19/12/2005
 * @author   Jimmy K G
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class FFCommissionRatesSearch extends Action
{
  
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the CommissionRatesSearch class
   */
  public FFCommissionRatesSearch()
  {

  }


  /**
   * This method makes a remote call to the Session bean which in turn makes a
   * call to all other ejb bean and creates a record and populates the DVO
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
	log.debug("===========================  FFCommissionSearch Process Start =====================================");
	FinderFeesResult oFinderFeesResult = null;
	long lffhseqNo;
	String strPrdcd=null;
	
	try{
	  CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
	  lffhseqNo=Long.parseLong(a_oRequest.getParameter("lFFHdrSeqNbr"));
	  strPrdcd=a_oRequest.getParameter("cProductCode");
	  log.debug("process -- > invoking  searchFFCommissionRates()");
	  oFinderFeesResult = remoteCHMSL.searchFFCommissionRates(lffhseqNo,strPrdcd);
	  log.debug("process -- > done searchFFCommissionRates()");
	  log.debug("process -- > oFinderFeesResult"+oFinderFeesResult);
	  setResult(oFinderFeesResult);
		
	}
	catch(RemoteException rex)
	{		
	  a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
	  throw new EElixirException(rex, "P1006");
	}
	catch(CreateException cex)
	{	
	  a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
	  throw new EElixirException(cex, "P1007");
	}
	catch(EElixirException eex)
	{	
	  log.debug("FFCommissionSearch--Inside catch of EElixir exception in process of FFCommissionSearch");
	  a_oRequest.setAttribute("ResultObject", oFinderFeesResult);
	  throw eex;
	} catch (FinderException e) {
		
		e.printStackTrace();
	}
  }
  
}