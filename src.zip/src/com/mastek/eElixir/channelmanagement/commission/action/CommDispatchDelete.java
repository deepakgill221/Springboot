/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME				: CommDispatchDelete.java
 *  AUTHOR					: Amid P Sahu
 *  VERSION					: 1.0
 *  CREATION DATE		    : Aprl 12, 2009
 *  COMPANY				    : Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *   
 *--------------------------------------------------------------------------------
 *Amid_Fin_156_Upload Of Commission Dispatch
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.commission.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class CommDispatchDelete extends Action {

	/**
	 * Constructer
	 */

	public CommDispatchDelete() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :
	 *            ResultObject object.
	 * @roseuid 3B94961803CB
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		CHMSL remoteCHMSL = null;
		String result = null;
		try {
			log.debug("Amid inside the process method");			
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);			
			SearchData _oSearchData = new SearchData();  
	       if (request.getParameter("dtUpload") != null)
	       {
	         _oSearchData.setTaskDate3(DateUtil.retGCDate(request.getParameter("dtUpload").trim()));
	       }  	
	       result = remoteCHMSL.deleteCommissionDispatch(_oSearchData);
	       log.debug("p_dtUpload>>"+request.getParameter("dtUpload"));	
	       request.setAttribute("p_dtUpload",request.getParameter("dtUpload"));	
	       setResult(result);
	       	  
		} catch (FinderException fex) {
			request.setAttribute("ResultObject", _oCommDispatchList);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oCommDispatchList);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oCommDispatchList);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log.debug("In SegmentUpdate eelixir exception before setting result"
							+ eLex);
			
			request.setAttribute("ResultObject", _oCommDispatchList);
			throw eLex;
		}

	}

	// class level variable declarations.

	CommDispatchResult _oCommDispatchResult = null;

	ArrayList _oCommDispatchList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
