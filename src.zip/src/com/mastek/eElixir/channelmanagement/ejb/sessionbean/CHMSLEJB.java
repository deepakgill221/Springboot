/********************************************************************
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  	BY				REASON
*--------------------------------------------------------------------------------
*1.1		07/04/2015		Vibhu Nigam		FIN838_AgentCommissionDisbursementLimitChange
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.benefit.ejb.sessionbean.BenefitSL;
import com.mastek.eElixir.channelmanagement.benefit.ejb.sessionbean.BenefitSLHome;
import com.mastek.eElixir.channelmanagement.benefit.util.BenefitResult;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.channelmanagement.commission.dvo.ContractProdValidate;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.CommissionProjectionSL;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.CommissionProjectionSLHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.CommissionSL;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.CommissionSLHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.ContractSL;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.ContractSLHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.FinderFeesSL;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.FinderFeesSLHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.PolicyAckSL;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.PolicyAckSLHome;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.RYCRuleMasterSL;
import com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.RYCRuleMasterSLHome;
import com.mastek.eElixir.channelmanagement.commission.util.CollectionParamResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionProjectionResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractCopyResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.commission.util.DisbursementSetupResult;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
import com.mastek.eElixir.channelmanagement.contest.ejb.sessionbean.ContestSL;
import com.mastek.eElixir.channelmanagement.contest.ejb.sessionbean.ContestSLHome;
import com.mastek.eElixir.channelmanagement.contest.util.ContestResult;
import com.mastek.eElixir.channelmanagement.csacpa.ejb.sessionbean.CsaCpaSL;
import com.mastek.eElixir.channelmanagement.csacpa.ejb.sessionbean.CsaCpaSLHome;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.sessionbean.FormulaEngineSL;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.sessionbean.FormulaEngineSLHome;
import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitResultMain;
import com.mastek.eElixir.channelmanagement.gpa.ejb.sessionbean.GpaSL;
import com.mastek.eElixir.channelmanagement.gpa.ejb.sessionbean.GpaSLHome;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardMasterResult;
import com.mastek.eElixir.channelmanagement.master.ejb.entitybean.Tax;
import com.mastek.eElixir.channelmanagement.master.ejb.entitybean.TaxHome;
import com.mastek.eElixir.channelmanagement.master.ejb.sessionbean.CustomSettingSL;
import com.mastek.eElixir.channelmanagement.master.ejb.sessionbean.CustomSettingSLHome;
import com.mastek.eElixir.channelmanagement.master.ejb.sessionbean.MasterSL;
import com.mastek.eElixir.channelmanagement.master.ejb.sessionbean.MasterSLHome;
import com.mastek.eElixir.channelmanagement.master.util.AllocationMarkerResult;
import com.mastek.eElixir.channelmanagement.master.util.CbpResult;
import com.mastek.eElixir.channelmanagement.master.util.CompanyResult;
import com.mastek.eElixir.channelmanagement.master.util.CustomSettingResult;
import com.mastek.eElixir.channelmanagement.master.util.ProductResult;
import com.mastek.eElixir.channelmanagement.master.util.QuestionResult;
import com.mastek.eElixir.channelmanagement.master.util.StateResult;
import com.mastek.eElixir.channelmanagement.master.util.SubChannelResult;
import com.mastek.eElixir.channelmanagement.master.util.TaxResult;
import com.mastek.eElixir.channelmanagement.payments.ejb.sessionbean.PaymentWithHoldSL;
import com.mastek.eElixir.channelmanagement.payments.ejb.sessionbean.PaymentWithHoldSLHome;
import com.mastek.eElixir.channelmanagement.process.util.ProcessResult;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.AgencySL;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.AgencySLHome;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.AgentSL;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.AgentSLHome;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.ApplicationSL;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.ApplicationSLHome;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.BlackListSL;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.BlackListSLHome;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.BounceChargesExcemptionSL;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.BounceChargesExcemptionSLHome;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.IrdaRecordSL;
import com.mastek.eElixir.channelmanagement.recruitment.ejb.sessionbean.IrdaRecordSLHome;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgencyResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentAgencyResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentContractDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentMovementDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentPerformanceDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentPersistancyDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentRefreeDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentSegmentHistoryResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.ApplicationResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.BlackListResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.BounceChargesExcemptionResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.IrdaRecordResult;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.sessionbean.SegmentSL;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.sessionbean.SegmentSLHome;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.sessionbean.SurrenderRateDefSL;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.sessionbean.SurrenderRateDefSLHome;
import com.mastek.eElixir.channelmanagement.segmentation.util.AdjustedPaidCaseResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.MPSResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.ManualSegmentResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentCriteriaResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentWeightageResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SurrenderRateDefResult;
import com.mastek.eElixir.channelmanagement.setup.ejb.sessionbean.PersistencySL;
import com.mastek.eElixir.channelmanagement.setup.ejb.sessionbean.PersistencySLHome;
import com.mastek.eElixir.channelmanagement.setup.util.PersistencyResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.sessionbean.AgencyDocSL;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.sessionbean.AgencyDocSLHome;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.sessionbean.BonusSL;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.sessionbean.BonusSLHome;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.sessionbean.DesignationSL;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.sessionbean.DesignationSLHome;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.sessionbean.ReportingStructureSL;
import com.mastek.eElixir.channelmanagement.structuremaintenance.ejb.sessionbean.ReportingStructureSLHome;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.BonusResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.BonusSlabResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.DesignationResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.RepHierarchyResult;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.sessionbean.ManualOverrideSL;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.sessionbean.ManualOverrideSLHome;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.sessionbean.MovementCriteriaSL;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.sessionbean.MovementCriteriaSLHome;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.sessionbean.MovementSL;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.sessionbean.MovementSLHome;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.sessionbean.PolicyTransferSL;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.sessionbean.PolicyTransferSLHome;
import com.mastek.eElixir.channelmanagement.structuremovements.util.AgencyMovementResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.AgentMovementResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.MovementCriteriaResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.PolicyResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.PolicyTransferResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.SuspendResult;
import com.mastek.eElixir.channelmanagement.target.ejb.sessionbean.DairitenEvalDefinitionSL;
import com.mastek.eElixir.channelmanagement.target.ejb.sessionbean.DairitenEvalDefinitionSLHome;
import com.mastek.eElixir.channelmanagement.target.ejb.sessionbean.ExcepAgencyPromoSL;
import com.mastek.eElixir.channelmanagement.target.ejb.sessionbean.ExcepAgencyPromoSLHome;
import com.mastek.eElixir.channelmanagement.target.ejb.sessionbean.TargetSL;
import com.mastek.eElixir.channelmanagement.target.ejb.sessionbean.TargetSLHome;
import com.mastek.eElixir.channelmanagement.target.util.DairitenEvalDefinitionResult;
import com.mastek.eElixir.channelmanagement.target.util.ExcepAgencyPromoResult;
import com.mastek.eElixir.channelmanagement.target.util.TargetResult;
import com.mastek.eElixir.channelmanagement.util.ApprovalResult;
import com.mastek.eElixir.channelmanagement.util.CHMJQueryData;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.common.ejb.sessionbean.ApprovalSL;
import com.mastek.eElixir.common.ejb.sessionbean.ApprovalSLHome;
import com.mastek.eElixir.common.ejb.sessionbean.CommonSL;
import com.mastek.eElixir.common.ejb.sessionbean.CommonSLHome;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.AddressMasterResult;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.UserResult;


public class CHMSLEJB implements SessionBean
{
    private PolicyAckSL _oPolicyAckSL = null;
    private PolicyAckSLHome _oPolicyAckSLHome = null;

    //overriding comm rate ends here sandeepb
    //***********************PHASE I variables********************************************
    private CommissionSLHome _oCommissionSLHome;
    private CommissionSL _oCommissionSL;
    private PaymentWithHoldSLHome oPaymentWithHoldSLHome;
    private PaymentWithHoldSL oPaymentWithHoldSL;
    public ReportingStructureSLHome _oReportingStructureSLHome;
    private ReportingStructureSL _oReportingStructureSL;
    public DesignationSLHome _oDesignationSLHome;
    private DesignationSL _oDesignationSL;

    //member variable for Prasad end
    private ApplicationSLHome _oApplicationSLHome;
    private ApplicationSL _oApplicationSL;
    private AgentSLHome _oAgentSLHome;
    private AgentSL _oAgentSL;
    private AgencySLHome _oAgencySLHome;
    private AgencySL _oAgencySL;

    /* Reference to Remote Interface and Home name for Contract*/
    private ContractSL _oContractSL = null;
    private ContractSLHome _oContractSLHome = null;
    private AgencyDocSLHome _oAgencyDocSLHome;
    private AgencyDocSL _oAgencyDocSL;
    public PersistencySLHome _oPersistencySLHome;
    private PersistencySL _oPersistencySL;

    // declaration for Pallav starts
    //Member variables
    private BenefitSLHome _oBenefitSLHome;
    private BenefitSL _oBenefitSL;
    private ApprovalSLHome _oApprovalSLHome;
    private ApprovalSL _oApprovalSL;
    private FormulaEngineSLHome _oFormulaEngineSLHome;
    private FormulaEngineSL _oFormulaEngineSL;
    private MasterSLHome _oMasterSLHome;
    private MasterSL _oMasterSL;
    private CommonSLHome _oCommonSLHome = null;
    private CommonSL _oCommonSL = null;

    // declaration for pallav ends
    //***********************PHASE I variables END********************************************
    //***********************PHASE II variables START********************************************
    private MovementSL _oMovementSL = null;
    private MovementSLHome _oMovementSLHome = null;
    private BlackListSLHome _oBlackListSLHome = null;
    private BlackListSL _oBlackListSL = null;
    private ContestSLHome _oContestSLHome = null;
    private ContestSL _oContestSL = null;
    private PolicyTransferSL _oPolicyTransferSL = null;
    private PolicyTransferSLHome _oPolicyTransferSLHome = null;
    private DairitenEvalDefinitionSL _oDairitenEvalDefinitionSL = null;
    private DairitenEvalDefinitionSLHome _oDairitenEvalDefinitionSLHome = null;
    private MovementCriteriaSLHome _oMovementCriteriaSLHome = null;
    private MovementCriteriaSL _oMovementCriteriaSL = null;
    private TargetSLHome _oTargetSLHome = null;
    private TargetSL _oTargetSL = null;
    private ExcepAgencyPromoSL _oExcepAgencyPromoSL = null;
    private ExcepAgencyPromoSLHome _oExcepAgencyPromoSLHome = null;
    private CommissionProjectionSLHome _oCommissionProjectionSLHome = null;
    private CommissionProjectionSL _oCommissionProjectionSL = null;

    //***********************PHASE II variables END********************************************
    // Vikrant - Start
    private TaxHome _oTaxHome = null;
    private Tax _oTax = null;
    private BonusSLHome _oBonusSLHome;
    private BonusSL _oBonusSL;

	// added by shameem
	private FinderFeesSLHome _oFinderFeesSLHome ;
	private FinderFeesSL _oFinderFeesSL;
	
/*Commented by jayasimha for dscoping of Lapserule and lapse rule descoping 

	private LapseRuleSLHome _oLapseRuleSLHome ;
	private LapseRuleSL _oLapseRuleSL;

End of Descoping*/

	private RYCRuleMasterSLHome _oRYCRuleMasterSLHome;
	private RYCRuleMasterSL _oRYCRuleMasterSL;

	private ManualOverrideSLHome _oManualOverrideSLHome;
	private ManualOverrideSL _oManualOverrideSL;

    // Vikrant - End
	
	
//	AMID_IRDA_RECORDS_PH2_START
	private IrdaRecordSLHome _oIrdaRecordSLHome;
	private IrdaRecordSL _oIrdaRecordSL;
//	AMID_IRDA_RECORDS_PH2_END
	//Prabhat_Bounce_charge_Exemption_FIN_68 start
	
	private BounceChargesExcemptionSLHome _oBounceChargesExcemptionSLHome;
	private BounceChargesExcemptionSL _oBounceChargesExcemptionSL;
	
	//Prabhat_Bounce_charge_Exemption_FIN_68 End
	// Amid CSA/CPA - Start
	
	private CsaCpaSLHome _oCsaCpaSLHome;
	private CsaCpaSL _oCsaCpaSL;
	
	//Amid CSA/CPA - End
	private SegmentSLHome _oSegmentSLHome;
    private SegmentSL _oSegmentSL;
    private GpaSL  _oGpaSL;
    private GpaSLHome _oGpaSLHome;
    //Amid_FSD_FYC & RYC Payment post Agent Termination Start
    private CustomSettingSLHome _oCustomSettingSLHome;
	private CustomSettingSL _oCustomSettingSL;	
    //Amid_FSD_FYC & RYC Payment post Agent Termination End
	
	/* Added by Manisha on 15-May-2014 for Release 15.1 FSD_AGN867_ SurrenderRateSegmentationCriteria STARTS*/
	public SurrenderRateDefSLHome _oSurrendRateDefSLHome;
    private SurrenderRateDefSL _oSurrendRateDefSL;
    /* Added by Manisha on 15-May-2014 for Release 15.1 FSD_AGN867_ SurrenderRateSegmentationCriteria ENDS*/
	
    private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

    public CHMSLEJB()
    {
    }

    public void ejbCreate()
    {
    }

    public void ejbRemove()
    {
    }

    public void ejbActivate()
    {
    }

    public void ejbPassivate()
    {
    }

    public void setSessionContext(SessionContext sc)
    {
    }

    /* Added onsite by Vinay Cerejo on 08/01/2003 -- START */
    public ArrayList getChannelDesignationMasterList()
        throws EElixirException
    {
        ArrayList alChannelDesignationMaster = null;
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oReportingStructureSLHome = (ReportingStructureSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ReportingStructureSLHome"),
                    ReportingStructureSLHome.class);
            _oReportingStructureSL = _oReportingStructureSLHome.create();
            alChannelDesignationMaster = _oReportingStructureSL.getChannelDesignationMasterList();
        }
        catch (CreateException cex)
        {
            throw new EElixirException("P8600");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException("P8600");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
        return alChannelDesignationMaster;
    }

    public SearchData agencyListSearch(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
       

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

            _oAgencySLHome = (AgencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "AgencySLHome"), AgencySLHome.class);
            _oAgencySL = _oAgencySLHome.create();

            a_oSearchData = _oAgencySL.agencyListSearch(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
                cex);
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
                rex);
            throw new EElixirException(rex.getMessage());
        }

        return a_oSearchData;
    }

    public SearchData agentListSearch(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oAgentSLHome = (AgentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "AgentSLHome"), AgentSLHome.class);
            _oAgentSL = _oAgentSLHome.create();
            a_oSearchData = _oAgentSL.agentListSearch(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
                cex);
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
                rex);
            throw new EElixirException(rex.getMessage());
        }

        return a_oSearchData;
    }
    
    
//FIn_126_Anantha starts
	
    /**
     * Gives the List of Agents
         * @param a_oSearchData
         * @return
         * @throws RemoteException
         * @throws EElixirException
         */
	 public String searchAgentTxAcct(SearchData a_oSearchData) 
	 throws FinderException, EElixirException
	 {
		 {
		        String resultString = null;

		        try
		        {
		        	log.debug("CHMSLEJB--searchAgentTxAcct---Before  objEJBHomeFactory");
		            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		            _oAgentSLHome = (AgentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
		                        "AgentSLHome"), AgentSLHome.class);
		            _oAgentSL = _oAgentSLHome.create();
		            resultString = _oAgentSL.searchAgentTxAcct(a_oSearchData);
		        }
		        catch (CreateException cex)
		        {
		            log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
		                cex);
		            throw new EElixirException(cex.getMessage());
		        }
		        catch (RemoteException rex)
		        {
		            log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
		                rex);
		            throw new EElixirException(rex.getMessage());
		        }

		        return resultString;
		    }

	 }
	 
	 
	 

    public AgentAgencyResult agentAgencySearch(String a_strAgentCd,int iDetReqd)
        throws FinderException, EElixirException
    {

        AgentAgencyResult oAgentAgencyResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oAgencySLHome = (AgencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "AgencySLHome"), AgencySLHome.class);
            _oAgencySL = _oAgencySLHome.create();
            oAgentAgencyResult = _oAgencySL.agentAgencySearch(a_strAgentCd,iDetReqd);
            return oAgentAgencyResult;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
                cex);
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
                rex);
            throw new EElixirException(rex.getMessage());
        }
    }
    //Modified by Amid for FSD_AGN_69_Restriction on Agent movement v1.2 Start 
   
    public AgentAgencyResult AgentAgencyTerminationEntry(String a_strAgentCd)
    throws FinderException, EElixirException
	{
	
	    AgentAgencyResult oAgentAgencyResult = null;
	
	    try
	    {
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oAgencySLHome = (AgencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "AgencySLHome"), AgencySLHome.class);
	        _oAgencySL = _oAgencySLHome.create();
	        oAgentAgencyResult = _oAgencySL.AgentAgencyTerminationEntry(a_strAgentCd);
	        return oAgentAgencyResult;
	    }
	    catch (CreateException cex)
	    {
	        log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
	            cex);
	        throw new EElixirException(cex.getMessage());
	    }
	    catch (RemoteException rex)
	    {
	        log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
	            rex);
	        throw new EElixirException(rex.getMessage());
	    }
	}
    //Modified by Amid for FSD_AGN_69_Restriction on Agent movement v1.2 End
    //Modified by Amid for Pagination
    public SearchData agentAgencyListSearch(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        String resultString = null;
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oAgencySLHome = (AgencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "AgencySLHome"), AgencySLHome.class);
            _oAgencySL = _oAgencySLHome.create();

            a_oSearchData = _oAgencySL.agentAgencyListSearch(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
                cex);
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
                rex);
            throw new EElixirException(rex.getMessage());
        }
        return a_oSearchData;
    }

    public String searchContractMap(SearchData _oSearchData)
        throws FinderException, EElixirException
    {
        String strResult = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oContractSLHome = (ContractSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);

        try
        {
            _oContractSL = _oContractSLHome.create();
            strResult = _oContractSL.searchContractMap(_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }

        return strResult;
    }

    /* end searchContractMap */

    //*********************************************************************************************************************//
    ///////////////////////////////////// CODE BY JIMMY START HERE ////////////////////////////
    public String getAgencyCd(String a_strAgentCd) throws EElixirException
    {
        try
        {
            _oAgencySL = getAgencySL("AgencySLHome", AgencySLHome.class);
            String strAgencyCd = _oAgencySL.getAgencyCd(a_strAgentCd);
            return strAgencyCd;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public Short getAgencyLength() throws EElixirException
    {
        try
        {
            _oAgencySL = getAgencySL("AgencySLHome", AgencySLHome.class);
            Short nAgencyLength = _oAgencySL.getAgencyLength();
            return nAgencyLength;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }
	//Added by Srikanth CTS for App and DOJ functionality
	 public ArrayList getDesignationsApplicable() throws EElixirException
    {
	ArrayList a_list = null;
        try
        {
		log.debug("CHMSLEJB getDesignationsApplicable Start");
         _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
         a_list = _oAgentSL.getDesignationsApplicable();
		 return a_list;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }
	//End Srikanth

    //Modified by Prabhat for Pagination 
    //Modified returned type
    
    public SearchData searchApplication(SearchData a_oSearchData)
        throws EElixirException
    {
        try
        {
            _oApplicationSL = getApplicationSL("ApplicationSLHome",
                    ApplicationSLHome.class);
            a_oSearchData = _oApplicationSL.searchApplication(a_oSearchData);
            return a_oSearchData;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public long createApplication(ApplicationResult oApplicationResult)
        throws EElixirException
    {
        try
        {
            _oApplicationSL = getApplicationSL("ApplicationSLHome",
                    ApplicationSLHome.class);

            long lApplcSeqNbr = _oApplicationSL.createApplication(oApplicationResult);
            return lApplcSeqNbr;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    //-----------------------------------Himanshu---------------------------------------------------------
    
    
    public String searchvalidValue ()throws RemoteException, EJBException, EElixirException
    {
    	log.debug("CHMSLEJB:searchValidValue method");
    	 String strValidVal = "";

         try
         {
        	
             EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
             CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            
             _oBonusSLHome = (BonusSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
             "BonusSLHome"), BonusSLHome.class);
             _oBonusSL = _oBonusSLHome.create();
             strValidVal = _oBonusSL.searchvalidValue();
             log.debug("CHMSLEJB: INSIDE TRY3");
             return strValidVal;
         }
         catch (EJBException eex)
		   {
			  
			   throw eex;
	 }
         catch (CreateException ce)
         {
             throw new EElixirException(ce, "P1007");
         }
     }
    
//------------------------------------------------------------------------------------------
    public void updateApplication(ApplicationResult oApplicationResult)
        throws EElixirException
    {
        try
        {
            _oApplicationSL = getApplicationSL("ApplicationSLHome",
                    ApplicationSLHome.class);
            _oApplicationSL.updateApplication(oApplicationResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public ApplicationResult searchApplication(long a_lApplcSeqNbr,
        String a_strAgentCd, String a_strApplcntType) throws EElixirException
    {
        ApplicationResult oApplicationResult = null;

        try
        {
            _oApplicationSL = getApplicationSL("ApplicationSLHome",
                    ApplicationSLHome.class);
            oApplicationResult = _oApplicationSL.searchApplication(a_lApplcSeqNbr,
                    a_strAgentCd, a_strApplcntType);

            return oApplicationResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateApplicationStatusOnSubmit(
        ApplicationResult oApplicationResult) throws EElixirException
    {
        try
        {
            _oApplicationSL = getApplicationSL("ApplicationSLHome",
                    ApplicationSLHome.class);
            _oApplicationSL.updateApplicationStatusOnSubmit(oApplicationResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateApplicationStatusOnSubmitBackword(
        ApplicationResult oApplicationResult) throws EElixirException
    {
        try
        {
            _oApplicationSL = getApplicationSL("ApplicationSLHome",
                    ApplicationSLHome.class);
            _oApplicationSL.updateApplicationStatusOnSubmitBackword(oApplicationResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public AgentResult searchAgent(String a_strAgentCd)
        throws EElixirException
    {
        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
            AgentResult oAgentResult = _oAgentSL.searchAgent(a_strAgentCd);
            return oAgentResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public AgencyResult searchAgency(String a_strAgentCd)
        throws EElixirException
    {
        try
        {
            _oAgencySL = getAgencySL("AgencySLHome", AgencySLHome.class);

            AgencyResult oAgencyResult = _oAgencySL.searchAgency(a_strAgentCd);
            return oAgencyResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateAgent(AgentResult a_oAgentResult)
        throws EElixirException
    {
        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
            _oAgentSL.updateAgent(a_oAgentResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateAgency(AgencyResult a_oAgencyResult)
        throws EElixirException
    {
        try
        {
            _oAgencySL = getAgencySL("AgencySLHome", AgencySLHome.class);
            _oAgencySL.updateAgency(a_oAgencyResult);

        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public String approveApplication(ApplicationResult oApplicationResult)
        throws EElixirException
    {
        try
        {
            _oApplicationSL = getApplicationSL("ApplicationSLHome",
                    ApplicationSLHome.class);

            String strAgentCd = _oApplicationSL.approveApplication(oApplicationResult);


            return strAgentCd;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    private ApplicationSL getApplicationSL(String strHome, Class cHomeClass)
        throws RemoteException, CreateException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        ApplicationSLHome oApplicationSLHome = (ApplicationSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        ApplicationSL oApplicationSL = oApplicationSLHome.create();
        return oApplicationSL;
    }

    private AgentSL getAgentSL(String strHome, Class cHomeClass)
        throws RemoteException, CreateException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        AgentSLHome oAgentSLHome = (AgentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        AgentSL oAgentSL = oAgentSLHome.create();
        return oAgentSL;
    }

    private AgencySL getAgencySL(String strHome, Class cHomeClass)
        throws RemoteException, CreateException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        AgencySLHome oAgencySLHome = (AgencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        AgencySL oAgencySL = oAgencySLHome.create();
        return oAgencySL;
    }

    private DesignationSL getDesignationSL(String strHome, Class cHomeClass)
        throws RemoteException, CreateException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        DesignationSLHome oDesignationSLHome = (DesignationSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        DesignationSL oDesignationSL = oDesignationSLHome.create();
        return oDesignationSL;
    }

    public CompanyResult searchCompany()
        throws FinderException, EElixirException
    {
        CompanyResult oCompanyResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            oCompanyResult = _oMasterSL.searchCompany();

            return oCompanyResult;
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateCompany(CompanyResult oCompanyResult)
        throws EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.updateCompany(oCompanyResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    ///////////////////////////////////// CODE BY JIMMY END HERE ////////////////////////////
    // ************************************************************************************
    // *******************Module for Pallav Starts ********************************
    // ******************** MOdule Commission Starts************************************
    public ContractResult searchContract(long a_lCommAgrmtSeqNbr)
        throws FinderException, EElixirException
    {
        ContractResult oContractResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oContractSLHome = (ContractSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ContractSLHome"), ContractSLHome.class);

            _oContractSL = _oContractSLHome.create();
            oContractResult = _oContractSL.searchContract(a_lCommAgrmtSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to contract action class" +
            oContractResult);

        return oContractResult;
    }

    public void deleteContract(long a_lCommAgrmtSeqNbr,
        ContractResult a_oContractResult)
        throws RemoveException, FinderException, EElixirException
    {
        ContractResult oContractResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oContractSLHome = (ContractSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ContractSLHome"), ContractSLHome.class);
            _oContractSL = _oContractSLHome.create();
            _oContractSL.deleteContract(a_lCommAgrmtSeqNbr, a_oContractResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }

        catch (RemoveException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3022");
        }

        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

    }

    public ContractProdValidate getContractBaseUnit(
        ContractProdValidate a_oContractProdValidate)
        throws FinderException, EElixirException
    {
        // ContractProdValidate oContractProdValidate = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oContractSLHome = (ContractSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);

        try
        {
            _oContractSL = _oContractSLHome.create();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        try
        {
            a_oContractProdValidate = _oContractSL.getContractBaseUnit(a_oContractProdValidate);
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return a_oContractProdValidate;
    }

    public void updateCommissionContract(ContractResult a_oContractResult)
        throws EJBException, EElixirException
    {
        try
        {

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

            _oContractSLHome = (ContractSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ContractSLHome"), ContractSLHome.class);
            _oContractSL = _oContractSLHome.create();
            _oContractSL.updateCommission(a_oContractResult);
         
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public long createCommissionContract(ContractResult a_oContractResult)
        throws EJBException, EElixirException
    {
        //ContractResult contractResult = null;
        long seqNo = 0;

        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oContractSLHome = (ContractSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ContractSLHome"), ContractSLHome.class);
            _oContractSL = _oContractSLHome.create();
            seqNo = _oContractSL.createCommissionContract(a_oContractResult);
            return seqNo;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public String searchContract(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oContractSLHome = (ContractSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);
        try
        {
            _oContractSL = _oContractSLHome.create();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        try
        {
            resultString = _oContractSL.searchContract(a_oResultObject);
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return resultString;
    }

    // *****************************Commission ends here ********************
    // *****************************Copy Contract starts here **************
    public void copyContract(ContractCopyResult a_oContractCopyResult)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oContractSLHome = (ContractSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);

        try
        {
            _oContractSL = _oContractSLHome.create();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        try
        {
            _oContractSL.copyContract(a_oContractCopyResult);
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }

    // *******************************Copy Contract ends here **********************
    // ******************************Benefit starts here ***************************
    public BenefitResult searchBenefit(long a_lbenseqnbr)
        throws FinderException, EElixirException
    {
        BenefitResult oBenefitResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BenefitSLHome"), BenefitSLHome.class);
            _oBenefitSL = _oBenefitSLHome.create();
            oBenefitResult = _oBenefitSL.searchBenefit(a_lbenseqnbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return oBenefitResult;
    }

    public String searchBenefit(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);

        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            log.debug("CHMSLEJB--Inside try");
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        try
        {
            resultString = _oBenefitSL.searchBenefit(a_oResultObject);
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return resultString;
    }

    public long createBenefit(BenefitResult a_oBenefitResult)
        throws EJBException, EElixirException
    {
        //BenefitResult benefitResult = null;
        long seqNo = 0;

        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BenefitSLHome"), BenefitSLHome.class);
            _oBenefitSL = _oBenefitSLHome.create();
            seqNo = _oBenefitSL.createBenefit(a_oBenefitResult);

            return seqNo;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void updateBenefit(BenefitResult a_oBenefitResult)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BenefitSLHome"), BenefitSLHome.class);
            _oBenefitSL = _oBenefitSLHome.create();
            _oBenefitSL.updateBenefit(a_oBenefitResult);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void deleteBenefit(BenefitResult a_oBenefitResult)
        throws RemoveException, FinderException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BenefitSLHome"), BenefitSLHome.class);
            _oBenefitSL = _oBenefitSLHome.create();
            _oBenefitSL.deleteBenefit(a_oBenefitResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }

        catch (RemoveException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P9022");
        }

        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }

    // **************************Benefit ends here ****************************
    // **************************Master starts here for Channel ******************
    public ArrayList searchChannel() throws FinderException, EElixirException
    {
        ArrayList arrChannelResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            arrChannelResult = _oMasterSL.searchChannel();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return arrChannelResult;
    }

    public void updateChannel(ArrayList a_arrChannelResult)
        throws FinderException, EJBException, EElixirException
    {
        ArrayList arrChannelResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.updateChannel(a_arrChannelResult);
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }

    }

    public SubChannelResult searchSubChannel(Character a_cChannelType)
        throws FinderException, EJBException, EElixirException
    {
        SubChannelResult oSubChannelResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            oSubChannelResult = _oMasterSL.searchSubChannel(a_cChannelType);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
        return oSubChannelResult;
    }

    // *******************************Master ends here for Channel ****************
    // *******************************Formula starts here for Unit, Group and Formula ****************
    public UnitResultMain searchUnit(String a_strUnitId)
        throws FinderException, EElixirException
    {
        UnitResultMain oUnitResultMain = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);

            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            oUnitResultMain = _oFormulaEngineSL.searchUnit(a_strUnitId.trim()
                                                                      .toUpperCase());
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return oUnitResultMain;
    }

    public String searchUnit(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "FormulaEngineSLHome"), FormulaEngineSLHome.class);

        try
        {
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        try
        {
            resultString = _oFormulaEngineSL.searchUnit(a_oResultObject);
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return resultString;
    }

    public String createUnit(UnitResultMain oUnitResultMain)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            return _oFormulaEngineSL.createUnit(oUnitResultMain);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void updateUnit(UnitResultMain oUnitResultMain)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            _oFormulaEngineSL.updateUnit(oUnitResultMain);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public ArrayList searchGroup(String a_strGroupId)
        throws FinderException, EElixirException
    {
        ArrayList arrGroupResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);

            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            arrGroupResult = _oFormulaEngineSL.searchGroup(a_strGroupId.trim()
                                                                       .toUpperCase());
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return arrGroupResult;
    }

    public String searchGroup(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "FormulaEngineSLHome"), FormulaEngineSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            log.debug("CHMSLEJB--Inside try");
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        try
        {
            resultString = _oFormulaEngineSL.searchGroup(a_oResultObject);
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to unit action class");
        log.debug(resultString);

        return resultString;
    }

    public String createGroup(ArrayList a_arrGroup)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--In create Unit of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();

            String s = _oFormulaEngineSL.createGroup(a_arrGroup);
            log.debug("CHMSLEJB--out of create Group of CHMSLEJB");

            return s;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void updateGroup(ArrayList a_arrGroup)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--In create Unit of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            _oFormulaEngineSL.updateGroup(a_arrGroup);
            log.debug("CHMSLEJB--out of create Group of CHMSLEJB");
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public FormulaResult searchFormula(long a_lFormlDefnSeqNbr)
        throws FinderException, EElixirException
    {
        FormulaResult oFormulaResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);

            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            oFormulaResult = _oFormulaEngineSL.searchFormula(a_lFormlDefnSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to group action class" +
            oFormulaResult);

        return oFormulaResult;
    }

    public String searchFormula(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "FormulaEngineSLHome"), FormulaEngineSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            log.debug("CHMSLEJB--Inside try");
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        try
        {
            resultString = _oFormulaEngineSL.searchFormula(a_oResultObject);
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to unit action class");
        log.debug(resultString);

        return resultString;
    }

    public long createFormula(FormulaResult a_oFormulaResult)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--In create Unit of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();

            long seqNo = _oFormulaEngineSL.createFormula(a_oFormulaResult);
            log.debug("CHMSLEJB--out of create Formula of CHMSLEJB");

            return seqNo;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void updateFormula(FormulaResult a_oFormulaResult)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--In create Unit of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oFormulaEngineSLHome = (FormulaEngineSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "FormulaEngineSLHome"), FormulaEngineSLHome.class);
            _oFormulaEngineSL = _oFormulaEngineSLHome.create();
            _oFormulaEngineSL.updateFormula(a_oFormulaResult);
            log.debug("CHMSLEJB--out of create Formula of CHMSLEJB");
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException fex)
        {
            log.exception(fex.getMessage());
            throw new EElixirException(fex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    // *****************************formula ends here****************************
    // *****************************Contest starts here****************************
    public String searchContest(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        String resultString = null;

        try
        {
            _oContestSL = getContestSL("ContestSLHome", ContestSLHome.class);
            log.debug("CHMSLEJB--After Lookup");
            resultString = _oContestSL.searchContest(a_oResultObject);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to Contest action class");
        log.debug(resultString);

        return resultString;
    }

    public ContestResult searchContest(long a_lcontestseqnbr)
        throws FinderException, EElixirException
    {
        ContestResult oContestResult = null;

        try
        {
            _oContestSL = getContestSL("ContestSLHome", ContestSLHome.class);
            log.debug("CHMSLEJB--Inside try");
            oContestResult = _oContestSL.searchContest(a_lcontestseqnbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to contest action class" +
            oContestResult);

        return oContestResult;
    }

    public long createContest(ContestResult a_oContestResult)
        throws EJBException, EElixirException
    {
        long seqNo = 0;

        try
        {
            _oContestSL = getContestSL("ContestSLHome", ContestSLHome.class);
            seqNo = _oContestSL.createContest(a_oContestResult);
            log.debug("CHMSLEJB--out of create Benefit of CHMSLEJB");

            return seqNo;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void updateContest(ContestResult a_oContestResult)
        throws EJBException, EElixirException
    {
        try
        {
            _oContestSL = getContestSL("ContestSLHome", ContestSLHome.class);
            _oContestSL.updateContest(a_oContestResult);
            log.debug("CHMSLEJB--out of create Benefit of CHMSLEJB");

            //return seqNo;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void deleteContest(ContestResult a_oContestResult)
        throws RemoveException, FinderException, EElixirException
    {
        try
        {
            _oContestSL = getContestSL("ContestSLHome", ContestSLHome.class);
            log.debug("CHMSLEJB--Inside try");
            _oContestSL.deleteContest(a_oContestResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }

        catch (RemoveException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P9513");
        }

        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to Contest action class");
    }

    //
    private ContestSL getContestSL(String strHome, Class cHomeClass)
        throws RemoteException, CreateException, EElixirException
    {
        log.debug("CHMSLEJB--Looking for ContestSLHome");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB--Looking for ContestSLHome");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--Looking for ContestSLHome");

        ContestSLHome oContestSLHome = (ContestSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        ContestSL oContestSL = oContestSLHome.create();
        log.debug("CHMSLEJB--ContestSLHome Created");

        return oContestSL;
    }

    // *****************************Contest ends here****************************
    // *****************************MovementCriteria starts here****************************
    public String searchMovementCriteria(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        String strResultString = null;

        try
        {
            _oMovementCriteriaSL = getMovementCriteriaSL("MovementCriteriaSLHome",
                    MovementCriteriaSLHome.class);
            log.debug("CHMSLEJB--After Lookup");
            strResultString = _oMovementCriteriaSL.searchMovementCriteria(a_oResultObject);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to MovementCriteria action class");
        log.debug(strResultString);

        return strResultString;
    }

    public MovementCriteriaResult searchMovementCriteria(long a_lmovmnseqnbr)
        throws FinderException, EElixirException
    {
        MovementCriteriaResult oMovementCriteriaResult = null;

        try
        {
            _oMovementCriteriaSL = getMovementCriteriaSL("MovementCriteriaSLHome",
                    MovementCriteriaSLHome.class);
            log.debug("CHMSLEJB--Inside try");
            oMovementCriteriaResult = _oMovementCriteriaSL.searchMovementCriteria(a_lmovmnseqnbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug("CHMSLEJB--returning back to MovementCriteria action class" +
            oMovementCriteriaResult);

        return oMovementCriteriaResult;
    }

    public long createMovementCriteria(
        MovementCriteriaResult a_oMovementCriteriaResult)
        throws EJBException, EElixirException
    {
        long seqNo = 0;

        try
        {
            _oMovementCriteriaSL = getMovementCriteriaSL("MovementCriteriaSLHome",
                    MovementCriteriaSLHome.class);
            seqNo = _oMovementCriteriaSL.createMovementCriteria(a_oMovementCriteriaResult);
            log.debug("CHMSLEJB--out of create MovementCriteria of CHMSLEJB");

            return seqNo;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void updateMovementCriteria(
        MovementCriteriaResult a_oMovementCriteriaResult)
        throws EJBException, EElixirException
    {
        try
        {
            _oMovementCriteriaSL = getMovementCriteriaSL("MovementCriteriaSLHome",
                    MovementCriteriaSLHome.class);
            _oMovementCriteriaSL.updateMovementCriteria(a_oMovementCriteriaResult);
            log.debug("CHMSLEJB--out of update MovementCriteria of CHMSLEJB");

            //return seqNo;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    //
    private MovementCriteriaSL getMovementCriteriaSL(String strHome,
        Class cHomeClass)
        throws RemoteException, CreateException, EElixirException
    {
        log.debug("CHMSLEJB--Looking for MovementCriteriaSLHome");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB--Looking for MovementCriteriaSLHome");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--Looking for MovementCriteriaSLHome");

        MovementCriteriaSLHome oMovementCriteriaSLHome = (MovementCriteriaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        MovementCriteriaSL oMovementCriteriaSL = oMovementCriteriaSLHome.create();
        log.debug("CHMSLEJB--MovementCriteriaSLHome Created");

        return oMovementCriteriaSL;
    }

    // *****************************MovementCriteria ends here****************************
    //  *****************************Module for Pallav ends here****************************
    //  *****************************Module for Vinay stratshere****************************
    //Code starts by Vinay
    public String searchContract() throws FinderException, EElixirException
    {
        String strResult = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");

        _oContractSLHome = (ContractSLHome) objEJBHomeFactoryLocal.lookUpHome("com.mastek.eElixir.channelmanagement.commission.ejb.sessionbean.ContractSLHome",
                ContractSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oContractSL = _oContractSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            strResult = _oContractSL.searchContract();
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex.getMessage());
        }

        log.debug("CHMSLEJB--returning back to Contracts action class");
        log.debug(strResult);

        return strResult;
    }

    public long createContractMap(ArrayList al_ContractMapResult)
        throws CreateException, EElixirException
    {
        //Collection resultCollection = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oContractSLHome = (ContractSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oContractSL = _oContractSLHome.create();
            log.debug("CHMSLEJB--Inside try");

            return _oContractSL.createContractMap(al_ContractMapResult);
        }

        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }
    }

    public void updateContractMap(ArrayList al_oContractMapResult)
        throws CreateException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oContractSLHome = (ContractSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ContractSLHome"), ContractSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oContractSL = _oContractSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oContractSL.updateContractMap(al_oContractMapResult);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }
    }

    public ArrayList searchContractMap(long a_LContMapSeqNbr)
        throws FinderException, EElixirException
    {
        ArrayList al_resultObject = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oContractSLHome = (ContractSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oContractSL = _oContractSLHome.create();
            log.debug("CHMSLEJB--Inside try");

            al_resultObject = _oContractSL.searchContractMap(a_LContMapSeqNbr);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to ContractMap action class" +
            al_resultObject);

        return al_resultObject;
    }

    public ArrayList searchAgencyDoc(String a_searchAgencyDoc)
        throws FinderException, EElixirException
    {
        ArrayList resultObject = new ArrayList();
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oAgencyDocSLHome = (AgencyDocSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "AgencyDocSLHome"), AgencyDocSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oAgencyDocSL = _oAgencyDocSLHome.create();
            log.debug("CHMSLEJB--Inside try");

            resultObject = _oAgencyDocSL.searchAgencyDoc(a_searchAgencyDoc);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    //Code for persistency
    public String searchPersistency(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        String strResult = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oPersistencySLHome = (PersistencySLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PersistencySLHome"), PersistencySLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oPersistencySL = _oPersistencySLHome.create();
            log.debug("CHMSLEJB--Inside try");
            strResult = _oPersistencySL.searchPersistency(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }

        return strResult;
    }

    public void createPersistency(PersistencyResult a_oPersistencyResult)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oPersistencySLHome = (PersistencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PersistencySLHome"), PersistencySLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oPersistencySL = _oPersistencySLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oPersistencySL.createPersistency(a_oPersistencyResult);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to Persistency action class");
    }

    public void updatePersistency(PersistencyResult a_oPersistencyResult)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oPersistencySLHome = (PersistencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PersistencySLHome"), PersistencySLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oPersistencySL = _oPersistencySLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oPersistencySL.updatePersistency(a_oPersistencyResult);
        }
        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to Persistency action class");
    }

    public PersistencyResult searchPersistency(String a_strPerstType)
        throws FinderException, EElixirException
    {
        PersistencyResult strResult = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oPersistencySLHome = (PersistencySLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PersistencySLHome"), PersistencySLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oPersistencySL = _oPersistencySLHome.create();
            log.debug("CHMSLEJB--Inside try");
            strResult = _oPersistencySL.searchPersistency(a_strPerstType);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }

        return strResult;
    }

    //code for subchannel
    public ArrayList searchSubChannel(String a_cChannelType)
        throws FinderException, EElixirException
    {
        ArrayList _oSubChannelList = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oSubChannelList = _oMasterSL.searchSubChannel(a_cChannelType);
        }
        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        return _oSubChannelList;
    }

    public void updateSubChannel(ArrayList a_oSubChannelList)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oMasterSL.updateSubChannel(a_oSubChannelList);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to SubChannel action class");
    }

    //code for UserParameter
    public ArrayList searchUserParameter(int a_iParamTypeCd)
        throws FinderException, EElixirException
    {
        ArrayList _oUserParameterList = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oUserParameterList = _oMasterSL.searchUserParameter(a_iParamTypeCd);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        return _oUserParameterList;
    }

    public void updateUserParameter(ArrayList a_oUserParameterList)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oMasterSL.updateUserParameter(a_oUserParameterList);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to userParameter action class");
    }

    //code for selfContract
    public ArrayList searchSelfContract(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        ArrayList _oSelfContractList = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oContractSLHome = (ContractSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oContractSL = _oContractSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oSelfContractList = _oContractSL.searchSelfContract(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        return _oSelfContractList;
    }

    public void updateSelfContract(ArrayList a_oSelfContractList)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oContractSLHome = (ContractSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oContractSL = _oContractSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oContractSL.updateSelfContract(a_oSelfContractList);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to SelfContract action class");
    }

    //code for Clawback
    public ArrayList searchClawback(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        ArrayList _oClawbackList = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oContractSLHome = (ContractSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oContractSL = _oContractSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oClawbackList = _oContractSL.searchClawback(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        return _oClawbackList;
    }

    public void updateClawback(ArrayList a_oClawbackList)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oContractSLHome = (ContractSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ContractSLHome"), ContractSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oContractSL = _oContractSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oContractSL.updateClawback(a_oClawbackList);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to Clawback action class");
    }

    //Code ends by Vinay
    //  *****************************Module forvinay ends here****************************
    public void createApproval(ApprovalResult a_ApprovalResult)
        throws FinderException, EElixirException
    {
        try
        {
            log.debug("CHMSLEJB--In create Adjustment of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oApprovalSLHome = (ApprovalSLHome) objEJBHomeFactory.lookUpHome(_oCHMPropertyUtil.getCHMProperty(
                        "ApprovalSLHome"), ApprovalSLHome.class);
            _oApprovalSL = _oApprovalSLHome.create();
            _oApprovalSL.createApproval(a_ApprovalResult);
            log.debug("CHMSLEJB--out of create Adjustment of CHMSLEJB");
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P6007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }
    //Rajeev_ManualOverride_CR_01122010 Start
    public void manualoverrideApproval(ApprovalResult a_ApprovalResult)
    throws FinderException, EElixirException
    {
    try
    {
        log.debug("CHMSLEJB--In create Adjustment of CHMSLEJB");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oApprovalSLHome = (ApprovalSLHome) objEJBHomeFactory.lookUpHome(_oCHMPropertyUtil.getCHMProperty(
                    "ApprovalSLHome"), ApprovalSLHome.class);
        _oApprovalSL = _oApprovalSLHome.create();
        _oApprovalSL.manualoverrideApproval(a_ApprovalResult);
        log.debug("CHMSLEJB--out of create Adjustment of CHMSLEJB");
    }
    catch (CreateException cex)
    {
        throw new EElixirException(cex, "P6007");
    }
    catch (RemoteException rex)
    {
        throw new EElixirException(rex, "P1006");
    }
    catch (EElixirException eex)
    {
        throw eex;
    }
 }
  //Rajeev_ManualOverride_CR_01122010 End

    public String searchApproval(SearchData o_SearchData)
        throws FinderException, EElixirException
    {
        String strResult = null;

        try
        {
            log.debug("CHMSLEJB--APPROVAL CHMSL EJB -------");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB--1-------" + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--2 -------" + oCHMPropertyUtil);
            _oApprovalSLHome = (ApprovalSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ApprovalSLHome"), ApprovalSLHome.class);
            log.debug("CHMSLEJB--3 -------" + _oApprovalSLHome);
            log.debug("CHMSLEJB--After Lookup");
            _oApprovalSL = _oApprovalSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            strResult = _oApprovalSL.searchApproval(o_SearchData);
            log.debug("CHMSLEJB--After search Approval in CHMSLEJB ----------");
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P6007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }

        return strResult;
    }

    ///////////////////////////////////////////code added by Prasad for Designation,Reporting Links,Location  module////////////////////
    ////////////////////////////////////////CREATE METHODS//////////////////////////////////////////
    public void createDesignation(DesignationResult a_oDesignationResult)
        throws EJBException, EElixirException
    {
        try
        {
            log.debug("CHMSLEJB--Debug 1CHMSL");

            String strResult = null;
            EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oDesignationSLHome = (DesignationSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "DesignationSLHome"), DesignationSLHome.class);

            log.debug("CHMSLEJB--Insde CHMSLEJB Home ref " +
                _oDesignationSLHome);
            _oDesignationSL = _oDesignationSLHome.create();
            log.debug("CHMSLEJB--Insde CHMSLEJB Local ref " + _oDesignationSL);
            _oDesignationSL.createDesignation(a_oDesignationResult);
        }
        catch (CreateException cex)
        {
            throw new EElixirException("P8052");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException("P8052");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw eex;
        }
    }

    public void createReportingStructure(
        RepHierarchyResult a_oRepHeirarchyResult)
        throws EElixirException, FinderException
    {
        try
        {
            log.debug("CHMSLEJB--Debug 1CHMSL");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB--Debug 2CHMSL");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--Debug 3CHMSL");
            _oReportingStructureSLHome = (ReportingStructureSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ReportingStructureSLHome"),
                    ReportingStructureSLHome.class);

            _oReportingStructureSL = _oReportingStructureSLHome.create();
            _oReportingStructureSL.createReportingStructure(a_oRepHeirarchyResult);
        }
        catch (CreateException cex)
        {
            throw new EElixirException("P8052");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException("P8052");
        }
        catch (EElixirException eex)
        {
            log.exception(eex.getMessage());
            throw eex;
        }
    }

    ////////////////////////////////////END CREATE METHODS/////////////////////////////////////////////
    ////////////////////////////////////UPDATE METHODS START/////////////////////////////////////////////////
    public void updateDesignation(DesignationResult a_oDesignationResult)
        throws EElixirException
    {
        //DesignationResult resultDesignation = null;
        try
        {
            log.debug(
                "CHMSLEJB--######### IN CHMSL EJB UPDATE DESIGNATION METHOD######" +
                a_oDesignationResult.getDesgnDesc());

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

            _oDesignationSLHome = (DesignationSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "DesignationSLHome"), DesignationSLHome.class);
            _oDesignationSL = _oDesignationSLHome.create();
            _oDesignationSL.updateDesignation(a_oDesignationResult);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }
    }

    /*
     * Invoked by the session bean to look up the ReportingStructureSLEJB
     * @param RepHierarchyResult
     * @throws FinderException
     * @throws EElixirException
     */
    public void updateReportingStructure(
        RepHierarchyResult a_oRepHeirarchyResult)
        throws EElixirException, FinderException
    {
        log.debug("CHMSLEJB--Starting the updateReportingStructure method");

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oReportingStructureSLHome = (ReportingStructureSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ReportingStructureSLHome"),
                    ReportingStructureSLHome.class);
            _oReportingStructureSL = _oReportingStructureSLHome.create();
            _oReportingStructureSL.updateReportingStructure(a_oRepHeirarchyResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P8934");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P8935");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }

        log.debug("CHMSLEJB--Ending the updateReportingStructure method");
    }

    /////////////////////////////////SEARCH METHODS////////////////////////////////////////////////
    public String searchDesignation(SearchData oSearchData)
        throws EElixirException
    {
        String resultString = null;
        log.debug("CHMSLEJB--INSIDE CHSMLEJB's searchDesignation*****\n");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oDesignationSLHome = (DesignationSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "DesignationSLHome"), DesignationSLHome.class);
        log.debug("CHMSLEJB--after lookup for DesignationSLHome");

        try
        {
            log.debug("CHMSLEJB--before create of DesignationSL");
            _oDesignationSL = _oDesignationSLHome.create();
            log.debug("CHMSLEJB--after create of DesignationSL");
            resultString = _oDesignationSL.searchDesignation(oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }

        return resultString;
    }

    public DesignationResult searchDesignationCode(String strChannelType)
        throws EElixirException, FinderException
    {
        log.debug("CHMSLEJB--Starting the searchDesignationCode method");

        DesignationResult oDesignationResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oDesignationSLHome = (DesignationSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "DesignationSLHome"), DesignationSLHome.class);
            _oDesignationSL = _oDesignationSLHome.create();
            oDesignationResult = _oDesignationSL.searchDesignationCode(strChannelType);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        return oDesignationResult;
    }

    public DesignationResult searchDesignation(String a_strDesgnCd)
        throws EElixirException, FinderException, EJBException
    {
        DesignationResult oDesignationResult = null;
        log.debug("CHMSLEJB--Inside CHMSLEJB");

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oDesignationSLHome = (DesignationSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "DesignationSLHome"), DesignationSLHome.class);
            _oDesignationSL = _oDesignationSLHome.create();
            log.debug("CHMSLEJB--SL Home " + _oDesignationSL);
            oDesignationResult = _oDesignationSL.searchDesignation(a_strDesgnCd);

            return oDesignationResult;
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }
    }

    public RepHierarchyResult searchReportingStructure(String a_strRepLinkCode)
        throws EElixirException, FinderException
    {
        RepHierarchyResult oRepHierarchyResult = null;
        log.debug("CHMSLEJB--Inside CHMSLEJB");

        try
        {
            log.debug(
                "CHMSLEJB--\nInside the searchReportingStructure(RHS CODE) method of CHSMLEJB****** " +
                a_strRepLinkCode);

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oReportingStructureSLHome = (ReportingStructureSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ReportingStructureSLHome"),
                    ReportingStructureSLHome.class);
            _oReportingStructureSL = _oReportingStructureSLHome.create();
            log.debug("CHMSLEJB--\n _oReportingStructureSL " +
                _oReportingStructureSL);
            oRepHierarchyResult = _oReportingStructureSL.searchReportingStructure(a_strRepLinkCode);

            return oRepHierarchyResult;
        }
        catch (CreateException cex)
        {
            throw new EElixirException("P8600");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException("P8600");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    /*
     * Invoked by the session bean to look up the ReportingStructureSLEJB
     * @param SearchData
     * @throws FinderException
     * @throws EElixirException
     */
    public String searchReportingStructure(SearchData a_oSearchData)
        throws EElixirException, FinderException
    {
        String strResultData = null;

        try
        {
            log.debug(
                "CHMSLEJB--\nInside the searchReportingStructure method of CHSMLEJB****** ");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB--objEJBHomeFactory ----" + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--oCHMPropertyUtil::: " + oCHMPropertyUtil);
            _oReportingStructureSLHome = (ReportingStructureSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ReportingStructureSLHome"),
                    ReportingStructureSLHome.class);
            log.debug("CHMSLEJB--_oReportingStructureSLHome : " +
                _oReportingStructureSLHome);
            _oReportingStructureSL = _oReportingStructureSLHome.create();
            log.debug("CHMSLEJB--_oReportingStructureSL : " +
                _oReportingStructureSL);
            strResultData = _oReportingStructureSL.searchReportingStructure(a_oSearchData);
        }
        catch (CreateException cex)
        {
            throw new EElixirException("P8600");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException("P8600");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }

        return strResultData;
    }

    /////////////////////////////////END SEARCH METHODS////////////////////////////////////////////////
    public void updatePaymentWithHold(ArrayList alPaymentWithHoldResult)
        throws EElixirException, CreateException
    {
        log.debug(
            "\nInside the UpdatePaymentWithHold method of CHSMLEJB****** ");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("objEJBHomeFactory ----" + objEJBHomeFactory);

        CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("_oCHMPropertyUtil::: " + _oCHMPropertyUtil);
        oPaymentWithHoldSLHome = (PaymentWithHoldSLHome) objEJBHomeFactory.lookUpHome(_oCHMPropertyUtil.getCHMProperty(
                    "PaymentWithHoldSLHome"), PaymentWithHoldSLHome.class);
        log.debug("oPaymentWithHoldSLHome : " + oPaymentWithHoldSLHome);

        try
        {
            oPaymentWithHoldSL = oPaymentWithHoldSLHome.create();
            oPaymentWithHoldSL.updatePaymentWithHold(alPaymentWithHoldResult);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }
    }

    public ArrayList searchPaymentWithHold(SearchData oSearchData)
        throws EElixirException, FinderException
    {
        ArrayList alResultObject = new ArrayList();
        log.debug(
            "\nInside the SearchPaymentWithHold method of CHSMLEJB****** ");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("objEJBHomeFactory ----" + objEJBHomeFactory);

        CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("_oCHMPropertyUtil::: " + _oCHMPropertyUtil);
        oPaymentWithHoldSLHome = (PaymentWithHoldSLHome) objEJBHomeFactory.lookUpHome(_oCHMPropertyUtil.getCHMProperty(
                    "PaymentWithHoldSLHome"), PaymentWithHoldSLHome.class);
        log.debug("oPaymentWithHoldSLHome : " + oPaymentWithHoldSLHome);

        try
        {
            oPaymentWithHoldSL = oPaymentWithHoldSLHome.create();
            alResultObject = oPaymentWithHoldSL.searchPaymentWithHold(oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CreateException ");
            throw new EElixirException(cex, "P8075");
        }
        catch (RemoteException cex)
        {
            log.debug("RemoteeException ");
            throw new EElixirException(cex, "P8075");
        }

        return alResultObject;
    }

    ///////////////////////////////////////////code ends by Prasad for Designation And Reporting Links module////////////////////
    //*******************************Vinaysheel's code starts here****************************
    public SuspendResult searchSuspend(Long a_oLAgntSuspnSeqNbr)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----searchSuspend----In searchSuspend");

        SuspendResult resultObject = null;
        log.debug("CHMSLEJB----searchSuspend----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----searchSuspend----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchSuspend----before Lookup");
        _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MovementSLHome"), MovementSLHome.class);
        log.debug("CHMSLEJB----searchSuspend----After Lookup");

        try
        {
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB----searchSuspend----Inside try");

            resultObject = _oMovementSL.searchSuspend(a_oLAgntSuspnSeqNbr);
        }
        catch (CreateException rex)
        {
            log.debug("CHMSLEJB--SuspendSEarch--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3504");
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--SuspendSEarch--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3504");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--SuspendSEarch--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    public long createSuspend(SuspendResult a_oSuspendResult)
        throws EJBException, EElixirException
    {
        log.debug("CHMSLEJB--createSuspend()");

        try
        {
            log.debug("CHMSLEJB--createSuspend()--in try");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--createSuspend()--after getting propertyutil");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB--createSuspend()--after getting factory");
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB--createSuspend()--after getting home");
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB--createSuspend()--after getting remote");

            long _lAgntSuspnSeqNbr = _oMovementSL.createSuspend(a_oSuspendResult);
            log.debug(
                "CHMSLEJB--createSuspend()--out of create Formula of CHMSLEJB" +
                _lAgntSuspnSeqNbr);

            return _lAgntSuspnSeqNbr;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB-createSuspend()-inside create exception");
            throw new EElixirException(cex, "P3503");
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB-createSuspend()-inside Remoteexception");
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3503");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB-createSuspend()-inside ejb exception");
            throw new EElixirException(ejbex, "P3503");
        }
    }

    public void updateSuspend(SuspendResult a_oSuspendResult)
        throws EJBException, EElixirException
    {
        log.debug("CHMSLEJB--updateSuspend()");

        try
        {
            log.debug("CHMSLEJB--updateSuspend()--in try");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug(
                "CHMSLEJB--updateSuspend()--after getting oCHMPropertyUtil ");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug(
                "CHMSLEJB--updateSuspend()--after getting objEJBHomeFactory ");
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug(
                "CHMSLEJB--updateSuspend()--after getting _oMovementSLHome ");
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB--updateSuspend()--after getting _oMovementSL ");
            _oMovementSL.updateSuspend(a_oSuspendResult);
            log.debug("CHMSLEJB--updateSuspend()--going out CHMSLEJB");
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--updateSuspend()---inside create exception");
            throw new EElixirException(cex, "P3505");
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--updateSuspend()---inside remote exception");
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3505");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--updateSuspend()---inside ejb exception");
            throw new EElixirException(ejbex, "P3505");
        }
    }

    public SuspendResult searchPastSuspensions(String a_strAgentCd)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----searchPastSuspensions----In searchSuspend");

        SuspendResult resultObject = null;
        log.debug("CHMSLEJB----searchPastSuspensions----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----searchPastSuspensions----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchPastSuspensions----before Lookup");
        _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MovementSLHome"), MovementSLHome.class);
        log.debug("CHMSLEJB----searchPastSuspensions----After Lookup");

        try
        {
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB----searchPastSuspensions----Inside try");

            resultObject = _oMovementSL.searchPastSuspensions(a_strAgentCd);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchPastSuspensions--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3507");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchPastSuspensions--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3507");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchPastSuspensions--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }
//Added by Amid for Pagination 
    //*******************************Vinaysheel's code ends here****************************
    ///	Code for Suspension Search by Sandeep Bangera///////////////
    public SearchData searchSuspend(SearchData a_oSearchData)
        throws EElixirException, FinderException
    {
      
        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB _oMovementSLHome : " + _oMovementSLHome);
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB _oMovementSL : " + _oMovementSL);
            a_oSearchData = _oMovementSL.searchSuspend(a_oSearchData);
            log.debug("CHMSLEJB -- After serach result ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }

        return a_oSearchData;
    }

    ///***************Code for Policy Transfer starts**********************
    public String searchPolicyTransfer(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        String resultString = null;
        log.debug("CHMSLEJB--INSIDE CHSMLEJB's searchPolicyTransfer*****\n");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oPolicyTransferSLHome = (PolicyTransferSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PolicyTransferSLHome"), PolicyTransferSLHome.class);
        log.debug("CHMSLEJB--after lookup for PolicyTransferSLHome");

        try
        {
            log.debug("CHMSLEJB--before create of PolicyTransferSL");
            _oPolicyTransferSL = _oPolicyTransferSLHome.create();
            log.debug("CHMSLEJB--after create of PolicyTransferSL");

            resultString = _oPolicyTransferSL.searchPolicyTransfer(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }

        return resultString;
    }

    public PolicyTransferResult searchPolicyTransferEntry(long a_lpolhdrseqnbr)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----searchPolicyTransferEntry----In searchSuspend");

        PolicyTransferResult resultObject = null;
        log.debug("CHMSLEJB----searchPolicyTransferEntry----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug(
            "CHMSLEJB----searchPolicyTransferEntry----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchPolicyTransferEntry----before Lookup");
        _oPolicyTransferSLHome = (PolicyTransferSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PolicyTransferSLHome"), PolicyTransferSLHome.class);
        log.debug("CHMSLEJB----searchPolicyTransferEntry----After Lookup");

        try
        {
            _oPolicyTransferSL = _oPolicyTransferSLHome.create();
            log.debug("CHMSLEJB----searchPolicyTransferEntry----Inside try");

            resultObject = _oPolicyTransferSL.searchPolicyTransferEntry(a_lpolhdrseqnbr);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchPolicyTransferEntry--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3504");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchPolicyTransferEntry--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3504");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchPolicyTransferEntry--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    public long createPolicyTransferEntry(
        PolicyTransferResult a_oPolicyTransferResult,
        ArrayList alPolicyTransferDetailResult) throws EElixirException
    {
        log.debug("CHMSLEJB--createPolicyTransferEntry()");

        try
        {
            log.debug("CHMSLEJB--createPolicyTransferEntry()--in try");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug(
                "CHMSLEJB--createPolicyTransferEntry()--after getting propertyutil");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug(
                "CHMSLEJB--createPolicyTransferEntry()--after getting factory");
            _oPolicyTransferSLHome = (PolicyTransferSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "PolicyTransferSLHome"), PolicyTransferSLHome.class);
            log.debug(
                "CHMSLEJB--createPolicyTransferEntry()--after getting home");
            _oPolicyTransferSL = _oPolicyTransferSLHome.create();
            log.debug(
                "CHMSLEJB--createPolicyTransferEntry()--after getting remote");

            long _lpolhdrseqnbr = _oPolicyTransferSL.createPolicyTransferEntry(a_oPolicyTransferResult,
                    alPolicyTransferDetailResult);
            log.debug(
                "CHMSLEJB--createPolicyTransferEntry()--out of create Formula of CHMSLEJB" +
                _lpolhdrseqnbr);

            return _lpolhdrseqnbr;
        }
        catch (CreateException cex)
        {
            log.debug(
                "CHMSLEJB-createPolicyTransferEntry()-inside create exception");
            throw new EElixirException(cex, "P3503");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB-createPolicyTransferEntry()-inside Remoteexception");
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3503");
        }
        catch (EJBException ejbex)
        {
            log.debug(
                "CHMSLEJB-createPolicyTransferEntry()-inside ejb exception");
            throw new EElixirException(ejbex, "P3503");
        }
    }

    public void updatePolicyTransfer(
        PolicyTransferResult a_oPolicyTransferResult,
        ArrayList alPolicyTransferDetailResult)
        throws EJBException, EElixirException
    {
        log.debug("CHMSLEJB--updatePolicyTransfer()");

        try
        {
            log.debug("CHMSLEJB--updatePolicyTransfer()--in try");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug(
                "CHMSLEJB--updatePolicyTransfer()--after getting oCHMPropertyUtil ");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug(
                "CHMSLEJB--updatePolicyTransfer()--after getting objEJBHomeFactory ");
            _oPolicyTransferSLHome = (PolicyTransferSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "PolicyTransferSLHome"), PolicyTransferSLHome.class);
            log.debug(
                "CHMSLEJB--updatePolicyTransfer()--after getting _oPolicyTransferSLHome ");
            _oPolicyTransferSL = _oPolicyTransferSLHome.create();
            log.debug(
                "CHMSLEJB--updatePolicyTransfer()--after getting _oPolicyTransferSL ");
            _oPolicyTransferSL.updatePolicyTransferEntry(a_oPolicyTransferResult,
                alPolicyTransferDetailResult);
            log.debug("CHMSLEJB--updatePolicyTransfer()--going out CHMSLEJB");
        }
        catch (CreateException cex)
        {
            log.debug(
                "CHMSLEJB--updatePolicyTransfer()---inside create exception");
            throw new EElixirException(cex, "P3505");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--updatePolicyTransfer()---inside remote exception");
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3505");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--updatePolicyTransfer()---inside ejb exception");
            throw new EElixirException(ejbex, "P3505");
        }
    }

    public ArrayList searchPolicyTransferDetailEntry(Long a_lpolhdrseqnbr,
        String a_strAgentCd, Short _nPolTrfType)
        throws FinderException, EElixirException
    {
        log.debug(
            "CHMSLEJB----searchPolicyTransferDetailEntry----In searchPolicyTransferDetailEntry");

        ArrayList resultObject = new ArrayList();
        log.debug(
            "CHMSLEJB----searchPolicyTransferDetailEntry----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug(
            "CHMSLEJB----searchPolicyTransferDetailEntry----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug(
            "CHMSLEJB----searchPolicyTransferDetailEntry----before Lookup");
        _oPolicyTransferSLHome = (PolicyTransferSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PolicyTransferSLHome"), PolicyTransferSLHome.class);
        log.debug("CHMSLEJB----searchPolicyTransferDetailEntry----After Lookup");

        try
        {
            _oPolicyTransferSL = _oPolicyTransferSLHome.create();
            log.debug(
                "CHMSLEJB----searchPolicyTransferDetailEntry----Inside try");

            resultObject = _oPolicyTransferSL.searchPolicyTransferDetailEntry(a_lpolhdrseqnbr,
                    a_strAgentCd, _nPolTrfType);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchPolicyTransferDetailEntry--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3518");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchPolicyTransferDetailEntry--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3518");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchPolicyTransferDetailEntry--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    public PolicyTransferResult searchSupervisor(String a_strAgentCd)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----searchSupervisor----In searchSupervisor");

        PolicyTransferResult resultObject = null;
        log.debug("CHMSLEJB----searchSupervisor----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----searchSupervisor----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchSupervisor----before Lookup");
        _oPolicyTransferSLHome = (PolicyTransferSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PolicyTransferSLHome"), PolicyTransferSLHome.class);
        log.debug("CHMSLEJB----searchSupervisor----After Lookup");

        try
        {
            _oPolicyTransferSL = _oPolicyTransferSLHome.create();
            log.debug("CHMSLEJB----searchSupervisor----Inside try");

            resultObject = _oPolicyTransferSL.searchSupervisor(a_strAgentCd);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchSupervisor--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3520");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchSupervisor--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3520");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchSupervisor--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    //***********************Code for Policy Transfer ends**************
    public String searchBlackList(SearchData a_oSearchData)
        throws EElixirException, FinderException
    {
        String strResultData = null;

        try
        {
            log.debug(
                "CHMSLEJB--\nInside the searchBlackiList method of CHSMLEJB****** ");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB--objEJBHomeFactory ----" + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--oCHMPropertyUtil::: " + oCHMPropertyUtil);
            _oBlackListSLHome = (BlackListSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BlackListSLHome"), BlackListSLHome.class);
            log.debug("CHMSLEJB--_oBlackListSLHome : " + _oBlackListSLHome);
            _oBlackListSL = _oBlackListSLHome.create();
            log.debug("CHMSLEJB--_oBlackListSL : " + _oBlackListSL);
            strResultData = _oBlackListSL.searchBlackList(a_oSearchData);

            return strResultData;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    ///////////////////////////////////// CODE BY JIMMY START HERE ////////////////////////////
    //This Method is Used to Create an BlackListed Agent Entry in The System
    public long createBlackList(BlackListResult oBlackListResult)
        throws EElixirException
    {
        try
        {
            log.debug("CHMSLEJB--In create BlackList of CHMSLEJB");
            _oBlackListSL = getBlackListSL("BlackListSLHome",
                    BlackListSLHome.class);

            long lLiaBlackListSeqNbr = _oBlackListSL.createBlackList(oBlackListResult);

            return lLiaBlackListSeqNbr;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    //This Method is Used to Update an BlackListed Agent Entry in The System
    public void updateBlackList(BlackListResult oBlackListResult)
        throws EElixirException
    {
        try
        {
            log.debug("CHMSLEJB--In Update BlackList of CHMSLEJB");
            _oBlackListSL = getBlackListSL("BlackListSLHome",
                    BlackListSLHome.class);
            _oBlackListSL.updateBlackList(oBlackListResult);
            log.debug("CHMSLEJB--out of Update BlackList of CHMSLEJB");
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    //This Method is Used to Retrieve an BlackListed Agent Entry in The System
    public BlackListResult searchBlackList(long a_lLiaBlackListSeqNbr)
        throws EElixirException
    {
        BlackListResult oBlackListResult = null;

        try
        {
            _oBlackListSL = getBlackListSL("BlackListSLHome",
                    BlackListSLHome.class);
            oBlackListResult = _oBlackListSL.searchBlackList(a_lLiaBlackListSeqNbr);

            return oBlackListResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    //This Method is Used to do the Remote Lookup Of BlackListSL
    private BlackListSL getBlackListSL(String strHome, Class cHomeClass)
        throws RemoteException, CreateException, EElixirException
    {
        log.debug("CHMSLEJB--Looking for BlackListSLHome");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB--Looking for BlackListSLHome");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--Looking for BlackListSLHome");

        BlackListSLHome oBlackListSLHome = (BlackListSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        BlackListSL oBlackListSL = oBlackListSLHome.create();
        log.debug("CHMSLEJB--BlackListSLHome Created");

        return oBlackListSL;
    }

    public void createMenuAccessLog(String strUserId, String strOptionAccess)
        throws RemoteException, EElixirException
    {
        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            _oCommonSL.createMenuAccessLog(strUserId, strOptionAccess);
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public ArrayList getBranchList(String a_strBankCd)
        throws RemoteException, EElixirException
    {
        ArrayList al_branchList = null;

        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            al_branchList = _oCommonSL.getBranchList(a_strBankCd);

            return al_branchList;
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public AddressMasterResult addressMasterSearch(String a_strAddrCd)
        throws EElixirException
    {
        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            AddressMasterResult oAddressMasterResult = _oCommonSL.addressMasterSearch(a_strAddrCd);

            return oAddressMasterResult;
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    private CommonSL getCommonSL(String strHome, Class cHomeClass)
        throws RemoteException, CreateException, EElixirException
    {
        log.debug("Looking for CommonSLHome");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        CommonSLHome oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    strHome), cHomeClass);
        CommonSL oCommonSL = oCommonSLHome.create();
        log.debug("CommonSLHome Created");

        return oCommonSL;
    }

    ///////////////////////////////////// CODE BY JIMMY END HERE ////////////////////////////
    //***********************Sandeep Code for Agent Movement**************
    public String searchMovements(SearchData a_oSearchData)
        throws EElixirException, FinderException
    {
        String resultData = null;

        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB _oMovementSLHome : " + _oMovementSLHome);
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB _oMovementSL : " + _oMovementSL);
            resultData = _oMovementSL.searchMovements(a_oSearchData);
            log.debug("CHMSLEJB -- After serach result ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }

        return resultData;
    }

    public AgentMovementResult searchAgentMovement(Long a_lAgntMovmnSeqNbr)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----searchAgentMovement----In searchAgentMovement");

        AgentMovementResult resultObject = null;
        log.debug("CHMSLEJB----searchAgentMovement----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----searchAgentMovement----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchAgentMovement----before Lookup");
        _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MovementSLHome"), MovementSLHome.class);
        log.debug("CHMSLEJB----searchAgentMovement----After Lookup");

        try
        {
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB----searchAgentMovement----Inside try");

            resultObject = _oMovementSL.searchAgentMovement(a_lAgntMovmnSeqNbr);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgentMovement--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3528");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgentMovement--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3528");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgentMovement--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }
    	//<Added by Ankita on 1.06.2012 for MO changes :START>
    public AgentResult searchAgentDetailsForAgentMovement(String a_strAgentCd,String a_strScreenName,String dtEffFrom)
        throws FinderException, EElixirException
    {
        log.debug(
            "CHMSLEJB----searchAgentDetailsForAgentMovement----In searchAgentMovement");

        AgentResult resultObject = null;
        log.debug(
            "CHMSLEJB----searchAgentDetailsForAgentMovement----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug(
            "CHMSLEJB----searchAgentDetailsForAgentMovement----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug(
            "CHMSLEJB----searchAgentDetailsForAgentMovement----before Lookup");
        _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MovementSLHome"), MovementSLHome.class);
        log.debug(
            "CHMSLEJB----searchAgentDetailsForAgentMovement----After Lookup");

        try
        {
            _oMovementSL = _oMovementSLHome.create();
            log.debug(
                "CHMSLEJB----searchAgentDetailsForAgentMovement----Inside try");

            resultObject = _oMovementSL.searchAgentDetailsForAgentMovement(a_strAgentCd,a_strScreenName,dtEffFrom);
          //<Added by Ankita on 1.06.2012 for MO changes :END>
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgentDetailsForAgentMovement--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3532");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgentDetailsForAgentMovement--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3532");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgentDetailsForAgentMovement--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    public Short searchDesignationLevelForAgentMovement(String a_strNewDesgnCd)
        throws FinderException, EElixirException
    {
        log.debug(
            "CHMSLEJB----searchDesignationLevelForAgentMovement----In searchDesignationLevelForAgentMovement");

        Short resultObject = null;
        log.debug(
            "CHMSLEJB----searchDesignationLevelForAgentMovement----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug(
            "CHMSLEJB----searchDesignationLevelForAgentMovement----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug(
            "CHMSLEJB----searchDesignationLevelForAgentMovement----before Lookup");
        _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MovementSLHome"), MovementSLHome.class);
        log.debug(
            "CHMSLEJB----searchDesignationLevelForAgentMovement----After Lookup");

        try
        {
            _oMovementSL = _oMovementSLHome.create();
            log.debug(
                "CHMSLEJB----searchDesignationLevelForAgentMovement----Inside try");

            resultObject = _oMovementSL.searchDesignationLevelForAgentMovement(a_strNewDesgnCd);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchDesignationLevelForAgentMovement--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3532");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchDesignationLevelForAgentMovement--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3532");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchDesignationLevelForAgentMovement--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    public long createAgentMovement(AgentMovementResult a_oAgentMovementResult)
        throws EElixirException
    {
        log.debug("CHMSLEJB--createAgentMovement()");

        try
        {
            log.debug("CHMSLEJB--createAgentMovement()--in try");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug(
                "CHMSLEJB--createAgentMovement()--after getting propertyutil");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB--createAgentMovement()--after getting factory");
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB--createAgentMovement()--after getting home");
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB--createAgentMovement()--after getting remote");

            long _lAgntMovmnSeqNbr = _oMovementSL.createAgentMovement(a_oAgentMovementResult);
            log.debug(
                "CHMSLEJB--createAgentMovement()--out of create Formula of CHMSLEJB" +
                _lAgntMovmnSeqNbr);

            return _lAgntMovmnSeqNbr;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB-createAgentMovement()-inside create exception");
            throw new EElixirException(cex, "P3547");
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB-createAgentMovement()-inside Remoteexception");
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3547");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB-createAgentMovement()-inside ejb exception");
            throw new EElixirException(ejbex, "P3547");
        }
    }

    public void updateAgentMovement(AgentMovementResult a_oAgentMovementResult)
        throws EElixirException
    {
        log.debug("CHMSLEJB--createAgentMovement()");

        try
        {
            log.debug("CHMSLEJB--createAgentMovement()--in try");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug(
                "CHMSLEJB--createAgentMovement()--after getting propertyutil");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB--createAgentMovement()--after getting factory");
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB--createAgentMovement()--after getting home");
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB--createAgentMovement()--after getting remote");
            _oMovementSL.updateAgentMovement(a_oAgentMovementResult);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB-createAgentMovement()-inside create exception");
            throw new EElixirException(cex, "P3548");
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB-createAgentMovement()-inside Remoteexception");
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3548");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public ArrayList searchSubOrdinateDetails(Long a_lAgntMovmnSeqNbr,
        String a_strAgentCd) throws FinderException, EElixirException
    {
        log.debug(
            "CHMSLEJB----searchSubOrdinateDetails----In searchSubOrdinateDetails");

        ArrayList resultObject = new ArrayList();
        log.debug("CHMSLEJB----searchSubOrdinateDetails----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug(
            "CHMSLEJB----searchSubOrdinateDetails----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchSubOrdinateDetails----before Lookup");
        _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MovementSLHome"), MovementSLHome.class);
        log.debug("CHMSLEJB----searchSubOrdinateDetails----After Lookup");

        try
        {
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB----searchSubOrdinateDetails----Inside try");

            resultObject = _oMovementSL.searchSubOrdinateDetails(a_lAgntMovmnSeqNbr,
                    a_strAgentCd);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchPolicyTransferDetailEntry--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3552");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchSubOrdinateDetails--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3552");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchSubOrdinateDetails--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    //**********************Agent Movement Code Ends *********************
    //**********************Agent Movement Code Ends *********************
    //**********************Agent Movement Code Ends *********************
    //***********************Code for Agency Branch Termination Llst Search **Sandeep**************
//	  Added by Srikanth CTS for Agency Movement AGN-09
    public String searchAgencyMovement(SearchData a_oSearchData)
        throws EElixirException, FinderException
    {
        String resultData = null;

        try
        {
            log.debug("CHMSLEJB searchAgencyMovement starts");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB _oMovementSLHome : " + _oMovementSLHome);
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB _oMovementSL : " + _oMovementSL);
            resultData = _oMovementSL.searchAgencyMovement(a_oSearchData);
            
            log.debug("CHMSLEJB searchAgencyMovement starts"+resultData);
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }

        return resultData;
    }

    /*
    *This method will look up the movementSLEjb & call the SEarch method
    */

    //Added by Srikanth CTS for Agency Movement AGN-09
    public AgencyMovementResult searchAgencyMovement(
        long lAgntMovmnSeqNbr) throws EElixirException, FinderException
    {
        AgencyMovementResult resultObject = null;

        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB _oMovementSLHome : " + _oMovementSLHome);
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB _oMovementSL : " + _oMovementSL);
            resultObject = _oMovementSL.searchAgencyMovement(lAgntMovmnSeqNbr);
            log.debug("CHMSLEJB -- After serach result ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }

        return resultObject;
    }
    //End by Srikanth CTS

    // Added by Srikanth CTS for Agency Movement AGN-09
    public long createAgencyMovement(
        AgencyMovementResult a_oAgencyMovementResult)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB--createAgencyMovement() starts");

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB _oMovementSLHome : " + _oMovementSLHome);
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB--createAgencyMovement--after getting remote");

            long _lAgntMovmSeqNbr = _oMovementSL.createAgencyMovement(a_oAgencyMovementResult);
            
            log.debug("CHMSLEJB--createAgencyMovement() ends"+_lAgntMovmSeqNbr);

            return _lAgntMovmSeqNbr;
        }
        catch (CreateException cex)
        {
            log.debug(
                "CHMSLEJB-createAgencyBranchTerminationEntry()-inside create exception");
            throw new EElixirException(cex, "P3503");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB-createAgencyBranchTerminationEntry()-inside Remoteexception");
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3503");
        }
        catch (EJBException ejbex)
        {
            log.debug(
                "CHMSLEJB-createAgencyBranchTerminationEntry()-inside ejb exception");
            throw new EElixirException(ejbex, "P3503");
        }
    }
    //End by Srikanth CTS
    
    
    // Added by Srikanth CTS for Agency Movement AGN-09
    public void updateAgencyMovement(
        AgencyMovementResult a_oAgencyMovementResult)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB--updateAgencyMovement()");

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

            //  log.debug("CHMSLEJB oCHMPropertyUtil : "+oCHMPropertyUtil);
            _oMovementSLHome = (MovementSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MovementSLHome"), MovementSLHome.class);
            log.debug("CHMSLEJB _oMovementSLHome : " + _oMovementSLHome);
            _oMovementSL = _oMovementSLHome.create();
            log.debug("CHMSLEJB--updateAgencyMovement()--after getting remote");
            _oMovementSL.updateAgencyMovement(a_oAgencyMovementResult);
        }
        catch (CreateException cex)
        {
            log.debug(
                "CHMSLEJB-updateAgencyMovement()-inside create exception");
            throw new EElixirException(cex, "p6300");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB-updateAgencyMovement()-inside Remoteexception");
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "p6300");
        }
        catch (EJBException ejbex)
        {
            log.debug(
                "CHMSLEJB-updateAgencyMovement()-inside ejb exception");
            throw new EElixirException(ejbex, "p6300");
        }
        catch (EElixirException eex)
        {
        	log.debug(
            "CHMSLEJB-updateAgencyMovement()-inside EElixirException exception");
            throw eex;
        }
    }
    //End by Srikanth CTS

    //**********************Agency branch Termination List Search Ends**Sandeep*********************
    //Added SAndeep 23rd Dec '02 Daitiren Eval Defn
    //***********************Code for Dairiten Evaluation Definition List Search **Sandeep**************

    /* This method will search for the  Dairiten Evaluation Definition based on the search crtiteria passed in the
    *Searchdata object
    *@param SearchData
    *@return String
    *@throws EElixirException FinderException RemoteException
    */
    public String searchDairitenEvalDefinition(SearchData a_oSearchData)
        throws EElixirException, FinderException
    {
        String resultData = null;

        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oDairitenEvalDefinitionSLHome = (DairitenEvalDefinitionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "DairitenEvalDefinitionSLHome"),
                    DairitenEvalDefinitionSLHome.class);
            log.debug("CHMSLEJB _oDairitenEvalDefinitionSLHome : " +
                _oDairitenEvalDefinitionSLHome);
            _oDairitenEvalDefinitionSL = _oDairitenEvalDefinitionSLHome.create();
            log.debug("CHMSLEJB _oDairitenEvalDefinitionSL : " +
                _oDairitenEvalDefinitionSL);
            resultData = _oDairitenEvalDefinitionSL.searchDairitenEvalDefinition(a_oSearchData);
            log.debug("CHMSLEJB -- After serach result ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }

        return resultData;
    }

    //**********************Dairiten Evaluation Definition List Search Ends**Sandeep*********************
    //***********************Code for Dairiten Evaluation Definition Create **Sandeep**************

    /* This method will lookup the Dairiten Eval Definition session bean
    *Searchdata object
    *@param SearchData
    *@return String
    *@throws EElixirException FinderException RemoteException
    */
    public void createDairitenEvalDefinition(
        DairitenEvalDefinitionResult a_oDairitenEvalDefinitionResult)
        throws EElixirException, FinderException
    {
        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oDairitenEvalDefinitionSLHome = (DairitenEvalDefinitionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "DairitenEvalDefinitionSLHome"),
                    DairitenEvalDefinitionSLHome.class);
            log.debug("CHMSLEJB _oDairitenEvalDefinitionSLHome : " +
                _oDairitenEvalDefinitionSLHome);
            _oDairitenEvalDefinitionSL = _oDairitenEvalDefinitionSLHome.create();
            log.debug("CHMSLEJB _oDairitenEvalDefinitionSL : " +
                _oDairitenEvalDefinitionSL);
            _oDairitenEvalDefinitionSL.createDairitenEvalDefinition(a_oDairitenEvalDefinitionResult);
            log.debug("CHMSLEJB -- After CREATE ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }
    }

    //**********************Dairiten Evaluation Definition Create Ends**Sandeep*********************
    //***********************Code for Dairiten Evaluation Definition Search**Sandeep**************
    public DairitenEvalDefinitionResult searchDairitenEvalDefinition(
        String a_strSubChannelType) throws FinderException, EElixirException
    {
        DairitenEvalDefinitionResult resultObject = null;

        try
        {
            log.debug(
                "CHMSLEJB--in searchDairitenEvalDefinition(String a_strSubChannelType)");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug(
                "CHMSLEJB--after getfacory searchDairitenEvalDefinition(String a_strSubChannelType)");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup in CHMSL");
            _oDairitenEvalDefinitionSLHome = (DairitenEvalDefinitionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "DairitenEvalDefinitionSLHome"),
                    DairitenEvalDefinitionSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oDairitenEvalDefinitionSL = _oDairitenEvalDefinitionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            resultObject = _oDairitenEvalDefinitionSL.searchDairitenEvalDefinition(a_strSubChannelType);
            log.debug("CHMSLEJB--after search in CHMSL");
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    public void updateDairitenEvalDefinition(
        DairitenEvalDefinitionResult oDairitenEvalDefinitionResult)
        throws EElixirException
    {
        try
        {
            log.debug(
                "CHMSLEJB--In Update updateDairitenEvalDefinition of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oDairitenEvalDefinitionSLHome = (DairitenEvalDefinitionSLHome) objEJBHomeFactory.lookUpHome(_oCHMPropertyUtil.getCHMProperty(
                        "DairitenEvalDefinitionSLHome"),
                    DairitenEvalDefinitionSLHome.class);
            _oDairitenEvalDefinitionSL = _oDairitenEvalDefinitionSLHome.create();
            _oDairitenEvalDefinitionSL.updateDairitenEvalDefinition(oDairitenEvalDefinitionResult);
            log.debug("CHMSLEJB--out of create Application of CHMSLEJB");
        }
        catch (CreateException cex)
        {
            throw new EElixirException("P4511");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
        catch (EJBException ejbex)
        {
            log.debug("-----------CHMSLEJB--------- ejbexception caught");
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (RemoteException rex)
        {
            log.debug("remote exception in chmslejb" + rex.detail);
            throw new EElixirException(rex, "P1006");
        }
    }

    //End Addition Sandeep
    //******************************Target code starts here**********************
    public ArrayList searchTarget(TargetResult _oTargetResult)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----searchTarget----In searchTarget");

        ArrayList resultObject = new ArrayList();

        try
        {
            log.debug("CHMSLEJB----searchTarget----Before getFactory");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB----searchTarget----Before getPropertyUtil");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB----searchTarget----before Lookup");
            _oTargetSLHome = (TargetSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "TargetSLHome"), TargetSLHome.class);
            log.debug("CHMSLEJB----searchTarget----After Lookup");

            _oTargetSL = _oTargetSLHome.create();
            log.debug("CHMSLEJB----searchTarget----Inside try");

            resultObject = _oTargetSL.searchTarget(_oTargetResult);
        }
        catch (CreateException rex)
        {
            log.debug("CHMSLEJB--searchTarget--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P4530");
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--searchTarget--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P4530");
        }
        catch (EElixirException rex)
        {
            log.debug("CHMSLEJB--searchTarget--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB----searchTarget----returning back to TargetSearch " +
            "action class");

        return resultObject;
    }

    public void createTarget(ArrayList alTarget)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----createTarget----In createTarget");

        try
        {
            log.debug("CHMSLEJB----createTarget----Before getFactory");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB----createTarget----Before getPropertyUtil");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB----createTarget----before Lookup");
            _oTargetSLHome = (TargetSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "TargetSLHome"), TargetSLHome.class);
            log.debug("CHMSLEJB----createTarget----After Lookup");

            _oTargetSL = _oTargetSLHome.create();
            log.debug("CHMSLEJB----createTarget----Inside try");

            _oTargetSL.createTarget(alTarget);
        }
        catch (CreateException rex)
        {
            log.debug("CHMSLEJB--createTarget--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P4532");
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--createTarget--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P4532");
        }
        catch (EElixirException rex)
        {
            log.debug("CHMSLEJB--createTarget--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB----createTarget----returning back to TargetSearch " +
            "action class");
    }

    public void updateTarget(ArrayList alTarget)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----updateTarget----In createTarget");

        try
        {
            log.debug("CHMSLEJB----updateTarget----Before getFactory");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB----updateTarget----Before getPropertyUtil");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB----updateTarget----before Lookup");
            _oTargetSLHome = (TargetSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "TargetSLHome"), TargetSLHome.class);
            log.debug("CHMSLEJB----updateTarget----After Lookup");

            _oTargetSL = _oTargetSLHome.create();
            log.debug("CHMSLEJB----updateTarget----Inside try");

            _oTargetSL.updateTarget(alTarget);
        }
        catch (CreateException rex)
        {
            log.debug("CHMSLEJB--updateTarget--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P4533");
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--updateTarget--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P4533");
        }
        catch (EElixirException rex)
        {
            log.debug("CHMSLEJB--updateTarget--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB----updateTarget----returning back to TargetSearch " +
            "action class");
    }

    public ArrayList searchTargetDetail(Long a_lSelfRefNbr)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----searchTargetDetail----In searchTargetDetail");

        ArrayList resultObject = null;

        try
        {
            log.debug("CHMSLEJB----searchTargetDetail----Before getFactory");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug(
                "CHMSLEJB----searchTargetDetail----Before getPropertyUtil");

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB----searchTargetDetail----before Lookup");
            _oTargetSLHome = (TargetSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "TargetSLHome"), TargetSLHome.class);
            log.debug("CHMSLEJB----searchTargetDetail----After Lookup");

            _oTargetSL = _oTargetSLHome.create();
            log.debug("CHMSLEJB----searchTargetDetail----Inside try");

            resultObject = _oTargetSL.searchTargetDetail(a_lSelfRefNbr);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchTargetDetail--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P4530");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchTargetDetail--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P4530");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchTargetDetail--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug(
            "CHMSLEJB----searchTargetDetail----returning back to TargetSearch " +
            "action class");

        return resultObject;
    }

    //added for target definition
    public String searchTargetDefinition(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        String resultData = null;

        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oTargetSLHome = (TargetSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "TargetSLHome"), TargetSLHome.class);
            log.debug("CHMSLEJB _oTargetSLHome : " + _oTargetSLHome);
            _oTargetSL = _oTargetSLHome.create();
            log.debug("CHMSLEJB _oTargetSL : " + _oTargetSL);
            resultData = _oTargetSL.searchTargetDefinition(a_oSearchData);
            log.debug("CHMSLEJB -- After serach result ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }

        return resultData;
    }

    //End Addition Sandeep
    //******************************Target code ends here**********************
    //1/15/2003       Vinaysheel		Modified to bring channel, subchannel and branch type on change of parent code
    //exceptional Agenc y Promotion code starts
    public ExcepAgencyPromoResult searchCurrentRank(String a_strAgentCd)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB----searchCurrentRank----In searchCurrentRank");

        ExcepAgencyPromoResult resultObject = null;
        log.debug("CHMSLEJB----searchCurrentRank----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----searchCurrentRank----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oExcepAgencyPromoSLHome = (ExcepAgencyPromoSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "ExcepAgencyPromoSLHome"), ExcepAgencyPromoSLHome.class);
        log.debug("CHMSLEJB _oExcepAgencyPromoSLHome : " +
            _oExcepAgencyPromoSLHome);

        /* log.debug("CHMSLEJB----searchCurrentRank----before Lookup");
         _oPolicyTransferSLHome = (PolicyTransferSLHome)objEJBHomeFactory
                          .lookUpHome(oCHMPropertyUtil.getCHMProperty("PolicyTransferSLHome"), PolicyTransferSLHome.class);
         log.debug("CHMSLEJB----searchCurrentRank----After Lookup");*/
        try
        {
            _oExcepAgencyPromoSL = _oExcepAgencyPromoSLHome.create();
            log.debug("CHMSLEJB _oExcepAgencyPromoSL : " +
                _oExcepAgencyPromoSL);

            resultObject = _oExcepAgencyPromoSL.searchCurrentRank(a_strAgentCd);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchCurrentRank--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3520");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchCurrentRank--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P3520");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchCurrentRank--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        return resultObject;
    }

    public String searchExcepAgencyPromo(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        String resultData = null;

        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oExcepAgencyPromoSLHome = (ExcepAgencyPromoSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ExcepAgencyPromoSLHome"), ExcepAgencyPromoSLHome.class);
            log.debug("CHMSLEJB _oExcepAgencyPromoSLHome : " +
                _oExcepAgencyPromoSLHome);
            _oExcepAgencyPromoSL = _oExcepAgencyPromoSLHome.create();
            log.debug("CHMSLEJB _oExcepAgencyPromoSL : " +
                _oExcepAgencyPromoSL);
            resultData = _oExcepAgencyPromoSL.searchExcepAgencyPromo(a_oSearchData);
            log.debug("CHMSLEJB -- After serach result ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }

        return resultData;
    }

    public ExcepAgencyPromoResult searchExceptionalAgencyPromotion(
        long lAgencyPromSeqNbr) throws FinderException, EElixirException
    {
        ExcepAgencyPromoResult _oExcepAgencyPromoResult = null;

        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oExcepAgencyPromoSLHome = (ExcepAgencyPromoSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ExcepAgencyPromoSLHome"), ExcepAgencyPromoSLHome.class);
            log.debug("CHMSLEJB _oExcepAgencyPromoSLHome : " +
                _oExcepAgencyPromoSLHome);
            _oExcepAgencyPromoSL = _oExcepAgencyPromoSLHome.create();
            log.debug("CHMSLEJB _oExcepAgencyPromoSL : " +
                _oExcepAgencyPromoSL);
            _oExcepAgencyPromoResult = _oExcepAgencyPromoSL.searchExceptionalAgencyPromotion(lAgencyPromSeqNbr);
            log.debug("CHMSLEJB -- After serach result ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }

        return _oExcepAgencyPromoResult;
    }

    public long createExceptionalAgencyPromotion(
        ExcepAgencyPromoResult _oExcepAgencyPromoResult)
        throws RemoteException, FinderException, EElixirException
    {
        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oExcepAgencyPromoSLHome = (ExcepAgencyPromoSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ExcepAgencyPromoSLHome"), ExcepAgencyPromoSLHome.class);
            log.debug("CHMSLEJB _oExcepAgencyPromoSLHome : " +
                _oExcepAgencyPromoSLHome);
            _oExcepAgencyPromoSL = _oExcepAgencyPromoSLHome.create();
            log.debug("CHMSLEJB _oExcepAgencyPromoSL : " +
                _oExcepAgencyPromoSL);

            long _lAgencyPromSeqNbr = _oExcepAgencyPromoSL.createExceptionalAgencyPromotion(_oExcepAgencyPromoResult);
            log.debug(
                "CHMSLEJB -- ##create in sl of Exceptional Agency Promotion----");

            return _lAgencyPromSeqNbr;
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }
    }

    public void updateExceptionalAgencyPromotion(
        ExcepAgencyPromoResult _oExcepAgencyPromoResult)
        throws FinderException, EElixirException
    {
        try
        {
            log.debug("inside search in chmslejb");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            log.debug("CHMSLEJB objEJBHomeFactory : " + objEJBHomeFactory);

            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB oCHMPropertyUtil : " + oCHMPropertyUtil);
            _oExcepAgencyPromoSLHome = (ExcepAgencyPromoSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "ExcepAgencyPromoSLHome"), ExcepAgencyPromoSLHome.class);
            log.debug("CHMSLEJB _oExcepAgencyPromoSLHome : " +
                _oExcepAgencyPromoSLHome);
            _oExcepAgencyPromoSL = _oExcepAgencyPromoSLHome.create();
            log.debug("CHMSLEJB _oExcepAgencyPromoSL : " +
                _oExcepAgencyPromoSL);
            _oExcepAgencyPromoSL.updateExceptionalAgencyPromotion(_oExcepAgencyPromoResult);
            log.debug("CHMSLEJB -- After uptdating result ----");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (RemoteException ejbex)
        {
            throw new EElixirException(ejbex, "P1006");
        }
        catch (CreateException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eLex)
        {
            throw eLex;
        }
    }

    //exceptional agency promotion code ends
    // ***********************Commission Projection Starts Here************************************
    public String searchCommissionProjection(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oCommissionProjectionSLHome = (CommissionProjectionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "CommissionProjectionSLHome"),
                CommissionProjectionSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oCommissionProjectionSL = _oCommissionProjectionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        try
        {
            resultString = _oCommissionProjectionSL.searchCommissionProjection(a_oResultObject);
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        return resultString;
    }

    public CommissionProjectionResult searchCommissionProjection(
        long a_lComProjSeqNbr) throws FinderException, EElixirException
    {
        CommissionProjectionResult oCommissionProjectionResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommissionProjectionSLHome = (CommissionProjectionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommissionProjectionSLHome"),
                    CommissionProjectionSLHome.class);

            _oCommissionProjectionSL = _oCommissionProjectionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            oCommissionProjectionResult = _oCommissionProjectionSL.searchCommissionProjection(a_lComProjSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug(
            "CHMSLEJB--returning back to CommissionProjection action class" +
            oCommissionProjectionResult);

        return oCommissionProjectionResult;
    }

    public long createCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--In create CommissionProjection of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oCommissionProjectionSLHome = (CommissionProjectionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommissionProjectionSLHome"),
                    CommissionProjectionSLHome.class);
            _oCommissionProjectionSL = _oCommissionProjectionSLHome.create();

            long seqNo = _oCommissionProjectionSL.createCommissionProjection(a_oCommissionProjectionResult);
            log.debug(
                "CHMSLEJB--out of create CommissionProjection of CHMSLEJB");

            return seqNo;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void updateCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws EJBException, EElixirException
    {
        try
        {
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--In create Unit of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oCommissionProjectionSLHome = (CommissionProjectionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommissionProjectionSLHome"),
                    CommissionProjectionSLHome.class);
            _oCommissionProjectionSL = _oCommissionProjectionSLHome.create();
            _oCommissionProjectionSL.updateCommissionProjection(a_oCommissionProjectionResult);
            log.debug(
                "CHMSLEJB--out of create CommissionProjection of CHMSLEJB");
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--inside create exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException fex)
        {
            log.exception(fex.getMessage());
            throw new EElixirException(fex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void deleteCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws RemoveException, FinderException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommissionProjectionSLHome = (CommissionProjectionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommissionProjectionSLHome"),
                    CommissionProjectionSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommissionProjectionSL = _oCommissionProjectionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oCommissionProjectionSL.deleteCommissionProjection(a_oCommissionProjectionResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }

        catch (RemoveException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P3207");
        }

        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        log.debug(
            "CHMSLEJB--returning back to CommissionProjection action class");
    }

    // ***********************Commission Projection Ends Here************************************
    public ArrayList searchMenu() throws FinderException, EElixirException
    {
        ArrayList arrMenuResult = null;

        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            arrMenuResult = _oCommonSL.searchMenu();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        return arrMenuResult;
    }

    public void updateMenu(ArrayList a_arrMenuResult)
        throws FinderException, EJBException, EElixirException
    {
        ArrayList arrMenuResult = null;

        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            log.debug("CHMSLEJB--Inside try");
            _oCommonSL.updateMenu(a_arrMenuResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }

        log.debug("CHMSLEJB--returning back to Menu action class");
    }

    public ArrayList searchSubMenu(String a_strMenuId)
        throws FinderException, EElixirException
    {
        ArrayList arrSubMenuResult = null;

        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            arrSubMenuResult = _oCommonSL.searchSubMenu(a_strMenuId);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        return arrSubMenuResult;
    }

    public void updateSubMenu(ArrayList a_arrSubMenuResult)
        throws FinderException, EJBException, EElixirException
    {
        ArrayList arrSubMenuResult = null;

        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            log.debug("CHMSLEJB--Inside try");
            _oCommonSL.updateSubMenu(a_arrSubMenuResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        /*  catch(FinderException cex)
          {
            log.debug("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
          }*/
        //never thrown
        /*  catch(EJBException ejbex)
          {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
          } */
        //never thrown
        log.debug("CHMSLEJB--returning back to Menu action class");
    }

    public ArrayList searchPrivilege(String a_strSubMenuId)
        throws FinderException, EElixirException
    {
        ArrayList arrPrivilegeResult = null;

        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            arrPrivilegeResult = _oCommonSL.searchPrivilege(a_strSubMenuId);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        return arrPrivilegeResult;
    }

    public void updatePrivilege(ArrayList a_arrPrivilegeResult)
        throws FinderException, EJBException, EElixirException
    {
        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            log.debug("CHMSLEJB--Inside try");
            _oCommonSL.updatePrivilege(a_arrPrivilegeResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        /* catch(FinderException cex)
        {
          log.debug("CHMSLEJB--inside finder exception");
          throw new EElixirException(cex, "P1007");
        }*/
        //never thrown
        /* catch(EJBException ejbex)
        {
          log.debug("CHMSLEJB--inside ejb exception");
          throw new EElixirException(ejbex, "P1007");
        }*/
        //never thrown
        log.debug("CHMSLEJB--returning back to Menu action class");
    }

    //*********************UserPrivilege methods
    public ArrayList searchUserPrivilege(Long lRoleSeqNbr)
        throws FinderException, EElixirException
    {
        ArrayList _oUserPrivilegeList = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "CommonSLHome"), CommonSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB-----searchUserPrivilege----lRoleSeqNbr" +
                lRoleSeqNbr);
            _oUserPrivilegeList = _oCommonSL.searchUserPrivilege(lRoleSeqNbr);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        return _oUserPrivilegeList;
    }

    public void updateUserPrivilege(ArrayList a_oUserPrivilegeList,
        Long lRoleSeqNbr) throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "CommonSLHome"), CommonSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oCommonSL.updateUserPrivilege(a_oUserPrivilegeList, lRoleSeqNbr);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to a_oUserPrivilege action class");
    }

    public void copyUserPrivilege(Long lSrcRoleSeqNbr, Long lTrgRoleSeqNbr,
        String strUserId) throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "CommonSLHome"), CommonSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oCommonSL.copyUserPrivilege(lSrcRoleSeqNbr, lTrgRoleSeqNbr,
                strUserId);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to a_oUserPrivilege action class");
    }

    public ArrayList searchRoleTypes(Long lRoleTypes)
        throws FinderException, EElixirException
    {
        ArrayList _oRoleList = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommonSLHome"), CommonSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB-----searchRoleTypes----lRoleTypes" +
                lRoleTypes);
            _oRoleList = _oCommonSL.searchRoleTypes(lRoleTypes);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back " + _oRoleList);

        return _oRoleList;
    }

    public long createRole(String strRoleDisplayName, String strRoleDesc,
        String strRoleDn, String strUserId)
        throws FinderException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommonSLHome"), CommonSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");

            long lRoleSeqNbr = _oCommonSL.createRole(strRoleDisplayName,
                    strRoleDesc, strRoleDn, strUserId);

            return lRoleSeqNbr;
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }
    }

    // **************************Master starts here for Financial Year ******************
    public ArrayList searchFinancialYear()
        throws FinderException, EElixirException
    {
        ArrayList arrFinancialYearResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            arrFinancialYearResult = _oMasterSL.searchFinancialYear();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        return arrFinancialYearResult;
    }

    public void updateFinancialYear(ArrayList a_arrFinancialYearResult)
        throws FinderException, EJBException, EElixirException
    {
        ArrayList arrFinancialYearResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oMasterSL.updateFinancialYear(a_arrFinancialYearResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }

        log.debug("CHMSLEJB--returning back to FinancialYear action class");
    }

    // **************************Master ends here for Financial Year ******************

    /*Designation delete functionality*/
    public void deleteDesignation(String strDesgnCd)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oDesignationSLHome = (DesignationSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "DesignationSLHome"), DesignationSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oDesignationSL = _oDesignationSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oDesignationSL.deleteDesignation(strDesgnCd);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to a_oUserPrivilege action class");
    }

    /*Persistency delete functionality*/
    public void deletePersistency(String strPerstType)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oPersistencySLHome = (PersistencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PersistencySLHome"), PersistencySLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oPersistencySL = _oPersistencySLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oPersistencySL.deletePersistency(strPerstType);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to a_oUserPrivilege action class");
    }

    /*Persistency delete functionality*/

    //code for SystemParameter
    public ArrayList searchSystemParameter(int a_iParamTypeCd)
        throws FinderException, EElixirException
    {
        ArrayList _oSystemParameterList = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oSystemParameterList = _oMasterSL.searchSystemParameter(a_iParamTypeCd);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back " + _oSystemParameterList);

        return _oSystemParameterList;
    }

    public void updateSystemParameter(ArrayList a_oSystemParameterList)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oMasterSL.updateSystemParameter(a_oSystemParameterList);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to userParameter action class");
    }

    public String searchUser(SearchData a_oSearchData)
        throws EElixirException, FinderException
    {
        String strUserList = null;

        try
        {
            CommonSL _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            strUserList = _oCommonSL.searchUser(a_oSearchData);

            return strUserList;
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public long createUser(UserResult oUserResult) throws EElixirException
    {
        try
        {
            log.debug("CHMSLEJB--In create User of CHMSLEJB");
            _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);

            long lUserSeqNbr = _oCommonSL.createUser(oUserResult);
            log.debug("CHMSLEJB--out of create User of CHMSLEJB");

            return lUserSeqNbr;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateUser(UserResult oUserResult) throws EElixirException
    {
        try
        {
            log.debug("CHMSLEJB--In Update User of CHMSLEJB");
            _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            _oCommonSL.updateUser(oUserResult);
            log.debug("CHMSLEJB--out of Update User of CHMSLEJB");
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public UserResult searchUser(Long lUserSeqNbr) throws EElixirException
    {
        UserResult oUserResult = null;

        try
        {
            _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            oUserResult = _oCommonSL.searchUser(lUserSeqNbr);

            return oUserResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }
    
    /**
     * Added By Prabhat
     * Method for getting details of user's location wise roles
     * Start
     */
    public String validateUserRolesOnLocation(SearchData oSearchData) throws EElixirException
    {
        try
        {
            _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            String xml = _oCommonSL.validateUserRolesOnLocation(oSearchData);

            return xml;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }
    
    public SearchData getUserRolesOnLocation(SearchData oSearchData) throws EElixirException
    {
        try
        {
            _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
            oSearchData = _oCommonSL.getUserRolesOnLocation(oSearchData);

            return oSearchData;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }
    
    /**
     * Added By Prabhat
     * Method for getting details of user's location wise roles
     * End
     */

    public ArrayList getRoleDefinitions(String strRoleName,
        String strRoleNameKanji) throws RemoteException, EElixirException
    {
        ArrayList _oRoleDefinition = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommonSLHome"), CommonSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB-----searchRoleTypes----data passed " +
                strRoleName + "|" + strRoleNameKanji);
            _oRoleDefinition = _oCommonSL.getRoleDefinitions(strRoleName,
                    strRoleNameKanji);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back " + _oRoleDefinition);

        return _oRoleDefinition;
    }

    public void updateRoleDefinition(ArrayList _alRoleDefinitionList)
        throws RemoteException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommonSLHome"), CommonSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB----updateRoleDefinition-----data passed " +
                _alRoleDefinitionList);
            _oCommonSL.updateRoleDefinition(_alRoleDefinitionList);
        }
        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }
    }

    public void updateUserPassword(UserResult uResult)
        throws RemoteException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommonSLHome"), CommonSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB----updateUserPassword-----data passed " +
                uResult);
            _oCommonSL.updateUserPassword(uResult);
        }
        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }
    }

    public ArrayList searchLockedUsers(String strUserIDSearch)
        throws RemoteException, EElixirException
    {
        ArrayList alLockedUsers = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommonSLHome"), CommonSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB-----searchData----data passed " +
                alLockedUsers);
            alLockedUsers = _oCommonSL.searchLockedUsers(strUserIDSearch);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back " + alLockedUsers);

        return alLockedUsers;
    }

    public void updateUserLock(ArrayList alLockedUsers)
        throws RemoteException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommonSLHome"), CommonSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB----updateUserPassword-----data passed " +
                alLockedUsers);
            _oCommonSL.updateUserLock(alLockedUsers);
        }
        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }
    }

    public void deleteRole(Long lRoleSeqNbr)
        throws RemoteException, EElixirException
    {
        ArrayList alLockedUsers = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommonSLHome = (CommonSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommonSLHome"), CommonSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommonSL = _oCommonSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB-----deleterole----data passed " + lRoleSeqNbr);
            _oCommonSL.deleteRole(lRoleSeqNbr);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }
    }

    // Vikrant - Start
    public String searchTax(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        String strResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            strResult = _oMasterSL.searchTax(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.fatal("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.fatal("CHMSLEJB--RemoteException ");
            throw new EElixirException(cex, "P1006");
        }

        return strResult;
    }

    public TaxResult searchTax(Long a_lTaxSeqNbr)
        throws EElixirException, FinderException
    {
        TaxResult oTaxResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            oTaxResult = _oMasterSL.searchTax(a_lTaxSeqNbr);

            return oTaxResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1006");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    //This Method is Used to Retrieve an Tax Entry in The System
    public boolean isUniqueTaxCode(TaxResult a_oTaxResult)
        throws EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();

            return _oMasterSL.isUniqueTaxCode(a_oTaxResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    //Added by asim
    public boolean isUniqueDefault(TaxResult a_oTaxResult)
        throws EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();

            return _oMasterSL.isUniqueDefault(a_oTaxResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public boolean isUniqueTaxCodeinUpdate(TaxResult a_oTaxResult)
        throws EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();

            return _oMasterSL.isUniqueTaxCodeinUpdate(a_oTaxResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public Long createTax(TaxResult a_oTaxResult)
        throws EElixirException, RemoteException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();

            Long lTaxSeqNbr = _oMasterSL.createTax(a_oTaxResult);

            return lTaxSeqNbr;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateTax(TaxResult a_oTaxResult)
        throws RemoteException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.updateTax(a_oTaxResult);
        }
        catch (EJBException eex)
        {
            log.fatal("CHMSLEJB - In EJBException Exception");

            Exception e = eex.getCausedByException();

            if (e instanceof EElixirException)
            {
                throw (EElixirException) e;
            }
            else
            {
                throw eex;
            }
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            log.fatal("CHMSLEJB - In RemoteException Exception");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException eex)
        {
            log.fatal("CHMSLEJB - In EElixirException Exception");
            throw eex;
        }
    }

    private TaxHome getTaxHome(String a_strHome, Class a_oHomeClass)
        throws EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        TaxHome oTaxHome = (TaxHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    a_strHome), a_oHomeClass);

        return oTaxHome;
    }

    //For Bonus 
    public String searchBonus(SearchData a_oSearchData)
        throws FinderException, EElixirException, RemoteException
    {
        String strResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oBonusSLHome = (BonusSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BonusSLHome"), BonusSLHome.class);
            _oBonusSL = _oBonusSLHome.create();
            strResult = _oBonusSL.searchBonus(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.fatal("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }

        return strResult;
    }

    public Long createBonus(BonusResult a_oBonusResult)
        throws EElixirException, RemoteException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oBonusSLHome = (BonusSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BonusSLHome"), BonusSLHome.class);
            _oBonusSL = _oBonusSLHome.create();

            Long lBonusSeqNbr = _oBonusSL.createBonus(a_oBonusResult);

            return lBonusSeqNbr;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public BonusResult searchBonus(Long a_lBonusHdrSeqNbr)
        throws EElixirException, FinderException
    {
        BonusResult oBonusResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oBonusSLHome = (BonusSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BonusSLHome"), BonusSLHome.class);
            _oBonusSL = _oBonusSLHome.create();
            oBonusResult = _oBonusSL.searchBonus(a_lBonusHdrSeqNbr);

            return oBonusResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateBonus(BonusResult a_oBonusResult)
        throws EElixirException, RemoteException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oBonusSLHome = (BonusSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "BonusSLHome"), BonusSLHome.class);
            _oBonusSL = _oBonusSLHome.create();
            _oBonusSL.updateBonus(a_oBonusResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void deleteBonus(Long a_lBonusHdrSeqNbr)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBonusSLHome = (BonusSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BonusSLHome"), BonusSLHome.class);

        try
        {
            _oBonusSL = _oBonusSLHome.create();
            _oBonusSL.deleteBonus(a_lBonusHdrSeqNbr);
        }
        catch (CreateException rex)
        {
            log.fatal(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.fatal(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.fatal(rex.getMessage());
            throw rex;
        }
    }

    public String searchProduct(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        String strResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            strResult = _oMasterSL.searchProduct(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.fatal("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.fatal("CHMSLEJB--RemoteException ");
            throw new EElixirException(cex, "P1006");
        }

        return strResult;
    }

    public ProductResult searchProduct(String a_strProdCd)
        throws EElixirException, FinderException
    {
        ProductResult oProductResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            oProductResult = _oMasterSL.searchProduct(a_strProdCd);

            return oProductResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public boolean isUniqueProductCode(ProductResult a_oProductResult)
        throws EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();

            return _oMasterSL.isUniqueProductCode(a_oProductResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void createProduct(ProductResult a_oProductResult)
        throws EElixirException, RemoteException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.createProduct(a_oProductResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (FinderException cex)
        {
            log.fatal("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void updateProduct(ProductResult oProductResult)
        throws EElixirException, RemoteException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.updateProduct(oProductResult);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public AgentResult searchAgencyDetailsForAgentMovement(
        String a_strNewBrchCd, String a_strAgentCd, String a_strCurrBrchCd, String strMovementType)
        throws FinderException, EElixirException
    {
        log.debug(
            "CHMSLEJB----searchAgencyDetailsForAgentMovement----In searchAgencyMovement");

        AgentResult resultObject = null;
        log.debug(
            "CHMSLEJB----searchAgencyDetailsForAgentMovement----Before getFactory");

        EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug(
            "CHMSLEJB----searchAgencyDetailsForAgentMovement----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug(
            "CHMSLEJB----searchAgencyDetailsForAgentMovement----before Lookup");
        _oMovementSLHome = (MovementSLHome) oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MovementSLHome"), MovementSLHome.class);
        log.debug(
            "CHMSLEJB----searchAgencyDetailsForAgentMovement----After Lookup");

        try
        {
            _oMovementSL = _oMovementSLHome.create();
            log.debug(
                "CHMSLEJB----searchAgencyDetailsForAgentMovement----Inside try");

            resultObject = _oMovementSL.searchAgencyDetailsForAgentMovement(a_strNewBrchCd,
                    a_strAgentCd, a_strCurrBrchCd,strMovementType);
        }
        catch (CreateException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgencyDetailsForAgentMovement--In CreateException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P2032");
        }
        catch (RemoteException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgencyDetailsForAgentMovement--In RemoteException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P2032");
        }
        catch (EElixirException rex)
        {
            log.debug(
                "CHMSLEJB--searchAgencyDetailsForAgentMovement--In EELixirException of CHMSLEJB");
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug(
            "CHMSLEJB----searchAgencyDetailsForAgentMovement----returning back to GETAgentDetailsForAgentMovement action class" +
            resultObject);

        return resultObject;
    }

    /*
      * Invoked by the session bean to look up the  MasterSLEJB
      * @param Long
      * @return ArrayList
      * @throws EElixirException
      * @throws FinderException
    */
    public ArrayList searchPaymentCycle(Long a_lPaymentCycleSeqNbr)
        throws FinderException, EElixirException
    {
        ArrayList _oPaymentCycleList = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oPaymentCycleList = _oMasterSL.searchPaymentCycle(a_lPaymentCycleSeqNbr);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back " + _oPaymentCycleList);

        return _oPaymentCycleList;
    }

    /*
      * Invoked by the session bean to look up the  MasterSLEJB
      * @param String
      * @return ArrayList
      * @throws EElixirException
      * @throws FinderException
    */
    public ArrayList searchPaymentCycleByDate(String a_strPaymentCycleDt)
        throws FinderException, EElixirException
    {
        ArrayList _oPaymentCycleList = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oPaymentCycleList = _oMasterSL.searchPaymentCycleByDate(a_strPaymentCycleDt);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back " + _oPaymentCycleList);

        return _oPaymentCycleList;
    }

    public void updatePaymentCycle(ArrayList a_oPaymentCycleList)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oMasterSL.updatePaymentCycle(a_oPaymentCycleList);
        }

        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to PaymentCycle action class");
    }

    public void createPaymentCycle(ArrayList a_oPaymentCycleList)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oMasterSL.createPaymentCycle(a_oPaymentCycleList);
        }

        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());

            //throw new EElixirException(rex, "P1006");
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to PaymentCycle action class");
    }

    // Vikrant - End
    //overriding commission rate starts here ...... sandeep b
    public ArrayList searchOverridingCommRate(long a_lPriKey)
        throws FinderException, EElixirException
    {
        ArrayList arrOverridingCommRate = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommissionSLHome = (CommissionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommissionSLHome"), CommissionSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommissionSL = _oCommissionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            arrOverridingCommRate = _oCommissionSL.searchOverridingCommRate(a_lPriKey);
        }
        catch (CreateException cex)
        {
            log.fatal(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.fatal(rex.getMessage());
            throw new EElixirException(rex, "P1007");
        }

        log.debug("CHMSLEJB--returning back to action class" +
            arrOverridingCommRate);

        return arrOverridingCommRate;
    }

    public void updateOverridingCommRate(
        ArrayList a_arrOverridingCommRateResult)
        throws EJBException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oCommissionSLHome = (CommissionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "CommissionSLHome"), CommissionSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oCommissionSL = _oCommissionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            log.debug("CHMSLEJB--Inside try");
            _oCommissionSL.updateOverridingCommRate(a_arrOverridingCommRateResult);
            log.debug("CHMSLEJB--out of create Commission of CHMSLEJB");
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1007");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }
    }

    public void deleteAgent(String a_strAgentCd, String a_strUserID)
        throws RemoteException, EElixirException
    {
        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
            _oAgentSL.deleteAgent(a_strAgentCd, a_strUserID);
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    //**********************Code For Question Master Starts***************************
    public String searchQuestionReply(SearchData oSearchData)
        throws FinderException, RemoteException, EElixirException
    {
        String strResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            strResult = _oMasterSL.searchQuestionReply(oSearchData);
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1006");
        }

        return strResult;
    }

    //This Method is Used to Retrieve an BlackListed Agent Entry in The System
    public QuestionResult searchQuestionReply(long a_lQuestSeqNbr)
        throws RemoteException, EElixirException
    {
        QuestionResult oQuestionResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            oQuestionResult = _oMasterSL.searchQuestionReply(a_lQuestSeqNbr);

            return oQuestionResult;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
    }

    //This Method is Used to Create an BlackListed Agent Entry in The System
    public long createQuestionReply(QuestionResult oQuestionResult)
        throws RemoteException, EElixirException
    {
        try
        {
            log.debug("CHMSLEJB--In create QuestionReply of CHMSLEJB");

            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();

            long lQuestSeqNbr = _oMasterSL.createQuestionReply(oQuestionResult);
            log.debug("CHMSLEJB--out of create oQuestionResult of CHMSLEJB");

            return lQuestSeqNbr;
        }
        catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
    }

    public void updateQuestionReply(QuestionResult oQuestionResult)
        throws RemoteException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.updateQuestionReply(oQuestionResult);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }

    public void deleteQuestionReply(long a_lQuestSeqNbr)
        throws RemoteException, FinderException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.deleteQuestionReply(a_lQuestSeqNbr);
        }

        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }

    //***********************Code For Question Master Ends*****************************
    //***********************Code For DesignationQuestion Map Starts*****************************
    public ArrayList searchDesignationQuestionMap(SearchData oSearchData)
        throws RemoteException, FinderException, EElixirException
    {
        ArrayList strResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();

            strResult = _oMasterSL.searchDesignationQuestionMap(oSearchData);
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1006");
        }

        return strResult;
    }

    public void updateDesignationQuestionMap(
        ArrayList a_oDesignationQuestionMapList)
        throws RemoteException, FinderException, EElixirException
    {
        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.updateDesignationQuestionMap(a_oDesignationQuestionMapList);
        }

        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }

    public ArrayList searchPolicyAck(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        ArrayList _oPolicyAckList = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

        _oPolicyAckSLHome = (PolicyAckSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PolicyAckSLHome"), PolicyAckSLHome.class);

        try
        {
            _oPolicyAckSL = _oPolicyAckSLHome.create();

            _oPolicyAckList = _oPolicyAckSL.searchPolicyAck(a_oSearchData);
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            throw new EElixirException(cex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        log.debug(_oPolicyAckList.size() + "");

        return _oPolicyAckList;
    }

    public void updatePolicyAck(ArrayList a_oPolicyAckList)
        throws FinderException, EElixirException
    {
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();

        _oPolicyAckSLHome = (PolicyAckSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PolicyAckSLHome"), PolicyAckSLHome.class);

        try
        {
            _oPolicyAckSL = _oPolicyAckSLHome.create();

            _oPolicyAckSL.updatePolicyAck(a_oPolicyAckList);
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            throw new EElixirException(cex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }
    }

    public String policyListSearch(SearchData a_oSearchData)
        throws FinderException, EElixirException
    {
        String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oPolicyTransferSLHome = (PolicyTransferSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PolicyTransferSLHome"), PolicyTransferSLHome.class);

        try
        {
            _oPolicyTransferSL = _oPolicyTransferSLHome.create();
            resultString = _oPolicyTransferSL.policyListSearch(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.debug(cex.getMessage());
            throw new EElixirException(cex, "P1006");
        }
        catch (FinderException cex)
        {
            log.debug(cex.getMessage());
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug(cex.getMessage());
            throw new EElixirException(cex, "P1006");
        }

        return resultString;
    }

    public AgentMovementDetailResult searchAgentMovement(String a_strAgentCd)
        throws FinderException, EElixirException
    {
        log.debug("CHMSLEJB--CHMSLEJB--AgentAgencySearch--Start");

        AgentMovementDetailResult oAgentMovementDetailResult = null;

        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);

            oAgentMovementDetailResult = _oAgentSL.searchAgentMovement(a_strAgentCd);
            log.debug("CHMSLEJB--out of Search Agent of CHMSLEJB");

            return oAgentMovementDetailResult;
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
                cex);
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
                rex);
            throw new EElixirException(rex.getMessage());
        }
    }

    public AgentRefreeDetailResult searchAgentRefree(String a_strAgentCd)
        throws FinderException, EElixirException
    {
        AgentRefreeDetailResult oAgentRefreeDetailResult = null;

        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
            oAgentRefreeDetailResult = _oAgentSL.searchAgentRefree(a_strAgentCd);

            return oAgentRefreeDetailResult;
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex.getMessage());
        }
    }

    public AgentContractDetailResult searchAgentContract(String a_strAgentCd,
        Short nIsWritingAgent) throws FinderException, EElixirException
    {
        AgentContractDetailResult oAgentContractDetailResult = null;

        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
            oAgentContractDetailResult = _oAgentSL.searchAgentContract(a_strAgentCd,
                    nIsWritingAgent);

            return oAgentContractDetailResult;
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex.getMessage());
        }
    }

    public AgentPerformanceDetailResult searchAgentPerformance(
        String a_strAgentCd, Short a_nYear)
        throws FinderException, EElixirException
    {
        AgentPerformanceDetailResult oAgentPerformanceDetailResult = null;

        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);

            oAgentPerformanceDetailResult = _oAgentSL.searchAgentPerformance(a_strAgentCd,
                    a_nYear);

            return oAgentPerformanceDetailResult;
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex.getMessage());
        }
    }

    public AgentPersistancyDetailResult searchAgentPersistancy(
        String a_strAgentCd, Short a_nYear)
        throws FinderException, EElixirException
    {
        AgentPersistancyDetailResult oAgentPersistancyDetailResult = null;

        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);

            oAgentPersistancyDetailResult = _oAgentSL.searchAgentPersistancy(a_strAgentCd,
                    a_nYear);

            return oAgentPersistancyDetailResult;
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex.getMessage());
        }
    }

    public PolicyResult policySearch(String a_strPolicyNbr)
        throws FinderException, EElixirException
    {
        PolicyResult oPolicyResult = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oPolicyTransferSLHome = (PolicyTransferSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "PolicyTransferSLHome"), PolicyTransferSLHome.class);

        try
        {
            _oPolicyTransferSL = _oPolicyTransferSLHome.create();
            oPolicyResult = _oPolicyTransferSL.policySearch(a_strPolicyNbr);
        }
        catch (CreateException cex)
        {
            log.debug(cex.getMessage());
            throw new EElixirException(cex, "P1006");
        }
        catch (FinderException cex)
        {
            log.debug(cex.getMessage());
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug(cex.getMessage());
            throw new EElixirException(cex, "P1006");
        }

        return oPolicyResult;
    }
//  Anantha_AGN05_REQVII Starts
    public ArrayList getAllExistingClientDetails(String strTitle,
        String strFirstName, String strLastName, GregorianCalendar dtBirth,
        Short nGenderCd,String a_strfhtitlecd,String a_strfhfirstname,String a_strfhlastname,String a_strApprovalFlag) throws FinderException, EElixirException
    {
        ArrayList alExistingClientDetails = null;

        try
        {
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);

            alExistingClientDetails = _oAgentSL.getAllExistingClientDetails(strTitle,
                    strFirstName, strLastName, dtBirth, nGenderCd, a_strfhtitlecd, a_strfhfirstname, a_strfhlastname, a_strApprovalFlag);
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }

        return alExistingClientDetails;
    }
    
    
    public String getFHusbandDetails(String a_strApplcSeqNbr) throws FinderException, EElixirException
        {
            String strFHusbandDetailsResult = null;

            try
            {
                _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);

                strFHusbandDetailsResult = _oAgentSL.getFHusbandDetails(a_strApplcSeqNbr); 
            }
            catch (CreateException cex)
            {
                log.debug("CHMSLEJB--CreateException ");
                throw new EElixirException(cex, "P1006");
            }
            catch (RemoteException cex)
            {
                log.debug("CHMSLEJB--RemoteeException ");
                throw new EElixirException(cex, "P1006");
            }

            return strFHusbandDetailsResult;
        }
    
//  Anantha_AGN05_REQVII Ends

    public ApplicationResult getAllContactClientDetails(String strClientCd)
        throws FinderException, EElixirException
    {
        ApplicationResult oApplicationResult = null;

        try
        {
            log.debug("Befire Calling SL 1");
            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
            log.debug("Befire Calling SL 2");
            oApplicationResult = _oAgentSL.getAllContactClientDetails(strClientCd);
            log.debug("Befire Calling SL 3");
        }
        catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateException ");
            throw new EElixirException(cex, "P1006");
        }
        catch (RemoteException cex)
        {
            log.debug("CHMSLEJB--RemoteeException ");
            throw new EElixirException(cex, "P1006");
        }

        return oApplicationResult;
    }
    
    public String searchOtherBenefit(SearchData a_oSearchData)throws FinderException, EElixirException, RemoteException
	{
    	String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            resultString = _oBenefitSL.searchOtherBenefit(a_oSearchData);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return resultString;
    	
	}
    
    public long createOtherBenefit(OtherBenefitResult a_oOtherBenefitResult)throws FinderException, EElixirException, RemoteException
	{
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            long _lBonusHdrSeqNbr = _oBenefitSL.createOtherBenefit(a_oOtherBenefitResult);
     
            return _lBonusHdrSeqNbr; 
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch(EElixirException ex)
        {
        	log.debug("CHMSLEJB->createOtherBenefit-> "+ex);
        	throw ex;
        }
	}
	
	public OtherBenefitResult searchOtherBenefit(long lBonusHdrSeqNbr) throws FinderException, EElixirException, RemoteException
	{
        OtherBenefitResult oOtherBenefitResult = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            oOtherBenefitResult = _oBenefitSL.searchOtherBenefit(lBonusHdrSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return oOtherBenefitResult;
	}
	
    public void updateOtherBenefit(OtherBenefitResult a_oOtherBenefitResult)throws FinderException, EElixirException, RemoteException
	{
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            _oBenefitSL.updateOtherBenefit(a_oOtherBenefitResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch(EElixirException ex)
        {
        	log.debug("CHMSLEJB->updateOtherBenefit-> "+ex);
        	throw ex;
        }
	}
    
    public void updateAgentTargetDetails(ArrayList alAgentDetails,Long lBonusHdrSeqNbr)	throws FinderException,EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            _oBenefitSL.updateAgentTargetDetails(alAgentDetails,lBonusHdrSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }        
    }
    
    public ArrayList searchOtherBenefitAgentDetails (long lBonusHdrSeqNbr) throws FinderException,EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        ArrayList alAgentDetails = null;
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            alAgentDetails = _oBenefitSL.searchOtherBenefitAgentDetails(lBonusHdrSeqNbr);
            
            return alAgentDetails;
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }
    
    public void deleteOtherBenefit(Long lBonusHdrSeqNbr) throws FinderException,EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            _oBenefitSL.deleteOtherBenefit(lBonusHdrSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }        
    }
    
    public void deleteCriteriaParameters(Long lBonusHdrSeqNbr) throws FinderException,EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            _oBenefitSL.deleteCriteriaParameters(lBonusHdrSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }


	 // Methods added by Shameem Shaik for Finder Fees Module under commission.
	 //	******************************FinderFees starts here ***************************
	
	 public String searchFinderFees(SearchData a_oResultObject)
		 throws FinderException, EElixirException
	 {
		 String resultString = null;
		 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		 _oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
					 "FinderFeesSLHome"), FinderFeesSLHome.class);

		 try
		 {				
			 _oFinderFeesSL = _oFinderFeesSLHome.create();
			 log.debug("CHMSLEJB--Inside try");
		 }
		 catch (CreateException cex)
		 {
			 log.exception(cex.getMessage());
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }

		 try
		 {
			 resultString = _oFinderFeesSL.searchFinderFees(a_oResultObject);
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 return resultString;
	 }
	 
	 public String searchFinderFees()
			 throws FinderException, EElixirException, RemoteException
	 {
		 String resultString = null;
		 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		 _oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
					 "FinderFeesSLHome"), FinderFeesSLHome.class);

		 try
		 {				
			 _oFinderFeesSL = _oFinderFeesSLHome.create();
			 log.debug("CHMSLEJB--Inside try");
		 }
		 catch (CreateException cex)
		 {
			 log.exception(cex.getMessage());
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }

		 try
		 {
			 resultString = _oFinderFeesSL.searchFinderFees();
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 return resultString;
	 }

	 public long createFinderFees(FinderFeesResult a_FinderFeesResult)
			 throws EJBException, EElixirException
	 {		 
		 long seqNo = 0;

		 try
		 {
			 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			 
			 _oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						 "FinderFeesSLHome"), FinderFeesSLHome.class);
			 _oFinderFeesSL = _oFinderFeesSLHome.create();
			 seqNo = _oFinderFeesSL.createFinderFees(a_FinderFeesResult);

			 return seqNo;
		 }
		 catch (CreateException cex)
		 {
			 log.debug("CHMSLEJB--inside create exception");
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 catch (EJBException ejbex)
		 {
			 log.debug("CHMSLEJB--inside ejb exception");
			 throw new EElixirException(ejbex, "P1007");
		 }
	 }
	 
	 public void updateFinderFees(FinderFeesResult a_FinderFeesResult)
			 throws EElixirException, RemoteException
		{
			 try
			 {
				EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();								
				CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
				
			 	_oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						 "FinderFeesSLHome"), FinderFeesSLHome.class);
			 	_oFinderFeesSL = _oFinderFeesSLHome.create();
			 	_oFinderFeesSL.updateFinderFees(a_FinderFeesResult);
			 }
			 catch (CreateException ce)
			 {
				 throw new EElixirException(ce, "P1007");
			 }
			 catch (EJBException ejbex)
			 {
				 throw (EElixirException) ejbex.getCausedByException();
			 }
			 catch (EElixirException eex)
			 {
				 throw eex;
			 }
		}
	
	public void deleteFinderFees(Long a_lFFHdrSeqNbr)
		   throws FinderException, EElixirException
	   {
		   EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		   CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			_oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						"FinderFeesSLHome"), FinderFeesSLHome.class);

		   try
		   {
			  _oFinderFeesSL = _oFinderFeesSLHome.create();
			  _oFinderFeesSL.deleteFinderFees(a_lFFHdrSeqNbr);
		   }
		   catch (CreateException rex)
		   {
			   log.fatal(rex.getMessage());
			   throw new EElixirException(rex, "P1006");
		   }
		   catch (RemoteException rex)
		   {
			   log.fatal(rex.getMessage());
			   throw new EElixirException(rex, "P1006");
		   }
		   catch (EElixirException rex)
		   {
			   log.fatal(rex.getMessage());
			   throw rex;
		   }
	   }
		 
		 
	
	   public FinderFeesResult searchFinderFees(long a_lffeeseqnbr)
		   throws FinderException, EElixirException
	   {
		   FinderFeesResult oFinderFeesResult = null;

		   try
		   {
			   EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			   CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			   _oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						   "FinderFeesSLHome"), FinderFeesSLHome.class);
			   _oFinderFeesSL = _oFinderFeesSLHome.create();
			   oFinderFeesResult = _oFinderFeesSL.searchFinderFees(a_lffeeseqnbr);
		   }
		   catch (CreateException cex)
		   {
			   log.exception(cex.getMessage());
			   throw new EElixirException(cex, "P1007");
		   }
		   catch (RemoteException rex)
		   {
			   log.exception(rex.getMessage());
			   throw new EElixirException(rex, "P1006");
		   }
		   return oFinderFeesResult;
	   }

	   public void updateFFCommissionRates(FinderFeesResult a_FinderFeesResult)
			   throws EElixirException, RemoteException
		   {
			long seqNo = 0;
			   try
			   {
				EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		   		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		   		_oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
					   "FinderFeesSLHome"), FinderFeesSLHome.class);
		  		_oFinderFeesSL = _oFinderFeesSLHome.create();
				_oFinderFeesSL.updateFFCommissionRates(a_FinderFeesResult);
				
				//return seqNo;
			   }
			   catch (CreateException ce)
			   {
				   throw new EElixirException(ce, "P1007");
			   }
			   catch (EJBException ejbex)
			   {
				   throw (EElixirException) ejbex.getCausedByException();
			   }
			   catch (EElixirException eex)
			   {
				   throw eex;
			   }
		   }
	
		public long createFinderFeesMap(ArrayList al_FinderFeesMapResult)
		  throws RemoteException, CreateException, EElixirException
		  {
		  	
//			Collection resultCollection = null;
			  EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
			  CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
			  log.debug("CHMSLEJB--before Lookup");
			  _oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						  "FinderFeesSLHome"), FinderFeesSLHome.class);
			  log.debug("CHMSLEJB--After Lookup");
	
			  try
			  {
				  _oFinderFeesSL = _oFinderFeesSLHome.create();
				  log.debug("CHMSLEJB--Inside try");
	
				  return _oFinderFeesSL.createFinderFeesMap(al_FinderFeesMapResult);
			  }
	
			  catch (CreateException rex)
			  {
				  log.debug(rex.getMessage());
				  throw new EElixirException(rex, "P1006");
			  }
			  catch (RemoteException rex)
			  {
				  log.debug(rex.getMessage());
				  throw new EElixirException(rex, "P1006");
			  }
			  catch (EElixirException rex)
			  {
				  log.debug(rex.getMessage());
				  throw rex;
			  }
		   
		  }
		  
		  
	public ArrayList searchFinderFeesMap(long a_LFFMapSeqNbr)
					  throws RemoteException, FinderException, EElixirException
	{
			ArrayList al_resultObject = null;
			
			EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
			log.debug("CHMSLEJB--before Lookup");
			_oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								  "FinderFeesSLHome"), FinderFeesSLHome.class);								  
									
			log.debug("CHMSLEJB--After Lookup");
	
			try
			{
				_oFinderFeesSL = _oFinderFeesSLHome.create();
				log.debug("CHMSLEJB--Inside try");
	
				al_resultObject = _oFinderFeesSL.searchFinderFeesMap(a_LFFMapSeqNbr);
			}
			catch (CreateException rex)
			{
				log.debug(rex.getMessage());
				throw new EElixirException(rex, "P1006");
			}
			catch (RemoteException rex)
			{
				log.debug(rex.getMessage());
				throw new EElixirException(rex, "P1006");
			}
			catch (EElixirException rex)
			{
				log.debug(rex.getMessage());
				throw rex;
			}
	
			log.debug("CHMSLEJB--returning back to FinderFeesMap action class" +
				al_resultObject);
	
			return al_resultObject;
		}
		
		public String searchFinderFeesMap(SearchData a_oResultObject)
				throws FinderException, EElixirException, RemoteException
		 {
			 String resultString = null;
			
			 EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
		     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
		     log.debug("CHMSLEJB--before Lookup");
		     _oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								 "FinderFeesSLHome"), FinderFeesSLHome.class);		

			 try
			 {				
				 _oFinderFeesSL = _oFinderFeesSLHome.create();
				 log.debug("CHMSLEJB--Inside try");
			 }
			 catch (CreateException cex)
			 {
				 log.exception(cex.getMessage());
				 throw new EElixirException(cex, "P1007");
			 }
			 catch (RemoteException rex)
			 {
				 log.exception(rex.getMessage());
				 throw new EElixirException(rex, "P1006");
			 }

			 try
			 {
				 resultString = _oFinderFeesSL.searchFinderFeesMap(a_oResultObject);
			 }
			 catch (RemoteException rex)
			 {
				 log.exception(rex.getMessage());
				 throw new EElixirException(rex, "P1006");
			 }
			 return resultString;
		 }
		 
		 
		 public void updateFinderFeesMap(ArrayList al_oFinderFeesMapResult)
				 throws CreateException, EElixirException
			 {
				 try
				 {
					EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
					CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
					log.debug("CHMSLEJB--before Lookup");
					_oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								"FinderFeesSLHome"), FinderFeesSLHome.class);

					_oFinderFeesSL = _oFinderFeesSLHome.create();
					 log.debug("CHMSLEJB--Inside try");
					_oFinderFeesSL.updateFinderFeesMap(al_oFinderFeesMapResult);
					log.debug("CHMSLEJB--after invoking updateFinderFeesMap");
				 }
				 catch (CreateException rex)
				 {
					 log.debug(rex.getMessage());
					 throw new EElixirException(rex, "P1006");
				 }
				 catch (RemoteException rex)
				 {
					 log.debug(rex.getMessage());

					 //throw new EElixirException(rex, "P1006");
					 throw new EElixirException(rex, "P1006");
				 }
				 catch (EElixirException rex)
				 {
					 log.debug(rex.getMessage());
					 throw rex;
				 }
			 }

//added by jim
			public FinderFeesResult searchFFCommissionRates(long a_lbenseqnbr,String a_strprdcd)
				throws FinderException, EElixirException
			{
				FinderFeesResult oFinderFeesResult = null;

				try
				{
					EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
					CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
					_oFinderFeesSLHome = (FinderFeesSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								"FinderFeesSLHome"), FinderFeesSLHome.class);
					_oFinderFeesSL = _oFinderFeesSLHome.create();
					oFinderFeesResult = _oFinderFeesSL.searchFFCommissionRates(a_lbenseqnbr,a_strprdcd);
				}
				catch (CreateException cex)
				{
					log.exception(cex.getMessage());
					throw new EElixirException(cex, "P1007");
				}
				catch (RemoteException rex)
				{
					log.exception(rex.getMessage());
					throw new EElixirException(rex, "P1006");
				}
				return oFinderFeesResult;
			}

/*   Commented by jayasimha for Descoping of Lapse Rule and Lapse Rule Mapping 


		 public String searchLapseRule(SearchData a_oResultObject)
		 throws FinderException, EElixirException
	 {
		 String resultString = null;
		 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		 _oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
					 "LapseRuleSLHome"), LapseRuleSLHome.class);

		 try
		 {				
			 _oLapseRuleSL = _oLapseRuleSLHome.create();
			 log.debug("CHMSLEJB--Inside try searchLapseRule");
		 }
		 catch (CreateException cex)
		 {
			 log.exception(cex.getMessage());
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }

		 try
		 {
			 resultString = _oLapseRuleSL.searchLapseRule(a_oResultObject);
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 return resultString;
	 }
	 

	 public String searchLapseRule()
			 throws FinderException, EElixirException, RemoteException
	 {
		 String resultString = null;
		 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		 _oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
					 "LapseRuleSLHome"), LapseRuleSLHome.class);

		 try
		 {				
			 _oLapseRuleSL = _oLapseRuleSLHome.create();
			 log.debug("CHMSLEJB--Inside try searchLapseRule");
		 }
		 catch (CreateException cex)
		 {
			 log.exception(cex.getMessage());
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }

		 try
		 {
			 resultString = _oLapseRuleSL.searchLapseRule();
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 return resultString;
	 }
 public LapseRuleResult searchLapseRule(long a_llreeseqnbr)
		   throws FinderException, EElixirException
	   {
		   LapseRuleResult oLapseRuleResult = null;

		   try
		   {
			   EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			   CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			   _oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						   "LapseRuleSLHome"), LapseRuleSLHome.class);
			   _oLapseRuleSL = _oLapseRuleSLHome.create();
			   oLapseRuleResult = _oLapseRuleSL.searchLapseRule(a_llreeseqnbr);
		   }
		   catch (CreateException cex)
		   {
			   log.exception(cex.getMessage());
			   throw new EElixirException(cex, "P1007");
		   }
		   catch (RemoteException rex)
		   {
			   log.exception(rex.getMessage());
			   throw new EElixirException(rex, "P1006");
		   }
		   return oLapseRuleResult;
	   }

 public long createLapseRule(LapseRuleResult a_LapseRuleResult)
			 throws EJBException, EElixirException
	 {		 
		 long seqNo = 0;

		 try
		 {
			 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			 
			 _oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						 "LapseRuleSLHome"), LapseRuleSLHome.class);
			 _oLapseRuleSL = _oLapseRuleSLHome.create();
			 seqNo = _oLapseRuleSL.createLapseRule(a_LapseRuleResult);

			 return seqNo;
		 }
		 catch (CreateException cex)
		 {
			 log.debug("CHMSLEJB--inside create exception");
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 catch (EJBException ejbex)
		 {
			 log.debug("CHMSLEJB--inside ejb exception");
			 throw new EElixirException(ejbex, "P1007");
		 }
	 }
	 
	 public void deleteLapseRule(Long a_lLRHdrSeqNbr)
		   throws FinderException, EElixirException
	   {
		   EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		   CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			_oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						"LapseRuleSLHome"), LapseRuleSLHome.class);

		   try
		   {
			  _oLapseRuleSL = _oLapseRuleSLHome.create();
			  _oLapseRuleSL.deleteLapseRule(a_lLRHdrSeqNbr);
		   }
		   catch (CreateException rex)
		   {
			   log.fatal(rex.getMessage());
			   throw new EElixirException(rex, "P1006");
		   }
		   catch (RemoteException rex)
		   {
			   log.fatal(rex.getMessage());
			   throw new EElixirException(rex, "P1006");
		   }
		   catch (EElixirException rex)
		   {
			   log.fatal(rex.getMessage());
			   throw rex;
		   }
	   }
	
 public void updateLapseRule(LapseRuleResult a_LapseRuleResult)
			 throws EElixirException, RemoteException
		{
			 try
			 {
				EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();								
				CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
				
			 	_oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						 "LapseRuleSLHome"), LapseRuleSLHome.class);
			 	_oLapseRuleSL = _oLapseRuleSLHome.create();
			 	_oLapseRuleSL.updateLapseRule(a_LapseRuleResult);
			 }
			 catch (CreateException ce)
			 {
				 throw new EElixirException(ce, "P1007");
			 }
			 catch (EJBException ejbex)
			 {
				 throw (EElixirException) ejbex.getCausedByException();
			 }
			 catch (EElixirException eex)
			 {
				 throw eex;
			 }
		}
public ArrayList createLapseRuleMap(LapseRuleMapResult a_LapseRuleMapResult)
		  throws RemoteException, CreateException, EElixirException
		  {
		  	
			  EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
			  CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
			  log.debug("CHMSLEJB--before Lookup createLapseRuleMap");
			  _oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						  "LapseRuleSLHome"), LapseRuleSLHome.class);
			  log.debug("CHMSLEJB--After Lookup createLapseRuleMap");
	
			  try
			  {
				  _oLapseRuleSL = _oLapseRuleSLHome.create();
				  log.debug("CHMSLEJB--Inside try createLapseRuleMap inCHMSLEJB");
				  return _oLapseRuleSL.createLapseRuleMap(a_LapseRuleMapResult);
			  }
	
			  catch (CreateException rex)
			  {
				  log.debug(rex.getMessage());
				  throw new EElixirException(rex, "P1006");
			  }
			  catch (RemoteException rex)
			  {
				  log.debug(rex.getMessage());
				  throw new EElixirException(rex, "P1006");
			  }
			  catch (EElixirException rex)
			  {
				  log.debug(rex.getMessage());
				  throw rex;
			  }
		   
		  }
		  
		  
	public ArrayList searchLapseRuleMap(long a_LLRMapSeqNbr)
					  throws RemoteException, FinderException, EElixirException
	{
			ArrayList al_resultObject = null;
			
			EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
			log.debug("CHMSLEJB--before Lookup searchLapseRuleMap");
			_oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								  "LapseRuleSLHome"), LapseRuleSLHome.class);								  
									
			log.debug("CHMSLEJB--After Lookup searchLapseRuleMap");
	
			try
			{
				_oLapseRuleSL = _oLapseRuleSLHome.create();
				log.debug("CHMSLEJB--Inside try searchLapseRuleMap");
	
				al_resultObject = _oLapseRuleSL.searchLapseRuleMap(a_LLRMapSeqNbr);
			}
			catch (CreateException rex)
			{
				log.debug(rex.getMessage());
				throw new EElixirException(rex, "P1006");
			}
			catch (RemoteException rex)
			{
				log.debug(rex.getMessage());
				throw new EElixirException(rex, "P1006");
			}
			catch (EElixirException rex)
			{
				log.debug(rex.getMessage());
				throw rex;
			}
	
			log.debug("CHMSLEJB--returning back to LapseRuleMap action class" +
				al_resultObject);
	
			return al_resultObject;
		}
		
		public String searchLapseRuleMap(SearchData a_oResultObject)
				throws FinderException, EElixirException, RemoteException
		 {
			 String resultString = null;
			
			 EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
		     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
		     log.debug("CHMSLEJB--before Lookup searchLapseRuleMap");
		     _oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								 "LapseRuleSLHome"), LapseRuleSLHome.class);		

			 try
			 {				
				 _oLapseRuleSL = _oLapseRuleSLHome.create();
				 log.debug("CHMSLEJB--Inside try searchLapseRuleMap");
			 }
			 catch (CreateException cex)
			 {
				 log.exception(cex.getMessage());
				 throw new EElixirException(cex, "P1007");
			 }
			 catch (RemoteException rex)
			 {
				 log.exception(rex.getMessage());
				 throw new EElixirException(rex, "P1006");
			 }

			 try
			 {
				 resultString = _oLapseRuleSL.searchLapseRuleMap(a_oResultObject);
			 }
			 catch (RemoteException rex)
			 {
				 log.exception(rex.getMessage());
				 throw new EElixirException(rex, "P1006");
			 }
			 return resultString;
		 }
		 
		 
		 public void updateLapseRuleMap(ArrayList al_oLapseRuleMapResult)
				 throws CreateException, EElixirException
			 {
				 try
				 {
					EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
					CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
					log.debug("CHMSLEJB--before Lookup updateLapseRuleMap");
					_oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								"LapseRuleSLHome"), LapseRuleSLHome.class);

					_oLapseRuleSL = _oLapseRuleSLHome.create();
					 log.debug("CHMSLEJB--Inside try updateLapseRuleMap");
					_oLapseRuleSL.updateLapseRuleMap(al_oLapseRuleMapResult);
					log.debug("CHMSLEJB--after invoking updateLapseRuleMap");
				 }
				 catch (CreateException rex)
				 {
					 log.debug(rex.getMessage());
					 throw new EElixirException(rex, "P1006");
				 }
				 catch (RemoteException rex)
				 {
					 log.debug(rex.getMessage());

					 //throw new EElixirException(rex, "P1006");
					 throw new EElixirException(rex, "P1006");
				 }
				 catch (EElixirException rex)
				 {
					 log.debug(rex.getMessage());
					 throw rex;
				 }
			 }

	public ArrayList searchLapseRuleEffDate()
				 throws FinderException, EElixirException, RemoteException
	{
		ArrayList _oArrayList=new ArrayList();		
			EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
			log.debug("CHMSLEJB--before Lookup searchLapseRuleEffDate");
			_oLapseRuleSLHome = (LapseRuleSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								  "LapseRuleSLHome"), LapseRuleSLHome.class);								  
			log.debug("CHMSLEJB--After Lookup searchLapseRuleEffDate");
			try
			{
				_oLapseRuleSL = _oLapseRuleSLHome.create();
				log.debug("CHMSLEJB--Inside try searchLapseRuleEffDate");
				_oArrayList = _oLapseRuleSL.searchLapseRuleEffDate();
				
			}
			catch (CreateException rex)
			{
				log.debug(rex.getMessage());
				throw new EElixirException(rex, "P1006");
			}
			catch (RemoteException rex)
			{
				log.debug(rex.getMessage());
				throw new EElixirException(rex, "P1006");
			}
			catch (EElixirException rex)
			{
				log.debug(rex.getMessage());
				throw rex;
			}
	
			log.debug("CHMSLEJB--returning back to LapseRuleMap action class" +
		_oArrayList);
	
			return _oArrayList;
		}



 End of the commented code */


			public Long createAllocationMarker(AllocationMarkerResult a_AllocationMarkerResult)
					throws EElixirException, RemoteException
				{
					try
					{
						EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
						CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
						_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
									"MasterSLHome"), MasterSLHome.class);
						_oMasterSL = _oMasterSLHome.create();
						Long lAllocMarkerSeqNbr=_oMasterSL.createAllocationMarker(a_AllocationMarkerResult);

						//Long lTaxSeqNbr = _oMasterSL.createAllocationMarker(a_AllocationMarkerResult);

					return lAllocMarkerSeqNbr;
					}
					catch (CreateException ce)
					{
						throw new EElixirException(ce, "P1007");
					}
					catch (FinderException cex)
					{
						log.fatal("CHMSLEJB--inside finder exception");
						throw new EElixirException(cex, "P1007");
					}
					catch (EJBException ejbex)
					{
						throw (EElixirException) ejbex.getCausedByException();
					}
					catch (EElixirException eex)
					{
						throw eex;
					}
				}
				
				
			public AllocationMarkerResult searchAllocationMarker(Long a_lAllocMarkerSeqNbr)
					throws EElixirException, FinderException
				{
					AllocationMarkerResult oAllocationMarkerResult = null;

					try
					{
						EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
						CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
						_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
									"MasterSLHome"), MasterSLHome.class);
						_oMasterSL = _oMasterSLHome.create();
						oAllocationMarkerResult = _oMasterSL.searchAllocationMarker(a_lAllocMarkerSeqNbr);

						return oAllocationMarkerResult;
					}
					catch (CreateException ce)
					{
						throw new EElixirException(ce, "P1006");
					}
					catch (FinderException cex)
					{
						log.fatal("CHMSLEJB--inside finder exception");
						throw new EElixirException(cex, "P1006");
					}
					catch (RemoteException rex)
					{
						throw new EElixirException(rex, "P1006");
					}
					catch (EJBException ejbex)
					{
						throw (EElixirException) ejbex.getCausedByException();
					}
					catch (EElixirException eex)
					{
						throw eex;
					}
				}
				

			 public String searchAllocationMarker(SearchData a_oSearchData)
				 throws FinderException, EElixirException
			 {
				 String strResult = null;

				 try
				 {
					 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
					 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
					 _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								 "MasterSLHome"), MasterSLHome.class);
					 _oMasterSL = _oMasterSLHome.create();
					 strResult = _oMasterSL.searchAllocationMarker(a_oSearchData);
				 }
				 catch (CreateException cex)
				 {
					 log.fatal("CHMSLEJB--CreateException ");
					 throw new EElixirException(cex, "P1006");
				 }
				 catch (RemoteException cex)
				 {
					 log.fatal("CHMSLEJB--RemoteException ");
					 throw new EElixirException(cex, "P1006");
				 }

				 return strResult;
			 }


	public HashMap searchBankSortCd(String strBankCode)
        throws EElixirException, FinderException
    {
        log.debug("CHMSLEJB--Starting the searchBankSortCd method");

		HashMap  oHashMap = new HashMap();

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oAgentSLHome = (AgentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "AgentSLHome"), AgentSLHome.class);
            _oAgentSL = _oAgentSLHome.create();
			oHashMap = _oAgentSL.searchBankSortCd(strBankCode);
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        return oHashMap;
    }

public String searchRYCRuleMaster()throws FinderException, EElixirException, RemoteException
	{
    	String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oRYCRuleMasterSLHome = (RYCRuleMasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "RYCRuleMasterSLHome"), RYCRuleMasterSLHome.class);
        try
        {
            _oRYCRuleMasterSL = _oRYCRuleMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            resultString = _oRYCRuleMasterSL.searchRYCRuleMaster();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return resultString;
    	
	}
	
	public String searchRYCRuleMaster(SearchData a_oResultObject)
			 throws FinderException, EElixirException, RemoteException
	{
		String resultString = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oRYCRuleMasterSLHome = (RYCRuleMasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "RYCRuleMasterSLHome"), RYCRuleMasterSLHome.class);
        try
        {
            _oRYCRuleMasterSL = _oRYCRuleMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            resultString = _oRYCRuleMasterSL.searchRYCRuleMaster(a_oResultObject);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return resultString;


	}


  public RYCRuleMasterSearchResult searchRYCRuleMaster(long lRYCHdrSeqNbr)
			throws FinderException, EElixirException, RemoteException
  {
	RYCRuleMasterSearchResult oRYCRuleMasterSearchResult = null;
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oRYCRuleMasterSLHome = (RYCRuleMasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "RYCRuleMasterSLHome"), RYCRuleMasterSLHome.class);
	 try
        {
            _oRYCRuleMasterSL = _oRYCRuleMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            oRYCRuleMasterSearchResult = _oRYCRuleMasterSL.searchRYCRuleMaster(lRYCHdrSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return oRYCRuleMasterSearchResult;
  }


	public long createRYCRuleMaster(RYCRuleMasterSearchResult a_RYCRuleMasterSearchResult)
			 throws EJBException, EElixirException
	 {		 
		 long seqNo = 0;

		 try
		 {
			 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			 
			 _oRYCRuleMasterSLHome = (RYCRuleMasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "RYCRuleMasterSLHome"), RYCRuleMasterSLHome.class);
			  _oRYCRuleMasterSL = _oRYCRuleMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
			 seqNo = _oRYCRuleMasterSL.createRYCRuleMaster(a_RYCRuleMasterSearchResult);

			 return seqNo;
		 }
		 catch (CreateException cex)
		 {
			 log.debug("CHMSLEJB--inside create exception");
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 catch (EJBException ejbex)
		 {
			 log.debug("CHMSLEJB--inside ejb exception");
			 throw new EElixirException(ejbex, "P1007");
		 }
	 }

	 public void updateRYCRuleMaster(RYCRuleMasterSearchResult a_RYCRuleMasterSearchResult)
			 throws EJBException, EElixirException
	 {		 
	 try
		 {
			 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			 
			 _oRYCRuleMasterSLHome = (RYCRuleMasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "RYCRuleMasterSLHome"), RYCRuleMasterSLHome.class);
			  _oRYCRuleMasterSL = _oRYCRuleMasterSLHome.create();
            log.debug("CHMSLEJB--calling update rycrulemaster");
			 _oRYCRuleMasterSL.updateRYCRuleMaster(a_RYCRuleMasterSearchResult);

		 }
		 catch (CreateException cex)
		 {
			 log.debug("CHMSLEJB--inside create exception");
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 catch (EJBException ejbex)
		 {
			 log.debug("CHMSLEJB--inside ejb exception");
			 throw new EElixirException(ejbex, "P1007");
		 }
	 }
	
	 public void deleteRYCRuleMaster(Long rycHdrSeqNbr)
			 throws EJBException, EElixirException
	 {		 
	 try
		 {
			 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			 
			 _oRYCRuleMasterSLHome = (RYCRuleMasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "RYCRuleMasterSLHome"), RYCRuleMasterSLHome.class);
			  _oRYCRuleMasterSL = _oRYCRuleMasterSLHome.create();
            log.debug("CHMSLEJB--calling update rycrulemaster");
			 _oRYCRuleMasterSL.deleteRYCRuleMaster(rycHdrSeqNbr);

		 }
		 catch (CreateException cex)
		 {
			 log.debug("CHMSLEJB--inside create exception");
			 throw new EElixirException(cex, "P1007");
		 }
		 catch (RemoteException rex)
		 {
			 log.exception(rex.getMessage());
			 throw new EElixirException(rex, "P1006");
		 }
		 catch (EJBException ejbex)
		 {
			 log.debug("CHMSLEJB--inside ejb exception");
			 throw new EElixirException(ejbex, "P1007");
		 }
	 }

	public String searchManualOverride(SearchData a_oSearchData)
		throws FinderException, EElixirException
	{
		String strResult = null;

		try
		{
			log.debug("i am in searchManualOverride chmslejb");
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			_oManualOverrideSLHome = (ManualOverrideSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						"ManualOverrideSLHome"), ManualOverrideSLHome.class);
			_oManualOverrideSL = _oManualOverrideSLHome.create();
			log.debug("Before calling search Manual Override in session");
			strResult = _oManualOverrideSL.searchManualOverride(a_oSearchData);
		
		}
		catch (CreateException cex)
		{
			log.fatal("CHMSLEJB--CreateException ");
			throw new EElixirException(cex, "P1006");
		}
		catch (RemoteException cex)
		{
			log.fatal("CHMSLEJB--RemoteException ");
			throw new EElixirException(cex, "P1006");
		}

		return strResult;
	}
	
//	Anup_JAN10_REL_FSD_TCU-AGN-1_Manual_Override_changes_Starts
	
	public ArrayList searchManualOverride(String strManualOverrideSeqNbr)
			throws FinderException, EElixirException
		{
			log.debug("CHMSLEJB----SearchManualOverride----In SearchManualOverride");
			ArrayList resultObject =  new ArrayList();
			log.debug("CHMSLEJB----SearchManualOverride----Before getFactory");

			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			log.debug("CHMSLEJB----SearchManualOverride----Before getPropertyUtil");

			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			log.debug("CHMSLEJB----SearchManualOverride----before Lookup");
			_oManualOverrideSLHome = (ManualOverrideSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
						"ManualOverrideSLHome"), ManualOverrideSLHome.class);
			log.debug("CHMSLEJB----SearchManualOverride----After Lookup");

			try
			{
				_oManualOverrideSL = _oManualOverrideSLHome.create();
				log.debug("CHMSLEJB----SearchManualOverride----Inside try");
				resultObject = _oManualOverrideSL.searchManualOverride(strManualOverrideSeqNbr);
				log.debug("after Getting the Result Object from chmsl ejb---------->"+resultObject);
			}
			catch (CreateException rex)
			{
				log.debug("CHMSLEJB--SearchManualOverride--In CreateException of CHMSLEJB");
				log.debug(rex.getMessage());
				throw new EElixirException(rex, "P7504");
			}
			catch (RemoteException rex)
			{
				log.debug("CHMSLEJB--SearchManualOverride--In RemoteException of CHMSLEJB");
				log.debug(rex.getMessage());
				throw new EElixirException(rex, "P7504");
			}
			catch (EElixirException rex)
			{
				log.debug(
					"CHMSLEJB--SearchManualOverride--In EELixirException of CHMSLEJB");
				log.debug(rex.getMessage());
				throw rex;
			}

			return resultObject;
		}
		public ArrayList createManualOverride(ArrayList al_ManualOverrideResult)
						throws EElixirException, RemoteException
					{
						try
						{   ArrayList al_ManualOverrideSeqNbr=new ArrayList();
							EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
							CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
							_oManualOverrideSLHome = (ManualOverrideSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
										"ManualOverrideSLHome"), ManualOverrideSLHome.class);
							_oManualOverrideSL = _oManualOverrideSLHome.create();
							 al_ManualOverrideSeqNbr=_oManualOverrideSL.createManualOverride(al_ManualOverrideResult);
							log.debug("CHMSLEJB--createManualOverride--lManualOverrideSeqNbr"+al_ManualOverrideSeqNbr);							
						return al_ManualOverrideSeqNbr;
						}
						catch (CreateException ce)
						{
							throw new EElixirException(ce, "P1007");
						}
						catch (FinderException cex)
						{
							log.fatal("CHMSLEJB--inside finder exception");
							throw new EElixirException(cex, "P1007");
						}
						catch (EJBException ejbex)
						{
							throw (EElixirException) ejbex.getCausedByException();
						}
						catch (EElixirException eex)
						{
							throw eex;
						}
					}
	
	public ArrayList getManualOverrideDetails(String strAgentCd)
				throws EElixirException,FinderException
			{
				log.debug("CHMSLEJB----getManualOverrideDetails----In getManualOverrideDetails");

				ArrayList alresultObject = new ArrayList();
				log.debug("CHMSLEJB----getManualOverrideDetails----Before getFactory");
				EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
				log.debug("CHMSLEJB----getManualOverrideDetails----Before getPropertyUtil");
				CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
				log.debug("CHMSLEJB----getManualOverrideDetails----before Lookup");
				_oManualOverrideSLHome = (ManualOverrideSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
							"ManualOverrideSLHome"), ManualOverrideSLHome.class);
				log.debug("CHMSLEJB----getManualOverrideDetails----After Lookup");

				try
				{
					_oManualOverrideSL = _oManualOverrideSLHome.create();
					log.debug("CHMSLEJB----getManualOverrideDetails----Inside try");

					alresultObject = _oManualOverrideSL.getManualOverrideDetails(strAgentCd);
					log.debug("after Getting the Result Object from chmsl ejb---------->"+alresultObject);
				}
				catch (CreateException rex)
				{
					log.debug("CHMSLEJB--getManualOverrideDetails--In CreateException of CHMSLEJB");
					log.debug(rex.getMessage());
					throw new EElixirException(rex, "P7504");
				}
				
				catch (RemoteException rex)
				{
					log.debug("CHMSLEJB--getManualOverrideDetails--In RemoteException of CHMSLEJB");
					log.debug(rex.getMessage());
					throw new EElixirException(rex, "P7504");
				}
				catch (EElixirException rex)
				{
					log.debug(
						"CHMSLEJB--getManualOverrideDetails--In EELixirException of CHMSLEJB");
					log.debug(rex.getMessage());
					throw rex;
				}

				return alresultObject;
			}
	
			public ArrayList updateManualOverride(ArrayList al_ManualOverrideResult)
							throws RemoteException, EElixirException,CreateException
			{
				ArrayList al_ResultSet = new ArrayList();
				try
								 {
									EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
									CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();			  
									log.debug("CHMSLEJB--before Lookup");
									_oManualOverrideSLHome = (ManualOverrideSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
												"ManualOverrideSLHome"), ManualOverrideSLHome.class);

									_oManualOverrideSL = _oManualOverrideSLHome.create();
									 log.debug("CHMSLEJB--Inside try");
									 al_ResultSet=_oManualOverrideSL.updateManualOverride(al_ManualOverrideResult);
									log.debug("CHMSLEJB--after invoking updateManualOverride");
									return al_ResultSet;
								 }
								 catch (CreateException rex)
								 {
									 log.debug(rex.getMessage());
									 throw new EElixirException(rex, "P1006");
								 }
								 catch (RemoteException rex)
								 {
									 log.debug(rex.getMessage());
									 //throw new EElixirException(rex, "P1006");
									 throw new EElixirException(rex, "P1006");
								 }
								 catch (EElixirException rex)
								 {
									 log.debug(rex.getMessage());
									 throw rex;
								 }
								
			}
//	Anup_JAN10_REL_FSD_TCU-AGN-1_Manual_Override_changes_Ends
			public BonusSlabResult searchBonusSlab(Long a_lBonusDtlSeqNbr)
						throws FinderException, EElixirException
					{
						log.debug("CHMSLEJB----searchBonusSlab----In searchBonusSlab");

						BonusSlabResult resultObject = null;
						log.debug("CHMSLEJB----searchBonusSlab----Before getFactory");

						EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
						log.debug("CHMSLEJB----searchBonusSlab----Before getPropertyUtil");

						CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
						log.debug("CHMSLEJB----searchBonusSlab----before Lookup");
						_oBonusSLHome = (BonusSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
									"BonusSLHome"), BonusSLHome.class);
						log.debug("CHMSLEJB----searchBonusSlab----After Lookup");

						try
						{
							_oBonusSL = _oBonusSLHome.create();
							log.debug("CHMSLEJB----searchBonusSlab----Inside try");

							resultObject = _oBonusSL.searchBonusSlab(a_lBonusDtlSeqNbr);
							log.debug("after Getting the Result Object from chmsl ejb---------->"+resultObject);
						}
						catch (CreateException rex)
						{
							log.debug("CHMSLEJB--searchBonusSlab--In CreateException of CHMSLEJB");
							log.debug(rex.getMessage());
							throw new EElixirException(rex, "P7504");
						}
						catch (RemoteException rex)
						{
							log.debug("CHMSLEJB--searchBonusSlab--In RemoteException of CHMSLEJB");
							log.debug(rex.getMessage());
							throw new EElixirException(rex, "P7504");
						}
						catch (EElixirException rex)
						{
							log.debug(
								"CHMSLEJB--searchBonusSlab--In EELixirException of CHMSLEJB");
							log.debug(rex.getMessage());
							throw rex;
						}

						return resultObject;
					}

			public void addUpdateBonusSlab(BonusSlabResult a_oBonusSlabResult)
				   throws EElixirException, RemoteException
			   {
				   try
				   {
					   EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
					   CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
					   _oBonusSLHome = (BonusSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
								   "BonusSLHome"), BonusSLHome.class);
					   _oBonusSL = _oBonusSLHome.create();
					   _oBonusSL.addUpdateBonusSlab(a_oBonusSlabResult);
				   }
				   catch (CreateException ce)
				   {
					   throw new EElixirException(ce, "P1007");
				   }
				   catch (EJBException ejbex)
				   {
					   throw (EElixirException) ejbex.getCausedByException();
				   }
				   catch (EElixirException eex)
				   {
					   throw eex;
				   }
			   }
			public AgentResult searchProhibitJVPosting(String strAgentCd)
				   throws EElixirException
			   {
				   try
				   {
					   _oAgentSL = getAgentSL("AgentSLHome",
					AgentSLHome.class);
					AgentResult oAgentResult = _oAgentSL.searchProhibitJVPosting(strAgentCd);
					   return oAgentResult;
				   }
				   catch (CreateException ce)
				   {
					   throw new EElixirException(ce, "P1007");
				   }
				   catch (RemoteException rex)
				   {
					   throw new EElixirException(rex, "P1006");
				   }
				   catch (EJBException ejbex)
				   {
					   throw (EElixirException) ejbex.getCausedByException();
				   }
				   catch (EElixirException eex)
				   {
					   throw eex;
				   }
			   }
			   
			public void updateProhibitJVPosting(AgentResult oAgentResult)
					throws EElixirException
				{
					try
					{
						_oAgentSL = getAgentSL("AgentSLHome",
				   AgentSLHome.class);
				   _oAgentSL.updateProhibitJVPosting(oAgentResult);
					}
					catch (CreateException ce)
					{
						throw new EElixirException(ce, "P1007");
					}
					catch (RemoteException rex)
					{
						throw new EElixirException(rex, "P1006");
					}
					catch (EJBException ejbex)
					{
						throw (EElixirException) ejbex.getCausedByException();
					}
					catch (EElixirException eex)
					{
						throw eex;
					}
				}
			//Arun_FSGOASSOCIATE_REL8.0 Starts
			public ApplicationResult searchGOApplicability(ApplicationResult oApplicationResult) 
			   throws EElixirException
			   {
				 try
				  {
				  _oAgentSL = getAgentSL("AgentSLHome",
			       AgentSLHome.class);
				  oApplicationResult=_oAgentSL.searchGOApplicability(oApplicationResult);
				  return oApplicationResult;
				  }
				catch (CreateException ce)
				   {
					   throw new EElixirException(ce, "P1007");
				   }
				   catch (RemoteException rex)
				   {
					   throw new EElixirException(rex, "P1006");
				   }
				   catch (EJBException ejbex)
				   {
					   throw (EElixirException) ejbex.getCausedByException();
				   }
				   catch (EElixirException eex)
				   {
					   throw eex;
				   }
				
			   }
	// Sridhar_FSAutSus_REL8.0 Strats
			
			/*<CODE_TAG: FS_Automated_Suspension1.1 DONT_UPDATE_chm_auto_suspension_table Dated: 3/6/2011 Starts>
			 * public void updateBankAccount(ApplicationResult oApplicationResult, String strAgentCd)
	        throws EElixirException
	        {
				log.debug("in updateBankAccount of chmslejb");
				
				boolean bOverrideSuspension=oApplicationResult.getAgentResult().getSuspendStatus();
				String strOverrideRemarks=oApplicationResult.getAgentResult().getStrOverrideRemarks();
				String strCreated=oApplicationResult.getUserId();
				
				try
		        {
		            _oApplicationSL = getApplicationSL("ApplicationSLHome",
		                    ApplicationSLHome.class);
		            _oApplicationSL.updateBankAccount(oApplicationResult,strAgentCd);
		            
		        }
		        catch (CreateException ce)
		        {
		            throw new EElixirException(ce, "P1007");
		        }
		        catch (RemoteException rex)
		        {
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (EJBException ejbex)
		        {
		            throw (EElixirException) ejbex.getCausedByException();
		        }
		        catch (EElixirException eex)
		        {
		            throw eex;
		        } 
				
			}
			<CODE_TAG: FS_Automated_Suspension1.1 DONT_UPDATE_chm_auto_suspension_table Dated: 3/6/2011 Ends>
			*/

			// Sridhar_FSAutSus_REL8.0 Ends
			//Arun_Everest_Segmentation_Start
		public ArrayList searchChannelSegments(String a_cChannelType)
	       throws FinderException, EElixirException
	    {
	        ArrayList _oSegmentationList = null;
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        log.debug("CHMSLEJB--before Lookup");
	        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "SegmentSLHome"), SegmentSLHome.class);
	        log.debug("CHMSLEJB--After Lookup");

	        try
	        {
	            _oSegmentSL = _oSegmentSLHome.create();
	            log.debug("CHMSLEJB--Inside try");
	            _oSegmentationList = _oSegmentSL.searchChannelSegments(a_cChannelType);
	        }
	        catch (CreateException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	        catch (RemoteException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	        catch (EElixirException rex)
	        {
	            log.exception(rex.getMessage());
	            throw rex;
	        }

	        return _oSegmentationList;
	    }
		
		public void updateSegmentMaster(ArrayList a_alSegmentMasterList)
	       throws FinderException, EElixirException
	       {
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        log.debug("CHMSLEJB--before Lookup");
	        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "SegmentSLHome"), SegmentSLHome.class);
	        log.debug("CHMSLEJB--After Lookup");
	        try
	        {
	            _oSegmentSL = _oSegmentSLHome.create();
	            log.debug("CHMSLEJB--Inside try");
	            _oSegmentSL.updateSegmentMaster(a_alSegmentMasterList);
	        }
	        catch (CreateException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	        catch (RemoteException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	        catch (EElixirException rex)
	        {
	            log.exception(rex.getMessage());
	            throw rex;
	        }
	        
	       }
		
     public SegmentCriteriaResult searchSegmentCriteria(String a_strSegmentType)
	       throws FinderException,EElixirException
	    {
	        //ArrayList _oSegmentationList = null;
    	 SegmentCriteriaResult _oSegmentCriteriaResult=null;
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        log.debug("CHMSLEJB--before Lookup");
	        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "SegmentSLHome"), SegmentSLHome.class);
	        log.debug("CHMSLEJB--After Lookup");

	        try
	        {
	            _oSegmentSL = _oSegmentSLHome.create();
	            log.debug("CHMSLEJB--Inside try");
	            _oSegmentCriteriaResult = _oSegmentSL.searchSegmentCriteria(a_strSegmentType);
	        }
	        catch (CreateException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	        catch (RemoteException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	        catch (EElixirException rex)
	        {
	            log.exception(rex.getMessage());
	            throw rex;
	        }

	        return _oSegmentCriteriaResult;
	    }
     public void updateSegmentCriteria(SegmentCriteriaResult a_oSegmentCriteriaResult)
     throws FinderException, EElixirException
     {
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
      CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
      log.debug("CHMSLEJB--before Lookup");
      _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                  "SegmentSLHome"), SegmentSLHome.class);
      log.debug("CHMSLEJB--After Lookup");
      try
      {
          _oSegmentSL = _oSegmentSLHome.create();
          log.debug("CHMSLEJB--Inside try");
          _oSegmentSL.updateSegmentCriteria(a_oSegmentCriteriaResult);
      }
      catch (CreateException rex)
      {
          log.exception(rex.getMessage());
          throw new EElixirException(rex, "P1006");
      }
      catch (RemoteException rex)
      {
          log.exception(rex.getMessage());
          throw new EElixirException(rex, "P1006");
      }
      catch (EElixirException rex)
      {
          log.exception(rex.getMessage());
          throw rex;
      }
      
     }
     
//		Arun_Everest_Segmentation_End
			//Sunaina_Everest_Segmentation_inclexl_field_Ends
			//<!--sunaina_Everest_ManualSegmentation_Starts-->
			public Long ManualSegmentCreate(ManualSegmentResult oManualSegmentResult)
	        throws FinderException, EElixirException
	    {
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "SegmentSLHome"), SegmentSLHome.class);
	        log.debug("CHMSLEJB--Inside try");

	        try
	        {
	        	_oSegmentSL = _oSegmentSLHome.create();
	        	Long lSeqNbr=_oSegmentSL.ManualSegmentCreate(oManualSegmentResult);
	        	return lSeqNbr;
	        }
	        catch (CreateException cex)
	        {
	            log.exception(cex.getMessage());
	            throw new EElixirException(cex, "P1007");
	        }
	        catch (RemoteException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	       	        
	    }
			//<!--sunaina_Everest_ManualSegmentation_Ends-->

			//<!--sunaina_Everest_Segmentation_For_ManualSegmentation_Starts-->
			public ManualSegmentResult getManualSegmentResult(String a_strAgentCd)
	        throws FinderException, EElixirException
	    {
	        log.debug(
	            "CHMSLEJB----getManualSegmentResult----In getManualSegmentResult");

	        ManualSegmentResult resultObject = null;
	        log.debug(
	            "CHMSLEJB----getManualSegmentResult----Before getFactory");

	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        log.debug(
	            "CHMSLEJB----getManualSegmentResult----Before getPropertyUtil");

	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        log.debug(
	            "CHMSLEJB----getManualSegmentResult----before Lookup");
	        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "SegmentSLHome"), SegmentSLHome.class);
	        log.debug(
	            "CHMSLEJB----getManualSegmentResult----After Lookup");

	        try
	        {
	        	_oSegmentSL = _oSegmentSLHome.create();
	            log.debug(
	                "CHMSLEJB----getManualSegmentResult----Inside try");

	            resultObject = _oSegmentSL.getManualSegmentResult(a_strAgentCd);
	        }
	        catch (CreateException rex)
	        {
	            log.debug(
	                "CHMSLEJB--getManualSegmentResult--In CreateException of CHMSLEJB");
	            log.debug(rex.getMessage());
	            throw new EElixirException(rex, "P3532");
	        }
	        catch (RemoteException rex)
	        {
	            log.debug(
	                "CHMSLEJB--getManualSegmentResult--In RemoteException of CHMSLEJB");
	            log.debug(rex.getMessage());
	            throw new EElixirException(rex, "P3532");
	        }
	        catch (EElixirException rex)
	        {
	            log.debug(
	                "CHMSLEJB--getManualSegmentResult--In EELixirException of CHMSLEJB");
	            log.debug(rex.getMessage());
	            throw rex;
	        }

	        return resultObject;
	    }
		//<!--sunaina_Everest_Segmentation_For_ManualSegmentation_Ends-->
			//Arun_Everest_ManualSegment_start
			public ManualSegmentResult searchManualSegment(Long a_lSeqNo)
	        throws FinderException, EElixirException
	        {
	          log.debug(
	            "CHMSLEJB----searchManualSegment----In searchManualSegment");

	           ManualSegmentResult oManualSegmentResult = null;
	          log.debug(
	            "CHMSLEJB----searchManualSegment----Before getFactory");

	           EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	          log.debug(
	            "CHMSLEJB----searchManualSegment----Before getPropertyUtil");

	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        log.debug(
	            "CHMSLEJB----searchManualSegment----before Lookup");
	        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "SegmentSLHome"), SegmentSLHome.class);
	        log.debug(
	            "CHMSLEJB----searchManualSegment----After Lookup");

	        try
	        {
	        	_oSegmentSL = _oSegmentSLHome.create();
	            log.debug(
	                "CHMSLEJB----searchManualSegment----Inside try");

	            oManualSegmentResult = _oSegmentSL.searchManualSegment(a_lSeqNo);
	        }
	        catch (CreateException rex)
	        {
	            log.debug(
	                "CHMSLEJB--searchManualSegment--In CreateException of CHMSLEJB");
	            log.debug(rex.getMessage());
	            throw new EElixirException(rex, "P3532");
	        }
	        catch (RemoteException rex)
	        {
	            log.debug(
	                "CHMSLEJB--searchManualSegment--In RemoteException of CHMSLEJB");
	            log.debug(rex.getMessage());
	            throw new EElixirException(rex, "P3532");
	        }
	        catch (EElixirException rex)
	        {
	            log.debug(
	                "CHMSLEJB--searchManualSegment--In EELixirException of CHMSLEJB");
	            log.debug(rex.getMessage());
	            throw rex;
	        }

	        return oManualSegmentResult;
	    }
		public void ManualSegmentUpdate(ManualSegmentResult oManualSegmentResult)
	        throws FinderException, EElixirException
	    {
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "SegmentSLHome"), SegmentSLHome.class);
	        log.debug("CHMSLEJB--Inside try");

	        try
	        {
	        	_oSegmentSL = _oSegmentSLHome.create();
	        	_oSegmentSL.ManualSegmentUpdate(oManualSegmentResult);
	        	
	        }
	        catch (CreateException cex)
	        {
	            log.exception(cex.getMessage());
	            throw new EElixirException(cex, "P1007");
	        }
	        catch (RemoteException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	       	        
	    }
			//Arun_Everest_ManualSegment_end
			//Sunaina_Everest_Segmentation_Start  // code modified by anup for pending pagination for Amid_segmentation
			public SearchData searchSegmentWeightage(SearchData strParameter)
		       throws FinderException, EElixirException
		    {
				SearchData _oSegmentWeightageList = null;
		        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		        log.debug("CHMSLEJB--before Lookup");
		        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
		                    "SegmentSLHome"), SegmentSLHome.class);
		        log.debug("CHMSLEJB--After Lookup");

		        try
		        {
		            _oSegmentSL = _oSegmentSLHome.create();
		            log.debug("CHMSLEJB--Inside try");
		            _oSegmentWeightageList = _oSegmentSL.searchSegmentWeightage(strParameter);
		        }
		        catch (CreateException rex)
		        {
		            log.exception(rex.getMessage());
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (RemoteException rex)
		        {
		            log.exception(rex.getMessage());
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (EElixirException rex)
		        {
		            log.exception(rex.getMessage());
		            throw rex;
		        }

		        return _oSegmentWeightageList;
		    }

			public void updateSegmentWeightage(ArrayList a_oSegmentWeightageList)
		       throws FinderException, EElixirException
		       {
				EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		        log.debug("CHMSLEJB--before Lookup");
		        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
		                    "SegmentSLHome"), SegmentSLHome.class);
		        log.debug("CHMSLEJB--After Lookup");
		        try
		        {
		            _oSegmentSL = _oSegmentSLHome.create();
		            log.debug("CHMSLEJB--Inside try");
		            _oSegmentSL.updateSegmentWeightage(a_oSegmentWeightageList);
		        }
		        catch (CreateException rex)
		        {
		            log.exception(rex.getMessage());
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (RemoteException rex)
		        {
		            log.exception(rex.getMessage());
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (EElixirException rex)
		        {
		            log.exception(rex.getMessage());
		            throw rex;
		        }

		       }
//			Sunaina_Everest_Segmentation_End
//Sunaina_Everest_Segmentation_inclexl_field_Starts
			public SegmentWeightageResult getIncExcSearch(String strParameter)
	        throws FinderException, EElixirException
	    {

				SegmentWeightageResult oSegmentWeightageResult = null;

	        try
	        {
	            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	            _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                "SegmentSLHome"), SegmentSLHome.class);
	            _oSegmentSL = _oSegmentSLHome.create();
	            log.debug("CHMSLEJB--Inside try");
	            oSegmentWeightageResult = _oSegmentSL.getIncExcSearch(strParameter);
	            return oSegmentWeightageResult;
	        }
	        catch (CreateException cex)
	        {
	            log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
	                cex);
	            throw new EElixirException(cex.getMessage());
	        }
	        catch (RemoteException rex)
	        {
	            log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
	                rex);
	            throw new EElixirException(rex.getMessage());
	        }
	    }
			//Sunaina_Everest_Segmentation_inclexl_field_Ends

		// Santosh_CBP Starts
	public ArrayList searchCbpMaster(String strChannelType)
			throws FinderException, EElixirException {

		ArrayList _oCbpMasterList = null;
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		log.debug("CHMSLEJB--before Lookup");

		_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(
				oCHMPropertyUtil.getCHMProperty("MasterSLHome"),
				MasterSLHome.class);
		log.debug("CHMSLEJB--After Lookup");

		try {
			_oMasterSL = _oMasterSLHome.create();
			log.debug("CHMSLEJB--Inside try");
			_oCbpMasterList = _oMasterSL.searchCbpMaster(strChannelType);

		} catch (CreateException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (EElixirException rex) {
			log.exception(rex.getMessage());
			throw rex;
		}

		return _oCbpMasterList;
	}

	/**
	 * Updating CbpMaster Info
	 * 
	 * @param a_alCbpMasterList
	 * @throws FinderException
	 * @throws EElixirException
	 *             Santosh Pandya
	 */
	public void updateCbpMaster(ArrayList a_alCbpMasterList)
			throws FinderException, EElixirException {

		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		log.debug("CHMSLEJB--before Lookup");

		_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(
				oCHMPropertyUtil.getCHMProperty("MasterSLHome"),
				MasterSLHome.class);

		try {

			_oMasterSL = _oMasterSLHome.create();
			log.debug("CHMSLEJB--Inside try");
			_oMasterSL.updateCbpMaster(a_alCbpMasterList);
			
		} catch (CreateException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (EElixirException rex) {
			log.exception(rex.getMessage());
			throw rex;
		}

	}

	/**
	 * for Loading AgencyCode according to Channel type
	 * 
	 * @param strChannelType
	 * @return CbpResult
	 * @throws FinderException
	 * @throws EJBException
	 * @throws EElixirException
	 */
	public CbpResult searchCbpChannel(String strChannelType)
			throws FinderException, EJBException, EElixirException {

		CbpResult oCbpResult = null;
		try {
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil
					.getPropertyUtil();
			_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(
					oCHMPropertyUtil.getCHMProperty("MasterSLHome"),
					MasterSLHome.class);
			_oMasterSL = _oMasterSLHome.create();
			oCbpResult = _oMasterSL.searchCbpChannel(strChannelType);
		} catch (CreateException cex) {
			log.exception(cex.getMessage());
			throw new EElixirException(cex, "P1007");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (FinderException cex) {
			log.debug("CHMSLEJB--inside finder exception");
			throw new EElixirException(cex, "P1007");
		} catch (EJBException ejbex) {
			log.debug("CHMSLEJB--inside ejb exception");
			throw new EElixirException(ejbex, "P1007");
		}
		return oCbpResult;
	}
//	FSD_AGN-59_Export to excel and Last status change date.doc Added  by Anup starts	
	
	 public String searchAgentContractExcel(String a_strAgentCd,
		        Short nIsWritingAgent) throws FinderException, EElixirException
		    {  
		    	log.debug("CHMSLEJB--AgentContractDetailResult-- starts >>>");
		        String oAgentContractDetailResult = null;

		        try
		        {
		            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
		            oAgentContractDetailResult = _oAgentSL.searchAgentContractExcel(a_strAgentCd,
		                    nIsWritingAgent);
		        log.debug("CHMSLEJB--AgentContractDetailResult-- Ends >>>");
		            return oAgentContractDetailResult;
		        }
		        catch (CreateException cex)
		        {
		            throw new EElixirException(cex.getMessage());
		        }
		        catch (RemoteException rex)
		        {
		            throw new EElixirException(rex.getMessage());
		        }
		    }
	 
//Ends	 
//	AMID_IRDA_RECORDS_PH2_START 
	public IrdaRecordResult searchIrdaTrainingDetails(String a_strClientCd,long a_lApplcSeqNbr)throws RemoteException, EElixirException
	 {
		
		 IrdaRecordResult _oIrdaRecordResult=null;
		 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	     log.debug("CHMSLEJB--before Lookup");
	     _oIrdaRecordSLHome = (IrdaRecordSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	     "IrdaRecordSLHome"), IrdaRecordSLHome.class);
	     log.debug("CHMSLEJB--After Lookup >> "+_oIrdaRecordSLHome);
	     try
	     { 
	    	 _oIrdaRecordSL = _oIrdaRecordSLHome.create();
	         log.debug("CHMSLEJB--Inside try");         
	         _oIrdaRecordResult = _oIrdaRecordSL.searchIrdaTrainingDetails(a_strClientCd,a_lApplcSeqNbr);
	     }
	     catch (CreateException rex)
	     {
	         log.exception(rex.getMessage());
	         throw new EElixirException(rex, "P1006");
	     }
	     catch (RemoteException rex)
	     {
	         log.exception(rex.getMessage());
	         throw new EElixirException(rex, "P1006");
	     }
	     catch (EElixirException rex)
	     {
	         log.exception(rex.getMessage());
	         throw rex;
	     } catch (FinderException efx) {
	    	 log.exception(efx.getMessage());
	         throw new EElixirException(efx, "P1006");
		}

	     return _oIrdaRecordResult;
		
	 }
	
	public void updateIrdaRecord(IrdaRecordResult a_oIrdaRecordResult)
	throws RemoteException, FinderException, EElixirException
	{
		
	 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oIrdaRecordSLHome = (IrdaRecordSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "IrdaRecordSLHome"), IrdaRecordSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
     try
     {
         _oIrdaRecordSL = _oIrdaRecordSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oIrdaRecordSL.updateIrdaRecord(a_oIrdaRecordResult);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }
     
    }
//	AMID_IRDA_RECORDS_PH2_END
	//Prabhat_Bounce_charge_Exemption_FIN_68 start
	
	public BounceChargesExcemptionResult searchBounceChargesExcemptionDetails(String strAgentCd,long a_lApplcSeqNbr) throws RemoteException, EElixirException
	{

		BounceChargesExcemptionResult _oBounceChargesExcemptionResult=null;
		
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	    CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	    log.debug("CHMSLEJB--before Lookup --BounceChargesExcemption search");
	    _oBounceChargesExcemptionSLHome = (BounceChargesExcemptionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("BounceChargesExcemptionSLHome"), BounceChargesExcemptionSLHome.class);
	    log.debug("CHMSLEJB--After Lookup >> "+_oBounceChargesExcemptionSLHome);
	    
	    try
	     { 
	    	 _oBounceChargesExcemptionSL = _oBounceChargesExcemptionSLHome.create();
	         log.debug("CHMSLEJB--Inside try --BounceChargesExcemption calling search");         
	         _oBounceChargesExcemptionResult = _oBounceChargesExcemptionSL.searchBounceChargesExcemptionDetails(strAgentCd,a_lApplcSeqNbr);
	     }
	     catch (CreateException rex)
	     {
	         log.exception(rex.getMessage());
	         throw new EElixirException(rex, "apre405");
	     }
	     catch (RemoteException rex)
	     {
	         log.exception(rex.getMessage());
	         throw new EElixirException(rex, "apre405");
	     }
	     catch (EElixirException rex)
	     {
	         log.exception(rex.getMessage());
	         throw rex;
	     } 
		
		return _oBounceChargesExcemptionResult;
		
	}
	
	
	public void updateBounceChargesExcemption(BounceChargesExcemptionResult a_oBounceChargesExcemptionResult)throws RemoteException,  EElixirException
	{
		 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	     log.debug("CHMSLEJB--before Lookup --BounceChargesExcemption Update");
	     _oBounceChargesExcemptionSLHome = (BounceChargesExcemptionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                 "BounceChargesExcemptionSLHome"), BounceChargesExcemptionSLHome.class);
	     log.debug("CHMSLEJB--After Lookup--BounceChargesExcemption Update");
	     try
	     {
	         _oBounceChargesExcemptionSL = _oBounceChargesExcemptionSLHome.create();
	         log.debug("CHMSLEJB--Inside try-- BounceChargesExcemption calling update");
	         _oBounceChargesExcemptionSL.updateBounceChargesExcemption(a_oBounceChargesExcemptionResult);
	     }
	     catch (CreateException rex)
	     {
	         log.exception(rex.getMessage());
	         throw new EElixirException(rex, "apre405");
	     }
	     catch (RemoteException rex)
	     {
	         log.exception(rex.getMessage());
	         throw new EElixirException(rex, "apre405");
	     }
	     catch (EElixirException rex)
	     {
	         log.exception(rex.getMessage());
	         throw rex;
	     }
		
		
	}
	
	

	//Prabhat_Bounce_charge_Exemption_FIN_68 End	
				//sunaina_starts

			public AgentSegmentHistoryResult searchAgentHistory(String a_strAgentCd) throws FinderException, EElixirException
			    {
				AgentSegmentHistoryResult oAgentSegmentHistoryResult = null;

			        try
			        {
			            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
			            oAgentSegmentHistoryResult = _oAgentSL.searchAgentHistory(a_strAgentCd);

			            return oAgentSegmentHistoryResult;
			        }
			        catch (CreateException cex)
			        {
			            throw new EElixirException(cex.getMessage());
			        }
			        catch (RemoteException rex)
			        {
			            throw new EElixirException(rex.getMessage());
			        }
			    }

	//Sunaina_Everest_Segmentation_PhaseII_Starts
	public GpaStandardMasterResult searchGpaStandards(long a_strSeqNbr,String a_strParameter)
    throws FinderException,EElixirException
 {
		GpaStandardMasterResult _oGpaStandardMasterResult=null;
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oGpaSLHome = (GpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "GpaSLHome"), GpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");

     try
     {
         _oGpaSL = _oGpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oGpaStandardMasterResult = _oGpaSL.searchGpaStandards(a_strSeqNbr,a_strParameter);
         return _oGpaStandardMasterResult;
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }


 }
	/**
	 *
	 * @param a_strParameter
	 * @return
	 * @throws FinderException
	 * @throws EElixirException
	 */
	public GpaCriteriaMasterResult searchGpaCriteria(long a_strSeqNbr,String a_strParameter)
    throws FinderException,EElixirException
 {
		ArrayList _oGpaList=null;
		GpaCriteriaMasterResult _oGpaCriteriaMasterResult=null;
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oGpaSLHome = (GpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "GpaSLHome"), GpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");


     try
     {
         _oGpaSL = _oGpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oGpaCriteriaMasterResult = _oGpaSL.searchGpaCriteria(a_strSeqNbr,a_strParameter);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }
     log.debug("received result _oGpaCriteriaMasterResult"+_oGpaCriteriaMasterResult);
     return _oGpaCriteriaMasterResult;
 }

	public ArrayList searchDesignationGpa(String a_strDesignation)
    throws FinderException, EElixirException
 {
     ArrayList _oGpaList = null;
     try
     {
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oGpaSLHome = (GpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "GpaSLHome"), GpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");


    	 _oGpaSL = _oGpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oGpaList = _oGpaSL.searchDesignationGpa(a_strDesignation);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }

     return _oGpaList;
 }

	public void updateGpa(ArrayList _oGpaList)
    throws FinderException, EElixirException
    {
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oGpaSLHome = (GpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
     "GpaSLHome"), GpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
     try
     {
    	 _oGpaSL = _oGpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oGpaSL.updateGpa(_oGpaList);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }

    }

	public void updateGpaStandard(GpaStandardMasterResult _oGpaStandardMasterResult)
    throws FinderException, EElixirException
    {
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oGpaSLHome = (GpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
     "GpaSLHome"), GpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
     try
     {
    	 _oGpaSL = _oGpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oGpaSL.updateGpaStandard(_oGpaStandardMasterResult);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }

    }

	public void updateGpaCriteria(GpaCriteriaMasterResult _oGpaCriteriaMasterResult)
    throws FinderException, EElixirException
    {
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oGpaSLHome = (GpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
     "GpaSLHome"), GpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
     try
     {
    	 _oGpaSL = _oGpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oGpaSL.updateGpaCriteria(_oGpaCriteriaMasterResult);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }

    }

	public void copyDesignationGpa(String a_strDesignation,String a_strInputDesg,String a_strUserId)
    throws FinderException, EElixirException
 {
     ArrayList _oGpaList = null;
     try
     {
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oGpaSLHome = (GpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "GpaSLHome"), GpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");


    	 _oGpaSL = _oGpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oGpaSL.copyDesignationGpa(a_strDesignation,a_strInputDesg,a_strUserId);
         log.debug("return from gpasl");
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }


 }
//	Amid_CSA_CPA_Start
	
	public ArrayList searchCsaCpa(String a_agentType)
       throws FinderException, EElixirException
    {
		ArrayList _oCsaCpaList = null;
		        
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        _oCsaCpaSLHome = (CsaCpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "CsaCpaSLHome"), CsaCpaSLHome.class);
        log.debug("CHMSLEJB--After Lookup");

        try
        {
            _oCsaCpaSL = _oCsaCpaSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oCsaCpaList = _oCsaCpaSL.searchCsaCpa(a_agentType);
        }
        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }
       
        return _oCsaCpaList;
    }
	public CsaCpaResult searchCsaCpaCriteria(String a_strAgentType,String a_strChannelType)
    throws FinderException,EElixirException
 {
     
	 CsaCpaResult _oCsaCpaResult=null;
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oCsaCpaSLHome = (CsaCpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
     "CsaCpaSLHome"), CsaCpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
     try
     { 
    	 _oCsaCpaSL = _oCsaCpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");         
         _oCsaCpaResult = _oCsaCpaSL.searchCsaCpaCriteria(a_strAgentType,a_strChannelType);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }

     return _oCsaCpaResult;
 }
	
	public void updateCsaCpaCriteria(CsaCpaResult a_oCsaCpaCriteriaResult)
	throws RemoteException, FinderException, EElixirException
	{
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oCsaCpaSLHome = (CsaCpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "CsaCpaSLHome"), CsaCpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
     try
     {
         _oCsaCpaSL = _oCsaCpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oCsaCpaSL.updateCsaCpaCriteria(a_oCsaCpaCriteriaResult);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }
     
    }
	public void updateCsaCpa(ArrayList a_alCsaCpaList)
    throws FinderException, EElixirException
    {
	 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oCsaCpaSLHome = (CsaCpaSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "CsaCpaSLHome"), CsaCpaSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
     try
     {
         _oCsaCpaSL = _oCsaCpaSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oCsaCpaSL.updateCsaCpa(a_alCsaCpaList);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }
     
    }
	
    
//	Amid_CSA_CPA_end	
	// Santosh_Everest_Segmentation_Adjusted_Paid_Case_Starts

	public void updateAdjustedPaidCase(ArrayList a_oAdjustedPaidCaseList)
			throws FinderException, EElixirException {
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		
		_oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(
				oCHMPropertyUtil.getCHMProperty("SegmentSLHome"),
				SegmentSLHome.class);
		
		try {
			
			_oSegmentSL = _oSegmentSLHome.create();
			_oSegmentSL.updateAdjustedPaidCase(a_oAdjustedPaidCaseList);
			
		} catch (CreateException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (EElixirException rex) {
			log.exception(rex.getMessage());
			throw rex;
		}

	}
//	 ANUP_AGT05_REL9.0 Version 2 Starts -->
	public void approveApplicationforExistingClient(ApplicationResult oApplicationResult)
    throws EElixirException
{
    try
    {
        _oApplicationSL = getApplicationSL("ApplicationSLHome",
                ApplicationSLHome.class);

         _oApplicationSL.approveApplicationforExistingClient(oApplicationResult);
        
    }
    catch (CreateException ce)
    {
        throw new EElixirException(ce, "P1007");
    }
    catch (RemoteException rex)
    {
        throw new EElixirException(rex, "P1006");
    }
    catch (EJBException ejbex)
    {
        throw (EElixirException) ejbex.getCausedByException();
    }
    catch (EElixirException eex)
    {
        throw eex;
    }
}
//	 ANUP_AGT05_REL9.0 Version 2 Ends -->

	/**
	 * Get the AdjustedPaid Case Result
	 * 
	 * @param strParameter
	 * @return ArrayList
	 * @throws FinderException
	 * @throws EElixirException
	 *             Santosh Pandya
	 */
	
	//Updated by Prabhat For pagination
	public SearchData searchAdjustedPaidCase(SearchData oSSearchData)
			throws FinderException, EElixirException {
		
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		log.debug("CHMSLEJB--before Lookup");
		_oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(
				oCHMPropertyUtil.getCHMProperty("SegmentSLHome"),
				SegmentSLHome.class);
		log.debug("CHMSLEJB--After Lookup");

		try {
			_oSegmentSL = _oSegmentSLHome.create();			
			oSSearchData = _oSegmentSL.searchAdjustedPaidCase(oSSearchData);
		} catch (CreateException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1007");
		} catch (EElixirException rex) {
			log.exception(rex.getMessage());
			throw rex;
		}

		return oSSearchData;
	}
	
	/**
	 * Added by Prabhat for validating duplicate adjusted paid cases. --start
	 * 
	 */
	
	public String validateAdjustedPaidCase(SearchData oSSearchData)
	throws FinderException, EElixirException 
	{

		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		log.debug("CHMSLEJB--before Lookup for validating adjusted paid case");
		_oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(
				oCHMPropertyUtil.getCHMProperty("SegmentSLHome"),
				SegmentSLHome.class);
		log.debug("CHMSLEJB--After Lookup for validating adjusted paid case");
		String xml=null;
		try {
			_oSegmentSL = _oSegmentSLHome.create();			
			xml = _oSegmentSL.validateAdjustedPaidCase(oSSearchData);
		} catch (CreateException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1006");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "P1007");
		} catch (EElixirException rex) {
			log.exception(rex.getMessage());
			throw rex;
		}
		
		return xml;
	}
	
	
	
	/**
	 * Added by Prabhat for validating duplicate adjusted paid cases. --End
	 * 
	 */
	
	

	public AdjustedPaidCaseResult getPlanType(String strProductType)
			throws FinderException, EElixirException {


		AdjustedPaidCaseResult oAdjustedPaidCaseResult = null; 

		try {
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil
					.getPropertyUtil();
			_oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(
					oCHMPropertyUtil.getCHMProperty("SegmentSLHome"),
					SegmentSLHome.class);
			_oSegmentSL = _oSegmentSLHome.create();

			Short productType =  new Short(Short.parseShort(strProductType));
			oAdjustedPaidCaseResult = _oSegmentSL.getPlanType(productType);
			return oAdjustedPaidCaseResult;
		} catch (CreateException cex) {
			log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB "
					+ cex);
			throw new EElixirException(cex.getMessage());
		} catch (RemoteException rex) {
			log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB "
					+ rex);
			throw new EElixirException(rex.getMessage());
		}
	}

	// Santosh_Everest_Segmentation_Adjusted_Paid_Case_Ends
	//<!--FSD_AGN30_Past Performance details for all agents in MyAgent SUNAINA STARTS-->
	public AgentPerformanceDetailResult searchAgentPerformanceList(
	        String a_strAgentCd, Short a_nYear, Short a_nYearType)
	        throws FinderException, EElixirException
	    {
	        AgentPerformanceDetailResult oAgentPerformanceDetailResult = null;

	        try
	        {
	            _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);

	            oAgentPerformanceDetailResult = _oAgentSL.searchAgentPerformanceList(a_strAgentCd,
	                    a_nYear,a_nYearType);

	            return oAgentPerformanceDetailResult;
	        }
	        catch (CreateException cex)
	        {
	            throw new EElixirException(cex.getMessage());
	        }
	        catch (RemoteException rex)
	        {
	            throw new EElixirException(rex.getMessage());
	        }
	    }

//<!--FSD_AGN30_Past Performance details for all agents in MyAgent SUNAINA ENDS-->
	//Amid_Fin_156_Upload Of Commission Dispatch_Starts	
 public String searchCommissionDispatch(SearchData _oSearchData) throws FinderException, EElixirException
 {
	      
     String strResult = null;
     EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     _oCommissionSLHome = (CommissionSLHome)objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
     "CommissionSLHome"), CommissionSLHome.class);
     try
     {
    	 _oCommissionSL = _oCommissionSLHome.create();
         strResult = _oCommissionSL.searchCommissionDispatch(_oSearchData);
     }
     catch (CreateException cex)
     {
         log.debug("CHMSLEJB--CreateException ");
         throw new EElixirException(cex, "P1006");
     }
     catch (RemoteException cex)
     {
         log.debug("CHMSLEJB--RemoteeException ");
         throw new EElixirException(cex, "P1006");
     }

     return strResult;
 }
 public void updateCommDispatch(ArrayList a_alCommDispatchList) throws FinderException, EElixirException
 {
	 EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     _oCommissionSLHome = (CommissionSLHome)objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
     "CommissionSLHome"), CommissionSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
  try
  {
	  _oCommissionSL = _oCommissionSLHome.create();
      log.debug("CHMSLEJB--Inside try>>>updateCommDispatch");
      _oCommissionSL.updateCommDispatch(a_alCommDispatchList);
  }
  catch (CreateException rex)
  {
      log.exception(rex.getMessage());
      throw new EElixirException(rex, "P1006");
  }
  catch (RemoteException rex)
  {
      log.exception(rex.getMessage());
      throw new EElixirException(rex, "P1006");
  }
  catch (EElixirException rex)
  {
      log.exception(rex.getMessage());
      throw rex;
  }
  
 }
 

	
//	 ANUP_DST_Incentive_April_REL_Starts
	 public ArrayList searchPersReduction (long lBonusHdrSeqNbr) throws FinderException,EElixirException
	    {
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "BenefitSLHome"), BenefitSLHome.class);
	        ArrayList alDSTDetails = null;
	        try
	        {
	            _oBenefitSL = _oBenefitSLHome.create();
	            alDSTDetails = _oBenefitSL.searchPersReduction(lBonusHdrSeqNbr);
	            
	            return alDSTDetails;
	        }
	        catch (CreateException cex)
	        {
	            log.exception(cex.getMessage());
	            throw new EElixirException(cex, "P1007");
	        }
	        catch (RemoteException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }
	    }
	 
	
	 public void updatePerReductionDetails(ArrayList alDSTDetails,Long lBonusHdrSeqNbr)	throws FinderException,EElixirException
	    {
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "BenefitSLHome"), BenefitSLHome.class);
	        try
	        {
	            _oBenefitSL = _oBenefitSLHome.create();
	            _oBenefitSL.updatePerReductionDetails(alDSTDetails,lBonusHdrSeqNbr);
	        }
	        catch (CreateException cex)
	        {
	            log.exception(cex.getMessage());
	            throw new EElixirException(cex, "P1007");
	        }
	        catch (RemoteException rex)
	        {
	            log.exception(rex.getMessage());
	            throw new EElixirException(rex, "P1006");
	        }        
	    }
	    

//	 ANUP_DST_Incentive_April_REL_Ends
 public String deleteCommissionDispatch(SearchData _oSearchData) throws FinderException, EElixirException
 {
	 log.debug("CHMSLEJB--deleteCommissionDispatch");
     String strResult = null;
     EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     _oCommissionSLHome = (CommissionSLHome)objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
     "CommissionSLHome"), CommissionSLHome.class);
     try
     {
    	 _oCommissionSL = _oCommissionSLHome.create();
    	 log.debug("CHMSLEJB--before calleing deleteCommissionDispatch()");
         strResult = _oCommissionSL.deleteCommissionDispatch(_oSearchData);
     }
     catch (CreateException cex)
     {
         log.debug("CHMSLEJB--CreateException ");
         throw new EElixirException(cex, "P1006");
     }
     catch (RemoteException cex)
     {
         log.debug("CHMSLEJB--RemoteeException ");
         throw new EElixirException(cex, "P1006");
     }

     return strResult;
 }

//	Amid_Fin_156_Upload Of Commission Dispatch_Ends

	//<!--FSD_FIN_160_Switching off ST for locations in MyAgent.v0 ADDED BY Sunaina-->

	public String searchState(SearchData a_oSearchData)
    throws FinderException, EElixirException
{
    String strResult = null;

    try
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        _oMasterSL = _oMasterSLHome.create();

        strResult = _oMasterSL.searchState(a_oSearchData);
        log.debug("_oMasterSL.searchState(a_oSearchData)"+ strResult);
        return strResult;
    }
    catch (CreateException cex)
    {
        log.fatal("CHMSLEJB--CreateException ");
        throw new EElixirException(cex, "P1006");
    }
    catch (RemoteException cex)
    {
        log.fatal("CHMSLEJB--RemoteException ");
        throw new EElixirException(cex, "P1006");
    }

}

	public Long createState(ArrayList a1StateDetailsList)
    throws FinderException, EElixirException
{
		Long _lStateSeqNbr =null;
    log.debug("CHMSLEJB----createTarget----In createTarget");

    try
    {
        log.debug("CHMSLEJB----createTarget----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----createTarget----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----createTarget----before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
        "MasterSLHome"), MasterSLHome.class);
      _oMasterSL = _oMasterSLHome.create();

      _lStateSeqNbr = _oMasterSL.createState(a1StateDetailsList);

      return _lStateSeqNbr;
    }
    catch (CreateException rex)
    {
        log.debug("CHMSLEJB--createState--In CreateException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4532");
    }
    catch (RemoteException rex)
    {
        log.debug("CHMSLEJB--createState--In RemoteException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4532");
    }
    catch (EElixirException rex)
    {
        log.debug("CHMSLEJB--createState--In EELixirException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw rex;
    }


}


	public ArrayList searchStateDet(Long _lStateSeqNbr)
    throws FinderException, EElixirException
{
    log.debug("CHMSLEJB----searchTarget----In searchTarget");

    ArrayList resultObject = new ArrayList();
    try
    {
        log.debug("CHMSLEJB----searchTarget----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----searchTarget----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchTarget----before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB----searchState----After Lookup");

        _oMasterSL = _oMasterSLHome.create();
        log.debug("CHMSLEJB----searchState----Inside try");

        resultObject = _oMasterSL.searchStateDet(_lStateSeqNbr);
    }
    catch (CreateException rex)
    {
        log.debug("CHMSLEJB--searchState--In CreateException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4530");
    }
    catch (RemoteException rex)
    {
        log.debug("CHMSLEJB--searchState--In RemoteException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4530");
    }
    catch (EElixirException rex)
    {
        log.debug("CHMSLEJB--searchState--In EELixirException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw rex;
    }

    log.debug("CHMSLEJB----searchState----returning back to TargetSearch " +
        "action class");

    return resultObject;
}


	public void updateState(ArrayList a1StateDetailsList)
    throws FinderException, EElixirException
{
    log.debug("CHMSLEJB----updateState----In createTarget");

    try
    {
        log.debug("CHMSLEJB----updateState----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----updateState----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----updateState----before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
        "MasterSLHome"), MasterSLHome.class);
      _oMasterSL = _oMasterSLHome.create();

      _oMasterSL.updateState(a1StateDetailsList);
    }
    catch (CreateException rex)
    {
        log.debug("CHMSLEJB--createState--In CreateException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4532");
    }
    catch (RemoteException rex)
    {
        log.debug("CHMSLEJB--createState--In RemoteException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4532");
    }
    catch (EElixirException rex)
    {
        log.debug("CHMSLEJB--createState--In EELixirException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw rex;
    }

    log.debug("CHMSLEJB----createState----returning back to TargetSearch " +
        "action class");
}

	/* Changed by Manisha on 10 Oct 2011-FIN 393_Professional_Tax START */
	public ArrayList searchStatecd(String nStateCd ,String nTaxType)
    throws FinderException, EElixirException
{
    log.debug("CHMSLEJB----searchTarget----In searchTarget");

    ArrayList resultObject = new ArrayList();
    try
    {
        log.debug("CHMSLEJB----searchTarget----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----searchTarget----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchTarget----before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB----searchState----After Lookup");

        _oMasterSL = _oMasterSLHome.create();
        log.debug("CHMSLEJB----searchState----Inside try");
        /* FIXED by Himanshu on 29 Oct 2011-FIN 393_Professional_Tax START */
        log.debug("BEFORE MY fUNCTION hIMANSHU IN CHMSLEJB");
        resultObject = _oMasterSL.searchStatecd(nStateCd ,nTaxType);
        log.debug("AFTER MY fUNCTION hIMANSHU IN CHMSLEJB");

    }
    catch (CreateException rex)
    {
        log.debug("CHMSLEJB--searchState--In CreateException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4530");
    }
    catch (RemoteException rex)
    {
        log.debug("CHMSLEJB--searchState--In RemoteException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4530");
    }
    catch (EElixirException rex)
    {
        log.debug("CHMSLEJB--searchState--In EELixirException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw rex;
    }

    log.debug("CHMSLEJB----searchState----returning back to TargetSearch " +
        "action class");

    return resultObject;
}
	 /* FIXED by Himanshu on 29 Oct 2011-FIN 393_Professional_Tax End */
	
	public ArrayList searchStatecdcreate(String nStateCd ,String nTaxType)
    throws FinderException, EElixirException
{
    log.debug("CHMSLEJB----searchTarget----In searchTarget");

    ArrayList resultObject = new ArrayList();
    try
    {
        log.debug("CHMSLEJB----searchTarget----Before getFactory");

        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        log.debug("CHMSLEJB----searchTarget----Before getPropertyUtil");

        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB----searchTarget----before Lookup");
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        log.debug("CHMSLEJB----searchState----After Lookup");

        _oMasterSL = _oMasterSLHome.create();
        log.debug("CHMSLEJB----searchState----Inside try");
        /* FIXED by Himanshu on 29 Oct 2011-FIN 393_Professional_Tax START */
        log.debug("BEFORE MY  IN searchStatecdcreate CHMSLEJB");
        resultObject = _oMasterSL.searchStatecdcreate(nStateCd ,nTaxType);
        log.debug("AFTER MY fUNCTION hIMANSHU IN CHMSLEJB");
       
    }
    catch (CreateException rex)
    {
        log.debug("CHMSLEJB--searchState--In CreateException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4530");
    }
    catch (RemoteException rex)
    {
        log.debug("CHMSLEJB--searchState--In RemoteException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw new EElixirException(rex, "P4530");
    }
    catch (EElixirException rex)
    {
        log.debug("CHMSLEJB--searchState--In EELixirException of CHMSLEJB");
        log.debug(rex.getMessage());
        throw rex;
    }

    log.debug("CHMSLEJB----searchState----returning back to TargetSearch " +
        "action class");

    return resultObject;
}
	 /* FIXED by Himanshu on 29 Oct 2011-FIN 393_Professional_Tax End */
	//<!--FSD_FIN_160_Switching off ST for locations in MyAgent.v0 Ended BY Sunaina-->
//	FIN-117_86_Restriction on commission disbursement ADDED by sunaina
	 public String searchBounceCharge(SearchData oSearchData)
    throws EElixirException, FinderException
{
		 String resultData = null;
    log.debug(
        "\nInside the SearchPaymentWithHold method of CHSMLEJB****** ");

    EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
    log.debug("objEJBHomeFactory ----" + objEJBHomeFactory);

    CHMPropertyUtil _oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
    log.debug("_oCHMPropertyUtil::: " + _oCHMPropertyUtil);
    oPaymentWithHoldSLHome = (PaymentWithHoldSLHome) objEJBHomeFactory.lookUpHome(_oCHMPropertyUtil.getCHMProperty(
                "PaymentWithHoldSLHome"), PaymentWithHoldSLHome.class);
    log.debug("oPaymentWithHoldSLHome : " + oPaymentWithHoldSLHome);

    try
    {
        oPaymentWithHoldSL = oPaymentWithHoldSLHome.create();
        resultData = oPaymentWithHoldSL.searchBounceCharge(oSearchData);
    }
    catch (CreateException cex)
    {
        log.debug("CreateException ");
        throw new EElixirException(cex, "P8075");
    }
    catch (RemoteException cex)
    {
        log.debug("RemoteeException ");
        throw new EElixirException(cex, "P8075");
    }

    return resultData;
}
	//FIN-117_86_Restriction on commission disbursement ADDED by sunaina
//	<!--FSD_FIN_68_Debiting_Bounce_charges_APRIL_REL_ANUP_19Feb2009_Starts-->
    public ArrayList searchBounce() throws FinderException, EElixirException
    {
        ArrayList arrChannelResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            arrChannelResult = _oMasterSL.searchBounceChrgs();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return arrChannelResult;
    }

    public void updateBounce(ArrayList a_arrBounceResult)
        throws FinderException, EJBException, EElixirException
    {
    	log.debug("CHMSLEJB----updateBounce----> started");
        ArrayList arrChannelResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            _oMasterSL.updateBounceChrg(a_arrBounceResult);
       
            log.debug("CHMSLEJB----updateBounce----> ends");
        }
        catch (CreateException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException cex)
        {
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            throw new EElixirException(ejbex, "P1007");
        }

    }

//	<!--FSD_FIN_68_Debiting_Bounce_charges_APRIL_REL_ANUP_19Feb2009_Ends-->
//  <!--sunaina_Commision_Dispatch_CR_Starts-->
    public CommDispatchResult searchGetLocationCd(String strUserId)
    throws RemoteException, FinderException, EElixirException
    {
    	log.debug("CHMSLEJB--Starting the searchDesignationCode method");

    	CommDispatchResult oCommDispatchResult = null;
    	EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oCommissionSLHome = (CommissionSLHome)objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
        "CommissionSLHome"), CommissionSLHome.class);
        log.debug("CHMSLEJB--After Lookup");
     try
     {
   	  _oCommissionSL = _oCommissionSLHome.create();
       log.debug("CHMSLEJB--Inside try>>>updateCommDispatch");
       oCommDispatchResult = _oCommissionSL.searchGetLocationCd(strUserId);

     	   
        }
        catch (CreateException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.debug(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.debug(rex.getMessage());
            throw rex;
        }

        return oCommDispatchResult;
    }
    //<!--sunaina_Commision_Dispatch_CR_Ended-->
    
  //Added by Prabhat for FSD_TCU-AGN-6_IRDA Details Start   
    public boolean enableIrdaTab(String agentCode) throws RemoteException, FinderException, EElixirException
    {
    	boolean enable=false;
    	try
    	{
    		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oAgentSLHome = (AgentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "AgentSLHome"), AgentSLHome.class);
            _oAgentSL = _oAgentSLHome.create();
            
            enable=_oAgentSL.enableIrdaTab(agentCode);
            
            return enable;
    	}
    	catch (CreateException cex)
        {
            log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " +
                cex);
            throw new EElixirException(cex.getMessage());
        }
        catch (RemoteException rex)
        {
            log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " +
                rex);
            throw new EElixirException(rex.getMessage());
        }
    	
    }
 //Added by Prabhat for FSD_TCU-AGN-6_IRDA Details End
   //Amid_FSD_FYC & RYC Payment post Agent Termination Start
    public ArrayList searchCustomSetting(CustomSettingResult a_oCustomSettingResult)
    throws FinderException, EElixirException
 {
    	log.debug("inside chmslejb>>>searchCustomSetting");
	 ArrayList _oCustomSettingList = null;		        
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oCustomSettingSLHome = (CustomSettingSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "CustomSettingSLHome"), CustomSettingSLHome.class);
     log.debug("CHMSLEJB--After Lookup");

     try
     {
         _oCustomSettingSL = _oCustomSettingSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oCustomSettingList = _oCustomSettingSL.searchCustomSetting(a_oCustomSettingResult);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }
    
     return _oCustomSettingList;
 }
    public void updateCustomSetting(ArrayList a_alCustomSettingList)
    throws FinderException, EElixirException
    {
	 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oCustomSettingSLHome = (CustomSettingSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "CustomSettingSLHome"), CustomSettingSLHome.class);
     log.debug("CHMSLEJB--After Lookup");
     try
     {
    	 _oCustomSettingSL = _oCustomSettingSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oCustomSettingSL.updateCustomSetting(a_alCustomSettingList);
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }
     
    }
 //Amid_FSD_FYC & RYC Payment post Agent Termination End
    //Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Starts	
	    public ArrayList searchOverrideCommRuleList(String a_cChannelType)
        throws FinderException, EElixirException
        {
        ArrayList _oCommRuleList = null;
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oCommissionSLHome = (CommissionSLHome)objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
        "CommissionSLHome"), CommissionSLHome.class);      
        try
        {
        	_oCommissionSL = _oCommissionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oCommRuleList = _oCommissionSL.searchOverrideCommRuleList(a_cChannelType);
        }
        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        return _oCommRuleList;
    }

     public void updateOverrideCommRule(ArrayList a_oCommRuleList)
        throws FinderException, EElixirException
    {
    	
        EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oCommissionSLHome = (CommissionSLHome)objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
        "CommissionSLHome"), CommissionSLHome.class);

        try
        {
            _oCommissionSL = _oCommissionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oCommissionSL.updateOverrideCommRule(a_oCommRuleList);
        }

        catch (CreateException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }

        log.debug("CHMSLEJB--returning back to OverrideCommissionRuleUpdate action class");
    }  
     
     
     /* This method will lookup Commission session bean
      *Searchdata object
      *@param String
      *@return String
      *@throws EElixirException FinderException RemoteException
      */
      public String productCodeExists(String strAgencyCode,
	            String strProdCd, String dtEffFrom)
          throws EElixirException, FinderException
      {   
    	  String  alAnalList = null;
    	  
    	  EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
          CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
          _oCommissionSLHome = (CommissionSLHome)objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
          "CommissionSLHome"), CommissionSLHome.class);

          try
          {
              _oCommissionSL = _oCommissionSLHome.create();
              log.debug("CHMSLEJB--Inside try");
              alAnalList = _oCommissionSL.searchProdCodeExists(strAgencyCode,strProdCd,dtEffFrom);
          }
          catch (EJBException ejbex)
          {
              throw new EElixirException(ejbex, "P1007");
          }
          catch (RemoteException ejbex)
          {
              throw new EElixirException(ejbex, "P1006");
          }
          catch (CreateException ejbex)
          {
              throw new EElixirException(ejbex, "P1007");
          }
          catch (EElixirException eLex)
          {
              throw eLex;
          }
          return alAnalList;
      }
    //Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Ends    
    /*  Anup_Session_Listner_Implementation_Starts 
     * @Param HashMap hmParam
     * @return ProcessResult
     */
    public ProcessResult getCallProceduresMyAgent(HashMap hmParam) throws FinderException,EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "BenefitSLHome"), BenefitSLHome.class);
        ProcessResult oProcessResult = null;
        try
        {
            _oBenefitSL = _oBenefitSLHome.create();
            oProcessResult = _oBenefitSL.callProceduresMyAgent(hmParam);
            
            return oProcessResult;
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
    }
    // Session_Listner_Implementation_Ends
//Arun_Modified_For_PerformanceImprovment_start
    public ApplicationResult searchApplicationQuestionList(long a_lApplcSeqNbr,
            String a_strAgentCd, String a_strApplcntType) throws EElixirException
        {               
            	ApplicationResult oApplicationResult = null;

                try
                {
                    _oApplicationSL = getApplicationSL("ApplicationSLHome",
                            ApplicationSLHome.class);
                    oApplicationResult = _oApplicationSL.searchApplicationQuestionList(a_lApplcSeqNbr,
                            a_strAgentCd, a_strApplcntType);
                    return oApplicationResult;
            	
                }
            catch (CreateException ce)
            {
                throw new EElixirException(ce, "P1007");
            }
            catch (RemoteException rex)
            {
                throw new EElixirException(rex, "P1006");
            }
            catch (EJBException ejbex)
            {
                throw (EElixirException) ejbex.getCausedByException();
            }
            catch (EElixirException eex)
            {
                throw eex;
            }
        }

    public void updateAgentQuestion(AgentResult a_oAgentResult)
    throws EElixirException
   {
     try
     {
        _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
        _oAgentSL.updateAgentQuestion(a_oAgentResult);
     }
    catch (CreateException ce)
    {
        throw new EElixirException(ce, "P1007");
    }
    catch (RemoteException rex)
    {
        throw new EElixirException(rex, "P1006");
    }
    catch (EJBException ejbex)
    {
        throw (EElixirException) ejbex.getCausedByException();
    }
    catch (EElixirException eex)
    {
        throw eex;
    }
}
    
    

    
    public ApplicationResult searchApplicationClientSearch(long a_lApplcSeqNbr,
            String a_strAgentCd, String a_strApplcntType) throws EElixirException
       {               
          	ApplicationResult oApplicationResult = null;

          try
            {                	
               _oApplicationSL = getApplicationSL("ApplicationSLHome",
                        ApplicationSLHome.class);
               oApplicationResult = _oApplicationSL.searchApplicationClientSearch(a_lApplcSeqNbr,
                      a_strAgentCd, a_strApplcntType);
                 return oApplicationResult;
            }
            catch (CreateException ce)
            {
                throw new EElixirException(ce, "P1007");
            }
            catch (RemoteException rex)
            {
                throw new EElixirException(rex, "P1006");
            }
            catch (EJBException ejbex)
            {
                throw (EElixirException) ejbex.getCausedByException();
            }
            catch (EElixirException eex)
            {
                throw eex;
            }
        }
    
    public void updateApplicationClient(ApplicationResult a_oApplicationResult)
    throws EElixirException
    {
      try
      {
        _oAgentSL = getAgentSL("AgentSLHome", AgentSLHome.class);
        _oAgentSL.updateAgentClient(a_oApplicationResult); 
      }
      catch (CreateException ce)
      {
         throw new EElixirException(ce, "P1007");
      }
      catch (RemoteException rex)
      {
         throw new EElixirException(rex, "P1006");
      }
      catch (EJBException ejbex)
      {
        throw (EElixirException) ejbex.getCausedByException();
      }
      catch (EElixirException eex)
      {
         throw eex;
      }
     
    
 }
    public ApplicationResult searchApplicationBankDetails(long a_lApplcSeqNbr,
    String a_strAgentCd, String a_strApplcntType)throws EElixirException
    {
    	ApplicationResult oApplicationResult = null;

    	try
    	{   		
            _oApplicationSL = getApplicationSL("ApplicationSLHome",
                    ApplicationSLHome.class);
            oApplicationResult = _oApplicationSL.searchApplicationBankDetails(a_lApplcSeqNbr,
                    a_strAgentCd, a_strApplcntType);
               return oApplicationResult;
    		
    	} catch (CreateException ce)
        {
            throw new EElixirException(ce, "P1007");
        }
        catch (RemoteException rex)
        {
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    	
    }
    
  public void updateBankApplication(ApplicationResult oApplicationResult)
    throws EElixirException
  {
    try
    {
        _oApplicationSL = getApplicationSL("ApplicationSLHome",
                ApplicationSLHome.class);
        _oApplicationSL.updateBankApplication(oApplicationResult);
    }
    catch (CreateException ce)
    {
        throw new EElixirException(ce, "P1007");
    }
    catch (RemoteException rex)
    {
        throw new EElixirException(rex, "P1006");
    }
    catch (EJBException ejbex)
    {
        throw (EElixirException) ejbex.getCausedByException();
    }
    catch (EElixirException eex)
    {
        throw eex;
    }
}
  //Nominee
  public ApplicationResult searchApplicationNominee(long a_lApplcSeqNbr,
		    String a_strAgentCd, String a_strApplcntType)throws EElixirException
		    {
		    	ApplicationResult oApplicationResult = null;

		    	try
		    	{   		
		            _oApplicationSL = getApplicationSL("ApplicationSLHome",
		                    ApplicationSLHome.class);
		            oApplicationResult = _oApplicationSL.searchApplicationNominee(a_lApplcSeqNbr,
		                    a_strAgentCd, a_strApplcntType);
		               return oApplicationResult;
		    		
		    	} catch (CreateException ce)
		        {
		            throw new EElixirException(ce, "P1007");
		        }
		        catch (RemoteException rex)
		        {
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (EJBException ejbex)
		        {
		            throw (EElixirException) ejbex.getCausedByException();
		        }
		        catch (EElixirException eex)
		        {
		            throw eex;
		        }
		    	
		    }
  
  public void updateApplicationNominee(ApplicationResult oApplicationResult)
  throws EElixirException
 {
   try
   {
	   _oApplicationSL = getApplicationSL("ApplicationSLHome",
               ApplicationSLHome.class);
       _oApplicationSL.updateApplicationNominee(oApplicationResult);
   }
  catch (CreateException ce)
  {
      throw new EElixirException(ce, "P1007");
  }
  catch (RemoteException rex)
  {
      throw new EElixirException(rex, "P1006");
  }
  catch (EJBException ejbex)
  {
      throw (EElixirException) ejbex.getCausedByException();
  }
  catch (EElixirException eex)
  {
      throw eex;
  }
}
  
  //Tax details
  public ApplicationResult searchApplicationTaxInfo(long a_lApplcSeqNbr,
		    String a_strAgentCd, String a_strApplcntType)throws EElixirException
		    {
		    	ApplicationResult oApplicationResult = null;

		    	try
		    	{   		
		            _oApplicationSL = getApplicationSL("ApplicationSLHome",
		                    ApplicationSLHome.class);
		            log.debug("Before SearchApplicationTaxInfo method of CHMSLEJB");
		            oApplicationResult = _oApplicationSL.searchApplicationTaxInfo(a_lApplcSeqNbr,
		                    a_strAgentCd, a_strApplcntType);
		            log.debug("After SearchApplicationTaxInfo method of CHMSLEJB"); 
		               return oApplicationResult;
		    		
		    	} catch (CreateException ce)
		        {
		            throw new EElixirException(ce, "P1007");
		        }
		        catch (RemoteException rex)
		        {
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (EJBException ejbex)
		        {
		            throw (EElixirException) ejbex.getCausedByException();
		        }
		        catch (EElixirException eex)
		        {
		            throw eex;
		        }
		    	
		    }
  public void updateApplicationTaxInfo(ApplicationResult oApplicationResult)
  throws EElixirException
 {
   try
   {
	   _oApplicationSL = getApplicationSL("ApplicationSLHome",
               ApplicationSLHome.class);
       _oApplicationSL.updateApplicationTaxInfo(oApplicationResult);
   }
  catch (CreateException ce)
  {
      throw new EElixirException(ce, "P1007");
  }
  catch (RemoteException rex)
  {
      throw new EElixirException(rex, "P1006");
  }
  catch (EJBException ejbex)
  {
      throw (EElixirException) ejbex.getCausedByException();
  }
  catch (EElixirException eex)
  {
      throw eex;
  }
}
  
  //Education
  public ApplicationResult searchApplicationEducWorkDtls(long a_lApplcSeqNbr,
		    String a_strAgentCd, String a_strApplcntType)throws EElixirException
   {
		    	ApplicationResult oApplicationResult = null;

		    	try
		    	{   		
		            _oApplicationSL = getApplicationSL("ApplicationSLHome",
		                    ApplicationSLHome.class);
		            log.debug("Before searchApplicationEducDtls method of CHMSLEJB");
		            oApplicationResult = _oApplicationSL.searchApplicationEducWorkDtls(a_lApplcSeqNbr,
		                    a_strAgentCd, a_strApplcntType);
		            log.debug("After searchApplicationEducDtls method of CHMSLEJB"); 
		               return oApplicationResult;
		    		
		    	} catch (CreateException ce)
		        {
		            throw new EElixirException(ce, "P1007");
		        }
		        catch (RemoteException rex)
		        {
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (EJBException ejbex)
		        {
		            throw (EElixirException) ejbex.getCausedByException();
		        }
		        catch (EElixirException eex)
		        {
		            throw eex;
		        }
		    	
		    }
  public void updateApplicationEduWorkDtls(ApplicationResult oApplicationResult)
  throws EElixirException
 {
   try
   {
	   _oApplicationSL = getApplicationSL("ApplicationSLHome",
               ApplicationSLHome.class);
       _oApplicationSL.updateApplicationEduWorkDtls(oApplicationResult);
   }
  catch (CreateException ce)
  {
      throw new EElixirException(ce, "P1007");
  }
  catch (RemoteException rex)
  {
      throw new EElixirException(rex, "P1006");
  }
  catch (EJBException ejbex)
  {
      throw (EElixirException) ejbex.getCausedByException();
  }
  catch (EElixirException eex)
  {
      throw eex;
  }
}
  
  public ApplicationResult searchApplicationAssGO(long a_lApplcSeqNbr,
		    String a_strAgentCd, String a_strApplcntType)throws EElixirException
 {
		    	ApplicationResult oApplicationResult = null;

		    	try
		    	{   		
		            _oApplicationSL = getApplicationSL("ApplicationSLHome",
		                    ApplicationSLHome.class);
		            log.debug("Before searchApplicationAssGO method of CHMSLEJB");
		          oApplicationResult = _oApplicationSL.searchApplicationAssGO(a_lApplcSeqNbr,
		                    a_strAgentCd, a_strApplcntType);
		            log.debug("After searchApplicationAssGO method of CHMSLEJB"); 
		               return oApplicationResult;
		    		
		    	} catch (CreateException ce)
		        {
		            throw new EElixirException(ce, "P1007");
		        }
		        catch (RemoteException rex)
		        {
		            throw new EElixirException(rex, "P1006");
		        }
		        catch (EJBException ejbex)
		        {
		            throw (EElixirException) ejbex.getCausedByException();
		        }
		        catch (EElixirException eex)
		        {
		            throw eex;
		        }
		    	
		    }
  public void updateApplicationAssGo(ApplicationResult oApplicationResult) throws EElixirException
  {
	  try
	   {
		   _oApplicationSL = getApplicationSL("ApplicationSLHome",
	               ApplicationSLHome.class);
	       _oApplicationSL.updateApplicationAssGo(oApplicationResult);
	   }
	  catch (CreateException ce)
	  {
	      throw new EElixirException(ce, "P1007");
	  }
	  catch (RemoteException rex)
	  {
	      throw new EElixirException(rex, "P1006");
	  }
	  catch (EJBException ejbex)
	  {
	      throw (EElixirException) ejbex.getCausedByException();
	  }
	  catch (EElixirException eex)
	  {
	      throw eex;
	  }
	  
  }
 //Arun_Modified_For_PerformanceImprovment_end

   /* Added By Jayasimha for FSD_TCU_AGN_09 functionality @jan2010 */
    public ArrayList searchAgencyTermSusDtls() throws FinderException, EElixirException
    {
        ArrayList arrAgencyTermSusResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            arrAgencyTermSusResult = _oMasterSL.searchAgencyTermSusDtls();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        return arrAgencyTermSusResult;
    }

    
    public void updateAgencyTermSusDtls(ArrayList a_arrAgencyTermSusResult)
    throws FinderException, EJBException, EElixirException
{
 

    try
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "MasterSLHome"), MasterSLHome.class);
        _oMasterSL = _oMasterSLHome.create();
        _oMasterSL.updateAgencyTermSusDtls(a_arrAgencyTermSusResult);
    }
    catch (CreateException cex)
    {
        throw new EElixirException(cex, "P1007");
    }
    catch (RemoteException rex)
    {
        throw new EElixirException(rex, "P1006");
    }
    catch (FinderException cex)
    {
        throw new EElixirException(cex, "P1007");
    }
    catch (EJBException ejbex)
    {
        throw new EElixirException(ejbex, "P1007");
    }

}
    
    
    /*  end of the code Added By Jayasimha for FSD_TCU_AGN_09 functionality @jan2010 */
 // Anup_FSD_TDS20PAN_V1.4_09Feb2010_Starts
    public ArrayList searchTDSInvalidPan()
        throws FinderException, EElixirException
    {
        ArrayList arrTDSInvalidPanResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            arrTDSInvalidPanResult = _oMasterSL.searchTDSInvalidPan();
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }

        return arrTDSInvalidPanResult;
    }

    public void updateTDSInvalidPan(ArrayList a_arrTDSInvalidPanResult)
        throws FinderException, EJBException, EElixirException
    {
        ArrayList arrTDSInvalidPanResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup");
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            log.debug("CHMSLEJB--After Lookup");

            _oMasterSL = _oMasterSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oMasterSL.updateTDSInvalidPan(a_arrTDSInvalidPanResult);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException cex)
        {
            log.debug("CHMSLEJB--inside finder exception");
            throw new EElixirException(cex, "P1007");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }

        log.debug("CHMSLEJB--returning back to TDSInvalidPan action class");
    }

 // Anup_FSD_TDS20PAN_V1.4_09Feb2010_Ends

//Added by Srikanth CTS for MPS
    public ArrayList searchChannelMPSTypes(String a_cChannelType)
    throws FinderException, EElixirException
 {
    log.entry("CHMSLEJB","searchChannelMPSTypes","starts");
     ArrayList _oSegmentationList = null;
     EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
     CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
     log.debug("CHMSLEJB--before Lookup");
     _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                 "SegmentSLHome"), SegmentSLHome.class);
     log.debug("CHMSLEJB--After Lookup");

     try
     {
         _oSegmentSL = _oSegmentSLHome.create();
         log.debug("CHMSLEJB--Inside try");
         _oSegmentationList = _oSegmentSL.searchChannelMPSTypes(a_cChannelType);
         
         log.exit("CHMSLEJB", "searchChannelMPSTypes", "exit");
     }
     catch (CreateException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (RemoteException rex)
     {
         log.exception(rex.getMessage());
         throw new EElixirException(rex, "P1006");
     }
     catch (EElixirException rex)
     {
         log.exception(rex.getMessage());
         throw rex;
     }

     return _oSegmentationList;
 }
    
   
public MPSResult searchMPSMasterData(long _lMPSHdrSeqNbr)throws FinderException, EElixirException, RemoteException 
{
	log.entry("CHMSLEJB","searchMPSMasterData","starts");
		MPSResult _oMPSResult = null;
    	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        
        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "SegmentSLHome"), SegmentSLHome.class);
        try
        {
            _oSegmentSL = _oSegmentSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            _oMPSResult = _oSegmentSL.searchMPSMasterData(_lMPSHdrSeqNbr);
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EElixirException rex)
        {
            log.exception(rex.getMessage());
            throw rex;
        }
        log.exit("CHMSLEJB", "searchMPSMasterData", "exit");
        return _oMPSResult;
    	
}

public long createMPSMaster(MPSResult a_MPSResult)
	throws EJBException, EElixirException
{
	log.entry("CHMSLEJB","createMPSMaster","starts");
	long seqNo = 0;
	
	try
	{
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        
        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "SegmentSLHome"), SegmentSLHome.class);
	        
	    _oSegmentSL = _oSegmentSLHome.create();
		log.debug("CHMSLEJB--Inside try");
		seqNo = _oSegmentSL.createMPSMaster(a_MPSResult);
		
		log.entry("CHMSLEJB","createMPSMaster","end"+seqNo);
	
		return seqNo;
	}
	catch (CreateException cex)
	{
	log.debug("CHMSLEJB--inside create exception");
	throw new EElixirException(cex, "P1007");
	}
	catch (RemoteException rex)
	{
	log.exception(rex.getMessage());
	throw new EElixirException(rex, "P1006");
	}
	catch (EJBException ejbex)
	{
	log.debug("CHMSLEJB--inside ejb exception");
	throw new EElixirException(ejbex, "P1007");
	}
	
}

public void updateMPSMaster(MPSResult a_MPSResult)
	throws EJBException, EElixirException
{		 
	log.entry("CHMSLEJB","updateMPSMaster","end");
	try
	{
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("CHMSLEJB--before Lookup");
        
        _oSegmentSLHome = (SegmentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "SegmentSLHome"), SegmentSLHome.class);
	        
	    _oSegmentSL = _oSegmentSLHome.create();
		log.debug("CHMSLEJB--Inside try");
		
		_oSegmentSL.updateMPSMaster(a_MPSResult);
		
		log.exit("CHMSLEJB","updateMPSMaster","end");
	
	}
	catch (CreateException cex)
	{
	log.debug("CHMSLEJB--inside create exception");
	throw new EElixirException(cex, "P1007");
	}
	catch (RemoteException rex)
	{
	log.exception(rex.getMessage());
	throw new EElixirException(rex, "P1006");
	}
	catch (EJBException ejbex)
	{
	log.debug("CHMSLEJB--inside ejb exception");
	throw new EElixirException(ejbex, "P1007");
	}
}
   
  //End by Srikanth CTS

//Anup_AugRel2010_FSD_TPR_V1.3_Starts
public ArrayList searchChannelTPRTypes(String a_cChannelType)
throws FinderException, EElixirException
{
log.entry("CHMSLEJB","searchChannelTPRTypes","starts");
 ArrayList _oBenefitList = null;
 EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
 CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
 log.debug("CHMSLEJB--before Lookup");
 _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
 "BenefitSLHome"), BenefitSLHome.class);
 
 log.debug("CHMSLEJB--After Lookup");

 try
 {
     _oBenefitSL = _oBenefitSLHome.create();     
     _oBenefitList = _oBenefitSL.searchChannelTPRTypes(a_cChannelType);
     
     log.exit("CHMSLEJB", "searchChannelMPSTypes", "exit");
 }
 catch (CreateException rex)
 {
     log.exception(rex.getMessage());
     throw new EElixirException(rex, "P1006");
 }
 catch (RemoteException rex)
 {
     log.exception(rex.getMessage());
     throw new EElixirException(rex, "P1006");
 }
 catch (EElixirException rex)
 {
     log.exception(rex.getMessage());
     throw rex;
 }

 return _oBenefitList;
}


public TPRResult searchTPRMasterData(long _lTPRHdrSeqNbr)throws FinderException, EElixirException, RemoteException 
{
log.entry("CHMSLEJB","searchTPRMasterData","starts");
	TPRResult _oTPRResult = null;
	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
    CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
    log.debug("CHMSLEJB--before Lookup");
    
    _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
    "BenefitSLHome"), BenefitSLHome.class);
   
    try
    {
        _oBenefitSL = _oBenefitSLHome.create();
        log.debug("CHMSLEJB--Inside try");
        _oTPRResult = _oBenefitSL.searchTPRMasterData(_lTPRHdrSeqNbr);
    }
    catch (CreateException cex)
    {
        log.exception(cex.getMessage());
        throw new EElixirException(cex, "P1007");
    }
    catch (RemoteException rex)
    {
        log.exception(rex.getMessage());
        throw new EElixirException(rex, "P1006");
    }
    catch (EElixirException rex)
    {
        log.exception(rex.getMessage());
        throw rex;
    }
    log.exit("CHMSLEJB", "searchTPRMasterData", "exit");
    return _oTPRResult;
	
}

public void createTPRMaster(ArrayList a_TPRResult)
throws EJBException, EElixirException
{
log.entry("CHMSLEJB","createTPRMaster","starts");


try
{
	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
    CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
    log.debug("CHMSLEJB--before Lookup");
    
    _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
    "BenefitSLHome"), BenefitSLHome.class);
        
    _oBenefitSL = _oBenefitSLHome.create();
	log.debug("CHMSLEJB--Inside try");
	 _oBenefitSL.createTPRMaster(a_TPRResult);
}
catch (CreateException cex)
{
log.debug("CHMSLEJB--inside create exception");
throw new EElixirException(cex, "P1007");
}
catch (RemoteException rex)
{
log.exception(rex.getMessage());
throw new EElixirException(rex, "P1006");
}
catch (EJBException ejbex)
{
log.debug("CHMSLEJB--inside ejb exception");
throw new EElixirException(ejbex, "P1007");
}

}

public void updateTPRMaster(TPRResult a_TPRResult)
throws EJBException, EElixirException
{		 
log.entry("CHMSLEJB","updateMPSMaster","end");
try
{
	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
    CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
    log.debug("CHMSLEJB--before Lookup");    
    _oBenefitSLHome = (BenefitSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
    "BenefitSLHome"), BenefitSLHome.class);        
    _oBenefitSL = _oBenefitSLHome.create();		
	_oBenefitSL.updateTPRMaster(a_TPRResult);	
	log.exit("CHMSLEJB","updateTPRMaster","end");
}
catch (CreateException cex)
{
log.debug("CHMSLEJB--inside create exception");
throw new EElixirException(cex, "P1007");
}
catch (RemoteException rex)
{
log.exception(rex.getMessage());
throw new EElixirException(rex, "P1006");
}
catch (EJBException ejbex)
{
log.debug("CHMSLEJB--inside ejb exception");
throw new EElixirException(ejbex, "P1007");
}
}

//Anup_AugRel2010_FSD_TPR_V1.3_Ends

// Anantha_FSD_Duplicate_myFlow_Application_Niumber_v1[1].1 starts

public String validateDuplicateMyFlowAppNumber(CHMJQueryData a_oCHMJQueryData) throws FinderException, EElixirException
{
    String  strAgentCd = null;

    try
    {
    	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        _oAgentSLHome = (AgentSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "AgentSLHome"), AgentSLHome.class);
        _oAgentSL = _oAgentSLHome.create();
        strAgentCd = _oAgentSL.validateDuplicateMyFlowAppNumber(a_oCHMJQueryData);
    }
    catch (CreateException cex)
    {
        log.exception(cex.getMessage());
        throw new EElixirException(cex, "P1007");
    }
    catch (RemoteException rex)
    {
        log.exception(rex.getMessage());
        throw new EElixirException(rex, "P1006");
    }
    return strAgentCd;
}

// Anantha_FSD_Duplicate_myFlow_Application_Niumber_v1[1].1 ends
	/*
	 * ALEX_FSD_20K_TDS_Exemption_Limit_V1.7 Starts
	 */
	public ArrayList fetchTDSExemptionLimit() throws RemoteException,
			EElixirException {
		log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: fetchTDSExemptionLimit | STARTS");
		ArrayList arrFetchList = null;
		try {
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("MasterSLHome"),MasterSLHome.class);
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: fetchTDSExemptionLimit | LOOKUP SUCCESS");
			_oMasterSL = _oMasterSLHome.create();
			arrFetchList = _oMasterSL.fetchTDSExemptionLimit();
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: fetchTDSExemptionLimit | END");
		} catch (CreateException cex) {
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: fetchTDSExemptionLimit | EXCEPTION: CREATE");
			throw new EElixirException(cex, "p8070");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "p8070");
		} catch (EJBException ejbex) {
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: fetchTDSExemptionLimit | EXCEPTION: EJB");
			throw new EElixirException(ejbex, "p8071");
		}
		return arrFetchList;
	}

	public void exemptionTDSCreateandUpdate(ArrayList arrTDSExemption)
			throws RemoteException, EElixirException {
		log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: exemptionTDSCreateandUpdate | STARTS");		
		try {
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("MasterSLHome"),MasterSLHome.class);
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: exemptionTDSCreateandUpdate | LOOKUP SUCCESS");
			_oMasterSL = _oMasterSLHome.create();
			_oMasterSL.exemptionTDSCreateandUpdate(arrTDSExemption);
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: exemptionTDSCreateandUpdate | END");
		} catch (CreateException cex) {
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: exemptionTDSCreateandUpdate | EXCEPTION: CREATE");
			throw new EElixirException(cex, "p8070");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "p8070");
		} catch (EJBException ejbex) {
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: exemptionTDSCreateandUpdate | EXCEPTION: EJB");
			throw new EElixirException(ejbex, "p8071");
		}

	}
	//Added by Alexpandiyan for JAN Release on 18 Jan 2010 Start
	public int getFinancialYear(String businessDate) throws RemoteException,EElixirException {
		log.debug("EJBNAME: MASTERSLEJB | BUSINESS METHOD: getFinancialYear ");
		try {
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
			_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("MasterSLHome"),MasterSLHome.class);
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: getFinancialYear | LOOKUP SUCCESS");
			_oMasterSL = _oMasterSLHome.create();
			return _oMasterSL.getFinancialYear(businessDate);
		} catch (CreateException cex) {
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: getFinancialYear | EXCEPTION: CREATE");
			throw new EElixirException(cex, "p8070");
		} catch (RemoteException rex) {
			log.exception(rex.getMessage());
			throw new EElixirException(rex, "p8070");
		} catch (EJBException ejbex) {
			log.debug("EJBNAME: CHMSLEJB | BUSINESS METHOD: getFinancialYear | EXCEPTION: EJB");
			throw new EElixirException(ejbex, "p8071");
		}
		
		}
	//Added by Alexpandiyan for JAN Release End
	/*
	 * ALEX_FSD_20K_TDS_Exemption_Limit_V1.7 Ends
	 */
	/* Start:Rel. Q2 change treatment ofservice charge V1.0 - Monika  06-01-11 */
	public ArrayList searchServiceCharge()throws FinderException, EElixirException, RemoteException 
	{
		ArrayList arrServiceChrgResult = null;

        try
        {
            EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                        "MasterSLHome"), MasterSLHome.class);
            _oMasterSL = _oMasterSLHome.create();
            arrServiceChrgResult = _oMasterSL.searchServiceCharge();

            return arrServiceChrgResult;
        }
        catch (CreateException cex)
        {
            log.exception(cex.getMessage());
            throw new EElixirException(cex, "P1007");
        }
        catch (RemoteException rex)
        {
            log.exception(rex.getMessage());
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            log.debug("CHMSLEJB--inside ejb exception");
            throw new EElixirException(ejbex, "P1007");
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
    }

    public void createServiceCharge(ArrayList arrServChargeResult)
    throws EElixirException, RemoteException
	{
	    try
	    {
	    	//<CODE_TAG: Q2_REL_FSD_change_in_treatment_ofservice_charge_V1.1 Dated: 07/Apr/2011 Starts>
	    	log.debug("CreateServiceCharge Starts");
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "MasterSLHome"), MasterSLHome.class);
	        _oMasterSL = _oMasterSLHome.create();
	        _oMasterSL.createServiceCharge(arrServChargeResult);
	        log.debug("CreateServiceCharge Ends");
	        //<CODE_TAG: Q2_REL_FSD_change_in_treatment_ofservice_charge_V1.1 Dated: 07/Apr/2011 Ends>
	    }
	    catch (CreateException ce)
	    {
	        throw new EElixirException(ce, "P1007");
	    }
	    catch (EJBException ejbex)
	    {
	        throw (EElixirException) ejbex.getCausedByException();
	    }
	    catch (EElixirException eex)
	    {
	        throw eex;
	    }
	}
	/*End:Rel. Q2 change treatment ofservice charge V1.0 - Monika  06-01-11 */	
    
    /* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping START */
    
    public void createCapping(ArrayList a_oCappingResult)  throws EElixirException, RemoteException
    {
		try
		{
			log.debug("CHESLEJB createCapping Starts");
		    EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		    CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		    _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
		                "MasterSLHome"), MasterSLHome.class);
		    _oMasterSL = _oMasterSLHome.create();
		    
		    log.debug("CHESLEJB createCapping after create");
		    _oMasterSL.createCapping(a_oCappingResult);
		
		   // return lCapSeqNbr;
		}
		catch (CreateException ce)
		{
		    throw new EElixirException(ce, "P1007");
}
		catch (FinderException cex)
		{
		    log.fatal("CHMSLEJB--inside finder exception");
		    throw new EElixirException(cex, "P1007");
		}
		catch (EJBException ejbex)
		{
		    throw (EElixirException) ejbex.getCausedByException();
		}
		catch (EElixirException eex)
		{
		    throw eex;
		}
    
    }
    
    public ArrayList searchCapping() throws EElixirException, FinderException
	{
	    ArrayList oCapResult = null;
	
	    try
	    {
	    	log.debug("searchCapping--CHMSLEJB-START");
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "MasterSLHome"), MasterSLHome.class);
	        _oMasterSL = _oMasterSLHome.create();
	        log.debug("searchCapping--CHMSLEJB-START before");
	        oCapResult = _oMasterSL.searchCapping();
	        log.debug("searchCapping--CHMSLEJB-END");
	
	        return oCapResult;
       
	    }
	    catch (CreateException ce)
	    {
	        throw new EElixirException(ce, "P1007");
	    }
	    catch (RemoteException rex)
	    {
	        throw new EElixirException(rex, "P1006");
	    }
	    catch (EJBException ejbex)
	    {
	        throw (EElixirException) ejbex.getCausedByException();
	    }
	    catch (EElixirException eex)
	    {
	        throw eex;
	    }
	}
    
    /* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping END */
    
    /*Added by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: START */
    public ArrayList searchChannelProdSeg() throws EElixirException, FinderException
	{
	    ArrayList oCapResult = null;
	
	    try
	    {
	    	log.debug("searchCapping--CHMSLEJB-START");
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "MasterSLHome"), MasterSLHome.class);
	        _oMasterSL = _oMasterSLHome.create();
	        log.debug("searchChannelProdSeg--CHMSLEJB-START before");
	        oCapResult = _oMasterSL.searchChannelProdSeg();
	        log.debug("searchChannelProdSeg--CHMSLEJB-END");
	
	        return oCapResult;
       
	    }
	    catch (CreateException ce)
	    {
	        throw new EElixirException(ce, "P1007");
	    }
	    catch (RemoteException rex)
	    {
	        throw new EElixirException(rex, "P1006");
	    }
	    catch (EJBException ejbex)
	    {
	        throw (EElixirException) ejbex.getCausedByException();
	    }
	    catch (EElixirException eex)
	    {
	        throw eex;
	    }
	} 
        
    /*Added by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: END */
    
    /* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation START */
    
    public ArrayList getWeightageList(Long lSeqNo) throws EElixirException, FinderException
	{
	    ArrayList arrlWeightageResult = null;
	
	    try
	    {
	    	log.debug("getWeightageList--CHMSLEJB-START");
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "MasterSLHome"), MasterSLHome.class);
	        _oMasterSL = _oMasterSLHome.create();
	        log.debug("getWeightageList--CHMSLEJB-START before");
	        arrlWeightageResult = _oMasterSL.getWeightageList(lSeqNo);
	        log.debug("getWeightageList--CHMSLEJB-END");
	
	        return arrlWeightageResult;
       
	    }
	    catch (CreateException ce)
	    {
	        throw new EElixirException(ce, "P1007");
	    }
	    catch (RemoteException rex)
	    {
	        throw new EElixirException(rex, "P1006");
	    }
	    catch (EJBException ejbex)
	    {
	        throw (EElixirException) ejbex.getCausedByException();
	    }
	    catch (EElixirException eex)
	    {
	        throw eex;
	    }
	}
    
    public void updateWeightage(ArrayList arrlWeightageResult)  throws EElixirException, RemoteException
    {
		try
		{
			log.debug("CHESLEJB updateWeightage Starts");
		    EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		    CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
		    _oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
		                "MasterSLHome"), MasterSLHome.class);
		    _oMasterSL = _oMasterSLHome.create();
		    
		    log.debug("CHESLEJB updateWeightage after create");
		    _oMasterSL.updateWeightage(arrlWeightageResult);
		
		   
		}
		catch (CreateException ce)
		{
		    throw new EElixirException(ce, "P1007");
		}
		catch (FinderException cex)
		{
		    log.fatal("CHMSLEJB--inside finder exception");
		    throw new EElixirException(cex, "P1007");
		}
		catch (EJBException ejbex)
		{
		    throw (EElixirException) ejbex.getCausedByException();
		}
		catch (EElixirException eex)
		{
		    throw eex;
		}
    
    }
    
    /* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation END */
    
    /* Added by Manisha on 10 Oct 2011-FIN 393_Professional_Tax START */
    
    public StateResult searchStateTax(Long a_strPerstType) throws FinderException, EElixirException
    {
    	StateResult strResult = null;
    	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
    	CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
    	log.debug("CHMSLEJB--before Lookup");
    	_oMasterSLHome = (MasterSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
        			"MasterSLHome"), MasterSLHome.class);
    	log.debug("CHMSLEJB--After Lookup");

	    try
	    {
	    	_oMasterSL = _oMasterSLHome.create();
	        log.debug("CHMSLEJB--Inside try");
	        strResult = _oMasterSL.searchStateTax(a_strPerstType);
	    }
	    catch (CreateException cex)
	    {
	        log.debug("CHMSLEJB--CreateException ");
	        throw new EElixirException(cex, "P1006");
	    }
	    catch (RemoteException cex)
	    {
	        log.debug("CHMSLEJB--RemoteeException ");
	        throw new EElixirException(cex, "P1006");
}
    
	    return strResult;
}

    /* Added by Manisha on 10 Oct 2011-FIN 393_Professional_Tax END */

    //<CODE_TAG: FSD_CBP_WPC_Calculation AddedBy: Alexpandiyan Dated: 28/9/2011 Starts>
    public String getAllCBPSetUpChannel()throws RemoteException, EElixirException
    {
    	String strChannels="";
    	try
    	{    	
	        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	        _oAgencySLHome = (AgencySLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                    "AgencySLHome"), AgencySLHome.class);
	        _oAgencySL = _oAgencySLHome.create();
	        strChannels=_oAgencySL.getAllCBPSetUpChannel();
    	}
    	catch (CreateException cex)
    	{
    		log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " + cex);
    		throw new EElixirException(cex.getMessage());
    	}
    	catch (RemoteException rex)
    	{
    		log.debug("CHMSLEJB--RemoteError in Busines method of CHMSLEJB " + rex);
        	throw new EElixirException(rex.getMessage());
    	}
    	return strChannels;
    }
    //<CODE_TAG: FSD_CBP_WPC_Calculation AddedBy: Alexpandiyan Dated: 28/9/2011 Ends>

	// <CODE_TAG: FSD_SSO_Location_Changes AddedBy: Alexpandiyan Dated: 7/10/2011 Starts> 
    public Map fetchLocationByUserId(String userId)throws RemoteException, EElixirException
    {
    	Map locationMap=null;
    	try{
    	 _oCommonSL = getCommonSL("CommonSLHome", CommonSLHome.class);
    	 locationMap= _oCommonSL.fetchLocationByUserId(userId);
    	}
    	catch (CreateException cex)
     	{
     		log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " + cex);
     		throw new EElixirException(cex.getMessage());
     	}    	
    	return locationMap;
    }
 // <CODE_TAG: FSD_SSO_Location_Changes AddedBy: Alexpandiyan Dated: 7/10/2011 Ends>
    
    /* Added by Manisha on 15-May-2014 for Release 15.1 FSD_AGN867_ SurrenderRateSegmentationCriteria STARTS*/
    public void createSurrenderRateDef(SurrenderRateDefResult a_oSurrenderRateDefResult) throws FinderException, EElixirException
    {
	    EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
	    CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	    log.debug("CHMSLEJB--before Lookup");
	    _oSurrendRateDefSLHome = (SurrenderRateDefSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                "SurrenderRateDefSLHome"), SurrenderRateDefSLHome.class);
	    log.debug("CHMSLEJB--After Lookup");
	
	    try
	    {
	        _oSurrendRateDefSL = _oSurrendRateDefSLHome.create();
	        log.debug("CHMSLEJB--Inside try");
	        _oSurrendRateDefSL.createSurrenderRateDef(a_oSurrenderRateDefResult);
	    }
	
	    catch (CreateException rex)
	    {
	        log.exception(rex.getMessage());
	        throw new EElixirException(rex, "P1006");
	    }
	    catch (RemoteException rex)
	    {
	        log.exception(rex.getMessage());
	        throw new EElixirException(rex, "P1006");
	    }
	    catch (EElixirException rex)
	    {
	        log.exception(rex.getMessage());
	        throw rex;
	    }
	
	    log.debug("CHMSLEJB--returning back to SurrenderRateDef action class");
    }
    
    public SurrenderRateDefResult searchSurrenderRateDef(Short strParam) throws FinderException, EElixirException
    {
    	SurrenderRateDefResult strResult = null;
	    EJBHomeFactory objEJBHomeFactoryLocal = EJBHomeFactory.getFactory();
	    CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
	    log.debug("CHMSLEJB--before Lookup");
	    _oSurrendRateDefSLHome = (SurrenderRateDefSLHome) objEJBHomeFactoryLocal.lookUpHome(oCHMPropertyUtil.getCHMProperty(
	                "SurrenderRateDefSLHome"), SurrenderRateDefSLHome.class);
	    log.debug("CHMSLEJB--After Lookup");
	
	    try
	    {
	    	_oSurrendRateDefSL = _oSurrendRateDefSLHome.create();
	        log.debug("CHMSLEJB--Inside try");
	        strResult = _oSurrendRateDefSL.searchSurrenderRateDef(strParam);
	    }
	    catch (CreateException cex)
	    {
	        log.debug("CHMSLEJB--CreateException ");
	        throw new EElixirException(cex, "P1006");
	    }
	    catch (RemoteException cex)
	    {
	        log.debug("CHMSLEJB--RemoteeException ");
	        throw new EElixirException(cex, "P1006");
	    }
	
	    return strResult;
    }
    /* Added by Manisha on 15-May-2014 for Release 15.1 FSD_AGN867_ SurrenderRateSegmentationCriteria ENDS*/

   // Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Starts   
    public CollectionParamResult saveCollectionParams(CollectionParamResult collectionParam )throws RemoteException, EElixirException
    {
    	Map locationMap=null;
    	try{
    		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup for CommissionSLHome");
    		_oCommissionSLHome = (CommissionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("CommissionSLHome"), CommissionSLHome.class);
    		log.debug("CHMSLEJB--After Lookup for CommissionSLHome");

            _oCommissionSL = _oCommissionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            collectionParam = _oCommissionSL.saveCollectionParams(collectionParam);
    	}
    	catch (CreateException cex)
     	{
     		log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " + cex);
     		throw new EElixirException(cex.getMessage());
     	} catch (FinderException fex) {
     		log.debug("CHMSLEJB--FinderError in Busines method of CHMSLEJB " + fex);
     		throw new EElixirException(fex.getMessage());
		}    	
    	return collectionParam;
    }
    
    public CollectionParamResult getCollectionParams()throws RemoteException, EElixirException
    {
    	CollectionParamResult collectionParam = null;
    	try{
    		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("CHMSLEJB--before Lookup for CommissionSLHome");
    		_oCommissionSLHome = (CommissionSLHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("CommissionSLHome"), CommissionSLHome.class);
    		log.debug("CHMSLEJB--After Lookup for CommissionSLHome");

            _oCommissionSL = _oCommissionSLHome.create();
            log.debug("CHMSLEJB--Inside try");
            collectionParam = _oCommissionSL.getCollectionParams();
    	}
    	catch (CreateException cex)
     	{
     		log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB " + cex);
     		throw new EElixirException(cex.getMessage());
     	} catch (FinderException fex) {
     		log.debug("CHMSLEJB--FinderError in Busines method of CHMSLEJB " + fex);
     		throw new EElixirException(fex.getMessage());
		}    	
    	return collectionParam;
    }
	// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Ends

	// Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Starts
	public ArrayList getDisbursementSetup() throws RemoteException,
			EElixirException {
		ArrayList disbursementSetup = null;
		try {
			log.debug("CHMSLEJB--getDisbursementSetup--Ends");
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil
					.getPropertyUtil();
			_oCommissionSLHome = (CommissionSLHome) objEJBHomeFactory
					.lookUpHome(
							oCHMPropertyUtil.getCHMProperty("CommissionSLHome"),
							CommissionSLHome.class);
			_oCommissionSL = _oCommissionSLHome.create();
			disbursementSetup = _oCommissionSL.getDisbursementSetup();
			log.debug("CHMSLEJB--getDisbursementSetup--Ends");
		} catch (CreateException cex) {
			log.debug("CHMSLEJB--CreateError in Busines method of CHMSLEJB "
					+ cex);
			throw new EElixirException(cex.getMessage());
		} catch (RemoteException rex) {
			log.debug("CHMSLEJB--FinderError in Busines method of CHMSLEJB "
					+ rex);
			throw new EElixirException(rex.getMessage());
		}
		return disbursementSetup;
	}

	public void SaveUpdateDisbumSetupDetails(ArrayList _oDisbumSetuplst)
			throws EJBException, RemoteException, EElixirException {
		try {
			log.debug("CHMSLEJB--SaveUpdateDisbumSetupDetails--Starts");
			EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
			CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil
					.getPropertyUtil();
			_oCommissionSLHome = (CommissionSLHome) objEJBHomeFactory
					.lookUpHome(
							oCHMPropertyUtil.getCHMProperty("CommissionSLHome"),
							CommissionSLHome.class);
			_oCommissionSL = _oCommissionSLHome.create();
			_oCommissionSL.SaveUpdateDisbumSetupDetails(_oDisbumSetuplst);
			log.debug("CHMSLEJB--SaveUpdateDisbumSetupDetails--Ends");
		} catch (CreateException cex) {
			throw new EElixirException(cex, "P1007");
		} catch (RemoteException rex) {
			throw new EElixirException(rex, "P1007");
		} catch (EJBException ejbex) {
			throw new EElixirException(ejbex, "P1007");
		}

	}
	// Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Ends

//  Rohit Kumar  AGN 929 Starts 25 June 2017 Starts 
	 public void updateApplicationAmlUlipTraining(ApplicationResult oApplicationResult)
	  throws EElixirException
	 {
	   try
	   {
		   _oApplicationSL = getApplicationSL("ApplicationSLHome",
	               ApplicationSLHome.class);
	      _oApplicationSL.updateApplicationAmlUlipTraining(oApplicationResult);
	   }
	  catch (CreateException ce)
	  {
	      throw new EElixirException(ce, "P1007");
	  }
	  catch (RemoteException rex)
	  {
	      throw new EElixirException(rex, "P1006");
	  }
	  catch (EJBException ejbex)
	  {
	      throw (EElixirException) ejbex.getCausedByException();
	  }
	  catch (EElixirException eex)
	  {
	      throw eex;
	  }
	}
	//  Rohit Kumar  AGN 929 Starts 25 June 2017 ends
	 
	//  Aradhana Pandey  AGN 929 Starts 11_Jul_2017 Starts 
	 //Commented By Aradhana 11_Jul_2017:: STARTS
	 public ApplicationResult searchApplicationAmlUlipTraining(long a_lApplcSeqNbr, String a_strAgentCd, String a_strApplcntType) throws EElixirException,RemoteException,FinderException,EJBException
	  
	 {
		 ApplicationResult applicationresult=null;
	   try
	   {
		   _oApplicationSL = getApplicationSL("ApplicationSLHome",
	               ApplicationSLHome.class);
		   applicationresult= _oApplicationSL.searchApplicationAmlUlipTraining(a_lApplcSeqNbr, a_strAgentCd, a_strApplcntType);
	  
	      return applicationresult;
	   }
	  catch (CreateException ce)
	  {
	      throw new EElixirException(ce, "P1007");
	  }
	  catch (RemoteException rex)
	  {
	      throw new EElixirException(rex, "P1006");
	  }
	  catch (EJBException ejbex)
	  {
	      throw (EElixirException) ejbex.getCausedByException();
	  }
	  catch (EElixirException eex)
	  {
	      throw eex;
	  }
	}
	
	//  Aradhana Pandey  AGN 929 Starts 11_Jul_2017 ends
}
