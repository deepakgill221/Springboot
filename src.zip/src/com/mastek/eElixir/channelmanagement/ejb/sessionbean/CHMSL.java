/********************************************************************
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  	BY				REASON
*--------------------------------------------------------------------------------
*1.1		07/04/2015		Vibhu Nigam		FIN838_AgentCommissionDisbursementLimitChange
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.benefit.util.BenefitResult;
import com.mastek.eElixir.channelmanagement.benefit.util.OtherBenefitResult;
import com.mastek.eElixir.channelmanagement.benefit.util.TPRResult;
import com.mastek.eElixir.channelmanagement.commission.dvo.CommissionRatesDetails;
import com.mastek.eElixir.channelmanagement.commission.dvo.ContractProdValidate;
import com.mastek.eElixir.channelmanagement.commission.util.CollectionParamResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommDispatchResult;
import com.mastek.eElixir.channelmanagement.commission.util.CommissionProjectionResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractCopyResult;
import com.mastek.eElixir.channelmanagement.commission.util.ContractResult;
import com.mastek.eElixir.channelmanagement.commission.util.DisbursementSetupResult;
import com.mastek.eElixir.channelmanagement.contest.util.ContestResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitResultMain;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaCriteriaResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardMasterResult;
import com.mastek.eElixir.channelmanagement.gpa.util.GpaStandardResult;
import com.mastek.eElixir.channelmanagement.master.util.CappingResult;
import com.mastek.eElixir.channelmanagement.master.util.CbpResult;
import com.mastek.eElixir.channelmanagement.master.util.CompanyResult;
import com.mastek.eElixir.channelmanagement.master.util.CustomSettingResult;
import com.mastek.eElixir.channelmanagement.master.util.ProductResult;
import com.mastek.eElixir.channelmanagement.master.util.QuestionResult;
import com.mastek.eElixir.channelmanagement.master.util.ServiceChargeResult;
import com.mastek.eElixir.channelmanagement.master.util.SubChannelResult;
import com.mastek.eElixir.channelmanagement.master.util.TaxResult;
//sunaina fin 122
import com.mastek.eElixir.channelmanagement.master.util.StateResult;
//sunaina fin 122
import com.mastek.eElixir.channelmanagement.master.util.AllocationMarkerResult;
import com.mastek.eElixir.channelmanagement.process.util.ProcessResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgencyResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentAgencyResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentContractDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentMovementDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentPerformanceDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentPersistancyDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentRefreeDetailResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.ApplicationResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.BlackListResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.BounceChargesExcemptionResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.ClientResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.AdjustedPaidCaseResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.IrdaRecordResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.ManualSegmentResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentWeightageResult;
import com.mastek.eElixir.channelmanagement.setup.util.PersistencyResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.BonusResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.DesignationResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.RepHierarchyResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.AgencyBranchTerminationResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.AgencyMovementResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.AgentMovementResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.MovementCriteriaResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.PolicyResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.PolicyTransferResult;
import com.mastek.eElixir.channelmanagement.structuremovements.util.SuspendResult;
import com.mastek.eElixir.channelmanagement.target.util.DairitenEvalDefinitionResult;
import com.mastek.eElixir.channelmanagement.target.util.ExcepAgencyPromoResult;
import com.mastek.eElixir.channelmanagement.target.util.TargetResult;
import com.mastek.eElixir.channelmanagement.util.ApprovalResult;
import com.mastek.eElixir.channelmanagement.util.CHMJQueryData;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.AddressMasterResult;
import com.mastek.eElixir.common.util.Log;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.UserResult;
import com.mastek.eElixir.channelmanagement.commission.util.FinderFeesResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult; 
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentCriteriaResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.MPSResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SurrenderRateDefResult;
/* Commented by jayasimha for Descoping of Lapse Rule and Lapse Rule Mapping 


import com.mastek.eElixir.channelmanagement.commission.util.LapseRuleResult;
import com.mastek.eElixir.channelmanagement.commission.util.LapseRuleMapResult;

End of the commented code*/

import com.mastek.eElixir.channelmanagement.commission.util.RYCRuleMasterSearchResult;
//AMID CSA/CPA SEARCH Start
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
//AMID CSA/CPA SEARCH End
import com.mastek.eElixir.channelmanagement.structuremovements.util.ManualOverrideResult;
import com.mastek.eElixir.channelmanagement.structuremaintenance.util.BonusSlabResult;
import com.mastek.eElixir.channelmanagement.recruitment.util.AgentSegmentHistoryResult;





// Vikrant - End
public interface CHMSL extends EJBObject
{
    /* Added onsite by Vinay Cerejo on 08/01/2003 -- START */
    public ArrayList getChannelDesignationMasterList()
        throws RemoteException, EElixirException;

    /* Added onsite by Vinay Cerejo on 08/01/2003 -- END */
    //Modified by Amid for Pagination
    public SearchData agentAgencyListSearch(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    public AgentAgencyResult agentAgencySearch(String a_strAgentCd,int iDetReqd)
        throws RemoteException, FinderException, EElixirException;
    //Modified by Amid for FSD_AGN_69_Restriction on Agent movement v1.2 Start
    public AgentAgencyResult AgentAgencyTerminationEntry(String a_strAgentCd)
    throws RemoteException, FinderException, EElixirException;
    //Modified by Amid for FSD_AGN_69_Restriction on Agent movement v1.2 End

    public void createApproval(ApprovalResult a_ApprovalResult)
        throws RemoteException, FinderException, EElixirException;
    //Rajeev_ManualOverride_CR_01122010 Start
    public void manualoverrideApproval(ApprovalResult a_ApprovalResult)
    throws RemoteException, FinderException, EElixirException;
    //Rajeev_ManualOverride_CR_01122010 End

    public String searchApproval(SearchData o_SearchData)
        throws RemoteException, FinderException, EElixirException;

    ///////////////////////////////////// CODE BY JIMMY START HERE ////////////////////////////
    public String getAgencyCd(String a_strAgentCd)
        throws EElixirException, RemoteException;

    public Short getAgencyLength() throws EElixirException, RemoteException;
	//Added by Srikanth CTS for App and DOJ functionality
	public ArrayList getDesignationsApplicable() throws EElixirException, RemoteException;

    public long createApplication(ApplicationResult oApplicationResult)
        throws RemoteException, EElixirException;

    public void updateApplication(ApplicationResult oApplicationResult)
        throws RemoteException, EElixirException;

    public ApplicationResult searchApplication(long a_lApplcSeqNbr,
        String a_strAgentCd, String a_strApplcntType)
        throws RemoteException, EElixirException;

  //Modified by Prabhat For Pagination Start
    public SearchData searchApplication(SearchData a_oSearchData)
        throws RemoteException, EElixirException;

  //Modified by Prabhat For Pagination End
    
    public void updateApplicationStatusOnSubmit(
        ApplicationResult oApplicationResult)
        throws RemoteException, EElixirException;

    public void updateApplicationStatusOnSubmitBackword(
        ApplicationResult oApplicationResult)
        throws RemoteException, EElixirException;

    public AgentResult searchAgent(String a_strAgentCd)
        throws RemoteException, EElixirException;

    public AgencyResult searchAgency(String a_strAgentCd)
        throws RemoteException, EElixirException;

    public void updateAgent(AgentResult oAgentResult)
        throws RemoteException, EElixirException;

    public void updateAgency(AgencyResult oAgencyResult)
        throws RemoteException, EElixirException;

    public String approveApplication(ApplicationResult oApplicationResult)
        throws RemoteException, EElixirException;

    public void updateCompany(CompanyResult oCompanyResult)
        throws RemoteException, EElixirException;

    public CompanyResult searchCompany()
        throws RemoteException, FinderException, EElixirException;

    ///////////////////////////////////// CODE BY JIMMY END HERE ////////////////////////////
    //////////////
    //NO OWNER
    /////////////////////
    public SearchData agencyListSearch(SearchData oSSearchData)
        throws RemoteException, FinderException, EElixirException;

    public SearchData agentListSearch(SearchData oSSearchData)
        throws RemoteException, FinderException, EElixirException;
    
//FIn_126_Anantha starts
	
    /**
     * Gives the List of Agents
         * @param a_oSearchData
         * @return String
         * @throws RemoteException
         * @throws FinderException
         * @throws EElixirException
         */
	 public String searchAgentTxAcct(SearchData a_oSearchData) 
	 throws RemoteException, FinderException, EElixirException;

    //////////////
    //NO OWNER
    /////////////////////
    //Code Starts By Vinaysheel
    public String searchContractMap(SearchData _oSearchData)
        throws RemoteException, FinderException, EElixirException;

    public long createContractMap(ArrayList al_ContractMapResult)
        throws RemoteException, CreateException, EElixirException;

    public String searchContract()
        throws RemoteException, FinderException, EElixirException;

    public ArrayList searchContractMap(long _iLContMapSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public void updateContractMap(ArrayList al_oContractMapResult)
        throws RemoteException, CreateException, EElixirException;

    public ArrayList searchAgencyDoc(String a_searchAgencyDoc)
        throws RemoteException, FinderException, EElixirException;

    //Code added for persistency
    public String searchPersistency(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    public void createPersistency(PersistencyResult a_oPersistencyResult)
        throws RemoteException, FinderException, EElixirException;

    public void updatePersistency(PersistencyResult a_oPersistencyResult)
        throws RemoteException, FinderException, EElixirException;

    public PersistencyResult searchPersistency(String a_strPerstType)
        throws RemoteException, FinderException, EElixirException;

    //Code added for SubChannel
    public ArrayList searchSubChannel(String a_cChannelType)
        throws RemoteException, FinderException, EElixirException;

    public void updateSubChannel(ArrayList a_oSubChannelList)
        throws RemoteException, FinderException, EElixirException;

    //Code added for UserParameter
    public ArrayList searchUserParameter(int a_iParamTypeCd)
        throws RemoteException, FinderException, EElixirException;

    public void updateUserParameter(ArrayList a_oUserParameterList)
        throws RemoteException, FinderException, EElixirException;

    //code for selfContract
    public ArrayList searchSelfContract(SearchData oSSearchData)
        throws RemoteException, FinderException, EElixirException;

    public void updateSelfContract(ArrayList a_oSelfContractList)
        throws RemoteException, FinderException, EElixirException;

    //code for Clawback

    /*
      * Invoked by the session bean to look up the ContractSLEJB for searching of Clawback .
      * @param oSSearchData oSSearchData
      * @throws RemoteException
      * @throws EJBException
     */
    public ArrayList searchClawback(SearchData oSSearchData)
        throws RemoteException, FinderException, EElixirException;

    public void updateClawback(ArrayList a_oClawbackList)
        throws RemoteException, FinderException, EElixirException;

    //code ends by Vinaysheel
    ///////////////////////////////////////////code added by Prasad for Designation And Reporting Links module////////////////////

    /* Designation Related Methods*/
    public String searchDesignation(SearchData oSearchData)
        throws RemoteException, EElixirException;

    public DesignationResult searchDesignationCode(String strChannelType)
        throws RemoteException, EElixirException, FinderException;

    public DesignationResult searchDesignation(String a_ostrDesgnCd)
        throws RemoteException, FinderException, EElixirException, EJBException;

    public void createDesignation(DesignationResult oDesignationResult)
        throws RemoteException, EJBException, EElixirException;

    public void updateDesignation(DesignationResult oDesignationResult)
        throws RemoteException, EElixirException;

    /* Designation Related Methods End*/
    /* Reporting Links Related Methods*/
    public void updateReportingStructure(
        RepHierarchyResult a_oRepHeirarchyResult)
        throws EElixirException, FinderException, RemoteException;

    public void createReportingStructure(
        RepHierarchyResult a_oRepHeirarchyResult)
        throws EElixirException, FinderException, RemoteException;

    public String searchReportingStructure(SearchData a_oSearchData)
        throws EElixirException, FinderException, RemoteException;

    public RepHierarchyResult searchReportingStructure(String strRepLinkCode)
        throws RemoteException, EElixirException, FinderException;

    /*Payment WithHold Methods*/

    //public void updatePaymentWithHold(ArrayList alPaymentWithHoldResult)throws EElixirException,CreateException, RemoteException;
    //public ArrayList searchPaymentWithHold(SearchData oSearchData )throws EElixirException,FinderException,RemoteException;

    /*Payment WithHold Methods*/
    public void updatePaymentWithHold(ArrayList alPaymentWithHoldResult)
        throws EElixirException, CreateException, RemoteException;

    public ArrayList searchPaymentWithHold(SearchData oSearchData)
        throws EElixirException, FinderException, RemoteException;

    ///////////////////////////////////////////code ends by Prasad for Designation And Reporting Links module////////////////////
    // ****************************** Module for Pallav starts ******************************
    // *****************************Commission starts here *****************************
    public String searchContract(Object a_oResultObject)
        throws RemoteException, FinderException, EElixirException;
   //By Himanshu

    /* Himanshu FIN 393_Professional_Tax START */
    public String searchvalidValue( )throws RemoteException, EJBException, EElixirException ;

    /*  Himanshu on FIN 393_Professional_Tax Ends */
    public ContractResult searchContract(long a_lCommAgrmtSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public long createCommissionContract(ContractResult a_oContractResult)
        throws RemoteException, EJBException, EElixirException;

    public void updateCommissionContract(ContractResult a_oContractResult)
        throws RemoteException, EJBException, EElixirException;

    public void deleteContract(long a_lCommAgrmtSeqNbr,
        ContractResult a_oContractResult)
        throws RemoteException, RemoveException, FinderException, 
            EElixirException;

    public ContractProdValidate getContractBaseUnit(
        ContractProdValidate a_oContractProdValidate)
        throws FinderException, RemoteException, EElixirException;

    // *****************************Commission ends here *****************************
    // *****************************Copy Contract starts here *****************************
    public void copyContract(ContractCopyResult oContractCopyResult)
        throws FinderException, RemoteException, EElixirException;

    // *****************************Copy Contract ends here *****************************
    // *****************************Benefit starts here *****************************
    public BenefitResult searchBenefit(long a_lbenseqnbr)
        throws RemoteException, FinderException, EElixirException;

    public long createBenefit(BenefitResult a_oBenefitResult)
        throws EJBException, EElixirException, RemoteException;

    public void updateBenefit(BenefitResult a_oBenefitResult)
        throws EJBException, EElixirException, RemoteException;

    public String searchBenefit(Object a_oResultObject)
        throws FinderException, EElixirException, RemoteException;

    public void deleteBenefit(BenefitResult a_oBenefitResult)
        throws RemoveException, FinderException, EElixirException, 
            RemoteException;

    // *****************************Benefit ends here *****************************
    // *****************************Formula starts here for unit, group and formula*****************************
    public String searchUnit(Object a_oResultObject)
        throws FinderException, EElixirException, RemoteException;

    public UnitResultMain searchUnit(String a_strUnitId)
        throws RemoteException, FinderException, EElixirException;

    public String createUnit(UnitResultMain oUnitResultMain)
        throws EJBException, EElixirException, RemoteException;

    public void updateUnit(UnitResultMain oUnitResultMain)
        throws EJBException, EElixirException, RemoteException;

    public String searchGroup(Object a_oResultObject)
        throws FinderException, EElixirException, RemoteException;

    public ArrayList searchGroup(String a_strGroupId)
        throws RemoteException, FinderException, EElixirException;

    public String createGroup(ArrayList a_arrGroup)
        throws EJBException, EElixirException, RemoteException;

    public void updateGroup(ArrayList a_arrGroup)
        throws EJBException, EElixirException, RemoteException;

    public String searchFormula(Object a_oResultObject)
        throws FinderException, EElixirException, RemoteException;

    public FormulaResult searchFormula(long a_lFormlDefnSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public long createFormula(FormulaResult a_oFormulaResult)
        throws EJBException, EElixirException, RemoteException;

    public void updateFormula(FormulaResult a_oFormulaResult)
        throws EJBException, EElixirException, RemoteException;

    // *****************************Formula ends here for unit, group and formula*****************************
    // *****************************Channel starts here****************************
    public ArrayList searchChannel()
        throws RemoteException, FinderException, EElixirException;

    public void updateChannel(ArrayList a_arrChannelResult)
        throws RemoteException, FinderException, EJBException, EElixirException;

    public SubChannelResult searchSubChannel(Character a_cChannelType)
        throws RemoteException, FinderException, EJBException, EElixirException;

    // *****************************Channel ends here****************************
    // *****************************Contest ends here *****************************
    public ContestResult searchContest(long a_lcontestseqnbr)
        throws RemoteException, FinderException, EElixirException;

    public long createContest(ContestResult a_oContestResult)
        throws EJBException, EElixirException, RemoteException;

    public void updateContest(ContestResult a_oContestResult)
        throws EJBException, EElixirException, RemoteException;

    public String searchContest(Object a_oResultObject)
        throws FinderException, EElixirException, RemoteException;

    public void deleteContest(ContestResult a_oContestResult)
        throws RemoveException, FinderException, EElixirException, 
            RemoteException;

    // *****************************Contest ends here *****************************
    // ***************************** MOvementCriteria Starts here ********************
    public String searchMovementCriteria(Object a_oResultObject)
        throws FinderException, EElixirException, RemoteException;

    public MovementCriteriaResult searchMovementCriteria(long a_lmovmnseqnbr)
        throws RemoteException, FinderException, EElixirException;

    public long createMovementCriteria(
        MovementCriteriaResult a_oMovementCriteriaResult)
        throws EJBException, EElixirException, RemoteException;

    public void updateMovementCriteria(
        MovementCriteriaResult a_oMovementCriteriaResult)
        throws EJBException, EElixirException, RemoteException;

    // ***************************** MovementCriteria ends here **********************
    // // *****************************Module for Pallav ends here****************************
    //*******************************Vinaysheel's code starts here****************************
    //******************************Structure Movements code starts here**********************
    public SuspendResult searchSuspend(Long a_oLAgntSuspnSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public long createSuspend(SuspendResult a_oSuspendResult)
        throws EJBException, EElixirException, RemoteException;

    public void updateSuspend(SuspendResult a_oSuspendResult)
        throws EJBException, EElixirException, RemoteException;

    public SuspendResult searchPastSuspensions(String a_strAgentCd)
        throws RemoteException, FinderException, EElixirException;
  // Added by Amid for pagination
    public SearchData searchSuspend(SearchData a_oSearchData)
        throws EElixirException, FinderException, RemoteException;

    //******************************Structure Movements code ends here**********************
    //*******************************Vinaysheel's code ends here****************************
    ///////////////////////////////////// CODE BY JIMMY START HERE ////////////////////////////
    public long createBlackList(BlackListResult oBlackListResult)
        throws RemoteException, EElixirException;

    public void updateBlackList(BlackListResult oBlackListResult)
        throws RemoteException, EElixirException;

    public BlackListResult searchBlackList(long a_lLiaBlackListSeqNbr)
        throws RemoteException, EElixirException;

    //Method to Audit Menu Item Clicks in Database
    public void createMenuAccessLog(String strUserId, String strOptionAccess)
        throws RemoteException, EElixirException;

    public ArrayList getBranchList(String a_strBankCd)
        throws RemoteException, EElixirException;

    public AddressMasterResult addressMasterSearch(String a_strAddrCd)
        throws RemoteException, EElixirException;

    ///////////////////////////////////// CODE BY JIMMY END HERE ////////////////////////////
    //*********** Code by Amit N Starts Here ***************************************/
    public String searchBlackList(SearchData a_oSearchData)
        throws EElixirException, FinderException, RemoteException;

    //********** Code by Amit N Ends Here ******************************************/
    //*********************Sandeep start**********************************
    //**********************************AgentMovement starts here*****************************************
    //Sandeep Bangera
    public String searchMovements(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    public AgentMovementResult searchAgentMovement(Long a_lAgntMovmnSeqNbr)
        throws RemoteException, FinderException, EElixirException;
  //<Added by Ankita on 1.06.2012 for MO changes :START>
    public AgentResult searchAgentDetailsForAgentMovement(String a_strAgentCd,String a_strScreenName,String dtEffFrom)
        throws RemoteException, FinderException, EElixirException;
  //<Added by Ankita on 1.06.2012 for MO changes :END>
    public Short searchDesignationLevelForAgentMovement(String a_strNewDesgnCd)
        throws RemoteException, FinderException, EElixirException;

    public long createAgentMovement(AgentMovementResult oAgentMovementResult)
        throws RemoteException, EElixirException;

    public void updateAgentMovement(AgentMovementResult oAgentMovementResult)
        throws RemoteException, EElixirException;

    public ArrayList searchSubOrdinateDetails(Long a_lAgntMovmnSeqNbr,
        String a_strAgentCd)
        throws RemoteException, FinderException, EElixirException;

    //**********************************PolicyTransfer starts here*****************************************
    public String searchPolicyTransfer(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    public long createPolicyTransferEntry(
        PolicyTransferResult oPolicyTransferResult,
        ArrayList alPolicyTransferDetailResult)
        throws RemoteException, EElixirException;

    public PolicyTransferResult searchPolicyTransferEntry(long a_lpolhdrseqnbr)
        throws RemoteException, FinderException, EElixirException;

    public void updatePolicyTransfer(
        PolicyTransferResult a_oPolicyTransferResult,
        ArrayList alPolicyTransferDetailResult)
        throws EJBException, EElixirException, RemoteException;

    public ArrayList searchPolicyTransferDetailEntry(Long a_lpolhdrseqnbr,
        String a_strAgentCd, Short _nPolTrfType)
        throws RemoteException, FinderException, EElixirException;

    public PolicyTransferResult searchSupervisor(String a_strAgentCd)
        throws RemoteException, FinderException, EElixirException;

    //Sandeep Bangera
    /*public String searchAgencyBranchTermination(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;*/

    //Sandeep Bangera
    /*public AgencyBranchTerminationResult searchAgencyBranchTermination(
        long lAgntMovmnSeqNbr)
        throws RemoteException, FinderException, EElixirException;*/

    //Sandeep Bangera
    /*public long createAgencyBranchTermination(
        AgencyBranchTerminationResult a_oAgencyBranchTerminationResult)
        throws RemoteException, FinderException, EElixirException;*/

    //Sandeep Bangera
    /*public void updateAgencyBranchTermination(
        AgencyBranchTerminationResult a_oAgencyBranchTerminationResult)
        throws RemoteException, FinderException, EElixirException;*/

    //Sandeep Bangera
    public String searchDairitenEvalDefinition(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    //SANDEEP BANGERA 18th Dec'02
    public void createDairitenEvalDefinition(
        DairitenEvalDefinitionResult oDairitenEvalDefinitionResult)
        throws RemoteException, FinderException, EElixirException;

    //*******************************Amit N's code for Targets starts here****************************
    public DairitenEvalDefinitionResult searchDairitenEvalDefinition(
        String a_strSubChannelType)
        throws RemoteException, FinderException, EElixirException; //amits method

    public void updateDairitenEvalDefinition(
        DairitenEvalDefinitionResult oDairitenEvalDefinitionResult)
        throws RemoteException, EElixirException, EJBException;

    //end addition sandeep on 23rd Dec '02

    /* Exceptional Agency Promotion starts
    */
    public String searchExcepAgencyPromo(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    public ExcepAgencyPromoResult searchExceptionalAgencyPromotion(
        long lAgencyPromSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public long createExceptionalAgencyPromotion(
        ExcepAgencyPromoResult _oExcepAgencyPromoResult)
        throws RemoteException, FinderException, EElixirException;

    public void updateExceptionalAgencyPromotion(
        ExcepAgencyPromoResult _oExcepAgencyPromoResult)
        throws RemoteException, FinderException, EElixirException;

    public ExcepAgencyPromoResult searchCurrentRank(String a_strAgentCd)
        throws RemoteException, FinderException, EElixirException;

    /* Exceptional Agency Promotion ends
    */

    //******************************Target code starts here**********************
    public ArrayList searchTarget(TargetResult _oTargetResult)
        throws RemoteException, FinderException, EElixirException;

    public void createTarget(ArrayList alTarget)
        throws RemoteException, FinderException, EElixirException;

    public void updateTarget(ArrayList alTarget)
        throws RemoteException, FinderException, EElixirException;

    public ArrayList searchTargetDetail(Long a_lSelfRefNbr)
        throws RemoteException, FinderException, EElixirException;

    public String searchTargetDefinition(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    //******************************Target code ends here**********************
    // ***********************Commission Projection Starts Here************************************
    public String searchCommissionProjection(Object a_oResultObject)
        throws RemoteException, FinderException, EElixirException;

    public CommissionProjectionResult searchCommissionProjection(
        long a_lComProjSeqNbr)
        throws FinderException, EElixirException, RemoteException;

    public long createCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws EJBException, EElixirException, RemoteException;

    public void updateCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws EJBException, EElixirException, RemoteException;

    public void deleteCommissionProjection(
        CommissionProjectionResult a_oCommissionProjectionResult)
        throws RemoveException, FinderException, EElixirException, 
            RemoteException;

    // ***********************Commission Projection ends Here************************************
    public ArrayList searchMenu()
        throws RemoteException, FinderException, EElixirException;

    public void updateMenu(ArrayList a_arrMenuResult)
        throws RemoteException, FinderException, EJBException, EElixirException;

    public ArrayList searchSubMenu(String a_strMenuId)
        throws RemoteException, FinderException, EElixirException;

    public void updateSubMenu(ArrayList a_arrSubMenuResult)
        throws RemoteException, FinderException, EJBException, EElixirException;

    public ArrayList searchPrivilege(String a_strSubMenuId)
        throws RemoteException, FinderException, EElixirException;

    public void updatePrivilege(ArrayList a_arrPrivilegeResult)
        throws RemoteException, FinderException, EJBException, EElixirException;

    //****************Methods for UserPrivilege******************************
    public ArrayList searchUserPrivilege(Long lRoleSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public void updateUserPrivilege(ArrayList a_oUserPrivilegeList,Long lRoleseqNbr)
        throws RemoteException, FinderException, EElixirException;

    public void copyUserPrivilege(Long lSrcRoleSeqNbr, Long lTrgRoleSeqNbr,
        String strUserId)
        throws RemoteException, FinderException, EElixirException;

    public ArrayList searchRoleTypes(Long lRoleTypes)
        throws RemoteException, FinderException, EElixirException;

    public long createRole(String strRoleDisplayName, String strRoleDesc,
        String strRoleDn, String strUserId)
        throws RemoteException, FinderException, EElixirException;

    // *****************************Financial Year starts here****************************
    public ArrayList searchFinancialYear()
        throws RemoteException, FinderException, EElixirException;

    public void updateFinancialYear(ArrayList a_arrFinancialYearResult)
        throws RemoteException, FinderException, EJBException, EElixirException;

    // *****************************Financial Year ends here****************************

    /*Designation delete functionality*/
    public void deleteDesignation(String strDesgnCd)
        throws RemoteException, FinderException, EElixirException;

    /*Persistency delete functionality*/
    public void deletePersistency(String strPerstType)
        throws RemoteException, FinderException, EElixirException;

    //Code added for SystemParameter
    public ArrayList searchSystemParameter(int a_iParamTypeCd)
        throws RemoteException, FinderException, EElixirException;

    public void updateSystemParameter(ArrayList a_oSystemrParameterList)
        throws RemoteException, FinderException, EElixirException;

    public long createUser(UserResult oUserResult)
        throws RemoteException, EElixirException;

    public void updateUser(UserResult oUserResult)
        throws RemoteException, EElixirException;

    public UserResult searchUser(Long lUserSeqNbr)
        throws RemoteException, EElixirException;
    
    /**
     * Added By Prabhat
     * Method for getting details of user's location wise roles
     * Start
     */
     

    public SearchData getUserRolesOnLocation(SearchData oSearchData)
    throws RemoteException, EElixirException;
    
    public String validateUserRolesOnLocation(SearchData oSearchData)
    throws RemoteException, EElixirException;
    
    /**
     * Added By Prabhat
     * Method for getting details of user's location wise roles
     * End
     */
    public String searchUser(SearchData a_oSearchData)
        throws EElixirException, FinderException, RemoteException;

    public ArrayList getRoleDefinitions(String strRoleName,
        String strRoleNameKanji) throws RemoteException, EElixirException;

    public void updateRoleDefinition(ArrayList _alRoleDefinitionList)
        throws RemoteException, EElixirException;

    public void updateUserPassword(UserResult uResult)
        throws RemoteException, EElixirException;

    public ArrayList searchLockedUsers(String strUserIDSearch)
        throws RemoteException, EElixirException;

    public void updateUserLock(ArrayList alLockedUsers)
        throws RemoteException, EElixirException;

    public void deleteRole(Long lRoleSeqNbr)
        throws RemoteException, EElixirException;

    // Vikrant - Start
    public String searchTax(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    public TaxResult searchTax(Long a_lTaxSeqNbr)
        throws RemoteException, EElixirException, FinderException;

    public Long createTax(TaxResult oTaxResult)
        throws EElixirException, RemoteException;

    public void updateTax(TaxResult oTaxResult)
        throws RemoteException, EElixirException;

    public boolean isUniqueTaxCode(TaxResult a_oTaxResult)
        throws RemoteException, EElixirException;

    //added by asim
    public boolean isUniqueDefault(TaxResult a_oTaxResult)
        throws RemoteException, EElixirException;

    public boolean isUniqueTaxCodeinUpdate(TaxResult a_oTaxResult)
        throws RemoteException, EElixirException;

    public String searchBonus(SearchData a_oSearchData)
        throws FinderException, EElixirException, RemoteException;

    public Long createBonus(BonusResult oBonusResult)
        throws EElixirException, RemoteException;

    public BonusResult searchBonus(Long a_lBonusHdrSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public void updateBonus(BonusResult oBonusResult)
        throws RemoteException, EElixirException;

    public void deleteBonus(Long a_lBonusHdrSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    //Product methods
    public String searchProduct(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;

    public ProductResult searchProduct(String a_strProdCd)
        throws RemoteException, FinderException, EElixirException;

    public void createProduct(ProductResult oProductResult)
        throws EElixirException, RemoteException;

    public void updateProduct(ProductResult oProductResult)
        throws RemoteException, EElixirException;

    public boolean isUniqueProductCode(ProductResult a_oProductResult)
        throws RemoteException, EElixirException;

    public AgentResult searchAgencyDetailsForAgentMovement(
        String a_strNewBrchCd, String a_strAgentCd, String a_strCurrBrchCd, String strMovementType)
        throws RemoteException, FinderException, EElixirException;

    public ArrayList searchPaymentCycle(Long a_lPaymentCycleSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public ArrayList searchPaymentCycleByDate(String a_strPaymentCycleDt)
        throws RemoteException, FinderException, EElixirException;

    public void updatePaymentCycle(ArrayList a_oPaymentCycleList)
        throws RemoteException, FinderException, EElixirException;

    public void createPaymentCycle(ArrayList a_oPaymentCycleList)
        throws RemoteException, FinderException, EElixirException;

    // Vikrant - End
    // *****************************Overriding comm rate starts here Sandeep*****************************
    public ArrayList searchOverridingCommRate(long a_lPriKey)
        throws FinderException, RemoteException, EElixirException;

    public void updateOverridingCommRate(
        ArrayList a_arrOverridingCommRateResult)
        throws EJBException, RemoteException, EElixirException;

    public void deleteAgent(String a_strAgentCd, String a_strUserID)
        throws RemoteException, EElixirException;

    public String searchQuestionReply(SearchData oSearchData)
        throws RemoteException, EElixirException, FinderException;

    public QuestionResult searchQuestionReply(long a_lQuestSeqNbr)
        throws RemoteException, EElixirException;

    public long createQuestionReply(QuestionResult oQuestionResult)
        throws RemoteException, EElixirException;

    public void updateQuestionReply(QuestionResult oQuestionResult)
        throws RemoteException, EElixirException;

    public void deleteQuestionReply(long a_lQuestSeqNbr)
        throws RemoteException, FinderException, EElixirException;

    public ArrayList searchDesignationQuestionMap(SearchData oSearchData)
        throws RemoteException, EElixirException, FinderException;

    public void updateDesignationQuestionMap(
        ArrayList a_oDesignationQuestionMapList)
        throws RemoteException, FinderException, EElixirException;

    public ArrayList searchPolicyAck(SearchData oSSearchData)
        throws RemoteException, FinderException, EElixirException;

    public void updatePolicyAck(ArrayList a_oSelfContractList)
        throws RemoteException, FinderException, EElixirException;

    public String policyListSearch(SearchData a_oSearchData)
        throws FinderException, EElixirException, RemoteException;

    public AgentMovementDetailResult searchAgentMovement(String a_strAgentCd)
        throws FinderException, EElixirException, RemoteException;

    public AgentRefreeDetailResult searchAgentRefree(String a_strAgentCd)
        throws FinderException, EElixirException, RemoteException;

    public AgentContractDetailResult searchAgentContract(String a_strAgentCd,
        Short nIsWritingAgent)
        throws FinderException, EElixirException, RemoteException;

    public AgentPerformanceDetailResult searchAgentPerformance(
        String a_strAgentCd, Short a_nYear)
        throws FinderException, EElixirException, RemoteException;

    public AgentPersistancyDetailResult searchAgentPersistancy(
        String a_strAgentCd, Short a_nYear)
        throws FinderException, EElixirException, RemoteException;

    public PolicyResult policySearch(String a_strPolicyNbr)
        throws FinderException, EElixirException, RemoteException;
//  Anantha_AGN05_REQVII starts
    public ArrayList getAllExistingClientDetails(String strTitle,
        String strFirstName, String strLastName, GregorianCalendar dtBirth,
        Short nGenderCd,String a_strfhtitlecd,String a_strfhfirstname,String a_strfhlastname,String a_strApprovalFlag)
        throws FinderException, EElixirException, RemoteException;
    
    public String getFHusbandDetails(String a_strApplcSeqNbr)
    throws EElixirException, RemoteException;
    
//  Anantha_AGN05_REQVII ends
        
	public ApplicationResult getAllContactClientDetails(String strClientCd)
			throws FinderException, EElixirException, RemoteException;        
	
	public String searchOtherBenefit(SearchData a_oSearchData)
    	throws FinderException, EElixirException, RemoteException;
	
	public long createOtherBenefit(OtherBenefitResult a_oOtherBenefitResult) 
		throws FinderException,RemoteException,EElixirException;

	public OtherBenefitResult searchOtherBenefit(long lBonusHdrSeqNbr)
			throws FinderException, EElixirException, RemoteException;
	
	public void updateOtherBenefit(OtherBenefitResult a_oOtherBenefitResult)
			throws FinderException,EElixirException, RemoteException;
	
	public void updateAgentTargetDetails(ArrayList alAgentDetails,Long lBonusHdrSeqNbr)
			throws FinderException,EElixirException, RemoteException;
	
	public ArrayList searchOtherBenefitAgentDetails (long lBonusHdrSeqNbr)
			throws FinderException,EElixirException, RemoteException;
	
	public void deleteOtherBenefit(Long lBonusHdrSeqNbr) 
			throws FinderException,EElixirException, RemoteException;
	
	public void deleteCriteriaParameters(Long lBonusHdrSeqNbr)
	        throws FinderException,EElixirException, RemoteException;

	//	added by shameem shaik for finder fees module
	public String searchFinderFees(SearchData a_oResultObject)
			 throws FinderException, EElixirException, RemoteException;
			 
	public FinderFeesResult searchFinderFees(long a_lbenseqnbr)
				throws FinderException, EElixirException, RemoteException;
				
	public String searchFinderFees()
				 throws FinderException, EElixirException, RemoteException;	

	public long createFinderFees(FinderFeesResult a_FinderFeesResult)
					throws RemoteException,EJBException, EElixirException;
					
	public void updateFinderFees(FinderFeesResult a_FinderFeesResult)
		   throws RemoteException, EElixirException;
	
	public void deleteFinderFees(Long a_lFFHdrSeqNbr)
			throws RemoteException, FinderException, EElixirException;	   

	public void updateFFCommissionRates(FinderFeesResult a_FinderFeesResult)
				  throws EElixirException, RemoteException;
//added by jim
	public FinderFeesResult searchFFCommissionRates(long a_lbenseqnbr,String a_strprdcd)
		 throws EElixirException , FinderException , RemoteException;				 
	
	public long createFinderFeesMap(ArrayList al_FinderFeesMapResult)
		   throws RemoteException, CreateException, EElixirException;
	
	public ArrayList searchFinderFeesMap(long _iLFFMapSeqNbr)
			throws RemoteException, FinderException, EElixirException;	
			
	public String searchFinderFeesMap(SearchData a_oResultObject)
				 throws FinderException, EElixirException, RemoteException;
	
	public void updateFinderFeesMap(ArrayList al_FinderFeesMapResult)
			throws RemoteException, CreateException, EElixirException;	
	
	/* Commented by jayasimha for Descoping of Lapse Rule and Lapse Rule Mapping 
	
		
		
	public String searchLapseRule(SearchData a_oResultObject)
			 throws FinderException, EElixirException, RemoteException;
			 
	public LapseRuleResult searchLapseRule(long a_lbenseqnbr)
				throws FinderException, EElixirException, RemoteException;
				
	public String searchLapseRule()
				 throws FinderException, EElixirException, RemoteException;	
 
	public long createLapseRule(LapseRuleResult a_LapseRuleResult)
					throws RemoteException,EJBException, EElixirException;
					
	public void deleteLapseRule(Long a_lLRHdrSeqNbr)
			throws RemoteException, FinderException, EElixirException;	

	public void updateLapseRule(LapseRuleResult a_LapseRuleResult)
		   throws RemoteException, EElixirException;

	public ArrayList createLapseRuleMap(LapseRuleMapResult a_LapseRuleMapResult)
		   throws RemoteException, CreateException, EElixirException;
	
	public ArrayList searchLapseRuleMap(long _iLLRMapSeqNbr)
			throws RemoteException, FinderException, EElixirException;	
			
	public String searchLapseRuleMap(SearchData a_oResultObject)
				 throws FinderException, EElixirException, RemoteException;
	
	public void updateLapseRuleMap(ArrayList al_LapseRuleMapResult)
			throws RemoteException, CreateException, EElixirException;

	public ArrayList searchLapseRuleEffDate()
				 throws FinderException, EElixirException, RemoteException;	





End of the commented code */



	  public String searchAllocationMarker(SearchData a_oSearchData)
		   throws RemoteException, EElixirException, FinderException;

  public AllocationMarkerResult searchAllocationMarker(Long a_lAllocMarkerSeqNbr)
		  throws RemoteException, EElixirException, FinderException;
		  
		  
	public Long createAllocationMarker(AllocationMarkerResult oAllocationMarkerResult)
		throws EElixirException, RemoteException;

	 public HashMap searchBankSortCd(String strBankCode)
            throws RemoteException, EElixirException, FinderException;

 
	public String searchRYCRuleMaster()
			 throws FinderException, EElixirException, RemoteException;

	public String searchRYCRuleMaster(SearchData a_oResultObject)
			 throws FinderException, EElixirException, RemoteException;

	public RYCRuleMasterSearchResult searchRYCRuleMaster(long lRYCHdrSeqNbr)
			throws FinderException, EElixirException, RemoteException;

	public long createRYCRuleMaster(RYCRuleMasterSearchResult a_RYCRuleMasterSearchResult)
			 throws EJBException, EElixirException, RemoteException;

	public void updateRYCRuleMaster(RYCRuleMasterSearchResult a_RYCRuleMasterSearchResult)
			 throws EJBException, EElixirException, RemoteException;

	public void deleteRYCRuleMaster(Long rycHdrSeqNbr)
			 throws EJBException, EElixirException, RemoteException;

	public String searchManualOverride(SearchData a_oSearchData)
			   throws RemoteException, EElixirException, FinderException;
    // JAN_REL_FSD_Comm_Accounting_Change_Unit_Linked_Starts				   
			   
	public ArrayList searchManualOverride(String strManualOverrideSeqNbr)
				   throws RemoteException, EElixirException, FinderException;
	
	public ArrayList createManualOverride(ArrayList al_ManualOverrideResult)
			    throws EElixirException, RemoteException;
	public ArrayList getManualOverrideDetails(String strAgentCd)
				throws EElixirException, RemoteException,FinderException;	   
	public ArrayList updateManualOverride(ArrayList al_ManualOverrideResult)
				throws RemoteException, CreateException, EElixirException;	
	// JAN_REL_FSD_Comm_Accounting_Change_Unit_Linked_Ends	
	public BonusSlabResult searchBonusSlab(Long a_lBonusDtlSeqNbr)
					   throws RemoteException, EElixirException, FinderException;
	public void addUpdateBonusSlab(BonusSlabResult oBonusSlabResult)
			throws RemoteException, EElixirException;
	public AgentResult searchProhibitJVPosting(String strAgentCd)
		   throws RemoteException, EElixirException;
	public void updateProhibitJVPosting(AgentResult oAgentResult)
			throws RemoteException, EElixirException;
	//Arun_FSGOASSOCIATE_REL8.0 Starts
	public ApplicationResult searchGOApplicability(ApplicationResult oApplicationResult) 
	   throws RemoteException, EElixirException;
// Sridhar_FSAutSus_REL8.0 
	/*<CODE_TAG: FS_Automated_Suspension1.1 DONT_UPDATE_chm_auto_suspension_table Dated: 3/6/2011 Starts>
	public void updateBankAccount(ApplicationResult oApplicationResult,
			String strAgentCd) throws RemoteException, EElixirException;
	<CODE_TAG: FS_Automated_Suspension1.1 DONT_UPDATE_chm_auto_suspension_table Dated: 3/6/2011 Ends>		
	*/
//	Arun_Everest_Segmentation_Start
	public ArrayList searchChannelSegments(String a_cChannelType)
    throws RemoteException, FinderException, EElixirException;
	public void updateSegmentMaster(ArrayList a_alSegmentMasterList)
	throws RemoteException, FinderException, EElixirException;
	public SegmentCriteriaResult searchSegmentCriteria(String a_strSegmentType)
	throws RemoteException, EElixirException;
	public void updateSegmentCriteria(SegmentCriteriaResult a_oSegmentCriteriaResult)
	throws RemoteException, FinderException, EElixirException;
	//<!--sunaina_Everest_ManualSegmentation_starts-->
	public Long ManualSegmentCreate(ManualSegmentResult oManualSegmentResult)
    throws FinderException, RemoteException, EElixirException;
	//<!--sunaina_Everest_ManualSegmentation_Ends-->
	//<!--sunaina_Everest_Segmentation_For_ManualSegmentation_Starts-->
	public ManualSegmentResult getManualSegmentResult(String a_strAgentCd)
    throws RemoteException, FinderException, EElixirException;
//	<!--sunaina_Everest_Segmentation_For_ManualSegmentation_Ends-->
//	Arun_Everest_ManualSegment_start
	public ManualSegmentResult searchManualSegment(Long a_lSeqNo) throws
	RemoteException, FinderException, EElixirException;
	public void ManualSegmentUpdate(ManualSegmentResult oManualSegmentResult)
    throws FinderException, RemoteException, EElixirException;
//<!--sunaina_Everest_Segmentation_starts--> <!--Added by anup pagination pending by amid-->
	public SearchData searchSegmentWeightage(SearchData strParameter)
    throws RemoteException, FinderException, EElixirException;
	public void updateSegmentWeightage(ArrayList a_oSegmentWeightageList)
	throws RemoteException, FinderException, EElixirException;
//<!--sunaina_Everest_Segmentation_ends-->
//sunaina_Everest_Segmentation_incexcfield
	public SegmentWeightageResult getIncExcSearch(String strParameter)
    throws RemoteException, FinderException, EElixirException;
	
	//Santosh_CBP Starts
	public ArrayList searchCbpMaster(String strChannelType)
    throws RemoteException, FinderException, EElixirException;
	
	public void updateCbpMaster(ArrayList a_alCbpMasterList)
	throws RemoteException, FinderException, EElixirException;
	
	public CbpResult searchCbpChannel(String strChannelType)
    throws RemoteException, FinderException, EJBException, EElixirException;
	
	
	//Santosh_CBP Ends
	//	FSD_AGN-59_Export to excel and Last status change date.doc Modified by Anup starts	
	public String searchAgentContractExcel(String a_strAgentCd,
	        Short nIsWritingAgent)
	        throws FinderException, EElixirException, RemoteException;	
	
	//Ends
// AMID_IRDA_RECORDS_PH2_START
	
	public IrdaRecordResult searchIrdaTrainingDetails(String strClientCd,long a_lApplcSeqNbr)
				throws RemoteException, EElixirException;
	public void updateIrdaRecord(IrdaRecordResult a_oIrdaRecordResult)
	throws RemoteException, FinderException, EElixirException;
	
	
	//AMID_IRDA_RECORDS_PH2_START
	
	
	//Prabhat_Bounce_charge_Exemption_FIN_68 start
	
		public BounceChargesExcemptionResult searchBounceChargesExcemptionDetails(String strAgentCd,long a_lApplcSeqNbr) throws RemoteException, EElixirException;
		public void updateBounceChargesExcemption(BounceChargesExcemptionResult a_oBounceChargesExcemptionResult)throws RemoteException, EElixirException;
	
	//Prabhat_Bounce_charge_Exemption_FIN_68 End
	
	// ANUP_AGT05_REL9.0 Version 2 Starts -->
	 public void approveApplicationforExistingClient(ApplicationResult oApplicationResult)
     throws RemoteException, EElixirException;
	 // ANUP_AGT05_REL9.0 Version 2 Ends -->

	//sunaina
	public AgentSegmentHistoryResult searchAgentHistory(String a_strAgentCd)
	        throws FinderException, EElixirException, RemoteException;
	//Sunaina_Everest_Segmentation_PhaseII_Starts
	/**
	 * @param a_strParameter
	 * @return
	 * @throws RemoteException
	 * @throws EElixirException
	 */
	public GpaStandardMasterResult searchGpaStandards(long a_strSeqNbr, String a_strParameter)
	throws RemoteException, EElixirException;
	/**
	 *
	 * @param a_strParameter
	 * @return
	 * @throws RemoteException
	 * @throws EElixirException
	 */
	public GpaCriteriaMasterResult searchGpaCriteria(long a_strSeqNbr, String a_strParameter)
	throws RemoteException, EElixirException;
	/**
	 *
	 * @param a_cChannelType
	 * @return
	 * @throws RemoteException
	 * @throws FinderException
	 * @throws EElixirException
	 */
	public ArrayList searchDesignationGpa(String a_strDesignation)
    throws RemoteException, FinderException, EElixirException;

	public void updateGpa(ArrayList _oGpaList)
	throws RemoteException, FinderException, EElixirException;

	public void updateGpaStandard(GpaStandardMasterResult _oGpaStandardMasterResult)
	throws RemoteException, FinderException, EElixirException;

	public void updateGpaCriteria(GpaCriteriaMasterResult _oGpaCriteriaMasterResult)
	throws RemoteException, FinderException, EElixirException;
	//Sunaina_Everest_Segmentation_PhaseII_Ends
	public void copyDesignationGpa(String a_strDesignation,String a_strInputDesg,String a_strUserId)
	throws RemoteException, FinderException, EElixirException;
	// Amid CSA/CPA Starts
	public ArrayList searchCsaCpa(String a_agentType) throws RemoteException,
			FinderException, EElixirException;

    public CsaCpaResult searchCsaCpaCriteria(String a_strAgentType,String a_strChannelType)
			throws RemoteException, EElixirException;

	public void updateCsaCpaCriteria(CsaCpaResult a_oCsaCpaCriteriaResult)
			throws RemoteException, FinderException, EElixirException;
	public void updateCsaCpa(ArrayList a_alCsaCpaList)
	throws RemoteException, FinderException, EElixirException;

	// Amid CSA/CPA End
	//Santosh_Pandya_Adjusted_Paid_Case_Started
	public void updateAdjustedPaidCase(ArrayList a_oAdjustedPaidCaseList)
	throws RemoteException,FinderException,EElixirException;
	
	//Updated by Prabhat For pagination
	public SearchData searchAdjustedPaidCase(SearchData oSSearchData)
    throws RemoteException, FinderException, EElixirException;
	
	//Added by Prabhat for validating adjusted paid case duplicate check start
	
	public String validateAdjustedPaidCase(SearchData oSSearchData)
    throws RemoteException, FinderException, EElixirException;
	
	//Added by Prabhat for validating adjusted paid case duplicate check end
	
	public AdjustedPaidCaseResult getPlanType(String strProductType)
    throws RemoteException, FinderException, EElixirException;
	
	//Santosh_Pandya_Adjusted_Paid_Case_End
	//<!--FSD_AGN30_Past Performance details for all agents in MyAgent SUNAINA STARTS-->
	 public AgentPerformanceDetailResult searchAgentPerformanceList(
		        String a_strAgentCd, Short a_nYear, Short a_nYearType)
		        throws FinderException, EElixirException, RemoteException;
	 //<!--FSD_AGN30_Past Performance details for all agents in MyAgent SUNAINA ENDS-->
	 //Amid_Fin_156_Upload Of Commission Dispatch_Starts	 
	 public String searchCommissionDispatch(SearchData _oSearchData)
     throws RemoteException, FinderException, EElixirException;
	 public void updateCommDispatch(ArrayList a_alCommDispatchList)
		throws RemoteException, FinderException, EElixirException;

	 public String deleteCommissionDispatch(SearchData _oSearchData)
     throws RemoteException, FinderException, EElixirException;


	 //Amid_Fin_156_Upload Of Commission Dispatch_Ends
	
	 //	 ANUP_DST_Incentive_April_REL_Start
	 public ArrayList searchPersReduction(long a_lBonusHdrSeqNbr)
     throws RemoteException, FinderException, EElixirException;
	 

	 public void updatePerReductionDetails(ArrayList alDSTDetails,Long lBonusHdrSeqNbr)
		throws FinderException,EElixirException, RemoteException;
//	 ANUP_DST_Incentive_April_REL_Ends			    
	 //<!--FSD_FIN_160_Switching off ST for locations in MyAgent.v0 ADDED BY Sunaina-->
	 public String searchState(SearchData a_oSearchData)
     throws RemoteException, FinderException, EElixirException;

	 public ArrayList searchStateDet(Long _lStateSeqNbr)
     throws RemoteException, FinderException, EElixirException;

	 public Long createState(ArrayList a1StateDetailsList)
     throws RemoteException, FinderException, EElixirException;

	 public void updateState(ArrayList a1StateDetailsList)
     throws RemoteException, FinderException, EElixirException;

	 /* FIXED by Himanshu on 29 Oct 2011-FIN 393_Professional_Tax START */
	 public ArrayList searchStatecd(String nStateCd ,String nTaxType)
     throws RemoteException, FinderException, EElixirException;
	 public ArrayList searchStatecdcreate(String nStateCd ,String nTaxType)
     throws RemoteException, FinderException, EElixirException;
	 /* FIXED by Himanshu on 29 Oct 2011-FIN 393_Professional_Tax End */


     //<!--FSD_FIN_160_Switching off ST for locations in MyAgent.v0 Ended BY Sunaina-->
					    
//	FIN-117_86_Restriction on commission disbursement ADDED by sunaina
	 public String searchBounceCharge(SearchData oSearchData)
     throws FinderException, EElixirException, RemoteException;
	//FIN-117_86_Restriction on commission disbursement ADDED by sunaina
//		<!--FSD_FIN_68_Debiting_Bounce_charges_APRIL_REL_ANUP_19Feb2009_Starts-->
	    public ArrayList searchBounce()
	        throws RemoteException, FinderException, EElixirException;

	    public void updateBounce(ArrayList a_arrChannelResult)
	        throws RemoteException, FinderException, EJBException, EElixirException;
//		<!--FSD_FIN_68_Debiting_Bounce_charges_APRIL_REL_ANUP_19Feb2009_Ends-->	    

	    //<!--sunaina_Commision_Dispatch_CR_Starts-->
	    public CommDispatchResult searchGetLocationCd(String strUserId)
        throws RemoteException, FinderException, EElixirException;
	    //<!--sunaina_Commision_Dispatch_CR_Ended-->
	 
	 // 
	 
	 //Added by Prabhat for FSD_TCU-AGN-6_IRDA Details Start   
	    public boolean enableIrdaTab(String agentCode) throws RemoteException, FinderException, EElixirException;
	 //Added by Prabhat for FSD_TCU-AGN-6_IRDA Details End
	 //Amid_FSD_FYC & RYC Payment post Agent Termination Start
	  public ArrayList searchCustomSetting(CustomSettingResult a_oCustomSettingResult) throws RemoteException,
		FinderException, EElixirException;
	  public void updateCustomSetting(ArrayList a_alCustomSettingList)
		throws RemoteException, FinderException, EElixirException;
	 //Amid_FSD_FYC & RYC Payment post Agent Termination End
	    //Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Starts
	    public ArrayList searchOverrideCommRuleList(String a_cChannelType)
        throws RemoteException, FinderException, EElixirException;

	    public void updateOverrideCommRule(ArrayList a_oOverrideCommList)
        throws RemoteException, FinderException, EElixirException;
	    
	    public String productCodeExists(String strAgencyCode,
	            String strProdCd, String dtEffFrom) throws EElixirException, RemoteException;
	    //Anup_DEC_REL_TCU-AGN-20_Select_Product_Commission_V1.2 Ends
//	  Session_Listner_Implementation_Starts 
	    public ProcessResult  getCallProceduresMyAgent(HashMap hmParam)
	    throws EElixirException, RemoteException;
//	    Session_Listner_Implementation_Ends
	    
	    //Arun_Modified_For_PerformanceImprovment
	    public ApplicationResult searchApplicationQuestionList(long a_lApplcSeqNbr,
	            String a_strAgentCd, String a_strApplcntType)
	            throws RemoteException, EElixirException;
	    
	  public void updateAgentQuestion(AgentResult oAgentResult)
			throws RemoteException, EElixirException;
	  //personal details
	  public ApplicationResult searchApplicationClientSearch(long a_lApplcSeqNbr,
	            String a_strAgentCd, String a_strApplcntType)
	            throws RemoteException, EElixirException;
	   
	  public void updateApplicationClient(ApplicationResult oApplicationResult)
		throws RemoteException, EElixirException;
	  public ApplicationResult searchApplicationBankDetails(long a_lApplcSeqNbr,
	            String a_strAgentCd, String a_strApplcntType)
	  throws RemoteException,EElixirException;
	  public void updateBankApplication(ApplicationResult oApplicationResult)
		throws RemoteException, EElixirException;
	  //Nominee
	 public ApplicationResult searchApplicationNominee(long a_lApplcSeqNbr,
	            String a_strAgentCd, String a_strApplcntType)
	 throws RemoteException, EElixirException;
	 
	 public void updateApplicationNominee(ApplicationResult oApplicationResult)
	 throws RemoteException, EElixirException;
	public ApplicationResult searchApplicationTaxInfo(long a_lApplcSeqNbr,
	            String a_strAgentCd, String a_strApplcntType)
     throws RemoteException,EElixirException;
	public void updateApplicationTaxInfo(ApplicationResult oApplicationResult)
	 throws RemoteException, EElixirException;
	//Education and Work
	public ApplicationResult searchApplicationEducWorkDtls(long a_lApplcSeqNbr,
            String a_strAgentCd, String a_strApplcntType)
	 throws RemoteException, EElixirException;
	public void updateApplicationEduWorkDtls(ApplicationResult oApplicationResult)
	 throws RemoteException, EElixirException;
	//ASSGO
	public ApplicationResult searchApplicationAssGO(long a_lApplcSeqNbr,
	            String a_strAgentCd, String a_strApplcntType)
     throws RemoteException,EElixirException;
	public void updateApplicationAssGo(ApplicationResult oApplicationResult)
	 throws RemoteException, EElixirException;

/*  Added By Jayasimha for FSD_TCU_AGN_09 functionality @jan2010 */
		
		public ArrayList searchAgencyTermSusDtls()
        throws RemoteException, FinderException, EElixirException;

	    public void updateAgencyTermSusDtls(ArrayList a_arrAgencyTermSusResult)
        throws RemoteException, FinderException, EJBException, EElixirException;
		
		
/* end of the code Added By Jayasimha for FSD_TCU_AGN_09 functionality @jan2010 */

//	  Added by Srikanth CTS for Agency Movement AGN-09
		public long createAgencyMovement(
		        AgencyMovementResult a_oAgencyMovementResult)
		        throws RemoteException, FinderException, EElixirException;
		
	    public AgencyMovementResult searchAgencyMovement(
	            long lAgntMovmnSeqNbr)
	            throws RemoteException, FinderException, EElixirException;
	    
	    public void updateAgencyMovement(
        AgencyMovementResult a_oAgencyMovementResult)
        throws RemoteException, FinderException, EElixirException;
	    
	    public String searchAgencyMovement(SearchData a_oSearchData)
        throws RemoteException, FinderException, EElixirException;
//End by Srikanth CTS	    

	    // Anup_FSD_TDS20PAN_V1.4_09Feb2010_Starts
	    public ArrayList searchTDSInvalidPan()
	        throws RemoteException, FinderException, EElixirException;

	    public void updateTDSInvalidPan(ArrayList a_arrTDSInvalidPan)
	        throws RemoteException, FinderException, EJBException, EElixirException;

	    // Anup_FSD_TDS20PAN_V1.4_09Feb2010_Ends
	    
		//Added by Srikanth CTS for MPS
	    public ArrayList searchChannelMPSTypes(String a_cChannelType)
	    throws RemoteException, FinderException, EElixirException;
	    
	    public MPSResult searchMPSMasterData(long lMPSHdrSeqNbr)
	    throws FinderException, EElixirException, RemoteException;
	    
	    public long createMPSMaster(MPSResult a_MPSResult)
		 throws EJBException, EElixirException, RemoteException;
	    
		public void updateMPSMaster(MPSResult a_MPSResult)
		 throws EJBException, EElixirException, RemoteException;
	    
	//End by Srikanth CTS	
		//Anup_AugRel2010_FSD_TPR_V1.3_Starts
	    public ArrayList searchChannelTPRTypes(String a_cChannelType)
	    throws RemoteException, FinderException, EElixirException;
	    
	    public TPRResult searchTPRMasterData(long lTPRHdrSeqNbr)
	    throws FinderException, EElixirException, RemoteException;	    
	   
	    public void createTPRMaster(ArrayList a_TPRResult)
		throws EJBException, EElixirException, RemoteException;
	    
		public void updateTPRMaster(TPRResult a_TPRResult)
		throws EJBException, EElixirException, RemoteException;
	    
		//Anup_AugRel2010_FSD_TPR_V1.3_Ends
		
		//Anantha_FSD_Duplicate_myFlow_Application_Niumber_v1[1].1 Starts
		public String validateDuplicateMyFlowAppNumber(CHMJQueryData a_oCHMJQueryData)
        throws RemoteException, FinderException, EElixirException;
		//Anantha_FSD_Duplicate_myFlow_Application_Niumber_v1[1].1 ends
	    	/** ALEX_FSD_20K_TDS_Exemption_Limit_V1.7 Starts */
	public ArrayList fetchTDSExemptionLimit() throws RemoteException,
			EElixirException;

	public void exemptionTDSCreateandUpdate(ArrayList arrTDSExemption)
			throws RemoteException, EElixirException;
	//Added by Alexpandiyan for JAN Release on 18 Jan 2010 Start
	public int getFinancialYear(String businessDate)
	throws RemoteException, EElixirException;
	//Added by Alexpandiyan for JAN Release End
	/** ALEX_FSD_20K_TDS_Exemption_Limit_V1.7 Ends */
	
	/* Start:Rel. Q2 change treatment ofservice charge V1.0 - Monika  06-01-11 */
	public ArrayList searchServiceCharge()
	throws RemoteException, EElixirException;
	
	public void createServiceCharge(ArrayList arrServChargeResult)
	throws RemoteException, EElixirException;
	/*End:Rel. Q2 change treatment ofservice charge V1.0 - Monika  06-01-11 */

	// <CODE_TAG: FSD_SSO_Location_Changes AddedBy: Alexpandiyan Dated: 7/10/2011 Starts> 
	
	 public Map fetchLocationByUserId(String userId)throws RemoteException, EElixirException;

	// <CODE_TAG: FSD_SSO_Location_Changes AddedBy: Alexpandiyan Dated: 7/10/2011 Ends> 





	/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping START */
	
	public void createCapping(ArrayList oCappingResult) throws EElixirException, RemoteException;
	
	public ArrayList searchCapping() throws RemoteException, FinderException, EElixirException;
	
	/* Added by Manisha on 20 Sep 2011-AGN339_FSD_Capping END */
	
	/* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation START */
	public ArrayList getWeightageList(Long lSeqNo) throws RemoteException, FinderException, EElixirException;
	
	public void updateWeightage(ArrayList arrlWeightageResult) throws EElixirException, RemoteException;
	/* Added by Manisha on 30 Sep 2011-CBP_WPC_Calculation END */   
        
	/* Added by Manisha on 30 Sep 2011-FIN 393_Professional_Tax START */ 
	public StateResult searchStateTax(Long a_strPerstType) throws RemoteException, FinderException, EElixirException;
	/* Added by Manisha on 30 Sep 2011-FIN 393_Professional_Tax END */

        //<CODE_TAG: FSD_CBP_WPC_Calculation AddedBy: Alexpandiyan Dated: 28/9/2011 Starts>
	 public String getAllCBPSetUpChannel() throws RemoteException, EElixirException ;
	//<CODE_TAG: FSD_CBP_WPC_Calculation AddedBy: Alexpandiyan Dated: 28/9/2011 Ends>

	 /*Added by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: START */
	public ArrayList searchChannelProdSeg() throws RemoteException, FinderException, EElixirException;
	/*Added by Ankita Singh on 1.12.2011 for Capping Seva Issue# 142160: END*/
	
	/* Added by Manisha on 15-May-2014 for Release 15.1 FSD_AGN867_ SurrenderRateSegmentationCriteria STARTS*/
	public void createSurrenderRateDef(SurrenderRateDefResult a_oSurrenderRateDefResult) throws RemoteException, FinderException, EElixirException;
	
	public SurrenderRateDefResult searchSurrenderRateDef(Short a_strParam) throws RemoteException, FinderException, EElixirException;
	/* Added by Manisha on 15-May-2014 for Release 15.1 FSD_AGN867_ SurrenderRateSegmentationCriteria ENDS*/
	
	// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Start
	public CollectionParamResult saveCollectionParams(CollectionParamResult collectionParamResult) throws RemoteException, EElixirException ;
	public CollectionParamResult getCollectionParams()throws RemoteException, EElixirException ;
	// Varun: Added for Release 15.1 - FSD_FIN751_Collection_Upload_v1.2 Ends
	
	// Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Start
	public ArrayList getDisbursementSetup()throws RemoteException, EElixirException ;
	
	public void SaveUpdateDisbumSetupDetails(ArrayList _oDisbumSetuplst)
	        throws EJBException, RemoteException, EElixirException;	
	// Vibhu_FIN838_AgentCommissionDisbursementLimitChange_Ends
	 //Added By Rohit Kumar for AGN929 Starts	
	public void updateApplicationAmlUlipTraining(ApplicationResult oApplicationResult)
	   throws EJBException, RemoteException, EElixirException;
	public ApplicationResult searchApplicationAmlUlipTraining(long a_lApplcSeqNbr,
            String a_strAgentCd, String a_strApplcntType)throws EElixirException,RemoteException,FinderException,EJBException;
	//Added By Rohit Kumar for AGN929 Ends

}
