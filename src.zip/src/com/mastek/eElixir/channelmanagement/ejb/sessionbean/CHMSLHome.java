package com.mastek.eElixir.channelmanagement.ejb.sessionbean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

import com.mastek.eElixir.common.exception.EElixirException;

public interface CHMSLHome extends EJBHome
{

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   */
  public CHMSL create() throws RemoteException, CreateException, EElixirException;

}