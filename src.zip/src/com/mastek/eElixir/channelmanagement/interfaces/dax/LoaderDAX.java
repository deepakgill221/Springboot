package com.mastek.eElixir.channelmanagement.interfaces.dax;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mastek.eElixir.channelmanagement.interfaces.util.LoaderConstants;
import com.mastek.eElixir.channelmanagement.interfaces.util.LoaderEnv;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;

public class  LoaderDAX implements Serializable
{
    private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	//private static Connection _oConnection;--FindBug_Fix_SUNAINA_STARTS

	/**
	* This method will insert info into table header about the type of upload to follow
	* @param a_oLoaderEnv the loader environment to obtain filename, user name etc
	*/
	public void insertHeader(LoaderEnv a_oLoaderEnv) throws EElixirException
	{
		log.debug("LoaderDAX--insertHeader--Begin");
		PreparedStatement pstmtInsertHeader= null;
		Connection _oConnection = null; //FindBug_Fix_SUNAINA_STARTS
		 
		String strInsertHeader = "INSERT INTO CHM_XMLFILES_DTL_INT( NIEFLAG, DTBATCH, STRFILETAG, STRSERIAL,	"+
								  "     		STRXMLFILENAME,NSTATUS,STRCREATEDBY, DTCREATED ) " + 
								  "	VALUES(1,TRUNC(SYSDATE),?,?,?,?,?, SYSDATE)";
		log.debug("LoaderDAX--insertHeader--Query is " + strInsertHeader );
		try
		{
			log.debug("LoaderDAX--insertHeader--Obtain Connection");
//			_oConnection = getConnection(a_oLoaderEnv.getUser(),a_oLoaderEnv.getPassword()); 
			_oConnection = DBConnection.getConnection();
			pstmtInsertHeader = _oConnection.prepareStatement(strInsertHeader);		
			log.debug("LoaderDAX--insertHeader--With Loader env " + a_oLoaderEnv);

			String strPrefixTag = a_oLoaderEnv.getTypeDesc();		
			pstmtInsertHeader.setString(1, strPrefixTag );
			log.debug("LoaderDAX--insertHeader--Prefix Tag is  " + strPrefixTag );

			pstmtInsertHeader.setString(2, a_oLoaderEnv.getSerialNo());
			log.debug("LoaderDAX--insertHeader--Serial No is " + a_oLoaderEnv.getSerialNo());

			pstmtInsertHeader.setString(3, a_oLoaderEnv.getDataFile());
			log.debug("LoaderDAX--insertHeader--DataFile " + a_oLoaderEnv.getDataFile());
			
			pstmtInsertHeader.setShort(4, LoaderConstants.BUSY);
			log.debug("LoaderDAX--insertHeader--State " + LoaderConstants.BUSY);
			
			pstmtInsertHeader.setString(5, a_oLoaderEnv.getUser());
			log.debug("LoaderDAX--insertHeader--User " + a_oLoaderEnv.getUser());

			pstmtInsertHeader.executeQuery(); 
			log.debug("LoaderDAX--insertHeader--insertion Done " );
		}
		catch (SQLException ex){
			log.debug("LoaderDAX--insertHeader--SQL EXCEPTION " + ex);
			ex.printStackTrace();
 	        throw new EElixirException(ex, "P9500");
		}
	    finally	{
		   try
	      {
		    if(pstmtInsertHeader != null)
			  pstmtInsertHeader.close();
			  //this.closeConnection();	
			DBConnection.closeConnection(_oConnection);
	      }
		  catch(SQLException sqlex)
	      {
		    log.debug("LoaderDAX--insertHeader--Exception in closing Prepared Statement " + sqlex);

	      }
		}
		 
		log.debug("LoaderDAX--insertHeader--End");
	}
	
  /** 
	* This function will cleanup the interface table 
	* 
	* @param a_oLoaderEnv the loader environment to obtain filename, user name etc
	*/
	public void deleteDetail(LoaderEnv a_oLoaderEnv) throws EElixirException
	{
		log.debug("LoaderDAX--deleteDetail--Begin");
		Statement stmtDeleteDetail = null;
		Connection _oConnection = null;//FindBug_Fix_SUNAINA_STARTS

		String strDeleteDetail = "DELETE FROM " + a_oLoaderEnv.getInterfaceTableName();
		log.debug("LoaderDAX--deleteDetail--Delete Query: " + strDeleteDetail );
		try
		{
			log.debug("LoaderDAX--deleteDetail--Obtainig Connection");
//			_oConnection = getConnection(a_oLoaderEnv.getUser(),a_oLoaderEnv.getPassword()); 
			_oConnection = DBConnection.getConnection(); 
			stmtDeleteDetail = _oConnection.createStatement();
			stmtDeleteDetail.executeUpdate(strDeleteDetail); 
			log.debug("LoaderDAX--deleteDetail--Deletion done");
			
		}catch (SQLException sqlex)	{
			log.debug("LoaderDAX--deleteDetail--SQL Exception " + sqlex);
 	        throw new EElixirException(sqlex, "P9501");
		}
	    finally	{
		   try  {
		    if(stmtDeleteDetail  != null)
			  stmtDeleteDetail.close();

//			this.closeConnection();	
			DBConnection.closeConnection(_oConnection);
	      }
		  catch(SQLException sqlex)
	      {
		    log.debug("LoaderDAX--deleteDetail--Exception in closing Prepared Statement " + sqlex);
		
	      }
		}
		log.debug("LoaderDAX--deleteDetail--End");
	}

  /**
	* This method will update the upload header table to handle the case of reloading 
	* erroneous records
	* @param a_oLoaderEnv the loader environment to obtain filename, user name etc
	*/
	public void updateHeaderStatus(LoaderEnv a_oLoaderEnv) throws EElixirException
	{
		log.debug("LoaderDAX--updateHeaderStatus--Begin");
		PreparedStatement pstmtUpdateHeaderStatus= null;
		Connection _oConnection = null;//FindBug_Fix_SUNAINA_STARTS

		log.debug("LoaderDAX--updateHeaderStatus--Preparing query");
		String strUpdateHeaderStatus =   "UPDATE CHM_XMLFILES_DTL_INT " +
								   "SET NSTATUS = ?, STRXMLFILENAME = ?	 " + 
								   "WHERE STRSERIAL = ? ";
		try
		{
			log.debug("LoaderDAX--Obtainig Connection ");
//			_oConnection = getConnection(a_oLoaderEnv.getUser(),a_oLoaderEnv.getPassword()); 
			_oConnection = DBConnection.getConnection(); 

			log.debug("LoaderDAX--updateHeaderStatus-- Beginning Update with Loader Env " + a_oLoaderEnv );
			log.debug("LoaderDAX--updateHeaderStatus-- Update Query is " + strUpdateHeaderStatus);
			pstmtUpdateHeaderStatus = _oConnection.prepareStatement(strUpdateHeaderStatus);
			pstmtUpdateHeaderStatus.setInt(1, LoaderConstants.BUSY);
			log.debug("LoaderDAX--updateHeaderStatus--State to Busy  " + LoaderConstants.BUSY);

			pstmtUpdateHeaderStatus.setString(2, a_oLoaderEnv.getDataFile());
			log.debug("LoaderDAX--updateHeaderStatus--Upload File:  " + a_oLoaderEnv.getDataFile());

			pstmtUpdateHeaderStatus.setString(3,  a_oLoaderEnv.getSerialNo() );
			log.debug("LoaderDAX--updateHeaderStatus--Serial No:  " + a_oLoaderEnv.getSerialNo() );

			pstmtUpdateHeaderStatus.executeUpdate();
			log.debug("LoaderDAX--updateHeaderStatus-- Update Done " );
		}
		catch (SQLException sqlex)		{
			log.debug("LoaderDAX--updateHeaderStatus-- SQL Exception " + sqlex);
 	        throw new EElixirException(sqlex, "P9502");
		}
		finally	{
		   try  {
		    if(pstmtUpdateHeaderStatus   != null)
			  pstmtUpdateHeaderStatus.close();

//			this.closeConnection();	
			DBConnection.closeConnection(_oConnection);
	      }
		  catch(SQLException sqlex)
	      {
		    log.debug("LoaderDAX--updateHeaderStatus-- Exception in closing Prepared Statement " + sqlex);
		
	      }
		}
		log.debug("LoaderDAX--updateHeaderStatus--End");
	}

  /**
	* This method will update the upload header table to indicate the number of records
	* uploaded from flat file and also the status of upload
	* @param a_oLoaderEnv the loader environment to obtain filename, user name etc
	*/
	public void updateHeader(LoaderEnv a_oLoaderEnv) throws EElixirException
	{
		log.debug("LoaderDAX--updateHeader--Begin");
		PreparedStatement pstmtUpdateHeader= null;
		Connection _oConnection = null;//FindBug_Fix_SUNAINA_STARTS

		log.debug("LoaderDAX--updateHeader--Preparing query");
		String strUpdateHeader =   "UPDATE CHM_XMLFILES_DTL_INT " +
								   "SET NSTATUS = ?, INORECORDS = ?	 " + 
								   "WHERE STRSERIAL = ? ";
		
		String strCountDetailRecords = "SELECT COUNT(*) FROM " +  a_oLoaderEnv.getInterfaceTableName();
		log.debug("LoaderDAX--updateHeader--Count Query is " + strCountDetailRecords  );

		try
		{
			log.debug("LoaderDAX--Obtainig Connection ");
//			_oConnection = getConnection(a_oLoaderEnv.getUser(),a_oLoaderEnv.getPassword()); 
			_oConnection = DBConnection.getConnection(); 

			long lDataCount = 0;
			pstmtUpdateHeader = _oConnection.prepareStatement(strCountDetailRecords);
			ResultSet rsCount = pstmtUpdateHeader.executeQuery(); 
			if (rsCount.next())		{
				lDataCount = rsCount.getLong(1);
			}
			log.debug("LoaderDAX--UpdateHeader--Record Count is " + lDataCount );

			log.debug("LoaderDAX--UpdateHeader--Beginning Update with Loader Env " + a_oLoaderEnv );
			log.debug("LoaderDAX--UpdateHeader--Update Query is " + strUpdateHeader);
			pstmtUpdateHeader = _oConnection.prepareStatement(strUpdateHeader);
			pstmtUpdateHeader.setInt(1, a_oLoaderEnv.getExitState().intValue());
			log.debug("LoaderDAX--UpdateHeader--Exit State: " + a_oLoaderEnv.getExitState().intValue());
			pstmtUpdateHeader.setLong(2, lDataCount);
			log.debug("LoaderDAX--UpdateHeader--Data Count: " + lDataCount);
			pstmtUpdateHeader.setString(3, a_oLoaderEnv.getSerialNo() );
			log.debug("LoaderDAX--UpdateHeader--Serial No: " + a_oLoaderEnv.getSerialNo() );
			pstmtUpdateHeader.executeQuery();
			log.debug("LoaderDAX--UpdateHeader-- Update Done " );
		}
		catch (SQLException sqlex)		{
			log.debug("LoaderDAX--UpdateHeader-- SQL Exception " + sqlex);
			sqlex.printStackTrace();
 	        throw new EElixirException(sqlex, "P9503");
		}
		finally	{
		   try  {
		    if(pstmtUpdateHeader   != null)
			  pstmtUpdateHeader.close();

//			this.closeConnection();	
			DBConnection.closeConnection(_oConnection);
	      }
		  catch(SQLException sqlex)
	      {
		    log.debug("LoaderDAX--UpdateHeader-- Exception in closing Prepared Statement " + sqlex);
		
	      }
		}
		log.debug("LoaderDAX--updateHeader--End");
	}

	/**
	* This method will determine the status of the Upload being requested
	* @return 0 No Error, 1 Error, 2 Busy, 3 NOT Upload -1 FATAL ERROR
	*		
	*/
	public int getStatus(LoaderEnv a_oLoaderEnv) throws EElixirException
	{
		log.debug("LoaderDAX--getStatus--Begin");
		PreparedStatement pstmtStatus=null;
		Connection _oConnection = null;//FindBug_Fix_SUNAINA_STARTS
		String strStatus = "SELECT NSTATUS  FROM CHM_XMLFILES_DTL_INT WHERE  STRSERIAL = ?";
		int iLastStatus = -1;
		log.debug("LoaderDAX--getStatus--QUery being executed " + strStatus);
		try
		{
			log.debug("LoaderDAX--getStatus--Obtainng Connection " );
//			_oConnection = getConnection(a_oLoaderEnv.getUser(),a_oLoaderEnv.getPassword()); 
			_oConnection = DBConnection.getConnection(); 
			pstmtStatus = _oConnection.prepareStatement(strStatus);
			log.debug("LoaderDAX--getStatus--Passing parameter " + a_oLoaderEnv.getSerialNo()  );
			pstmtStatus.setString(1, a_oLoaderEnv.getSerialNo() ) ;
			ResultSet rsStatus = pstmtStatus.executeQuery(); 
			if (rsStatus.next())		{
				log.debug("LoaderDAX--getStatus--record exists" );
				iLastStatus = rsStatus.getInt("NSTATUS");
			}
			else {
				log.debug("LoaderDAX--getStatus--no record in header" );
				iLastStatus = LoaderConstants.NOT_LOADED;
			}

			log.debug("LoaderDAX--getStatus--Last STatus is " +  iLastStatus );
		}
		catch (SQLException sqlex)
		{
		    log.debug("LoaderDAX--Exception in closing Prepared Statement " + sqlex);
 	        throw new EElixirException(sqlex, "P9504");
		}
		finally	{
		   try  {
		    if(pstmtStatus   != null)
			  pstmtStatus.close();

//			this.closeConnection();	
			DBConnection.closeConnection(_oConnection);
	      }
		  catch(SQLException sqlex)
	      {
		    log.debug("LoaderDAX--getStatus--Exception in closing Prepared Statement " + sqlex);
		
	      }
		}
		log.debug("LoaderDAX--getStatus--End");
		return iLastStatus ;
	}
	


	/**
	* Temproary method to return connection.
	* Will use standard framework later

	public static Connection getConnection (String a_strUserName, String a_strPassword) 
	{
		try {
		
			String driverClass  = "oracle.jdbc.driver.OracleDriver";
			Driver d = (Driver)Class.forName(driverClass).newInstance();

			return  DriverManager.getConnection(_dbURL,a_strUserName,a_strPassword);
		  } catch (Exception e) {
			  System.out.println ("Get Conection--Exception occured : " + e.getMessage());
			  e.printStackTrace();
		  }	
		  return null;
	 }
	*/

  /**
   * Temporary	
   * Closes the connection object taken from the connection pool

  public static void closeConnection() 
  {
    try
      {
        if(_oConnection !=  null)      {
           _oConnection.close();
          }
      }
	   catch(SQLException sqlex)     {
        log.debug("LoaderDAX--Problem closing connection " + sqlex);
      }
   }
   */

	/**
	* Temporary Logger
	
	private static void log(String s)
	{
		System.out.println("LoaderDAX--" + s);
	}
	*/
}
