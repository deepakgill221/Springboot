/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : INTERFACES
*  FILENAME			: ImportXML.java
*  AUTHOR			:
*  VERSION			: 1.0
*  CREATION DATE	: November  17, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*	VERSION			DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.interfaces.action;

/**
 *
 * FileNames is the Action Class for Getting list of all the files .
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author
 * @version 1.0
 */


import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.interfaces.util.XmlImportUtilityHandler;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class ImportXML extends Action
{
   public ImportXML()
   {

   }


   /**
   * This is a dummy method, used to show the result of importing the xml file
   * @param : request - Request object.
   * @throws EElixirException
   */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     log.debug("In the Process of the ImportXML method");

      String strFileName=null;
      Vector  vResult=null;

      strFileName=(String)a_oRequest.getParameter("fileName");
	  String strRunpoint = 	(String)a_oRequest.getParameter("cbRunPoint");
    //execute the wrapper class anmd take the result;
	vResult=XmlImportUtilityHandler.performImport(strFileName, strRunpoint.equals(String.valueOf(DataConstants.RUN_WHOLE_CYCLE)) );

    setResult(vResult);

    }



private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}


