/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : INTERFACES
*  FILENAME			: ActionProcedureStatus.java
*  AUTHOR			: 
*  VERSION			: 1.0
*  CREATION DATE	: November  15, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*	VERSION			DATE		  BY			REASON
*--------------------------------------------------------------------------------
*	
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.interfaces.action;

/**
 *
 * ActionProcedureStatus is the Action Class for Getting th status of procedures selected from jsp .
 * Copyright (c) 2002 Mastek Ltd
 * Date       17/11/2002
 * @author    
 * @version 1.0
 */

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSL;
import com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSLHome;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;



public class ActionProcedureStatus extends Action
{
   public ActionProcedureStatus()
   {

   }


   /**
   * This is a dummy method, used only when page is loaded first time
   * @param : request - Request object.
   * @throws EElixirException
   */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     log.debug("In the Process of the ProcedureStatus method");
      Vector vecFileTags=new Vector();
      String [] arrstrFileTags=null;	
      Hashtable htFileTagsStatus=null;
      Vector vecFileTagsStatus=null;
      HttpSession  session = a_oRequest.getSession();


      log.debug("Value of path:"+a_oRequest.getParameter("filePath").trim());
      log.debug("Value of date:"+a_oRequest.getParameter("date").trim());
      log.debug("Value of operation:"+a_oRequest.getParameter("operation").trim());		
      session.setAttribute("InterfaceFilePath",a_oRequest.getParameter("filePath").trim());
      session.setAttribute("InterfaceDate",a_oRequest.getParameter("date").trim());	
      session.setAttribute("InterfaceOperation",a_oRequest.getParameter("operation").trim());	

      arrstrFileTags=a_oRequest.getParameterValues("strFileTags");
      
      //put the list of filetags into vecFielTags
      for(int i=0;i<arrstrFileTags.length;i++)
      		vecFileTags.add(arrstrFileTags[i]);

     try
     {
	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        InterfaceSLHome homeInterfaceSL = (InterfaceSLHome) objEJBHomeFactory.lookUpHome("com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSLHome",com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSLHome.class);
        log.debug("Home object created"+homeInterfaceSL);
	InterfaceSL remoteInterfaceSL = (InterfaceSL)javax.rmi.PortableRemoteObject.narrow(homeInterfaceSL.create(),com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSL.class);
	log.debug("In the Process of the ProcedureStatus method remoteobject  created"+remoteInterfaceSL);

	htFileTagsStatus=remoteInterfaceSL.getStatus(vecFileTags,a_oRequest.getParameter("operation").trim(),a_oRequest.getParameter("date").trim());	
	vecFileTagsStatus=convertToVector(htFileTagsStatus);
        
	setResult(vecFileTagsStatus);	
     }
 
     catch(RemoteException rex)
           {
             rex.printStackTrace();
		log.debug("In the RemoteException of ACTION CLASS");
             throw new EElixirException("P8051");
           }
           catch(CreateException cex)
           {
            	cex.printStackTrace();
		 log.debug("In the CreateException of ACTION CLASS");
             throw new EElixirException(cex, "P8052");
           }
            catch(EElixirException eex)
           {
		eex.printStackTrace();
             log.debug("In the Elixir of ACTION CLASS"+eex.getCustomErrorCode());
             log.debug("In the Elixir of ACTION CLASS"+eex.getMessage());
             log.debug("In the Elixir of ACTION CLASS"+eex.getCustomMessage());
             throw eex;
           }
		
   }

   private Vector convertToVector(Hashtable a_htFileTagsStatus)
   {
	Vector vecFileTagsStatus=new Vector();
	Enumeration enKeys=a_htFileTagsStatus.keys();
	
	while(enKeys.hasMoreElements())
	{
		String strKey=(String)enKeys.nextElement();
		String strValue=(String)a_htFileTagsStatus.get(strKey);

		if(strValue.equals("0")) 	
		                strValue="Procedure successfully earlier. Do you want to do it again";
		else if(strValue.equals("1"))
		                strValue="Procedure unsuccessfully earlier. Do you want to try do it again";
		else if(strValue.equals("2"))		
		    strValue="Procedure is Busy";
		else if(strValue.equals("3"))
  		    strValue="Procedure will be executed";

		vecFileTagsStatus.add(strKey);
		vecFileTagsStatus.add(strKey+"-"+strValue);
	}
   		
	return vecFileTagsStatus;	
	
  
   }

private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
}


