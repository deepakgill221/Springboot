/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : INTERFACES
*  FILENAME			: FileNames.java
*  AUTHOR			: 
*  VERSION			: 1.0
*  CREATION DATE	: November  17, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*	VERSION			DATE		  BY			REASON
*--------------------------------------------------------------------------------
*	
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.interfaces.action;

/**
 *
 * FileNames is the Action Class for Getting list of all the files .
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author    Ashwini Nadkarni
 * @version 1.0
 */


import java.io.File;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.PropertyUtil;


public class FileNames extends Action
{
   public FileNames()
   {

   }


   /**
   * This is a dummy method, used only when page is loaded first time
   * @param : request - Request object.
   * @throws EElixirException
   */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     log.debug("In the Process of the ActionExceuteProcedure method");
      String [] arrStrFileNames=null;
      String strFilePath=null;
      Vector vecFileNames=new Vector();
	HttpSession  session = a_oRequest.getSession();
      File f=null;	
      PropertyUtil oPropUtil=null;

     //to get the path from which ths file names have to be picked
	
        if(Constants.INTERFACES_PROP_FILE!=null)
	{
            oPropUtil=new PropertyUtil(Constants.INTERFACES_PROP_FILE);
	}
	else
	{
	 throw new EElixirException("No Entry found in the Constants file");
	}

        	
	if(oPropUtil != null)
            strFilePath = oPropUtil.getProperty("import_folder");


	log.debug("File path obtained"+strFilePath);
	
      	//Make a file object with the required path
	f= new File(strFilePath);
	
	//get the list of all the files in this directory
	arrStrFileNames=f.list();

	 log.debug(arrStrFileNames+" length "+arrStrFileNames.length+" DFGF");	

	//put all files with .jsp extension into a vector 	
		for(int i=0;i<arrStrFileNames.length;i++)
		{
			
			if(arrStrFileNames[i].toLowerCase().endsWith(".xml"))
  	 			 { vecFileNames.add(arrStrFileNames[i]);
			          }
 		}
               
	
	    
		
	  setResult(vecFileNames);
    }

      		
	
private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}


