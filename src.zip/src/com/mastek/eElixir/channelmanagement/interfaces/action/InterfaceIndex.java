/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : INTERFACES
*  FILENAME			: InterfaceIndex.java
*  AUTHOR			: 
*  VERSION			: 1.0
*  CREATION DATE	: November  17, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*	VERSION			DATE		  BY			REASON
*--------------------------------------------------------------------------------
*	
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.interfaces.action;

/**
 *
 * InterfaceIndex is a dummy Action Class for getting the InterfaceIndex.jsp page .
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author    
 * @version 1.0
 */


import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class InterfaceIndex extends Action
{
   public InterfaceIndex()
   {

   }


   /**
   * This is a dummy method, used only when page is loaded first time
   * @param : request - Request object.
   * @throws EElixirException
   */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     log.debug("In the Process of the InterfaceIndex method");	
    
   }

      		
	
private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}


