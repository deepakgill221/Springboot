/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : INTERFACES
*  FILENAME			: ActionExecuteProcedure.java
*  AUTHOR			: 
*  VERSION			: 1.0
*  CREATION DATE	: November  15, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*	VERSION			DATE		  BY			REASON
*--------------------------------------------------------------------------------
*	
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.interfaces.action;

/**
 *
 * AddDesignation is the Action Class for Getting Designation Create jsp page .
 * Copyright (c) 2002 Mastek Ltd
 * Date       05/09/2002
 * @author    
 * @version 1.0
 */

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSL;
import com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSLHome;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;



public class ActionExecuteProcedure extends Action
{
   public ActionExecuteProcedure()
   {

   }


   /**
   * This is a dummy method, used only when page is loaded first time
   * @param : request - Request object.
   * @throws EElixirException
   */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     log.debug("In the Process of the ActionExceuteProcedure method");
      Vector vecFileTags=new Vector();
      String [] arrstrFileTags=null;
      String strFilePath=null;
      String strDate=null;
      Vector vecFileTagsEndStatus=null;
      //HttpSession  session = a_oRequest.getSession();


      //get the values from the session and remove the values fromm the session
      strFilePath=(String)a_oRequest.getParameter("filePath");
log.debug("strFilePath"+strFilePath);
      strDate=(String)a_oRequest.getParameter("date");		
log.debug("strDate"+strDate);
      String processType=(String)a_oRequest.getParameter("strProcess");
	log.debug("in Process on ActionExecuteProcedure"+processType);
      if(processType.equals(DataConstants.INTERFACE_DAY_END))
      {
log.debug("in if");
	  arrstrFileTags=a_oRequest.getParameterValues("strFileTagsDay");
      }else{
log.debug("in else");
          arrstrFileTags=a_oRequest.getParameterValues("strFileTagsMonth");
      }
      
      //put the list of filetags into vecFielTags
      for(int i=0;i<arrstrFileTags.length;i++)
      {
log.debug("in for");
        String strFileTagName = arrstrFileTags[i].trim();
        String strFileTag = null;
        String strProcName = null;
        Integer iProdVer = null;
log.debug("strFileTagName"+strFileTagName);
        if(strFileTagName != null && !strFileTagName.equals(""))
        {
          StringTokenizer st = new StringTokenizer(strFileTagName,"|");

          //while(st.hasMoreTokens()){
            strFileTag = (String)st.nextElement();
	    strProcName = (String)st.nextElement();
          //  break;
          //}

          log.debug("strFileTag"+strFileTag);
          log.debug("strProcName"+strProcName);
        }
	String[] temp ={"",""};
	temp[0]=strFileTag;
	temp[1]=strProcName;
	vecFileTags.add(temp);

      }

     try
     {
	EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        InterfaceSLHome homeInterfaceSL = (InterfaceSLHome) objEJBHomeFactory.lookUpHome("com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSLHome",InterfaceSLHome.class);
        log.debug("Home object created"+homeInterfaceSL);
	InterfaceSL remoteInterfaceSL = (InterfaceSL)javax.rmi.PortableRemoteObject.narrow(homeInterfaceSL.create(),com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSL.class);
	log.debug("In the Process of the ProcedureStatus method remoteobject  created"+remoteInterfaceSL);

	vecFileTagsEndStatus=remoteInterfaceSL.executeProcedures(vecFileTags,strDate,strFilePath);
	//vecFileTagsEndStatus=convertToVector(htFileTagsEndStatus);
        
	setResult(vecFileTagsEndStatus);	
     }
 
     catch(RemoteException rex)
           {
             log.debug("In the RemoteException of ACTION CLASS");
             throw new EElixirException("P8051");
           }
           catch(CreateException cex)
           {
             log.debug("In the CreateException of ACTION CLASS");
             throw new EElixirException(cex, "P8052");
           }
            catch(EElixirException eex)
           {
             log.debug("In the Elixir of ACTION CLASS"+eex.getCustomErrorCode());
             log.debug("In the Elixir of ACTION CLASS"+eex.getMessage());
             log.debug("In the Elixir of ACTION CLASS"+eex.getCustomMessage());
             throw eex;
           }
		
   }

   private Vector convertToVector(Hashtable a_htFileTagsEndStatus)
   {
	Vector vecFileTagsEndStatus=new Vector();
	Enumeration enKeys=a_htFileTagsEndStatus.keys();
	
	while(enKeys.hasMoreElements())
	{
		String strKey=(String)enKeys.nextElement();
        	String strError=(String)a_htFileTagsEndStatus.get(strKey);
			
		vecFileTagsEndStatus.add(strKey+"-"+strError);
	}
   		
	return vecFileTagsEndStatus;	
	
  
   }
private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}


