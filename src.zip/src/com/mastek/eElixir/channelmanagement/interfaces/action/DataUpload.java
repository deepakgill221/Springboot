/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		: INTERFACES
*  FILENAME			: DataUpload.java
*  AUTHOR			: Vinay Cerejo 
*  VERSION			: 1.0
*  CREATION DATE	: 5/30/2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*	VERSION			DATE		  BY			REASON
*--------------------------------------------------------------------------------
*	
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

package com.mastek.eElixir.channelmanagement.interfaces.action;

/**
 *
 * DataUpload is a Action Class for Uploading Data via SQL Loader.
 * 
 */

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSL;
import com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSLHome;
import com.mastek.eElixir.channelmanagement.interfaces.util.LoaderConstants;
import com.mastek.eElixir.channelmanagement.interfaces.util.LoaderEnv;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.XProperties;
import com.mastek.eElixir.common.util.EncryptionDecryptionUtil;//	Ananth_FSEncDcr_REL8.0


public class DataUpload extends Action
{
   private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

   public DataUpload()
   {
   }


   /**
   * This is a dummy method, used only when page is loaded first time
   * @param : request - Request object.
   * @throws EElixirException
   */
   public void process(HttpServletRequest a_oRequest)  throws EElixirException
   {
     log.debug("DataUpload--In the Process of the DataUpload method");	
	 try
     {
		short nUploadType = Short.parseShort(a_oRequest.getParameter("nUploadType").trim());
		log.debug("DataUpload--Uploading Data Type " + nUploadType);
		String strDataFile = a_oRequest.getParameter("strDataFile");
		log.debug("DataUpload--Uploading Data File " + strDataFile);
		String strControlFile = a_oRequest.getParameter("strControlFile");
		log.debug("DataUpload--Uploading Ctrl File " + strControlFile);
		String strLogsLoc = a_oRequest.getParameter("strLogFile");
		log.debug("DataUpload--Uploading Ctrl File " + strLogsLoc);

		XProperties oXProperties  = XProperties.getPropertyUtil(Constants.SETUP_FILE);
		String strHostString = oXProperties.getProperty("db.host") ;
		String strDBUser = oXProperties.getProperty("db.user") ;

		//Ananth_FSEncDcr_REL8.0 Starts
		String strIsEncryptedPWD= oXProperties.getProperty("db.pwd.isEncrypted") ;
		String strDBPasssword=null;
	
		
			if(strIsEncryptedPWD!=null&&!strIsEncryptedPWD.trim().equals(""))
 			{
					strDBPasssword=oXProperties.getProperty("db.pwd");
					//Fetching Actuval DB Password
					strDBPasssword=EncryptionDecryptionUtil.getDBPassword(strIsEncryptedPWD,strDBPasssword);
	
			}
			else
	  			{
					log.debug(" db.pwd.isEncrypted attribute value is not set in application.properties file ");
				}
	 		
		//Ananth_FSEncDcr_REL8.0 Ends
		
		String strShellParam = oXProperties.getProperty("run.env.shell");
		
		LoaderEnv oLoaderEnv =  new LoaderEnv();
		oLoaderEnv.setType(new Short(nUploadType) );
		oLoaderEnv.setDataFile(strDataFile);
		oLoaderEnv.setControlFile(strControlFile);
		oLoaderEnv.setLogFile(strLogsLoc);

		oLoaderEnv.setUser(strDBUser);
		oLoaderEnv.setPassword(strDBPasssword);
		oLoaderEnv.setDBSchema(strHostString);
		oLoaderEnv.setCmd(strShellParam);
		
		EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
		InterfaceSLHome homeInterfaceSL = (InterfaceSLHome) objEJBHomeFactory.lookUpHome("com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSLHome",InterfaceSLHome.class);
		log.debug("DataUpload--Home object created"+homeInterfaceSL);
		InterfaceSL remoteInterfaceSL = (InterfaceSL)javax.rmi.PortableRemoteObject.narrow(homeInterfaceSL.create(),com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean.InterfaceSL.class);
		log.debug("DataUpload--In the Process of the ProcedureStatus method remoteobject  created"+remoteInterfaceSL);
		int iUploadState =remoteInterfaceSL.upload(oLoaderEnv);
	
		a_oRequest.setAttribute("strExecState","" + iUploadState);
		a_oRequest.setAttribute("strLogsLoc", strLogsLoc);
	
	}
	catch(RemoteException rex)
	{
		a_oRequest.setAttribute("strExecState","" + LoaderConstants.SYS_LOAD_FAILED);
		log.debug("DataUpload--In the RemoteException of ACTION CLASS");
		throw new EElixirException(rex, "P8051");

	}
	catch(CreateException cex)
	{
		a_oRequest.setAttribute("strExecState","" + LoaderConstants.SYS_LOAD_FAILED);
		log.debug("DataUpload--In the CreateException of ACTION CLASS");
		throw new EElixirException(cex, "P8052");
	}
	catch(EElixirException eex)
	{
		a_oRequest.setAttribute("strExecState","" + LoaderConstants.SYS_LOAD_FAILED);
		log.debug("DataUpload--ElixirException "+eex);
		throw eex;
	}

   }

      		
	


}


