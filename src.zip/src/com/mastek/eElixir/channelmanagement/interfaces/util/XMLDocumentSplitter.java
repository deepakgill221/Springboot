package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.io.IOException;
import java.net.URL;

import oracle.xml.parser.v2.SAXParser;
import oracle.xml.parser.v2.XMLDocument;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class XMLDocumentSplitter extends DefaultHandler {
  private boolean status = true;
  
  private Document curDoc;
  private Node     curNode;
  private Element  curElement;
  private URL      fileURL;
  private XMLDocumentHandler handler;
  private String splitOnElement = null;
  boolean seenDocElementYet = false;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  // Remember the XMLDocumentHandler we're being asked to use.
  public XMLDocumentSplitter(XMLDocumentHandler handler) {
   this.handler = handler;
  }
  // Split a large XML document into N subdocuments, each one identified
  // by the an opening 'splitElement' element. Invoke an XMLDocumentHandler
  // to process each subdocument encountered.
  public void split(URL fileURL, String splitElement)
   throws SAXParseException,SAXException,IOException {
   this.fileURL        = fileURL;
   this.splitOnElement = splitElement;
   // Create a new SAXParser
   XMLReader parser = new SAXParser();
   // Register the current instance of this class as the Document Handler
   parser.setContentHandler(this);
   // Create a SAX InputSource on the URL's InputStream
   InputSource is = new InputSource(fileURL.openStream());
   // Start parsing the stream of XML
   parser.parse(is);

   //close the file
   is.getByteStream().close();
  }
  // Handle the <Element> "start-element" parsing event
public void startElement(String uri,String localName,String qName,
                         Attributes atl) throws SAXException {
   // If we were given a null element name to split on, behave "normally"
   // by using the document element as the splitElement.
   if (splitOnElement == null && !seenDocElementYet) {
     splitOnElement = qName;
     seenDocElementYet = true;
   }
   // If we're NOT currently building a subdocument and the element name
   // is the split element, then create a new XMLDocument for new subdocument
   if (curDoc == null) {
     if (qName.equals(splitOnElement)) {
       curDoc = new XMLDocument();
       curNode = curDoc;
     }
     else {
       // If we're NOT building a subdocument but this element
       // is not the splitterElement, then do nothing.
       return;
     }
   }
   // Construct a DOM Element node for the current element being parsed
log.debug("qName = " + qName);
   curElement = curDoc.createElement(qName);
   
    //Element curElementSRNO = curDoc.createElement("SRNO");
		//curElementSRNO.setNodeValue("100000");
		//curNode.appendChild(curElementSRNO);
   	//curNode = curElementSRNO;
   	//log.debug(curNode);

   // Add DOM Attribute nodes to the element for each attribute parsed
   for (int i=0; i<atl.getLength(); i++) {
    // curElement.setAttribute(atl.getQName(i),atl.getValue(i));
   }
   // Append the current DOM Element as a child of the current node in the
   // subdocument being constructured, and set it to be the new current node
   curNode.appendChild(curElement);
   curNode = curElement;   	
  }
  // Handle the </Element> "end-element" parsing event
  public void endElement(String uri, String localName, String qName)
    throws SAXException {
    // If we're NOT building a subdocument, we don't care. Just return.
    if (curDoc == null) return;
    // If this is the endElement event for the subdocument splitElement
    // then we're done with the subdocument and are ready to call the
    // handler to handle it.
    if (qName.equals(splitOnElement)) {
     if (curDoc != null) {
       try {
         // Call the XMLDocumentHandler.handle() method for current subdoc

         handler.handleDocument(curDoc,fileURL);
         
         status = status && handler.isSuccessful();
         
         //log.debug ("Status : " + status);
       }
       catch (Exception e) {
//         System.err.println(e.getMessage());
			log.debug("XMLDOcumentSplitter--" + e.getMessage());
         status = false;
       }
     }
     // Get ready for the next subdoc by nulling out our 'current' variables
     curDoc = null;
     curNode = null;
     curElement = null;
    }
    else {
     // If this is the endElement for any other element, make
     // its parent the new current node
     curNode = curNode.getParentNode();
    }
  }
  // Handle the "just got some text" parsing event
  public void characters(char[] cbuf, int start, int len) {
    // If we get text characters, create a new DOM Text node and
    // append it as a child of the current node.
    if (curDoc != null) {
      curElement.appendChild(curDoc.createTextNode(new String(cbuf,start,len)));
    }
  }
  
  public boolean getStatus() {
  	return status;
  }
}
