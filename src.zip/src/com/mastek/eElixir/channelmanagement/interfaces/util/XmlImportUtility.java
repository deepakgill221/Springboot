package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.net.URL;
import java.util.Vector;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class XmlImportUtility {

  private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  public static Vector performImport (String dataFile, boolean flag /** @RC1.0 */) {
    Vector vMessages = new Vector();
	String serialNumber = null;
    try {


      if (dataFile == null) {
        throw new IllegalArgumentException ("Invalid data file name : NULL");
      }

      String prefix = dataFile.substring(0, 6);

      URL dataXMLFileURL = ResourceManager.get_data_xml (dataFile);
      URL schemaXSDFileURL = ResourceManager.get_schema_xsd(prefix);
      URL tagXMLFileURL = ResourceManager.get_tag_xml(prefix);
      URL insertXSLFileURL = ResourceManager.get_insert_xsl(prefix);
      
      /** call validation */
      log.debug ("before validate engine");
      serialNumber = ValidationEngine.validate (dataXMLFileURL, schemaXSDFileURL, tagXMLFileURL);

      if (serialNumber == null) {
        log.debug ("Validation failed. Aborting...");

        log.debug ("XML import failed.");

        String sourceFolder = ResourceManager.getString ("folder_inxml");
        String errorFolder = ResourceManager.getString ("folder_errxml");
        if (FileTransfer.moveFile (dataFile, sourceFolder, errorFolder))
        {
          log.debug (" FILE " + dataFile + " MOVED TO FOLDER:" + errorFolder);
          vMessages.addElement(" FILE " + dataFile + " MOVED TO FOLDER:" + errorFolder);
        }
        else
        {
          log.debug (" ERROR: FILE " + dataFile + " COULD NOT BE MOVED TO FOLDER:" + errorFolder);
          vMessages.addElement(" ERROR: FILE " + dataFile + " COULD NOT BE MOVED TO FOLDER:" + errorFolder);
        }

        vMessages.addElement(" XML IMPORT FAILED .");
        vMessages.addElement("SERIAL_NO:"+ serialNumber );   //Should never occur. VinayC
        return vMessages;

      } else {
        vMessages.addElement(" VALIDATION SUCCESSFUL");
        log.debug (" Validation successful");
      }

   /* call import */
      boolean isLoaded = XMLLoader.load (insertXSLFileURL, dataXMLFileURL, tagXMLFileURL, serialNumber, flag);
      if (isLoaded) {
        log.debug ("XML data imported");
        vMessages.addElement("XML DATA IMPORTED");
        String sourceFolder = ResourceManager.getString ("folder_inxml");
        String outFolder = ResourceManager.getString ("folder_outxml");

        if (FileTransfer.moveFile (dataFile, sourceFolder, outFolder))
        {
          vMessages = new Vector();
          vMessages.addElement("XML FILE " + dataFile + " IMPORT SUCCESSFUL & MOVED TO FOLDER:" + outFolder);
          return vMessages;
        } else
        {
          vMessages.addElement(" ERROR : XML FILE " + dataFile + " IMPORT SUCCESSFUL BUT COULD NOT  MOVE TO FOLDER:" + outFolder);
          return vMessages;

        }
      } else {
        log.debug ("XML import failed.");
        vMessages.addElement("XML IMPORT FAILED.");
        String sourceFolder = ResourceManager.getString ("folder_inxml");
        String errFolder = ResourceManager.getString ("folder_errxml");

		vMessages.addElement("SERIAL_NO:"+ serialNumber );   
        if (FileTransfer.moveFile (dataFile, sourceFolder, errFolder))
        {
          vMessages.addElement(" FILE " + dataFile + " MOVED TO FOLDER:" + errFolder);
          return vMessages;
        } else
        {
          vMessages.addElement(" ERROR: FILE " + dataFile + " COULD NOT BE MOVED TO FOLDER:" + errFolder);
          return vMessages;
        }
      }
    } catch (ValidationException ve) {
      log.debug ("Exception occured : " + ve.getMessage());
      ve.printStackTrace();

      /** report error */
      ErrorUtil.reportError (dataFile, "UNKNOWN", "XmlImportUtility.performImport", "ERR_VALIDATION", ve.getMessage() , 0,0);
      vMessages.addElement(" ERROR : " + ve.getMessage());
   	  vMessages.addElement("SERIAL_NO:"+ serialNumber );   
      return vMessages;

    }

    catch (IllegalArgumentException iae) {
      log.debug ("Exception occured : " + iae.getMessage());
      iae.printStackTrace();

      /** report error */
      ErrorUtil.reportError (dataFile, "UNKNOWN", "XmlImportUtility.performImport", "ERR_FILE_NOT_FOUND", iae.getMessage() , 0,0);
      vMessages.addElement(" ERROR : " + iae.getMessage());
	  vMessages.addElement("SERIAL_NO:"+ serialNumber );   
      return vMessages;

    }
    catch (Exception e) {
      log.debug ("Exception occured : " + e.getMessage());
      e.printStackTrace();

      /** report error */
      ErrorUtil.reportError (dataFile, "UNKNOWN", "XmlImportUtility.performImport", "ERR_GENERIC", e.getMessage() , 0,0);
      vMessages.addElement(" ERROR : " + e.getMessage());
	  vMessages.addElement("SERIAL_NO:"+ serialNumber );   
      return vMessages;
    }

    catch (Error err) {
      log.debug ("ERROR : " + err.getMessage());
      err.printStackTrace();
      vMessages.addElement(" ERROR : " + err.getMessage());
	  vMessages.addElement("SERIAL_NO:"+ serialNumber );   
      return vMessages;

    }
  }

    	public static void main (String argv[]) {
		try {
		  String fileName = argv[0];
			
			boolean flag = false;
			if (argv.length == 2) {
			  flag = "-t".equals(argv[1]);
	    }
			XmlImportUtility.performImport (fileName, flag);
			
		} catch (Exception e) {
				log.debug ("Exception occured : " + e.getMessage());
				e.printStackTrace();
		  }
	}
}