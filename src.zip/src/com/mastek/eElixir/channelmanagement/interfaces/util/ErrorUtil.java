package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;

public class ErrorUtil {

private static  Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  public static boolean reportError (String fileName,
  																	String serialNumber,
  																	String procName,
  																	String errorCode,
  																	String description,
  																	int lineNo, int columnNo) {


		try {

			if ((errorCode == null) || "".equals(errorCode)) {
				errorCode = "ERR_UNKNOWN";
			}

			if ((serialNumber == null) || "".equals(serialNumber)) {
				serialNumber = "UNKNOWN";
			}

//			Connection conn = ConnectionFactory.getConnection (ResourceManager.get_connectionName());
			Connection conn = DBConnection.getConnection();

			String insertString =
					"INSERT INTO chm_xml_error_messages (lErrSeqNbr, strXmlfile, strSerial, strProcname, "
		    + "strErrCd, strErrDesc, NLINENO, NCOLUMN, strCreatedBy, dtCreated) "
		    + " VALUES (chm_xml_ErrMsg_seq.nextval, ?, ?, ?, ?, ?,?, ?, 'INTERFACE', sysdate ) ";



		  PreparedStatement prepStmt = conn.prepareStatement (insertString);
		  prepStmt.setString (1, fileName);
		  prepStmt.setString (2, serialNumber);
		  prepStmt.setString (3, procName);
		  prepStmt.setString (4, errorCode);
		  prepStmt.setString (5, description);
		  prepStmt.setInt (6, lineNo);
		  prepStmt.setInt (7, columnNo);

		  int result = prepStmt.executeUpdate ();

		  if (result == 0) {
		  	log.debug ("Reporting error failed ");
		  	return false;
		  }

		  conn.commit();
		  conn.close();
		  conn = null;

		  return true;
		} catch (SQLException sqle) {
				log.debug ("Failed to report error : " + sqle.getMessage());
				sqle.printStackTrace();

				return false;
			}
 
			catch (Exception e) {
				log.debug ("Exception occured : " + e.getMessage());
				e.printStackTrace();

				return false;
			}
  }
}