package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.net.URL;

import org.w3c.dom.Document;
public interface XMLDocumentHandler {
  boolean handleDocument( Document d , URL u ) throws Exception;
  boolean isSuccessful ();
}