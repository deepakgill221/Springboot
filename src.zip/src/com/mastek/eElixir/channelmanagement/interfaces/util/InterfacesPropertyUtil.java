package com.mastek.eElixir.channelmanagement.interfaces.util;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.PropertyUtil;

public class InterfacesPropertyUtil extends PropertyUtil {

  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	private InterfacesPropertyUtil() throws EElixirException {
    super( Constants.INTERFACES_PROP_FILE);
	  log.debug("InterfacesPropertyUtil Loaded Property file for interfaces property lookup");
  }

  public static InterfacesPropertyUtil getPropertyUtil() throws EElixirException {
    if(_oInterfacesPropertyUtil == null)
      _oInterfacesPropertyUtil = new InterfacesPropertyUtil();
      return _oInterfacesPropertyUtil;
  }

  public String getInterfacesProperty(String a_strPropertyKey) {
		String strPropertyValue = "";
	  log.debug("InterfacesPropertyUtil Fetching property for : " + a_strPropertyKey);

	  if(_oInterfacesPropertyUtil != null)
				 strPropertyValue = _oInterfacesPropertyUtil.getProperty(a_strPropertyKey);

	  log.debug("InterfacesPropertyUtil property IS : " + strPropertyValue );
		return strPropertyValue;
	}



	/**
   * Attributes
   */
  private static InterfacesPropertyUtil _oInterfacesPropertyUtil = null;


  public static void main (String[] argv) {
		try {
		  InterfacesPropertyUtil propUtil = InterfacesPropertyUtil.getPropertyUtil();

		  System.out.println(propUtil.getInterfacesProperty("DateFormat"));
	} catch (Exception e) {
			System.out.println("Exception occured : "+ e.getMessage());
			e.printStackTrace();
	  }
	}
}
