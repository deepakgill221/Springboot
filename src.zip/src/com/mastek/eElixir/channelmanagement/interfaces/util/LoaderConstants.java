package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.io.Serializable;

public interface LoaderConstants extends  Serializable
{
	public static final short ADDRESS_UPLOAD = 1;
	public static final short BANK_UPLOAD = 2;
	public static final short OTHER_LIFE_INSURANCE_UPLOAD = 3;
	public static final short AFCO_UPLOAD = 4;
	public static final short ORICO_UPLOAD = 5;


	public static final String ADDRESS_TAG = "ADDR";
	public static final String BANK_TAG = "BANK";
	public static final String OTHER_LIFE_INSURANCE_TAG = "OLIA";
	public static final String AFFILATED_COMPANY_TAG = "AFCO";
	public static final String ORICO_TAG = "OAGT";

	public static final String LOADER_PROPS_FILE = "./loader.properties";

	public static final short NO_ERROR = 0;
	public static final short LOAD_ERROR = 1;
	public static final short BUSY = 2;
	public static final short NOT_LOADED = 3;
	public static final short DUPLICATE_LOAD = 4;
	public static final short SYS_LOAD_FAILED = 5;

	public static final String  ADDRESS_INT_TABLE = "COM_ADDRESS_M_XMLINT";
	public static final String  BANK_INT_TABLE = "COM_BANK_M_XMLINT";
	public static final String  OLIA_INT_TABLE = "CHM_INSUR_COMP_M_XMLINT";
	public static final String  AFCO_INT_TABLE = "CHM_AFFILIATED_AGENCY_XMLINT";//Affilated Companies
	public static final String  OAGT_INT_TABLE = "CHM_AGENT_ORICO_XMLINT";
}
