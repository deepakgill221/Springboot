package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import oracle.xml.parser.schema.XMLSchema;
import oracle.xml.parser.schema.XSDBuilder;
import oracle.xml.parser.schema.XSDException;
import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.SAXParser;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLParseException;
import oracle.xml.parser.v2.XMLParser;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;

public class ValidationEngine {

  private static String strSrno = null;
  private static String strRootName = null;
  private static String strFileName = null;

	private static Hashtable htActualTagTable = null;
	private static Hashtable htTagTable = null;

	private static int iTotalRowCount = 0;
	private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

//	private static String connName = ResourceManager.get_connectionName();

	public static String validate (URL a_urlDataXMLURL, URL a_urlSchemaXSDURL, URL a_urlTagXMLURL) throws ValidationException {
log.debug("in validate");
    try {

			if (a_urlDataXMLURL == null) {
			  throw new IllegalArgumentException ("Invalid data XML URL : NULL");
			}

			if (a_urlSchemaXSDURL == null) {
				throw new IllegalArgumentException ("Invalid schema XSD URL : NULL");
			}

			if (a_urlTagXMLURL == null) {
				throw new IllegalArgumentException ("Invalid tag XML URL : NULL");
			}

			 /** following parameters are used while reporting errors */
			 String strS = a_urlDataXMLURL.getFile();
			 int iIndex = strS.lastIndexOf("/");
			 strFileName = strS.substring (iIndex+1, strS.length() - 4);

			 log.debug(" validating " + a_urlDataXMLURL + "...");

			 /** load the element names for row count matching */
			 /** get the list of elements to consider from the tag (xml) file */
			 DOMParser domParser = new DOMParser();

			 /** parse the TAG xml document */
			 domParser.parse (a_urlTagXMLURL);

			 /** Create a XNL Document */
			 XMLDocument doc = domParser.getDocument();

			 Element root = doc.getDocumentElement();

			 /** get list of all TAG nodes */
			 NodeList nl = root.getElementsByTagName("TAG");

       /** process individual TAG */
       Node n;
       for (int i=0; i < nl.getLength(); i++)
       {
         n = nl.item(i);
         String strTagName = n.getFirstChild().getNodeValue();

         if (htActualTagTable == null) {
         	 htActualTagTable = new Hashtable();
         }
         htActualTagTable.put(strTagName, new Integer(0));
       }


	    /** build the XML schema object */
	    XSDBuilder builder = new XSDBuilder();
	    XMLSchema schema = (XMLSchema) builder.build(a_urlSchemaXSDURL);

	    /** Create SAX parser instance */
	    SAXParser parser = new SAXParser();

	    /** set the XML schema to be applied */
	    parser.setXMLSchema (schema);
			parser.setValidationMode(XMLParser.SCHEMA_VALIDATION);
      parser.setPreserveWhitespace (true);

      /** set the error handler. Ideally it should write to a error.log file */
			parser.setErrorHandler (new ErrorHandler() {
    		public void error(SAXParseException e) throws SAXException {
    			log.debug("  Error " + e.getMessage());
    		}

    		public void warning (SAXParseException e) throws SAXException {
    			log.debug("  Warning " + e.getMessage());
    		}

    		public void fatalError (SAXParseException e) throws SAXException {
    			log.debug("  Fatal error " + e.getMessage());
    		}
			});

      /** set the Content Handler */
      parser.setContentHandler (new DefaultHandler() {
      	private boolean bFoundSrno = false;
				private boolean bFoundRowCount = false;
				private boolean bFoundTotalRowCount = false;
				private boolean bFoundRootElement = false;

				private String strRowCountElement = null;

      	public void startDocument () throws SAXException {
      		bFoundRootElement = true;
      	}


      	public void startElement (String namespaceURI,
      														String localName,
      														String qName,
      														Attributes atts)
      							throws SAXException {


       	  /** check for serial number */
       	  bFoundSrno = "SRNO".equals(qName);

					if (bFoundRootElement) {
						strRootName = qName;
						bFoundRootElement = false;
					}

					if (qName.startsWith("R")) {

						String k = qName.substring(1,qName.length());
						if (htActualTagTable.containsKey(k)) {
						  strRowCountElement = k;
						  bFoundRowCount = true;

					  }
					}

       	  /** check for row count */
       	  if (htActualTagTable.containsKey(qName)) {
            log.debug("Incrementing Count for " + qName);
       	  	int count = ((Integer)htActualTagTable.get(qName)).intValue();
       	  	htActualTagTable.put(qName, new Integer(++count));
       	  }


        	bFoundTotalRowCount = "TOTALRECORDS".equals(qName);

      	}

      	public void endElement (String namespaceURI,
													String localName,
													String qName)
						throws SAXException {
				}

      	public void characters(char[] ch,
                       				 int start,
                       				 int length)
                		throws SAXException {

					if (bFoundSrno) {
						strSrno = new String(ch, start, length);

						log.debug("  Serial Number : "+ strSrno);
						bFoundSrno = false;
				  }

				  if (bFoundTotalRowCount) {
				  	iTotalRowCount = Integer.parseInt(new String(ch, start, length));

				  	log.debug("  Total number of rows " + iTotalRowCount);
						bFoundTotalRowCount = false;
				  }

				  if (bFoundRowCount) {
				  	int rowCount = Integer.parseInt(new String(ch, start, length));
				  	if (htTagTable == null) {
				  		htTagTable = new Hashtable();
				  	}

				  	htTagTable.put(strRowCountElement, new Integer(rowCount));


				  	log.debug("  Expected row count for " + strRowCountElement + " is " + rowCount);
				  	bFoundRowCount = false;
				  }
        }
      });

      /** check for strctural errors (data type, length, etc.) */
      parser.parse(a_urlDataXMLURL);

			/**
			 * check if header information availabe
			 */
			 if (strSrno == null) {
			   String errMsg = "HEDER invalid or missing";
  			   /** report as an error */
			   ErrorUtil.reportError (strFileName, "UNKNOWN", "ValidationEngine.validate", null, errMsg, 0, 0);
			   return null;
			 }

			/**
			 * check for number of row counts
			 **/
// Anantha_MAMM_Migration_WAS6.1 changes done
			 Enumeration enum1 = htActualTagTable.keys();

			 int actualTotalCount = 0;

			 while (enum1.hasMoreElements()) {
			 	 String Key = (String) enum1.nextElement();
			 	 int count = ((Integer)htActualTagTable.get(Key)).intValue();

			 	 log.debug(" -> " + Key);

			 	 int found  = 0;
			 	 Object obj = htTagTable.get(Key);
			 	 if (obj == null) {
			 	 	 if (count != 0) {
			 	 	   log.debug( " Error : " + count + " records expected for " + Key + " but found none");

			 	 	   /** report as an error */
			 	 	   ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", null,
			 	 	   												count + " records expected for " + Key + " but found none", 0, 0);
					   if (!enum1.hasMoreElements()) {
						 return null;
					   }
			 	 	 }
			 	 } else {
					 	 found = ((Integer)htTagTable.get(Key)).intValue();
			 	 	   /** report as an error */

						 if (count != found) {

							 log.debug(" Error in no. of records for " + Key + " expected " + count + ": founnd " + found);
				 	 	   /** report as an error */
				 	 	   ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", null,
			 	 	   												" Error in no. of records for " + Key + " expected " + count + ": found " + found, 0, 0);
					 	 	 if (!enum1.hasMoreElements()) {
					 	 	 	 return null;
					 	 	 }
					 	 }

					 	 actualTotalCount += found;
			 	}
			 }

			 if (actualTotalCount != iTotalRowCount) {
			 	 String errorMessage = " Error in total no. of records. expected: " + iTotalRowCount + " found: " + actualTotalCount;

			 	 log.debug(errorMessage);

			 	 /** report as an error */
			 	 ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", null, errorMessage, 0, 0);
			 	 return null;
			 }
 
       /** check for serial number */
//       Connection con = ConnectionFactory.getConnection(connName);
       Connection con = DBConnection.getConnection();
       Statement stmt = con.createStatement();

       String selectString = "select STRSERIAL, NSTATUS from CHM_XMLFILES_DTL_INT where STRSERIAL= '"+ strSrno +"'";
	     //String selectString = "select STRSERIAL, NSTATUS from CHM_XMLFILES_DTL_INT WHERE NSTATUS != 2";

       log.debug(selectString);

       ResultSet rs = stmt.executeQuery(selectString);

       if (rs.next()) {
       	 /** import already done for this file, so throw validation exception */
       	 int status = rs.getInt("NSTATUS");
		 String _srnNo = rs.getString("STRSERIAL");

		 if (strSrno.equals (_srnNo)) {
       	   if (status == 0) {
			   log.debug("  Warning : Data already imported. ");

			   /** report as an error */
			   ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", null, "Data already imported", 0, 0);
			   con.close();
			   return null;
	       } else {
			   return strSrno;
		     }

       	 } else if (status == 2) {
       	 	   log.debug("  Warning : Data being imported. ");
       	 	   con.close();
       	 	   return null;
       	   } else if (status == 1) {
  			   log.debug("  Previous run causes error. Calling data for re-run.");
			   con.close();
			   return strSrno;
       	     }
           con.close();
       	   return null;
       } else {
       	   try {
       		 log.debug(" Data can be inserted.");

       		 iIndex = strFileName.indexOf("/");
       		 String sDate = strFileName.substring(iIndex + 7, strFileName.length());

       		 SimpleDateFormat Format = new SimpleDateFormat("yyMMdd");

					 Date d = Format.parse (sDate);

					 log.debug(d.toString());

       		 String insertString = " insert into CHM_XMLFILES_DTL_INT "
       		 	+ " values (1, ?, '" + strRootName + "','" + strSrno + "','" + strFileName.substring(iIndex + 1, strFileName.length()) + "' , " + iTotalRowCount + ", 2, 'INTERFACE', sysdate)";

       		 PreparedStatement prepStmt = con.prepareStatement (insertString);
       		 prepStmt.setTimestamp(1, new Timestamp(d.getTime()));

       		 int result = prepStmt.executeUpdate();

       		 if (result == 0) {
       		 	 log.debug("  insert into HEADER table for a new serial No.: " + strSrno + " failed...");
       		 	 con.close();
       		 	 return null;
       		 } else {
       		 	   con.close();
       		 	   return strSrno;
       		 	 }
       		} catch (SQLException sqle) {
       				log.debug("Database error : " + sqle.getMessage());
       				sqle.printStackTrace();

       				ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", "ERR_INTERNAL", sqle.getMessage(), 0, 0);
       		  }
       	 }

       con.close();
       return null;

    } catch (XSDException xsde) {
    		log.debug("XSDException occured : " + xsde.getMessage());
    		xsde.printStackTrace();

				ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", "ERR_INTERNAL", xsde.getMessage(), 0, 0);

				/** should create a ValidationException and throw back */
				throw new ValidationException ();
    	}

      catch (XMLParseException xmlpe) {
      	log.debug("XML parsing exception occured");

      	for (int i=0; i < xmlpe.getNumMessages(); i++) {
      		int messageType = xmlpe.getMessageType (i);
      		String prefix = "		warning : ";

      		if (i == XMLParseException.ERROR) {
      			prefix = "		error : ";
      		} else if (i == XMLParseException.FATAL_ERROR) {
      			  prefix = "		Fatal error : ";
      		  }

					String eMessage = xmlpe.getMessage(i);

      		String message =
      			prefix + eMessage + " [PublicID:" + xmlpe.getPublicId(i)
      			+ " SystemID:" + xmlpe.getSystemId(i) + "]";

      		int iIndex = eMessage.indexOf(":");
      		String errorCode = "ERR_UNKNOWN";

      		if (iIndex > 0) {
      			errorCode = eMessage.substring(0, iIndex);
      		}

      	  ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", errorCode, message, xmlpe.getLineNumber(i), xmlpe.getColumnNumber(i));

      		log.debug( message);
      	}

      	return null;
      }

      catch (SAXParseException saxpe) {
    		log.debug("SAXParseException occured : " + saxpe.getMessage());
    		saxpe.printStackTrace();

				ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", "ERR_INTERNAL", saxpe.getMessage(), saxpe.getLineNumber(), saxpe.getColumnNumber());

				/** should create a ValidationException and throw back */
				throw new ValidationException ();
      }

      catch (SAXException saxe) {
    		log.debug("SAXException occured : " + saxe.getMessage());
    		saxe.printStackTrace();

				ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", "ERR_INTERNAL", saxe.getMessage(), 0, 0);

				/** should create a ValidationException and throw back */
				throw new ValidationException ();

    	}

      catch (Exception e) {
    		log.debug("Exception occured : " + e.getMessage());
    		e.printStackTrace();

				ErrorUtil.reportError (strFileName, strSrno, "ValidationEngine.validate", "ERR_INTERNAL", e.getMessage(), 0, 0);

				/** should create a ValidationException and throw back */
				throw new ValidationException ();
    	}
  }

   // Helper method to create a URL from a file name
   static URL createURL(String strFileName)
   {
      URL url = null;
      try
      {
         url = new URL(strFileName);
      }
      catch (MalformedURLException ex)
      {
         File f = new File(strFileName);
         try
         {
            String path = f.getAbsolutePath();
            // This is a bunch of weird code that is required to
            // make a valid URL on the Windows platform, due
            // to inconsistencies in what getAbsolutePath returns.
            String fs = System.getProperty("file.separator");
            if (fs.length() == 1)
            {
               char sep = fs.charAt(0);
               if (sep != '/')
                  path = path.replace(sep, '/');
               if (path.charAt(0) != '/')
                  path = '/' + path;
            }
            path = "file://" + path;
            url = new URL(path);
         }
         catch (MalformedURLException e)
         {
            log.debug("Cannot create url for: " + strFileName);
            System.exit(0);
         }
      }
      return url;
   }



}