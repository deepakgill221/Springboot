package com.mastek.eElixir.channelmanagement.interfaces.util;

/**
 * Resource Manager
 */

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class ResourceManager {
  protected static InterfacesPropertyUtil propertyUtil = null;

  private static ResourceManager resources = null;
  private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  private ResourceManager () throws EElixirException {
		if (propertyUtil == null ) {
			propertyUtil = InterfacesPropertyUtil.getPropertyUtil();
		}
	}

  public static String getString (String s) {
		try {
		  if (resources == null) {
		  	resources = new ResourceManager();
		  }

		  return propertyUtil.getInterfacesProperty(s);
	  } catch (Exception e) {
				System.out.println(" Exception occured when read InterfaceProperty for "+ s + " : " + e.getMessage());
				return null;

	    }
	}

  public static URL get_data_xml (String fileName) {
    if (propertyUtil == null) {
		}
    return createURL(resources.getString("folder_data_xml"), fileName);
  }

  public static URL get_schema_xsd (String prefix) {
    return createURL (resources.getString("folder_schema_xsd"), resources.getString (prefix + "_schema_xsd"));
  }

  public static URL get_insert_xsl (String type) {
    return createURL (resources.getString ("folder_insert_xsl"), resources.getString (type + "_insert_xsl"));
  }

  public static URL get_tag_xml (String type) {
    return createURL (resources.getString ("folder_tag_xml"), resources.getString (type + "_tag_xml"));
  }

  public static String get_proc_name (String type) {
  	return resources.getString (type+ "_proc");
  }

  public static String getDataXMLFolder () {
  	return resources.getString("folder_data_xml");
  }

  public static String getSchemaXSDFolder () {
  	return resources.getString("folder_schema_xsd");
  }

  public static String getInsertXSLFolder () {
  	return resources.getString("folder_insert_xsl");
  }

  public static String getTagXMLFolder () {
  	return resources.getString("folder_tag_xml");
  }
/*
  public static String get_connectionName () {
    return resources.getString("ConnectionName");
  }
*/ 
   /** Helper method to create a URL from a file name */
   private static URL createURL(String folderName, String fileName)
   {
   	  fileName = folderName +"\\" + fileName;
      URL url = null;
      try
      {
         url = new URL(fileName);
      }
      catch (MalformedURLException ex)
      {
         File f = new File(fileName);

         try
         {
            String path = f.getAbsolutePath();
            // This is a bunch of weird code that is required to
            // make a valid URL on the Windows platform, due
            // to inconsistencies in what getAbsolutePath returns.
            String fs = System.getProperty("file.separator");
            if (fs.length() == 1)
            {
               char sep = fs.charAt(0);
               if (sep != '/')
                  path = path.replace(sep, '/');
               if (path.charAt(0) != '/')
                  path = '/' + path;

            }
            path = "file://" + path;
            url = new URL(path);
         }
         catch (MalformedURLException e)
         {
            log.debug("Cannot create url for: " + fileName);

            return null;
         }
      }
      return url;
   }

   public static void main (String argv[]) {
   	 System.out.println(get_schema_xsd ("PA01FA"));
   }
}