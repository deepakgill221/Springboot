package com.mastek.eElixir.channelmanagement.interfaces.util;

public class ValidationException extends Exception {
  public String getMessage () {
    return new String("Validation failed");
  }
}