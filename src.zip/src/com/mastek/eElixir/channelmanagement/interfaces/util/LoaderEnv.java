package com.mastek.eElixir.channelmanagement.interfaces.util;


import java.util.GregorianCalendar;


public class LoaderEnv implements  LoaderConstants
{
	private String _strUser ;
	private String _strPassword ;
	private String _strDBSchema;
	private String _strCmd;

	private String _strBankControlFile;
	private String _strBankDataFile;
	
	private String _strAddrControlFile ;
	private String _strAddrDataFile;

	private String _strOLIControlFile ;
	private String _strOLIDataFile;

	private String _strOAGTControlFile ;
	private String _strOAGTDataFile;

	private String _strAFCOControlFile ;
	private String _strAFCODataFile;

	private String _strControlFile;
	private String _strDataFile;
	private String _strLogFile;

	private String _strSerialNo;
	private Short _nExitState ;
	private Short _nType ;


	public void setCmd(String a_strCmd )
	{
		this._strCmd = a_strCmd;
	}

	public String getCmd()
	{
		return 	this._strCmd;
	}
		
	
	public void setLogFile(String a_strLog )
	{
		this._strLogFile = a_strLog;
	}

	public String getLogFile()
	{
		return 	this._strLogFile;
	}	

	public void setUser(String a_strUser )
	{
		this._strUser = a_strUser;
	}

	public String getUser()
	{
		return 	this._strUser;
	}
	
	public void setPassword(String a_strPassword)
	{
		this._strPassword = a_strPassword;
	}

	public String getPassword()
	{
		return 	this._strPassword;
	}

	public void setDBSchema(String a_strDBSchema)
	{
		this._strDBSchema = a_strDBSchema;
	}

	public String getDBSchema()
	{
		return 	this._strDBSchema;
	}


	public void setBankControlFile(String a_strBankControlFile )
	{
		this._strBankControlFile = a_strBankControlFile ;
	}

	public String getBankControlFile()
	{
		return this._strBankControlFile;
	}

	public void setBankDataFile(String a_strBankDataFile )
	{
		this._strBankDataFile = a_strBankDataFile ;
	}

	public String getBankDataFile()
	{
		return this._strBankDataFile;
	}

	public void setAddressControlFile(String a_strAddressControlFile )
	{
		this._strAddrControlFile = a_strAddressControlFile ;
	}

	public String getAddressControlFile()
	{
		return this._strAddrControlFile;
	}

	public void setAddressDataFile(String a_strAddressDataFile )
	{
		this._strAddrDataFile = a_strAddressDataFile ;
	}

	public String getAddressDataFile()
	{
		return this._strAddrDataFile;
	}

	public void setOAGTControlFile(String a_strOAGTControlFile )
	{
		this._strOAGTControlFile = a_strOAGTControlFile ;
	}

	public String getOAGTControlFile()
	{
		return this._strOAGTControlFile;
	}

	public void setOAGTDataFile(String a_strOAGTDataFile )
	{
		this._strOAGTDataFile = a_strOAGTDataFile ;
	}

	public String getOAGTDataFile()
	{
		return this._strOAGTDataFile;
	}

	public void setAFCOControlFile(String a_strAFCOControlFile )
	{
		this._strAFCOControlFile = a_strAFCOControlFile ;
	}

	public String getAFCOControlFile()
	{
		return this._strAFCOControlFile;
	}


	public void setAFCODataFile(String a_strAFCODataFile )
	{
		this._strAFCODataFile = a_strAFCODataFile ;
	}

	public String getAFCODataFile()
	{
		return this._strAFCODataFile;
	}


	public void setOLIControlFile(String a_strOLIControlFile )
	{
		this._strOLIControlFile = a_strOLIControlFile ;
	}

	public String getOLIControlFile()
	{
		return this._strOLIControlFile;
	}

	public void setOLIDataFile(String a_strOLIDataFile )
	{
		this._strOLIDataFile = a_strOLIDataFile ;
	}

	public String getOLIDataFile()
	{
		return this._strOLIDataFile;
	}

	public void setExitState(Short a_nExitState)
	{
		this._nExitState = a_nExitState;
	}

	public Short getExitState()
	{
		if (this._nExitState.intValue() > 0)
		{
			//set the state as Error
			this._nExitState = new Short("1");
		}

		return this._nExitState ;
	}

	public void setType(Short a_nType)
	{
		this._nType = a_nType;
	}

	public Short getType()
	{
		return this._nType ;
	}

	/**
	* Will return the active Control file depending on Type of Upload
	*/	
	public String getActiveControlFile()
	{
		switch (this._nType.intValue())
		{
			case LoaderConstants.ADDRESS_UPLOAD:
					return this._strAddrControlFile;
			case LoaderConstants.BANK_UPLOAD:
					return this._strBankControlFile;
			case LoaderConstants.OTHER_LIFE_INSURANCE_UPLOAD:
					return this._strOAGTControlFile;
			case LoaderConstants.AFCO_UPLOAD:
					return this._strAFCOControlFile;
			case LoaderConstants.ORICO_UPLOAD:
					return this._strOAGTControlFile;
	
			default :	return "ERROR";
		}

	}

	/**
	* Will return the active Data file depending on Type of Upload
	*/
	public String getActiveDataFile()
	{
		switch (this._nType.intValue())
		{
			case LoaderConstants.ADDRESS_UPLOAD:
					return _strAddrDataFile;
			case LoaderConstants.BANK_UPLOAD:
					return _strBankDataFile;
			case LoaderConstants.OTHER_LIFE_INSURANCE_UPLOAD:
					return _strOAGTDataFile;
			case LoaderConstants.AFCO_UPLOAD:
					return this._strAFCODataFile;
			case LoaderConstants.ORICO_UPLOAD:
					return this._strOAGTDataFile;		
			default :	return "ERROR";
		}
	}

	public void setDataFile(String a_strDataFile){
		this._strDataFile = a_strDataFile;
	}

	public String getDataFile(){
		return this._strDataFile;
	}

	public void setControlFile(String a_strControlFile){
		this._strControlFile = a_strControlFile;
	}

	public String getControlFile(){
		return this._strControlFile;
	}

	/**
	* Will return the PREFIX depending on Type of Upload
	*/
	public String getTypeDesc() 
	{
		switch (this._nType.intValue())
		{
			case LoaderConstants.ADDRESS_UPLOAD:
					return ADDRESS_TAG;
			case LoaderConstants.BANK_UPLOAD:
					return BANK_TAG;
			case LoaderConstants.OTHER_LIFE_INSURANCE_UPLOAD:
					return OTHER_LIFE_INSURANCE_TAG;
			case LoaderConstants.AFCO_UPLOAD:
					return AFFILATED_COMPANY_TAG;
			case LoaderConstants.ORICO_UPLOAD:
					return ORICO_TAG;	
			default :	return "ERROR";
		}
	}

	/**
	* Will return the Interface Table Name depending on Type of Upload
	*/
	public String getInterfaceTableName() 
	{
		switch (this._nType.intValue())
		{
			case LoaderConstants.ADDRESS_UPLOAD:
					return LoaderConstants.ADDRESS_INT_TABLE ;
			case LoaderConstants.BANK_UPLOAD:
					return LoaderConstants.BANK_INT_TABLE;
			case LoaderConstants.OTHER_LIFE_INSURANCE_UPLOAD:
					return LoaderConstants.OAGT_INT_TABLE;
			case LoaderConstants.AFCO_UPLOAD:
					return LoaderConstants.AFCO_INT_TABLE;
			case LoaderConstants.ORICO_UPLOAD:
					return LoaderConstants.OAGT_INT_TABLE;	

		}
		return "";

	}

  /**
	* Returns the serial Number
	* This method is used to obatin the type desciption + system date string
	* @return  String Primary key string for header table
	*/
	public String getSerialNo()
	{
		return this.getTypeDesc() + this.getSysDateAsNum();
	}

  /**
	* Can be shifted to util class later
	* This method is used to obatin the system date string
	* @return  String the System date in YYYYMMDD format
	*/
    public String getSysDateAsNum()
	{
		GregorianCalendar gcDate =new GregorianCalendar();

		    int iDate = gcDate.get(gcDate.DATE);
            int iMonth = gcDate.get(gcDate.MONTH)+1;
            int iYear = gcDate.get(gcDate.YEAR);
            String strDate=iDate+"";
            String strMonth=iMonth+"";

            if(iDate<10){
                strDate = "0"+iDate;
            }
            if(iMonth<10){
                strMonth = "0"+iMonth;
            }

		return iYear + strMonth+ strDate;
	}


	public String toString() 
	{
		return "LoaderEnv:: ControlFile: " + _strControlFile + " DataFile: "  + _strDataFile + " LoadType : " + _nType +
				" User " + _strUser + " DBSchema: " + _strDBSchema + 
			    " AddressControlFile: " + _strAddrControlFile + " AddressDataFile: "  + _strAddrDataFile +
			    " BankControlFile: " + _strBankControlFile + " BankDataFile: "  + _strBankDataFile +
			    " OAGTControlFile: " + _strOAGTControlFile + " OAGTDataFile: "  + _strOAGTDataFile +
			    " AFCOControlFile: " + _strAFCOControlFile + " AFCODataFile: "  + _strAFCODataFile +
			    " OAGTControlFile: " + _strOAGTControlFile + " OAGTDataFile: "  + _strOAGTDataFile +
				" SerialNo: " + _strSerialNo +  " Exit State : " + _nExitState;
	}
}
