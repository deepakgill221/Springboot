package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.util.StringTokenizer;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
//import oracle.xml.parser.v2.XMLDocument;
//import oracle.xml.parser.v2.XMLNode;

public class ConnectionFactory {

  private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /*
  private static XMLDocument root;

  public static Connection getConnection(String name) throws Exception {
    if (root == null) {
      // Read Connections.xml from the runtime CLASSPATH
      Class c = ConnectionFactory.class;
      InputStream file = c.getResourceAsStream("/resources/Connection.xml");
      if (file == null) {
        throw new FileNotFoundException("Connection.xml not in CLASSPATH");
      }
      // Parse Connections.xml and cache the XMLDocument of config info
      root = XMLHelper.parse(file,null);
    }
    // Prepare an XPath expression to find the connectioin named 'name'
    String pattern = "/connections/connection[@name='"+name+"']";
    // Find the first connection matching the expression above
    XMLNode connNode     = (XMLNode) root.selectSingleNode(pattern);
    if (connNode != null) {
      String username     = connNode.valueOf("username");
      String password     = connNode.valueOf("password");
      String dburl        = connNode.valueOf("dburl");
      String driverClass  = "oracle.jdbc.driver.OracleDriver";
      Driver d = (Driver)Class.forName(driverClass).newInstance();
      //log.debug("Connecting as " + username + " at " + dburl);
      return  DriverManager.getConnection(dburl,username,password);
    }
    else return null;
  }*/

  public static Connection getConnection (String name) {
		try {
			String dbString = ResourceManager.getString (name);
			StringTokenizer tokenizer = new StringTokenizer (dbString, ",", false);

			String dburl        = tokenizer.nextToken();
			String username     = tokenizer.nextToken();;
			String password     = tokenizer.nextToken();;

			String driverClass  = "oracle.jdbc.driver.OracleDriver";
			Driver d = (Driver)Class.forName(driverClass).newInstance();

			return  DriverManager.getConnection(dburl,username,password);
	  } catch (Exception e) {
			  log.debug ("Exception occured : " + e.getMessage());
			  e.printStackTrace();

			  return null;
	  }
	}
}
