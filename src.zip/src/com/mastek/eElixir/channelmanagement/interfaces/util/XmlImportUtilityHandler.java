package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.util.Vector;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class XmlImportUtilityHandler {

  private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  public static Vector performImport (String fileName, boolean a_bRunpoint) {

	log.debug("XmlImportUtilityHandler --Runpoint is " + a_bRunpoint);
    Vector result = XmlImportUtility.performImport (fileName, a_bRunpoint);

    /** dummy call to the XMLImportUtil */
    //log.debug ("  calling XmlImportUtil.performImport("+ fileName +")");

    /** return result */
    //String result = fileName + " successfully imported";

    //if (fileName.indexOf("HE") >= 0) {
    //  result = fileName + " import failed";
    //}

    return result;
  }

 /**
 * Commandline Usage 
 */
  public static void main (String argv[]) {

		if (argv.length < 2)			{
			log.debug ("Usage : XmlImportUtilityHandler filename [full | partial]" );
			System.exit(1);
		}

		try {
//			String fileName = argv[0];

			performImport(argv[0], argv[1].equals("full"));

		} catch (Exception e) {
				log.debug ("XmlImportUtilityHandler--Exception occured : " + e.getMessage());
				e.printStackTrace();
				System.exit(1);
		}
	}
}