package com.mastek.eElixir.channelmanagement.interfaces.util;

/*
Java file Name  :  XMLLoader.java
Author          :  Smruti Kanta Mohanty
Date            :
This program helps in storing XML data to multiple table from a XML file of any size.
*/

/*Class imports*/
import java.io.FileNotFoundException;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLNode;
import oracle.xml.parser.v2.XSLException;
import oracle.xml.parser.v2.XSLProcessor;
import oracle.xml.parser.v2.XSLStylesheet;

import org.w3c.dom.NodeList;
import org.xml.sax.SAXParseException;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;
public class XMLLoader{

  //Class level variables...
  private static URL      trans;   //.xsl file for transformation.
  private static URL      file;    //.xml file for data
  private static URL      tags;    //.xml contains all goup tags for insert processing.
  private static String   strSlNo;

  private static XSLStylesheet sheet = null;
  private static boolean ignoreErrs  = true;
  private static Connection    conn  = null;
  private static String  dateFormat  = ResourceManager.getString("DateFormat");
  private static String  docElement  = null;
//  private static String  connName    = null;		//"demo1";
  private static String  type    = null;					//not used
  private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  public static boolean load(URL transform,URL xmlfile,URL xmltags, String strslno, boolean flag) throws Exception
    {
    	trans=transform;
      file=xmlfile;
      tags=xmltags;
      strSlNo = strslno;
  //    connName = ResourceManager.get_connectionName();
			
			//log.debug("trans = " + trans);
			//log.debug("file =" + file);
			//log.debug("tags =" + tags);
			log.debug("strSlNo =" + strSlNo);
      
      try
        {
        /** Open data base connection... */
	//        conn = ConnectionFactory.getConnection(connName);
	      conn = DBConnection.getConnection();
        conn.setAutoCommit(false);
        }
      catch (SQLException sqle)
        {
        log.debug ("Error connecting to database : " + sqle.getMessage());
				sqle.printStackTrace();        
        
        return false;
      }

      /** Load the Stylesheet... */
      if (trans != null)
       {
        try
          {
          XSLProcessor proc = new XSLProcessor();
          proc.setBaseURL(trans);
          sheet = proc.newXSLStylesheet(trans);
          }		//try...
        catch (XSLException xsle)
          {
          log.debug ("Error loading stylesheet : " + xsle.getMessage());
          xsle.printStackTrace();
          
          HeaderUpdate(1, strslno);
          return false;
          }		//catch..
        } else {
        	  throw new IllegalArgumentException (" invalid value for Transformation (XSL) : NULL");
          }	

          /** Create a Multi-table Insert Handler */
          MultiTableInsertHandler mtih = new MultiTableInsertHandler(conn,sheet,ignoreErrs, strSlNo);

          /** Set the date format for the insert handler (null is ok) */
          mtih.setDateFormat(dateFormat);

          /** Use an XMLDocumentSplitter to handle large documents, passing
            * MultiTableInsertHandler to be used for each "SubDocument" found
            */
          XMLDocumentSplitter splitter = new XMLDocumentSplitter( mtih );

          /** Get all the docElement from Tags.xml... and loop through each element... */
          DOMParser d = new DOMParser();
          try {
            d.parse(tags);
          } catch(SAXParseException spex) {
              log.debug ("Error occured during parsing : " + spex.getMessage());
              spex.printStackTrace();
            
              HeaderUpdate(1, strslno);
              return false;
            }	
            catch(FileNotFoundException fnfe) {
              log.debug ("File missing : " + fnfe.getMessage());
            	fnfe.printStackTrace();
            
            	HeaderUpdate(1, strslno);
            	return false;
            }

          /** Create node list */
          try
            {
            XMLDocument xmldoc = (XMLDocument)d.getDocument();
            NodeList nl = null;
            nl=xmldoc.selectNodes("//TAGS/TAG");
            int found = nl.getLength();
            
            if(found >0) {
             for(int z = 0; z<found; z++) {
               XMLNode curNode = (XMLNode)nl.item(z);
               docElement = curNode.valueOf(".");

               /**
                * Process the input document, splitting it into subdocs to be
                * handled based on the specified docElement.
                */
               
               splitter.split(file,docElement);
							 
							 ///** for test ONLY */ conn.commit();
							 
							 if (!splitter.getStatus()) {
							 	 log.debug ("Failure during insert.. Aborting");
															 
								 try {
								   conn.rollback();	
								   HeaderUpdate(1, strslno);
								   conn.close();
								   log.debug ("Changes rolled back.");
								} catch (SQLException e) {
										log.debug ("Rollback failed : " + e.getMessage());
										e.printStackTrace();
								  }
								 return false;	
							 }
             }

  					 /** call the store procedure to insert into main table */
 						if (flag) { /** @RC1.0 */
	 						String fileName = xmlfile.getFile();
	 						int index =  fileName.lastIndexOf("/");
	            String s = fileName.substring(index + 1, fileName.length() - 4);
	              
	            /** call the PL/SQL procedure (interface -> main table) */
	            
	            String procedureName = ResourceManager.get_proc_name(s.substring(0,6));
	            CallableStatement cs = conn.prepareCall("{call "+ procedureName +" (?, ?, ?, ?)}");
	            cs.setString(1, s);
	            cs.setString (2, strSlNo);
	            
	            cs.registerOutParameter(3, Types.INTEGER);
	            cs.registerOutParameter(4, Types.VARCHAR);
	            
	            cs.execute();              
								
							if (cs.getInt(3) != 0) {
								log.debug ("Error : " + cs.getInt(3) + " " + cs.getString(4));
							
								index =  fileName.lastIndexOf("/");
								ErrorUtil.reportError (s, strSlNo, "XMLLoader.load", "ERR_INTERNAL", "Error executng procedure '"+procedureName+"': " + cs.getString(4), 0,0); 
								throw new Exception ("failure");
							}
					  }
						/** Update insert sucsessfull... */
		        HeaderUpdate(0, strslno);
		        conn.setAutoCommit(true);
						conn.commit();
		        conn.close();
		        return true;						   
          }
          return false;
         } catch(XSLException xse) {
             log.debug (" XSL Exception : " + xse.getMessage());
             xse.printStackTrace();
 					   
 					   try {
               conn.rollback();
               HeaderUpdate(1, strslno);
              
               log.debug ("Rollback done...");
               return false;
             }
             catch (SQLException sqlex) {
                log.debug ("Failed to rollback transaction : " + sqlex.getMessage());
               sqlex.printStackTrace();
              
                HeaderUpdate(1, strslno);
                return false;
             }
           }
           
           catch (Exception ex) {
             /** Update Header table to error and roll back detail table insert. */
             log.debug ("Exception occured : " + ex.getMessage());
             ex.printStackTrace();
             
             String sFile = xmlfile.getFile();
             int i = sFile.lastIndexOf("/");
						 
						 sFile = sFile.substring (i + 1, sFile.length()-4);
							             
						 ErrorUtil.reportError (sFile, strSlNo, "XMLLoader.load", "ERR_INTERNAL", ex.getMessage(), 0,0); 
								
             try {
               conn.rollback();
               HeaderUpdate(1, strslno);
              
               log.debug ("Rollback done...");
               return false;
             } catch (SQLException sqlex) {
                 log.debug ("Failed to rollback transaction : " + sqlex.getMessage());
                 sqlex.printStackTrace();
              
                 HeaderUpdate(1, strslno);
                 return false;
               }
            }
        }

	private static boolean HeaderUpdate(int status, String slno)
    {
    try
      { 
      
//      Connection con = ConnectionFactory.getConnection(connName);
      Connection con = DBConnection.getConnection();
      //update status in header table.... to processing
      Statement stmt = con.createStatement();
      int rowUpdated = stmt.executeUpdate("UPDATE CHM_XMLFILES_DTL_INT SET NSTATUS = " + status + " WHERE STRSERIAL = '" + slno + "' AND NIEFLAG = 1" );
      if (rowUpdated==0)
        {
        con.close();
        return false;
        }
      con.close();
      return true;
      }
    catch(SQLException sqle)
      {
       log.debug ("Database error while reporting ERROR to database : " + sqle.getMessage());
       sqle.printStackTrace();
       return false;
      }
      
      catch (Exception e) {
      	log.debug ("Exception occured : " + e.getMessage());
      	e.printStackTrace();
      	
      	return false;
      }
    }
  }

