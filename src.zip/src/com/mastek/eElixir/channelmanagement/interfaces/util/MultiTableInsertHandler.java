package com.mastek.eElixir.channelmanagement.interfaces.util;

/*
Java file Name  :  XMLLoader.java
Author          :  Smruti Kanta Mohanty
Date            :
This program helps in inserting XML data to multiple table from a XML file of any size.
*/

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;

import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLElement;
import oracle.xml.parser.v2.XSLProcessor;
import oracle.xml.parser.v2.XSLStylesheet;
import oracle.xml.sql.dml.OracleXMLSave;

import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class MultiTableInsertHandler implements XMLDocumentHandler {
  private XMLDocument    categories = null;
  private String         path       = null;
  private String         table      = null;
  private XSLStylesheet  sheet      = null;
  private String         dateFormat = null;
  private int itemsHandled          = 0;
  private int itemsInserted         = 0;
  private boolean ignoreErrors      = false;
  private boolean successful      = true;
  private boolean f = true;
  private String strSlrNo = null;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  Connection     conn;

  // Provide a JDBC Connection and optionally an XSL Transformation
  // to be used to transform the XML Datagram into multi-table insert format
  // If 'ignoreErrors' is true, then individual inserts can succeed even if
  // some fail due to errors. If false, any error on insert does a rollback.
  public MultiTableInsertHandler( Connection conn,
                                  XSLStylesheet sheet,
                                  boolean ignoreErrors, String SrNo ) {
   this.conn         = conn;
   this.sheet        = sheet;
   this.ignoreErrors = ignoreErrors;
   this.strSlrNo = SrNo;
  }

  // Process an XML datagram for multi-table insert
  public boolean handleDocument( Document d, URL u ) throws Exception {
    try {
          itemsHandled++;
      f = handle(d,u);
      itemsInserted++;
      log.debug("MultiTableInsertHandler--handleDocument--" + formatted(itemsHandled)+": Inserted.");
			return true;
    }
    catch (oracle.xml.sql.OracleXMLSQLException ex) {
      try { conn.rollback(); successful = false;} catch (SQLException s) {}
      log.debug("MultiTableInsertHandler--handleDocument--Exception :: " + formatted(itemsHandled)+": Failed, ORA-" + 
		  formatted(ex.getErrorCode()));

      return false;
    }
  }

  // Handle the transformation and multi-table inserting
  private boolean handle(Document d, URL u) throws Exception {
    XMLDocument result = null;
    NodeList    nl     = null;
    // If a transformation has been specified, do the transformation
    if (sheet != null) {

    Element e = d.getDocumentElement();
    e.setAttribute("SRNO", strSlrNo);

      XSLProcessor  processor = new XSLProcessor();
      DocumentFragment df = processor.processXSL(sheet, (XMLDocument)d);
      result = new XMLDocument();

      result.appendChild(df);

    }
    else {
      result = (XMLDocument)d;
    }
    // First check if document element is ROWSET. If present, only one ROWSET
    nl = result.selectNodes("/ROWSET");
    if (nl != null && nl.getLength() == 0) {
       XMLElement e = (XMLElement) result.getDocumentElement();
       // If ROWSET is not Doc Element, Search for ROWSET children elements
       nl = e.selectNodes("ROWSET");
    }
    String table = null;
    int rowsets = nl != null ? nl.getLength() : 0;
    // Loop over all the ROWSET elements we found.
    for (int z = 0; z < rowsets; z++ ) {
      // Create a new document with current ROWSET as doc element.
      XMLDocument insDoc = new XMLDocument();
      XMLElement curElt = (XMLElement)nl.item(z);
      curElt.getParentNode().removeChild(curElt);
      insDoc.adoptNode(curElt);
      insDoc.appendChild(curElt);
      // Pickup the target tablename from the table attribute of ROWSET tag
      table = curElt.valueOf("@table");

      //log.debug (table == null);
	  //added logs, remove them after line number col number
      log.debug ("MultiTableInsertHandler--handle--DocuElement--" + insDoc.getDocumentElement()); 
      log.debug ("MultiTableInsertHandler--handle--First Child DocuElement--" + insDoc.getDocumentElement().getFirstChild()); 

      // If table name was given and ROWSET element has some child elements
      if (table != null && insDoc.getDocumentElement().getFirstChild() != null) {
        try {
          // Create the XMLSave object and pass current ROWSET doc and tablename
          OracleXMLSave xs = new OracleXMLSave(conn,table);
          //xs.setCommitBatch(1);
          xs.setIgnoreCase(true);
          if (dateFormat != null) {
            xs.setDateFormat(dateFormat);
          }
          int rows = xs.insertXML(insDoc);

          log.debug ("MultiTableInsertHandler--handle--Rows inserted : " + rows);
          xs.close();

          return true;
        }
        catch (oracle.xml.sql.OracleXMLSQLException ex) {
          // If we're ignoring errors, then note the error and continue.
          if (ignoreErrors) {
            log.debug ("MultiTableInsertHandler--handle--" + " XML SQL Error: "+ ex.getXMLSQLErrorString() 
					 + "XML Error string: " + ex.getXMLErrorString() + " Exception :: " + ex.getMessage() );
            log.debug("MultiTableInsertHandler--handle-- " + formatted(itemsHandled)+": Ignoring, ORA-" +  formatted(ex.getErrorCode()) 
					 + " on table " + table);
			insDoc.print(System.out);
			insDoc.print(new FileOutputStream("XMLError.dmp",true));//added VinayC
			ByteArrayOutputStream bos = new ByteArrayOutputStream(); 
			insDoc.print(bos);

			//Adding Error trapping for record whose insert fails. VinayC

			ErrorUtil.reportError (u.getFile(), strSlrNo, "MultiTableInsertHandler.handle", "Error Inserting Record", ex.getMessage() + "Erroneous Record: " + bos.toString(), 0, 0);
			successful = false;
			return false;

          }
          else {
            throw ex;
          }
        }
      }
    }

    return false;
  }
  public int getItemsHandled() { return itemsHandled; };
  public void setDateFormat(String format) {
    dateFormat = format;
  }
  private String formatted(long n) {
    java.text.DecimalFormat df = new java.text.DecimalFormat();
    df.applyPattern("00000");
    return df.format(n).toString();
  }

  public boolean isSuccessful () {
  	return (f && successful);
  }
}