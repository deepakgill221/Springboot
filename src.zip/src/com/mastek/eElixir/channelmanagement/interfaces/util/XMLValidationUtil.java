package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class XMLValidationUtil {

  private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	public static String validate (String dataFile,  String schemaFile,  String tagFile) {
																  
		try {
			URL dataURL = createURL (dataFile);
			URL schemaURL = createURL (schemaFile);
			URL tagURL = createURL (tagFile);
			
			return ValidationEngine.validate (dataURL, schemaURL, tagURL);
		} catch (ValidationException vex) {
				log.debug ("ValidationException occured : " + vex.getMessage());
				vex.printStackTrace();
				return null;
			}
			
			catch (Exception e) {
				log.debug ("Excepion occured : " + e.getMessage());
				e.printStackTrace();
				
				return null; 
			}																		  
  }		
  
	/** Helper method to create a URL from a file name */
  private static URL createURL(String fileName)
  {
      URL url = null;
      try
      {
         url = new URL(fileName);
      }
      catch (MalformedURLException ex)
      {
         File f = new File(fileName);
         
         try
         {
            String path = f.getAbsolutePath();
            // This is a bunch of weird code that is required to
            // make a valid URL on the Windows platform, due
            // to inconsistencies in what getAbsolutePath returns.
            String fs = System.getProperty("file.separator");
            if (fs.length() == 1)
            {
               char sep = fs.charAt(0);
               if (sep != '/')
                  path = path.replace(sep, '/');
               if (path.charAt(0) != '/')
                  path = '/' + path;
               
            }
            path = "file://" + path;
            url = new URL(path);
         }
         catch (MalformedURLException e)
         {
            log.debug("Cannot create url for: " + fileName);
            
            return null;
         }
      }
      return url;
   }     														  
}