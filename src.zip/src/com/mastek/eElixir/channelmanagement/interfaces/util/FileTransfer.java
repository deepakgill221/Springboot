package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class FileTransfer {
 
  private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  public static boolean moveFile (String fileName, String source, String target) {
    try {

      URL sourceURL = createURL (source, fileName);

      log.debug (sourceURL.getFile());
      File s = new File (source, fileName);
      if (!s.exists()) {
		log.debug (" Source path '" + source + ":" + fileName + "' not found");

		return false;
	  }


      File t = new File (target);
      if (!t.exists()) {
		log.debug (" Target path '" + target + "' does not exist");

		if (!t.mkdirs()) {
		  log.debug ("  failed to create " + target);
		  return false;
		}

		log.debug (" " + target + " created.");
		return true;
	  }

	  t = new File (target, fileName);

	  return s.renameTo (t);


    } catch (Exception e) {
        log.debug ("  Exception occured : " + e.getMessage());
        e.printStackTrace();

        return false;
      }

  }

	/** Helper method to create a URL from a file name */
	private static URL createURL(String folderName, String fileName)
	{
	  fileName = folderName +"\\" + fileName;
	  URL url = null;
	  try
	  {
		 url = new URL(fileName);
	  }
	  catch (MalformedURLException ex)
	  {
		 File f = new File(fileName);

		 try
		 {
			String path = f.getAbsolutePath();
			// This is a bunch of weird code that is required to
			// make a valid URL on the Windows platform, due
			// to inconsistencies in what getAbsolutePath returns.
			String fs = System.getProperty("file.separator");
			if (fs.length() == 1)
			{
			   char sep = fs.charAt(0);
			   if (sep != '/')
				  path = path.replace(sep, '/');
			   if (path.charAt(0) != '/')
				  path = '/' + path;

			}
			path = "file://" + path;
			url = new URL(path);
		 }
		 catch (MalformedURLException e)
		 {
			log.debug("Cannot create url for: " + fileName);

			return null;
		 }
	  }
	  return url;
	}

  public static void main (String argv[]) {
	  log.debug("Filetransfer Begins");
    FileTransfer.moveFile (argv[0], argv[1], argv[2]);
	  	  log.debug("Filetransfer Ends");
  }
}