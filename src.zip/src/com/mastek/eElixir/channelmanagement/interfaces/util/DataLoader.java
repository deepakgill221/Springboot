/********************************************************************
*
*  PROJECT						: PRUDENTIAL
*  MODULE NAME					: Common
*  FILENAME						: DataLoader
*  AUTHOR						: VINAY CEREJO
*  VERSION						: 1.0
*  CREATION DATE				: January 30, 2003
*  COMPANY						: Mastek Ltd.
*  COPYRIGHT					: COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class DataLoader 
{
    private static Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
	private Properties _oProps = null;
	private LoaderEnv _oLoaderEnv = null;
	private Short _nLoadType = null;


	public DataLoader(LoaderEnv a_oLoaderEnv)
	{
		this._oLoaderEnv = a_oLoaderEnv;
	}


	/**
	* DEPRECATED
	*/
	public DataLoader(short a_nLoadType)
	{
		_nLoadType = new Short(a_nLoadType);
		//loadProperties();
	}

	/**
	* DEPRECATED
	* Method will load all external properties to set up DataLoader to execute SQL Loader program
	* @return HashMap hash will contain all key values 
	*/
	public void loadProperties() 
	{
		log.debug("DataLoader--loadProperties--Begin");
		try
		{
			log.debug("DataLoader--Loading Properties from file " + LoaderConstants.LOADER_PROPS_FILE);
			_oProps = new Properties();
			_oProps.load(this.getClass().getResourceAsStream(LoaderConstants.LOADER_PROPS_FILE));

			log.debug("DataLoader--Loader Properties Read: "+ _oProps);

			log.debug("DataLoader--Loader Environment being Set up");
			_oLoaderEnv = new LoaderEnv();
			_oLoaderEnv.setType(this._nLoadType);

			_oLoaderEnv.setUser(_oProps.getProperty("db.user"));
			_oLoaderEnv.setPassword(_oProps.getProperty("db.password"));
			_oLoaderEnv.setDBSchema(_oProps.getProperty("db.schema"));

			_oLoaderEnv.setAddressDataFile(_oProps.getProperty("data.address"));
			_oLoaderEnv.setAddressControlFile(_oProps.getProperty("ctrl.address"));

			_oLoaderEnv.setBankDataFile(_oProps.getProperty("data.bank"));
			_oLoaderEnv.setBankControlFile(_oProps.getProperty("ctrl.bank"));

			_oLoaderEnv.setOLIDataFile(_oProps.getProperty("data.oli"));
			_oLoaderEnv.setOLIControlFile(_oProps.getProperty("ctrl.oli"));

			_oLoaderEnv.setAFCODataFile(_oProps.getProperty("data.afco"));
			_oLoaderEnv.setAFCOControlFile(_oProps.getProperty("ctrl.afco"));

			_oLoaderEnv.setOAGTDataFile(_oProps.getProperty("data.oagt"));
			_oLoaderEnv.setOAGTControlFile(_oProps.getProperty("ctrl.oagt"));

			log.debug("DataLoader--Loader Environment Set up Done " + _oLoaderEnv);

		}
		catch (Exception ex){
			log.debug("DataLoader--Loading Parameters Failed  " +ex);
			ex.printStackTrace();
		}

		log.debug("DataLoader--loadProperties--End");
	}

	/**
	*@return LoaderEnv. The loader environment properties
	*/
	public LoaderEnv getEnv()
	{
		return this._oLoaderEnv;

	}

	/**
	* Method will build commandline parameters to pass for SQL Loader
	*
	* @return String 
	*/
	public String generateCommandLine() 
	{
		log.debug("DataLoader--generateCommandLine--Begin");

		String strCommandLine = _oLoaderEnv.getCmd() +  " userid=" + _oLoaderEnv.getUser() + "/" + _oLoaderEnv.getPassword() +
								"@" + _oLoaderEnv.getDBSchema() + " control=" + _oLoaderEnv.getControlFile() + 
								" data=" + _oLoaderEnv.getDataFile() + " log=" + _oLoaderEnv.getLogFile() ;

		log.debug("DataLoader--generateCommandLine--CMD Line : " + strCommandLine );

		log.debug("DataLoader--generateCommandLine--End");
		return strCommandLine;
	}

	/**
	* Method will spawn a process for execution of SQL Loader
	* @param String a_strLoaderParam the parameters to fire SQL Loader with
	* @return int execution status indicates Success if O, failure other wise
	*/
	public int executeSQLLoader(String a_strLoaderParam) throws EElixirException
	{
		log.debug("DataLoader--executeSQLLoader--Begin");
		Process p = null;
		BufferedReader err=null;
		try
		{ 
			log.debug("DataLoader--executeSQLLoader--CMD: " + a_strLoaderParam);
			p = Runtime.getRuntime().exec(a_strLoaderParam);
			//p.waitFor();
			err	= new BufferedReader(new InputStreamReader(p.getInputStream()));		
			String line;		
			while ((line = err.readLine()) != null)	System.out.println(line);
			
		}
		catch (Exception ex)	{
			log.debug("DataLoader--Execution Halted Midway. ");
			log.debug("DataLoader--Cause : " + ex);
			ex.printStackTrace();
			new EElixirException(ex, "P9505");

		}
//		FindBug_Fix_SUNAINA_STARTS
		finally{
			try {
				err.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
//		FindBug_Fix_SUNAINA_ENDED
		log.debug("DataLoader--executeSQLLoader--End");
		log.debug("DataLoader--Execution Complete. Exit with "  + p.exitValue());
		return p.exitValue();
	}

	/**
	* Method will Upload Data for Bank, Address or Other Life Insurance
	* @param int 
	* @return int execution status indicates Success if O, failure other wise
	*/
	public int uploadData() throws EElixirException
	{
		log.debug("DataLoader--upLoadData--Begin");
		
		String strCmdLine = generateCommandLine();
		int iExecStaus =  executeSQLLoader(strCmdLine);

		log.debug("DataLoader--upLoadData--End");
		return iExecStaus;
	}

	/**
	* Test Load of DataLoader
	*/
	public static void main(String args[]) 
	{
/*		if (args.length == 0 )		{

			log.debug("DataLoader--Upload Failed!! Parameter Missing. Valid usage is >>");
			log.debug("DataLoader--DataLoader [Address|Bank|OLI|AFCO|OAGT]");
			System.exit(1);
		}

		log.debug("DataLoader-->>Upload of Data Begins for " + args[0]);

		DataLoader oDL = null;

		if (args[0].equalsIgnoreCase("Address"))		{
			oDL = new DataLoader(LoaderConstants.ADDRESS_UPLOAD);
		}
		else if (args[0].equalsIgnoreCase("Bank"))		{
			oDL = new DataLoader(LoaderConstants.BANK_UPLOAD);
		}
		else if (args[0].equalsIgnoreCase("OLI"))		{
			oDL = new DataLoader(LoaderConstants.OTHER_LIFE_INSURANCE_UPLOAD);
		}
		else if (args[0].equalsIgnoreCase("AFCO"))		{
			oDL = new DataLoader(LoaderConstants.AFCO_UPLOAD);
		}
		else if (args[0].equalsIgnoreCase("OAGT"))		{
			oDL = new DataLoader(LoaderConstants.ORICO_UPLOAD);
		}

		else{
			log.debug("DataLoader--Upload Failed!! Invalid Parameter. Valid usage is >>");
			log.debug("DataLoader--DataLoader [Address|Bank|OLI]");
			System.exit(1);
		}

		LoaderEnv oLoaderEnv = oDL.getEnv();
		
		LoaderDAX oLoaderDAX = new LoaderDAX();
		int iStatus = oLoaderDAX.getStatus(oLoaderEnv);
		switch (iStatus )
		{
			case LoaderConstants.NOT_LOADED:
				log.debug("DataLoader-->>Loading file for first time");
				oLoaderDAX.deleteDetail(oLoaderEnv);
				oLoaderDAX.insertHeader(oLoaderEnv);
				log.debug("DataLoader-->>Loading Completed.");
				break;
			case LoaderConstants.NO_ERROR:
				log.debug("DataLoader-->>File has already been loaded.. Loading again is not allowed");
				System.exit(1);
				break;
			case LoaderConstants.LOAD_ERROR:
				log.debug("DataLoader-->>File had been loaded with errors. Loading again");
				oLoaderDAX.deleteDetail(oLoaderEnv);
				oLoaderDAX.updateHeaderStatus(oLoaderEnv);
				break;
			case LoaderConstants.BUSY:
				log.debug("DataLoader-->>File loading is in Progress. Simultaneous loading not supported");
				System.exit(1);
				break;
		}

		
		int iExecStatus = oDL.uploadData();
		if (iExecStatus == 0)		{
			log.debug("DataLoader-->>Data Loading Task Completed Successfull!");
		}
		else{
			log.debug("DataLoader-->>Data Loading Task Failed. Refer Logs for Details!");
		}
		oLoaderEnv.setExitState(new Short("" + iExecStatus));

		oLoaderDAX.updateHeader(oLoaderEnv);
		*/
	}
	

}

