package com.mastek.eElixir.channelmanagement.interfaces.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLParser;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class XMLHelper {
  // Parse an XML document from a character Reader
  public static XMLDocument parse( Reader r, URL baseUrl )
                         throws IOException, SAXParseException, SAXException  {
    // Construct an input source from the Reader
    InputSource input = new InputSource(r);
    // Set the base URL if provided
    if (baseUrl != null) input.setSystemId(baseUrl.toString());
    // Construct a new DOM Parser
    DOMParser xp = new DOMParser();
    // Parse in Non-Validating Mode
    xp.setValidationMode(XMLParser.NONVALIDATING);
    // Preserve Whitespace
    xp.setPreserveWhitespace(true);
    // Attempt to parse XML coming in from the Reader
    xp.parse(input);
    // If the parse is successful, return the DOM Document
    return (XMLDocument) xp.getDocument();
  }
  // Parse XML from an InputStream
  public static XMLDocument parse( InputStream is, URL baseURL )
                         throws SAXParseException, SAXException, IOException {
    // Construct a Reader and call parse(Reader)
    return parse( new InputStreamReader(is), baseURL );
  }
  // Parse XML From a String
  public static XMLDocument parse( String xml, URL baseurl )
                            throws MalformedURLException, IOException,
                                   SAXParseException, SAXException {

    // Construct a reader and call parse(Reader)
    return parse(new StringReader(xml),baseurl);
  }
  // Parse XML from a URL
  public static XMLDocument parse( URL url ) throws IOException,
                                                 SAXParseException,
                                                 SAXException  {
    // Construct an InputStream and call parse(InputStream)
    // Use the url passed-in as the baseURL
    return parse( url.openStream(), url);
  }
  // Format information for a parse error
  public static String formatParseError(SAXParseException s) {
     int lineNum = s.getLineNumber();
     int  colNum = s.getColumnNumber();
     String file = s.getSystemId();
     String  err = s.getMessage();
     return "XML parse error " + (file != null ? "in file " + file + "\n" : "")+
            "at line " + lineNum + ", character " + colNum + "\n" + err;
  }
}
