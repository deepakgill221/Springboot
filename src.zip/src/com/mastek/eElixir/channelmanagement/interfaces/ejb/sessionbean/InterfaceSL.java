package com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Vector;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.interfaces.util.LoaderEnv;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This InterfaceSL Local interface provides method for getting the data from Interface bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author 
 * @version 1.0
 */



public interface InterfaceSL extends EJBObject
{
  /**
    * Invoked to Obtain the status of various stored procedures by firing query.
    * @param: StrQuery
    * @throws RemoteException
    * @throws EElixirException
    */
  public Hashtable getStatus(Vector a_vecFileTags,String a_strIEFlag,String a_strDate) throws EElixirException, RemoteException;
  public Vector executeProcedures(Vector a_vecFileTags,String a_strDate,String a_strFilePath) throws EElixirException, RemoteException;	
/**
* method to launch SQL Loader for Data Uplaods of Address/Bank/ORICO etc
* @param a_iLoadeType the type of data to upload
* @return  0 indicating success, any other value indicates failure
*
*/
  public int upload(LoaderEnv a_oLoaderEnv) throws EElixirException, RemoteException;
}