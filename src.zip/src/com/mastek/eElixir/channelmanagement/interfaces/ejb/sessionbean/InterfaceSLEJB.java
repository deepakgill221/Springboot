package com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Vector;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.interfaces.dax.LoaderDAX;
import com.mastek.eElixir.channelmanagement.interfaces.util.DataLoader;
import com.mastek.eElixir.channelmanagement.interfaces.util.LoaderConstants;
import com.mastek.eElixir.channelmanagement.interfaces.util.LoaderEnv;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

/**
 * <p>Title: eElixir</p>
 * <p>Description: This Interface session bean gets the required information about the stored procedures required</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Nitin
 * @version 1.0
 */

public class InterfaceSLEJB implements SessionBean
{


  /**
   * Constructor of the InterfaceSLEJB class
   */
  public InterfaceSLEJB    ()
  {

  }

  /**
   * Called by the container to create a session bean instance. Its parameters typically
   * contain the information the client uses to customize the bean instance for its use.
   * It requires a matching pair in the bean class and its home interface.
   */
  public void ejbCreate    ()
  {

  }

  /**
   * A container invokes this method before it ends the life of the session object. This
   * happens as a result of a client's invoking a remove operation, or when a container
   * decides to terminate the session object after a timeout. This method is called with
   * no transaction context.
   */
  public void ejbRemove    ()
  {

  }

  /**
   * The activate method is called when the instance is activated from its 'passive' state.
   * The instance should acquire any resource that it has released earlier in the ejbPassivate()
   * method. This method is called with no transaction context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * The passivate method is called before the instance enters the 'passive' state. The
   * instance should release any resources that it can re-acquire later in the ejbActivate()
   * method. After the passivate method completes, the instance must be in a state that
   * allows the container to use the Java Serialization protocol to externalize and store
   * away the instance's state. This method is called with no transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * Set the associated session context. The container calls this method after the instance
   * creation. The enterprise Bean instance should store the reference to the context
   * object in an instance variable. This method is called with no transaction context.
   * @param sc
   */

  public void setSessionContext    (SessionContext sc)
  {
    this._EJB_Context = sc;
  }


  /**
   * Invoked to Obtain the list drop down list by firing query.
   * @param: StrQuery
   * @throws RemoteException
   * @throws EElixirException
   */

  public Hashtable getStatus(Vector a_vecFileTags,String a_strIEFlag,String a_strDate) throws EElixirException
  {
    log.debug("InterfaceSLEJB--getStatus--Start");
    log.debug("InterfaceSLEJB--getStatus--Start");
    Hashtable htFileTagsStatus=new Hashtable();
    PreparedStatement pstmtStatus=null;
    ResultSet rs=null;
    log.debug("value of date that is being converted to GC "+a_strDate);
    GregorianCalendar GCdt=DateUtil.retGCDate(a_strDate);
    log.debug("InterfaceSLEJB--getStatus--GC ready");
    try
    {
      log.debug("InterfaceSLEJB--getStatus--Getting DBconection " );
      log.debug("InterfaceSLEJB--getStatus--Getting DBconection " );
      _oConnection = DBConnection.getConnection();
      log.debug("InterfaceSLEJB--getStatus--Connection Obatined " + _oConnection );
      log.debug("InterfaceSLEJB--getStatus--Connection Obatined " + _oConnection );
      pstmtStatus=_oConnection.prepareStatement("select nstatus,strfiletag from CHM_XMLFILES_DTL_INT X where DTBATCH=? and NIEFLAG=? AND STRSERIAL IN (select max(STRSERIAL) from CHM_XMLFILES_DTL_INT Y where  X.DTBATCH=Y.DTBATCH AND X.NIEFLAG=Y.NIEFLAG and X.STRFILETAG=Y.STRFILETAG GROUP BY DTBATCH,NIEFLAG,STRSERIAL)");
      pstmtStatus.setTimestamp(1,DateUtil.retTimestamp(GCdt));
      pstmtStatus.setInt(2,Integer.parseInt(a_strIEFlag));
      rs=pstmtStatus.executeQuery();

      log.debug("InterfaceSLEJB--getStatus--result ste obtained " );
      log.debug("InterfaceSLEJB--getStatus--result ste obtained " );

      while(rs.next())
      {
        String strFileTag= rs.getString(2);
        int iStatus=rs.getInt(1);
        if(a_vecFileTags.contains(strFileTag))
            { htFileTagsStatus.put(strFileTag,""+iStatus);
        a_vecFileTags.remove(strFileTag);
        }
      }

      log.debug("InterfaceSLEJB--getStatus--hasttable ready " + htFileTagsStatus );
      log.debug("InterfaceSLEJB--getStatus--hasttable almost ready " + htFileTagsStatus );
      //if there are any elements left in the vector then that means thats that FileTag hasnt been implemented yet

      for(int i=0;i<a_vecFileTags.size();i++)
        htFileTagsStatus.put((String)a_vecFileTags.elementAt(i),"3");
      log.debug("InterfaceSLEJB--getStatus--hasttable ready " + htFileTagsStatus );

    }
    catch (EElixirException eex)
    {
      log.debug("InterfaceSLEJB--getStatus--Exception " +  eex);
      throw eex;
    }
    catch(Exception e){e.printStackTrace();}
    finally{
      try
      {
        if(pstmtStatus!=null)
          pstmtStatus.close();
        if(rs!=null)
          rs.close();
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex)
      {
        throw new EElixirException(eElex,"P1005");
      }
      catch(Exception e1){e1.printStackTrace();}
    }
    return htFileTagsStatus;
  }

  public Vector executeProcedures(Vector a_vecFileTags,String a_strDate, String a_strFilePath) throws EElixirException
  {
    log.debug("InterfaceSLEJB--executeProcedure--Start");
    Vector vFileTagsStatus=new Vector();
    GregorianCalendar GCdt=DateUtil.retGCDate(a_strDate);
    PreparedStatement pstmtUpDateStatus =null;//FindBug_Fix_SUNAINA_STARTS

    int iErrorCode;
    String strProcName = "";
    CallableStatement cstmt=null;

    log.debug("InterfaceSLEJB--executeProcedure--Getting DBconection " );
    try
    {
      _oConnection = DBConnection.getConnection();
      log.debug("InterfaceSLEJB--executeProcedure--Connection Obatined " + _oConnection );
      log.debug("InterfaceSLEJB--executeProcedure--Connection Obatined " + _oConnection );

      for(int i=0;i<a_vecFileTags.size();i++)
      {
        strProcName = ((String[])a_vecFileTags.elementAt(i))[0];
        String[] temp= (String[])a_vecFileTags.elementAt(i);
        log.debug("temp[0]"+temp[0]);
        log.debug("CM_PKG_XML_INT.temp[1]"+"CM_PKG_XML_INT." +temp[1]);

        cstmt=_oConnection.prepareCall("{ call CM_PKG_XML_INT."+temp[1]+"(?,?,?,?,?)}");

        //to set the input variables
        log.debug("1"+GCdt);
        log.debug("2-----"+a_strFilePath);
        log.debug("3---"+temp[0]);
        log.debug ("5----" + DateUtil.retTimestamp(GCdt).getClass().getName());
        cstmt.setTimestamp(1,DateUtil.retTimestamp(GCdt));
        cstmt.setString(2,a_strFilePath);
        cstmt.setString(3,temp[0]);

        //to set the data type of the output variables
        cstmt.registerOutParameter(4,Types.INTEGER);
        cstmt.registerOutParameter(5,Types.VARCHAR);

        try
        {
          cstmt.executeUpdate();
        }catch(Exception e){
          e.printStackTrace();
          String[] temp1 ={"","",""};
          temp1[0]=strProcName;
          temp1[1]="";
          temp1[2]=e.getMessage();
          vFileTagsStatus.add(temp1);
          continue;
        }


        log.debug("procedure executed");
        log.debug("***********************procedure executed");
        log.debug("cstmt.getInt(4)"+cstmt.getInt(4));
        log.debug("cstmt.getString(5)"+cstmt.getString(5));
        //get the output from the procedure called and put it in the Vector htFileTagsStatus
        iErrorCode=cstmt.getInt(4);

        String[] temp1 ={"","",""};
        temp1[0]=((String[])a_vecFileTags.elementAt(i))[0];
        temp1[1]=""+iErrorCode;
        temp1[2]=cstmt.getString(5);

        vFileTagsStatus.add(temp1);
        log.debug("vlaue being put in ht table:"+((String[])a_vecFileTags.elementAt(i))[0]+"__"+cstmt.getString(5));

        //update this status in into the database
        String strQuery;
        if(iErrorCode==0) strQuery="update CHM_XMLFILES_DTL_INT set nstatus=0 where nieflag=? and dtbatch=? and strfiletag=? and strserial=(select max(strfiletag) from CHM_XMLFILES_DTL_INT where nieflag=? and dtbatch=? and strfiletag=?) ";
        else  strQuery="update CHM_XMLFILES_DTL_INT X set nstatus=1 where nieflag=? and dtbatch=? and strfiletag=? and strserial=(select max(strfiletag) from CHM_XMLFILES_DTL_INT Y where nieflag=? and dtbatch=? and strfiletag=?)";

        pstmtUpDateStatus=_oConnection.prepareStatement(strQuery);
        pstmtUpDateStatus.setInt(1,Integer.parseInt(DataConstants.INTERFACE_IMPORT));
        pstmtUpDateStatus.setInt(4,Integer.parseInt(DataConstants.INTERFACE_IMPORT));
        pstmtUpDateStatus.setTimestamp(2,DateUtil.retTimestamp(GCdt));
        pstmtUpDateStatus.setTimestamp(5,DateUtil.retTimestamp(GCdt));
        pstmtUpDateStatus.setString(3,((String[])a_vecFileTags.elementAt(i))[0]);
        pstmtUpDateStatus.setString(6,((String[])a_vecFileTags.elementAt(i))[0]);

        log.debug("value about to be updated");
        pstmtUpDateStatus.executeUpdate();
        log.debug("value updated");

      }
      //}
      //catch (EElixirException eex)  {eex.printStackTrace();
      //	  log.debug("InterfaceSLEJB--executeProcedure--Exception " +  eex);
      //	  throw eex;
    }
    catch(Exception e){
      e.printStackTrace();
      String[] temp1 ={"","",""};
        temp1[0]="";
        temp1[1]="";
        temp1[2]=e.getMessage();
        vFileTagsStatus.add(temp1);

    }
    finally{
      try{
//FindBug_Fix_SUNAINA_STARTS
    	  if(pstmtUpDateStatus!=null)
    		  pstmtUpDateStatus.close();
//FindBug_Fix_SUNAINA_ENDS
        if(cstmt!=null)
          cstmt.close();
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
      catch(Exception e1){e1.printStackTrace();}
    }

    return vFileTagsStatus;

  }

/**
* method to launch SQL Loader for Data Uplaods of Address/Bank/ORICO etc
* @param a_iLoadeType the type of data to upload
* @return  0 indicating success, any other value indicates failure
*
*/
  public int upload(LoaderEnv a_oLoaderEnv) throws EElixirException
  {
	  DataLoader oDL = null;
   	  LoaderDAX oLoaderDAX = null;

	  try
	  {
			oDL = new DataLoader(a_oLoaderEnv );
			
			oLoaderDAX = new LoaderDAX();
			int iStatus = oLoaderDAX.getStatus(a_oLoaderEnv);
			switch (iStatus )
			{
				case LoaderConstants.NOT_LOADED:
					log.debug("InterfaceSLEJB--Loading file for first time");
					oLoaderDAX.deleteDetail(a_oLoaderEnv);
					oLoaderDAX.insertHeader(a_oLoaderEnv);
					break;
				case LoaderConstants.NO_ERROR:
					log.debug("InterfaceSLEJB--File has already been loaded.. Loading again is not allowed");
					return LoaderConstants.DUPLICATE_LOAD;
				case LoaderConstants.LOAD_ERROR:
					log.debug("InterfaceSLEJB--File had been loaded with errors. Loading again");
					oLoaderDAX.deleteDetail(a_oLoaderEnv);
					oLoaderDAX.updateHeaderStatus(a_oLoaderEnv);
					break;
				case LoaderConstants.BUSY:
					log.debug("InterfaceSLEJB--File loading is in Progress. Simultaneous loading not supported");
					return LoaderConstants.BUSY;
			}

			log.debug("InterfaceSLEJB--Loading begun.");
			int iExecStatus = oDL.uploadData();
			if (iExecStatus == 0)		{
				log.debug("InterfaceSLEJB--Data Loading Task Completed Successfull!");
			}
			else{
				log.debug("InterfaceSLEJB--Data Loading Task Failed. Refer Logs for Details!");
			}
			a_oLoaderEnv.setExitState(new Short("" + iExecStatus));
			oLoaderDAX.updateHeader(a_oLoaderEnv);

			return iExecStatus;

		}
		catch (EElixirException eex)		{
			log.debug("InterfaceSLEJB--Exception Loading Data!");
			throw eex;
		}
  }

  /**
   * Attributes declaration
   */
  Connection _oConnection = null;
  public SessionContext _EJB_Context = null;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}