package com.mastek.eElixir.channelmanagement.interfaces.ejb.sessionbean;

 
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This InterfaceSL Local home interface provides one create method  </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author 
 * @version 1.0
 */
public interface InterfaceSLHome extends EJBHome
{

    /**
     * Called by the client to create an EJB bean instance. It requires a matching pair in
     * the bean class, i.e. ejbCreate().
     * @throws javax.ejb.CreateException
     * return CommonSL
     */
    public InterfaceSL create    ()  throws CreateException , RemoteException ;
}