/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: GroupCreate.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Get GroupCreate is the Action Class for creating a Group Detail,depending upon the
 * data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       25/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.formulaengine.action;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.formulaengine.util.GroupFetch;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;
public class GroupCreate extends Action
{
  //private Log log = new Log(GroupSearch.class.getName(),Constants.CHM_MODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the GroupCreate class
   */
  public GroupCreate()
  {

  }


  /**
   * Uses the id of Group and gets the detail for that Group.
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    ArrayList arrGroupResult = null;
    GroupFetch oGroupFetch = new GroupFetch();
    try{
      arrGroupResult = oGroupFetch.fetchGroup(a_oRequest);
      String strGroupId = a_oRequest.getParameter("strGroupId");

      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
      strGroupId = remoteCHMSL.createGroup(arrGroupResult);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      log.debug("GroupCreate--created Group with Id " + strGroupId);
      EElixirUtils.reloadMaster(DataConstants.GROUP);
      arrGroupResult = remoteCHMSL.searchGroup(strGroupId);
      log.debug("GroupCreate--result accessed");
      setResult(arrGroupResult);
      log.debug("GroupCreate--result is set");
    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", arrGroupResult);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", arrGroupResult);
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", arrGroupResult);
      throw new EElixirException(fex, "P5012");
    }
    catch(EElixirException eex)
    {
      log.debug("GroupCreate--Inside catch of Eelixir exception in process of GroupCreate");
      a_oRequest.setAttribute("ResultObject", arrGroupResult);
      throw eex;
    }
  }
}