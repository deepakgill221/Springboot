/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: UnitCreate.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * Get UnitCreate is the Action Class for creating a Unit Detail,depending upon the
 * data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       25/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.formulaengine.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitFetch;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitResultMain;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.EElixirUtils;
import com.mastek.eElixir.common.util.Logger;
public class UnitCreate extends Action
{
  //private Log log = new Log(UnitSearch.class.getName(),Constants.CHM_MODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the UnitSearch class
   */
  public UnitCreate()
  {

  }


  /**
   * Uses the id of Unit and gets the detail for that Unit.
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    UnitResultMain oUnitResultMain = null;
    UnitFetch oUnitFetch = new UnitFetch();
    try{
      oUnitResultMain = oUnitFetch.fetchUnit(a_oRequest);
      
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_CREATE);
      String strUnitId = remoteCHMSL.createUnit(oUnitResultMain);
      log.debug("UnitCreate-CREATED UNIT str unitID is " + strUnitId);
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
      log.debug("UnitCreate-CREATED Reloading unit dropdown");
      EElixirUtils.reloadMaster(DataConstants.UNIT);
	  EElixirUtils.reloadMaster(DataConstants.LOGICAL_UNIT);
	  EElixirUtils.reloadMaster(DataConstants.ARITMETIC_UNIT);
      log.debug("UnitCreate-CREATED Reloading unit dropdown completed going on to search");
      oUnitResultMain = remoteCHMSL.searchUnit(strUnitId);
      log.debug("UnitCreate-CREATED search completed");
      log.debug("UnitCreate--result accessed");
      setResult(oUnitResultMain);
      log.debug("UnitCreate--result is set");
    }
    catch(RemoteException rex)
    {
      a_oRequest.setAttribute("ResultObject", oUnitResultMain);
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      a_oRequest.setAttribute("ResultObject", oUnitResultMain);
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      a_oRequest.setAttribute("ResultObject", oUnitResultMain);
      throw new EElixirException(fex, "P5005");
    }
    catch(EElixirException eex)
    {
      log.debug("UnitCreate--Inside catch of Eelixir exception in process of UnitCreate" + eex);
      a_oRequest.setAttribute("ResultObject", oUnitResultMain);
      eex.printStackTrace();
      throw eex;
    }
	catch(Exception ex)
	{
      		ex.printStackTrace();
	      log.debug("SKP-UnitCreate" + ex);
	}
  }
}