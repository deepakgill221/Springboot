/********************************************************************
 *
 *  PROJECT			: PRUDENTIAL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME			: NewFormulaListSearch.java
 *  AUTHOR			: Pallav Laddha
 *  VERSION			: 1.0
 *  CREATION DATE	        : October 20, 2002
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 1.1           4/1/2003          Jimmy Shah            Changes for the Audit of Menu Clicks
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * NewFormulaListSearch is the Action Class for Getting jsp page for first time ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       25/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.formulaengine.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.channelmanagement.util.MenuAccessLog;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class NewFormulaListSearch extends Action
{
  //private Log log = new Log(NewFormulaListSearch.class.getName(),Constants.CHM_MODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the NewFormulaListSearch class
   */
  public NewFormulaListSearch()
  {

  }

  /**
   * This is a dummy method, used only when page is loaded first time
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    try
    {
      MenuAccessLog.createMenuAccessLog(a_oRequest);
      a_oRequest.setAttribute("actiontype",DataConstants.ACTION_ADD);
    }
    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
  }
}