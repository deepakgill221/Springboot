/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FormulaListSearch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get FormulaListSearch is the Action Class for Getting a list of Formula ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.formulaengine.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class FormulaListSearch extends Action
{
  //private Log log = new Log(FormulaListSearch.class.getName(),Constants.CHM_MODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the FormulaListSearch class
   */
  public FormulaListSearch()
  {

  }

  /**
   * This method uses the search data and to populate Benefit
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    Object formulaResult = null;
    String result =null;
    try{
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);


      String strFormlId   = a_oRequest.getParameter("strFormlId");
      String strFormlDesc = a_oRequest.getParameter("strFormlDesc");

      SearchData oSearchData = new SearchData();
      oSearchData.setTask1(strFormlId);
      oSearchData.setTask2(strFormlDesc);
      formulaResult = oSearchData;
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);
      result = remoteCHMSL.searchFormula(formulaResult);
      log.debug("FormulaListSearch--result accessed");
      setResult(result);
      log.debug("FormulaListSearch--result is set");
    }


    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "P5018");
    }
  }


}