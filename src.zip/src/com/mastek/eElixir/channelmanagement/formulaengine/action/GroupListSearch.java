/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: GroupListSearch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/


/**
 * Get GroupListSearch is the Action Class for Getting a list of Group ,depending upon the
 * search data.
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.formulaengine.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;

public class GroupListSearch extends Action
{
  //private Log log = new Log(GroupListSearch.class.getName(),Constants.CHM_MODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


  /**
   * Constructor of the GroupListSearch class
   */
  public GroupListSearch()
  {

  }

  /**
   * This method uses the search data and to populate Benefit
   * @param a_oRequest HttpServletRequest object.
   * @throws EElixirException
   */
  public void process(HttpServletRequest a_oRequest)  throws EElixirException
  {
    Object groupResult = null;
    String result =null;
    try{
      CHMSL remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);


      String strGroupId   = a_oRequest.getParameter("strGroupId");
      String strGroupDesc = a_oRequest.getParameter("strGroupDesc");

      SearchData oSearchData = new SearchData();
      oSearchData.setTask1(strGroupId);
      oSearchData.setTask2(strGroupDesc);
      groupResult = oSearchData;
      a_oRequest.setAttribute("actiontype", DataConstants.ACTION_ADD);
      result = remoteCHMSL.searchGroup(groupResult);
      log.debug("GroupListSearch--result accessed");
      setResult(result);
      log.debug("GroupListSearch--result is set");
    }


    catch(RemoteException rex)
    {
      throw new EElixirException(rex, "P1006");
    }
    catch(CreateException cex)
    {
      throw new EElixirException(cex, "P1007");
    }
    catch(FinderException fex)
    {
      throw new EElixirException(fex, "P5012");
    }
  }


}