/********************************************************************
*
*  PROJECT			: Amal
*  MODULE NAME		        : Customer Development
*  FILENAME			: UnitPK
*  AUTHOR			: Pallav
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 10, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;
import java.io.Serializable;
/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the Bean which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class UnitProdMixPK implements Serializable
{
 // private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor
   */
  public UnitProdMixPK ()
  {
  }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode    ()
  {
    int iHashcode=0;
    if (_strUnitId != null && _strProdCd != null && _iProdVer != null)
    {
	    iHashcode = _strUnitId.hashCode() + _strProdCd.hashCode() + _iProdVer.hashCode();
    }
    else  if(_strUnitId != null){
      iHashcode= _strUnitId.hashCode();
      //log.debug("HashCode for UnitId:" + iHashcode);
    }
    return iHashcode;

  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * @param obj method is unspecified.
   * @return boolean
   */


  public boolean equals    (Object obj)
  {
    boolean bEqual=false;
/*	if(obj!=null && obj instanceof UnitProdMixPK)
	{
		if (_strUnitId != null && _strProdCd != null && _iProdVer != null)
		{
			bEqual = this._strUnitId.equals(((UnitProdMixPK)obj)._strUnitId) && this._strProdCd.equals(((UnitProdMixPK)obj)._strProdCd) && this._iProdVer.equals(((UnitProdMixPK)obj)._iProdVer); 	    
		}
		if(_strUnitId != null)
		{
		  bEqual = this._strUnitId.equals(((UnitProdMixPK)obj)._strUnitId);
		}
	}Illegal State Exception*/
    return bEqual;
  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public String toString    ()
  {
    return null;
  }

  /**
   *  Method to access the Seq No field
   * @return Character
   */
  public String getUnitId()
  {
    return this._strUnitId;
  }

  /**
   *  Method to set value of the Seq No field
   * @param a_strUnitId String
   *
   */
  public void setUnitId(String a_strUnitId)
  {
    this._strUnitId = a_strUnitId;
  }

  /**
   * Constructor
   * @param a_strUnitId String
   *
   */
	
  public UnitProdMixPK(String a_strUnitId)
  {
    this._strUnitId = a_strUnitId;
  }

  public UnitProdMixPK(String a_strUnitId,String a_strProdCd,Integer a_iProdVer)
  {
	this._strUnitId = a_strUnitId;
	this._strProdCd = a_strProdCd;
	this._iProdVer  = a_iProdVer;
  }

  public void setProdCd(String _strProdCd)
  {
	  this._strProdCd = _strProdCd;
  }

  public String getProdCd()
  {
	  return this._strProdCd;
  }

  public void setProdVer(Integer _iProdVer)
  {
	  this._iProdVer = _iProdVer;
  }

  public Integer getProdVer()
  {
	  return this._iProdVer;
  }
  
  private String _strUnitId;
  private String _strProdCd;
  private Integer _iProdVer;
}