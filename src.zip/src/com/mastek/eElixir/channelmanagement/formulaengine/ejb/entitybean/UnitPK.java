/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: UnitPK.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : october 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;
import java.io.Serializable;
/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the Bean which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class UnitPK implements Serializable
{
 // private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
  /**
   * Constructor
   */
  public UnitPK    ()
  {
  }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode    ()
  {
/*    int iHashcode=0;

	if(_strUnitId != null){
      iHashcode= _strUnitId.hashCode();
    }
    else if(new Long(_lUnitDefnSeqNbr)!= null){
      iHashcode= new Long(_lUnitDefnSeqNbr).hashCode();
    }
Illegal State Exception*/

	int iHashCode = (_strUnitId == null)?0:_strUnitId.hashCode() + new Long(_lUnitDefnSeqNbr).hashCode();
    return iHashCode;
  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * @param obj method is unspecified.
   * @return boolean
   */
  public boolean equals (Object obj)
  {
    boolean bEqual=false;
/*	if(obj!=null && obj instanceof UnitPK)
	{
		  bEqual = this._strUnitId.equals(((UnitPK)obj)._strUnitId);
		
		if(_strUnitId != null){
		  bEqual = this._strUnitId.equals(((UnitPK)obj)._strUnitId);
		}
		else
		{
		  bEqual = this._lUnitDefnSeqNbr  ==  ((UnitPK)obj)._lUnitDefnSeqNbr;
		}
	}Illegal State Exception*/

/*	if(obj != null && obj instanceof UnitPK)
	{
		UnitPK oUnitPK = (UnitPK)obj;
        bEqual = (this._strUnitId != null && this._strUnitId.equals(oUnitPK.getUnitId()) && new Long(this._lUnitDefnSeqNbr).equals(new Long(oUnitPK.getUnitDefnSeqNbr())))?true:false;
	}
*/
    return bEqual;
  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public String toString    ()
  {
    return null;
  }

  /**
   *  Method to access the Seq No field
   * @return Character
   */
  public String getUnitId()
  {
    return this._strUnitId;
  }

  /**
   *  Method to set value of the Seq No field
   * @param a_strUnitId String
   *
   */
  public void setUnitId(String a_strUnitId)
  {
    this._strUnitId = a_strUnitId;
  }

  /**
   * Constructor
   * @param a_strUnitId String
   *
   */

  public UnitPK(String a_strUnitId)
  {
    this._strUnitId = a_strUnitId;
  }


  public long getUnitDefnSeqNbr()
  {
    return this._lUnitDefnSeqNbr;
  }

  /**
   *  Method to set value of the Seq No field
   *
   */
  public void setUnitDefnSeqNbr(long a_lUnitDefnSeqNbr)
  {
    this._lUnitDefnSeqNbr = a_lUnitDefnSeqNbr;
  }

  /**
   * Constructor
   * @param SeqNo long
   */

  public UnitPK (long a_lUnitDefnSeqNbr)
  {
    this._lUnitDefnSeqNbr = a_lUnitDefnSeqNbr;
  }

  private long _lUnitDefnSeqNbr;
  private String _strUnitId;
}