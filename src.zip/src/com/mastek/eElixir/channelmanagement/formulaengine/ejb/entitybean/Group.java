/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: Group.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.formulaengine.util.GroupResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This Group interface provides method for retreving data from the
 * database through primaryKey  </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface Group extends EJBObject
{
  /* This method gets the GroupResult Object
  * @return GroupResult
  */
  public GroupResult getGroupResult() throws RemoteException, EElixirException;

  /* This method sets the GroupResult Object
  * @param a_oGroupResult GroupResult
  */
  public void setGroupResult(GroupResult a_oGroupResult) throws RemoteException, EElixirException;

  /* This method gets the ArrayList Object
  * @return ArrayList
  */
  public ArrayList getGroupResultList() throws RemoteException, EElixirException;

  /* This method sets the ArrayList Object
  * @param a_arrList ArrayList
  */
  public void setGroupResultList(ArrayList a_arrList) throws RemoteException, EElixirException;


}