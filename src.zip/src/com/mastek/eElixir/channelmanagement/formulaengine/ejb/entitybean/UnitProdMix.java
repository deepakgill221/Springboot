/********************************************************************
*
*  PROJECT			: Prudential
*  MODULE NAME      : Channel Management
*  FILENAME			: UnitProdMix
*  AUTHOR			: Pallav
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 10, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitProductMixResult;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This Unit interface provides method for retreving data from the
 * database through primaryKey  </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface UnitProdMix extends EJBObject
{
  /* This method gets the UnitResult Object
  * @return UnitDetail
  */
  public UnitProductMixResult getUnitProdMix() throws  EElixirException,RemoteException;

  /* This method sets the UnitResult Object
  * @param a_oUnitDetail UnitDetail
  */
  public void setUnitProdMix(UnitProductMixResult a_UnitProductMixResult) throws  EElixirException,RemoteException;

  /* This method gets the ArrayList Object
  * @return ArrayList
  */
  public ArrayList getUnitProdMixList() throws  EElixirException,RemoteException;

  /* This method sets the ArrayList Object
  * @param a_arrList ArrayList
  */
  public void setUnitProdMixList(ArrayList a_arrList) throws  EElixirException,RemoteException;


}