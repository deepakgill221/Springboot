/********************************************************************
*
*  PROJECT			: Prudential
*  MODULE NAME	    : Channel Management
*  FILENAME			: UnitProdMixHome
*  AUTHOR			: Pallav
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 10, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitProductMixResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This Unit home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


public interface UnitProdMixHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @throws javax.ejb.FinderException
   * @param upmpk UnitProdMixPK
   * @throws java.rmi.FinderException
   * @throws javax.ejb.EElixirException
   * @return UnitProdMixLocal
   */

  public UnitProdMix findByPrimaryKey   (UnitProdMixPK upmpk)
      throws FinderException,  EElixirException,RemoteException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @return UnitProdMixLocal
   * @throws javax.ejb.CreateException
   * @throws javax.ejb.EElixirException
   */
  public UnitProdMix create() throws CreateException,  EElixirException,RemoteException;


  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class
   * @param a_oUnitProductMix UnitProductMix
   * @throws javax.ejb.CreateException
   * @throws javax.ejb.EElixirException
   * @return UnitProdMixLocal
   */
  public UnitProdMix create(UnitProductMixResult a_oUnitProductMixResult) throws CreateException, EElixirException,RemoteException;


}