/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: GroupPK.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : october 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;
import java.io.Serializable;

/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the Bean which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class GroupPK implements Serializable
{

  /**
   * Constructor
   */
  public GroupPK    ()
  {
  }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode    ()
  {

/*    int iHashcode=0;
    if(_strGroupId != null){
      iHashcode= _strGroupId.hashCode();
    }
    else if(new Long(_lCritDefnSeqNbr)!= null){
      iHashcode= new Long(_lCritDefnSeqNbr).hashCode();
    }
Illegal State Exception*/
	int iHashCode = (_strGroupId == null)?0:_strGroupId.hashCode() + new Long(_lCritDefnSeqNbr).hashCode();
    return iHashCode;


  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * @param obj method is unspecified.
   * @return boolean
   */
  public boolean equals    (Object obj)
  {

    boolean bEqual=false;

/*	if(obj!=null && obj instanceof GroupPK)
	{
		 if(_strGroupId != null){
		   bEqual = this._strGroupId.equals(((GroupPK)obj)._strGroupId);
		 }
		 else
		 {
		   bEqual = this._lCritDefnSeqNbr  ==  ((GroupPK)obj)._lCritDefnSeqNbr;
		 }
	}Illegal State Exception*/
    return bEqual;
  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public String toString    ()
  {
    return null;
  }

  /**
   *  Method to access the Seq No field
   * @return Character
   */
  public String getGroupId()
  {
    return this._strGroupId;
  }

  /**
   *  Method to set value of the Seq No field
   * @param a_strGroupId String
   *
   */
  public void setGroupId(String a_strGroupId)
  {
    this._strGroupId = a_strGroupId;
  }

  /**
   * Constructor
   * @param a_strGroupId String
   *
   */

  public GroupPK(String a_strGroupId)
  {
    this._strGroupId = a_strGroupId;
  }


  public long getCritDefnSeqNbr()
  {
    return this._lCritDefnSeqNbr;
  }

  /**
   *  Method to set value of the Seq No field
   *
   */
  public void setCritDefnSeqNbr(long a_lCritDefnSeqNbr)
  {
    this._lCritDefnSeqNbr = a_lCritDefnSeqNbr;
  }

  /**
   * Constructor
   * @param SeqNo long
   */

  public GroupPK    (long a_lCritDefnSeqNbr)
  {
    this._lCritDefnSeqNbr = a_lCritDefnSeqNbr;
  }

  private long _lCritDefnSeqNbr;
  private String _strGroupId;



}