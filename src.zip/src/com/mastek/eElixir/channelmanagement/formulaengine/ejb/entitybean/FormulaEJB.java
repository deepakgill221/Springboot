/********************************************************************
 *
 *  PROJECT			: PRUDENTIAL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME			: FormulaEJB.java
 *  AUTHOR			: Pallav Laddha
 *  VERSION			: 1.0
 *  CREATION DATE	        : October 20, 2002
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.formulaengine.dax.FormulaEngineDAX;
import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;



/**
 * <p>Title: eElixir</p>
 * <p>Description: This Formula Entity bean retrive data from the database according to seach condition</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class FormulaEJB implements EntityBean
{
  /**
   * Attributes declaration
   */
  private EntityContext _oContext;
  private Connection _oConnection = null;
  private DataSource _oDatasource = null;
  private FormulaEngineDAX  _oFormulaEngineDAX;
  private FormulaResult _oFormulaResult;
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


  /**
   * Constructor for FormulaEJB class
   */
  public FormulaEJB    ()
  {

  }

  /**
   * Matching method of the create() method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @return FormulaPK
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.FormulaPK ejbCreate    () throws CreateException, EElixirException
  {
    FormulaPK bpk = new FormulaPK();

    return bpk;

  }

  /**
   * Matching method of the create(FormulaResult a_oFormulaResult) method of the bean's home interface. The container
   * invokes an ejbCreate method to create an entity object. It executes in the transaction
   * context determined by the transactionattribute of the matching create() method.
   * @param  a_oFormulaResult FormulaResult
   * @return FormulaPK
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public FormulaPK ejbCreate   (FormulaResult a_oFormulaResult) throws CreateException, EElixirException
  {
    FormulaPK fpk = null;
    try{
      _oFormulaEngineDAX = getDAX();
      log.debug("FormulaEJB--before getFormula method of dax object");
      long lbenseqnbr = _oFormulaEngineDAX.createFormula(a_oFormulaResult);
      log.debug("FormulaEJB-------------------------the value obained in Entity bean is ---"+ lbenseqnbr);
      fpk = new FormulaPK();
      fpk.setFormlDefnSeqNbr(lbenseqnbr);
      log.debug("FormulaEJB--Key in entiy bean is " + fpk.getFormlDefnSeqNbr());
      log.debug("FormulaEJB--after getFormula method of dax object");
      //DBConnection.closeConnection(_oConnection);
    }
    catch(EElixirException eex)
    {
      throw eex;
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex, "P1005");
      }
    }
    log.debug("FormulaEJB--Key in entiy bean is again " + fpk.getFormlDefnSeqNbr());
    return fpk;
  }

  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate    () throws CreateException, EElixirException
  {

  }


  /**
   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
   * on an instance after it invokes the ejbCreate method with the same arguments. It
   * executes in the same transaction context as that of the matching ejbCreate method.
   * @param a_oFormulaResult FormulaResult
   * @throws javax.ejb.CreateException
   * @throws EElixirException
   */
  public void ejbPostCreate    (FormulaResult a_oFormulaResult) throws CreateException, EElixirException
  {

  }

  /**
   * A container invokes this method when the instance is taken out of the pool of available
   * instances to become associated with a specific EJB object. This method transitions
   * the instance to the ready state. This method executes in an unspecified transaction
   * context.
   */
  public void ejbActivate    ()
  {

  }

  /**
   * A container invokes this method on an instance before the instance becomes disassociated
   * with a specific EJB object. After this method completes, the container will place
   * the instance into the pool of available instances. This method executes in an unspecified
   * transaction context.
   */
  public void ejbPassivate    ()
  {

  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by loading it from the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbLoad    ()
  {
    log.debug("FormulaEJB--ejbLoad() fired");
    FormulaPK fPK = (FormulaPK)_oContext.getPrimaryKey();
    try
    {
      _oFormulaResult = new  FormulaResult();
      _oFormulaEngineDAX = (FormulaEngineDAX)getDAX();
      log.debug("FormulaEJB--Before Calling getApplication on FormulaDAX");
      _oFormulaResult = _oFormulaEngineDAX.getFormula(fPK.getFormlDefnSeqNbr());
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eex)
      {
        throw new EJBException(eex);
      }
    }
  }

  /**
   * A container invokes this method to instruct the instance to synchronize its state
   * by storing it to the underlying database. This method always executes in the transaction
   * context determined by the value of the transaction attribute in the deployment descriptor.
   */
  public void ejbStore    ()
  {
    log.debug("FormulaEJB--ejbStore() fired");
	/* CHANGE TO AVOID UPDATE  */
    if(this._oFormulaResult != null && this._oFormulaResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
    {
    try
      {
      _oFormulaEngineDAX = (FormulaEngineDAX)getDAX();
        _oFormulaEngineDAX.updateFormula(_oFormulaResult);
      }
      catch(EElixirException ex)
      {
        throw new EJBException(ex);
      }
      finally
      {
        try
        {
          if(_oConnection != null)
            DBConnection.closeConnection(_oConnection);
        }
        catch(EElixirException eex)
        {
          throw new EJBException(eex);
        }
      }
    }
  }

  /**
   * A container invokes this method before it removes the EJB object that is currently
   * associated with the instance. It is invoked when a client invokes a remove operation
   * on the enterprise Bean's home or remote interface. It transitions the instance from
   * the ready state to the pool of available instances. It is called in the transaction
   * context of the remove operation.
   * @throws javax.ejb.RemoveException
   */
  public void ejbRemove    ()
  {
    /* Currently commented since Remove functionality is not present for Formula
    log.debug("FormulaEJB--ejbRemove() fired");
    try
    {
      FormulaEngineDAX oFormulaEngineDAX = getDAX();
      oFormulaEngineDAX.removeFormula(((FormulaPK)(_oContext.getPrimaryKey())).getBenSeqNbr());
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally
    {
      try
      {
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eex)
      {
        throw new EJBException(eex);
      }
    }
    */
  }

  /**
   * Set the associated entity context. The container invokes this method on an instance
   * after the instance has been created. This method is called in an unspecified transaction
   * context.
   * @param ctx EntityContext
   */
  public void setEntityContext    (EntityContext ctx)
  {
    _oContext = ctx;
  }

  /**
   * Unset the associated entity context. The container calls this method before removing
   * the instance. This is the last method that the container invokes on the instance.
   * The Java garbage collector will  invoke the finalize() method on the instance. It
   * is called in an unspecified transaction context.
   */
  public void unsetEntityContext    ()
  {
    _oContext = null;
  }

  /**
   * Invoked by the container on the instance when the container selects the instance to
   * execute a matching client-invoked find() method. It executes in the transaction
   * context determined by the transaction attribute of the matching find() method.
   * @param a_FormulaPK FormulaPK
   * @return FormulaPK
   * @throws javax.ejb.FinderException
   * @throws EElixirException
   */
  public FormulaPK ejbFindByPrimaryKey    (FormulaPK a_FormulaPK) throws FinderException,EElixirException
  {
    try{
      log.debug("FormulaEJB--Inside Findby primary key of FormulaEJB");
      _oFormulaEngineDAX = getDAX();
      log.debug("FormulaEJB--Inside Find by primary key " + a_FormulaPK.getFormlDefnSeqNbr() + "");
      boolean bFlag = _oFormulaEngineDAX.findFormula(a_FormulaPK.getFormlDefnSeqNbr());
      log.debug("FormulaEJB--After find Formula");
      if(bFlag){
        log.debug("FormulaEJB--Returning Formula Primary Key");
        return a_FormulaPK;
      }
      else
        throw new EElixirException("P5018"); // to be decided
    }
    catch(EElixirException eex)
    {
      throw new EJBException(eex);
    }
    finally{
      try{
        if(_oConnection != null)
          DBConnection.closeConnection(_oConnection);
      }
      catch(EElixirException eElex){
        throw new EElixirException(eElex,"P1005");
      }
    }
  }


/**
 * Gets the Dax object and sets the connection on it.
 * @return FormulaDAX
 * @throws EElixirException
 */
  private FormulaEngineDAX getDAX() throws EElixirException
  {
    _oConnection = DBConnection.getConnection();
    CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
    FormulaEngineDAX _oFormulaEngineDAX = (FormulaEngineDAX)theDAXFactory.createDAX(theDAXFactory.FORMULAENGINEDAX);
    _oFormulaEngineDAX.setConnection(_oConnection);

    return _oFormulaEngineDAX;
  }


  public FormulaResult getFormulaResult() throws  EElixirException
  {
    return _oFormulaResult;
  }

  public void setFormulaResult(FormulaResult a_oFormulaResult) throws  EElixirException
  {
    this._oFormulaResult = a_oFormulaResult;
  }


}