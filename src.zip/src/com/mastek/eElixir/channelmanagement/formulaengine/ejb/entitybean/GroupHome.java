/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: GroupHome.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.formulaengine.util.GroupResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 * <p>Title: eElixir</p>
 * <p>Description:This Group home interface provides one create method & find by primary key
 * Called by the client to create/find an EJB bean instance, usually find by primary key</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


public interface GroupHome extends EJBHome
{
  /**
   * Called by the client to find an EJB bean instance, usually find by primary key
   * @throws javax.ejb.FinderException
   * @param upk GroupPK
   * @throws java.rmi.RemoteException
   * @throws java.rmi.FinderException
   * @throws javax.ejb.EElixirException
   * @return Group
   */

  public Group findByPrimaryKey   (GroupPK upk)
      throws FinderException, RemoteException, EElixirException;

  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class, i.e. ejbCreate().
   * @return Group
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   * @throws javax.ejb.EElixirException
   */
  public Group create() throws CreateException, RemoteException, EElixirException;


  /**
   * Called by the client to create an EJB bean instance. It requires a matching pair in
   * the bean class
   * @param a_oGroupResult GroupResult
   * @throws java.rmi.RemoteException
   * @throws javax.ejb.CreateException
   * @throws javax.ejb.EElixirException
   * @return Group
   */
  public Group create(GroupResult a_oGroupResult) throws CreateException, RemoteException, EElixirException;


}