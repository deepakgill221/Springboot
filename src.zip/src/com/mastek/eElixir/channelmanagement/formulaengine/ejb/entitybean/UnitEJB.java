/********************************************************************
 *
 *  PROJECT                        : PRUDENTIAL
 *  MODULE NAME                    : CHANNEL MANAGEMENT
 *  FILENAME                       : UnitEJB.java
 *  AUTHOR                         : Pallav Laddha
 *  VERSION                        : 1.0
 *  CREATION DATE                  : October 20, 2002
 *  COMPANY                        : Mastek Ltd.
 *  COPYRIGHT                      : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION  DATE        BY        REASON
 *--------------------------------------------------------------------------------
 * 2.1      26-09-2003  Dipti F   UT Rework
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;

import java.sql.Connection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.formulaengine.dax.FormulaEngineDAX;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitResult;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;


/**
 * <p>Title: eElixir</p>
 * <p>Description: This Unit Entity bean retrive data from the database according to seach condition</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class UnitEJB implements EntityBean
{
    /**
     * Attributes declaration
     */
    private EntityContext _oContext;
    private Connection _oConnection = null;
    private DataSource _oDatasource = null;
    private FormulaEngineDAX _oFormulaEngineDAX;
    private UnitResult _oUnitResult;
    private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);
    private ArrayList _arrUnit;

    /**
     * Constructor for BenefitEJB class
     */
    public UnitEJB()
    {
    }

    /**
     * Matching method of the create() method of the bean's home interface. The container
     * invokes an ejbCreate method to create an entity object. It executes in the transaction
     * context determined by the transactionattribute of the matching create() method.
     * @return UnitPK
     * @throws CreateException
     * @throws EElixirException
     */
    public UnitPK ejbCreate() throws CreateException, EElixirException
    {
        UnitPK bpk = new UnitPK();
        return bpk;
    }

    /**
     * Matching method of the create(UnitResult a_oUnitResult) method of the bean's home interface. The container
     * invokes an ejbCreate method to create an entity object. It executes in the transaction
     * context determined by the transactionattribute of the matching create() method.
     * @param  a_oUnitResult UnitResult
     * @return UnitPK
     * @throws javax.ejb.CreateException
     * @throws EElixirException
     */
    public UnitPK ejbCreate(UnitResult a_oUnitResult)
        throws CreateException, EElixirException
    {
        UnitPK upk = null;

        try
        {
            _oFormulaEngineDAX = getDAX();
            log.debug("UnitEJB--before getUnit method of dax object");

            String a_strUnitId = _oFormulaEngineDAX.createUnit(a_oUnitResult);
            log.debug("UnitEJB--after getUnit method of dax object");

			this._oUnitResult = a_oUnitResult;

            //upk = new UnitPK(a_oUnitResult.getUnitId());
            upk = new UnitPK(a_strUnitId);
			
            //cpk.setBenSeqNbr(lbenseqnbr);
            //log.debug("UnitEJB--Key in entiy bean is " + bpk.getBenSeqNbr());
            //DBConnection.closeConnection(_oConnection);
        }
        catch (EElixirException eex)
        {
            throw eex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }

        return upk; 
    }

    /**
     * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
     * on an instance after it invokes the ejbCreate method with the same arguments. It
     * executes in the same transaction context as that of the matching ejbCreate method.
     * @throws javax.ejb.CreateException
     * @throws EElixirException
     */
    public void ejbPostCreate() throws CreateException, EElixirException
    {
    }

    /**
     * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
     * on an instance after it invokes the ejbCreate method with the same arguments. It
     * executes in the same transaction context as that of the matching ejbCreate method.
     * @param a_oUnitResult UnitResult
     * @throws javax.ejb.CreateException
     * @throws EElixirException
     */
    public void ejbPostCreate(UnitResult a_oUnitResult)
        throws CreateException, EElixirException
    {
    }

    /**
     * A container invokes this method when the instance is taken out of the pool of available
     * instances to become associated with a specific EJB object. This method transitions
     * the instance to the ready state. This method executes in an unspecified transaction
     * context.
     */
    public void ejbActivate()
    {
    }

    /**
     * A container invokes this method on an instance before the instance becomes disassociated
     * with a specific EJB object. After this method completes, the container will place
     * the instance into the pool of available instances. This method executes in an unspecified
     * transaction context.
     */
    public void ejbPassivate()
    {
    }

    /**
     * A container invokes this method to instruct the instance to synchronize its state
     * by loading it from the underlying database. This method always executes in the transaction
     * context determined by the value of the transaction attribute in the deployment descriptor.
     */
    public void ejbLoad()
    {
        log.debug("UnitEJB--ejbLoad() fired");

        UnitPK unitPK = (UnitPK) _oContext.getPrimaryKey();

        try
        {
            //_oUnitResult = new  UnitResult();
            _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
            log.debug("UnitEJB--Before Calling getUnit on FormulaEngineDAX");

            if (unitPK.getUnitId() != null)
            {
                log.debug("UnitEJB-- Inside load for unitid");
                _arrUnit = _oFormulaEngineDAX.getUnit(unitPK.getUnitId());
            }
            else
            {
                log.debug("UnitEJB-- Inside load for seqNo");
                _oUnitResult = _oFormulaEngineDAX.getUnit(unitPK.getUnitDefnSeqNbr());
            }
        }
        catch (EElixirException eex)
        {
            throw new EJBException(eex);
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eex)
            {
                throw new EJBException(eex);
            }
        }
    }

    /**
     * A container invokes this method to instruct the instance to synchronize its state
     * by storing it to the underlying database. This method always executes in the transaction
     * context determined by the value of the transaction attribute in the deployment descriptor.
     */
    public void ejbStore()
    {
        log.debug("UnitEJB--ejbStore() fired");

        /* CHANGE TO AVOID UPDATE  */
        if ((this._oUnitResult != null) &&
                this._oUnitResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
        {
            try
            {
                log.debug("UnitEJB--inside ejbStore");
                _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
                log.debug("UnitEJB--after getting dax" + _oUnitResult);
                _oFormulaEngineDAX.updateUnit(_oUnitResult);
                log.debug("UnitEJB--After updating unit");
            }
            catch (EElixirException ex)
            {
                throw new EJBException(ex);
            }
            finally
            {
                try
                {
                    if (_oConnection != null)
                    {
                        DBConnection.closeConnection(_oConnection);
                    }
                }
                catch (EElixirException eex)
                {
                    throw new EJBException(eex);
                }
            }
        }
    }

    /**
     * A container invokes this method before it removes the EJB object that is currently
     * associated with the instance. It is invoked when a client invokes a remove operation
     * on the enterprise Bean's home or remote interface. It transitions the instance from
     * the ready state to the pool of available instances. It is called in the transaction
     * context of the remove operation.
     * @throws javax.ejb.RemoveException
     */
    public void ejbRemove()
    {
        log.debug("UnitEJB--ejbRemove() fired");

        try
        {
            _oFormulaEngineDAX = getDAX();
            _oFormulaEngineDAX.removeUnit(((UnitPK) (_oContext.getPrimaryKey())).getUnitDefnSeqNbr());
        }
        catch (EElixirException eex)
        {
            throw new EJBException(eex);
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eex)
            {
                throw new EJBException(eex);
            }
        }
    }

    /**
     * Set the associated entity context. The container invokes this method on an instance
     * after the instance has been created. This method is called in an unspecified transaction
     * context.
     * @param ctx EntityContext
     */
    public void setEntityContext(EntityContext ctx)
    {
        _oContext = ctx;
    }

    /**
     * Unset the associated entity context. The container calls this method before removing
     * the instance. This is the last method that the container invokes on the instance.
     * The Java garbage collector will  invoke the finalize() method on the instance. It
     * is called in an unspecified transaction context.
     */
    public void unsetEntityContext()
    {
        _oContext = null;
    }

    /**
     * Invoked by the container on the instance when the container selects the instance to
     * execute a matching client-invoked find() method. It executes in the transaction
     * context determined by the transaction attribute of the matching find() method.
     * @return UnitPK
     * @param a_UnitPK UnitPK
     * @throws javax.ejb.FinderException
     * @throws EElixirException
     */
    public UnitPK ejbFindByPrimaryKey(UnitPK a_UnitPK)
        throws FinderException, EElixirException
    {
        try
        {
            log.debug("UnitEJB--Inside Findby primary key of UnitEJB");
            _oFormulaEngineDAX = getDAX();
            log.debug("UnitEJB--Inside Find by primary key " +
                a_UnitPK.getUnitId() + "");

            if (a_UnitPK.getUnitId() != null)
            {
                boolean bFlag = _oFormulaEngineDAX.findUnit(a_UnitPK.getUnitId());
                log.debug("UnitEJB--After find unit");

                if (bFlag)
                {
                    log.debug("UnitEJB--Returning Unit Primary Key");

                    return a_UnitPK;
                }
                else
                {
                    throw new EElixirException("P5005"); // to be decided
                }
            }
            else
            {
                boolean bFlag = _oFormulaEngineDAX.findUnit(a_UnitPK.getUnitDefnSeqNbr());
                log.debug("UnitEJB--After find Unit of Seq No" +
                    a_UnitPK.getUnitDefnSeqNbr());

                if (bFlag)
                {
                    log.debug("UnitEJB--Returning Unit Primary Key");

                    return a_UnitPK;
                }
                else
                {
                    throw new EElixirException("P5006"); // to be decided
                }
            }
        }
        catch (EElixirException eex)
        {
            throw new EJBException(eex);
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }
    }

    /**
    * Gets the Dax object and sets the connection on it.
    * @return FormulaEngineDAX
    * @throws EElixirException
    */
    private FormulaEngineDAX getDAX() throws EElixirException
    {
        _oConnection = DBConnection.getConnection();

        CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        FormulaEngineDAX _oFormulaEngineDAX = (FormulaEngineDAX) theDAXFactory.createDAX(theDAXFactory.FORMULAENGINEDAX);
        _oFormulaEngineDAX.setConnection(_oConnection);

        return _oFormulaEngineDAX;
    }

    public ArrayList getUnitResultList() throws EElixirException
    {
        return _arrUnit;
    }

    public void setUnitResultList(ArrayList a_arrUnit)
        throws EElixirException
    {
        this._arrUnit = a_arrUnit;
    }

    public UnitResult getUnitResult() throws EElixirException
    {
        return _oUnitResult;
    }

    public void setUnitResult(UnitResult a_oUnitResult)
        throws EElixirException
    {
        this._oUnitResult = a_oUnitResult;
    }
}
