/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FormulaPK.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : october 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean;
import java.io.Serializable;

/**
 * <p>Title: eElixir</p>
 * <p>Description:This primary key class is for the FormulaBean which contains get & set
 *  methods for the primary key field Seq No</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class FormulaPK implements Serializable
{

  /**
   * Constructor
   */
  public FormulaPK    ()
  {
  }

  /**
   * Referencing to object that represents the entity object.
   * @return integer value
   */
  public int hashCode    ()
  {
    int iHashcode=0;
    if(new Long(_lFormlDefnSeqNbr)!= null)
    iHashcode= new Long(_lFormlDefnSeqNbr).hashCode();
    return iHashcode;

  }

  /**
   * Method that compares two entity object references -- since the Java Object.equals(Object
   * @param obj method is unspecified.
   * @return boolean
   */
  public boolean equals (Object obj)
  {
    boolean bEqual=false;
	if(obj!=null && obj instanceof FormulaPK)
	{
		if (this._lFormlDefnSeqNbr  ==  ((FormulaPK)obj)._lFormlDefnSeqNbr)
		{
		  bEqual = true;
		}
	}
    return bEqual;

  }

  /**
   * Own toString() method of a bean's PK class.
   * @return String
   */
  public String toString    ()
  {
    return null;
  }

  /**
   *  Method to access the Seq No field
   * @return long
   *
   */
  public long getFormlDefnSeqNbr()
  {
    return this._lFormlDefnSeqNbr;
  }

  /**
   *  Method to set value of the Seq No field
   * @param a_lFormlDefnSeqNbr long
   *
   */
  public void setFormlDefnSeqNbr(long a_lFormlDefnSeqNbr)
  {
    this._lFormlDefnSeqNbr = a_lFormlDefnSeqNbr;
  }

  /**
   * Constructor
   * @param a_lFormlDefnSeqNbr long
   */

  public FormulaPK    (long a_lFormlDefnSeqNbr)
  {
    this._lFormlDefnSeqNbr = a_lFormlDefnSeqNbr;
  }

  private long _lFormlDefnSeqNbr;


}