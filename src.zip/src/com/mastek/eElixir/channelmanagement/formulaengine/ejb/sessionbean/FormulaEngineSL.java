/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FormulaEngineSL.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : September 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;

import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitResultMain;
import com.mastek.eElixir.common.exception.EElixirException;

/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This FormulaEngineSL Local interface provides method for getting the data from FormulaEngine bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */



public interface FormulaEngineSL extends EJBObject
{
  /**
   * Gets the data based on the parameter of DVO
   * @param a_oResultObject Object
   * @return String XML format string object
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public String searchUnit(Object a_oResultObject) throws EElixirException , FinderException , RemoteException;
  /**
   * Gets the Data depending on the Unit id
   * @param a_strUnitId String
   * @return ArrayList
   * @throws FinderException
   * @throws EElixirException
   * @throws RemoteException
   */
  public UnitResultMain searchUnit(String a_strUnitId) throws  FinderException,EElixirException, RemoteException;
  /**
   * Creates the Data from the CHMSLEJB
   * @param a_arrUnit ArrayList
   * @throws EJBException
   * @throws EElixirException
   * @throws RemoteException
   */
  public String createUnit(UnitResultMain oUnitResultMain) throws  EJBException, EElixirException , RemoteException;
  /**
   * Creates the Data from the CHMSLEJB
   * @param a_arrUnit ArrayList
   * @throws EJBException
   * @throws EElixirException
   * @throws RemoteException
   */
  public void updateUnit(UnitResultMain oUnitResultMain) throws  EJBException, EElixirException , RemoteException;
  /**
   * Gets the data based on the parameter of DVO
   * @param a_oResultObject Object
   * @return String XML format string object
   * @throws EElixirException
   * @throws FinderException
   * @throws RemoteException
   */
  public String searchGroup(Object a_oResultObject) throws EElixirException , FinderException , RemoteException;
  /**
    * Gets the Data depending on the Group id
    * @param a_strGroupId String
    * @return ArrayList
    * @throws FinderException
    * @throws EElixirException
    * @throws RemoteException
    */
   public ArrayList searchGroup(String a_strGroupId) throws  FinderException,EElixirException, RemoteException;
   /**
    * Creates the Data from the CHMSLEJB
    * @param a_arrGroup ArrayList
    * @throws EJBException
    * @throws EElixirException
    * @throws RemoteException
    */
  public String createGroup(ArrayList a_arrGroup) throws  EJBException, EElixirException , RemoteException;
  /**
   * Creates the Data from the CHMSLEJB
   * @param a_arrGroup ArrayList
   * @throws EJBException
   * @throws EElixirException
   * @throws RemoteException
   */
  public void updateGroup(ArrayList a_arrGroup) throws  EJBException, EElixirException, RemoteException;
   /**
    * Gets the data based on the parameter of DVO
    * @param a_oResultObject Object
    * @return String XML format string object
    * @throws EElixirException
    * @throws FinderException
    * @throws RemoteException
    */
   public String searchFormula(Object a_oResultObject) throws EElixirException , FinderException , RemoteException;
   /**
    * Gets the Data depending on the Formula seqno
    * @param a_lFormlDefnSeqNbr long
    * @return FormulaResult
    * @throws FinderException
    * @throws EElixirException
    * @throws RemoteException
    */
   public FormulaResult searchFormula(long a_lFormlDefnSeqNbr) throws  FinderException,EElixirException, RemoteException;
   /**
    * Creates the Data from the CHMSLEJB
    * @param a_oFormulaResult FormulaResult
    * @return long
    * @throws EJBException
    * @throws EElixirException
    * @throws RemoteException
    */
  public long createFormula(FormulaResult a_oFormulaResult) throws  EJBException, EElixirException , RemoteException;
  /**
   * Updates/Insert/Deletes data into Formula hdr and its associated calc and elgble table
   * @param a_oFormulaResult FormulaResult
   * @throws FinderException
   * @throws EElixirException
   * @throws RemoteException
   */
  public void updateFormula(FormulaResult a_oFormulaResult) throws FinderException,EElixirException, RemoteException;

}