/********************************************************************
*
*  PROJECT                        : PRUDENTIAL
*  MODULE NAME                    : CHANNEL MANAGEMENT
*  FILENAME                       : FormulaEngineSLEJB.java
*  AUTHOR                         : Pallav Laddha
*  VERSION                        : 1.0
*  CREATION DATE                  : September 20, 2002
*  COMPANY                        : Mastek Ltd.
*  COPYRIGHT                      : COPYRIGHT (C) 2002.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION  DATE        BY        REASON
*--------------------------------------------------------------------------------
* 2.1      26-09-2003  Dipti F   UT Rework
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.mastek.eElixir.channelmanagement.formulaengine.dax.FormulaEngineDAX;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.Formula;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.FormulaHome;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.FormulaPK;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.Group;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.GroupHome;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.GroupPK;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.Unit;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.UnitHome;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.UnitPK;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.UnitProdMix;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.UnitProdMixHome;
import com.mastek.eElixir.channelmanagement.formulaengine.ejb.entitybean.UnitProdMixPK;
import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaCalculationResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaEligibilityCriteriaResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.GroupResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitProductMixResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitResultMain;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;


/**
 * <p>Title: eElixir</p>
 * <p>Description: This FormulaEngineSLEJB session bean acts as an interface for the FormulaEngine Entity bean</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */
public class FormulaEngineSLEJB implements SessionBean
{
    /**
     * Attributes declaration
     */
    private Connection _oConnection = null;
    private FormulaEngineDAX _oFormulaEngineDAX;
    private String _strCon;
    public SessionContext _EJBContext = null;
    public UnitHome _oUnitHome;
    private Unit _oUnit;
    public UnitProdMixHome _oUnitProdMixHome;
    private UnitProdMix _oUnitProdMix;
    public GroupHome _oGroupHome;
    private Group _oGroup;
    public FormulaHome _oFormulaHome;
    private Formula _oFormula;

    //private Log log = new Log(FormulaEngineSLEJB.class.getName(),Constants.CHM_MODULE);
    private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor of the FormulaEngineSLEJB class
     */
    public FormulaEngineSLEJB()
    {
    }

    /**
     * Called by the container to create a session bean instance. Its parameters typically
     * contain the information the client uses to customize the bean instance for its use.
     * It requires a matching pair in the bean class and its home interface.
     * @throws CreateException
     * @throws EElixirException
     */
    public void ejbCreate() throws CreateException, EElixirException
    {
    }

    /**
     * A container invokes this method before it ends the life of the session object. This
     * happens as a result of a client's invoking a remove operation, or when a container
     * decides to terminate the session object after a timeout. This method is called with
     * no transaction context.
     */
    public void ejbRemove()
    {
    }

    /**
     * The activate method is called when the instance is activated from its 'passive' state.
     * The instance should acquire any resource that it has released earlier in the ejbPassivate()
     * method. This method is called with no transaction context.
     */
    public void ejbActivate()
    {
    }

    /**
     * The passivate method is called before the instance enters the 'passive' state. The
     * instance should release any resources that it can re-acquire later in the ejbActivate()
     * method. After the passivate method completes, the instance must be in a state that
     * allows the container to use the Java Serialization protocol to externalize and store
     * away the instance's state. This method is called with no transaction context.
     */
    public void ejbPassivate()
    {
    }

    /**
     * Set the associated session context. The container calls this method after the instance
     * creation. The enterprise Bean instance should store the reference to the context
     * object in an instance variable. This method is called with no transaction context.
     * @param sc SessionContext
     */
    public void setSessionContext(SessionContext sc)
    {
        this._EJBContext = sc;
    }

    /**
     * Gets the data based on the parameter of DVO
     * @param a_oResultObject Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     */
    public String searchUnit(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        try
        {
            _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
            log.debug("FormulaEngineSLEJB--before getUnit method of dax object");
            _strCon = _oFormulaEngineDAX.getUnit(a_oResultObject);
            log.debug("FormulaEngineSLEJB--after getUnit method of dax object");

            //DBConnection.closeConnection(_oConnection);
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();

            Exception e = ejbex.getCausedByException();

            if (e instanceof EElixirException)
            {
                throw (EElixirException) e;
            }
            else
            {
                throw ejbex;
            }
        }
        catch (EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }

        log.debug(_strCon);

        return _strCon;
    }

    /**
     * Gets the Data depending on the Unit id
     * @param a_strUnitId String
     * @return ArrayList
     * @throws FinderException
     * @throws EElixirException
     */
    public UnitResultMain searchUnit(String a_strUnitId)
        throws FinderException, EElixirException
    {
        UnitResultMain oUnitResultMain = new UnitResultMain();
        ArrayList arrUnitResult = null;
        ArrayList arrProdMixResult = null;

        try
        {
            log.debug("FormulaEngineSLEJB--Before getting home");
            _oUnitHome = getUnitHome();
            _oUnitProdMixHome = getUnitProdMixHome();
            log.debug("FormulaEngineSLEJB--After getting home");

            UnitPK oUnitPK = new UnitPK(a_strUnitId);
            UnitProdMixPK oUnitProdMixPK = new UnitProdMixPK(a_strUnitId);

            //oUnitPK.setUnitId();
            log.debug("FormulaEngineSLEJB--oUnitPK.getUnitId():" +
                oUnitPK.getUnitId());
            log.debug("FormulaEngineSLEJB--After setting unitId");
            _oUnit = _oUnitHome.findByPrimaryKey(oUnitPK);
            _oUnitProdMix = _oUnitProdMixHome.findByPrimaryKey(oUnitProdMixPK);
            log.debug("FormulaEngineSLEJB--Getting Result from Unit Bean");
            arrUnitResult = _oUnit.getUnitResultList();
            arrProdMixResult = _oUnitProdMix.getUnitProdMixList();
            oUnitResultMain.setArrUnitDetail(arrUnitResult);
            oUnitResultMain.setArrUnitProductMix(arrProdMixResult);
        }
        catch (FinderException fe)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--FinderException " + fe);
            throw new EElixirException(fe, "P5005");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--RemoteEXception " + rex);
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--EJBException " + ejbex);
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--EElixirException " + eex);
            throw eex;
        }

        return oUnitResultMain;
    }

    /**
     * Validates a unit, checks to see if        unique key constraint is validated or not.
     * @param a_arrUnit ArrayList
     * @return boolean
     * @throws EElixirException
     * @throws FinderException
     */
    public boolean unitPresent(ArrayList a_arrUnit)
        throws EElixirException, FinderException
    {
        boolean isUnitPresent = false;

        try
        {
            if (a_arrUnit != null)
            {
            	_oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
                for (int i = 0; i < a_arrUnit.size(); i++)
                {
                    log.debug(
                        "FormulaEngineSLEJB--before	findUnit	method of dax object");
                    isUnitPresent = _oFormulaEngineDAX.findUnit(((UnitResult) a_arrUnit.get(
                                i)).getUnitId());
                    log.debug(
                        "FormulaEngineSLEJB--after findUnit method of dax object");

                    break;

                    //DBConnection.closeConnection(_oConnection);
                }
            }
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            throw eex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }

        return isUnitPresent;
    }

    /**
     * Creates the Data from the CHMSLEJB
     * @param a_arrUnit ArrayList
     * @throws EJBException
     * @throws EElixirException
     */
    public String createUnit(UnitResultMain oUnitResultMain)
        throws EJBException, EElixirException
    {
        log.debug("FormulaEngineSLEJB--In create Unit of FormulaEngineSLEJB");

        ArrayList a_arrUnit = oUnitResultMain.getArrUnitDetail();
        ArrayList a_arrProductMix = oUnitResultMain.getArrUnitProductMix();
		UnitResult oUnitResult = null;
        try
        {
            /*  if(unitPresent(a_arrUnit)){
                    log.debug("FormulaEngineSLEJB--before throwing exception");
                    throw new EElixirException("P5027");  //Throw Unique constraint        violated message
              }*/
            log.debug("FormulaEngineSLEJB--Before Lookup of entity bean");
			 _oUnitHome = getUnitHome();
            _oUnitProdMixHome = getUnitProdMixHome();

            log.debug("FormulaEngineSLEJB--After Lookup");
            _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();

            String strUnitId = _oFormulaEngineDAX.getNextUnitId();
            log.debug("FormulaEngineSLEJB--got new seq nbr " + strUnitId);

            if (a_arrUnit != null)
            {
                log.debug(
                    "FormulaEngineSLEJB--before getUnit method of dax object");

                for (int i = 0; i < a_arrUnit.size(); i++)
                {
                    oUnitResult = (UnitResult) a_arrUnit.get(i);
                    oUnitResult.setUnitId(strUnitId);
                    _oUnit = _oUnitHome.create(oUnitResult);
                }
            }

            //for product mix
            if (a_arrProductMix != null)
            {
               // _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
                log.debug(
                    "FormulaEngineSLEJB--before create method of entity bean");

                for (int i = 0; i < a_arrProductMix.size(); i++)
                {
                    UnitProductMixResult oUnitProductMixResult = (UnitProductMixResult) a_arrProductMix.get(i);
                    oUnitProductMixResult.setUnitId(strUnitId);
                    _oUnitProdMixHome.create(oUnitProductMixResult);
                }
            }

            UnitPK upk = (UnitPK) _oUnit.getPrimaryKey();

            //return upk.getUnitId();
            return strUnitId;
        }
        catch (CreateException cex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(cex, "P5002");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
        }

        /*  catch (FinderException fex)
          {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(fex, "P5005");
          }*/
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();

            //throw new EElixirException(ejbex, "P3025");
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug(
                "FormulaEngineSLEJB--Inside catch of Eelixir exception in createUnit of FormulaEngineSLEJB");
            throw eex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }
    }

    /**
     * Creates the Data from the CHMSLEJB
     * @param a_arrUnit ArrayList
     * @throws EJBException
     * @throws EElixirException
     */
    public void updateUnit(UnitResultMain oUnitResultMain)
        throws EJBException, EElixirException
    {
        ArrayList a_arrUnit = oUnitResultMain.getArrUnitDetail();
        ArrayList a_arrProductMix = oUnitResultMain.getArrUnitProductMix();

        log.debug("FormulaEngineSLEJB--In update Unit of FormulaEngineSLEJB");

        UnitResult oUnitResult = null;
        UnitProductMixResult oUnitProductMixResult = null;

        try
        {
            //EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
            //CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            log.debug("FormulaEngineSLEJB--Before Lookup of entity bean");
//Dipti            _oUnitHome = getUnitHome();

            //_oUnitHome = (UnitHome)objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty("UnitHome"),UnitHome.class);
            log.debug("FormulaEngineSLEJB--After Lookup");

            int nIncludeExclude = 0;

            if (a_arrUnit != null)
            {
                for (int i = 0; i < a_arrUnit.size(); i++)
                {
	              _oUnitHome = getUnitHome(); ///Dipti
                    oUnitResult = (UnitResult) a_arrUnit.get(i);
                    nIncludeExclude = oUnitResult.getIsInclOrExcl().intValue();
                    log.debug(
                        "FormulaEngineSLEJB--status flag of the unit object " +
                        oUnitResult.getStatusFlag());

                    if (oUnitResult.getStatusFlag().trim().equals(DataConstants.INSERT_MODE))
                    {
                        _oUnitHome.create((UnitResult) a_arrUnit.get(i));
                    }
                    else if (oUnitResult.getStatusFlag().trim().equals(DataConstants.UPDATE_MODE))
                    {
                        UnitPK upk = new UnitPK(oUnitResult.getUnitDefnSeqNbr().longValue());

                        // upk.setUnitDefnSeqNbr(oUnitResult.getUnitDefnSeqNbr().longValue());
                        _oUnit = _oUnitHome.findByPrimaryKey(upk);
                        _oUnit.setUnitResult(oUnitResult);
                    }
                    else if (oUnitResult.getStatusFlag().trim().equals(DataConstants.DELETE_MODE))
                    {
                        UnitPK upk = new UnitPK(oUnitResult.getUnitDefnSeqNbr()
                                                           .longValue());

                        //  upk.setUnitDefnSeqNbr(oUnitResult.getUnitDefnSeqNbr().longValue());
                        log.debug("FormulaEngineSLEJB--Inside Delete1");
                        _oUnit = _oUnitHome.findByPrimaryKey(upk);
                        log.debug("FormulaEngineSLEJB--Inside Delete2");
                        _oUnit.remove();
                    }
                }
            }

            if (nIncludeExclude != DataConstants.INCLUDE_EXCLUDE_NA)
            {
                if (a_arrProductMix != null)
                {
                    for (int i = 0; i < a_arrProductMix.size(); i++)
                    {
                        UnitProdMixPK upmxPk = null;
                        oUnitProductMixResult = (UnitProductMixResult) a_arrProductMix.get(i);

                        if (oUnitProductMixResult.getStatusFlag().trim().equals(DataConstants.INSERT_MODE))
                        {
                            _oUnitProdMixHome.create(oUnitProductMixResult);
                        }
                        else if (oUnitProductMixResult.getStatusFlag().trim()
                                                          .equals(DataConstants.UPDATE_MODE))
                        {
                            upmxPk = new UnitProdMixPK(oUnitProductMixResult.getUnitId(),
                                    oUnitProductMixResult.getProdCd(),
                                    oUnitProductMixResult.getProdVer());
                            log.debug("FormulaEngineSLEJB--:New Rec to Update" +
                                oUnitProductMixResult);
                            _oUnitProdMix = _oUnitProdMixHome.findByPrimaryKey(upmxPk);
                            log.debug(
                                "FormulaEngineSLEJB--UPDATING unit Prod mix " +
                                ((UnitProdMixPK) _oUnitProdMix.getPrimaryKey()).getUnitId());
                            log.debug(
                                "FormulaEngineSLEJB--creating new Primary key ProductCd " +
                                ((UnitProdMixPK) _oUnitProdMix.getPrimaryKey()).getProdCd());
                            log.debug(
                                "FormulaEngineSLEJB--creating new Primary key productversion " +
                                ((UnitProdMixPK) _oUnitProdMix.getPrimaryKey()).getProdVer());

                            UnitProductMixResult con_UnitProductMixResult = _oUnitProdMix.getUnitProdMix();
                            log.debug(
                                "FormulaEngineSLEJB--update prod mix timestamps " +
                                con_UnitProductMixResult.getTsDtUpdated() +
                                " " + oUnitProductMixResult.getTsDtUpdated());

                            if ((con_UnitProductMixResult.getTsDtUpdated() != null) &&
                                    (!con_UnitProductMixResult.getTsDtUpdated()
                                                                  .equals(oUnitProductMixResult.getTsDtUpdated())))
                            {
                                log.debug(
                                    "concurrency failed thorwing exception");
                                throw new EElixirException("P1100");
                            }

                            //log.debug("FormulaEngineSLEJB--:Old Record Fetched" + _oUnit.getUnitResult());
                            _oUnitProdMix.setUnitProdMix(oUnitProductMixResult);
                        }
                        else if (oUnitProductMixResult.getStatusFlag().trim()
                                                          .equals(DataConstants.DELETE_MODE))
                        {
                            upmxPk = new UnitProdMixPK(oUnitProductMixResult.getUnitId(),
                                    oUnitProductMixResult.getProdCd(),
                                    oUnitProductMixResult.getProdVer());
                            log.debug("FormulaEngineSLEJB--Inside Delete1");
                            _oUnitProdMix = _oUnitProdMixHome.findByPrimaryKey(upmxPk);
                            log.debug(
                                "FormulaEngineSLEJB--creating new Primary key strUnitId " +
                                ((UnitProdMixPK) _oUnitProdMix.getPrimaryKey()).getUnitId());
                            log.debug(
                                "FormulaEngineSLEJB--creating new Primary key ProductCd " +
                                ((UnitProdMixPK) _oUnitProdMix.getPrimaryKey()).getProdCd());
                            log.debug(
                                "FormulaEngineSLEJB--creating new Primary key productversion " +
                                ((UnitProdMixPK) _oUnitProdMix.getPrimaryKey()).getProdVer());

                            //  upk.setUnitDefnSeqNbr(oUnitResult.getUnitDefnSeqNbr().longValue());
                            log.debug("FormulaEngineSLEJB--Inside Delete2");
                            _oUnitProdMix.remove();
                        }
                    }
                }
            }
             //if na then do not do any thing it will be deleted from the database in the update method if the unit
        }
        catch (CreateException cex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(cex, "P5002");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException fe)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--FinderException " + fe);
            throw new EElixirException(fe, "P5005");
        }
        catch (RemoveException fe)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--RemoveException " + fe);
            throw new EElixirException(fe, "P5007");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();

            //throw new EElixirException(ejbex, "P3025");
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug(
                "FormulaEngineSLEJB--Inside catch of Eelixir exception in createUnit of FormulaEngineSLEJB");
            throw eex;
        }
    }

    /**
     * Gets the data based on the parameter of DVO
     * @param a_oResultObject Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     */
    public String searchGroup(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        try
        {
            _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
            log.debug(
                "FormulaEngineSLEJB--before getGroup method of dax object");
            _strCon = _oFormulaEngineDAX.getGroup(a_oResultObject);
            log.debug("FormulaEngineSLEJB--after getGroup method of dax object");

            //DBConnection.closeConnection(_oConnection);
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();

            Exception e = ejbex.getCausedByException();

            if (e instanceof EElixirException)
            {
                throw (EElixirException) e;
            }
            else
            {
                throw ejbex;
            }
        }
        catch (EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }

        log.debug(_strCon);

        return _strCon;
    }

    /**
     * Gets the Data depending on the Group id
     * @param a_strGroupId String
     * @return ArrayList
     * @throws FinderException
     * @throws EElixirException
     */
    public ArrayList searchGroup(String a_strGroupId)
        throws FinderException, EElixirException
    {
        ArrayList arrGroupResult = null;

        try
        {
            _oGroupHome = getGroupHome();

            GroupPK oGroupPK = new GroupPK();
            oGroupPK.setGroupId(a_strGroupId);
            _oGroup = _oGroupHome.findByPrimaryKey(oGroupPK);
            log.debug("FormulaEngineSLEJB--Getting Result from Group Bean");
            arrGroupResult = _oGroup.getGroupResultList();
        }
        catch (FinderException fe)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--FinderException " + fe);
            throw new EElixirException(fe, "P5012");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--RemoteEXception " + rex);
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--EJBException " + ejbex);
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--EElixirException " + eex);
            throw eex;
        }

        return arrGroupResult;
    }

    /**
     * Validates a group, checks to see if        unique key constraint is validated or not.
     * @param a_arrGroup ArrayList
     * @return boolean
     * @throws EElixirException
     * @throws FinderException
     */
    public boolean groupPresent(ArrayList a_arrGroup)
        throws EElixirException, FinderException
    {
        boolean isGroupPresent = false;

        try
        {
            if (a_arrGroup != null)
            {
                for (int i = 0; i < a_arrGroup.size(); i++)
                {
                    _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
                    log.debug(
                        "FormulaEngineSLEJB--before findGroup method of dax object");
                    isGroupPresent = _oFormulaEngineDAX.findGroup(((GroupResult) a_arrGroup.get(
                                i)).getGroupId());
                    log.debug(
                        "FormulaEngineSLEJB--after findGroup method of dax object");

                    break;

                    //DBConnection.closeConnection(_oConnection);
                }
            }
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            throw eex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }

        return isGroupPresent;
    }

    /**
     * Creates the Data from the CHMSLEJB
     * @param a_arrGroup ArrayList
     * @throws EJBException
     * @throws EElixirException
     */
    public String createGroup(ArrayList a_arrGroup)
        throws EJBException, EElixirException
    {
        log.debug("FormulaEngineSLEJB--In create Group of FormulaEngineSLEJB");

        try
        {
            if (groupPresent(a_arrGroup))
            {
                log.debug("FormulaEngineSLEJB--before throwing exception");
                throw new EElixirException("P5028"); //Throw Unique constraint	violated message
            }

            log.debug("FormulaEngineSLEJB--Before Lookup of entity bean");
            _oGroupHome = getGroupHome();
            log.debug("FormulaEngineSLEJB--After Lookup");

            String strGroupId = null;

            if (a_arrGroup != null)
            {
                _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
                log.debug(
                    "FormulaEngineSLEJB--before getUnit method of dax object");
                strGroupId = _oFormulaEngineDAX.getNextGroupId();

                for (int i = 0; i < a_arrGroup.size(); i++)
                {
                    GroupResult oGroupResult = (GroupResult) a_arrGroup.get(i);
                    oGroupResult.setGroupId(strGroupId);
                    _oGroup = _oGroupHome.create(oGroupResult);
                }
            }

            // GroupPK gpk = (GroupPK)_oGroup.getPrimaryKey();
            //return gpk.getGroupId();
            //Done for Illeagal State Exception
            return strGroupId;
        }
        catch (CreateException cex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(cex, "P5009");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException fex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(fex, "P5012");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();

            //throw new EElixirException(ejbex, "P3025");
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug(
                "FormulaEngineSLEJB--Inside catch of Eelixir exception in createGroup of FormulaEngineSLEJB");
            throw eex;
        }
        finally
	    {
	        try
	        {
	            if(_oConnection != null)
	                DBConnection.closeConnection(_oConnection);
	        }
	        catch(EElixirException eElex)
	        {
	            throw eElex;
	        }
	    }
    }

    /**
     * Creates the Data from the CHMSLEJB
     * @param a_arrGroup ArrayList
     * @throws EJBException
     * @throws EElixirException
     */
    public void updateGroup(ArrayList a_arrGroup)
        throws EJBException, EElixirException
    {
        log.debug("FormulaEngineSLEJB--In update Group of FormulaEngineSLEJB");

        GroupResult oGroupResult = null;

        try
        {
            log.debug("FormulaEngineSLEJB--Before Lookup of entity bean");
            _oGroupHome = getGroupHome();
            log.debug("FormulaEngineSLEJB--After Lookup");

            if (a_arrGroup != null)
            {
                for (int i = 0; i < a_arrGroup.size(); i++)
                {
                    oGroupResult = (GroupResult) a_arrGroup.get(i);
                    log.debug("FormulaEngineSLEJB--oGroupResult:" +
                        oGroupResult);

                    if (oGroupResult.getStatusFlag().trim().equals(DataConstants.INSERT_MODE))
                    {
                        log.debug("FormulaEngineSLEJB--Inside Insert1");
                        _oGroup = _oGroupHome.create(oGroupResult);
                        log.debug("FormulaEngineSLEJB--Inside Insert2");
                    }
                    else if (oGroupResult.getStatusFlag().trim().equals(DataConstants.UPDATE_MODE))
                    {
                        GroupPK gpk = new GroupPK();
                        log.debug("FormulaEngineSLEJB--Inside Update1");
                        gpk.setCritDefnSeqNbr(oGroupResult.getCritDefnSeqNbr()
                                                          .longValue());
                        log.debug("FormulaEngineSLEJB--Inside Update2");
                        _oGroup = _oGroupHome.findByPrimaryKey(gpk);

                        GroupResult con_GroupResult = _oGroup.getGroupResult();

                        if ((con_GroupResult.getTsDtUpdated() != null) &&
                                (!con_GroupResult.getTsDtUpdated().equals(oGroupResult.getTsDtUpdated())))
                        {
                            log.debug("concurrency failed thorwing exception");
                            throw new EElixirException("P1100");
                        }

                        log.debug("FormulaEngineSLEJB--Inside Update3");
                        _oGroup.setGroupResult(oGroupResult);
                    }
                    else if (oGroupResult.getStatusFlag().trim().equals(DataConstants.DELETE_MODE))
                    {
                        GroupPK gpk = new GroupPK();
                        gpk.setCritDefnSeqNbr(oGroupResult.getCritDefnSeqNbr()
                                                          .longValue());
                        log.debug("FormulaEngineSLEJB--Inside Delete1");
                        _oGroup = _oGroupHome.findByPrimaryKey(gpk);
                        log.debug("FormulaEngineSLEJB--Inside Delete2");
                        _oGroup.remove();
                    }
                }
            }
        }
        catch (CreateException cex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(cex, "P5009");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException fe)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--FinderException " + fe);
            throw new EElixirException(fe, "P5012");
        }
        catch (RemoveException fe)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--RemoveException " + fe);
            throw new EElixirException(fe, "P5014");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();

            //throw new EElixirException(ejbex, "P3025");
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug(
                "FormulaEngineSLEJB--Inside catch of Eelixir exception in createUnit of FormulaEngineSLEJB");
            throw eex;
        }
    }

    /**
     * Gets the Data depending on the Formula seqno
     * @param a_lFormlDefnSeqNbr long
     * @return FormulaResult
     * @throws FinderException
     * @throws EElixirException
     */
    public FormulaResult searchFormula(long a_lFormlDefnSeqNbr)
        throws FinderException, EElixirException
    {
        FormulaResult oFormulaResult = null;

        try
        {
            _oFormulaHome = getFormulaHome();

            FormulaPK oFormulaPK = new FormulaPK();
            oFormulaPK.setFormlDefnSeqNbr(a_lFormlDefnSeqNbr);
            _oFormula = _oFormulaHome.findByPrimaryKey(oFormulaPK);
            log.debug("FormulaEngineSLEJB--Getting Result from Formula Bean");
            oFormulaResult = _oFormula.getFormulaResult();
        }
        catch (FinderException fe)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--FinderException " + fe);
            throw new EElixirException(fe, "P9002");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--RemoteEXception " + rex);
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--EJBException " + ejbex);
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--EElixirException " + eex);
            throw eex;
        }

        return oFormulaResult;
    }

    /**
     * Gets the data based on the parameter of DVO
     * @param a_oResultObject Object
     * @return String XML format string object
     * @throws EElixirException
     * @throws FinderException
     */
    public String searchFormula(Object a_oResultObject)
        throws FinderException, EElixirException
    {
        try
        {
            _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
            log.debug(
                "FormulaEngineSLEJB--before getFormula method of dax object");
            _strCon = _oFormulaEngineDAX.getFormula(a_oResultObject);
            log.debug(
                "FormulaEngineSLEJB--after getFormula method of dax object");

            //DBConnection.closeConnection(_oConnection);
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();

            Exception e = ejbex.getCausedByException();

            if (e instanceof EElixirException)
            {
                throw (EElixirException) e;
            }
            else
            {
                throw ejbex;
            }
        }
        catch (EElixirException eLex)
        {
            _EJBContext.setRollbackOnly();
            throw eLex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P5018");
            }
        }

        log.debug(_strCon);

        return _strCon;
    }

    /**
     * Validates a formula, checks to see if        unique key constraint is validated or not.
     * @param a_strFormlId String
     * @return boolean
     * @throws EElixirException
     * @throws FinderException
     */
    public boolean formulaPresent(String a_strFormlId)
        throws EElixirException, FinderException
    {
        boolean isFormulaPresent = false;

        try
        {
            _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();
            log.debug(
                "FormulaEngineSLEJB--before	findFormula	method of dax object");
            isFormulaPresent = _oFormulaEngineDAX.findFormula(a_strFormlId);
            log.debug(
                "FormulaEngineSLEJB--after findFormula method of dax object");

            //DBConnection.closeConnection(_oConnection);
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            throw eex;
        }
        finally
        {
            try
            {
                if (_oConnection != null)
                {
                    DBConnection.closeConnection(_oConnection);
                }
            }
            catch (EElixirException eElex)
            {
                throw new EElixirException(eElex, "P1005");
            }
        }

        return isFormulaPresent;
    }

    /**
     * Creates the Data from the CHMSLEJB
     * @param a_oFormulaResult FormulaResult
     * @return long
     * @throws EJBException
     * @throws EElixirException
     */
    public long createFormula(FormulaResult a_oFormulaResult)
        throws EJBException, EElixirException
    {
        FormulaResult formulaResult = null;
        log.debug("FormulaEngineSLEJB--In create Formula of FormulaEngineSLEJB");

        long lFormlDefnSeqNbr = 0;

        try
        {
            if (formulaPresent(a_oFormulaResult.getFormlId()))
            {
                log.debug("FormulaEngineSLEJB--before throwing exception");
                throw new EElixirException("P5029"); //Throw Unique constraint	violated message
            }

            log.debug("FormulaEngineSLEJB--Before Lookup of entity bean");
            _oFormulaHome = getFormulaHome();
            log.debug("FormulaEngineSLEJB--After Lookup");

            _oFormula = _oFormulaHome.create(a_oFormulaResult);
            lFormlDefnSeqNbr = ((FormulaPK) _oFormula.getPrimaryKey()).getFormlDefnSeqNbr();
            log.debug("FormulaEngineSLEJB--Key is " + lFormlDefnSeqNbr);
        }
        catch (CreateException cex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(cex, "P5016");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException fex)
        {
            _EJBContext.setRollbackOnly();
            throw new EElixirException(fex, "P5018");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();

            //throw new EElixirException(ejbex, "P3025");
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug(
                "FormulaEngineSLEJB--Inside catch of Eelixir exception in createFormula of FormulaEngineSLEJB");
            throw eex;
        }

        //return FormulaResult;
        return lFormlDefnSeqNbr;
    }

    /**
     * Updates/Insert/Deletes data into Formula hdr and its associated calc and elgble table
     * @param a_oFormulaResult FormulaResult
     * @throws FinderException
     * @throws EElixirException
     */
    public void updateFormula(FormulaResult a_oFormulaResult)
        throws FinderException, EElixirException
    {
        FormulaResult oFormulaResult = null;

        try
        {
            log.debug("FormulaEngineSLEJB--Before Lookup");

            String strStatusFlag = null;
            _oFormulaHome = getFormulaHome();
            log.debug("FormulaEngineSLEJB--Home LookUP _oFormulaHome:" +
                _oFormulaHome);

            FormulaPK _oFormulaPK = new FormulaPK();
            _oFormulaPK.setFormlDefnSeqNbr(a_oFormulaResult.getFormlDefnSeqNbr()
                                                           .longValue());
            _oFormula = _oFormulaHome.findByPrimaryKey(_oFormulaPK);
            log.debug("FormulaEngineSLEJB--Updating call to  Formula Bean");

            ArrayList arrFormElgble = a_oFormulaResult.getFormulaEligibilityCriteria();
            ArrayList arrFormCalc = a_oFormulaResult.getFormulaCalculation();
            FormulaResult con_FormulaResult = _oFormula.getFormulaResult();

            //this is to check the header part
            if ((con_FormulaResult.getTsDtUpdated() != null) && a_oFormulaResult.getTsDtUpdated()!=null &&
                    (!con_FormulaResult.getTsDtUpdated().equals(a_oFormulaResult.getTsDtUpdated())))
            {
                log.debug("concurrency failed thorwing exception");
                throw new EElixirException("P1100");
            }

            log.debug("concurrency for header not failed continuing");
            _oFormulaEngineDAX = (FormulaEngineDAX) getDAX();

            if (arrFormElgble != null)
            {
				            log.debug("concurrency for header not failed continuing 1");
                for (int i = 0; i < arrFormElgble.size(); i++)
                {
                    FormulaEligibilityCriteriaResult o_FormulaEligibilityCriteriaResult =
                        (FormulaEligibilityCriteriaResult) arrFormElgble.get(i);
                    strStatusFlag = o_FormulaEligibilityCriteriaResult.getStatusFlag();

            log.debug("concurrency for header not failed continuing 2");
                    if (strStatusFlag.equalsIgnoreCase(
                                DataConstants.UPDATE_MODE) ||
                            strStatusFlag.equalsIgnoreCase(
                                DataConstants.DELETE_MODE))
                    {
						            log.debug("concurrency for header not failed continuing 3");
                        Timestamp con_dtUpdated = _oFormulaEngineDAX.getFormulaEligibiltyCriteriaDtUpdated(o_FormulaEligibilityCriteriaResult.getElgbleCritSeqNbr()
                                                                                                                                             .longValue(),
                                a_oFormulaResult.getFormlDefnSeqNbr().longValue());

            log.debug("concurrency for header not failed continuing 4");
                        if ((con_dtUpdated != null) && o_FormulaEligibilityCriteriaResult.getTsDtUpdated()!=null &&
                                (!con_dtUpdated.equals(
                                    o_FormulaEligibilityCriteriaResult.getTsDtUpdated())))
                        {

                            log.debug("concurrency failed thorwing exception");
                            throw new EElixirException("P1100");
                        }
						            log.debug("concurrency for header not failed continuing 5");
                    }
                }
            }
            log.debug("concurrency for header not failed continuing 6");
            if (arrFormCalc != null)
            {
	            log.debug("concurrency for header not failed continuing 7");
                for (int i = 0; i < arrFormCalc.size(); i++)
                {
		            log.debug("concurrency for header not failed continuing 8");
                    FormulaCalculationResult o_FormulaCalculationResult = (FormulaCalculationResult) arrFormCalc.get(i);
                    strStatusFlag = o_FormulaCalculationResult.getStatusFlag();
					 if (strStatusFlag.equalsIgnoreCase(
                                DataConstants.UPDATE_MODE) ||
                            strStatusFlag.equalsIgnoreCase(
                                DataConstants.DELETE_MODE))
                    {
							Timestamp con_dtUpdated = _oFormulaEngineDAX.getFormulaCalculationDtUpdated(o_FormulaCalculationResult.getFormlCalcSeqNbr()
																																  .longValue(),
									a_oFormulaResult.getFormlDefnSeqNbr().longValue());
						   log.debug("concurrency for header not failed continuing 9");
							if ((con_dtUpdated != null) && o_FormulaCalculationResult.getTsDtUpdated()!=null && 
									(!con_dtUpdated.equals(
										o_FormulaCalculationResult.getTsDtUpdated())))
							{
								log.debug("concurrency failed thorwing exception");
								throw new EElixirException("P1100");
							}
					}
		            log.debug("concurrency for header not failed continuing 10");
                }
	            log.debug("concurrency for header not failed continuing 11");
            }
            log.debug("concurrency for header not failed continuing 12");
            _oFormula.setFormulaResult(a_oFormulaResult);
            log.debug("FormulaEngineSLEJB--Result Obtained" + oFormulaResult);
        }
        catch (FinderException fe)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--FinderException " + fe);
            throw new EElixirException(fe, "P5016");
        }
        catch (RemoteException rex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--RemoteEXception " + rex);
            throw new EElixirException(rex, "P1006");
        }
        catch (EJBException ejbex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--EJBException " + ejbex);
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _EJBContext.setRollbackOnly();
            log.debug("FormulaEngineSLEJB--EElixirException " + eex);
            throw eex;
        }
        finally
	    {
	        try
	        {
	            if(_oConnection != null)
	                DBConnection.closeConnection(_oConnection);
	        }
	        catch(EElixirException eElex)
	        {
	            throw eElex;
	        }
	    }
    }

    /**
     * Gets the Dax object and sets the connection on it.
     * @return FormulaEngineDAX
     * @throws EElixirException
     */
    private FormulaEngineDAX getDAX() throws EElixirException
    {
        _oConnection = DBConnection.getConnection();

        CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        FormulaEngineDAX _oFormulaEngineDAX = (FormulaEngineDAX) theDAXFactory.createDAX(theDAXFactory.FORMULAENGINEDAX);
        _oFormulaEngineDAX.setConnection(_oConnection);

        return _oFormulaEngineDAX;
    }

    private UnitHome getUnitHome() throws EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("FormulaEngineSLEJB--Before Lookup");

        UnitHome oUnitHome = (UnitHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "UnitHome"), UnitHome.class);
        log.debug("FormulaEngineSLEJB--Home LookUP _oUnitHome:" + oUnitHome);

        return oUnitHome;
    }

    private GroupHome getGroupHome() throws EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("FormulaEngineSLEJB--Before Lookup");

        GroupHome oGroupHome = (GroupHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "GroupHome"), GroupHome.class);
        log.debug("FormulaEngineSLEJB--Home LookUP _oGroupHome:" + oGroupHome);

        return oGroupHome;
    }

    private FormulaHome getFormulaHome() throws EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("FormulaEngineSLEJB--Before Lookup");

        FormulaHome oFormulaHome = (FormulaHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "FormulaHome"), FormulaHome.class);
        log.debug("FormulaEngineSLEJB--Home LookUP _oGFormulaHome:" +
            oFormulaHome);

        return oFormulaHome;
    }

    private UnitProdMixHome getUnitProdMixHome() throws EElixirException
    {
        EJBHomeFactory objEJBHomeFactory = EJBHomeFactory.getFactory();
        CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
        log.debug("FormulaEngineSLEJB--Before Lookup");

        UnitProdMixHome oUnitProdMixHome = (UnitProdMixHome) objEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
                    "UnitProdMixHome"), UnitProdMixHome.class);
        log.debug("FormulaEngineSLEJB--Home LookUP _oUnitHome:" +
            oUnitProdMixHome);

        return oUnitProdMixHome;
    }
}
