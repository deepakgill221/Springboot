/********************************************************************
*
*  PROJECT			: Prudential
*  MODULE NAME		: Channel Management
*  FILENAME			: UnitResultMain
*  AUTHOR			: Pallav
*  VERSION			: 1.0
*  CREATION DATE	        : Mar 10, 2003
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Unit Result</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.formulaengine.util;

import java.io.Serializable;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class UnitResultMain extends UserData implements Serializable
{

  protected ArrayList _arrUnitResult  = null;
  protected ArrayList _arrUnitProductMix = null;

  public UnitResultMain()
  {

  }

  public ArrayList getArrUnitDetail() {
    return _arrUnitResult;
  }
  public void setArrUnitDetail(ArrayList a_arrUnitResult) {
    this._arrUnitResult = a_arrUnitResult;
  }
  public ArrayList getArrUnitProductMix() {
    return _arrUnitProductMix;
  }
  public void setArrUnitProductMix(ArrayList a_arrUnitProductMix) {
    this._arrUnitProductMix = a_arrUnitProductMix;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_arrUnitResult:" + _arrUnitResult + "\n";
    retValue = retValue + "_arrUnitProductMix:" + _arrUnitProductMix + "\n";
    return retValue;
  }


}
