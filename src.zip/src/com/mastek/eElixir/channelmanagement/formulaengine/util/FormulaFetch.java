/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FormulaFetch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * FormnulaFetch is the Utility Class for fetching parameter for Benefit
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.formulaengine.util;

import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class FormulaFetch
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the FormulaFetch class
   */
  public FormulaFetch()
  {

  }


  /**
   * This Fetches all the paramater for formula except primary key
   * @param a_oRequest HttpServletRequest object.
   * @return FormulaResult
   * @throws EElixirException
   */
  public FormulaResult fetchFormula(HttpServletRequest a_oRequest) {
    FormulaResult oFormulaResult = null;
    log.debug("FormulaFetch--Inside Formula Fetch");
    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");

    String strFormlId = "";

    if (a_oRequest.getParameter("strFormlId")!= null)
    {
        strFormlId = a_oRequest.getParameter("strFormlId").trim();
    }
    String dtUpdated = a_oRequest.getParameter("dtUpdated");
    String strFormlDesc   = a_oRequest.getParameter("strFormlDesc").trim();
    String strElgbleExpr  = a_oRequest.getParameter("strElgbleExpr").trim();
    String strUnitId = a_oRequest.getParameter("strUnitId");
    //String strCalcExpr    = a_oRequest.getParameter("strCalcExpr").trim();
    log.debug("FormulaFetch--Got 2 values strFormlId, strFormlDesc:" + strFormlId + " " + strFormlDesc);
    log.debug("FormulaFetch--Got 2 values strElgbleExpr, strCalcExpr:" + strElgbleExpr + " ");
    oFormulaResult = new FormulaResult();
    if (dtUpdated != null && !dtUpdated.trim().equals(""))
    {
      oFormulaResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated));
    }
    oFormulaResult.setFormlId(strFormlId);
    oFormulaResult.setFormlDesc(strFormlDesc);
    oFormulaResult.setElgbleExpr(strElgbleExpr);
    oFormulaResult.setUserId(_strUserId);
	oFormulaResult.setUnitId(strUnitId);

	//oFormulaResult.setFormulaCalculation(formlCalcFetch(a_oRequest));
	oFormulaResult.setFormulaEligibilityCriteria(formlElgbleFetch(a_oRequest));

    log.debug("FormulaFetch--Set formula data");
    return oFormulaResult;
  }

  /**
   * This method fetches all the details of Formula calc
   * @return ArrayList ArrayList of Formula calc
   * @param a_oRequest HttpServletRequest object.
   */
  private ArrayList formlCalcFetch(HttpServletRequest a_oRequest){
    ArrayList arrFormlCalc = null;
    FormulaCalculationResult oFormulaCalculationResult = null;
    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");

    log.debug("FormulaFetch--Fetching details of Formula calc");
    String[] strBaseParamId = a_oRequest.getParameterValues("strBaseParamId");
    String[] cStartBracket = a_oRequest.getParameterValues("cStartBracketC"); //char
    String[] cEndBracket = a_oRequest.getParameterValues("cEndBracketC"); //char
    String[] nOperator = a_oRequest.getParameterValues("nOperatorC"); //short
    String[] dValue = a_oRequest.getParameterValues("dValue"); //double
    String[] PKValue = a_oRequest.getParameterValues("PKValueC"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlagC"); //String
    String[] eval_dtUpdated =a_oRequest.getParameterValues("eval_dtUpdated"); //String

   // if minimum one of the status flag is not of type clear mode then
    // initialize arrProdMix
    if(strBaseParamId != null){
      for(int i = 0; i<strBaseParamId.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          arrFormlCalc = new ArrayList(10);
          break;
        }
      }
    }
    log.debug("FormulaFetch--Checking Clear Mode flag");

    if(arrFormlCalc != null){
      for(int i = 0; i<strBaseParamId.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          oFormulaCalculationResult = new FormulaCalculationResult();
          oFormulaCalculationResult.setUserId(_strUserId);
          if(! PKValue[i].trim().equals("")){
            oFormulaCalculationResult.setFormlCalcSeqNbr(new Long(PKValue[i].trim()));
          }
          oFormulaCalculationResult.setBaseParamId(strBaseParamId[i].trim());
          if( cStartBracket[i].trim().equals("")){
            oFormulaCalculationResult.setStartBracket(new Character(' '));
          }
          else{
            oFormulaCalculationResult.setStartBracket(new Character(cStartBracket[i].trim().charAt(0)));
          }

          if( cEndBracket[i].trim().equals("")){
            oFormulaCalculationResult.setEndBracket(new Character(' '));
          }
          else{
            oFormulaCalculationResult.setEndBracket(new Character(cEndBracket[i].trim().charAt(0)));
          }

          if(! nOperator[i].trim().equals("")){
            oFormulaCalculationResult.setOperator(new Short(nOperator[i].trim()));
          }
          if(! dValue[i].trim().equals("")){
            oFormulaCalculationResult.setValue(new Double(dValue[i].trim()));
          }
          log.debug("FormulaFetch--strStatusFlag[" + i + "] for Calc:" + strStatusFlag[i]);
          oFormulaCalculationResult.setStatusFlag(strStatusFlag[i]);
          if(eval_dtUpdated[i] != null && !eval_dtUpdated[i].trim().equals(""))
          {
            oFormulaCalculationResult.setTsDtUpdated(Timestamp.valueOf(eval_dtUpdated[i]));
          }
          arrFormlCalc.add(oFormulaCalculationResult);
        }
      }
    }
    log.debug("FormulaFetch--Fetched details of Formula calc");
    return arrFormlCalc;
  }

  /**
   * This method fetches all the details of Formula elgble
   * @return ArrayList ArrayList of Formula elgble
   * @param a_oRequest HttpServletRequest object.
   */
  private ArrayList formlElgbleFetch(HttpServletRequest a_oRequest){
    FormulaEligibilityCriteriaResult oFormulaEligibilityCriteriaResult = null;
    ArrayList arrFormlElgble = null;

    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");
    log.debug("FormulaFetch--Fetching details of Formula elgble");
    String[] strGroupId = a_oRequest.getParameterValues("strGroupId");
    String[] strExpression  = a_oRequest.getParameterValues("strExpression"); //string
    String[] nNoOfCondition    = a_oRequest.getParameterValues("nNoOfCondition"); //char
    String[] cStartBracket = a_oRequest.getParameterValues("cStartBracketE"); //char
    String[] cEndBracket = a_oRequest.getParameterValues("cEndBracketE"); //char
    String[] nOperator      = a_oRequest.getParameterValues("nOperatorE"); //short
    String[] PKValue       = a_oRequest.getParameterValues("PKValueE"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlagE"); //String
    String[] crit_dtUpdated = a_oRequest.getParameterValues("crit_dtUpdated"); //String

   // if minimum one of the status flag is not of type clear mode then
    // initialize arrProdMix
    if(strGroupId != null){
      for(int i = 0; i<strGroupId.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          arrFormlElgble = new ArrayList(10);
          break;
        }
      }
    }
    log.debug("FormulaFetch--Checking Clear Mode flag");

    if(arrFormlElgble != null){
      for(int i = 0; i<strGroupId.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          oFormulaEligibilityCriteriaResult = new FormulaEligibilityCriteriaResult();
          oFormulaEligibilityCriteriaResult.setUserId(_strUserId);
          log.debug("FormulaFetch--_strUserId:" + _strUserId);
          if(! PKValue[i].trim().equals("")){
            oFormulaEligibilityCriteriaResult.setElgbleCritSeqNbr(new Long(PKValue[i].trim()));
          }
          log.debug("FormulaFetch--PKValue[" + i + "]:" + PKValue[i]);
          oFormulaEligibilityCriteriaResult.setGroupId(strGroupId[i]);
          if(strExpression[i] != null){
            oFormulaEligibilityCriteriaResult.setExpression(strExpression[i].trim());
          }
          log.debug("FormulaFetch--strExpression[" + i + "]:" + strExpression[i]);
          if( cStartBracket[i].trim().equals("")){
            oFormulaEligibilityCriteriaResult.setStartBracket(new Character(' '));
          }
          else{
            oFormulaEligibilityCriteriaResult.setStartBracket(new Character(cStartBracket[i].trim().charAt(0)));
          }
          log.debug("FormulaFetch--cStartBracket[" + i + "]:" + cStartBracket[i]);
          if( cEndBracket[i].trim().equals("")){
            oFormulaEligibilityCriteriaResult.setEndBracket(new Character(' '));
          }
          else{
            oFormulaEligibilityCriteriaResult.setEndBracket(new Character(cEndBracket[i].trim().charAt(0)));
          }
          log.debug("FormulaFetch--cEndBracket[" + i + "]:" + cEndBracket[i]);

          if(! nOperator[i].trim().equals("")){
            oFormulaEligibilityCriteriaResult.setOperator(new Short(nOperator[i].trim()));
          }
          log.debug("FormulaFetch--nOperator[" + i + "]:" + nOperator[i]);

          if(! nNoOfCondition[i].trim().equals("")){
            oFormulaEligibilityCriteriaResult.setNoOfCondition(new Short(nNoOfCondition[i].trim()));
          }
          log.debug("FormulaFetch--nNoOfCondition[" + i + "]:" + nNoOfCondition[i]);

          log.debug("FormulaFetch--strStatusFlag[" + i + "] for Eligibility:" + strStatusFlag[i]);
          oFormulaEligibilityCriteriaResult.setStatusFlag(strStatusFlag[i]);
          if (crit_dtUpdated[i] != null && !crit_dtUpdated[i].trim().equals(""))
          {
            oFormulaEligibilityCriteriaResult.setTsDtUpdated(Timestamp.valueOf(crit_dtUpdated[i]));
          }
          arrFormlElgble.add(oFormulaEligibilityCriteriaResult);
        }
      }
    }
    log.debug("FormulaFetch--Fetched details of Formula elgble");
    return arrFormlElgble;
  }



}