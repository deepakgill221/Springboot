/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FormulaEligibilityCriteriaResult.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for FormulaEligibilityCriteria Formula</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.formulaengine.util;
import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class FormulaEligibilityCriteriaResult extends UserData implements Serializable
{
  protected Long     _lElgbleCritSeqNbr   = null;
  protected Long     _lFormlDefnSeqNbr    = null;
  protected String   _strGroupId          = null;
  protected Short    _nOperator           = null;
  protected Character _cStartBracket      = null;
  protected Character _cEndBracket        = null;
  protected Short    _nNoOfCondition      = null;
  protected String   _strExpression       = null;
  protected String    _strStatusFlag      = null;

  public FormulaEligibilityCriteriaResult()
  {

  }
  public Long getElgbleCritSeqNbr() {
    return _lElgbleCritSeqNbr;
  }
  public void setElgbleCritSeqNbr(Long a_lElgbleCritSeqNbr) {
    this._lElgbleCritSeqNbr = a_lElgbleCritSeqNbr;
  }
  public Long getFormlDefnSeqNbr() {
    return _lFormlDefnSeqNbr;
  }
  public void setFormlDefnSeqNbr(Long a_lFormlDefnSeqNbr) {
    this._lFormlDefnSeqNbr = a_lFormlDefnSeqNbr;
  }
  public Character getEndBracket() {
    return _cEndBracket;
  }
  public void setEndBracket(Character a_cEndBracket) {
    this._cEndBracket = a_cEndBracket;
  }
  public Character getStartBracket() {
    return _cStartBracket;
  }
  public void setStartBracket(Character a_cStartBracket) {
    this._cStartBracket = a_cStartBracket;
  }
  public Short getNoOfCondition() {
    return _nNoOfCondition;
  }
  public void setNoOfCondition(Short a_nNoOfCondition) {
    this._nNoOfCondition = a_nNoOfCondition;
  }
  public Short getOperator() {
    return _nOperator;
  }
  public void setOperator(Short a_nOperator) {
    this._nOperator = a_nOperator;
  }
  public String getExpression() {
    return _strExpression;
  }
  public void setExpression(String a_strExpression) {
    this._strExpression = a_strExpression;
  }
  public String getGroupId() {
    return _strGroupId;
  }
  public void setGroupId(String a_strGroupId) {
    this._strGroupId = a_strGroupId;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }


  public String toString(){
    String retValue = "";
    retValue = retValue + "_lElgbleCritSeqNbr:" + _lElgbleCritSeqNbr + "\n";
    retValue = retValue + "_lFormlDefnSeqNbr:" + _lFormlDefnSeqNbr + "\n";
    retValue = retValue + "_cStartBracket:" + _cStartBracket + "\n";
    retValue = retValue + "_cEndBracket:" + _cEndBracket + "\n";
    retValue = retValue + "_strGroupId:" + _strGroupId + "\n";
    retValue = retValue + "_nOperator:" + _nOperator + "\n";
    retValue = retValue + "_nNoOfCondition:" + _nNoOfCondition + "\n";
    retValue = retValue + "_strExpression:" + _strExpression + "\n";
    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";
    return retValue;
  }


}
