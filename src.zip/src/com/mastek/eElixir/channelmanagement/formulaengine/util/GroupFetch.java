/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: GroupFetch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * GroupFetch is the Utility Class for fetching parameter for Group
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.formulaengine.util;


import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;


public class GroupFetch
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the GroupFetch class
   */
  public GroupFetch()
  {

  }


  /**
   * This Fetches all the paramater for Group except primary key
   * @param a_oRequest HttpServletRequest object.
   * @return ArrayList
   * @throws EElixirException
   */
  public ArrayList fetchGroup(HttpServletRequest a_oRequest) {
    GroupResult oGroupResult = null;
    log.debug("GroupFetch--Inside Group Fetch");
    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");

    String strGroupId    = "";
    if (a_oRequest.getParameter("strGroupId")!= null)
    {
	    strGroupId = a_oRequest.getParameter("strGroupId").trim();
    }
    String strGroupDesc  = a_oRequest.getParameter("strGroupDesc").trim();
    String strGroupExpr   = a_oRequest.getParameter("strGroupExpr").trim();
    log.debug("GroupFetch--Got 2 values strGroupId, strGroupDesc, strGroupExpr:" + strGroupId + " " + strGroupDesc + " " + strGroupExpr);

    ArrayList arrGroup = null;

    log.debug("GroupFetch--Fetching details of Group");
    String[] strUnitId = a_oRequest.getParameterValues("strUnitId");
    String[] cStartBracket = a_oRequest.getParameterValues("cStartBracket"); //char
    String[] cEndBracket = a_oRequest.getParameterValues("cEndBracket"); //char
    String[] nOperator = a_oRequest.getParameterValues("nOperator"); //short
    String[] PKValue = a_oRequest.getParameterValues("PKValue"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlag"); //String
    String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");

   // if minimum one of the status flag is not of type clear mode then
    // initialize arrProdMix
    if(strUnitId != null){
      for(int i = 0; i<strUnitId.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          arrGroup = new ArrayList(10);
          break;
        }
      }
    }
    log.debug("GroupFetch--Checking Clear Mode flag");

    if(arrGroup != null){
      for(int i = 0; i<strUnitId.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          oGroupResult = new GroupResult();
		  if(strStatusFlag[i].trim().equals(DataConstants.UPDATE_MODE)){
			oGroupResult.setIsDirty(DataConstants.UPDATE_MODE);
		  }
		  else if(strStatusFlag[i].trim().equals(DataConstants.INSERT_MODE)){
			oGroupResult.setIsDirty(DataConstants.DISPLAY_MODE);
		  }


          oGroupResult.setUserId(_strUserId);
          oGroupResult.setGroupId(strGroupId);
          oGroupResult.setGroupDesc(strGroupDesc);
          oGroupResult.setGroupExpr(strGroupExpr);
          log.debug("GroupFetch--PKValue[" + i + "]" + PKValue[i]);
          if(! PKValue[i].trim().equals("")){
            oGroupResult.setCritDefnSeqNbr(new Long(PKValue[i].trim()));
            log.debug("GroupFetch--PKValue[" + i + "]" + PKValue[i]);
          }
          oGroupResult.setUnitId(strUnitId[i]);
          if( cStartBracket[i].trim().equals("")){
            oGroupResult.setStartBracket(new Character(' '));
          }
          else{
            oGroupResult.setStartBracket(new Character(cStartBracket[i].trim().charAt(0)));
          }

          if( cEndBracket[i].trim().equals("")){
            oGroupResult.setEndBracket(new Character(' '));
          }
          else{
            oGroupResult.setEndBracket(new Character(cEndBracket[i].trim().charAt(0)));
          }
          if(! nOperator[i].trim().equals("")){
            oGroupResult.setOperator(new Short(nOperator[i].trim()));
          }
          log.debug("GroupFetch--strStatusFlag[" + i + "]" + strStatusFlag[i]);
          oGroupResult.setStatusFlag(strStatusFlag[i]);
          if (dtUpdated[i] != null && !dtUpdated[i].trim().equals(""))
          {
            oGroupResult.setTsDtUpdated(Timestamp.valueOf(dtUpdated[i]));
          }
          arrGroup.add(oGroupResult);
        }
      }
    }
    log.debug("GroupFetch--Fetched details of Group");
    return arrGroup;
  }
}