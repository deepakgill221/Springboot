/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: UnitResult.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Unit Result</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.formulaengine.util;

import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class UnitResult extends UserData implements Serializable
{

  protected Long      _lUnitDefnSeqNbr  = null;
  protected String    _strUnitId        = null;
  protected String    _strUnitDesc      = null;
  protected String    _strBaseParamId   = null;
  protected Character _cStartBracket    = null;
  protected Long      _lLowValue        = null;
  protected Long      _lHighValue       = null;
  protected Short     _nOperator        = null;
  protected Character _cEndBracket      = null;
  protected String    _strStatusFlag    = null;
  protected String    _strUnitExpr      = null;
  protected Short _nMonthFrom = null;
  protected Short _nMonthTo = null;
  protected String _strBaseParamDesc = null;
  protected Short     _nCompOper        = null;
  protected Short _nIsInclOrExcl   = null;
  protected Short _nIsLogOrArith;

  public UnitResult()
  {

  }

  public Short getIsInclOrExcl()
  {
	  return this._nIsInclOrExcl;
  }
  public void setIsInclOrExcl(Short a_nIsInclOrExcl)
  {
	  this._nIsInclOrExcl = a_nIsInclOrExcl;
  }
  public Short getCompOper() {
    return _nCompOper;
  }
  public void setCompOper(Short a_nCompOper) {
    this._nCompOper = a_nCompOper;
  }
  
  public String getBaseParamDesc() {
    return _strBaseParamDesc;
  }
  public void setBaseParamDesc(String a_strBaseParamDesc) {
    this._strBaseParamDesc = a_strBaseParamDesc;
  }
  
  public Character getEndBracket() {
    return _cEndBracket;
  }
  public void setEndBracket(Character a_cEndBracket) {
    this._cEndBracket = a_cEndBracket;
  }
  public Character getStartBracket() {
    return _cStartBracket;
  }
  public void setStartBracket(Character a_cStartBracket) {
    this._cStartBracket = a_cStartBracket;
  }
  public Long getHighValue() {
    return _lHighValue;
  }
  public void setHighValue(Long a_lHighValue) {
    this._lHighValue = a_lHighValue;
  }
  public Long getLowValue() {
    return _lLowValue;
  }
  public void setLowValue(Long a_lLowValue) {
    this._lLowValue = a_lLowValue;
  }
  public Long getUnitDefnSeqNbr() {
    return _lUnitDefnSeqNbr;
  }
  public void setUnitDefnSeqNbr(Long a_lUnitDefnSeqNbr) {
    this._lUnitDefnSeqNbr = a_lUnitDefnSeqNbr;
  }
  public Short getOperator() {
    return _nOperator;
  }
  public void setOperator(Short a_nOperator) {
    this._nOperator = a_nOperator;
  }
  public String getBaseParamId() {
    return _strBaseParamId;
  }
  public void setBaseParamId(String a_strBaseParamId) {
    this._strBaseParamId = a_strBaseParamId;
  }
  public String getUnitDesc() {
    return _strUnitDesc;
  }
  public void setUnitDesc(String a_strUnitDesc) {
    this._strUnitDesc = a_strUnitDesc;
  }
  public String getUnitId() {
    return _strUnitId;
  }
  public void setUnitId(String a_strUnitId) {
    this._strUnitId = a_strUnitId;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }
  public String getUnitExpr() {
    return _strUnitExpr;
  }
  public void setUnitExpr(String a_strUnitExpr) {
    this._strUnitExpr = a_strUnitExpr;
  }
  public Short getMonthFrom() {
    return _nMonthFrom;
  }
  public void setMonthFrom(Short a_nMonthFrom) {
    this._nMonthFrom = a_nMonthFrom;
  }
  public Short getMonthTo() {
    return _nMonthTo;
  }
  public void setMonthTo(Short a_nMonthTo) {
    this._nMonthTo = a_nMonthTo;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_lUnitDefnSeqNbr:" + _lUnitDefnSeqNbr + "\n";
    retValue = retValue + "_strUnitId:" + _strUnitId + "\n";
    retValue = retValue + "_strUnitDesc:" + _strUnitDesc + "\n";
    retValue = retValue + "_strBaseParamId:" + _strBaseParamId + "\n";
    retValue = retValue + "_cStartBracket:" + _cStartBracket + "\n";
    retValue = retValue + "_lLowValue:" + _lLowValue + "\n";
    retValue = retValue + "_lHighValue:" + _lHighValue + "\n";
    retValue = retValue + "_nOperator:" + _nOperator + "\n";
    retValue = retValue + "_cEndBracket:" + _cEndBracket + "\n";
    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";
    retValue = retValue + "_nMonthFrom:" + _nMonthFrom + "\n";
    retValue = retValue + "_nMonthTo:" + _nMonthTo + "\n";
    retValue = retValue + "_strUnitExpr:" + _strUnitExpr + "\n";

    return retValue;
  }

	public Short getIsLogOrArith(){
		return _nIsLogOrArith;
	}

	public void setIsLogOrArith(Short short1){
		_nIsLogOrArith = short1;
	}

}
