/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: UnitFetch.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/



/**
 * UnitFetch is the Utility Class for fetching parameter for Unit
 * Copyright (c) 2002 Mastek Ltd
 * Date       20/09/2002
 * @author    Pallav Laddha
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.formulaengine.util;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;
public class UnitFetch
{
  //private Logger log = Logger.getInstance(Constants.CHANNELMODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

  /**
   * Constructor of the UnitFetch class
   */
  public UnitFetch()
  {

  }


  /**
   * This Fetches all the paramater for Unit except primary key
   * @param a_oRequest HttpServletRequest object.
   * @return ArrayList
   * @throws EElixirException
   */
  public UnitResultMain fetchUnit(HttpServletRequest a_oRequest) {
    UnitResult oUnitResult = null;
    UnitResultMain oUnitResultMain = new UnitResultMain();
    log.debug("UnitFetch--Inside Unit Fetch");

    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");
	String strUnitId  = "";

    if (a_oRequest.getParameter("strUnitId") !=null)
    {
    	strUnitId    = a_oRequest.getParameter("strUnitId").trim();
    }

    String strUnitDesc  = a_oRequest.getParameter("strUnitDesc").trim();
    String strUnitExpr  = a_oRequest.getParameter("strUnitExpr").trim();
    Short nIsInclOrExcl   = new Short(a_oRequest.getParameter("nIsInclOrExcl").trim());
    String nIsLogOrArith = a_oRequest.getParameter("nIsLogOrArith");  


    ArrayList arrUnit = null;

    log.debug("UnitFetch--Fetching details of Unit");
    String[] strBaseParamID = a_oRequest.getParameterValues("strBaseParamID");
    String[] nMonthFrom     = a_oRequest.getParameterValues("nMonthFrom");
    String[] nMonthTo       = a_oRequest.getParameterValues("nMonthTo");
    String[] cStartBracket = a_oRequest.getParameterValues("cStartBracket"); //char
    String[] cEndBracket = a_oRequest.getParameterValues("cEndBracket"); //char
    String[] nOperator = a_oRequest.getParameterValues("nOperator"); //short
    String[] cOperator = a_oRequest.getParameterValues("cOperator"); //short
    String[] lHighValue = a_oRequest.getParameterValues("lHighValue"); //double
    String[] PKValue = a_oRequest.getParameterValues("PKValue"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlag"); //String
    String[] nCompOper = a_oRequest.getParameterValues("strCompOperator");
    String[] unit_dtUpdated = a_oRequest.getParameterValues("unit_dtUpdated");

   // if minimum one of the status flag is not of type clear mode then
    // initialize arrProdMix
    if(strBaseParamID != null){
      for(int i = 0; i<strBaseParamID.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          arrUnit = new ArrayList();
          break;
        }
      }
    }

    if(arrUnit != null){
      for(int i = 0; i<strBaseParamID.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){

          oUnitResult = new UnitResult();

		  if(strStatusFlag[i].trim().equals(DataConstants.UPDATE_MODE)){
			oUnitResult.setIsDirty(DataConstants.UPDATE_MODE);
		  }
		  else if(strStatusFlag[i].trim().equals(DataConstants.INSERT_MODE)){
			oUnitResult.setIsDirty(DataConstants.DISPLAY_MODE);
		  }
          oUnitResult.setUserId(_strUserId);
          oUnitResult.setUnitId(strUnitId);
          oUnitResult.setUnitDesc(strUnitDesc);
          oUnitResult.setUnitExpr(strUnitExpr);
          oUnitResult.setIsLogOrArith(new Short(nIsLogOrArith));
          if(! PKValue[i].trim().equals("")){
            oUnitResult.setUnitDefnSeqNbr(new Long(PKValue[i].trim()));
            log.debug("UnitFetch--PKValue[" + i + "]" + PKValue[i]);
          }
          oUnitResult.setBaseParamId(strBaseParamID[i]);
          if(cStartBracket[i].trim().equals("")){
            oUnitResult.setStartBracket(new Character(' '));
          }
          else{
            oUnitResult.setStartBracket(new Character(cStartBracket[i].trim().charAt(0)));
          }

          if(cEndBracket[i].trim().equals("")){
            oUnitResult.setEndBracket(new Character(' '));
          }
          else{
            oUnitResult.setEndBracket(new Character(cEndBracket[i].trim().charAt(0)));
          }
          
			
		if(Integer.parseInt(nIsLogOrArith) == DataConstants.LOGICAL_EXPRESSION)
		{
			if(! nOperator[i].trim().equals(""))
			{
				oUnitResult.setOperator(new Short(nOperator[i].trim()));
			}
			if(! nCompOper[i].trim().equals(""))
	  	    {
			    oUnitResult.setCompOper(new Short(nCompOper[i].trim()));
			}
		}
		else if (Integer.parseInt(nIsLogOrArith) == DataConstants.ARITHMETIC_EXPRESSION)
		{
			if(!cOperator[i].trim().equals(""))
			{
				oUnitResult.setOperator(new Short(cOperator[i].trim()));
			}
			oUnitResult.setCompOper(null);
		}
          
          log.debug("UnitFetch--nOperator[i].trim()" + nOperator[i].trim());

         /* if(! lLowValue[i].trim().equals("")){
            oUnitResult.setLowValue(new Long(lLowValue[i].trim()));
          }*/
          if(! lHighValue[i].trim().equals("")){
            oUnitResult.setHighValue(new Long(lHighValue[i].trim()));
          }
          oUnitResult.setMonthFrom(new Short(nMonthFrom[i].trim()));
          oUnitResult.setMonthTo(new Short(nMonthTo[i].trim()));
          oUnitResult.setStatusFlag(strStatusFlag[i]);
          oUnitResult.setIsInclOrExcl(nIsInclOrExcl);
          log.debug("UNIT FETCH ---got the dtupdated for unit " + unit_dtUpdated[i]);
          if (unit_dtUpdated[i] != null && !unit_dtUpdated[i].trim().equals(""))
          {
            oUnitResult.setTsDtUpdated(Timestamp.valueOf(unit_dtUpdated[i]));
          }
          log.debug("UnitFetch--strStatusFlag[" + i + "]" + strStatusFlag[i]);
          arrUnit.add(oUnitResult);
        }
      }
    }
    log.debug("UnitFetch--Fetched details of Unit");

    oUnitResultMain.setArrUnitDetail(arrUnit);
    if(nIsInclOrExcl.shortValue() != DataConstants.INCLUDE_EXCLUDE_NA){
      oUnitResultMain.setArrUnitProductMix(productMixFetch(a_oRequest,strUnitId));
    }
    return oUnitResultMain;
  }

   /**
   * This method fetches all the details of ProductMix.
   * @return ArrayList ArrayList of ProductMix
   * @param a_oRequest HttpServletRequest
   * @param a_strUnitId String
   */
  private ArrayList productMixFetch(HttpServletRequest a_oRequest, String a_strUnitId){
    ArrayList arrUnitProductMix = null;
    UnitProductMixResult oUnitProductMixResult = null;
    HttpSession session = a_oRequest.getSession();
    String _strUserId = (String)session.getAttribute("username");

    log.debug("UnitFetch--Fetching details of Unit Product Mix");
    String[] strProdCdVer = a_oRequest.getParameterValues("strProdCdVer");
    //String[] lbenseqnbr = a_oRequest.getParameterValues("lbenseqnbr"); //double
    String[] strProdPerc = a_oRequest.getParameterValues("dProdPerc"); //double
    String[] strStatusFlag = a_oRequest.getParameterValues("statusFlagP"); //String
    String[] prodmix_dtUpdated = a_oRequest.getParameterValues("prodmix_dtUpdated"); //String

    // if minimum one of the status flag is not of type clear mode then
    // initialize arrProdMix
    if(strProdCdVer != null){
      for(int i = 0; i<strProdCdVer.length ; i++){
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){
          arrUnitProductMix = new ArrayList(10);
          break;
        }
      }
    }
    log.debug("productMixFetch--Checking Clear Mode flag");

    if(arrUnitProductMix != null){
      for(int i = 0; i<strProdCdVer.length ; i++){
        log.debug("UnitFetch--strStatusFlag[i]" + strStatusFlag[i]);
        if(!strStatusFlag[i].trim().equals(DataConstants.CLEAR_MODE)){

          oUnitProductMixResult = new UnitProductMixResult();
          log.debug("UnitFetch--Before Getting ProdCd and Ver");
          StringTokenizer st = new StringTokenizer(strProdCdVer[i],"|");
          String strProdCd = null;
          String strProdVer = null;
          while(st.hasMoreTokens()){
            strProdCd = (String)st.nextElement();
            break;
          }
          while(st.hasMoreTokens()){
            strProdVer = (String)st.nextElement();
            break;
          }
          Integer iProdVer = null;
          if(strProdVer != null){
            iProdVer = new Integer(strProdVer);
          }
          log.debug("UnitFetch--After Getting ProdCd and Ver");
          oUnitProductMixResult.setUnitId(a_strUnitId);
          oUnitProductMixResult.setProdCd(strProdCd);
          oUnitProductMixResult.setProdVer(iProdVer);
          oUnitProductMixResult.setStatusFlag(strStatusFlag[i]);
          oUnitProductMixResult.setUserId(_strUserId);

          log.debug("UNIT FETCH -- Prodmix --got the dtupdated for prod mix " + prodmix_dtUpdated[i]);
          if (prodmix_dtUpdated[i] != null && !prodmix_dtUpdated[i].trim().equals("") )
          {
            oUnitProductMixResult.setTsDtUpdated(Timestamp.valueOf(prodmix_dtUpdated[i]));
          }
         log.debug("UnitFetch--After setting ProdCd and Ver");
          if (strProdPerc[i] != null)
          {
	          if (!strProdPerc[i].trim().equals(""))
	          {
          		oUnitProductMixResult.setProdPerc(new Double(strProdPerc[i].trim()));
          	  }
          }
          log.debug("UnitFetch--After setting dProdPerc");
          arrUnitProductMix.add(oUnitProductMixResult);
        }
      }
    }
    log.debug("UnitFetch--Fetched details of Unit Product Mix");
    return arrUnitProductMix;
  }
}