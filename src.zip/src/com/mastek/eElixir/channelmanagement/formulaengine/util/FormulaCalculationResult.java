/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FormulaCalculationResult.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for FormulaCalculation Formula</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.formulaengine.util;

import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;
public class FormulaCalculationResult extends UserData implements Serializable
{
  protected Long      _lFormlCalcSeqNbr  = null;
  protected Long      _lFormlDefnSeqNbr  = null;
  protected String    _strBaseParamId    = null;
  protected Character _cStartBracket     = null;
  protected Short     _nOperator         = null;
  protected Double    _dValue            = null;
  protected Character _cEndBracket       = null;
  protected String    _strStatusFlag     = null;

  public FormulaCalculationResult()
  {

  }

  public String getBaseParamId() {
    return _strBaseParamId;
  }
  public void setBaseParamId(String a_strBaseParamId) {
    this._strBaseParamId = a_strBaseParamId;
  }
  public Character getEndBracket() {
    return _cEndBracket;
  }
  public void setEndBracket(Character a_cEndBracket) {
    this._cEndBracket = a_cEndBracket;
  }
  public Character getStartBracket() {
    return _cStartBracket;
  }
  public void setStartBracket(Character a_cStartBracket) {
    this._cStartBracket = a_cStartBracket;
  }

  public Short getOperator() {
    return _nOperator;
  }
  public void setOperator(Short a_nOperator) {
    this._nOperator = a_nOperator;
  }

  public Double getValue() {
    return _dValue;
  }
  public void setValue(Double a_dValue) {
    this._dValue = a_dValue;
  }
  public Long getFormlCalcSeqNbr() {
    return _lFormlCalcSeqNbr;
  }
  public void setFormlCalcSeqNbr(Long a_lFormlCalcSeqNbr) {
    this._lFormlCalcSeqNbr = a_lFormlCalcSeqNbr;
  }
  public Long getFormlDefnSeqNbr() {
    return _lFormlDefnSeqNbr;
  }
  public void setFormlDefnSeqNbr(Long a_lFormlDefnSeqNbr) {
    this._lFormlDefnSeqNbr = a_lFormlDefnSeqNbr;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_lFormlCalcSeqNbr:" + _lFormlCalcSeqNbr + "\n";
    retValue = retValue + "_lFormlDefnSeqNbr:" + _lFormlDefnSeqNbr + "\n";
    retValue = retValue + "_strBaseParamId:" + _strBaseParamId + "\n";
    retValue = retValue + "_cStartBracket:" + _cStartBracket + "\n";
    retValue = retValue + "_nOperator:" + _nOperator + "\n";
    retValue = retValue + "_dValue:" + _dValue + "\n";
    retValue = retValue + "_cEndBracket:" + _cEndBracket + "\n";
    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";

    return retValue;
  }

}
