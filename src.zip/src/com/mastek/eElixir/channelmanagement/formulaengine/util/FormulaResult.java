/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: FormulaResult.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Formula Result</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.formulaengine.util;

import java.io.Serializable;
import java.util.ArrayList;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class FormulaResult extends UserData implements Serializable{
   protected Long      _lFormlDefnSeqNbr              = null;
   protected String    _strFormlId                    = null;
   protected String    _strFormlDesc                  = null;
   protected ArrayList _arrFormulaCalculation         = null;
   protected ArrayList _arrFormulaEligibilityCriteria = null;
   protected String    _strCalcExpr                   = null;
   protected String    _strElgbleExpr                 = null;
   protected String    _strUnitId					  = null;


   public FormulaResult()
   {

   }

   public Long getFormlDefnSeqNbr() {
     return _lFormlDefnSeqNbr;
   }
   public void setFormlDefnSeqNbr(Long a_lFormlDefnSeqNbr) {
     this._lFormlDefnSeqNbr = a_lFormlDefnSeqNbr;
   }
   public String getFormlId() {
     return _strFormlId;
   }
   public void setFormlId(String a_strFormlId) {
     this._strFormlId = a_strFormlId;
   }
   public String getFormlDesc() {
     return _strFormlDesc;
   }
   public void setFormlDesc(String a_strFormlDesc) {
     this._strFormlDesc = a_strFormlDesc;
   }
   public ArrayList getFormulaCalculation() {
     return _arrFormulaCalculation;
   }
   public void setFormulaCalculation(ArrayList a_arrFormulaCalculation) {
     this._arrFormulaCalculation = a_arrFormulaCalculation;
   }
   public ArrayList getFormulaEligibilityCriteria() {
     return _arrFormulaEligibilityCriteria;
   }
   public void setFormulaEligibilityCriteria(ArrayList a_arrFormulaEligibilityCriteria) {
     this._arrFormulaEligibilityCriteria = a_arrFormulaEligibilityCriteria;
   }
   public String getCalcExpr() {
     return _strCalcExpr;
   }
   public void setCalcExpr(String a_strCalcExpr) {
     this._strCalcExpr = a_strCalcExpr;
  }
  public String getElgbleExpr() {
    return _strElgbleExpr;
  }
  public void setElgbleExpr(String a_strElgbleExpr) {
    this._strElgbleExpr = a_strElgbleExpr;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_lFormlDefnSeqNbr:" + _lFormlDefnSeqNbr + "\n";
    retValue = retValue + "_strFormlId:" + _strFormlId + "\n";
    retValue = retValue + "_strFormlDesc:" + _strFormlDesc + "\n";
    retValue = retValue + "_arrFormulaCalculation:" + _arrFormulaCalculation + "\n";
    retValue = retValue + "_arrFormulaEligibilityCriteria:" + _arrFormulaEligibilityCriteria + "\n";
    retValue = retValue + "_strCalcExpr:" + _strCalcExpr + "\n";
    retValue = retValue + "_strElgbleExpr:" + _strElgbleExpr + "\n";
	retValue = retValue + "_strUnitId:" + _strUnitId + "\n";
    return retValue;
  }
  public String getUnitId() {
	return _strUnitId;
  }
  public void setUnitId(String string) {
		_strUnitId = string;
	}

}
