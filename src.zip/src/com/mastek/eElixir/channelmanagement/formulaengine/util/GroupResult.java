/********************************************************************
*
*  PROJECT			: PRUDENTIAL
*  MODULE NAME		        : CHANNEL MANAGEMENT
*  FILENAME			: GroupResult.java
*  AUTHOR			: Pallav Laddha
*  VERSION			: 1.0
*  CREATION DATE	        : October 20, 2002
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT		        : COPYRIGHT (C) 2002.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:Result object for Group Result</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */


package com.mastek.eElixir.channelmanagement.formulaengine.util;

import java.io.Serializable;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class GroupResult extends UserData implements Serializable
{

  protected Long      _lCritDefnSeqNbr = null;
  protected String    _strUnitId       = null;
  protected String    _strGroupId      = null;
  protected String    _strGroupDesc    = null;
  protected Character _cStartBracket   = null;
  protected Short     _nOperator       = null;
  protected Character _cEndBracket     = null;
  protected String    _strStatusFlag    = null;
  protected String    _strGroupExpr    = null;
  protected String 	  _strGroupExprDesc = null;

  public GroupResult()
  {

  }

  public String getGroupExprDesc() {
    return _strGroupExprDesc;
  }
  public void setGroupExprDesc(String a_strGroupExprDesc) {
    this._strGroupExprDesc = a_strGroupExprDesc;
  }
  
  public Character getEndBracket() {
    return _cEndBracket;
  }
  public void setEndBracket(Character a_cEndBracket) {
    this._cEndBracket = a_cEndBracket;
  }
  public Character getStartBracket() {
    return _cStartBracket;
  }
  public void setStartBracket(Character a_cStartBracket) {
    this._cStartBracket = a_cStartBracket;
  }
  public Long getCritDefnSeqNbr() {
    return _lCritDefnSeqNbr;
  }
  public void setCritDefnSeqNbr(Long a_lCritDefnSeqNbr) {
    this._lCritDefnSeqNbr = a_lCritDefnSeqNbr;
  }
  public Short getOperator() {
    return _nOperator;
  }
  public void setOperator(Short a_nOperator) {
    this._nOperator = a_nOperator;
  }
  public String getGroupDesc() {
    return _strGroupDesc;
  }
  public void setGroupDesc(String a_strGroupDesc) {
    this._strGroupDesc = a_strGroupDesc;
  }
  public String getUnitId() {
    return _strUnitId;
  }
  public void setUnitId(String a_strUnitId) {
    this._strUnitId = a_strUnitId;
  }
  public String getGroupId() {
    return _strGroupId;
  }
  public void setGroupId(String a_strGroupId) {
    this._strGroupId = a_strGroupId;
  }
  public String getStatusFlag() {
    return _strStatusFlag;
  }
  public void setStatusFlag(String a_strStatusFlag) {
    this._strStatusFlag = a_strStatusFlag;
  }
  public String getGroupExpr() {
    return _strGroupExpr;
  }
  public void setGroupExpr(String a_strGroupExpr) {
    this._strGroupExpr = a_strGroupExpr;
  }

  public String toString(){
    String retValue = "";
    retValue = retValue + "_lCritDefnSeqNbr:" + _lCritDefnSeqNbr + "\n";
    retValue = retValue + "_strUnitId:" + _strUnitId + "\n";
    retValue = retValue + "_strGroupId:" + _strGroupId + "\n";
    retValue = retValue + "_strGroupDesc:" + _strGroupDesc + "\n";
    retValue = retValue + "_cStartBracket:" + _cStartBracket + "\n";
    retValue = retValue + "_nOperator:" + _nOperator + "\n";
    retValue = retValue + "_cEndBracket:" + _cEndBracket + "\n";
    retValue = retValue + "_strStatusFlag:" + _strStatusFlag + "\n";
    retValue = retValue + "_strGroupExpr:" + _strGroupExpr + "\n";

    return retValue;
  }

}
