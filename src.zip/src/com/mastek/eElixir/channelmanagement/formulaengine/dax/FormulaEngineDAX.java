/********************************************************************
 *
 *  PROJECT			: PRUDENTIAL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME			: FormulaEngineDAX.java
 *  AUTHOR			: Pallav Laddha
 *  VERSION			: 1.0
 *  CREATION DATE	        : October 20, 2002
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT		        : COPYRIGHT (C) 2002.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.formulaengine.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaCalculationResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaEligibilityCriteriaResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.FormulaResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.GroupResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitProductMixResult;
import com.mastek.eElixir.channelmanagement.formulaengine.util.UnitResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SearchData;
import com.mastek.eElixir.common.util.SqlRepositoryIF;
import com.mastek.eElixir.common.util.XMLConverter;

/**
 * <p>Title: eElixir</p>
 * <p>Description:The DAX implementaion for the FormulaEngine object </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Mastek Ltd</p>
 * @author Pallav
 * @version 1.0
 */

public class FormulaEngineDAX extends DAX
{
  /**
   * Constructor
   */
  public FormulaEngineDAX()
  {

  }

//  ////////////////// Unit Part Starts ////////////////////////// //
  /**
   * Populates the resultset into XML string object
   * @param a_oResultObject Object
   * @return XML string object
   * @throws EElixirException
   */

  public String getUnit(Object a_oResultObject) throws EElixirException
  {
    log.debug("FormulaEngineDAX--Inside getUnit of DAX");
    PreparedStatement pstmtSearchUnit = null;
    HashMap hmQueryMap = new HashMap();
    SearchData oSearchData = (SearchData)a_oResultObject;
    log.debug("FormulaEngineDAX--Search Data" + oSearchData);
    try
    {
      String strUnitId = oSearchData.getTask1();
      String strUnitDesc = oSearchData.getTask2();

      log.debug("FormulaEngineDAX--after Search Data");
      String strSearchUnitQuery = getSQLString("Select",CHMConstants.UNIT_LIST_SEARCH);

      hmQueryMap.put("Main",strSearchUnitQuery);

      strSearchUnitQuery = " AND strUnitId LIKE  ? " ;
      hmQueryMap.put("UNITID",strSearchUnitQuery);

      strSearchUnitQuery = " AND strUnitDesc LIKE  ? " ;
      hmQueryMap.put("UNITDESC",strSearchUnitQuery);

      String strQuery = (String)hmQueryMap.get("Main");
      log.debug("FormulaEngineDAX--Strquery =" + strQuery);
      if (strUnitId != null && !strUnitId.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("UNITID");
      }
      if (strUnitDesc!= null && !strUnitDesc.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("UNITDESC");
      }

      log.debug("FormulaEngineDAX--Strquery =" + strQuery);
      strQuery = strQuery + " order by strUnitId";
      pstmtSearchUnit = getPreparedStatement(strQuery);
      log.debug("FormulaEngineDAX--Query Formed  " + strQuery);

      int iPosition = 0 ;
      if (strUnitId!= null && !strUnitId.trim().equals("")) {
        log.debug("FormulaEngineDAX--Adding strUnitId " );
        pstmtSearchUnit.setString(++iPosition,"%" + strUnitId.trim().toUpperCase() + "%");
      }
      if (strUnitDesc != null && !strUnitDesc.trim().equals("")) {
        log.debug("FormulaEngineDAX--Adding strUnitDesc" );
        pstmtSearchUnit.setString(++iPosition,"%" + strUnitDesc.trim().toUpperCase() + "%");
      }
      ResultSet rsSearch = executeQuery(pstmtSearchUnit);
      return XMLConverter.getXMLString(rsSearch);
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5001");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5001");
    }
    finally
    {
      try
      {
        if(pstmtSearchUnit != null)
          pstmtSearchUnit.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }


  /**
    * Inserts a new record
    * @param a_oUnitResult UnitResult
    * @throws EElixirException
    */
   public String createUnit(UnitResult a_oUnitResult) throws EElixirException
   {
     PreparedStatement pstmtCreateUnit = null;
     try
     {

       String strUnitId      = a_oUnitResult.getUnitId().trim().toUpperCase();
       log.debug("FormulaEngineDAX--unit id got " + strUnitId);



       String strUnitDesc       = a_oUnitResult.getUnitDesc().trim().toUpperCase();
       String strUnitExpr       = a_oUnitResult.getUnitExpr().trim();
       String strBaseParamID       = a_oUnitResult.getBaseParamId();
       Character cStartBracket       = a_oUnitResult.getStartBracket();
       Long lLowValue       = a_oUnitResult.getLowValue();
       Long lHighValue       = a_oUnitResult.getHighValue();
       Character cEndBracket       = a_oUnitResult.getEndBracket();
       Short nOperator       = a_oUnitResult.getOperator();
       Short nMonthFrom     = a_oUnitResult.getMonthFrom();
       Short nMonthTo      = a_oUnitResult.getMonthTo();
       String strCreatedBy = a_oUnitResult.getUserId();
       Short nCompOper      = a_oUnitResult.getCompOper();
       Short nInclOrExcl   = a_oUnitResult.getIsInclOrExcl();


       // Before inserting a new record this function generates a new Seq no, on which the
       // new record is inserted.
       long lUnitDefnSeqNbr = getNextSeqNbr(DataConstants.UNIT_TYPE);
       String strCreateQuery = getSQLString("Insert",CHMConstants.UNIT_INSERT);

       log.debug("FormulaEngineDAX--strCreateQuery =" + strCreateQuery);
       pstmtCreateUnit = getPreparedStatement(strCreateQuery);

       pstmtCreateUnit.setLong(1,lUnitDefnSeqNbr);
       pstmtCreateUnit.setString(2,strUnitId);
       pstmtCreateUnit.setString(3,strUnitDesc);
       if(strBaseParamID != null && !strBaseParamID.trim().equals(""))
       {
	       pstmtCreateUnit.setString(4,strBaseParamID);
       }
       else
       {
		   pstmtCreateUnit.setNull(4,Types.VARCHAR);
       }
       pstmtCreateUnit.setString(5,(cStartBracket.charValue() + "").trim());
       if(lLowValue == null){
         pstmtCreateUnit.setNull(6,java.sql.Types.INTEGER);
       }
       else{
         pstmtCreateUnit.setLong(6,lLowValue.longValue());
       }
       if(lHighValue == null){
         pstmtCreateUnit.setNull(7,java.sql.Types.INTEGER);
       }
       else{
         pstmtCreateUnit.setLong(7,lHighValue.longValue());
       }
       pstmtCreateUnit.setString(8,(cEndBracket.charValue() + "").trim());
       if(nOperator == null){
         pstmtCreateUnit.setNull(9,java.sql.Types.INTEGER);
       }
       else{
         pstmtCreateUnit.setShort(9,nOperator.shortValue());
       }
       pstmtCreateUnit.setString(10,strUnitExpr);
       pstmtCreateUnit.setShort(11,nMonthFrom.shortValue());
       pstmtCreateUnit.setShort(12,nMonthTo.shortValue());
		if(nCompOper != null)
		{
			pstmtCreateUnit.setShort(13,nCompOper.shortValue());       
		}
		else
		{
			pstmtCreateUnit.setNull(13,Types.INTEGER);
		}
       
       pstmtCreateUnit.setString(14,strCreatedBy);
       pstmtCreateUnit.setShort(15,nInclOrExcl.shortValue());
	   pstmtCreateUnit.setShort(16,a_oUnitResult.getIsLogOrArith().shortValue());
       executeUpdate(pstmtCreateUnit);
	   return strUnitId;
     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5002");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw eex;
     }
     finally
     {
       try
       {
         if(pstmtCreateUnit != null)
           pstmtCreateUnit.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       }
     }
  }
  //this method will create the product mix defined in the unit module added on 29th March 2003
  public String createUnitProdMix(UnitProductMixResult a_oUnitProductMixResult) throws EElixirException{
   PreparedStatement pstmtCreateProductMix = null;
   try
   {
     String strCreateProductMixQuery = getSQLString("Insert",CHMConstants.UNIT_PRODUCT_MIX_INSERT);
     pstmtCreateProductMix = getPreparedStatement(strCreateProductMixQuery);

     pstmtCreateProductMix.setString(1,a_oUnitProductMixResult.getUnitId());
     pstmtCreateProductMix.setString(2,a_oUnitProductMixResult.getProdCd());
     pstmtCreateProductMix.setInt(3,a_oUnitProductMixResult.getProdVer().intValue());
     pstmtCreateProductMix.setDouble(4,a_oUnitProductMixResult.getProdPerc().doubleValue());
     pstmtCreateProductMix.setString(5,a_oUnitProductMixResult.getUserId());
     int icount = executeUpdate(pstmtCreateProductMix);
     log.debug("FormulaEngineDAX--insert of Product mix");
     return a_oUnitProductMixResult.getUnitId();
   }
   catch(SQLException sqlex){
     log.fatal(sqlex.getMessage());
     //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     throw new EElixirException(sqlex, "P9506");
   }
   /*
   catch(EElixirException eex)
   {
     log.fatal(eex.getMessage());
     throw new EElixirException(eex,"P9506");
   }
   */
   finally
   {
     try
     {
       if(pstmtCreateProductMix != null)
         pstmtCreateProductMix.close();
     }
     catch(SQLException sqlex)
     {
       log.fatal(sqlex.getMessage());
       throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     }
   }
 }

  public void updateUnitProdMix(UnitProductMixResult a_oUnitProductMixResult) throws EElixirException
  {
	PreparedStatement pstmtUpdateUnit = null;
    try
    {
      log.debug("FormulaEngineDAX--inside update unit");

      String strUnitId      = a_oUnitProductMixResult.getUnitId().trim().toUpperCase();
      log.debug("FormulaEngineDAX--strUnitId" + strUnitId);
      Double dProdPerc   = a_oUnitProductMixResult.getProdPerc();
      log.debug("FormulaEngineDAX--Product Percentage" + dProdPerc);
      String strProdCd       = a_oUnitProductMixResult.getProdCd().trim().toUpperCase();
      log.debug("FormulaEngineDAX--strProdCd" + strProdCd);
      Integer iProductVer      = a_oUnitProductMixResult.getProdVer();
      log.debug("FormulaEngineDAX--iProductVer" + iProductVer);

      String strUserId = a_oUnitProductMixResult.getUserId();
      log.debug("FormulaEngineDAX--userid" + strUserId);

      String strUpdateQuery = getSQLString("Update",CHMConstants.UNIT_PRODUCT_MIX_UPDATE);
      log.debug("FormulaEngineDAX--StrUpdateQuery =" + strUpdateQuery);

      pstmtUpdateUnit = getPreparedStatement(strUpdateQuery);
      //pstmtUpdateUnit.setString(1,strUnitId);
      //pstmtUpdateUnit.setString(1,strUnitDesc);
      pstmtUpdateUnit.setDouble(1,dProdPerc.doubleValue());
      log.debug("FormulaEngineDAX--After setting product perc");
      pstmtUpdateUnit.setString(2,strUserId);
      log.debug("FormulaEngineDAX--After setting cStartBracket");
      pstmtUpdateUnit.setString(3,strUnitId);
      pstmtUpdateUnit.setString(4,strProdCd);
      pstmtUpdateUnit.setInt(5,iProductVer.intValue());

      int icount = executeUpdate(pstmtUpdateUnit);
       log.debug("FormulaEngineDAX--" + icount);
	}
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5003");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5003");
    }
    finally
    {
      try
      {
        if(pstmtUpdateUnit != null)
          pstmtUpdateUnit.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

  public String getNextUnitId() throws EElixirException
  {
	  log.debug("in get next unit id method..");
	  Statement stmtNextSeq = null;
      String strSeqNo;
      try
      {
        String strNextSeqQuery = null;

        strNextSeqQuery = getSQLString("Select",CHMConstants.UNIT_SEQUENCE_NUMBER);
       	log.debug("got query as " + strNextSeqQuery);
        stmtNextSeq = getStatement();
        ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
        rsSeqNo.next();
        strSeqNo = rsSeqNo.getString(1);
        log.debug("got seq nbr as " +strSeqNo  );
        log.debug(strSeqNo + "");
	        while(strSeqNo.length() <= 4)
	       {
		       strSeqNo = "0" + strSeqNo;
	       }
	       strSeqNo = "U" + strSeqNo;
		log.debug("returning this --> " +strSeqNo  );
        return strSeqNo;
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P5026");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P5026");
      }
      finally
      {
        try
        {
          if(stmtNextSeq != null)
            stmtNextSeq.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
  }

   /**
   * Updates the Unit
   * @return int No of rows updated
   * @param: a_oUnitResult UnitResult
   * @throws EElixirException
   */
  public int updateUnit(UnitResult a_oUnitResult) throws EElixirException
  {
    PreparedStatement pstmtUpdateUnit = null;
    try
    {
      log.debug("FormulaEngineDAX--inside update unit");
      Long lUnitDefnSeqNbr = a_oUnitResult.getUnitDefnSeqNbr();
      log.debug("FormulaEngineDAX--lUnitDefnSeqNbr" + lUnitDefnSeqNbr);
      String strUnitId      = a_oUnitResult.getUnitId().trim().toUpperCase();
      log.debug("FormulaEngineDAX--strUnitId" + strUnitId);
      String strUnitDesc       = a_oUnitResult.getUnitDesc().trim().toUpperCase();
      log.debug("FormulaEngineDAX--strUnitDesc" + strUnitDesc);
      String strUnitExpr       = a_oUnitResult.getUnitExpr().trim();
      log.debug("FormulaEngineDAX--strUnitExpr" + strUnitExpr);
      String strBaseParamID       = a_oUnitResult.getBaseParamId();
      log.debug("FormulaEngineDAX--strBaseParamID" + strBaseParamID);
      Character cStartBracket       = a_oUnitResult.getStartBracket();
      log.debug("FormulaEngineDAX--cStartBracket" + cStartBracket);
      //Long lLowValue       = a_oUnitResult.getLowValue();
      //log.debug("FormulaEngineDAX--lLowValue" + lLowValue);
      Short nCompOper = a_oUnitResult.getCompOper();
      log.debug("FormulaEngineDAX--nCompOper" + nCompOper);

      Long lHighValue       = a_oUnitResult.getHighValue();
      log.debug("FormulaEngineDAX--lHighValue" + lHighValue);
      Character cEndBracket       = a_oUnitResult.getEndBracket();
      log.debug("FormulaEngineDAX--cEndBracket" + cEndBracket);
      Short nOperator       = a_oUnitResult.getOperator();
      log.debug("FormulaEngineDAX--nOperator" + nOperator);

      Short nMonthFrom     = a_oUnitResult.getMonthFrom();
      Short nMonthTo      = a_oUnitResult.getMonthTo();

      String strUpdatedBy = a_oUnitResult.getUserId();
      log.debug("FormulaEngineDAX--strUpdatedBy" + strUpdatedBy);
      Short nIsinclOrExcl = a_oUnitResult.getIsInclOrExcl();

      String strUpdateQuery = getSQLString("Update",CHMConstants.UNIT_UPDATE);
      log.debug("FormulaEngineDAX--StrUpdateQuery =" + strUpdateQuery);

      pstmtUpdateUnit = getPreparedStatement(strUpdateQuery);
      if(strBaseParamID != null && !strBaseParamID.trim().equals(""))
      {
		pstmtUpdateUnit.setString(1,strBaseParamID);
      }
      else
      {
		pstmtUpdateUnit.setNull(1,Types.VARCHAR);
      }
      
      log.debug("FormulaEngineDAX--After setting strBaseParamID");
      pstmtUpdateUnit.setString(2,(cStartBracket.charValue() + "").trim());
      log.debug("FormulaEngineDAX--After setting cStartBracket");
      if(nCompOper == null){
        pstmtUpdateUnit.setNull(3,java.sql.Types.INTEGER);
      }
      else{
        pstmtUpdateUnit.setShort(3,nCompOper.shortValue());
      }
      log.debug("FormulaEngineDAX--After setting lLowValue");
      if(lHighValue == null){
        pstmtUpdateUnit.setNull(4,java.sql.Types.LONGVARCHAR);
      }
      else{
        pstmtUpdateUnit.setLong(4,lHighValue.longValue());
      }
      log.debug("FormulaEngineDAX--After setting lHighValue");

      pstmtUpdateUnit.setString(5,(cEndBracket.charValue() + "").trim());
      log.debug("FormulaEngineDAX--After setting cEndBracket");
      if(nOperator == null){
        pstmtUpdateUnit.setNull(6,java.sql.Types.INTEGER);
      }
      else{
        pstmtUpdateUnit.setShort(6,nOperator.shortValue());
      }
      log.debug("FormulaEngineDAX--After setting nOperator");
      pstmtUpdateUnit.setString(7,strUnitExpr);
      log.debug("FormulaEngineDAX--After setting strUnitExpr");
      pstmtUpdateUnit.setString(8,strUnitDesc);
      pstmtUpdateUnit.setShort(9,nMonthFrom.shortValue());
      pstmtUpdateUnit.setShort(10,nMonthTo.shortValue());

      pstmtUpdateUnit.setString(11,strUpdatedBy);
      log.debug("FormulaEngineDAX--After setting strUpdatedBy");

      pstmtUpdateUnit.setShort(12,nIsinclOrExcl.shortValue());
      log.debug("FormulaEngineDAX--After setting including or excluding");
      //method to call is to delete all the products for this unit if selected is n/a
      if (nIsinclOrExcl.intValue() == DataConstants.INCLUDE_EXCLUDE_NA)
      {
	      deleteUnitProdMixAll(strUnitId);
	  }
		
	  pstmtUpdateUnit.setShort(13,a_oUnitResult.getIsLogOrArith().shortValue());		
      pstmtUpdateUnit.setLong(14,lUnitDefnSeqNbr.longValue());

      log.debug("FormulaEngineDAX--After setting lUnitDefnSeqNbr");
      int icount = executeUpdate(pstmtUpdateUnit);
       log.debug("FormulaEngineDAX--" + icount);
       return icount;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5003");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5003");
    }
    finally
    {
      try
      {
        if(pstmtUpdateUnit != null)
          pstmtUpdateUnit.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

 public void deleteUnitProdMixAll(String strUnitId) throws EElixirException
 {
	 	PreparedStatement pstmtRemoveUnitProdMixAll = null;
       try
       {
         log.debug("FormulaEngineDAX-- Inside remove Unit Product");
         String strRemoveQuery = getSQLString("Delete",CHMConstants.UNIT_PROD_MIX_DELETE_ALL);
         pstmtRemoveUnitProdMixAll = getPreparedStatement(strRemoveQuery);
         pstmtRemoveUnitProdMixAll.setString(1,strUnitId);
         int iRemove = executeUpdate(pstmtRemoveUnitProdMixAll);
         log.debug("FormulaEngineDAX-- remove Unit product count " + iRemove);
       }
       catch(SQLException sqlex){
         log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         throw new EElixirException(sqlex, "P5007");
       }
       catch(EElixirException eex)
       {
         log.exception(eex.getMessage());
         throw new EElixirException(eex,"P5007");
       }
       finally
       {
         try
         {

           if(pstmtRemoveUnitProdMixAll != null)
             pstmtRemoveUnitProdMixAll.close();

         }
         catch(SQLException sqlex)
         {
           log.exception(sqlex.getMessage());
           throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         }
       }
 }

 public void removeUnitProdMix(String strUnitId,String strProdCd,Integer iProdVer) throws EElixirException
 {
	   PreparedStatement pstmtRemoveUnitProdMix = null;
       try
       {
         log.debug("FormulaEngineDAX-- Inside remove Unit Product");
         String strRemoveQuery = getSQLString("Delete",CHMConstants.UNIT_PROD_MIX_DELETE);
         log.debug("FormulaEngineDAX-- Inside remove Unitgot string as " + strRemoveQuery);

         pstmtRemoveUnitProdMix = getPreparedStatement(strRemoveQuery);
         log.debug("FormulaEngineDAX-- Inside remove settng variables as " +strUnitId + " "+ strProdCd + " "+ iProdVer);
         pstmtRemoveUnitProdMix.setString(1,strUnitId);
         pstmtRemoveUnitProdMix.setString(2,strProdCd);
         pstmtRemoveUnitProdMix.setInt(3,iProdVer.intValue());

         int iRemove = executeUpdate(pstmtRemoveUnitProdMix);
         log.debug("FormulaEngineDAX-- remove Unit product count " + iRemove);
       }
       catch(SQLException sqlex){
         log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         throw new EElixirException(sqlex, "P5007");
       }
       catch(EElixirException eex)
       {
         log.exception(eex.getMessage());
         throw new EElixirException(eex,"P5007");
       }
       finally
       {
         try
         {

           if(pstmtRemoveUnitProdMix != null)
             pstmtRemoveUnitProdMix.close();

         }
         catch(SQLException sqlex)
         {
           log.exception(sqlex.getMessage());
           throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         }
       }
 }

/**
 * getUnitProdMix gets the UnitProductMix Details
 * @return ArrayList
 * @param a_strUnitId String
 * @throws EElixirException
 */
public ArrayList getUnitProdMix(String a_strUnitId) throws EElixirException {
// Now the part of Product Mix
    PreparedStatement pstmtSearchProductMix = null;
    ResultSet rsSearchProductMix = null;
    ArrayList arrProductMix = null;
    try
    {
      log.debug("FormulaEngineDAX-- Now the part for Product Mix");
      String strSelectProductMixQuery = getSQLString("Select",CHMConstants.UNIT_PRODUCT_MIX_SEARCH);
      log.debug("FormulaEngineDAX--search query is "+ strSelectProductMixQuery);
      pstmtSearchProductMix = getPreparedStatement(strSelectProductMixQuery);
      pstmtSearchProductMix.setString(1,a_strUnitId);

      rsSearchProductMix = executeQuery(pstmtSearchProductMix);
      log.debug("FormulaEngineDAX--Query executed properly");
      arrProductMix = new ArrayList(10);
      int count = 0;
      while(rsSearchProductMix.next())
      {
        UnitProductMixResult oUnitProductMixResult = new UnitProductMixResult();
        /*to avoid update*/
        oUnitProductMixResult.setIsDirty(DataConstants.DISPLAY_MODE);
        oUnitProductMixResult.setUnitId(a_strUnitId);
        oUnitProductMixResult.setProdCd(rsSearchProductMix.getString("STRPRODCD"));
        oUnitProductMixResult.setProdVer(new Integer(rsSearchProductMix.getInt("IPRODVER")));
        oUnitProductMixResult.setProdPerc(new Double(rsSearchProductMix.getDouble("DPRODPERC")));
        oUnitProductMixResult.setTsDtUpdated(rsSearchProductMix.getTimestamp("dtupdated"));
        arrProductMix.add(oUnitProductMixResult);
        count++;
      }
      log.debug("FormulaEngineDAX--Count for no of oContestProductMix obtained is :" + count);
      if(count == 0){
        arrProductMix = null;
      }
      return arrProductMix;
    }
    catch(SQLException sqlex){
        throw new EElixirException(sqlex, "P5033");
      }
     finally
      {
        try
        {
          if(rsSearchProductMix != null)
            rsSearchProductMix.close();

          if(pstmtSearchProductMix != null)
            pstmtSearchProductMix.close();
        }
        catch(SQLException sqlex)
        {
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
    }

  public ArrayList getUnit(String a_strUnitId) throws EElixirException
  {
    ResultSet rsSearchUnit = null;
    ArrayList arrUnitResult = null;
    UnitResult oUnitResult = null;
    PreparedStatement pstmtSearchUnit = null;
    HashMap hm = new HashMap();
    String unitExpression = "";
    try
    {
      String strSelectUnitQuery = getSQLString("Select",CHMConstants.UNIT_SEARCH_BY_UNIT_ID);
      log.debug("FormulaEngineDAX--search query is "+ strSelectUnitQuery);
      pstmtSearchUnit = getPreparedStatement(strSelectUnitQuery);
      pstmtSearchUnit.setString(1,a_strUnitId);
      rsSearchUnit = executeQuery(pstmtSearchUnit);
      log.debug("FormulaEngineDAX--Query executed properly");

      int count = 0;
      arrUnitResult = new ArrayList(10);
      while(rsSearchUnit.next())
      {
        oUnitResult = new UnitResult();
        oUnitResult.setUnitId(a_strUnitId);
        oUnitResult.setUnitDefnSeqNbr(new Long(rsSearchUnit.getLong(1)));
        oUnitResult.setBaseParamId(rsSearchUnit.getString(2));

        if(rsSearchUnit.getString(3) == null){
            oUnitResult.setStartBracket(new Character(' '));
        }
        else if(rsSearchUnit.getString(3).trim().equals("")){
          oUnitResult.setStartBracket(new Character(' '));
        }
        else{
          oUnitResult.setStartBracket(new Character(rsSearchUnit.getString(3).trim().charAt(0)));
        }

        log.debug("FormulaEngineDAX--rsSearchUnit.getString(4):" + rsSearchUnit.getShort(4));
        short cOper = rsSearchUnit.getShort(4);
        if(rsSearchUnit.wasNull()){
           oUnitResult.setCompOper(null);
        }
        else{
          oUnitResult.setCompOper(new Short(cOper));
        }

        long l = rsSearchUnit.getLong(5);
        if(rsSearchUnit.wasNull()){
           oUnitResult.setHighValue(null);
        }
        else{
          oUnitResult.setHighValue(new Long(l));
        }

        if(rsSearchUnit.getString(6) == null){
            oUnitResult.setEndBracket(new Character(' '));
        }
        else if(rsSearchUnit.getString(6).trim().equals("")){
          oUnitResult.setEndBracket(new Character(' '));
        }
        else{
          oUnitResult.setEndBracket(new Character(rsSearchUnit.getString(6).trim().charAt(0)));
        }

        short s = rsSearchUnit.getShort(7);
        if(rsSearchUnit.wasNull()){
           oUnitResult.setOperator(null);
        }
        else{
          oUnitResult.setOperator(new Short(s));
        }

        oUnitResult.setUnitDesc(rsSearchUnit.getString(8));
        oUnitResult.setUnitExpr(rsSearchUnit.getString(9));
        oUnitResult.setMonthFrom(new Short(rsSearchUnit.getShort(10)));
        oUnitResult.setMonthTo(new Short(rsSearchUnit.getShort(11)));
        oUnitResult.setIsInclOrExcl(new Short(rsSearchUnit.getShort("NISINCLOREXCL")));
        oUnitResult.setTsDtUpdated(rsSearchUnit.getTimestamp("dtupdated"));
		oUnitResult.setIsLogOrArith(new Short(rsSearchUnit.getShort("NISLOGORARITH")));

        //adding sandeep
        unitExpression = oUnitResult.getUnitExpr();
        hm.put(oUnitResult.getBaseParamId(),rsSearchUnit.getString("strBaseParamDesc"));
        //adding finished
        log.debug("FormulaEngineDAX--Unit filled");
        arrUnitResult.add(oUnitResult);
        count++;
      }
      if(count == 0){
         arrUnitResult = null;
      }
      else
      {//adding sandeep
	   StringTokenizer st = new StringTokenizer(unitExpression);
	   String unitExpressionDesc = "";
	   	while (st.hasMoreTokens())
	   	{
		   	String presentToken = st.nextToken();
	   		if(hm.containsKey(presentToken))
			{
				unitExpressionDesc = unitExpressionDesc +" "+ (String)hm.get(presentToken);
			}
			else
			{
				unitExpressionDesc = unitExpressionDesc +" " + presentToken;
			}
		}
		log.debug("FormulaEngineDAX--expression formed " + unitExpressionDesc);
		for(int i=0;i<arrUnitResult.size();i++)
		{
			oUnitResult = (UnitResult)arrUnitResult.get(i);
			oUnitResult.setBaseParamDesc(unitExpressionDesc);
			arrUnitResult.set(i,oUnitResult);
		}
      }

      return arrUnitResult;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5004");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5004");
    }
    finally
    {
      try
      {
        if(rsSearchUnit != null)
          rsSearchUnit.close();

        if(pstmtSearchUnit != null)
          pstmtSearchUnit.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
   }

   /**
    * getUnit gets the Unit Details
    * @return UnitResult
    * @param a_lUnitDefnSeqNbr long
    * @throws EElixirException
    */
   public UnitResult getUnit(long a_lUnitDefnSeqNbr) throws EElixirException
   {
     ResultSet rsSearchUnit = null;
     UnitResult oUnitResult = null;
     PreparedStatement pstmtSearchUnit = null;
     try
     {
       String strSelectUnitQuery = getSQLString("Select",CHMConstants.UNIT_SEARCH_BY_SEQ_NO);
       log.debug("FormulaEngineDAX--search query is "+ strSelectUnitQuery);
       pstmtSearchUnit = getPreparedStatement(strSelectUnitQuery);
       pstmtSearchUnit.setLong(1,a_lUnitDefnSeqNbr);
       rsSearchUnit = executeQuery(pstmtSearchUnit);
       log.debug("FormulaEngineDAX--Query executed properly");

       int count = 0;
       if(rsSearchUnit.next())
       {
         oUnitResult = new UnitResult();
		 /* CHANGE TO AVOID UPDATE  */
		 oUnitResult.setIsDirty(DataConstants.DISPLAY_MODE);
         oUnitResult.setUnitDefnSeqNbr(new Long(a_lUnitDefnSeqNbr));
         oUnitResult.setUnitId(rsSearchUnit.getString(1));
         oUnitResult.setBaseParamId(rsSearchUnit.getString(2));
         log.debug("FormulaEngineDAX--rsSearchUnit.getString(3):" + rsSearchUnit.getString(3));
         if(rsSearchUnit.getString(3) == null){
             oUnitResult.setStartBracket(new Character(' '));
         }
         else if(rsSearchUnit.getString(3).trim().equals("")){
           oUnitResult.setStartBracket(new Character(' '));
         }
         else{
           oUnitResult.setStartBracket(new Character(rsSearchUnit.getString(3).trim().charAt(0)));
         }

         long l = rsSearchUnit.getLong(4);
         if(rsSearchUnit.wasNull()){
            oUnitResult.setLowValue(null);
         }
         else{
           oUnitResult.setLowValue(new Long(l));
         }

         l = rsSearchUnit.getLong(5);
         if(rsSearchUnit.wasNull()){
            oUnitResult.setHighValue(null);
         }
         else{
           oUnitResult.setHighValue(new Long(l));
         }

         if(rsSearchUnit.getString(6) == null){
             oUnitResult.setEndBracket(new Character(' '));
         }
         else if(rsSearchUnit.getString(6).trim().equals("")){
           oUnitResult.setEndBracket(new Character(' '));
         }
         else{
           oUnitResult.setEndBracket(new Character(rsSearchUnit.getString(6).trim().charAt(0)));
         }

         short s = rsSearchUnit.getShort(7);
         if(rsSearchUnit.wasNull()){
            oUnitResult.setOperator(null);
         }
         else{
           oUnitResult.setOperator(new Short(s));
         }

         oUnitResult.setUnitDesc(rsSearchUnit.getString(8));
         oUnitResult.setUnitExpr(rsSearchUnit.getString(9));
         oUnitResult.setMonthFrom(new Short(rsSearchUnit.getShort(10)));
         oUnitResult.setMonthTo(new Short(rsSearchUnit.getShort(11)));
         oUnitResult.setTsDtUpdated(rsSearchUnit.getTimestamp("dtupdated"));
         log.debug("FormulaEngineDAX--Unit filled");
       }
       return oUnitResult;
     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
       //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       throw new EElixirException(sqlex, "P5004");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw new EElixirException(eex,"P5004");
     }
     finally
     {
       try
       {
         if(rsSearchUnit != null)
           rsSearchUnit.close();

         if(pstmtSearchUnit != null)
           pstmtSearchUnit.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       }
     }
    }


   /**
     * findUnit finds whether the unit is there or not
     * @return boolean
     * @param a_strUnitId String
     * @throws EElixirException
     */
    public boolean findUnit(String a_strUnitId) throws EElixirException
    {
      ResultSet rsSearchUnit = null;
      PreparedStatement pstmtFindPrimaryKey = null;
       log.debug("FormulaEngineDAX--Inside find unit of a_strUnitId" + a_strUnitId);
      try
      {
        String strSelectUnitQuery = getSQLString("Select",CHMConstants.FIND_UNITID_BY_PRIMARYKEY);
        if(pstmtFindPrimaryKey == null)
        {
          pstmtFindPrimaryKey = getPreparedStatement(strSelectUnitQuery);
        }
        pstmtFindPrimaryKey.setString(1,a_strUnitId.toUpperCase());

        rsSearchUnit = executeQuery(pstmtFindPrimaryKey);
        if(rsSearchUnit.next())
        {
          log.debug("FormulaEngineDAX--returning true for unit");
          return true;
        }
        else
        {
          log.debug("FormulaEngineDAX--returning false for unit");
          return false;
        }
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P5005");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P5005");
      }
      finally
      {
        try
        {
          if(rsSearchUnit != null)
            rsSearchUnit.close();

          if(pstmtFindPrimaryKey != null)
            pstmtFindPrimaryKey.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
    }


    /**
      * findUnit finds whether the unit is there or not
      * @return boolean
      * @param a_lUnitDefnSeqNbr long
      * @throws EElixirException
      */
     public boolean findUnit(long a_lUnitDefnSeqNbr) throws EElixirException
     {
       ResultSet rsSearchUnit = null;
       PreparedStatement pstmtFindPrimaryKey = null;
       log.debug("FormulaEngineDAX--Inside find unit of seqNo" + a_lUnitDefnSeqNbr);
       try
       {
         String strSelectUnitQuery = getSQLString("Select",CHMConstants.FIND_UNITSEQ_BY_PRIMARYKEY);
         if(pstmtFindPrimaryKey == null)
         {
           pstmtFindPrimaryKey = getPreparedStatement(strSelectUnitQuery);
         }
         pstmtFindPrimaryKey.setLong(1,a_lUnitDefnSeqNbr);

         rsSearchUnit = executeQuery(pstmtFindPrimaryKey);
         if(rsSearchUnit.next())
         {
           return true;
         }
         else
         {
           return false;
         }
       }
       catch(SQLException sqlex){
         log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         throw new EElixirException(sqlex, "P5006");
       }
       catch(EElixirException eex)
       {
         log.exception(eex.getMessage());
         throw new EElixirException(eex,"P5006");
       }
       finally
       {
         try
         {
           if(rsSearchUnit != null)
             rsSearchUnit.close();

           if(pstmtFindPrimaryKey != null)
             pstmtFindPrimaryKey.close();
         }
         catch(SQLException sqlex)
         {
           log.exception(sqlex.getMessage());
           throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         }
       }
     }


     /**
      * Removes the selected Unit
      * @return int No of rows removed
      * @param: a_lUnitDefnSeqNbr long
      * @throws EElixirException
      */
     public int removeUnit(long a_lUnitDefnSeqNbr) throws EElixirException
     {
       PreparedStatement pstmtRemoveUnit = null;
       try
       {
         log.debug("FormulaEngineDAX-- Inside remove Unit");
         String strRemoveQuery = getSQLString("Delete",CHMConstants.UNIT_DELETE);
         pstmtRemoveUnit = getPreparedStatement(strRemoveQuery);
         pstmtRemoveUnit.setLong(1,a_lUnitDefnSeqNbr);
         int iRemove = executeUpdate(pstmtRemoveUnit);
         return iRemove;
       }
       catch(SQLException sqlex){
         log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         throw new EElixirException(sqlex, "P5007");
       }
       catch(EElixirException eex)
       {
         log.exception(eex.getMessage());
         throw new EElixirException(eex,"P5007");
       }
       finally
       {
         try
         {

           if(pstmtRemoveUnit != null)
             pstmtRemoveUnit.close();

         }
         catch(SQLException sqlex)
         {
           log.exception(sqlex.getMessage());
           throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         }
       }

     }

     /**
      * findUnit finds whether the unit is there or not
      * @return boolean
      * @param a_lUnitDefnSeqNbr long
      * @throws EElixirException
      */
     public boolean findUnitProdMix(String strUnitId) throws EElixirException
     {
       ResultSet rsSearchUnit = null;
       PreparedStatement pstmtFindPrimaryKey = null;
       log.debug("FormulaEngineDAX--Inside find unit of seqNo" + strUnitId);
       try
       {
         String strSelectUnitQuery = getSQLString("Select",CHMConstants.FIND_UNIT_PROD_MIX_BY_UNIT_ID);
         if(pstmtFindPrimaryKey == null)
         {
           pstmtFindPrimaryKey = getPreparedStatement(strSelectUnitQuery);
         }
         pstmtFindPrimaryKey.setString(1,strUnitId);
         rsSearchUnit = executeQuery(pstmtFindPrimaryKey);
         rsSearchUnit.next();
         if(rsSearchUnit.getInt(1) > 0)
         {
           return true;
         }
         else
         {
           return false;
         }
       }
       catch(SQLException sqlex){
         log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         throw new EElixirException(sqlex, "P5006");
       }
       catch(EElixirException eex)
       {
         log.exception(eex.getMessage());
         throw new EElixirException(eex,"P5006");
       }
       finally
       {
         try
         {
           if(rsSearchUnit != null)
             rsSearchUnit.close();

           if(pstmtFindPrimaryKey != null)
             pstmtFindPrimaryKey.close();
         }
         catch(SQLException sqlex)
         {
           log.exception(sqlex.getMessage());
           throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         }
       }
     }
     /**
      * findUnit finds whether the unit is there or not
      * @return boolean
      * @param a_lUnitDefnSeqNbr long
      * @throws EElixirException
      */
     public boolean findUnitProdMix(String strUnitId,String strProdCd,Integer iProdVer) throws EElixirException
     {
       ResultSet rsSearchUnit = null;
       PreparedStatement pstmtFindPrimaryKey = null;
       log.debug("FormulaEngineDAX--Inside find unit prod mix 3 params" + strUnitId + strProdCd + iProdVer);
       try
       {
         String strSelectUnitQuery = getSQLString("Select",CHMConstants.FIND_UNIT_PROD_MIX_FOR_DELETE);
         if(pstmtFindPrimaryKey == null)
         {
           pstmtFindPrimaryKey = getPreparedStatement(strSelectUnitQuery);
         }

		 pstmtFindPrimaryKey.setString(1,strUnitId);
		 pstmtFindPrimaryKey.setString(2,strProdCd);
		 pstmtFindPrimaryKey.setInt(3,iProdVer.intValue());

		 rsSearchUnit = executeQuery(pstmtFindPrimaryKey);
         rsSearchUnit.next();
         if(rsSearchUnit.getInt(1) > 0)
         {
           return true;
         }
         else
         {
           return false;
         }
       }
       catch(SQLException sqlex){
         log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         throw new EElixirException(sqlex, "P5006");
       }
       catch(EElixirException eex)
       {
         log.exception(eex.getMessage());
         throw new EElixirException(eex,"P5006");
       }
       finally
       {
         try
         {
           if(rsSearchUnit != null)
             rsSearchUnit.close();

           if(pstmtFindPrimaryKey != null)
             pstmtFindPrimaryKey.close();
         }
         catch(SQLException sqlex)
         {
           log.exception(sqlex.getMessage());
           throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         }
       }
     }

     public UnitProductMixResult getUnitProdMix(String strUnitId,String strProdCd,Integer iProdVer) throws EElixirException
     {
       ResultSet rsSearchUnitProdMix = null;
       PreparedStatement pstmtFindPrimaryKey = null;
       UnitProductMixResult oUnitProductMixResult = null;
       log.debug("FormulaEngineDAX--Inside find unit prod mix 3 params" + strUnitId + strProdCd + iProdVer);
       try
       {
         String strSelectUnitQuery = getSQLString("Select",CHMConstants.FIND_UNI_PROD_MIX);
         if(pstmtFindPrimaryKey == null)
         {
           pstmtFindPrimaryKey = getPreparedStatement(strSelectUnitQuery);
         }

         pstmtFindPrimaryKey.setString(1,strUnitId);
         pstmtFindPrimaryKey.setString(2,strProdCd);
         pstmtFindPrimaryKey.setInt(3,iProdVer.intValue());

         rsSearchUnitProdMix = executeQuery(pstmtFindPrimaryKey);
         if (rsSearchUnitProdMix.next())
         {
           oUnitProductMixResult = new UnitProductMixResult();
           oUnitProductMixResult.setUnitId(rsSearchUnitProdMix.getString("STRUNITID"));
           oUnitProductMixResult.setProdCd(rsSearchUnitProdMix.getString("STRPRODCD"));
           oUnitProductMixResult.setProdVer(new Integer(rsSearchUnitProdMix.getInt("IPRODVER")));
           oUnitProductMixResult.setProdPerc(new Double(rsSearchUnitProdMix.getInt("DPRODPERC")));
           oUnitProductMixResult.setTsDtUpdated(rsSearchUnitProdMix.getTimestamp("DTUPDATED"));
         }
         return oUnitProductMixResult;
       }
       catch(SQLException sqlex){
         log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         throw new EElixirException(sqlex, "P5006");
       }
       catch(EElixirException eex)
       {
         log.exception(eex.getMessage());
         throw new EElixirException(eex,"P5006");
       }
       finally
       {
         try
         {
           if(rsSearchUnitProdMix != null)
             rsSearchUnitProdMix.close();

           if(pstmtFindPrimaryKey != null)
             pstmtFindPrimaryKey.close();
         }
         catch(SQLException sqlex)
         {
           log.exception(sqlex.getMessage());
           throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         }
       }
     }
//  ////////////////// Unit Part Ends ////////////////////////// //
//  ////////////////// Group Part Starts ////////////////////////// //

  /**
   * Populates the resultset into XML string object
   * @param a_oResultObject Object
   * @return XML string object
   * @throws EElixirException
   */

  public String getGroup(Object a_oResultObject) throws EElixirException
  {
    log.debug("FormulaEngineDAX--Inside getGroup of DAX");
    PreparedStatement pstmtSearchGroup = null;
    Statement st = null ;
    StringBuffer sb = new StringBuffer();
    HashMap hmQueryMap = new HashMap();
    SearchData oSearchData = (SearchData)a_oResultObject;
    log.debug("FormulaEngineDAX--Search Data" + oSearchData);
    try
    {
      String strGroupId = oSearchData.getTask1();
      String strGroupDesc = oSearchData.getTask2();

      log.debug("FormulaEngineDAX--after Search Data");
      String strSearchGroupQuery = getSQLString("Select",CHMConstants.GROUP_LIST_SEARCH);

      hmQueryMap.put("Main",strSearchGroupQuery);

      strSearchGroupQuery = " AND strGroupId LIKE  ? " ;
      hmQueryMap.put("GROUPID",strSearchGroupQuery);

      strSearchGroupQuery = " AND strGroupDesc LIKE  ? " ;
      hmQueryMap.put("GROUPDESC",strSearchGroupQuery);

      String strQuery = (String)hmQueryMap.get("Main");
      log.debug("FormulaEngineDAX--Strquery =" + strQuery);
      if (strGroupId != null && !strGroupId.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("GROUPID");
      }
      if (strGroupDesc!= null && !strGroupDesc.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("GROUPDESC");
      }

      log.debug("FormulaEngineDAX--Strquery =" + strQuery);
      strQuery = strQuery + " order by strGroupId";
      pstmtSearchGroup = getPreparedStatement(strQuery);
      log.debug("FormulaEngineDAX--Query Formed  " + strQuery);

      int iPosition = 0 ;
      if (strGroupId!= null && !strGroupId.trim().equals("")) {
        log.debug("FormulaEngineDAX--Adding strGroupId " );
        pstmtSearchGroup.setString(++iPosition,"%" + strGroupId.trim().toUpperCase() + "%");
      }
      if (strGroupDesc != null && !strGroupDesc.trim().equals("")) {
        log.debug("FormulaEngineDAX--Adding strGroupDesc" );
        pstmtSearchGroup.setString(++iPosition,"%" + strGroupDesc.trim().toUpperCase() + "%");
      }
      ResultSet rsSearch = executeQuery(pstmtSearchGroup);
      return XMLConverter.getXMLString(rsSearch);
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5008");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5008");
    }
    finally
    {
      try
      {
        if(pstmtSearchGroup != null)
          pstmtSearchGroup.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }

/* *********************************************************************************** */
//this method will genereate the group Id from oracle sequence
public String getNextGroupId() throws EElixirException
  {
	  Statement stmtNextSeq = null;
      String strSeqNo;
      try
      {
        String strNextSeqQuery = null;

        strNextSeqQuery = getSQLString("Select",CHMConstants.GROUP_SEQUENCE_NUMBER);

        stmtNextSeq = getStatement();
        ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
        rsSeqNo.next();
        strSeqNo = rsSeqNo.getString(1);
        log.debug(strSeqNo + "");
	        while(strSeqNo.length() <= 4)
	       {
		       strSeqNo = "0" + strSeqNo;
	       }
	       strSeqNo = "G" + strSeqNo;

        return strSeqNo;
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P5026");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P5026");
      }
      finally
      {
        try
        {
          if(stmtNextSeq != null)
            stmtNextSeq.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
  }
 /**
   * Inserts a new record
   * @param a_oGroupResult GroupResult
   * @throws EElixirException
   */
  public String createGroup(GroupResult a_oGroupResult) throws EElixirException
  {
    PreparedStatement pstmtCreateGroup = null;
    try
    {
      String strUnitId         = a_oGroupResult.getUnitId().trim().toUpperCase();
      String strGroupId        = a_oGroupResult.getGroupId().trim().toUpperCase();
      String strGroupDesc      = a_oGroupResult.getGroupDesc().trim().toUpperCase();
      String strGroupExpr      = a_oGroupResult.getGroupExpr().trim();
      Character cStartBracket  = a_oGroupResult.getStartBracket();
      Character cEndBracket    = a_oGroupResult.getEndBracket();
      Short nOperator          = a_oGroupResult.getOperator();
      String strCreatedBy      = a_oGroupResult.getUserId();

      // Before inserting a new record this function generates a new Seq no, on which the
      // new record is inserted.
      long lCritDefnSeqNbr = getNextSeqNbr(DataConstants.GROUP_TYPE);
      String strCreateQuery = getSQLString("Insert",CHMConstants.GROUP_INSERT);

      log.debug("FormulaEngineDAX--strCreateQuery =" + strCreateQuery);
      pstmtCreateGroup = getPreparedStatement(strCreateQuery);

      pstmtCreateGroup.setLong(1,lCritDefnSeqNbr);
      pstmtCreateGroup.setString(2,strUnitId);
      pstmtCreateGroup.setString(3,strGroupId);
      pstmtCreateGroup.setString(4,strGroupDesc);
      pstmtCreateGroup.setString(5,(cStartBracket.charValue() + "").trim());
      pstmtCreateGroup.setString(6,(cEndBracket.charValue() + "").trim());
      if(nOperator == null){
        pstmtCreateGroup.setNull(7,java.sql.Types.INTEGER);
      }
      else{
        pstmtCreateGroup.setShort(7,nOperator.shortValue());
      }
      pstmtCreateGroup.setString(8,strGroupExpr);
      pstmtCreateGroup.setString(9,strCreatedBy);

      int icount = executeUpdate(pstmtCreateGroup);
      log.debug("FormulaEngineDAX--" + icount);

	  return strGroupId;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
       //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     throw new EElixirException(sqlex, "P5009");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw eex;
    }
    finally
    {
      try
      {
        if(pstmtCreateGroup != null)
          pstmtCreateGroup.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
 }


 /**
  * Updates the Group
  * @return int No of rows updated
  * @param: a_oGroupResult GroupResult
  * @throws EElixirException
  */
 public int updateGroup(GroupResult a_oGroupResult) throws EElixirException
 {
   PreparedStatement pstmtUpdateGroup = null;
   try
   {

     Long lCritDefnSeqNbr    = a_oGroupResult.getCritDefnSeqNbr();
     String strUnitId        = a_oGroupResult.getUnitId().trim().toUpperCase();
     String strGroupId       = a_oGroupResult.getGroupId().trim().toUpperCase();
     String strGroupDesc     = a_oGroupResult.getGroupDesc().trim().toUpperCase();
     String strGroupExpr     = a_oGroupResult.getGroupExpr().trim();
     Character cStartBracket = a_oGroupResult.getStartBracket();
     Character cEndBracket   = a_oGroupResult.getEndBracket();
     Short nOperator         = a_oGroupResult.getOperator();
     String strUpdatedBy     = a_oGroupResult.getUserId();

     String strUpdateQuery = getSQLString("Update",CHMConstants.GROUP_UPDATE);
     log.debug("FormulaEngineDAX--strUpdateQuery =" + strUpdateQuery);
      pstmtUpdateGroup = getPreparedStatement(strUpdateQuery);
     //pstmtUpdateGroup.setString(2,strGroupId);
     //pstmtUpdateGroup.setString(2,strGroupDesc);
     pstmtUpdateGroup.setString(1,strUnitId);
     pstmtUpdateGroup.setString(2,(cStartBracket.charValue() + "").trim());
     pstmtUpdateGroup.setString(3,(cEndBracket.charValue() + "").trim());

     if(nOperator == null){
       pstmtUpdateGroup.setNull(4,java.sql.Types.INTEGER);
     }
     else{
       pstmtUpdateGroup.setShort(4,nOperator.shortValue());
     }
     pstmtUpdateGroup.setString(5,strGroupExpr);
     pstmtUpdateGroup.setString(6,strGroupDesc);
     pstmtUpdateGroup.setString(7,strUpdatedBy);
     pstmtUpdateGroup.setLong(8,lCritDefnSeqNbr.longValue());

     int icount = executeUpdate(pstmtUpdateGroup);
      log.debug("FormulaEngineDAX--" + icount);
      return icount;
   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     throw new EElixirException(sqlex, "P5010");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P5010");
   }
   finally
   {
     try
     {
       if(pstmtUpdateGroup != null)
         pstmtUpdateGroup.close();
     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     }
   }
 }

 /**
  * getGroup gets the Group Details
  * @return ArrayList
  * @param a_strGroupId String
  * @throws EElixirException
  */

 public ArrayList getGroup(String a_strGroupId) throws EElixirException
 {
   ResultSet rsSearchGroup = null;
   ArrayList arrGroupResult = null;
   GroupResult oGroupResult = null;
   PreparedStatement pstmtSearchGroup = null;
   HashMap hm = new HashMap();
   String strGroupExp = "";
   try
   {
     String strSelectGroupQuery = getSQLString("Select",CHMConstants.GROUP_SEARCH_BY_GROUP_ID);
     log.debug("FormulaEngineDAX--search query is "+ strSelectGroupQuery);
     pstmtSearchGroup = getPreparedStatement(strSelectGroupQuery);
     pstmtSearchGroup.setString(1,a_strGroupId);
     rsSearchGroup = executeQuery(pstmtSearchGroup);
     log.debug("FormulaEngineDAX--Query executed properly");

     int count = 0;
     arrGroupResult = new ArrayList(10);
     while(rsSearchGroup.next())
     {
       oGroupResult = new GroupResult();
       oGroupResult.setGroupId(a_strGroupId);
       oGroupResult.setCritDefnSeqNbr(new Long(rsSearchGroup.getLong(1)));
       oGroupResult.setUnitId(rsSearchGroup.getString(2));
       oGroupResult.setGroupDesc(rsSearchGroup.getString(3));

       if(rsSearchGroup.getString(4) == null){
           oGroupResult.setStartBracket(new Character(' '));
       }
       else if(rsSearchGroup.getString(4).trim().equals("")){
         oGroupResult.setStartBracket(new Character(' '));
       }
       else{
         oGroupResult.setStartBracket(new Character(rsSearchGroup.getString(4).trim().charAt(0)));
       }


       if(rsSearchGroup.getString(5) == null){
           oGroupResult.setEndBracket(new Character(' '));
       }
       else if(rsSearchGroup.getString(5).trim().equals("")){
         oGroupResult.setEndBracket(new Character(' '));
       }
       else{
         oGroupResult.setEndBracket(new Character(rsSearchGroup.getString(5).trim().charAt(0)));
        }

       short s = rsSearchGroup.getShort(6);
       if(rsSearchGroup.wasNull()){
          oGroupResult.setOperator(null);
       }
       else{
         oGroupResult.setOperator(new Short(s));
        }

       oGroupResult.setGroupExpr(rsSearchGroup.getString(7));
       oGroupResult.setTsDtUpdated(rsSearchGroup.getTimestamp("dtupdated"));
       log.debug("FormulaEngineDAX--Group filled");
       arrGroupResult.add(oGroupResult);
       hm.put(oGroupResult.getUnitId(),rsSearchGroup.getString("strunitdesc"));
       strGroupExp = oGroupResult.getGroupExpr();
       count++;
     }
     if(count == 0){
        arrGroupResult = null;
     }
     else
      {//adding sandeep
	   StringTokenizer st = new StringTokenizer(strGroupExp);
	   String groupExpressionDesc = "";
	   	while (st.hasMoreTokens())
	   	{
		   	String presentToken = st.nextToken();
	   		if(hm.containsKey(presentToken))
			{
				groupExpressionDesc = groupExpressionDesc +" "+ (String)hm.get(presentToken);
			}
			else
			{
				groupExpressionDesc = groupExpressionDesc +" " + presentToken;
			}
		}

		for(int i=0;i<arrGroupResult.size();i++)
		{
			oGroupResult = (GroupResult)arrGroupResult.get(i);
			oGroupResult.setGroupExprDesc(groupExpressionDesc);
			arrGroupResult.set(i,oGroupResult);
		}
      }

     return arrGroupResult;
   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     throw new EElixirException(sqlex, "P5011");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P5011");
   }
   finally
   {
     try
     {
       if(rsSearchGroup != null)
         rsSearchGroup.close();

       if(pstmtSearchGroup != null)
         pstmtSearchGroup.close();
     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     }
   }
  }


  /**
   * getGroup gets the Group Details
   * @return GroupResult
   * @param a_lCritDefnSeqNbr long
   * @throws EElixirException
   */

  public GroupResult getGroup(long a_lCritDefnSeqNbr) throws EElixirException
  {
    ResultSet rsSearchGroup = null;
    GroupResult oGroupResult = null;
    PreparedStatement pstmtSearchGroup = null;
    try
    {
      String strSelectGroupQuery = getSQLString("Select",CHMConstants.GROUP_SEARCH_BY_SEQ_NO);
      log.debug("FormulaEngineDAX--search query is "+ strSelectGroupQuery);
      pstmtSearchGroup = getPreparedStatement(strSelectGroupQuery);
      pstmtSearchGroup.setLong(1,a_lCritDefnSeqNbr);
      rsSearchGroup = executeQuery(pstmtSearchGroup);
      log.debug("FormulaEngineDAX--Query executed properly");

      int count = 0;
      while(rsSearchGroup.next())
      {
        oGroupResult = new GroupResult();
		/* CHANGE TO AVOID UPDATE  */
		oGroupResult.setIsDirty(DataConstants.DISPLAY_MODE);
        oGroupResult.setCritDefnSeqNbr(new Long(a_lCritDefnSeqNbr));
        oGroupResult.setGroupId(rsSearchGroup.getString(1));
        oGroupResult.setUnitId(rsSearchGroup.getString(2));
        oGroupResult.setGroupDesc(rsSearchGroup.getString(3));
        if(rsSearchGroup.getString(4) == null){
            oGroupResult.setStartBracket(new Character(' '));
        }
        else if(rsSearchGroup.getString(4).trim().equals("")){
          oGroupResult.setStartBracket(new Character(' '));
        }
        else{
          oGroupResult.setStartBracket(new Character(rsSearchGroup.getString(4).trim().charAt(0)));
        }


        if(rsSearchGroup.getString(5) == null){
            oGroupResult.setEndBracket(new Character(' '));
        }
        else if(rsSearchGroup.getString(5).trim().equals("")){
          oGroupResult.setEndBracket(new Character(' '));
        }
        else{
          oGroupResult.setEndBracket(new Character(rsSearchGroup.getString(5).trim().charAt(0)));
         }

        short s = rsSearchGroup.getShort(6);
        if(rsSearchGroup.wasNull()){
           oGroupResult.setOperator(null);
        }
        else{
          oGroupResult.setOperator(new Short(s));
         }
        oGroupResult.setGroupExpr(rsSearchGroup.getString(7));
        oGroupResult.setTsDtUpdated(rsSearchGroup.getTimestamp("dtupdated"));
        log.debug("FormulaEngineDAX--Group filled");
        count++;
      }
      return oGroupResult;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5011");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5011");
    }
    finally
    {
      try
      {
        if(rsSearchGroup != null)
          rsSearchGroup.close();

        if(pstmtSearchGroup != null)
          pstmtSearchGroup.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }




  /**
    * findGroup finds whether the Group is there or not
    * @return boolean
    * @param a_strGroupId String
    * @throws EElixirException
    */

   public boolean findGroup(String a_strGroupId) throws EElixirException
   {
     ResultSet rsSearchGroup = null;
     PreparedStatement pstmtFindPrimaryKey = null;
     try
     {
       String strSelectGroupQuery = getSQLString("Select",CHMConstants.FIND_GROUPID_BY_PRIMARYKEY);
       pstmtFindPrimaryKey = getPreparedStatement(strSelectGroupQuery);
       pstmtFindPrimaryKey.setString(1,a_strGroupId.toUpperCase());

       rsSearchGroup = executeQuery(pstmtFindPrimaryKey);
       if(rsSearchGroup.next())
       {
          log.debug("FormulaEngineDAX--returning true for group");
         return true;
       }
       else
       {
          log.debug("FormulaEngineDAX--returning false for group");
         return false;
       }
     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
       //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       throw new EElixirException(sqlex, "P5012");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw new EElixirException(eex,"P5012");
     }
     finally
     {
       try
       {
         if(rsSearchGroup != null)
           rsSearchGroup.close();

         if(pstmtFindPrimaryKey != null)
           pstmtFindPrimaryKey.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       }
     }
   }

   /**
     * findUnit finds whether the unit is there or not
     * @return boolean
     * @param a_lCritDefnSeqNbr long
     * @throws EElixirException
     */
    public boolean findGroup(long a_lCritDefnSeqNbr) throws EElixirException
    {
      ResultSet rsSearchGroup = null;
      PreparedStatement pstmtFindPrimaryKey = null;
      try
      {
        String strSelectGroupQuery = getSQLString("Select",CHMConstants.FIND_GROUPSEQ_BY_PRIMARYKEY);
        pstmtFindPrimaryKey = getPreparedStatement(strSelectGroupQuery);
        pstmtFindPrimaryKey.setLong(1,a_lCritDefnSeqNbr);

        rsSearchGroup = executeQuery(pstmtFindPrimaryKey);
        if(rsSearchGroup.next())
        {
          return true;
        }
        else
        {
          return false;
        }
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P5013");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P5013");
      }
      finally
      {
        try
        {
          if(rsSearchGroup != null)
            rsSearchGroup.close();

          if(pstmtFindPrimaryKey != null)
            pstmtFindPrimaryKey.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
    }

    /**
     * Removes the selected Unit
     * @return int No of rows removed
     * @param: a_lCritDefnSeqNbr long
     * @throws EElixirException
     */
    public int removeGroup(long a_lCritDefnSeqNbr) throws EElixirException
    {
      PreparedStatement pstmtRemoveGroup = null;
      try
      {
        log.debug("FormulaEngineDAX-- Inside remove Group");
        String strRemoveQuery = getSQLString("Delete",CHMConstants.GROUP_DELETE);
        pstmtRemoveGroup = getPreparedStatement(strRemoveQuery);
        pstmtRemoveGroup.setLong(1,a_lCritDefnSeqNbr);
        int iRemove = executeUpdate(pstmtRemoveGroup);
        return iRemove;
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P5014");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P5014");
      }
      finally
      {
        try
        {

          if(pstmtRemoveGroup != null)
            pstmtRemoveGroup.close();

        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }

    }
//  ////////////////// Group Part Ends ////////////////////////// //
//  ////////////////// Formula Part Starts ////////////////////////// //
 /* ************************************************************************************ */
  /**
   * Populates the resultset into XML string object
   * @param a_oResultObject Object
   * @return XML string object
   * @throws EElixirException
   */

  public String getFormula(Object a_oResultObject) throws EElixirException
  {
    log.debug("FormulaEngineDAX--Inside getForml of DAX");
    PreparedStatement pstmtSearchForml = null;
    Statement st = null ;
    StringBuffer sb = new StringBuffer();
    HashMap hmQueryMap = new HashMap();
    SearchData oSearchData = (SearchData)a_oResultObject;
    log.debug("FormulaEngineDAX--Search Data" + oSearchData);
    try
    {
      String strFormlId = oSearchData.getTask1();
      String strFormlDesc = oSearchData.getTask2();

      log.debug("FormulaEngineDAX--after Search Data");
      String strSearchFormulaQuery = getSQLString("Select",CHMConstants.FORMULA_LIST_SEARCH);

      hmQueryMap.put("Main",strSearchFormulaQuery);

      strSearchFormulaQuery = " AND strFormlId LIKE  ? " ;
      hmQueryMap.put("FORMLID",strSearchFormulaQuery);

      strSearchFormulaQuery = " AND strFormlDesc LIKE  ? " ;
      hmQueryMap.put("FORMLDESC",strSearchFormulaQuery);

      String strQuery = (String)hmQueryMap.get("Main");
      log.debug("FormulaEngineDAX--Strquery =" + strQuery);
      if (strFormlId != null && !strFormlId.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("FORMLID");
      }
      if (strFormlDesc!= null && !strFormlDesc.trim().equals("")) {
        strQuery += (String)hmQueryMap.get("FORMLDESC");
      }

      log.debug("FormulaEngineDAX--Strquery =" + strQuery);
      strQuery = strQuery + " order by strFormlId";
      pstmtSearchForml = getPreparedStatement(strQuery);
      log.debug("FormulaEngineDAX--Query Formed  " + strQuery);

      int iPosition = 0 ;
      if (strFormlId!= null && !strFormlId.trim().equals("")) {
        log.debug("FormulaEngineDAX--Adding strFormlId " );
        pstmtSearchForml.setString(++iPosition,"%" + strFormlId.trim().toUpperCase() + "%");
      }
      if (strFormlDesc != null && !strFormlDesc.trim().equals("")) {
        log.debug("FormulaEngineDAX--Adding strFormlDesc" );
        pstmtSearchForml.setString(++iPosition,"%" + strFormlDesc.trim().toUpperCase() + "%");
      }
      ResultSet rsSearch = executeQuery(pstmtSearchForml);
      return XMLConverter.getXMLString(rsSearch);
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5015");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5015");
    }
    finally
    {
      try
      {
        if(pstmtSearchForml != null)
          pstmtSearchForml.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
  }
//this method will genereate the formula Id from oracle sequence
public String getNextFormulaId() throws EElixirException
  {
	  Statement stmtNextSeq = null;
      String strSeqNo;
      try
      {
        String strNextSeqQuery = null;

        strNextSeqQuery = getSQLString("Select",CHMConstants.FORMULA_SEQUENCE_NUMBER);

        stmtNextSeq = getStatement();
        ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
        rsSeqNo.next();
        strSeqNo = rsSeqNo.getString(1);
        log.debug(strSeqNo + "");
	        while(strSeqNo.length() <= 4) // number of zeros to pad if the value is 1
	       {
		       strSeqNo = "0" + strSeqNo;
	       }
	       strSeqNo = "F" + strSeqNo;

        return strSeqNo;
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P5026");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P5026");
      }
      finally
      {
        try
        {
          if(stmtNextSeq != null)
            stmtNextSeq.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
  }

  /**
    * Inserts a new record
    * @param a_oFormulaResult FormulaResult
    * @return long Returns the next seq no generated on Formula table
    * @throws EElixirException
    */
   public long createFormula(FormulaResult a_oFormulaResult) throws EElixirException
   {
     PreparedStatement pstmtCreateFormula = null;
     ResultSet rsCreateFormula = null;
     ArrayList arrFormCalc = null;
     ArrayList arrFormElgble = null;
     long lFormlDefnSeqNbr;
     try
     {
      // String strFormlId           = a_oFormulaResult.getFormlId().trim().toUpperCase();
       String strFormlId = getNextFormulaId();
       String strFormlDesc         = a_oFormulaResult.getFormlDesc().trim().toUpperCase();
       String strElgbleExpr        = a_oFormulaResult.getElgbleExpr().trim();
       //String strCalcExpr          = a_oFormulaResult.getCalcExpr().trim();
       String strCreatedBy         = a_oFormulaResult.getUserId();

       arrFormCalc = a_oFormulaResult.getFormulaCalculation();
       arrFormElgble = a_oFormulaResult.getFormulaEligibilityCriteria();

       // Before inserting a new record this function generates a new Seq no, on which the
       // new record is inserted.
       lFormlDefnSeqNbr = getNextSeqNbr(DataConstants.FORMULA_HDR_TYPE);
       log.debug("FormulaEngineDAX--------------the dax created newkey----"+ lFormlDefnSeqNbr);

       String strCreateFormulaQuery = getSQLString("Insert",CHMConstants.FORMULA_INSERT);

       log.debug("FormulaEngineDAX--StrFormulaquery =" + strCreateFormulaQuery);
       pstmtCreateFormula = getPreparedStatement(strCreateFormulaQuery);

       pstmtCreateFormula.setLong(1,lFormlDefnSeqNbr);
       pstmtCreateFormula.setString(2,strFormlId);
       pstmtCreateFormula.setString(3,strFormlDesc);
       pstmtCreateFormula.setString(4,strElgbleExpr);
       pstmtCreateFormula.setNull(5,Types.VARCHAR);
       pstmtCreateFormula.setString(6,strCreatedBy);
	   pstmtCreateFormula.setString(7,a_oFormulaResult.getUnitId().trim());
       log.debug("FormulaEngineDAX--After setting all values");

       int icount = executeUpdate(pstmtCreateFormula);
       log.debug("FormulaEngineDAX--" + icount);
       log.debug("FormulaEngineDAX--------------the dax created newkey----"+ lFormlDefnSeqNbr);

       // Now inserting Calculation criteria
       log.debug("FormulaEngineDAX--Now inserting Calculation criteria");

       if(arrFormCalc != null){
         for(int i=0; i<arrFormCalc.size(); i++){
           FormulaCalculationResult oFormulaCalculationResult = (FormulaCalculationResult)arrFormCalc.get(i);
           insertFormulaCalc(oFormulaCalculationResult, lFormlDefnSeqNbr);
         }
       }

       // Now inserting Eligibility criteria
       log.debug("FormulaEngineDAX--Now inserting Eligibility criteria");
       if(arrFormElgble != null){
         for(int i=0; i<arrFormElgble.size(); i++){
           FormulaEligibilityCriteriaResult oFormulaEligibilityCriteriaResult = (FormulaEligibilityCriteriaResult)arrFormElgble.get(i);
           insertFormulaElgble(oFormulaEligibilityCriteriaResult, lFormlDefnSeqNbr);
         }
       }
       return lFormlDefnSeqNbr;
     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5016");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw eex;
     }
     finally
     {
       try
       {
         if(pstmtCreateFormula != null)
           pstmtCreateFormula.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       }
     }
   }



   /**
    * getFormula gets the Formula Details
    * @return ArrayList
    * @param a_lFormlDefnSeqNbr long
    * @throws EElixirException
    */
   public FormulaResult getFormula(long a_lFormlDefnSeqNbr) throws EElixirException
   {
     ResultSet rsSearchFormula = null;
     ArrayList arrFormCalc = null;
     ArrayList arrFormElgble = null;
     FormulaResult oFormulaResult = null;
     PreparedStatement pstmtSearchFormula = null;
     try
     {
       String strSelectFormulaQuery = getSQLString("Select",CHMConstants.FORMULA_SEARCH);
       log.debug("FormulaEngineDAX--search query is "+ strSelectFormulaQuery);
       pstmtSearchFormula = getPreparedStatement(strSelectFormulaQuery);
       pstmtSearchFormula.setLong(1,a_lFormlDefnSeqNbr);
       rsSearchFormula = executeQuery(pstmtSearchFormula);
       log.debug("FormulaEngineDAX--Query executed properly");
       oFormulaResult = new FormulaResult();
       int count = 0;
       if(rsSearchFormula.next())
       {
         /* CHANGE TO AVOID UPDATE  */
		 oFormulaResult.setIsDirty(DataConstants.DISPLAY_MODE);
		 oFormulaResult.setFormlDefnSeqNbr(new Long(a_lFormlDefnSeqNbr));
         oFormulaResult.setFormlId(rsSearchFormula.getString(1));
         oFormulaResult.setFormlDesc(rsSearchFormula.getString(2));
         oFormulaResult.setElgbleExpr(rsSearchFormula.getString(3));
         oFormulaResult.setCalcExpr(rsSearchFormula.getString(4));
         oFormulaResult.setTsDtUpdated(rsSearchFormula.getTimestamp("DTUPDATED"));
		 oFormulaResult.setUnitId(rsSearchFormula.getString("STRUNITID"));
         count++;
       }
       if(count == 0){
          oFormulaResult = null;
          return oFormulaResult;
       }

       // ///////// For getting values of Formula Calculation
       strSelectFormulaQuery = getSQLString("Select",CHMConstants.FORMULA_CALC_SEARCH);
       log.debug("FormulaEngineDAX--search query is "+ strSelectFormulaQuery);
       pstmtSearchFormula = getPreparedStatement(strSelectFormulaQuery);
       pstmtSearchFormula.setLong(1,a_lFormlDefnSeqNbr);
       rsSearchFormula = executeQuery(pstmtSearchFormula);
       log.debug("FormulaEngineDAX--Query executed properly");
       count = 0;
       arrFormCalc = new ArrayList(10);
       while(rsSearchFormula.next())
       {
         FormulaCalculationResult oFormulaCalculationResult = new FormulaCalculationResult();
         oFormulaCalculationResult.setFormlDefnSeqNbr(new Long(a_lFormlDefnSeqNbr));
         oFormulaCalculationResult.setFormlCalcSeqNbr(new Long(rsSearchFormula.getLong(1)));
         oFormulaCalculationResult.setBaseParamId(rsSearchFormula.getString(2));

         if(rsSearchFormula.getString(3) == null){
             oFormulaCalculationResult.setStartBracket(new Character(' '));
         }
         else if(rsSearchFormula.getString(3).trim().equals("")){
           oFormulaCalculationResult.setStartBracket(new Character(' '));
         }
         else{
           oFormulaCalculationResult.setStartBracket(new Character(rsSearchFormula.getString(3).trim().charAt(0)));
        }

         short s = rsSearchFormula.getShort(4);
         if(rsSearchFormula.wasNull()){
            oFormulaCalculationResult.setOperator(null);
         }
         else{
           oFormulaCalculationResult.setOperator(new Short(s));
        }

         double d = rsSearchFormula.getDouble(5);
         if(rsSearchFormula.wasNull()){
           oFormulaCalculationResult.setValue(null);
         }
         else{
           oFormulaCalculationResult.setValue(new Double(d));
        }

         if(rsSearchFormula.getString(6) == null){
             oFormulaCalculationResult.setEndBracket(new Character(' '));
         }
         else if(rsSearchFormula.getString(6).trim().equals("")){
           oFormulaCalculationResult.setEndBracket(new Character(' '));
         }
         else{
           oFormulaCalculationResult.setEndBracket(new Character(rsSearchFormula.getString(6).trim().charAt(0)));
        }
        oFormulaCalculationResult.setTsDtUpdated(rsSearchFormula.getTimestamp("DTUPDATED"));

         arrFormCalc.add(oFormulaCalculationResult);
         count++;
       }
       log.debug("FormulaEngineDAX--Count of created Calc record" + count);
       if(count == 0){
          arrFormCalc = null;
       }
       oFormulaResult.setFormulaCalculation(arrFormCalc);

       // ///////// For getting values of Formula Eligibility
       strSelectFormulaQuery = getSQLString("Select",CHMConstants.FORMULA_ELGBLE_SEARCH);
       log.debug("FormulaEngineDAX--search query is "+ strSelectFormulaQuery);
       pstmtSearchFormula = getPreparedStatement(strSelectFormulaQuery);
       pstmtSearchFormula.setLong(1,a_lFormlDefnSeqNbr);
       rsSearchFormula = executeQuery(pstmtSearchFormula);
       log.debug("FormulaEngineDAX--Query executed properly");
       count = 0;
       arrFormElgble = new ArrayList(10);
       while(rsSearchFormula.next())
       {
         FormulaEligibilityCriteriaResult oFormulaEligibilityCriteriaResult = new FormulaEligibilityCriteriaResult();
         oFormulaEligibilityCriteriaResult.setFormlDefnSeqNbr(new Long(a_lFormlDefnSeqNbr));
         oFormulaEligibilityCriteriaResult.setElgbleCritSeqNbr(new Long(rsSearchFormula.getLong(1)));
         oFormulaEligibilityCriteriaResult.setGroupId(rsSearchFormula.getString(2));
         log.debug("FormulaEngineDAX--Query executed properly");
         short s = rsSearchFormula.getShort(3);
         if(rsSearchFormula.wasNull()){
            oFormulaEligibilityCriteriaResult.setOperator(null);
         }
         else{
           oFormulaEligibilityCriteriaResult.setOperator(new Short(s));
         }

         s = rsSearchFormula.getShort(4);
         if(rsSearchFormula.wasNull()){
            oFormulaEligibilityCriteriaResult.setNoOfCondition(null);
         }
         else{
           oFormulaEligibilityCriteriaResult.setNoOfCondition(new Short(s));
         }

         oFormulaEligibilityCriteriaResult.setExpression(rsSearchFormula.getString(5));

         if(rsSearchFormula.getString(6) == null){
             oFormulaEligibilityCriteriaResult.setStartBracket(new Character(' '));
         }
         else if(rsSearchFormula.getString(6).trim().equals("")){
           oFormulaEligibilityCriteriaResult.setStartBracket(new Character(' '));
         }
         else{
           oFormulaEligibilityCriteriaResult.setStartBracket(new Character(rsSearchFormula.getString(6).trim().charAt(0)));
        }


         if(rsSearchFormula.getString(7) == null){
             oFormulaEligibilityCriteriaResult.setEndBracket(new Character(' '));
         }
         else if(rsSearchFormula.getString(7).trim().equals("")){
           oFormulaEligibilityCriteriaResult.setEndBracket(new Character(' '));
         }
         else{
           oFormulaEligibilityCriteriaResult.setEndBracket(new Character(rsSearchFormula.getString(7).trim().charAt(0)));
        }
        oFormulaEligibilityCriteriaResult.setTsDtUpdated(rsSearchFormula.getTimestamp("DTUPDATED"));
         arrFormElgble.add(oFormulaEligibilityCriteriaResult);
         count++;
       }
       if(count == 0){
          arrFormElgble = null;
       }
       oFormulaResult.setFormulaEligibilityCriteria(arrFormElgble);
       return oFormulaResult;
     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
       //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       throw new EElixirException(sqlex, "P5017");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw new EElixirException(eex,"P5017");
     }
     finally
     {
       try
       {
         if(rsSearchFormula != null)
           rsSearchFormula.close();

         if(pstmtSearchFormula != null)
           pstmtSearchFormula.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       }
     }
    }


    /**
      * findFormula finds whether the Formula is there or not
      * @return boolean
      * @param a_lFormlDefnSeqNbr long
      * @throws EElixirException
      */
     public boolean findFormula(long a_lFormlDefnSeqNbr) throws EElixirException
     {
       ResultSet rsSearchFormula = null;
       PreparedStatement pstmtFindPrimaryKey = null;
       try
       {
         String strSelectFormulaQuery = getSQLString("Select",CHMConstants.FIND_FORMULA_BY_PRIMARYKEY);
         if(pstmtFindPrimaryKey == null)
         {
           pstmtFindPrimaryKey = getPreparedStatement(strSelectFormulaQuery);
         }
         pstmtFindPrimaryKey.setLong(1,a_lFormlDefnSeqNbr);

         rsSearchFormula = executeQuery(pstmtFindPrimaryKey);
         if(rsSearchFormula.next())
         {
           return true;
         }
         else
         {
           return false;
         }
       }
       catch(SQLException sqlex){
         log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         throw new EElixirException(sqlex, "P5018");
       }
       catch(EElixirException eex)
       {
         log.exception(eex.getMessage());
         throw new EElixirException(eex,"P5018");
       }
       finally
       {
         try
         {
           if(rsSearchFormula != null)
             rsSearchFormula.close();

           if(pstmtFindPrimaryKey != null)
             pstmtFindPrimaryKey.close();
         }
         catch(SQLException sqlex)
         {
           log.exception(sqlex.getMessage());
           throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
         }
       }
     }


     /**
       * findFormula finds whether the Formula is there or not
       * @return boolean
       * @param a_strFormlId String
       * @throws EElixirException
       */

      public boolean findFormula(String a_strFormlId) throws EElixirException
      {
        ResultSet rsSearchFormula = null;
        PreparedStatement pstmtFindPrimaryKey = null;
        try
        {
          String strSelectFormulaQuery = getSQLString("Select",CHMConstants.FIND_FORMULAID_BY_PRIMARYKEY);
          pstmtFindPrimaryKey = getPreparedStatement(strSelectFormulaQuery);
          pstmtFindPrimaryKey.setString(1,a_strFormlId.toUpperCase());

          rsSearchFormula = executeQuery(pstmtFindPrimaryKey);
          if(rsSearchFormula.next())
          {
            log.debug("FormulaEngineDAX--returning true for formula");
            return true;
          }
          else
          {
            log.debug("FormulaEngineDAX--returning false for formula");
            return false;
          }
        }
        catch(SQLException sqlex){
          log.exception(sqlex.getMessage());
          //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
          throw new EElixirException(sqlex, "P5012");
        }
        catch(EElixirException eex)
        {
          log.exception(eex.getMessage());
          throw new EElixirException(eex,"P5012");
        }
        finally
        {
          try
          {
            if(rsSearchFormula != null)
              rsSearchFormula.close();

            if(pstmtFindPrimaryKey != null)
              pstmtFindPrimaryKey.close();
          }
          catch(SQLException sqlex)
          {
            log.exception(sqlex.getMessage());
            throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
          }
        }
      }


     /**
       * Inserts a new record
       * @param a_oFormulaResult FormulaResult
       * @throws EElixirException
       */
     public void updateFormula(FormulaResult a_oFormulaResult) throws EElixirException
     {
        PreparedStatement pstmtUpdateFormula = null;
        ArrayList arrFormCalc = null;
        ArrayList arrFormElgble = null;
        long lFormlDefnSeqNbr;

        try
        {
          log.debug("FormulaEngineDAX--Inside update formula" + a_oFormulaResult);
          lFormlDefnSeqNbr            = a_oFormulaResult.getFormlDefnSeqNbr().longValue();
          //String strFormlId         = a_oFormulaResult.getFormlId().trim().toUpperCase();
          String strFormlDesc         = a_oFormulaResult.getFormlDesc().trim().toUpperCase();
          String strUpdatedBy         = a_oFormulaResult.getUserId();
          String strElgbleExpr        = a_oFormulaResult.getElgbleExpr().trim();
          //String strCalcExpr          = a_oFormulaResult.getCalcExpr().trim();

          arrFormCalc = a_oFormulaResult.getFormulaCalculation();
          arrFormElgble = a_oFormulaResult.getFormulaEligibilityCriteria();

          String strUpdateFormulaQuery = getSQLString("Update",CHMConstants.FORMULA_UPDATE);

          log.debug("FormulaEngineDAX--StrFormulaquery =" + strUpdateFormulaQuery);
          pstmtUpdateFormula = getPreparedStatement(strUpdateFormulaQuery);

          pstmtUpdateFormula.setString(1,strFormlDesc);
          pstmtUpdateFormula.setString(2,strElgbleExpr);
          pstmtUpdateFormula.setNull(3,Types.VARCHAR);
          pstmtUpdateFormula.setString(4,strUpdatedBy);
		  pstmtUpdateFormula.setString(5,a_oFormulaResult.getUnitId());
          pstmtUpdateFormula.setLong(6,lFormlDefnSeqNbr);
          log.debug("FormulaEngineDAX--After setting all values");

          int icount = executeUpdate(pstmtUpdateFormula);
          log.debug("FormulaEngineDAX--" + icount);

          // Now updating Calculation criteria
          log.debug("FormulaEngineDAX--Now updating Calculation criteria");
          String statusFlag = null;
          if(arrFormCalc != null){
            for(int i=0; i<arrFormCalc.size(); i++){
              FormulaCalculationResult oFormulaCalculationResult = (FormulaCalculationResult)arrFormCalc.get(i);
              statusFlag = oFormulaCalculationResult.getStatusFlag();
              if(statusFlag != null){
                if(statusFlag.trim().equals(DataConstants.DELETE_MODE)){
                  removeFormulaCalc(oFormulaCalculationResult);
                }
                else  if(statusFlag.trim().equals(DataConstants.UPDATE_MODE)){
                  updateFormulaCalc(oFormulaCalculationResult);
                }
                else if(statusFlag.trim().equals(DataConstants.INSERT_MODE)){
                  insertFormulaCalc(oFormulaCalculationResult, lFormlDefnSeqNbr);
                }
              }
            }
          }

          log.debug("FormulaEngineDAX--Now inserting Eligibility criteria");
          if(arrFormElgble != null){
            for(int i=0; i<arrFormElgble.size(); i++){
              FormulaEligibilityCriteriaResult oFormulaEligibilityCriteriaResult = (FormulaEligibilityCriteriaResult)arrFormElgble.get(i);
              statusFlag = oFormulaEligibilityCriteriaResult.getStatusFlag();
              if(statusFlag != null){
                if(statusFlag.trim().equals(DataConstants.DELETE_MODE)){
                  removeFormulaElgble(oFormulaEligibilityCriteriaResult);
                }
                else  if(statusFlag.trim().equals(DataConstants.UPDATE_MODE)){
                  updateFormulaElgble(oFormulaEligibilityCriteriaResult);
                }
                else if(statusFlag.trim().equals(DataConstants.INSERT_MODE)){
                  insertFormulaElgble(oFormulaEligibilityCriteriaResult, lFormlDefnSeqNbr);
                }
              }
            }
          }
        }
        catch(SQLException sqlex){
          log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, "P5019");
        }
        catch(EElixirException eex)
        {
          log.exception(eex.getMessage());
          throw eex;
        }
        finally
        {
          try
          {
            if(pstmtUpdateFormula != null)
              pstmtUpdateFormula.close();
          }
          catch(SQLException sqlex)
          {
            log.exception(sqlex.getMessage());
            throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
          }
        }
     }


   /**
     * Inserts a new record
     * @param a_oFormulaCalculationResult FormulaCalculationResult
     * @param a_lFormlDefnSeqNbr long
     * @throws EElixirException
     */
    public void insertFormulaCalc(FormulaCalculationResult a_oFormulaCalculationResult, long a_lFormlDefnSeqNbr) throws EElixirException
    {
      PreparedStatement pstmtCreateFormula = null;
      try
      {

        Character cStartBracket  = null;
        Character cEndBracket    = null;
        Short nOperator          = null;
        String strBaseParamID    = null;
        Double value             = null;
        long lFormlCalcSeqNbr;
        int icount = 0;
        lFormlCalcSeqNbr = getNextSeqNbr(DataConstants.FORMULA_CALC_TYPE);
        log.debug("FormulaEngineDAX--Formula calc id" + lFormlCalcSeqNbr);
        cStartBracket  = a_oFormulaCalculationResult.getStartBracket();
        cEndBracket    = a_oFormulaCalculationResult.getEndBracket();
        nOperator      = a_oFormulaCalculationResult.getOperator();
        strBaseParamID = a_oFormulaCalculationResult.getBaseParamId();
        value          = a_oFormulaCalculationResult.getValue();

        log.debug("FormulaEngineDAX--lFormlCalcSeqNbr:" + lFormlCalcSeqNbr);
        log.debug("FormulaEngineDAX--cStartBracket:" + cStartBracket);
        log.debug("FormulaEngineDAX--cEndBracket:" + cEndBracket);
        log.debug("FormulaEngineDAX--nOperator:" + nOperator);
        log.debug("FormulaEngineDAX--strBaseParamID:" + strBaseParamID);
        log.debug("FormulaEngineDAX--value:" + value);
        log.debug("FormulaEngineDAX--a_lFormlDefnSeqNbr:" + a_lFormlDefnSeqNbr);


        String strCreateFormulaQuery = getSQLString("Insert",CHMConstants.FORMULA_CALC_INSERT);
        pstmtCreateFormula = getPreparedStatement(strCreateFormulaQuery);

        pstmtCreateFormula.setLong(1,lFormlCalcSeqNbr);
        pstmtCreateFormula.setLong(2,a_lFormlDefnSeqNbr);
        pstmtCreateFormula.setString(3,strBaseParamID);
        pstmtCreateFormula.setString(4,(cStartBracket.charValue() + "").trim());
        pstmtCreateFormula.setString(5,(cEndBracket.charValue() + "").trim());
        if(value == null){
          pstmtCreateFormula.setNull(6,java.sql.Types.DOUBLE);
        }
        else{
          pstmtCreateFormula.setDouble(6,value.doubleValue());
        }


        if(nOperator == null){
          pstmtCreateFormula.setNull(7,java.sql.Types.INTEGER);
        }
        else{
          pstmtCreateFormula.setShort(7,nOperator.shortValue());
        }
        pstmtCreateFormula.setString(8,a_oFormulaCalculationResult.getUserId());
        log.debug("FormulaEngineDAX--After setting all values of formula calc");
        icount = executeUpdate(pstmtCreateFormula);
        log.debug("FormulaEngineDAX--" + icount);
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
         //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       throw new EElixirException(sqlex, "P5020");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw eex;
      }
      finally
      {
        try
        {
          if(pstmtCreateFormula != null)
            pstmtCreateFormula.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
     }
    }


    /**
    * updates a new record
    * @param a_oFormulaCalculationResult FormulaCalculationResult
    * @throws EElixirException
    */
   public void updateFormulaCalc(FormulaCalculationResult a_oFormulaCalculationResult) throws EElixirException
   {
     PreparedStatement pstmtUpdateFormula = null;
     try
     {
       Character cStartBracket  = null;
       Character cEndBracket    = null;
       Short nOperator          = null;
       String strBaseParamID    = null;
       Double value             = null;
       long lFormlCalcSeqNbr;
       lFormlCalcSeqNbr = a_oFormulaCalculationResult.getFormlCalcSeqNbr().longValue();
       cStartBracket  = a_oFormulaCalculationResult.getStartBracket();
       cEndBracket    = a_oFormulaCalculationResult.getEndBracket();
       nOperator      = a_oFormulaCalculationResult.getOperator();
       strBaseParamID = a_oFormulaCalculationResult.getBaseParamId();
       value          = a_oFormulaCalculationResult.getValue();
       log.debug("FormulaEngineDAX--lFormlCalcSeqNbr:" + lFormlCalcSeqNbr);
       log.debug("FormulaEngineDAX--cStartBracket:" + cStartBracket);
       log.debug("FormulaEngineDAX--cEndBracket:" + cEndBracket);
       log.debug("FormulaEngineDAX--nOperator:" + nOperator);
       log.debug("FormulaEngineDAX--strBaseParamID:" + strBaseParamID);
       log.debug("FormulaEngineDAX--value:" + value);

       String strUpdateFormulaQuery = getSQLString("Update",CHMConstants.FORMULA_CALC_UPDATE);
       log.debug("FormulaEngineDAX--strUpdateFormulaQuery:" + strUpdateFormulaQuery);
       pstmtUpdateFormula = getPreparedStatement(strUpdateFormulaQuery);

       pstmtUpdateFormula.setString(1,strBaseParamID);
       pstmtUpdateFormula.setString(2,(cStartBracket.charValue() + "").trim());
       pstmtUpdateFormula.setString(3,(cEndBracket.charValue() + "").trim());
       if(value == null){
         pstmtUpdateFormula.setNull(4,java.sql.Types.DOUBLE);
       }
       else{
         pstmtUpdateFormula.setDouble(4,value.doubleValue());
        }


       if(nOperator == null){
         pstmtUpdateFormula.setNull(5,java.sql.Types.INTEGER);
       }
       else{
         pstmtUpdateFormula.setShort(5,nOperator.shortValue());
       }
       pstmtUpdateFormula.setString(6,a_oFormulaCalculationResult.getUserId());
       pstmtUpdateFormula.setLong(7,lFormlCalcSeqNbr);

       log.debug("FormulaEngineDAX--After setting all values of formula calc");
       int icount = executeUpdate(pstmtUpdateFormula);
       log.debug("FormulaEngineDAX--" + icount);
     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5021");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw eex;
     }
     finally
     {
       try
       {
         if(pstmtUpdateFormula != null)
           pstmtUpdateFormula.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       }
     }
   }

   /**
   * removes a record
   * @param a_oFormulaCalculationResult FormulaCalculationResult
   * @throws EElixirException
   */
  public void removeFormulaCalc(FormulaCalculationResult a_oFormulaCalculationResult) throws EElixirException
  {
    PreparedStatement pstmtRemoveFormulaCalc = null;
    try
    {
      log.debug("FormulaEngineDAX-- Inside remove Formula calc");
      String strRemoveQuery = getSQLString("Delete",CHMConstants.FORMULA_CALC_DELETE);
      pstmtRemoveFormulaCalc = getPreparedStatement(strRemoveQuery);
      pstmtRemoveFormulaCalc.setLong(1,a_oFormulaCalculationResult.getFormlCalcSeqNbr().longValue());
      int iRemove = executeUpdate(pstmtRemoveFormulaCalc);
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5022");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5022");
    }
    finally
    {
      try
      {

        if(pstmtRemoveFormulaCalc != null)
          pstmtRemoveFormulaCalc.close();

      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }


  }

  /**
    * Inserts a new record
    * @param a_oFormulaEligibilityCriteriaResult FormulaEligibilityCriteriaResult
    * @param a_lFormlDefnSeqNbr long
    * @throws EElixirException
    */
   public void insertFormulaElgble(FormulaEligibilityCriteriaResult a_oFormulaEligibilityCriteriaResult, long a_lFormlDefnSeqNbr) throws EElixirException
   {
     PreparedStatement pstmtCreateFormula = null;
     try
     {
       long     lElgbleCritSeqNbr;
       String   strGroupId          = null;
       Short    nNoOfCondition;
       String   strExpression       = null;
       Short nOperator          = null;
       Character cStartBracket  = null;
       Character cEndBracket    = null;

       lElgbleCritSeqNbr = getNextSeqNbr(DataConstants.FORMULA_ELGBLE_TYPE);
       log.debug("FormulaEngineDAX--Formula elgble id" + lElgbleCritSeqNbr);
       strGroupId  = a_oFormulaEligibilityCriteriaResult.getGroupId().trim().toUpperCase();
       nNoOfCondition    = a_oFormulaEligibilityCriteriaResult.getNoOfCondition();
       nOperator      = a_oFormulaEligibilityCriteriaResult.getOperator();
       strExpression = a_oFormulaEligibilityCriteriaResult.getExpression();
       cStartBracket  = a_oFormulaEligibilityCriteriaResult.getStartBracket();
       cEndBracket    = a_oFormulaEligibilityCriteriaResult.getEndBracket();

       String strCreateFormulaQuery = getSQLString("Insert",CHMConstants.FORMULA_ELGBLE_INSERT);
       log.debug("FormulaEngineDAX--strCreateFormulaQuery:" + strCreateFormulaQuery);
       pstmtCreateFormula = getPreparedStatement(strCreateFormulaQuery);

       pstmtCreateFormula.setLong(1,lElgbleCritSeqNbr);
       pstmtCreateFormula.setLong(2,a_lFormlDefnSeqNbr);
       pstmtCreateFormula.setString(3,strGroupId);
       pstmtCreateFormula.setString(4,strExpression);
       if(nNoOfCondition == null){
         pstmtCreateFormula.setNull(5,java.sql.Types.INTEGER);
       }
       else{
         pstmtCreateFormula.setShort(5,nNoOfCondition.shortValue());
       }

       if(nOperator == null){
         pstmtCreateFormula.setNull(6,java.sql.Types.INTEGER);
       }
       else{
         pstmtCreateFormula.setShort(6,nOperator.shortValue());
       }
       pstmtCreateFormula.setString(7,(cStartBracket.charValue() + "").trim());
       pstmtCreateFormula.setString(8,(cEndBracket.charValue() + "").trim());
       pstmtCreateFormula.setString(9,a_oFormulaEligibilityCriteriaResult.getUserId());
       log.debug("FormulaEngineDAX--After setting all values of formula elgble");
       int count = executeUpdate(pstmtCreateFormula);
       log.debug("FormulaEngineDAX--" + count);
     }
     catch(SQLException sqlex){
       log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5023");
     }
     catch(EElixirException eex)
     {
       log.exception(eex.getMessage());
       throw eex;
     }
     finally
     {
       try
       {
         if(pstmtCreateFormula != null)
           pstmtCreateFormula.close();
       }
       catch(SQLException sqlex)
       {
         log.exception(sqlex.getMessage());
         throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
       }
     }
   }


   /**
   * updates a new record
   * @param a_oFormulaEligibilityCriteriaResult FormulaEligibilityCriteriaResult
   * @throws EElixirException
   */
  public void updateFormulaElgble(FormulaEligibilityCriteriaResult a_oFormulaEligibilityCriteriaResult) throws EElixirException
  {
    PreparedStatement pstmtUpdateFormula = null;
    ResultSet rsCreateFormula = null;
    try
    {
      long     lElgbleCritSeqNbr;
      String   strGroupId          = null;
      Short    nNoOfCondition;
      String   strExpression       = null;
      Short nOperator          = null;
      Character cStartBracket  = null;
      Character cEndBracket    = null;

      lElgbleCritSeqNbr = a_oFormulaEligibilityCriteriaResult.getElgbleCritSeqNbr().longValue();
      log.debug("FormulaEngineDAX--Formula elgble id" + lElgbleCritSeqNbr);
      strGroupId  = a_oFormulaEligibilityCriteriaResult.getGroupId().trim().toUpperCase();
      nNoOfCondition    = a_oFormulaEligibilityCriteriaResult.getNoOfCondition();
      nOperator      = a_oFormulaEligibilityCriteriaResult.getOperator();
      strExpression = a_oFormulaEligibilityCriteriaResult.getExpression();
      cStartBracket  = a_oFormulaEligibilityCriteriaResult.getStartBracket();
      cEndBracket    = a_oFormulaEligibilityCriteriaResult.getEndBracket();

      String strCreateFormulaQuery = getSQLString("Update",CHMConstants.FORMULA_ELGBLE_UPDATE);
      log.debug("FormulaEngineDAX--strCreateFormulaQuery:" + strCreateFormulaQuery);
      pstmtUpdateFormula = getPreparedStatement(strCreateFormulaQuery);

      pstmtUpdateFormula.setString(1,strGroupId);
      pstmtUpdateFormula.setString(2,strExpression);
      if(nNoOfCondition == null){
        pstmtUpdateFormula.setNull(3,java.sql.Types.INTEGER);
      }
      else{
        pstmtUpdateFormula.setShort(3,nNoOfCondition.shortValue());
      }

      if(nOperator == null){
        pstmtUpdateFormula.setNull(4,java.sql.Types.INTEGER);
      }
      else{
        pstmtUpdateFormula.setShort(4,nOperator.shortValue());
      }
      pstmtUpdateFormula.setString(5,(cStartBracket.charValue() + "").trim());
      pstmtUpdateFormula.setString(6,(cEndBracket.charValue() + "").trim());
      pstmtUpdateFormula.setString(7,a_oFormulaEligibilityCriteriaResult.getUserId());
      pstmtUpdateFormula.setLong(8,lElgbleCritSeqNbr);

      log.debug("FormulaEngineDAX--After setting all values of formula elgble");
      int count = executeUpdate(pstmtUpdateFormula);
      log.debug("FormulaEngineDAX--" + count);
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
       //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     throw new EElixirException(sqlex, "P5024");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw eex;
    }
    finally
    {
      try
      {
        if(pstmtUpdateFormula != null)
          pstmtUpdateFormula.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
     }
  }

  /**
  * removes a record
  * @param a_oFormulaEligibilityCriteriaResult FormulaEligibilityCriteriaResult
  * @throws EElixirException
  */
 public void removeFormulaElgble(FormulaEligibilityCriteriaResult a_oFormulaEligibilityCriteriaResult) throws EElixirException
 {
   PreparedStatement pstmtRemoveFormulaElgble = null;
   try
   {
     log.debug("FormulaEngineDAX-- Inside remove Unit");
     String strRemoveQuery = getSQLString("Delete",CHMConstants.FORMULA_ELGBLE_DELETE);
     pstmtRemoveFormulaElgble = getPreparedStatement(strRemoveQuery);
     pstmtRemoveFormulaElgble.setLong(1,a_oFormulaEligibilityCriteriaResult.getElgbleCritSeqNbr().longValue());
     int iRemove = executeUpdate(pstmtRemoveFormulaElgble);
   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     throw new EElixirException(sqlex, "P5025");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P5025");
   }
   finally
   {
     try
     {

       if(pstmtRemoveFormulaElgble != null)
         pstmtRemoveFormulaElgble.close();

     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     }
   }
 }

 public Timestamp getFormulaEligibiltyCriteriaDtUpdated(long lElgbleCritSeqNbr,long lFormlDefnSeqNbr) throws EElixirException
 {
   String strQuery = null;
   PreparedStatement pstmtSearchFormula = null;
   ResultSet rsSearchFormula = null;
   Timestamp tsDtUpdated = null;
   try
   {
     strQuery = getSQLString("Select",CHMConstants.GET_FORMULA_ELIGIBILITYCRITERIA_DTUPDATED);
     log.debug("FormulaEngineDAX--search query is "+ strQuery);
     pstmtSearchFormula = getPreparedStatement(strQuery);
     pstmtSearchFormula.setLong(1,lElgbleCritSeqNbr);
     pstmtSearchFormula.setLong(2,lFormlDefnSeqNbr);
     rsSearchFormula = executeQuery(pstmtSearchFormula);
     log.debug("FormulaEngineDAX--Query executed properly");
     rsSearchFormula.next();
     tsDtUpdated = rsSearchFormula.getTimestamp("DTUPDATED");
     return tsDtUpdated;
   }
   catch(SQLException sqlex){
     log.exception(sqlex.getMessage());
     //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     throw new EElixirException(sqlex, "P5017");
   }
   catch(EElixirException eex)
   {
     log.exception(eex.getMessage());
     throw new EElixirException(eex,"P5017");
   }
   finally
   {
     try
     {
       if(rsSearchFormula != null)
         rsSearchFormula.close();

       if(pstmtSearchFormula != null)
         pstmtSearchFormula.close();
     }
     catch(SQLException sqlex)
     {
       log.exception(sqlex.getMessage());
       throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
     }
   }
 }

 public Timestamp getFormulaCalculationDtUpdated(long lFormlCalcSeqNbr,long lFormlDefnSeqNbr) throws EElixirException
  {
    String strQuery = null;
    PreparedStatement pstmtSearchFormula = null;
    ResultSet rsSearchFormula = null;
    Timestamp tsDtUpdated = null;
    try
    {
      strQuery = getSQLString("Select",CHMConstants.GET_FORMULA_CALCULATION_DTUPDATED);
      log.debug("FormulaEngineDAX--search query is "+ strQuery);
      pstmtSearchFormula = getPreparedStatement(strQuery);
      pstmtSearchFormula.setLong(1,lFormlCalcSeqNbr);
      pstmtSearchFormula.setLong(2,lFormlDefnSeqNbr);
      rsSearchFormula = executeQuery(pstmtSearchFormula);
      log.debug("FormulaEngineDAX--Query executed properly");
      rsSearchFormula.next();
      tsDtUpdated = rsSearchFormula.getTimestamp("DTUPDATED");
      return tsDtUpdated;
    }
    catch(SQLException sqlex){
      log.exception(sqlex.getMessage());
      //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      throw new EElixirException(sqlex, "P5017");
    }
    catch(EElixirException eex)
    {
      log.exception(eex.getMessage());
      throw new EElixirException(eex,"P5017");
    }
    finally
    {
      try
      {
        if(rsSearchFormula != null)
          rsSearchFormula.close();

        if(pstmtSearchFormula != null)
          pstmtSearchFormula.close();
      }
      catch(SQLException sqlex)
      {
        log.exception(sqlex.getMessage());
        throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
      }
    }
 }

  /**
    * Description getSQLString takes querytype and key and returns query
    * @return query string
    * @param a_strSQLType SQL Type i.e Select , Insert , Delete , Update
    * @param a_strKey String
    * @throws EElixirException
    */
   private String getSQLString(String a_strSQLType,String a_strKey) throws EElixirException
   {
     SqlRepositoryIF sqlRFIF = null;
     String strSql = "";
     try
     {
       sqlRFIF = CHMSqlRepository.getSqlRepository();
       strSql=sqlRFIF.getSQLString(a_strKey,a_strSQLType);
     }
     catch(EElixirException eex)
     {
       log.debug("FormulaEngineDAX--sql ex"+ eex);
       log.exception(eex.getMessage());
       throw new EElixirException(eex,"P3019"); // could not get sql string
     }
     return strSql;
   }




   /**
     * This function generates a new Seq no, on which the
     * new record is inserted.
     * @param type int
     * @return long Returns the next seq no generated on 3 different table
     * @throws EElixirException
     */
    protected long getNextSeqNbr(int type) throws EElixirException{
      Statement stmtNextSeq = null;
      long lSeqNo;
      try
      {
        String strNextSeqQuery = null;
        if(type == DataConstants.UNIT_TYPE){
          strNextSeqQuery = getSQLString("Select",CHMConstants.UNIT_SEQUENCENO);
        }
        else if(type == DataConstants.GROUP_TYPE){
          strNextSeqQuery = getSQLString("Select",CHMConstants.GROUP_SEQUENCENO);
        }
        else if(type == DataConstants.FORMULA_HDR_TYPE){
          strNextSeqQuery = getSQLString("Select",CHMConstants.FORMULA_HDR_SEQUENCENO);
        }
        else if(type == DataConstants.FORMULA_CALC_TYPE){
          strNextSeqQuery = getSQLString("Select",CHMConstants.FORMULA_CALC_SEQUENCENO);
        }
        else if(type == DataConstants.FORMULA_ELGBLE_TYPE){
          strNextSeqQuery = getSQLString("Select",CHMConstants.FORMULA_ELGBLE_SEQUENCENO);
        }
        stmtNextSeq = getStatement();
        ResultSet rsSeqNo = stmtNextSeq.executeQuery(strNextSeqQuery);
        rsSeqNo.next();
        lSeqNo = rsSeqNo.getLong(1);
        log.debug(lSeqNo + "");
        return lSeqNo;
      }
      catch(SQLException sqlex){
        log.exception(sqlex.getMessage());
        //throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        throw new EElixirException(sqlex, "P5026");
      }
      catch(EElixirException eex)
      {
        log.exception(eex.getMessage());
        throw new EElixirException(eex,"P5026");
      }
      finally
      {
        try
        {
          if(stmtNextSeq != null)
            stmtNextSeq.close();
        }
        catch(SQLException sqlex)
        {
          log.exception(sqlex.getMessage());
          throw new EElixirException(sqlex, sqlex.getErrorCode()+ "");
        }
      }
    }

     /*
     *  Member variables
     */
  //private Log log = new Log(FormulaEngineDAX.class.getName(),Constants.CHM_MODULE);
  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}