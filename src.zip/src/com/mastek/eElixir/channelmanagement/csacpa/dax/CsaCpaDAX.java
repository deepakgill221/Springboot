/********************************************************************
 *
 *  PROJECT			 : MNYL
 *  MODULE NAME      : CHANNEL MANAGEMENT
 *  FILENAME         : CsaCpaDAX.java
 *  AUTHOR           : Amid P Sahu
 *  VERSION          : 1.0
 *  CREATION DATE    : June 25, 2008
 *  COMPANY          : Mastek Ltd.
 *  COPYRIGHT        : COPYRIGHT (C) 2008.
 *  
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION        DATE     BY              REASON
 *--------------------------------------------------------------------------------

 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.csacpa.dax;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaCriteriaDetailsResult;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult;
import com.mastek.eElixir.channelmanagement.util.CHMConstants;
import com.mastek.eElixir.channelmanagement.util.CHMSqlRepository;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DAX;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.common.util.SqlRepositoryIF;

/**
 * <p>
 * Title: eElixir
 * </p>
 * <p>
 * Description:The DAX implementaion for the CsaCpaDAX object
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: Mastek Ltd
 * </p>
 * 
 * @author Amid P Sahu
 * @version 1.0
 */
public class CsaCpaDAX extends DAX {
	CsaCpaResult _oCsaCpaResult = null;

	CsaCpaCriteriaDetailsResult _oCsaCpaCriteriaDetailsResult = null;

	/*
	 * Member variables
	 */
	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

	/**
	 * Constructor
	 */
	public CsaCpaDAX() {
	}

	/**
	 * searchCsaCpa gets the Channel wise CSA/CPA Details
	 * 
	 * @return ArrayList
	 * @throws EElixirException
	 */
	public ArrayList searchCsaCpa(String a_cChannelType)
			throws EElixirException {
		ResultSet rsCsaCpa = null;
		PreparedStatement _pstmtCsaCpaSearch = null;
		ArrayList _oCsaCpaList = new ArrayList();
		try {
			

			String strSelectSubChannelQuery = getSQLString("Select",
					CHMConstants.FIND_CSA_CPA_BY_CHANNELTYPE);
			log.debug(strSelectSubChannelQuery);

			if (_pstmtCsaCpaSearch == null) {
				_pstmtCsaCpaSearch = getPreparedStatement(strSelectSubChannelQuery);
			}

			log.debug(_pstmtCsaCpaSearch + "");
			_pstmtCsaCpaSearch.setString(1, a_cChannelType);

			rsCsaCpa = executeQuery(_pstmtCsaCpaSearch);

			while (rsCsaCpa.next()) {
				_oCsaCpaResult = new CsaCpaResult();

				_oCsaCpaResult.setIsDirty(DataConstants.DISPLAY_MODE);
				_oCsaCpaResult.setChannelType(a_cChannelType);
				
				_oCsaCpaResult.setAgentSeqNbr(new Long(rsCsaCpa.getLong("LAGTSEQNBR")));
				
				_oCsaCpaResult.setAgentType(rsCsaCpa.getString("STRAGTTYPE"));
				_oCsaCpaResult.setStatusFlag(DataConstants.UPDATE_MODE);

				_oCsaCpaResult.setAgentTypeDesc(rsCsaCpa
						.getString("STRAGTTYPEDESC"));
				if (rsCsaCpa.getString("NPERIODTYPE") != null) {
					_oCsaCpaResult.setPeriodType(new Short(rsCsaCpa
							.getString("NPERIODTYPE")));
				} else {
					_oCsaCpaResult.setPeriodType(null);
				}
				if (rsCsaCpa.getString("NPERIOD") != null) {
					_oCsaCpaResult.setPeriod(new Short(rsCsaCpa
							.getString("NPERIOD")));
				} else {
					_oCsaCpaResult.setPeriod(null);
				}
				if (rsCsaCpa.getString("NFREQCAL") != null) {
					_oCsaCpaResult.setFreqCal(new Short(rsCsaCpa
							.getString("NFREQCAL")));
				} else {
					_oCsaCpaResult.setFreqCal(null);
				}
				if (rsCsaCpa.getString("NVINTAGE") != null) {
					_oCsaCpaResult.setVintAge(new Short(rsCsaCpa
							.getString("NVINTAGE")));
				} else {
					_oCsaCpaResult.setVintAge(null);
				}
				if (rsCsaCpa.getTimestamp("DTUPDATED") != null) {

					_oCsaCpaResult.setTsDtUpdated(rsCsaCpa
							.getTimestamp("DTUPDATED"));

				} else {
					_oCsaCpaResult.setTsDtUpdated(null);
				}

				_oCsaCpaList.add(_oCsaCpaResult);
			}

			return _oCsaCpaList;
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, "p8131");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "p8131");
		} finally {
			try {
				if (_pstmtCsaCpaSearch != null) {
					_pstmtCsaCpaSearch.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "p8131");
			}
		}
	}

	/**
	 * searchCsaCpaCriteria gets the CsaCpa Criteria result Details
	 * 
	 * @return CsaCpaResult
	 * @throws EElixirException
	 */
	public CsaCpaResult searchCsaCpaCriteria(String a_strAgentType,String a_strChannelType)
			throws EElixirException {
		ResultSet rsSearchCsaCpaCriteria = null;
		PreparedStatement _pstmtCsaCpaCriteria = null;
		ArrayList _oCsaCpaCriteriaDtlList = new ArrayList();
		CsaCpaResult oCsaCpaResult = new CsaCpaResult();
		try {

			String strSelectCsaCpaCriteriaQuery = getSQLString("Select",
					CHMConstants.SEARCH_CPA_CSA_CRITERIA);			

			if (_pstmtCsaCpaCriteria == null) {
				_pstmtCsaCpaCriteria = getPreparedStatement(strSelectCsaCpaCriteriaQuery);
			}

			
			_pstmtCsaCpaCriteria.setString(1, a_strAgentType);
			_pstmtCsaCpaCriteria.setString(2, a_strChannelType);

			rsSearchCsaCpaCriteria = executeQuery(_pstmtCsaCpaCriteria);

			while (rsSearchCsaCpaCriteria.next()) {
				
				oCsaCpaResult.setIsDirty(DataConstants.DISPLAY_MODE);
				oCsaCpaResult.setAgentSeqNbr(new Long(rsSearchCsaCpaCriteria
						.getLong("LAGTSEQNBR")));
				oCsaCpaResult.setChannelType(rsSearchCsaCpaCriteria.
						getString("CCHANNELTYPE"));
				oCsaCpaResult.setAgentType(rsSearchCsaCpaCriteria
						.getString("STRAGTTYPE"));
				oCsaCpaResult.setStatusFlag(DataConstants.UPDATE_MODE);

				oCsaCpaResult.setAgentTypeDesc(rsSearchCsaCpaCriteria
						.getString("STRAGTTYPEDESC"));
				if (rsSearchCsaCpaCriteria.getString("NPERIODTYPE") != null) {
					oCsaCpaResult.setPeriodType(new Short(
							rsSearchCsaCpaCriteria.getString("NPERIODTYPE")));
				} else {
					oCsaCpaResult.setPeriodType(null);
				}
				if (rsSearchCsaCpaCriteria.getString("NPERIOD") != null) {
					oCsaCpaResult.setPeriod(new Short(rsSearchCsaCpaCriteria
							.getString("NPERIOD")));
				} else {
					oCsaCpaResult.setPeriod(null);
				}
				if (rsSearchCsaCpaCriteria.getString("NFREQCAL") != null) {
					
					oCsaCpaResult.setFreqCal(new Short(rsSearchCsaCpaCriteria
							.getString("NFREQCAL")));
					
				} else {
					oCsaCpaResult.setFreqCal(null);
				}
				if (rsSearchCsaCpaCriteria.getString("NVINTAGE") != null) {
					oCsaCpaResult.setVintAge(new Short(rsSearchCsaCpaCriteria
							.getString("NVINTAGE")));
				} else {
					oCsaCpaResult.setVintAge(null);
				}
				if (rsSearchCsaCpaCriteria.getTimestamp("DTUPDATED") != null) {

					oCsaCpaResult.setTsDtUpdated(rsSearchCsaCpaCriteria
							.getTimestamp("DTUPDATED"));
				} else {
					oCsaCpaResult.setTsDtUpdated(null);
				}

				strSelectCsaCpaCriteriaQuery = getSQLString("Select",
						CHMConstants.SEARCH_CSA_CPA_CRITERIA_DETAILS);
				

				_pstmtCsaCpaCriteria = getPreparedStatement(strSelectCsaCpaCriteriaQuery);

				_pstmtCsaCpaCriteria.setLong(1, oCsaCpaResult.getAgentSeqNbr()
						.longValue());
				rsSearchCsaCpaCriteria = executeQuery(_pstmtCsaCpaCriteria);
				while (rsSearchCsaCpaCriteria.next()) {
					_oCsaCpaCriteriaDetailsResult = new CsaCpaCriteriaDetailsResult();

					_oCsaCpaCriteriaDetailsResult
							.setIsDirty(DataConstants.DISPLAY_MODE);

					_oCsaCpaCriteriaDetailsResult.setAgentDetSeqNbr(new Long(
							rsSearchCsaCpaCriteria.getLong("LRAGTSEQNBR")));
					_oCsaCpaCriteriaDetailsResult
							.setParamCd(rsSearchCsaCpaCriteria
									.getString("STRPARAMCD"));
					//Anup_AugRel_10_Agent Compensation Scheme 2010_05-05-2010_Starts
					_oCsaCpaCriteriaDetailsResult.setFromValue(rsSearchCsaCpaCriteria.getString("dtargetfrom"));
					_oCsaCpaCriteriaDetailsResult.setToValue(rsSearchCsaCpaCriteria.getString("dtargetto"));
					//Anup_AugRel_10_Agent Compensation Scheme 2010_05-05-2010_Ends
					if (rsSearchCsaCpaCriteria.getTimestamp("DTEFFFROM") != null) {
						_oCsaCpaCriteriaDetailsResult.setDtEffFrom(DateUtil
								.retGregorian(rsSearchCsaCpaCriteria
										.getTimestamp("DTEFFFROM")));
					} else {
						_oCsaCpaCriteriaDetailsResult.setDtEffFrom(null);
					}
					if (rsSearchCsaCpaCriteria.getTimestamp("DTEFFTO") != null) {
						_oCsaCpaCriteriaDetailsResult.setDtEffTo(DateUtil
								.retGregorian(rsSearchCsaCpaCriteria
										.getTimestamp("DTEFFTO")));
					} else {
						_oCsaCpaCriteriaDetailsResult.setDtEffTo(null);
					}

					if (rsSearchCsaCpaCriteria.getTimestamp("DTUPDATED") != null) {
						_oCsaCpaCriteriaDetailsResult
								.setTsDtUpdated(rsSearchCsaCpaCriteria
										.getTimestamp("DTUPDATED"));
					} else {
						_oCsaCpaCriteriaDetailsResult.setTsDtUpdated(null);
					}
					_oCsaCpaCriteriaDetailsResult
							.setStatusFlag(DataConstants.UPDATE_MODE); // changed

					_oCsaCpaCriteriaDtlList.add(_oCsaCpaCriteriaDetailsResult);
				}

			}
			oCsaCpaResult.setCsaCpaCriDetails(_oCsaCpaCriteriaDtlList);

			return oCsaCpaResult;
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, "P8132");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8132");
		} finally {
			try {
				if (_pstmtCsaCpaCriteria != null) {
					_pstmtCsaCpaCriteria.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P8132");
			}
		}
	}

	/**
	 * findCsaCpa finds whether the CsaCpa is there or not
	 * 
	 * @return boolean
	 * @param a_strAgentType
	 *            String
	 * @throws EElixirException
	 */
	/*
	public boolean findCsaCpa(String a_strAgentType) throws EElixirException {
		ResultSet rsSearchCsaCpa = null;
		PreparedStatement pstmtFindPrimaryKey = null;

		try {
			String strSelectCsaCpaQuery = getSQLString("Select",
					CHMConstants.FIND_CSACPA_BY_PRIMARYKEY);
			pstmtFindPrimaryKey = getPreparedStatement(strSelectCsaCpaQuery);
			pstmtFindPrimaryKey.setString(1, a_strAgentType.trim());
			rsSearchCsaCpa = executeQuery(pstmtFindPrimaryKey);

			if (rsSearchCsaCpa.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException(sqlex, "P7123");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P7123");
		} finally {
			try {
				if (rsSearchCsaCpa != null) {
					rsSearchCsaCpa.close();
				}

				if (pstmtFindPrimaryKey != null) {
					pstmtFindPrimaryKey.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}
*/
	public void updateCsaCpaCriteria(CsaCpaResult a_oCsaCpaCriteriaResult)
			throws EElixirException {
		updateCsaCpaCriterias(a_oCsaCpaCriteriaResult);

		if (a_oCsaCpaCriteriaResult.getCsaCpaCriDetails() != null) {
			for (int i = 0; i < a_oCsaCpaCriteriaResult.getCsaCpaCriDetails()
					.size(); i++) {
				CsaCpaCriteriaDetailsResult oCsaCpaCriteriaDetailsResult = (CsaCpaCriteriaDetailsResult) a_oCsaCpaCriteriaResult
						.getCsaCpaCriDetails().get(i);
				if (oCsaCpaCriteriaDetailsResult.getStatusFlag().equals(
						DataConstants.INSERT_MODE)) {					
					insertCsaCpaCriteriaDetails(oCsaCpaCriteriaDetailsResult,
							a_oCsaCpaCriteriaResult);
				} else if (oCsaCpaCriteriaDetailsResult.getStatusFlag().equals(
						DataConstants.UPDATE_MODE)) {
					
					updateCsaCpaCriteriaDetails(oCsaCpaCriteriaDetailsResult,
							a_oCsaCpaCriteriaResult);
				} else if (oCsaCpaCriteriaDetailsResult.getStatusFlag().equals(
						DataConstants.DELETE_MODE)) {					
					deleteCsaCpaCriteriaDetails(oCsaCpaCriteriaDetailsResult
							.getAgentDetSeqNbr());
				}
			}
		}

	}

	public void updateCsaCpaCriterias(CsaCpaResult a_oCsaCpaCriteriaResult)
			throws EElixirException {
		PreparedStatement pstmtUpdateCsaCpaCriMst = null;

		try {
			String strUpdateQuery = getSQLString("Update",
					CHMConstants.CSACPA_CRI_MST_UPDATE);
			pstmtUpdateCsaCpaCriMst = getPreparedStatement(strUpdateQuery);			
			String strAgentType = a_oCsaCpaCriteriaResult.getAgentType().trim();
			Short nFreqCal = a_oCsaCpaCriteriaResult.getFreqCal();
			Short nPeriodType = a_oCsaCpaCriteriaResult.getPeriodType();
			Short nPeriod = a_oCsaCpaCriteriaResult.getPeriod();
			Short nVintAge = a_oCsaCpaCriteriaResult.getVintAge();
			String strUpdatedBy = a_oCsaCpaCriteriaResult.getUserId();
			Long SeqNumb = a_oCsaCpaCriteriaResult.getAgentSeqNbr();

			if (nFreqCal != null) {
				pstmtUpdateCsaCpaCriMst.setShort(1, nFreqCal.shortValue());
			} else {
				pstmtUpdateCsaCpaCriMst.setNull(1, Types.SMALLINT);
			}
			if (nPeriodType != null) {
				pstmtUpdateCsaCpaCriMst.setShort(2, nPeriodType.shortValue());
			} else {
				pstmtUpdateCsaCpaCriMst.setNull(2, Types.SMALLINT);
			}
			if (nPeriod != null) {
				pstmtUpdateCsaCpaCriMst.setShort(3, nPeriod.shortValue());
			} else {
				pstmtUpdateCsaCpaCriMst.setNull(3, Types.SMALLINT);
			}
			if (nVintAge != null) {
				pstmtUpdateCsaCpaCriMst.setShort(4, nVintAge.shortValue());
			} else {
				pstmtUpdateCsaCpaCriMst.setNull(4, Types.SMALLINT);
			}

			pstmtUpdateCsaCpaCriMst.setString(5, strUpdatedBy);
			pstmtUpdateCsaCpaCriMst.setLong(6, SeqNumb.longValue());
			int iUpdate = executeUpdate(pstmtUpdateCsaCpaCriMst);			

		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException(sqlex, "P8133");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8133");
		} finally {
			try {
				if (pstmtUpdateCsaCpaCriMst != null) {
					pstmtUpdateCsaCpaCriMst.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}

	public void insertCsaCpaCriteriaDetails(
			CsaCpaCriteriaDetailsResult a_oCsaCpaCriteriaDetailsResult,
			CsaCpaResult a_oCsaCpaCriteriaResult) throws EElixirException {
		PreparedStatement pstmtCreateCsaCpaCriteria = null;
		Long SeqNumb;
		try {
			String strInsertCsaCpaCriQuery = getSQLString("Insert",
					CHMConstants.CSACPA_CRITERIA_DETAILS);
			pstmtCreateCsaCpaCriteria = getPreparedStatement(strInsertCsaCpaCriQuery);
			GregorianCalendar dtEffFrom = a_oCsaCpaCriteriaDetailsResult
					.getDtEffFrom();
			GregorianCalendar dtEffTo = a_oCsaCpaCriteriaDetailsResult
					.getDtEffTo();
			SeqNumb = getNextCsaCpaCriteriaSeqNbr();
			int iPos = 0;
			pstmtCreateCsaCpaCriteria.setLong(++iPos, SeqNumb.longValue());

			pstmtCreateCsaCpaCriteria.setLong(++iPos, a_oCsaCpaCriteriaResult
					.getAgentSeqNbr().longValue());
			pstmtCreateCsaCpaCriteria.setString(++iPos, a_oCsaCpaCriteriaResult
					.getAgentType());
			pstmtCreateCsaCpaCriteria.setString(++iPos,
					a_oCsaCpaCriteriaDetailsResult.getParamCd());

			pstmtCreateCsaCpaCriteria.setDouble(++iPos, new Double(
					a_oCsaCpaCriteriaDetailsResult.getFromValue()).doubleValue());
			
			pstmtCreateCsaCpaCriteria.setDouble(++iPos, new Double(
					a_oCsaCpaCriteriaDetailsResult.getToValue()).doubleValue());
			//Anup_AugRel_10_Agent Compensation Scheme 2010_05-05-2010_Ends
			if (dtEffFrom != null) {
				pstmtCreateCsaCpaCriteria.setTimestamp(++iPos, DateUtil
						.retTimestamp(dtEffFrom));
			}

			if (dtEffTo != null) {
				pstmtCreateCsaCpaCriteria.setTimestamp(++iPos, DateUtil
						.retTimestamp(dtEffTo));
			}

			pstmtCreateCsaCpaCriteria.setString(++iPos, a_oCsaCpaCriteriaResult
					.getUserId());
			executeUpdate(pstmtCreateCsaCpaCriteria);

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			log.fatal(sqlex.getMessage());
			throw new EElixirException(sqlex, "p8134");
		} catch (EElixirException eex) {
			eex.printStackTrace();
			log.fatal(eex.getMessage());
			throw new EElixirException(eex, "p8134");
		} finally {
			try {
				if (pstmtCreateCsaCpaCriteria != null) {
					pstmtCreateCsaCpaCriteria.close();
				}
			} catch (SQLException sqlex) {
				sqlex.printStackTrace();
				log.fatal(sqlex.getMessage());
				throw new EElixirException(sqlex, "p8134");
			}
		}

	}

	public void updateCsaCpaCriteriaDetails(
			CsaCpaCriteriaDetailsResult a_oCsaCpaCriteriaDetailsResult,
			CsaCpaResult a_oCsaCpaCriteriaResult) throws EElixirException {
		PreparedStatement pstmtUpdateCsaCpaCriDtl = null;

		try {
			String strUpdateQuery = getSQLString("Update",
					CHMConstants.CSACPA_CRI_DTL_UPDATE);
			pstmtUpdateCsaCpaCriDtl = getPreparedStatement(strUpdateQuery);			
			//String strParamCd = a_oCsaCpaCriteriaDetailsResult.getParamCd();			
			String dFromValue = a_oCsaCpaCriteriaDetailsResult.getFromValue();
			String dToValue = a_oCsaCpaCriteriaDetailsResult.getToValue();
			//GregorianCalendar dtEffFrom = a_oCsaCpaCriteriaDetailsResult
				//	.getDtEffFrom();
			GregorianCalendar dtEffTo = a_oCsaCpaCriteriaDetailsResult
					.getDtEffTo();
			String strUpdatedBy = a_oCsaCpaCriteriaResult.getUserId();

			int iPos = 0;
			pstmtUpdateCsaCpaCriDtl.setDouble(++iPos, (new Double(dFromValue))
					.doubleValue());
			pstmtUpdateCsaCpaCriDtl.setDouble(++iPos, (new Double(dToValue))
					.doubleValue());
			// Anup_AugRel_10_Agent Compensation Scheme 2010_05-05-2010_Ends

			pstmtUpdateCsaCpaCriDtl.setTimestamp(++iPos, DateUtil
						.retTimestamp(dtEffTo));			
			pstmtUpdateCsaCpaCriDtl.setString(++iPos, strUpdatedBy);

			pstmtUpdateCsaCpaCriDtl.setLong(++iPos,
					a_oCsaCpaCriteriaDetailsResult.getAgentDetSeqNbr()
							.longValue());
			executeUpdate(pstmtUpdateCsaCpaCriDtl);
			
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException(sqlex, "P8135");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8135");
		} finally {
			try {
				if (pstmtUpdateCsaCpaCriDtl != null) {
					pstmtUpdateCsaCpaCriDtl.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}

	}

	public void deleteCsaCpaCriteriaDetails(Long agentDescSquNum)
			throws EElixirException {
		PreparedStatement pstmtCsaCpaCriteria = null;

		try {

			String strdeleteCsaCpaCriteria = getSQLString("Delete",
					CHMConstants.CSACPA_CRITERIA_DELETE);
			
			pstmtCsaCpaCriteria = getPreparedStatement(strdeleteCsaCpaCriteria);
			int iPos = 0;
			pstmtCsaCpaCriteria.setLong(++iPos, agentDescSquNum.longValue());

			executeUpdate(pstmtCsaCpaCriteria);

		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());
			throw new EElixirException("P8136");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException("P8136");
		} finally {
			try {
				if (pstmtCsaCpaCriteria != null) {
					pstmtCsaCpaCriteria.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P8136");
			}
		}

	}

	/**
	 * For Getting next Sequence No. for CsaCpa Criteria
	 * 
	 * @return SeqNo
	 * @throws EElixirException
	 *             Amid P Sahu
	 */
	public Long getNextCsaCpaCriteriaSeqNbr() throws EElixirException {
		Statement stmtNextSeqCsaCpa = null;
		long lSeqNo;

		try {
			String strNextSeqQuery = getSQLString("Select",
					CHMConstants.CSACPA_DETAILS_SEQUENCENO);

			stmtNextSeqCsaCpa = getStatement();

			ResultSet rsSeqNo = stmtNextSeqCsaCpa.executeQuery(strNextSeqQuery);
			rsSeqNo.next();
			lSeqNo = rsSeqNo.getLong(1);			

			return new Long(lSeqNo);
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, "P8137");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8137");
		} finally {
			try {
				if (stmtNextSeqCsaCpa != null) {
					stmtNextSeqCsaCpa.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}

	/**
	 * For Getting next Sequence No. for CsaCpa
	 * 
	 * @return SeqNo
	 * @throws EElixirException
	 *             Amid P Sahu
	 */
	public Long getNextCsaCpaSeqNbr() throws EElixirException {
		Statement stmtNextSeqCbp = null;
		long lSeqNo;

		try {
			String strNextSeqQuery = getSQLString("Select",
					CHMConstants.CSACPA_SEQUENCENO);

			stmtNextSeqCbp = getStatement();

			ResultSet rsSeqNo = stmtNextSeqCbp.executeQuery(strNextSeqQuery);
			rsSeqNo.next();
			lSeqNo = rsSeqNo.getLong(1);
			log.debug(lSeqNo + "");

			return new Long(lSeqNo);
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());
			throw new EElixirException(sqlex, "P9006");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P9006");
		} finally {
			try {
				if (stmtNextSeqCbp != null) {
					stmtNextSeqCbp.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}

	/**
	 * findSegMent finds whether the Segment is there or not
	 * 
	 * @return boolean
	 * @param rsSearchCsaCpa
	 *            long
	 * @throws EElixirException
	 */
	public boolean findCsaCpaBySeqNo(long a_lCsaCpaSeqNbr)
			throws EElixirException {
		ResultSet rsSearchCsaCpa = null;
		PreparedStatement pstmtFindPrimaryKey = null;

		try {
			String strSelectCsaCpaQuery = getSQLString("Select",
					CHMConstants.FIND_CSACPA_BY_SEQUENCENO);
			pstmtFindPrimaryKey = getPreparedStatement(strSelectCsaCpaQuery);
			pstmtFindPrimaryKey.setLong(1, a_lCsaCpaSeqNbr);

			rsSearchCsaCpa = executeQuery(pstmtFindPrimaryKey);

			if (rsSearchCsaCpa.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException(sqlex, "P8138");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8138");
		} finally {
			try {
				if (rsSearchCsaCpa != null) {
					rsSearchCsaCpa.close();
				}

				if (pstmtFindPrimaryKey != null) {
					pstmtFindPrimaryKey.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}

	/**
	 * Inserts a new record
	 * 
	 * @param a_oCsaCpaResult
	 *            CsaCpaResult
	 * @throws EElixirException
	 */
	public Long createCsaCpa(CsaCpaResult a_oCsaCpaResult)
			throws EElixirException {
		PreparedStatement pstmtCreateCsaCpaMst = null;
		Long lCsaCpaSeqNbr;		
		try {
			String strInsertCsaCpaMstQuery = getSQLString("Insert",
					CHMConstants.CSACPA_INSERT);
			pstmtCreateCsaCpaMst = getPreparedStatement(strInsertCsaCpaMstQuery);
			lCsaCpaSeqNbr = getNextCsaCpaSeqNbr();
			int iPos = 0;
			pstmtCreateCsaCpaMst.setLong(++iPos, lCsaCpaSeqNbr.longValue());
			pstmtCreateCsaCpaMst.setString(++iPos, a_oCsaCpaResult
					.getAgentType().toUpperCase());
			pstmtCreateCsaCpaMst.setString(++iPos, a_oCsaCpaResult
					.getChannelType());
			pstmtCreateCsaCpaMst.setString(++iPos, a_oCsaCpaResult
					.getAgentTypeDesc());
			pstmtCreateCsaCpaMst.setString(++iPos, a_oCsaCpaResult.getUserId());
			executeUpdate(pstmtCreateCsaCpaMst);
			return lCsaCpaSeqNbr;
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			log.fatal(sqlex.getMessage());
			throw new EElixirException(sqlex, "P8139");
		} catch (EElixirException eex) {
			eex.printStackTrace();
			log.fatal(eex.getMessage());
			throw new EElixirException(eex, "P8139");
		} finally {
			try {
				if (pstmtCreateCsaCpaMst != null) {
					pstmtCreateCsaCpaMst.close();
				}
			} catch (SQLException sqlex) {
				sqlex.printStackTrace();
				log.fatal(sqlex.getMessage());
				throw new EElixirException(sqlex, "P8139");
			}
		}
	}

	/**
	 * getCsaCpa
	 * 
	 * @return CsaCpaResult
	 * @param a
	 *            long
	 * @throws EElixirException
	 */
	public CsaCpaResult getCsaCpa(long a_lCsaCpaSeqNbr) throws EElixirException {
		ResultSet rsSearchCsaCpa = null;
		PreparedStatement pstmtSearchCsaCpa = null;
		CsaCpaResult oCsaCpaResult = new CsaCpaResult();
		try {
			String strSelectCsaCpaQuery = getSQLString("Select",
					CHMConstants.SEARCH_CSACPA_BY_SEQUENCENO);		
			pstmtSearchCsaCpa = getPreparedStatement(strSelectCsaCpaQuery);
			pstmtSearchCsaCpa.setLong(1, a_lCsaCpaSeqNbr);			
			rsSearchCsaCpa = executeQuery(pstmtSearchCsaCpa);

			if (rsSearchCsaCpa.next()) {

				oCsaCpaResult.setIsDirty(DataConstants.DISPLAY_MODE);
				oCsaCpaResult.setAgentSeqNbr(new Long(rsSearchCsaCpa
						.getLong("LAGTSEQNBR")));
				oCsaCpaResult.setChannelType(rsSearchCsaCpa
						.getString("CCHANNELTYPE"));
				oCsaCpaResult.setAgentType(rsSearchCsaCpa
						.getString("STRAGTTYPE"));
				oCsaCpaResult.setAgentTypeDesc(rsSearchCsaCpa
						.getString("STRAGTTYPEDESC"));
				oCsaCpaResult.setTsDtUpdated(rsSearchCsaCpa
						.getTimestamp("DTUPDATED"));

			}
			return oCsaCpaResult;
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException(sqlex, "P8140");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8140");
		} finally {
			try {
				if (rsSearchCsaCpa != null) {
					rsSearchCsaCpa.close();
				}

				if (pstmtSearchCsaCpa != null) {
					pstmtSearchCsaCpa.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}

	}

	/**
	 * Updates the CSA/CPA
	 * 
	 * @return int No of rows updated
	 * @param: a_oCsaCpaResult CsaCpaResult
	 * @throws EElixirException
	 */
	public int updateCsaCpaMst(CsaCpaResult a_oCsaCpaResult)
			throws EElixirException {
		PreparedStatement pstmtUpdateCsaCpatMst = null;

		try {
			String strUpdateQuery = getSQLString("Update",
					CHMConstants.CSACPA_UPDATE);
			pstmtUpdateCsaCpatMst = getPreparedStatement(strUpdateQuery);			
			String strAgentDesc = a_oCsaCpaResult.getAgentTypeDesc();
			String strUpdatedBy = a_oCsaCpaResult.getUserId();
			long AgentDetSeqNbr = a_oCsaCpaResult.getAgentSeqNbr().longValue();

			pstmtUpdateCsaCpatMst.setString(1, strAgentDesc);
			pstmtUpdateCsaCpatMst.setString(2, strUpdatedBy);
			pstmtUpdateCsaCpatMst.setLong(3, AgentDetSeqNbr);

			int iUpdate = executeUpdate(pstmtUpdateCsaCpatMst);

			return iUpdate;
		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException(sqlex, "P8141");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P8141");
		} finally {
			try {
				if (pstmtUpdateCsaCpatMst != null) {
					pstmtUpdateCsaCpatMst.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, sqlex.getErrorCode() + "");
			}
		}
	}

	/**
	 * deletes CsaCpaResult record
	 * 
	 * @return void
	 * @param CsaCpaResult
	 * @throws EElixirException
	 */
	public void deleteCsaCpa(CsaCpaResult oCsaCpaResult)
			throws EElixirException {
		PreparedStatement _pstmtCsaCpa = null;
		PreparedStatement pstmtCsaCpaCriteria = null;

		Long AgentSeqNbr = oCsaCpaResult.getAgentSeqNbr();

		try {

			String strdeleteSegment = getSQLString("Delete",
					CHMConstants.CSACPA_DELETE);			
			_pstmtCsaCpa = getPreparedStatement(strdeleteSegment);

			_pstmtCsaCpa.setLong(1, AgentSeqNbr.longValue());

			executeUpdate(_pstmtCsaCpa);

			String strdeleteCsaCpaCriteria = getSQLString("Delete",
					CHMConstants.CSACPA_CRITERIA_DELETE_BY_SEQUENCYNO);			

			pstmtCsaCpaCriteria = getPreparedStatement(strdeleteCsaCpaCriteria);
			pstmtCsaCpaCriteria.setLong(1, AgentSeqNbr.longValue());
			executeUpdate(pstmtCsaCpaCriteria);

		} catch (SQLException sqlex) {
			log.exception(sqlex.getMessage());

			throw new EElixirException("P8142");
		} catch (EElixirException eex) {
			log.exception(eex.getMessage());
			throw new EElixirException("P8142");
		} finally {
			try {
				if (_pstmtCsaCpa != null) {
					_pstmtCsaCpa.close();
				}
			} catch (SQLException sqlex) {
				log.exception(sqlex.getMessage());
				throw new EElixirException(sqlex, "P8142");
			}
		}
	}

	/**
	 * Description getSQLString takes querytype and key and returns query
	 * 
	 * @return query string
	 * @param a_strSQLType
	 *            SQL Type i.e Select , Insert , Delete , Update
	 * @param a_strKey
	 *            String
	 * @throws EElixirException
	 */
	private String getSQLString(String a_strSQLType, String a_strKey)
			throws EElixirException {
		SqlRepositoryIF sqlRFIF = null;
		String strSql = "";

		try {
			sqlRFIF = CHMSqlRepository.getSqlRepository();
			strSql = sqlRFIF.getSQLString(a_strKey, a_strSQLType);
		} catch (EElixirException eex) {			
			log.exception(eex.getMessage());
			throw new EElixirException(eex, "P3019"); // could not get sql
			// string
		}

		return strSql;
	}

}
