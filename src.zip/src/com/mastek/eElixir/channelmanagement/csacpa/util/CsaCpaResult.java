/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME	    : CHANNEL MANAGEMENT
 *  FILENAME		: CsaCpaResult.java
 *  AUTHOR			: Amid P Sahu
 *  VERSION			: 1.0
 *  CREATION DATE   : June 25, 2008
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT	    : COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *									
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for CSA/CPA</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.csacpa.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class CsaCpaResult extends UserData implements Serializable {

	   private HashMap _hmCsaCpa;
	   private ArrayList _alCsaCpaCriDetails;
	   protected Long _lAgentSeqNbr = null;
	   private  String _cChannelType = null;
	   private  String _strAgentType = null;
	   private  String _strAgentTypeDesc = null;
	   private  Short _nPeriodType = null;
	   private Short _nPeriod = null;
	   private Short _nFreqCal = null;
	   private Short _nVintAge = null;
	   private  String _strStatusFlag = null;
	   
	  public CsaCpaResult()
	  {

	  }
    
	public HashMap getCsaCpa() {
		return _hmCsaCpa;
	}

	public void setCsaCpa(HashMap csaCpa) {
		this._hmCsaCpa = csaCpa;
	}
	

	public Long getAgentSeqNbr() {
		return _lAgentSeqNbr;
	}

	public void setAgentSeqNbr(Long agentSeqNbr) {
		this._lAgentSeqNbr = agentSeqNbr;
	}

	public String getChannelType() {
		return _cChannelType;
	}

	public void setChannelType(String channelType) {
		this._cChannelType = channelType;
	}

	public Short getFreqCal() {
		return _nFreqCal;
	}

	public void setFreqCal(Short freqCal) {
		this._nFreqCal = freqCal;
	}

	public Short getPeriod() {
		return _nPeriod;
	}

	public void setPeriod(Short period) {
		this._nPeriod = period;
	}

	public Short getPeriodType() {
		return _nPeriodType;
	}

	public void setPeriodType(Short periodType) {
		this._nPeriodType = periodType;
	}

	public Short getVintAge() {
		return _nVintAge;
	}

	public void setVintAge(Short vintAge) {
		this._nVintAge = vintAge;
	}

	public String getAgentType() {
		return _strAgentType;
	}

	public void setAgentType(String agentType) {
		this._strAgentType = agentType;
	}

	public String getAgentTypeDesc() {
		return _strAgentTypeDesc;
	}

	public void setAgentTypeDesc(String agentTypeDesc) {
		this._strAgentTypeDesc = agentTypeDesc;
	}

	public String getStatusFlag() {
		return _strStatusFlag;
	}

	public void setStatusFlag(String statusFlag) {
		this._strStatusFlag = statusFlag;
	}

	public ArrayList getCsaCpaCriDetails() {
		return _alCsaCpaCriDetails;
	}

	public void setCsaCpaCriDetails(ArrayList csaCpaCriDetails) {
		this._alCsaCpaCriDetails = csaCpaCriDetails;
	}

	

}
