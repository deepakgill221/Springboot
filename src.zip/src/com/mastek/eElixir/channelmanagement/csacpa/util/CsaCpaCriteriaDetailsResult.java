/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME		: CHANNEL MANAGEMENT
 *  FILENAME		: CsaCpaCriteriaDetailsResult.java
 *  AUTHOR			: Amid P Sahu
 *  VERSION			: 1.0
 *  CREATION DATE   : June 26, 2008
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT	    : COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *									

 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

/**
 * <p>Title: eElixir</p>
 * <p>Description:DVO for CSA/CPA</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */

package com.mastek.eElixir.channelmanagement.csacpa.util;

import java.io.Serializable;
import java.util.GregorianCalendar;

import com.mastek.eElixir.channelmanagement.util.UserData;

public class CsaCpaCriteriaDetailsResult extends UserData implements
		Serializable {

	protected Long _lAgentDetSeqNbr = null;
	private String _strParamCd = null;

	private String _strStatusFlag = null;

	private GregorianCalendar _dtEffFrom = null;

	private GregorianCalendar _dtEffTo = null;

	private String _dFromValue = null;
	private String _dToValue = null;
	
	

	public CsaCpaCriteriaDetailsResult() {

	}
	public Long getAgentDetSeqNbr() {
		return _lAgentDetSeqNbr;
	}

	public void setAgentDetSeqNbr(Long agentDetSeqNbr) {
		this._lAgentDetSeqNbr = agentDetSeqNbr;
	}
	
	public String getParamCd() {
		return _strParamCd;
	}

	public void setParamCd(String a_strParamCd) {
		this._strParamCd = a_strParamCd;
	}
//Anup_AugRel_10_Agent Compensation Scheme 2010_05-05-2010_Starts
	public void setFromValue(String a_dFromValue) {
		this._dFromValue = a_dFromValue;
	}

	public String getFromValue() {
		return _dFromValue;
	}	
	
	public void setToValue(String a_dToValue) {
		this._dToValue = a_dToValue;
	}

	public String getToValue() {
		return _dToValue;
	}
//Anup_AugRel_10_Agent Compensation Scheme 2010_05-05-2010_Ends
	public String getStatusFlag() {
		return _strStatusFlag;
	}

	public void setStatusFlag(String a_strStatusFlag) {
		this._strStatusFlag = a_strStatusFlag;
	}

	public GregorianCalendar getDtEffFrom() {
		return _dtEffFrom;
	}

	public void setDtEffFrom(GregorianCalendar a_dtEffFrom) {
		this._dtEffFrom = a_dtEffFrom;
	}

	public GregorianCalendar getDtEffTo() {
		return _dtEffTo;
	}

	public void setDtEffTo(GregorianCalendar a_dtEffTo) {
		this._dtEffTo = a_dtEffTo;
	}

	public String toString() {
		String retValue = " _strParamCd : " + _strParamCd + "_dtEffFrom"
				+ _dtEffFrom + "_dtEffTo :" + _dtEffTo + " StatusFlag : "
				+ _strStatusFlag;
		retValue = retValue + "\n";
		return retValue;
	}

	

}
