/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME      : CHANNEL MANAGEMENT
*  FILENAME         : CsaCpaCriteriaSearch.java
*  AUTHOR           : Amid P Sahu
*  VERSION          : 1.0
*  CREATION DATE    : June 26, 2008
*  COMPANY          : Mastek Ltd.
*  COPYRIGHT        : COPYRIGHT (C) 2008.
*  SPEC NAME        : EVEREST
*
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
*  VERSION        DATE                BY                        REASON
*--------------------------------------------------------------------------------
* 
*--------------------------------------------------------------------------------
*
**********************************************************************/
package com.mastek.eElixir.channelmanagement.csacpa.action;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.servlet.http.HttpServletRequest;

import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentCriteriaResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class CsaCpaCriteriaSearch extends Action
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);

    /**
     * Constructor for CsaCpaCriteriaSearch
     */
    public CsaCpaCriteriaSearch()
    {
    }

    /**
     * The Process Method is used to retrieve the CsaCpa criteria records
     * @param a_oRequest HttpServletRequest
     * @throws EElixirException
     */
    public void process(HttpServletRequest a_oRequest)
        throws EElixirException
    {
    	CsaCpaResult oCsaCpaResult = null;
        String strAgentType = null;
        String strChannelType=null;//Arun Modified for Production defect

        try
        {
            a_oRequest.setAttribute("actiontype",
                DataConstants.ACTION_LISTSEARCH);

            CHMSL oRemoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
            strAgentType = a_oRequest.getParameter("strAgentType");
            strChannelType=a_oRequest.getParameter("strChannelType");
            oCsaCpaResult = oRemoteCHMSL.searchCsaCpaCriteria(strAgentType,strChannelType);
            setResult(oCsaCpaResult);
            a_oRequest.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
        }
        catch (RemoteException rex)
        {
			_oLogger.fatal(getClass().getName(),"process","RemoteException "+rex.getMessage());
            a_oRequest.setAttribute("ResultObject", oCsaCpaResult);
            throw new EElixirException(rex, "P1006");
        }
        catch (CreateException cex)
        {
			_oLogger.fatal(getClass().getName(),"process","CreateException "+cex.getMessage());
            a_oRequest.setAttribute("ResultObject", oCsaCpaResult);
            throw new EElixirException(cex, "P1007");
        }
        catch (EElixirException eex)
        {
			_oLogger.fatal(getClass().getName(),"process","EElixirException "+eex.getMessage());
            a_oRequest.setAttribute("ResultObject", oCsaCpaResult);
            throw eex;
        }
        catch (Exception ex)
        {
			_oLogger.fatal(getClass().getName(),"process","Exception "+ex.getMessage());
            a_oRequest.setAttribute("ResultObject", oCsaCpaResult);
            throw new EElixirException(ex, "P1001");
        }
    }
}
