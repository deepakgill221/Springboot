/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME				: CsaCpaCriteriaUpdate.java
 *  AUTHOR					: Amid P Sahu
 *  VERSION					: 1.0
 *  CREATION DATE		    : June 30, 2008
 *  COMPANY				    : Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 * 
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.csacpa.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaCriteriaDetailsResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DateUtil;
import com.mastek.eElixir.common.util.Logger;

public class CsaCpaCriteriaUpdate extends Action {

	/**
	 * Constructor
	 */

	public CsaCpaCriteriaUpdate() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :
	 *            ResultObject object.
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		CHMSL remoteCHMSL = null;
		try {
			setCsaCpaCriteria(request);
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			remoteCHMSL.updateCsaCpaCriteria(_oCsaCpaCriteriaResult);
			_oCsaCpaCriteriaResult = remoteCHMSL.searchCsaCpaCriteria(request
					.getParameter("strAgentType"),request.getParameter("strChannelType"));

			setResult(_oCsaCpaCriteriaResult);

		} catch (FinderException fex) {
			request.setAttribute("ResultObject", _oCsaCpaCriteriaResult);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oCsaCpaCriteriaResult);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oCsaCpaCriteriaResult);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log
					.debug("In SegmentUpdate eelixir exception before setting result"
							+ eLex);
			if (eLex.getCustomErrorCode().equalsIgnoreCase("P1100")) {
				try {
					_oCsaCpaCriteriaResult = remoteCHMSL
							.searchCsaCpaCriteria(request
									.getParameter("strAgentType"),request.getParameter("strChannelType"));
				} catch (RemoteException rex) {
					request.setAttribute("ResultObject",
							_oCsaCpaCriteriaResult);
					throw new EElixirException(rex, "P1006");
				}
			}
			request.setAttribute("ResultObject", _oCsaCpaCriteriaResult);
			throw eLex;
		}

	}

	private void setCsaCpaCriteria(HttpServletRequest a_oRequest) {
		String strAgentType = a_oRequest.getParameter("strAgentType");
		String strAgentDesc = a_oRequest.getParameter("strAgentDesc");
		String nPeriodType = a_oRequest.getParameter("nPeriodType");
		String nPeriod = a_oRequest.getParameter("nPeriod");
		String nFreqCal = a_oRequest.getParameter("nFreqCal");
		String nVintAge = a_oRequest.getParameter("nVintAge");
		String SeqNumb = a_oRequest.getParameter("SeqNumb");
		String strChannelType=a_oRequest.getParameter("strChannelType");/*Arun Modified for Production defect*/
		String strParamCd[] = a_oRequest.getParameterValues("strParamCdVal");

		String lAgentDetSeqNbr[] = a_oRequest.getParameterValues("AgentDetSeqNbr");
		String dFromValue[] = a_oRequest.getParameterValues("dFromValue");
		String dToValue[] = a_oRequest.getParameterValues("dToValue");
		String dtEffFrom[] = a_oRequest.getParameterValues("dtEffFrom");
		String dtEffTo[] = a_oRequest.getParameterValues("dtEffTo");

		String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
		String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");
		
		
		HttpSession session = a_oRequest.getSession();

		String _strUserId = (String) session.getAttribute("username");

		_oCsaCpaCriteriaResult = new CsaCpaResult();
		_oCsaCpaCriteriaResult.setChannelType(strChannelType);
		_oCsaCpaCriteriaResult.setAgentType(strAgentType);

		_oCsaCpaCriteriaResult.setAgentTypeDesc(strAgentDesc);

		_oCsaCpaCriteriaResult.setPeriodType(new Short(nPeriodType));
		
		if (SeqNumb != null && !SeqNumb.trim().equals("")) {
			_oCsaCpaCriteriaResult.setAgentSeqNbr(new Long(SeqNumb));

		} else {
			_oCsaCpaCriteriaResult.setAgentSeqNbr(null);
		}

		if (nPeriod != null && !nPeriod.trim().equals("")) {
			_oCsaCpaCriteriaResult.setPeriod(new Short(nPeriod));
		} else {
			_oCsaCpaCriteriaResult.setPeriod(null);
		}

		if (nFreqCal != null && !nFreqCal.trim().equals("")) {
			_oCsaCpaCriteriaResult.setFreqCal(new Short(
					nFreqCal));
		} else {
			_oCsaCpaCriteriaResult.setFreqCal(null);
		}
		
		
		if (nVintAge != null && !nVintAge.trim().equals("")) {
			_oCsaCpaCriteriaResult.setVintAge(new Short(
					nVintAge));
		} else {
			_oCsaCpaCriteriaResult.setVintAge(null);
		}

		_oCsaCpaCriteriaResult.setUserId(_strUserId);

		if (statusFlag != null) {
			for (int i = 0; i < statusFlag.length; i++) {

				if (!(statusFlag[i].equals(DataConstants.CLEAR_MODE))) {
					_oCsaCpaCriteriaDetailsResult = new CsaCpaCriteriaDetailsResult();
					
					if (lAgentDetSeqNbr[i] != null && !lAgentDetSeqNbr[i].trim().equals("")) {
						_oCsaCpaCriteriaDetailsResult.setAgentDetSeqNbr(new Long(lAgentDetSeqNbr[i]));

					} else {
						_oCsaCpaCriteriaDetailsResult.setAgentDetSeqNbr(null);
					}
					_oCsaCpaCriteriaDetailsResult.setParamCd(strParamCd[i]
							.trim());
					_oCsaCpaCriteriaDetailsResult.setFromValue(dFromValue[i].trim());
					_oCsaCpaCriteriaDetailsResult.setToValue(dToValue[i].trim());
					_oCsaCpaCriteriaDetailsResult.setDtEffFrom(DateUtil
							.retGCDate(dtEffFrom[i].trim()));
					_oCsaCpaCriteriaDetailsResult.setDtEffTo(DateUtil
							.retGCDate(dtEffTo[i].trim()));
					_oCsaCpaCriteriaDetailsResult.setStatusFlag(statusFlag[i]);

					if (dtUpdated[i] != null && !dtUpdated[i].trim().equals("")) {
						_oCsaCpaCriteriaDetailsResult.setTsDtUpdated(Timestamp
								.valueOf(dtUpdated[i]));
					}

					_oCsaCpaCriteriaList.add(_oCsaCpaCriteriaDetailsResult);

				}
			}
		}
		_oCsaCpaCriteriaResult.setCsaCpaCriDetails(_oCsaCpaCriteriaList);
	}

	// class level variable declarations.

	CsaCpaResult _oCsaCpaCriteriaResult = null;

    CsaCpaCriteriaDetailsResult _oCsaCpaCriteriaDetailsResult = null;

	ArrayList _oCsaCpaCriteriaList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
