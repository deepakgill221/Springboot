/********************************************************************
 *
 *  PROJECT					: MNYL
 *  MODULE NAME		        : CHANNEL MANAGEMENT
 *  FILENAME					: CsaCpaUpdate
 *  AUTHOR					: Amid P Sahu
 *  VERSION					: 1.0
 *  CREATION DATE		    : July 02, 2008
 *  COMPANY				    : Mastek Ltd.
 *  COPYRIGHT				: COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *   
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.csacpa.action;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSL;
import com.mastek.eElixir.channelmanagement.ejb.sessionbean.CHMSLHome;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult;
import com.mastek.eElixir.channelmanagement.util.CHMLookup;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Action;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.Logger;

public class CsaCpaUpdate extends Action {

	/**
	 * Constructer
	 */

	public CsaCpaUpdate() {

	}

	/**
	 * This method makes a remote call to the Session bean which in turn makes a
	 * local call to all other bean .
	 * 
	 * @param :
	 *            ResultObject object.
	 * @roseuid 3B94961803CB
	 * @throws EElixirException
	 */

	public void process(HttpServletRequest request) throws EElixirException {
		request.setAttribute("actiontype", DataConstants.ACTION_UPDATE);
		CHMSL remoteCHMSL = null;
		try {
			setCsaCpa(request);
			log.debug("Amid inside the process method");
			remoteCHMSL = CHMLookup.getRemote("CHMSLHome", CHMSLHome.class);
			remoteCHMSL.updateCsaCpa(_oCsaCpaList);
			_oCsaCpaList = remoteCHMSL.searchCsaCpa(request
					.getParameter("cChannelType"));
			setResult(_oCsaCpaList);
		} catch (FinderException fex) {
			request.setAttribute("ResultObject", _oCsaCpaList);
			throw new EElixirException(fex, "P1007");
		} catch (RemoteException rex) {
			request.setAttribute("ResultObject", _oCsaCpaList);
			throw new EElixirException(rex, "P1006");
		} catch (CreateException cex) {
			request.setAttribute("ResultObject", _oCsaCpaList);

			throw new EElixirException(cex, "P1007");
		} catch (EElixirException eLex) {
			log
					.debug("In SegmentUpdate eelixir exception before setting result"
							+ eLex);
			if (eLex.getCustomErrorCode().equalsIgnoreCase("P1100")) {
				try {
					_oCsaCpaList = remoteCHMSL.searchCsaCpa(request
							.getParameter("cChannelType"));
					setResult(_oCsaCpaList);
				} catch (RemoteException rex) {
					request.setAttribute("ResultObject", _oCsaCpaList);
					throw new EElixirException(rex, "P1006");
				} catch (FinderException cex) {
					request.setAttribute("ResultObject", _oCsaCpaList);
					throw new EElixirException(cex, "P1007");
				}

			}
			request.setAttribute("ResultObject", _oCsaCpaList);
			throw eLex;
		}

	}

	private void setCsaCpa(HttpServletRequest a_oRequest) {
		String strAgentType[] = a_oRequest.getParameterValues("strAgentType");
		String strAgentDesc[] = a_oRequest.getParameterValues("strAgentDesc");
		String statusFlag[] = a_oRequest.getParameterValues("statusFlag");
		String[] dtUpdated = a_oRequest.getParameterValues("dtUpdated");
		String cChannelType = a_oRequest.getParameter("cChannelType");
		HttpSession session = a_oRequest.getSession();
		String _strUserId = (String) session.getAttribute("username");
		String SeqNumb[] = a_oRequest.getParameterValues("SeqNumb");

		if (statusFlag != null) {
			for (int i = 0; i < statusFlag.length; i++) {
				if (!(statusFlag[i].equals(DataConstants.CLEAR_MODE))) {
					_oCsaCpaResult = new CsaCpaResult();
					log.debug("Amid inside the setCsaCpa method befor seqno"+SeqNumb[i]);
					if (SeqNumb[i] != null && !SeqNumb[i].trim().equals("")) {
						_oCsaCpaResult.setAgentSeqNbr(new Long(SeqNumb[i]));

					} else {
						_oCsaCpaResult.setAgentSeqNbr(null);
					}
					log.debug("Amid inside the setCsaCpa method after seqno");
					_oCsaCpaResult.setChannelType(cChannelType);
					_oCsaCpaResult.setAgentType(strAgentType[i]);
					_oCsaCpaResult.setAgentTypeDesc(strAgentDesc[i]);
					_oCsaCpaResult.setStatusFlag(statusFlag[i]);
					if (dtUpdated[i] != null && !dtUpdated[i].trim().equals("")) {
						_oCsaCpaResult.setTsDtUpdated(Timestamp
								.valueOf(dtUpdated[i]));
					}
					_oCsaCpaResult.setUserId(_strUserId);

					log.debug("Amid show all parameter: setChannelType-"
							+ cChannelType + " agent type-" + strAgentType[i]
							+ "agent desc-" + strAgentDesc[i] + " statusFlag-"
							+ statusFlag[i] + " dtUpdated-" + dtUpdated[i]
							+ " strUserId- " + _strUserId);
					_oCsaCpaList.add(_oCsaCpaResult);

				}
			}
		}
	}

	// class level variable declarations.

	CsaCpaResult _oCsaCpaResult = null;

	ArrayList _oCsaCpaList = new ArrayList();

	private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);

}
