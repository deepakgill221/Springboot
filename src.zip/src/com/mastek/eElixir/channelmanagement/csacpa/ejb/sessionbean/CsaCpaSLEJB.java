/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : CHANNEL MANAGEMENT
*  FILENAME			: CsaCpaSLHome.java
*  AUTHOR			: Amid P Sahu	
*  VERSION			: 1.0
*  CREATION DATE    : June 24, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2008.
*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION        DATE           BY                        REASON
*--------------------------------------------------------------------------------
 
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.csacpa.ejb.sessionbean;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import com.mastek.eElixir.channelmanagement.csacpa.dax.CsaCpaDAX;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.channelmanagement.csacpa.ejb.entitybean.CsaCpa;
import com.mastek.eElixir.channelmanagement.csacpa.ejb.entitybean.CsaCpaCriteriaPK;
import com.mastek.eElixir.channelmanagement.csacpa.ejb.entitybean.CsaCpaHome;
import com.mastek.eElixir.channelmanagement.csacpa.ejb.entitybean.CsaCpaCriteriaHome;
import com.mastek.eElixir.channelmanagement.csacpa.ejb.entitybean.CsaCpaCriteria;
import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.CHMPropertyUtil;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.EJBHomeFactory;
import com.mastek.eElixir.common.util.Logger;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.entitybean.SegmentMaster;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.entitybean.SegmentMasterHome;
import com.mastek.eElixir.channelmanagement.segmentation.ejb.entitybean.SegmentMasterPK;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentCriteriaResult;
import com.mastek.eElixir.channelmanagement.segmentation.util.SegmentationResult;
import com.mastek.eElixir.channelmanagement.structuremovements.ejb.entitybean.ManualOverridePK;

public class CsaCpaSLEJB implements SessionBean
{
    private static final Logger _oLogger = Logger.getInstance(Constants.CHM_MODULE_ID);
    /**
     * Attributes declaration
     */
    private CsaCpaDAX _oCsaCpaDAX=null;
    private Connection _oConnection = null;
    private SessionContext _oSessionContext = null;
    private CsaCpaCriteriaHome _oCsaCpaCriteriaHome=null;
    private CsaCpaCriteria _oCsaCpaCriteria=null;
    private CsaCpaCriteriaPK _oCsaCpaCriteriaPK=null;
    private CsaCpaHome _oCsaCpaHome=null;
    private CsaCpa _oCsaCpa=null;
   
    /**
     * Constructor of the SegmentSLEJB class
     */
    public CsaCpaSLEJB()
    {
    }
    
    /**
     * Called by the container to create a session bean instance. Its parameters typically
     * contain the information the client uses to customize the bean instance for its use.
     * It requires a matching pair in the bean class and its home interface.
     * @throws CreateException
     * @throws EElixirException
     */
    public void ejbCreate() throws CreateException, EElixirException
    {
    }

    /**
     * A container invokes this method before it ends the life of the session object. This
     * happens as a result of a client's invoking a remove operation, or when a container
     * decides to terminate the session object after a timeout. This method is called with
     * no transaction context.
     */
    public void ejbRemove()
    {
    }

    /**
     * The activate method is called when the instance is activated from its 'passive' state.
     * The instance should acquire any resource that it has released earlier in the ejbPassivate()
     * method. This method is called with no transaction context.
     */
    public void ejbActivate()
    {
    }

    /**
     * The passivate method is called before the instance enters the 'passive' state. The
     * instance should release any resources that it can re-acquire later in the ejbActivate()
     * method. After the passivate method completes, the instance must be in a state that
     * allows the container to use the Java Serialization protocol to externalize and store
     * away the instance's state. This method is called with no transaction context.
     */
    public void ejbPassivate()
    {
    }

    /**
     * Set the associated session context. The container calls this method after the instance
     * creation. The enterprise Bean instance should store the reference to the context
     * object in an instance variable. This method is called with no transaction context.
     * @param sc SessionContext
     */
    public void setSessionContext(SessionContext a_oSessionContext)
    {
        this._oSessionContext = a_oSessionContext;
    }

    
    public ArrayList searchCsaCpa(String a_cChannelType) throws FinderException, EElixirException
    {
    	try
    	{
    	_oCsaCpaDAX = getDAX();
    	
    	 return _oCsaCpaDAX.searchCsaCpa(a_cChannelType);
    	}
    	catch (EElixirException eex)
        {           
            throw eex;
        }
    	finally
    	{
    		try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{				
				throw new EElixirException(eElex, "P1005");
			}
    		
    	}
        	
    }
    
   
    /**
     * Gets the Dax object and sets the connection on it.
     * @return CsaCpaDAX
     * @throws EElixirException
     */
    private CsaCpaDAX getDAX() throws EElixirException
    {
        _oConnection = DBConnection.getConnection();

        CHMDAXFactory oCHMDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
        CsaCpaDAX _oCsaCpaDAX = (CsaCpaDAX) oCHMDAXFactory.createDAX(CHMDAXFactory.CSACPADAX);
        _oCsaCpaDAX.setConnection(_oConnection);
        return _oCsaCpaDAX;
    }

    public CsaCpaResult searchCsaCpaCriteria(String a_strAgentType,String a_strChannelType) throws FinderException, EElixirException
    {
    	try{
    	_oCsaCpaDAX = getDAX();
    	
    	 return _oCsaCpaDAX.searchCsaCpaCriteria(a_strAgentType,a_strChannelType);
    	}
    	catch (EElixirException eex)
        {           
            throw eex;
        }
    	finally
    	{
    		try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{				
				throw new EElixirException(eElex, "P1005");
			}
    		
    	}
        	
    }
    
    public void updateCsaCpaCriteria(CsaCpaResult a_oCsaCpaCriteriaResult)throws FinderException, EElixirException
    {    	
        try
        {
        	CsaCpaCriteriaPK oCsaCpaCriteriaPK=null;
            EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oCsaCpaCriteriaHome = (CsaCpaCriteriaHome) oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
            "CsaCpaCriteriaHome"), CsaCpaCriteriaHome.class);
             oCsaCpaCriteriaPK = new CsaCpaCriteriaPK(a_oCsaCpaCriteriaResult.getAgentSeqNbr());
            _oCsaCpaCriteria = _oCsaCpaCriteriaHome.findByPrimaryKey(oCsaCpaCriteriaPK);
            _oCsaCpaCriteria.setCsaCpaCriteriaResult(a_oCsaCpaCriteriaResult);
         }
         catch (RemoteException rex)
         {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "RemoteException " + rex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
         }
        catch (FinderException fex)
        {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "FinderException " + fex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw new EElixirException(fex, "P7123");
        }
        catch (EJBException ejbex)
        {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "EJBException " + ejbex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "EElixirException " + eex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw eex;
        }
        finally
		{
			try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{
				_oLogger.fatal(getClass().getName(), "updateSegmentMaster",
					"EElixirException " + eElex.getMessage());
				throw new EElixirException(eElex, "P1005");
			}
		}
   }
    public void updateCsaCpa(ArrayList a_alCsaCpaList) throws FinderException, EElixirException
    {
    	CsaCpaResult oCsaCpaResult = null;
		boolean bFlag=false;
        try
        {
        	CsaCpaCriteriaPK oCsaCpaCriteriaPK=null;
            EJBHomeFactory oEJBHomeFactory = EJBHomeFactory.getFactory();
            CHMPropertyUtil oCHMPropertyUtil = CHMPropertyUtil.getPropertyUtil();
            _oCsaCpaHome = (CsaCpaHome) oEJBHomeFactory.lookUpHome(oCHMPropertyUtil.getCHMProperty(
            "CsaCpaHome"), CsaCpaHome.class);
              String strStatus = null;
            if (a_alCsaCpaList != null)
            {
            	int iSize = a_alCsaCpaList.size();
                for (int i = 0; i < iSize; i++)
                {                	
                	oCsaCpaResult = (CsaCpaResult) a_alCsaCpaList.get(i);
                	strStatus=oCsaCpaResult.getStatusFlag();
                	      	
				   	 if(strStatus.trim().equals(DataConstants.INSERT_MODE))
                     {              		 
                	    _oCsaCpaDAX = (CsaCpaDAX)getDAX();                		
                         _oCsaCpaHome.create(oCsaCpaResult);
                     }
                	 else if (strStatus.trim().equals(DataConstants.UPDATE_MODE))
                     {               		
                		 oCsaCpaCriteriaPK = new CsaCpaCriteriaPK(oCsaCpaResult.getAgentSeqNbr());
                		 _oCsaCpa = _oCsaCpaHome.findByPrimaryKey(oCsaCpaCriteriaPK);
                        CsaCpaResult oConCsaCpaResult = _oCsaCpa.getCsaCpaResult();
                                     
                        /* if ((oConCsaCpaResult.getTsDtUpdated() != null) &&
                                 (!oConCsaCpaResult.getTsDtUpdated().equals(oCsaCpaResult.getTsDtUpdated())))
                         {
                             _oLogger.fatal(
                                 "concurrency failed thorwing exception");
                             throw new EElixirException("P1100");
                         }*/

                         _oCsaCpa.setCsaCpaResult(oCsaCpaResult);
                     }
                	 else if (strStatus.trim().equals(DataConstants.DELETE_MODE))
                     {
                		 _oCsaCpaDAX = (CsaCpaDAX)getDAX();
                		 _oCsaCpaDAX.deleteCsaCpa(oCsaCpaResult);
                     }
                	 
                }
            }
        }
        catch (CreateException cex)
        {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "CreateException " + cex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw new EElixirException(cex, "P7131");
        }
        catch (RemoteException rex)
        {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "RemoteException " + rex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw new EElixirException(rex, "P1006");
        }
        catch (FinderException fex)
        {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "FinderException " + fex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw new EElixirException(fex, "P7123");
        }
        catch (EJBException ejbex)
        {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "EJBException " + ejbex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw (EElixirException) ejbex.getCausedByException();
        }
        catch (EElixirException eex)
        {
            _oLogger.fatal(getClass().getName(), "updateSegmentMaster ",
                "EElixirException " + eex.getMessage());
            _oSessionContext.setRollbackOnly();
            throw eex;
        }
        finally
		{
			try
			{
				if (_oConnection != null)
				{
					DBConnection.closeConnection(_oConnection);
				}
			}
			catch (EElixirException eElex)
			{
				_oLogger.fatal(getClass().getName(), "updateSegmentMaster",
					"EElixirException " + eElex.getMessage());
				throw new EElixirException(eElex, "P1005");
			}
		}
        
    }
    
 
  }