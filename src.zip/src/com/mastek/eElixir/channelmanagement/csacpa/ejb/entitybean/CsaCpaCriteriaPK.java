/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME	    : CHANNEL MANAGEMENT
 *  FILENAME		: CsaCpaCriteriaPK.java
 *  AUTHOR			: Amid P Sahu
 *  VERSION			: 1.0
 *  CREATION DATE   : July 03, 2008
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT	    : COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.csacpa.ejb.entitybean;

import java.io.Serializable;

/**
 * <p>
 * Title: eElixir
 * </p>
 * <p>
 * Description:This primary key class is for the MasterBean which contains get &
 * set methods for the primary key field Seq No
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: Mastek Ltd
 * </p>
 * 
 * @author Amid P Sahu
 * @version 1.0
 */
public class CsaCpaCriteriaPK implements Serializable {

	/**
	 * Constructor
	 */
	public CsaCpaCriteriaPK() {
	}

	/**
	 * Referencing to object that represents the entity object.
	 * 
	 * @return integer value
	 */

	public int hashCode() {
		int iHashcode = 0;
		if (_lcsacpaseqnbr != null)
			iHashcode = _lcsacpaseqnbr.hashCode();
		return iHashcode;

	}

	/**
	 * Method that compares two entity object references -- since the Java
	 * Object.equals(Object
	 * 
	 * @param obj
	 *            method is unspecified.
	 * @return boolean
	 */

	public boolean equals(java.lang.Object obj) {
		boolean bEqual = false;
		if (obj != null && obj instanceof CsaCpaCriteriaPK) {
			if (this._lcsacpaseqnbr == ((CsaCpaCriteriaPK) obj)._lcsacpaseqnbr) {
				bEqual = true;
			}
		}
		return bEqual;

	}

	/**
	 * Own toString() method of a bean's PK class.
	 * 
	 * @return String
	 */
	public java.lang.String toString() {
		return null;
	}

	/**
	 * Method to access the Seq No field
	 * 
	 * @return String
	 */
	public Long getCsaCpaSeqNbr() {
		return this._lcsacpaseqnbr;
	}

	/**
	 * Method to set value of the Seq No field
	 * 
	 * @param a_strSegmentType
	 *            String
	 * 
	 */
	public void setCsaCpaSeqNbr(Long a_lsegprdadjseqnbr) {
		this._lcsacpaseqnbr = a_lsegprdadjseqnbr;
	}

	public CsaCpaCriteriaPK(Long a_lcbpseqnbr) {
		this._lcsacpaseqnbr = a_lcbpseqnbr;
	}

	private Long _lcsacpaseqnbr;

}