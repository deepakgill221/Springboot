/********************************************************************
*
*  PROJECT			: MNYL
*  MODULE NAME	    : CHANNEL MANAGEMENT
*  FILENAME			: CsaCpaCriteria.java
*  AUTHOR			: Amid P Sahu
*  VERSION			: 1.0
*  CREATION DATE    : June 30, 2008
*  COMPANY			: Mastek Ltd.
*  COPYRIGHT	    : COPYRIGHT (C) 2008.

*
*  MODIFICATION HISTORY:-
*--------------------------------------------------------------------------------
* VERSION	DATE		  BY			REASON
*--------------------------------------------------------------------------------
*
*
*--------------------------------------------------------------------------------
*
*********************************************************************/
package com.mastek.eElixir.channelmanagement.csacpa.ejb.entitybean;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;
import com.mastek.eElixir.common.exception.EElixirException;


/**
 *
 * <p>Title: eElixir</p>
 * <p>Description:This  CsaCpaCriteria interface provides method for retreving data from the
 * database through primaryKey  </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */



public interface CsaCpaCriteria extends EJBObject
{
  /* This method gets the SegmentationResult Object
  * @return SegmentCriteriaResult
  */
  public CsaCpaResult getCsaCpaCriteriaResult() throws RemoteException, EElixirException;

  /* This method sets the SegmentCriteriaResult Object
  * @param a_oSegmentCriteriaResult SegmentCriteriaResult
  */
  public void setCsaCpaCriteriaResult(CsaCpaResult a_oCsaCpaCriteriaResult) throws RemoteException, EElixirException;

}