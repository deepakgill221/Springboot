/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME	    : CHANNEL MANAGEMENT
 *  FILENAME			: CsaCpaSLHome.java
 *  AUTHOR			: Amid P Sahu	
 *  VERSION			: 1.0
 *  CREATION DATE    : June 24, 2008
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT	    : COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION        DATE	BY              REASON
 *--------------------------------------------------------------------------------

 *--------------------------------------------------------------------------------
 *
 *********************************************************************/
package com.mastek.eElixir.channelmanagement.csacpa.ejb.sessionbean;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;

public interface CsaCpaSL extends EJBObject {
	/**
	 * 
	 * @param String
	 *            a_cChannelType
	 * @throws FinderException
	 * @throws RemoteException
	 * @throws EElixirException
	 */
	public ArrayList searchCsaCpa(String a_cChannelType)
			throws FinderException, RemoteException, EElixirException;

	/**
	 * 
	 * @param ArrayList
	 * @throws FinderException
	 * @throws RemoteException
	 * @throws EElixirException
	 */
	public void updateCsaCpa(ArrayList a_alCsaCpaList)
			throws FinderException, RemoteException, EElixirException;

	/**
	 * 
	 * @param String
	 * @throws FinderException
	 * @throws RemoteException
	 * @throws EElixirException
	 */
	public CsaCpaResult searchCsaCpaCriteria(String a_strAgentType,String a_strChannelType)
			throws FinderException, RemoteException, EElixirException;

	/**
	 * 
	 * @param SegmentCriteriaResult
	 * @throws FinderException
	 * @throws RemoteException
	 * @throws EElixirException
	 */
	public void updateCsaCpaCriteria(CsaCpaResult a_CsaCpaCriteriaResult)
			throws FinderException, RemoteException, EElixirException;

}
