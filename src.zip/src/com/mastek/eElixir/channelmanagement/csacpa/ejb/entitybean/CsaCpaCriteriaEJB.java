/********************************************************************
 *
 *  PROJECT			: MNYL
 *  MODULE NAME	    : CHANNEL MANAGEMENT
 *  FILENAME	    : CsaCpaCriteriaEJB.java
 *  AUTHOR			: Amid P Sahu
 *  VERSION			: 1.0
 *  CREATION DATE   : June 30, 2008
 *  COMPANY			: Mastek Ltd.
 *  COPYRIGHT	    : COPYRIGHT (C) 2008.

 *
 *  MODIFICATION HISTORY:-
 *--------------------------------------------------------------------------------
 * VERSION	DATE		  BY			REASON
 *--------------------------------------------------------------------------------
 *  
 *
 *--------------------------------------------------------------------------------
 *
 *********************************************************************/

package com.mastek.eElixir.channelmanagement.csacpa.ejb.entitybean;

import java.sql.Connection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.sql.DataSource;

import com.mastek.eElixir.channelmanagement.csacpa.dax.CsaCpaDAX;
import com.mastek.eElixir.channelmanagement.csacpa.util.CsaCpaResult;

import com.mastek.eElixir.channelmanagement.util.CHMDAXFactory;
import com.mastek.eElixir.channelmanagement.util.DataConstants;
import com.mastek.eElixir.common.exception.EElixirException;
import com.mastek.eElixir.common.util.Constants;
import com.mastek.eElixir.common.util.DBConnection;
import com.mastek.eElixir.common.util.Logger;



/**
 * <p>Title: eElixir</p>
 * <p>Description: This CsaCpaCriteria Entity bean retrive data from the database according to seach condition</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: Mastek Ltd</p>
 * @author Amid P Sahu
 * @version 1.0
 */

public class CsaCpaCriteriaEJB implements EntityBean
{
	/**
	   * Attributes declaration
	   */
	  private EntityContext _oContext;
	  private Connection _oConnection = null;
	  private DataSource _oDatasource = null;
	  private CsaCpaDAX  _oCsaCpaDAX;
	  private CsaCpaResult _oCsaCpaCriteriaResult;
	  private Logger log = Logger.getInstance(Constants.CHM_MODULE_ID);


	 /**
	  * Constructor for CsaCpaCriteriaEJB class
	  */
	  public CsaCpaCriteriaEJB()
	  {

	  }
	  
	  /**
	   * Matching method of the create() method of the bean's home interface. The container
	   * invokes an ejbCreate method to create an entity object. It executes in the transaction
	   * context determined by the transactionattribute of the matching create() method.
	   * @return CsaCpaMasterPK
	   * @throws CreateException
	   * @throws EElixirException
	   */
	  public CsaCpaCriteriaPK ejbCreate() throws CreateException, EElixirException
	  {
		  CsaCpaCriteriaPK spk = new CsaCpaCriteriaPK();

	    return spk;

	  }
	  /**
	   * Matching method of ejbCreate. The container invokes the matching ejbPostCreate method
	   * on an instance after it invokes the ejbCreate method with the same arguments. It
	   * executes in the same transaction context as that of the matching ejbCreate method.
	   * @throws javax.ejb.CreateException
	   * @throws EElixirException
	   */
	  public void ejbPostCreate() throws CreateException, EElixirException
	  {

	  }
	  /**
	   * A container invokes this method when the instance is taken out of the pool of available
	   * instances to become associated with a specific EJB object. This method transitions
	   * the instance to the ready state. This method executes in an unspecified transaction
	   * context.
	   */
	  public void ejbActivate    ()
	  {

	  }

	  /**
	   * A container invokes this method on an instance before the instance becomes disassociated
	   * with a specific EJB object. After this method completes, the container will place
	   * the instance into the pool of available instances. This method executes in an unspecified
	   * transaction context.
	   */
	  public void ejbPassivate    ()
	  {

	  }
	  /**
	   * Set the associated entity context. The container invokes this method on an instance
	   * after the instance has been created. This method is called in an unspecified transaction
	   * context.
	   * @param sc
	   */
	  public void setEntityContext    (EntityContext ctx)
	  {
	    _oContext = ctx;
	  }

	  /**
	   * Unset the associated entity context. The container calls this method before removing
	   * the instance. This is the last method that the container invokes on the instance.
	   * The Java garbage collector will  invoke the finalize() method on the instance. It
	   * is called in an unspecified transaction context.
	   */
	  public void unsetEntityContext    ()
	  {
	    _oContext = null;
	  }
	  
	  /**
	   * Invoked by the container on the instance when the container selects the instance to
	   * execute a matching client-invoked find() method. It executes in the transaction
	   * context determined by the transaction attribute of the matching find() method.
	   * @return ChannelPK
	   * @param a_ChannelPK ChannelPK
	   * @throws javax.ejb.FinderException
	   * @throws EElixirException
	   */
	  public CsaCpaCriteriaPK ejbFindByPrimaryKey(CsaCpaCriteriaPK a_CsaCpaCriteriaPK) throws FinderException,EElixirException
	  {
	    try{
	       _oCsaCpaDAX = getDAX();
	      boolean bFlag = _oCsaCpaDAX.findCsaCpaBySeqNo(a_CsaCpaCriteriaPK.getCsaCpaSeqNbr().longValue());
	      if(bFlag){
	         return a_CsaCpaCriteriaPK;
	      }
	      else
	        throw new EElixirException("P7123"); 
	    }
	    catch(EElixirException eex)
	    {
	      throw new EJBException(eex);
	    }
	    finally{
	      try{
	        if(_oConnection != null)
	          DBConnection.closeConnection(_oConnection);
	      }
	      catch(EElixirException eElex){
	        throw new EElixirException(eElex,"P1005");
	      }
	    }
	  }
	  /**
	   * A container invokes this method to instruct the instance to synchronize its state
	   * by loading it from the underlying database. This method always executes in the transaction
	   * context determined by the value of the transaction attribute in the deployment descriptor.
	   */
	  public void ejbLoad    ()
	  {
	  
	  }

	  /**
	   * A container invokes this method to instruct the instance to synchronize its state
	   * by storing it to the underlying database. This method always executes in the transaction
	   * context determined by the value of the transaction attribute in the deployment descriptor.
	   */
	  public void ejbStore    ()
	  {
	    log.debug("CsaCpaEJB--ejbStore() fired");
	    
		try {
		     if(this._oCsaCpaCriteriaResult != null && this._oCsaCpaCriteriaResult.getIsDirty().equals(DataConstants.UPDATE_MODE))
			{ 
			    _oCsaCpaDAX = (CsaCpaDAX)getDAX();
			    
			    _oCsaCpaDAX.updateCsaCpaCriteria(_oCsaCpaCriteriaResult);
		        
			   }
			  
		  }
		catch(EElixirException ex)   {
		    log.debug("CsaCpaCriteriaEJB--ejbStore exception" + ex);
			throw new EJBException(ex);
	   }
	  finally   {
	        try
	        {
	          if(_oConnection != null)
	            DBConnection.closeConnection(_oConnection);
	        }
	        catch(EElixirException eex)
	        {
	          throw new EJBException(eex);
	        }
	      }
	    log.debug("CsaCpaCriteriaEJB--ejbStore done");
	  }
	  
	  public void ejbRemove    ()
	  {
	  
	  }
	  
	  public CsaCpaResult getCsaCpaCriteriaResult() throws  EElixirException
	  {
	    return _oCsaCpaCriteriaResult;
	  }

	  public void setCsaCpaCriteriaResult(CsaCpaResult a_oCsaCpaCriteriaResult) throws  EElixirException
	  {
	    this._oCsaCpaCriteriaResult = a_oCsaCpaCriteriaResult;
	  }
	  
	  /**
	   * Gets the Dax object and sets the connection on it.
	   * @return CsaCpaDAX
	   * @throws EElixirException
	   */
	    private CsaCpaDAX getDAX() throws EElixirException
	    {
	      _oConnection = DBConnection.getConnection();
	      CHMDAXFactory theDAXFactory = (CHMDAXFactory) CHMDAXFactory.getDAXFactory();
	      CsaCpaDAX _oCsaCpaDAX = (CsaCpaDAX)theDAXFactory.createDAX(theDAXFactory.CSACPADAX);
	      _oCsaCpaDAX.setConnection(_oConnection);

	      return _oCsaCpaDAX;
	    }


	  
}
