/**
 * Polquotenquiry_OUTPUT_ERROR_REASON.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package BeanService;

public class Polquotenquiry_OUTPUT_ERROR_REASON  implements java.io.Serializable {
    private java.lang.String ERRORDESC;

    private java.lang.String ERROREROR;

    private BeanService.Polquotenquiry_OUTPUT_ERROR_REASON_FIELD[] FIELD;

    public Polquotenquiry_OUTPUT_ERROR_REASON() {
    }

    public Polquotenquiry_OUTPUT_ERROR_REASON(
           java.lang.String ERRORDESC,
           java.lang.String ERROREROR,
           BeanService.Polquotenquiry_OUTPUT_ERROR_REASON_FIELD[] FIELD) {
           this.ERRORDESC = ERRORDESC;
           this.ERROREROR = ERROREROR;
           this.FIELD = FIELD;
    }


    /**
     * Gets the ERRORDESC value for this Polquotenquiry_OUTPUT_ERROR_REASON.
     * 
     * @return ERRORDESC
     */
    public java.lang.String getERRORDESC() {
        return ERRORDESC;
    }


    /**
     * Sets the ERRORDESC value for this Polquotenquiry_OUTPUT_ERROR_REASON.
     * 
     * @param ERRORDESC
     */
    public void setERRORDESC(java.lang.String ERRORDESC) {
        this.ERRORDESC = ERRORDESC;
    }


    /**
     * Gets the ERROREROR value for this Polquotenquiry_OUTPUT_ERROR_REASON.
     * 
     * @return ERROREROR
     */
    public java.lang.String getERROREROR() {
        return ERROREROR;
    }


    /**
     * Sets the ERROREROR value for this Polquotenquiry_OUTPUT_ERROR_REASON.
     * 
     * @param ERROREROR
     */
    public void setERROREROR(java.lang.String ERROREROR) {
        this.ERROREROR = ERROREROR;
    }


    /**
     * Gets the FIELD value for this Polquotenquiry_OUTPUT_ERROR_REASON.
     * 
     * @return FIELD
     */
    public BeanService.Polquotenquiry_OUTPUT_ERROR_REASON_FIELD[] getFIELD() {
        return FIELD;
    }


    /**
     * Sets the FIELD value for this Polquotenquiry_OUTPUT_ERROR_REASON.
     * 
     * @param FIELD
     */
    public void setFIELD(BeanService.Polquotenquiry_OUTPUT_ERROR_REASON_FIELD[] FIELD) {
        this.FIELD = FIELD;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Polquotenquiry_OUTPUT_ERROR_REASON)) return false;
        Polquotenquiry_OUTPUT_ERROR_REASON other = (Polquotenquiry_OUTPUT_ERROR_REASON) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ERRORDESC==null && other.getERRORDESC()==null) || 
             (this.ERRORDESC!=null &&
              this.ERRORDESC.equals(other.getERRORDESC()))) &&
            ((this.ERROREROR==null && other.getERROREROR()==null) || 
             (this.ERROREROR!=null &&
              this.ERROREROR.equals(other.getERROREROR()))) &&
            ((this.FIELD==null && other.getFIELD()==null) || 
             (this.FIELD!=null &&
              java.util.Arrays.equals(this.FIELD, other.getFIELD())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getERRORDESC() != null) {
            _hashCode += getERRORDESC().hashCode();
        }
        if (getERROREROR() != null) {
            _hashCode += getERROREROR().hashCode();
        }
        if (getFIELD() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getFIELD());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getFIELD(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Polquotenquiry_OUTPUT_ERROR_REASON.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ERROR_REASON"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ERRORDESC");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ERRORDESC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ERROREROR");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ERROREROR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FIELD");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "FIELD"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ERROR_REASON_FIELD"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://localhost:8080/axis/services/polquotenquiryservice", "item"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
