/**
 * Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package BeanService;

public class Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE  implements java.io.Serializable {
    private java.lang.String CCYY;

    private java.lang.String DD;

    private java.lang.String MM;

    public Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE() {
    }

    public Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE(
           java.lang.String CCYY,
           java.lang.String DD,
           java.lang.String MM) {
           this.CCYY = CCYY;
           this.DD = DD;
           this.MM = MM;
    }


    /**
     * Gets the CCYY value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE.
     * 
     * @return CCYY
     */
    public java.lang.String getCCYY() {
        return CCYY;
    }


    /**
     * Sets the CCYY value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE.
     * 
     * @param CCYY
     */
    public void setCCYY(java.lang.String CCYY) {
        this.CCYY = CCYY;
    }


    /**
     * Gets the DD value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE.
     * 
     * @return DD
     */
    public java.lang.String getDD() {
        return DD;
    }


    /**
     * Sets the DD value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE.
     * 
     * @param DD
     */
    public void setDD(java.lang.String DD) {
        this.DD = DD;
    }


    /**
     * Gets the MM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE.
     * 
     * @return MM
     */
    public java.lang.String getMM() {
        return MM;
    }


    /**
     * Sets the MM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE.
     * 
     * @param MM
     */
    public void setMM(java.lang.String MM) {
        this.MM = MM;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE)) return false;
        Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE other = (Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CCYY==null && other.getCCYY()==null) || 
             (this.CCYY!=null &&
              this.CCYY.equals(other.getCCYY()))) &&
            ((this.DD==null && other.getDD()==null) || 
             (this.DD!=null &&
              this.DD.equals(other.getDD()))) &&
            ((this.MM==null && other.getMM()==null) || 
             (this.MM!=null &&
              this.MM.equals(other.getMM())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCCYY() != null) {
            _hashCode += getCCYY().hashCode();
        }
        if (getDD() != null) {
            _hashCode += getDD().hashCode();
        }
        if (getMM() != null) {
            _hashCode += getMM().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCYY");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "CCYY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DD");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "DD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "MM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
