/**
 * Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package BeanService;

public class Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS  implements java.io.Serializable {
    private java.lang.String AGENTNAME;

    private java.lang.String AGNTNUM;

    private java.lang.String BILLFREQ;

    private java.lang.String BPREM;

    private BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE[] CCDATE;

    private java.lang.String CHDRNUM;

    private java.lang.String CLTPCODE;

    private java.lang.String COWNNUM;

    private java.lang.String DESPNAME;

    private java.lang.String GIVNAME;

    private java.lang.String GRPGST;

    private java.lang.String LOCCDE;

    private java.lang.String MOP;

    private BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_OCCDATE[] OCCDATE;

    private java.lang.String QUOTENO;

    private java.lang.String QUOTESTS;

    private java.lang.String RTAXIDNUM;

    private java.lang.String STATCODE;

    private java.lang.String SURNAME;

    private java.lang.String ZCONTACT;

    private java.lang.String ZPRODNM;

    private java.lang.String ZSTATENM;

    private java.lang.String ZTOWN;

    public Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS() {
    }

    public Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS(
           java.lang.String AGENTNAME,
           java.lang.String AGNTNUM,
           java.lang.String BILLFREQ,
           java.lang.String BPREM,
           BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE[] CCDATE,
           java.lang.String CHDRNUM,
           java.lang.String CLTPCODE,
           java.lang.String COWNNUM,
           java.lang.String DESPNAME,
           java.lang.String GIVNAME,
           java.lang.String GRPGST,
           java.lang.String LOCCDE,
           java.lang.String MOP,
           BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_OCCDATE[] OCCDATE,
           java.lang.String QUOTENO,
           java.lang.String QUOTESTS,
           java.lang.String RTAXIDNUM,
           java.lang.String STATCODE,
           java.lang.String SURNAME,
           java.lang.String ZCONTACT,
           java.lang.String ZPRODNM,
           java.lang.String ZSTATENM,
           java.lang.String ZTOWN) {
           this.AGENTNAME = AGENTNAME;
           this.AGNTNUM = AGNTNUM;
           this.BILLFREQ = BILLFREQ;
           this.BPREM = BPREM;
           this.CCDATE = CCDATE;
           this.CHDRNUM = CHDRNUM;
           this.CLTPCODE = CLTPCODE;
           this.COWNNUM = COWNNUM;
           this.DESPNAME = DESPNAME;
           this.GIVNAME = GIVNAME;
           this.GRPGST = GRPGST;
           this.LOCCDE = LOCCDE;
           this.MOP = MOP;
           this.OCCDATE = OCCDATE;
           this.QUOTENO = QUOTENO;
           this.QUOTESTS = QUOTESTS;
           this.RTAXIDNUM = RTAXIDNUM;
           this.STATCODE = STATCODE;
           this.SURNAME = SURNAME;
           this.ZCONTACT = ZCONTACT;
           this.ZPRODNM = ZPRODNM;
           this.ZSTATENM = ZSTATENM;
           this.ZTOWN = ZTOWN;
    }


    /**
     * Gets the AGENTNAME value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return AGENTNAME
     */
    public java.lang.String getAGENTNAME() {
        return AGENTNAME;
    }


    /**
     * Sets the AGENTNAME value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param AGENTNAME
     */
    public void setAGENTNAME(java.lang.String AGENTNAME) {
        this.AGENTNAME = AGENTNAME;
    }


    /**
     * Gets the AGNTNUM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return AGNTNUM
     */
    public java.lang.String getAGNTNUM() {
        return AGNTNUM;
    }


    /**
     * Sets the AGNTNUM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param AGNTNUM
     */
    public void setAGNTNUM(java.lang.String AGNTNUM) {
        this.AGNTNUM = AGNTNUM;
    }


    /**
     * Gets the BILLFREQ value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return BILLFREQ
     */
    public java.lang.String getBILLFREQ() {
        return BILLFREQ;
    }


    /**
     * Sets the BILLFREQ value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param BILLFREQ
     */
    public void setBILLFREQ(java.lang.String BILLFREQ) {
        this.BILLFREQ = BILLFREQ;
    }


    /**
     * Gets the BPREM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return BPREM
     */
    public java.lang.String getBPREM() {
        return BPREM;
    }


    /**
     * Sets the BPREM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param BPREM
     */
    public void setBPREM(java.lang.String BPREM) {
        this.BPREM = BPREM;
    }


    /**
     * Gets the CCDATE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return CCDATE
     */
    public BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE[] getCCDATE() {
        return CCDATE;
    }


    /**
     * Sets the CCDATE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param CCDATE
     */
    public void setCCDATE(BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE[] CCDATE) {
        this.CCDATE = CCDATE;
    }


    /**
     * Gets the CHDRNUM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return CHDRNUM
     */
    public java.lang.String getCHDRNUM() {
        return CHDRNUM;
    }


    /**
     * Sets the CHDRNUM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param CHDRNUM
     */
    public void setCHDRNUM(java.lang.String CHDRNUM) {
        this.CHDRNUM = CHDRNUM;
    }


    /**
     * Gets the CLTPCODE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return CLTPCODE
     */
    public java.lang.String getCLTPCODE() {
        return CLTPCODE;
    }


    /**
     * Sets the CLTPCODE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param CLTPCODE
     */
    public void setCLTPCODE(java.lang.String CLTPCODE) {
        this.CLTPCODE = CLTPCODE;
    }


    /**
     * Gets the COWNNUM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return COWNNUM
     */
    public java.lang.String getCOWNNUM() {
        return COWNNUM;
    }


    /**
     * Sets the COWNNUM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param COWNNUM
     */
    public void setCOWNNUM(java.lang.String COWNNUM) {
        this.COWNNUM = COWNNUM;
    }


    /**
     * Gets the DESPNAME value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return DESPNAME
     */
    public java.lang.String getDESPNAME() {
        return DESPNAME;
    }


    /**
     * Sets the DESPNAME value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param DESPNAME
     */
    public void setDESPNAME(java.lang.String DESPNAME) {
        this.DESPNAME = DESPNAME;
    }


    /**
     * Gets the GIVNAME value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return GIVNAME
     */
    public java.lang.String getGIVNAME() {
        return GIVNAME;
    }


    /**
     * Sets the GIVNAME value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param GIVNAME
     */
    public void setGIVNAME(java.lang.String GIVNAME) {
        this.GIVNAME = GIVNAME;
    }


    /**
     * Gets the GRPGST value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return GRPGST
     */
    public java.lang.String getGRPGST() {
        return GRPGST;
    }


    /**
     * Sets the GRPGST value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param GRPGST
     */
    public void setGRPGST(java.lang.String GRPGST) {
        this.GRPGST = GRPGST;
    }


    /**
     * Gets the LOCCDE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return LOCCDE
     */
    public java.lang.String getLOCCDE() {
        return LOCCDE;
    }


    /**
     * Sets the LOCCDE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param LOCCDE
     */
    public void setLOCCDE(java.lang.String LOCCDE) {
        this.LOCCDE = LOCCDE;
    }


    /**
     * Gets the MOP value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return MOP
     */
    public java.lang.String getMOP() {
        return MOP;
    }


    /**
     * Sets the MOP value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param MOP
     */
    public void setMOP(java.lang.String MOP) {
        this.MOP = MOP;
    }


    /**
     * Gets the OCCDATE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return OCCDATE
     */
    public BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_OCCDATE[] getOCCDATE() {
        return OCCDATE;
    }


    /**
     * Sets the OCCDATE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param OCCDATE
     */
    public void setOCCDATE(BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_OCCDATE[] OCCDATE) {
        this.OCCDATE = OCCDATE;
    }


    /**
     * Gets the QUOTENO value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return QUOTENO
     */
    public java.lang.String getQUOTENO() {
        return QUOTENO;
    }


    /**
     * Sets the QUOTENO value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param QUOTENO
     */
    public void setQUOTENO(java.lang.String QUOTENO) {
        this.QUOTENO = QUOTENO;
    }


    /**
     * Gets the QUOTESTS value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return QUOTESTS
     */
    public java.lang.String getQUOTESTS() {
        return QUOTESTS;
    }


    /**
     * Sets the QUOTESTS value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param QUOTESTS
     */
    public void setQUOTESTS(java.lang.String QUOTESTS) {
        this.QUOTESTS = QUOTESTS;
    }


    /**
     * Gets the RTAXIDNUM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return RTAXIDNUM
     */
    public java.lang.String getRTAXIDNUM() {
        return RTAXIDNUM;
    }


    /**
     * Sets the RTAXIDNUM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param RTAXIDNUM
     */
    public void setRTAXIDNUM(java.lang.String RTAXIDNUM) {
        this.RTAXIDNUM = RTAXIDNUM;
    }


    /**
     * Gets the STATCODE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return STATCODE
     */
    public java.lang.String getSTATCODE() {
        return STATCODE;
    }


    /**
     * Sets the STATCODE value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param STATCODE
     */
    public void setSTATCODE(java.lang.String STATCODE) {
        this.STATCODE = STATCODE;
    }


    /**
     * Gets the SURNAME value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return SURNAME
     */
    public java.lang.String getSURNAME() {
        return SURNAME;
    }


    /**
     * Sets the SURNAME value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param SURNAME
     */
    public void setSURNAME(java.lang.String SURNAME) {
        this.SURNAME = SURNAME;
    }


    /**
     * Gets the ZCONTACT value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return ZCONTACT
     */
    public java.lang.String getZCONTACT() {
        return ZCONTACT;
    }


    /**
     * Sets the ZCONTACT value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param ZCONTACT
     */
    public void setZCONTACT(java.lang.String ZCONTACT) {
        this.ZCONTACT = ZCONTACT;
    }


    /**
     * Gets the ZPRODNM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return ZPRODNM
     */
    public java.lang.String getZPRODNM() {
        return ZPRODNM;
    }


    /**
     * Sets the ZPRODNM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param ZPRODNM
     */
    public void setZPRODNM(java.lang.String ZPRODNM) {
        this.ZPRODNM = ZPRODNM;
    }


    /**
     * Gets the ZSTATENM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return ZSTATENM
     */
    public java.lang.String getZSTATENM() {
        return ZSTATENM;
    }


    /**
     * Sets the ZSTATENM value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param ZSTATENM
     */
    public void setZSTATENM(java.lang.String ZSTATENM) {
        this.ZSTATENM = ZSTATENM;
    }


    /**
     * Gets the ZTOWN value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @return ZTOWN
     */
    public java.lang.String getZTOWN() {
        return ZTOWN;
    }


    /**
     * Sets the ZTOWN value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.
     * 
     * @param ZTOWN
     */
    public void setZTOWN(java.lang.String ZTOWN) {
        this.ZTOWN = ZTOWN;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS)) return false;
        Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS other = (Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.AGENTNAME==null && other.getAGENTNAME()==null) || 
             (this.AGENTNAME!=null &&
              this.AGENTNAME.equals(other.getAGENTNAME()))) &&
            ((this.AGNTNUM==null && other.getAGNTNUM()==null) || 
             (this.AGNTNUM!=null &&
              this.AGNTNUM.equals(other.getAGNTNUM()))) &&
            ((this.BILLFREQ==null && other.getBILLFREQ()==null) || 
             (this.BILLFREQ!=null &&
              this.BILLFREQ.equals(other.getBILLFREQ()))) &&
            ((this.BPREM==null && other.getBPREM()==null) || 
             (this.BPREM!=null &&
              this.BPREM.equals(other.getBPREM()))) &&
            ((this.CCDATE==null && other.getCCDATE()==null) || 
             (this.CCDATE!=null &&
              java.util.Arrays.equals(this.CCDATE, other.getCCDATE()))) &&
            ((this.CHDRNUM==null && other.getCHDRNUM()==null) || 
             (this.CHDRNUM!=null &&
              this.CHDRNUM.equals(other.getCHDRNUM()))) &&
            ((this.CLTPCODE==null && other.getCLTPCODE()==null) || 
             (this.CLTPCODE!=null &&
              this.CLTPCODE.equals(other.getCLTPCODE()))) &&
            ((this.COWNNUM==null && other.getCOWNNUM()==null) || 
             (this.COWNNUM!=null &&
              this.COWNNUM.equals(other.getCOWNNUM()))) &&
            ((this.DESPNAME==null && other.getDESPNAME()==null) || 
             (this.DESPNAME!=null &&
              this.DESPNAME.equals(other.getDESPNAME()))) &&
            ((this.GIVNAME==null && other.getGIVNAME()==null) || 
             (this.GIVNAME!=null &&
              this.GIVNAME.equals(other.getGIVNAME()))) &&
            ((this.GRPGST==null && other.getGRPGST()==null) || 
             (this.GRPGST!=null &&
              this.GRPGST.equals(other.getGRPGST()))) &&
            ((this.LOCCDE==null && other.getLOCCDE()==null) || 
             (this.LOCCDE!=null &&
              this.LOCCDE.equals(other.getLOCCDE()))) &&
            ((this.MOP==null && other.getMOP()==null) || 
             (this.MOP!=null &&
              this.MOP.equals(other.getMOP()))) &&
            ((this.OCCDATE==null && other.getOCCDATE()==null) || 
             (this.OCCDATE!=null &&
              java.util.Arrays.equals(this.OCCDATE, other.getOCCDATE()))) &&
            ((this.QUOTENO==null && other.getQUOTENO()==null) || 
             (this.QUOTENO!=null &&
              this.QUOTENO.equals(other.getQUOTENO()))) &&
            ((this.QUOTESTS==null && other.getQUOTESTS()==null) || 
             (this.QUOTESTS!=null &&
              this.QUOTESTS.equals(other.getQUOTESTS()))) &&
            ((this.RTAXIDNUM==null && other.getRTAXIDNUM()==null) || 
             (this.RTAXIDNUM!=null &&
              this.RTAXIDNUM.equals(other.getRTAXIDNUM()))) &&
            ((this.STATCODE==null && other.getSTATCODE()==null) || 
             (this.STATCODE!=null &&
              this.STATCODE.equals(other.getSTATCODE()))) &&
            ((this.SURNAME==null && other.getSURNAME()==null) || 
             (this.SURNAME!=null &&
              this.SURNAME.equals(other.getSURNAME()))) &&
            ((this.ZCONTACT==null && other.getZCONTACT()==null) || 
             (this.ZCONTACT!=null &&
              this.ZCONTACT.equals(other.getZCONTACT()))) &&
            ((this.ZPRODNM==null && other.getZPRODNM()==null) || 
             (this.ZPRODNM!=null &&
              this.ZPRODNM.equals(other.getZPRODNM()))) &&
            ((this.ZSTATENM==null && other.getZSTATENM()==null) || 
             (this.ZSTATENM!=null &&
              this.ZSTATENM.equals(other.getZSTATENM()))) &&
            ((this.ZTOWN==null && other.getZTOWN()==null) || 
             (this.ZTOWN!=null &&
              this.ZTOWN.equals(other.getZTOWN())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAGENTNAME() != null) {
            _hashCode += getAGENTNAME().hashCode();
        }
        if (getAGNTNUM() != null) {
            _hashCode += getAGNTNUM().hashCode();
        }
        if (getBILLFREQ() != null) {
            _hashCode += getBILLFREQ().hashCode();
        }
        if (getBPREM() != null) {
            _hashCode += getBPREM().hashCode();
        }
        if (getCCDATE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCCDATE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCCDATE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCHDRNUM() != null) {
            _hashCode += getCHDRNUM().hashCode();
        }
        if (getCLTPCODE() != null) {
            _hashCode += getCLTPCODE().hashCode();
        }
        if (getCOWNNUM() != null) {
            _hashCode += getCOWNNUM().hashCode();
        }
        if (getDESPNAME() != null) {
            _hashCode += getDESPNAME().hashCode();
        }
        if (getGIVNAME() != null) {
            _hashCode += getGIVNAME().hashCode();
        }
        if (getGRPGST() != null) {
            _hashCode += getGRPGST().hashCode();
        }
        if (getLOCCDE() != null) {
            _hashCode += getLOCCDE().hashCode();
        }
        if (getMOP() != null) {
            _hashCode += getMOP().hashCode();
        }
        if (getOCCDATE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOCCDATE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOCCDATE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getQUOTENO() != null) {
            _hashCode += getQUOTENO().hashCode();
        }
        if (getQUOTESTS() != null) {
            _hashCode += getQUOTESTS().hashCode();
        }
        if (getRTAXIDNUM() != null) {
            _hashCode += getRTAXIDNUM().hashCode();
        }
        if (getSTATCODE() != null) {
            _hashCode += getSTATCODE().hashCode();
        }
        if (getSURNAME() != null) {
            _hashCode += getSURNAME().hashCode();
        }
        if (getZCONTACT() != null) {
            _hashCode += getZCONTACT().hashCode();
        }
        if (getZPRODNM() != null) {
            _hashCode += getZPRODNM().hashCode();
        }
        if (getZSTATENM() != null) {
            _hashCode += getZSTATENM().hashCode();
        }
        if (getZTOWN() != null) {
            _hashCode += getZTOWN().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AGENTNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "AGENTNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AGNTNUM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "AGNTNUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BILLFREQ");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "BILLFREQ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BPREM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "BPREM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "CCDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_CCDATE"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://localhost:8080/axis/services/polquotenquiryservice", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHDRNUM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "CHDRNUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLTPCODE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "CLTPCODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COWNNUM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "COWNNUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESPNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "DESPNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GIVNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "GIVNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GRPGST");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "GRPGST"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LOCCDE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "LOCCDE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MOP");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "MOP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OCCDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "OCCDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS_OCCDATE"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://localhost:8080/axis/services/polquotenquiryservice", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUOTENO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "QUOTENO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUOTESTS");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "QUOTESTS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RTAXIDNUM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "RTAXIDNUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATCODE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "STATCODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SURNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "SURNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZCONTACT");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ZCONTACT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZPRODNM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ZPRODNM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZSTATENM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ZSTATENM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZTOWN");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ZTOWN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
