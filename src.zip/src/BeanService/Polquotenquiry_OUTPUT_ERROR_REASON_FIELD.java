/**
 * Polquotenquiry_OUTPUT_ERROR_REASON_FIELD.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package BeanService;

public class Polquotenquiry_OUTPUT_ERROR_REASON_FIELD  implements java.io.Serializable {
    private java.lang.String ERRORFIELD;

    public Polquotenquiry_OUTPUT_ERROR_REASON_FIELD() {
    }

    public Polquotenquiry_OUTPUT_ERROR_REASON_FIELD(
           java.lang.String ERRORFIELD) {
           this.ERRORFIELD = ERRORFIELD;
    }


    /**
     * Gets the ERRORFIELD value for this Polquotenquiry_OUTPUT_ERROR_REASON_FIELD.
     * 
     * @return ERRORFIELD
     */
    public java.lang.String getERRORFIELD() {
        return ERRORFIELD;
    }


    /**
     * Sets the ERRORFIELD value for this Polquotenquiry_OUTPUT_ERROR_REASON_FIELD.
     * 
     * @param ERRORFIELD
     */
    public void setERRORFIELD(java.lang.String ERRORFIELD) {
        this.ERRORFIELD = ERRORFIELD;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Polquotenquiry_OUTPUT_ERROR_REASON_FIELD)) return false;
        Polquotenquiry_OUTPUT_ERROR_REASON_FIELD other = (Polquotenquiry_OUTPUT_ERROR_REASON_FIELD) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ERRORFIELD==null && other.getERRORFIELD()==null) || 
             (this.ERRORFIELD!=null &&
              this.ERRORFIELD.equals(other.getERRORFIELD())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getERRORFIELD() != null) {
            _hashCode += getERRORFIELD().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Polquotenquiry_OUTPUT_ERROR_REASON_FIELD.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ERROR_REASON_FIELD"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ERRORFIELD");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ERRORFIELD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
