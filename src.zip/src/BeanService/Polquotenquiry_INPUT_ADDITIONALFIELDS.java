/**
 * Polquotenquiry_INPUT_ADDITIONALFIELDS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package BeanService;

public class Polquotenquiry_INPUT_ADDITIONALFIELDS  implements java.io.Serializable {
    private java.lang.String CHDRNUM;

    private java.lang.String QUOTENO;

    public Polquotenquiry_INPUT_ADDITIONALFIELDS() {
    }

    public Polquotenquiry_INPUT_ADDITIONALFIELDS(
           java.lang.String CHDRNUM,
           java.lang.String QUOTENO) {
           this.CHDRNUM = CHDRNUM;
           this.QUOTENO = QUOTENO;
    }


    /**
     * Gets the CHDRNUM value for this Polquotenquiry_INPUT_ADDITIONALFIELDS.
     * 
     * @return CHDRNUM
     */
    public java.lang.String getCHDRNUM() {
        return CHDRNUM;
    }


    /**
     * Sets the CHDRNUM value for this Polquotenquiry_INPUT_ADDITIONALFIELDS.
     * 
     * @param CHDRNUM
     */
    public void setCHDRNUM(java.lang.String CHDRNUM) {
        this.CHDRNUM = CHDRNUM;
    }


    /**
     * Gets the QUOTENO value for this Polquotenquiry_INPUT_ADDITIONALFIELDS.
     * 
     * @return QUOTENO
     */
    public java.lang.String getQUOTENO() {
        return QUOTENO;
    }


    /**
     * Sets the QUOTENO value for this Polquotenquiry_INPUT_ADDITIONALFIELDS.
     * 
     * @param QUOTENO
     */
    public void setQUOTENO(java.lang.String QUOTENO) {
        this.QUOTENO = QUOTENO;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Polquotenquiry_INPUT_ADDITIONALFIELDS)) return false;
        Polquotenquiry_INPUT_ADDITIONALFIELDS other = (Polquotenquiry_INPUT_ADDITIONALFIELDS) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CHDRNUM==null && other.getCHDRNUM()==null) || 
             (this.CHDRNUM!=null &&
              this.CHDRNUM.equals(other.getCHDRNUM()))) &&
            ((this.QUOTENO==null && other.getQUOTENO()==null) || 
             (this.QUOTENO!=null &&
              this.QUOTENO.equals(other.getQUOTENO())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCHDRNUM() != null) {
            _hashCode += getCHDRNUM().hashCode();
        }
        if (getQUOTENO() != null) {
            _hashCode += getQUOTENO().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Polquotenquiry_INPUT_ADDITIONALFIELDS.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_INPUT_ADDITIONALFIELDS"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHDRNUM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "CHDRNUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUOTENO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "QUOTENO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
