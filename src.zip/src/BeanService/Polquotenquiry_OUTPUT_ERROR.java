/**
 * Polquotenquiry_OUTPUT_ERROR.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package BeanService;

public class Polquotenquiry_OUTPUT_ERROR  implements java.io.Serializable {
    private BeanService.Polquotenquiry_OUTPUT_ERROR_REASON[] REASON;

    private java.lang.String STATUS;

    public Polquotenquiry_OUTPUT_ERROR() {
    }

    public Polquotenquiry_OUTPUT_ERROR(
           BeanService.Polquotenquiry_OUTPUT_ERROR_REASON[] REASON,
           java.lang.String STATUS) {
           this.REASON = REASON;
           this.STATUS = STATUS;
    }


    /**
     * Gets the REASON value for this Polquotenquiry_OUTPUT_ERROR.
     * 
     * @return REASON
     */
    public BeanService.Polquotenquiry_OUTPUT_ERROR_REASON[] getREASON() {
        return REASON;
    }


    /**
     * Sets the REASON value for this Polquotenquiry_OUTPUT_ERROR.
     * 
     * @param REASON
     */
    public void setREASON(BeanService.Polquotenquiry_OUTPUT_ERROR_REASON[] REASON) {
        this.REASON = REASON;
    }


    /**
     * Gets the STATUS value for this Polquotenquiry_OUTPUT_ERROR.
     * 
     * @return STATUS
     */
    public java.lang.String getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this Polquotenquiry_OUTPUT_ERROR.
     * 
     * @param STATUS
     */
    public void setSTATUS(java.lang.String STATUS) {
        this.STATUS = STATUS;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Polquotenquiry_OUTPUT_ERROR)) return false;
        Polquotenquiry_OUTPUT_ERROR other = (Polquotenquiry_OUTPUT_ERROR) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.REASON==null && other.getREASON()==null) || 
             (this.REASON!=null &&
              java.util.Arrays.equals(this.REASON, other.getREASON()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              this.STATUS.equals(other.getSTATUS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getREASON() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREASON());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREASON(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSTATUS() != null) {
            _hashCode += getSTATUS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Polquotenquiry_OUTPUT_ERROR.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ERROR"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REASON");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "REASON"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ERROR_REASON"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://localhost:8080/axis/services/polquotenquiryservice", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
