/**
 * Polquotenquiry_INPUT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package BeanService;

public class Polquotenquiry_INPUT  implements java.io.Serializable {
    private BeanService.Polquotenquiry_INPUT_ADDITIONALFIELDS[] ADDITIONALFIELDS;

    private java.lang.String BRANCH;

    private java.lang.String COMMITFLAG;

    private java.lang.String COMPANY;

    private java.lang.String IGNOREDRIVERHELD;

    private java.lang.String LANGUAGE;

    private java.lang.String OBJECTID;

    private java.lang.String PASSWORD;

    private java.lang.String SUPPRESSRCLRSC;

    private java.lang.String USRPRF;

    private java.lang.String VERBID;

    public Polquotenquiry_INPUT() {
    }

    public Polquotenquiry_INPUT(
           BeanService.Polquotenquiry_INPUT_ADDITIONALFIELDS[] ADDITIONALFIELDS,
           java.lang.String BRANCH,
           java.lang.String COMMITFLAG,
           java.lang.String COMPANY,
           java.lang.String IGNOREDRIVERHELD,
           java.lang.String LANGUAGE,
           java.lang.String OBJECTID,
           java.lang.String PASSWORD,
           java.lang.String SUPPRESSRCLRSC,
           java.lang.String USRPRF,
           java.lang.String VERBID) {
           this.ADDITIONALFIELDS = ADDITIONALFIELDS;
           this.BRANCH = BRANCH;
           this.COMMITFLAG = COMMITFLAG;
           this.COMPANY = COMPANY;
           this.IGNOREDRIVERHELD = IGNOREDRIVERHELD;
           this.LANGUAGE = LANGUAGE;
           this.OBJECTID = OBJECTID;
           this.PASSWORD = PASSWORD;
           this.SUPPRESSRCLRSC = SUPPRESSRCLRSC;
           this.USRPRF = USRPRF;
           this.VERBID = VERBID;
    }


    /**
     * Gets the ADDITIONALFIELDS value for this Polquotenquiry_INPUT.
     * 
     * @return ADDITIONALFIELDS
     */
    public BeanService.Polquotenquiry_INPUT_ADDITIONALFIELDS[] getADDITIONALFIELDS() {
        return ADDITIONALFIELDS;
    }


    /**
     * Sets the ADDITIONALFIELDS value for this Polquotenquiry_INPUT.
     * 
     * @param ADDITIONALFIELDS
     */
    public void setADDITIONALFIELDS(BeanService.Polquotenquiry_INPUT_ADDITIONALFIELDS[] ADDITIONALFIELDS) {
        this.ADDITIONALFIELDS = ADDITIONALFIELDS;
    }


    /**
     * Gets the BRANCH value for this Polquotenquiry_INPUT.
     * 
     * @return BRANCH
     */
    public java.lang.String getBRANCH() {
        return BRANCH;
    }


    /**
     * Sets the BRANCH value for this Polquotenquiry_INPUT.
     * 
     * @param BRANCH
     */
    public void setBRANCH(java.lang.String BRANCH) {
        this.BRANCH = BRANCH;
    }


    /**
     * Gets the COMMITFLAG value for this Polquotenquiry_INPUT.
     * 
     * @return COMMITFLAG
     */
    public java.lang.String getCOMMITFLAG() {
        return COMMITFLAG;
    }


    /**
     * Sets the COMMITFLAG value for this Polquotenquiry_INPUT.
     * 
     * @param COMMITFLAG
     */
    public void setCOMMITFLAG(java.lang.String COMMITFLAG) {
        this.COMMITFLAG = COMMITFLAG;
    }


    /**
     * Gets the COMPANY value for this Polquotenquiry_INPUT.
     * 
     * @return COMPANY
     */
    public java.lang.String getCOMPANY() {
        return COMPANY;
    }


    /**
     * Sets the COMPANY value for this Polquotenquiry_INPUT.
     * 
     * @param COMPANY
     */
    public void setCOMPANY(java.lang.String COMPANY) {
        this.COMPANY = COMPANY;
    }


    /**
     * Gets the IGNOREDRIVERHELD value for this Polquotenquiry_INPUT.
     * 
     * @return IGNOREDRIVERHELD
     */
    public java.lang.String getIGNOREDRIVERHELD() {
        return IGNOREDRIVERHELD;
    }


    /**
     * Sets the IGNOREDRIVERHELD value for this Polquotenquiry_INPUT.
     * 
     * @param IGNOREDRIVERHELD
     */
    public void setIGNOREDRIVERHELD(java.lang.String IGNOREDRIVERHELD) {
        this.IGNOREDRIVERHELD = IGNOREDRIVERHELD;
    }


    /**
     * Gets the LANGUAGE value for this Polquotenquiry_INPUT.
     * 
     * @return LANGUAGE
     */
    public java.lang.String getLANGUAGE() {
        return LANGUAGE;
    }


    /**
     * Sets the LANGUAGE value for this Polquotenquiry_INPUT.
     * 
     * @param LANGUAGE
     */
    public void setLANGUAGE(java.lang.String LANGUAGE) {
        this.LANGUAGE = LANGUAGE;
    }


    /**
     * Gets the OBJECTID value for this Polquotenquiry_INPUT.
     * 
     * @return OBJECTID
     */
    public java.lang.String getOBJECTID() {
        return OBJECTID;
    }


    /**
     * Sets the OBJECTID value for this Polquotenquiry_INPUT.
     * 
     * @param OBJECTID
     */
    public void setOBJECTID(java.lang.String OBJECTID) {
        this.OBJECTID = OBJECTID;
    }


    /**
     * Gets the PASSWORD value for this Polquotenquiry_INPUT.
     * 
     * @return PASSWORD
     */
    public java.lang.String getPASSWORD() {
        return PASSWORD;
    }


    /**
     * Sets the PASSWORD value for this Polquotenquiry_INPUT.
     * 
     * @param PASSWORD
     */
    public void setPASSWORD(java.lang.String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }


    /**
     * Gets the SUPPRESSRCLRSC value for this Polquotenquiry_INPUT.
     * 
     * @return SUPPRESSRCLRSC
     */
    public java.lang.String getSUPPRESSRCLRSC() {
        return SUPPRESSRCLRSC;
    }


    /**
     * Sets the SUPPRESSRCLRSC value for this Polquotenquiry_INPUT.
     * 
     * @param SUPPRESSRCLRSC
     */
    public void setSUPPRESSRCLRSC(java.lang.String SUPPRESSRCLRSC) {
        this.SUPPRESSRCLRSC = SUPPRESSRCLRSC;
    }


    /**
     * Gets the USRPRF value for this Polquotenquiry_INPUT.
     * 
     * @return USRPRF
     */
    public java.lang.String getUSRPRF() {
        return USRPRF;
    }


    /**
     * Sets the USRPRF value for this Polquotenquiry_INPUT.
     * 
     * @param USRPRF
     */
    public void setUSRPRF(java.lang.String USRPRF) {
        this.USRPRF = USRPRF;
    }


    /**
     * Gets the VERBID value for this Polquotenquiry_INPUT.
     * 
     * @return VERBID
     */
    public java.lang.String getVERBID() {
        return VERBID;
    }


    /**
     * Sets the VERBID value for this Polquotenquiry_INPUT.
     * 
     * @param VERBID
     */
    public void setVERBID(java.lang.String VERBID) {
        this.VERBID = VERBID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Polquotenquiry_INPUT)) return false;
        Polquotenquiry_INPUT other = (Polquotenquiry_INPUT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ADDITIONALFIELDS==null && other.getADDITIONALFIELDS()==null) || 
             (this.ADDITIONALFIELDS!=null &&
              java.util.Arrays.equals(this.ADDITIONALFIELDS, other.getADDITIONALFIELDS()))) &&
            ((this.BRANCH==null && other.getBRANCH()==null) || 
             (this.BRANCH!=null &&
              this.BRANCH.equals(other.getBRANCH()))) &&
            ((this.COMMITFLAG==null && other.getCOMMITFLAG()==null) || 
             (this.COMMITFLAG!=null &&
              this.COMMITFLAG.equals(other.getCOMMITFLAG()))) &&
            ((this.COMPANY==null && other.getCOMPANY()==null) || 
             (this.COMPANY!=null &&
              this.COMPANY.equals(other.getCOMPANY()))) &&
            ((this.IGNOREDRIVERHELD==null && other.getIGNOREDRIVERHELD()==null) || 
             (this.IGNOREDRIVERHELD!=null &&
              this.IGNOREDRIVERHELD.equals(other.getIGNOREDRIVERHELD()))) &&
            ((this.LANGUAGE==null && other.getLANGUAGE()==null) || 
             (this.LANGUAGE!=null &&
              this.LANGUAGE.equals(other.getLANGUAGE()))) &&
            ((this.OBJECTID==null && other.getOBJECTID()==null) || 
             (this.OBJECTID!=null &&
              this.OBJECTID.equals(other.getOBJECTID()))) &&
            ((this.PASSWORD==null && other.getPASSWORD()==null) || 
             (this.PASSWORD!=null &&
              this.PASSWORD.equals(other.getPASSWORD()))) &&
            ((this.SUPPRESSRCLRSC==null && other.getSUPPRESSRCLRSC()==null) || 
             (this.SUPPRESSRCLRSC!=null &&
              this.SUPPRESSRCLRSC.equals(other.getSUPPRESSRCLRSC()))) &&
            ((this.USRPRF==null && other.getUSRPRF()==null) || 
             (this.USRPRF!=null &&
              this.USRPRF.equals(other.getUSRPRF()))) &&
            ((this.VERBID==null && other.getVERBID()==null) || 
             (this.VERBID!=null &&
              this.VERBID.equals(other.getVERBID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getADDITIONALFIELDS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getADDITIONALFIELDS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getADDITIONALFIELDS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBRANCH() != null) {
            _hashCode += getBRANCH().hashCode();
        }
        if (getCOMMITFLAG() != null) {
            _hashCode += getCOMMITFLAG().hashCode();
        }
        if (getCOMPANY() != null) {
            _hashCode += getCOMPANY().hashCode();
        }
        if (getIGNOREDRIVERHELD() != null) {
            _hashCode += getIGNOREDRIVERHELD().hashCode();
        }
        if (getLANGUAGE() != null) {
            _hashCode += getLANGUAGE().hashCode();
        }
        if (getOBJECTID() != null) {
            _hashCode += getOBJECTID().hashCode();
        }
        if (getPASSWORD() != null) {
            _hashCode += getPASSWORD().hashCode();
        }
        if (getSUPPRESSRCLRSC() != null) {
            _hashCode += getSUPPRESSRCLRSC().hashCode();
        }
        if (getUSRPRF() != null) {
            _hashCode += getUSRPRF().hashCode();
        }
        if (getVERBID() != null) {
            _hashCode += getVERBID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Polquotenquiry_INPUT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_INPUT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADDITIONALFIELDS");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ADDITIONALFIELDS"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_INPUT_ADDITIONALFIELDS"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://localhost:8080/axis/services/polquotenquiryservice", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BRANCH");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "BRANCH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COMMITFLAG");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "COMMITFLAG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COMPANY");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "COMPANY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IGNOREDRIVERHELD");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "IGNOREDRIVERHELD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LANGUAGE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "LANGUAGE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OBJECTID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "OBJECTID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PASSWORD");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "PASSWORD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SUPPRESSRCLRSC");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "SUPPRESSRCLRSC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("USRPRF");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "USRPRF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VERBID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "VERBID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
