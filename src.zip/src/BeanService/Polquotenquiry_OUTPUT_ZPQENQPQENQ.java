/**
 * Polquotenquiry_OUTPUT_ZPQENQPQENQ.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package BeanService;

public class Polquotenquiry_OUTPUT_ZPQENQPQENQ  implements java.io.Serializable {
    private BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS[] ADDITIONALFIELDS;

    private java.lang.String MOREIND;

    private java.lang.String STATUS;

    public Polquotenquiry_OUTPUT_ZPQENQPQENQ() {
    }

    public Polquotenquiry_OUTPUT_ZPQENQPQENQ(
           BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS[] ADDITIONALFIELDS,
           java.lang.String MOREIND,
           java.lang.String STATUS) {
           this.ADDITIONALFIELDS = ADDITIONALFIELDS;
           this.MOREIND = MOREIND;
           this.STATUS = STATUS;
    }


    /**
     * Gets the ADDITIONALFIELDS value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ.
     * 
     * @return ADDITIONALFIELDS
     */
    public BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS[] getADDITIONALFIELDS() {
        return ADDITIONALFIELDS;
    }


    /**
     * Sets the ADDITIONALFIELDS value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ.
     * 
     * @param ADDITIONALFIELDS
     */
    public void setADDITIONALFIELDS(BeanService.Polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS[] ADDITIONALFIELDS) {
        this.ADDITIONALFIELDS = ADDITIONALFIELDS;
    }


    /**
     * Gets the MOREIND value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ.
     * 
     * @return MOREIND
     */
    public java.lang.String getMOREIND() {
        return MOREIND;
    }


    /**
     * Sets the MOREIND value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ.
     * 
     * @param MOREIND
     */
    public void setMOREIND(java.lang.String MOREIND) {
        this.MOREIND = MOREIND;
    }


    /**
     * Gets the STATUS value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ.
     * 
     * @return STATUS
     */
    public java.lang.String getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this Polquotenquiry_OUTPUT_ZPQENQPQENQ.
     * 
     * @param STATUS
     */
    public void setSTATUS(java.lang.String STATUS) {
        this.STATUS = STATUS;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Polquotenquiry_OUTPUT_ZPQENQPQENQ)) return false;
        Polquotenquiry_OUTPUT_ZPQENQPQENQ other = (Polquotenquiry_OUTPUT_ZPQENQPQENQ) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ADDITIONALFIELDS==null && other.getADDITIONALFIELDS()==null) || 
             (this.ADDITIONALFIELDS!=null &&
              java.util.Arrays.equals(this.ADDITIONALFIELDS, other.getADDITIONALFIELDS()))) &&
            ((this.MOREIND==null && other.getMOREIND()==null) || 
             (this.MOREIND!=null &&
              this.MOREIND.equals(other.getMOREIND()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              this.STATUS.equals(other.getSTATUS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getADDITIONALFIELDS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getADDITIONALFIELDS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getADDITIONALFIELDS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMOREIND() != null) {
            _hashCode += getMOREIND().hashCode();
        }
        if (getSTATUS() != null) {
            _hashCode += getSTATUS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Polquotenquiry_OUTPUT_ZPQENQPQENQ.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ZPQENQPQENQ"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADDITIONALFIELDS");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "ADDITIONALFIELDS"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:BeanService", "polquotenquiry_OUTPUT_ZPQENQPQENQ_ADDITIONALFIELDS"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://localhost:8080/axis/services/polquotenquiryservice", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MOREIND");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "MOREIND"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:BeanService", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
