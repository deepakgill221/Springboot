package com.qualtech.bot.scheduler;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class check 
{
	public static void main(String...abc)
	{
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		Calendar cal = Calendar.getInstance();
		String time =dateFormat.format(cal.getTime()); //2016/11/16 12:08:43
		Configuration cfg=new Configuration();  
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();  
		Session session1=factory.openSession();  
		Transaction t1=session1.beginTransaction();
		Query query = session1.createQuery("From BotBean b where p.id=18021");
		query.setCacheable(true);
		List<BotBean> list = query.list();
		Iterator it = list.iterator();
		while(it.hasNext())
		{
			BotBean bean = (BotBean)it.next();
			System.out.println(bean.getId());
			System.out.println(bean.getStatus());
		}

			System.out.println(list.toString());  
		/*BotBean botBean=new BotBean(); 
	    botBean.setCreatedBy("BotSchedular");
	    botBean.setStatus("SUCCESS");
	    botBean.setCreatedDate(time);
	    session.persist(botBean);  */
		System.out.println("END");
		t1.commit();
		session1.close();
		Session session2=factory.openSession();
		Transaction t2 = session2.beginTransaction();
		query = session2.createQuery("From BotBean b where p.id=18021");
		query.setCacheable(true);
		it = query.list().iterator();
		while (it.hasNext ()){
			BotBean p = (BotBean) it.next();
			System.out.println(p.getId());
			System.out.println(p.getId());
		}
		t2.commit();
		session2.close();
	}
}
