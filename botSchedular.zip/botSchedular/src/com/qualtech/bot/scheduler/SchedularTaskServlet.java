package com.qualtech.bot.scheduler;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class SchedularTaskServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	static ResourceBundle res=ResourceBundle.getBundle("com.qualtech.bot.scheduler.Scheduler");
	static Logger logger=Logger.getLogger(SchedularTaskServlet.class.getName());
	static ScheduledExecutorService scheduledExecutorService;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}  	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		
	}
	public void init(ServletConfig config) throws ServletException
    {
		super.init(config);
		proceed();
	}	
	private void proceed(){
		try
		{
			Runnable MapMemoryManagmentWebserviceScheduler = new  MapMemoryManagmentWebserviceScheduler();
			try
			{
				scheduledExecutorService = Executors.newScheduledThreadPool(2);
				schedulerTasks("MapMemoryManagmentWebserviceScheduler", MapMemoryManagmentWebserviceScheduler);
			}
			catch(Exception e)
			{
				System.out.println("Exception occoured");
			}				
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void schedulerTasks(String taskName,Runnable schedular)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy kk:mm");			
		Calendar cal =null;
		int weekDay=0;
		int weekMin=0;
		int weekHr=0;
		int runDay=0;
		int runHr=0;
		int runMin=0;
		int runDelay=0;
		float runGap=0;
		String flag=null;
		try
		{	
			flag=res.getString("com.max.bot."+taskName+".Active").trim();
			if(flag!=null && flag.equalsIgnoreCase("Y"))
			{
				cal=Calendar.getInstance();
				weekDay = cal.get(Calendar.DAY_OF_WEEK);//get the Weekday , from 1 to 7
				weekHr = cal.get(Calendar.HOUR_OF_DAY);//get the Weekday , from 0 to 23
				weekMin = cal.get(Calendar.MINUTE);//get the Weekday , from 0 to 59
				runDay=Integer.parseInt(res.getString("com.max.bot."+taskName+".day").trim());
				runDay=runDay==0?weekDay:runDay;
				runHr=Integer.parseInt(res.getString("com.max.bot."+taskName+".hrs").trim());
				runHr=runHr==0?weekHr:runHr;
				runMin=Integer.parseInt(res.getString("com.max.bot."+taskName+".min").trim());
				runGap=Float.parseFloat(res.getString("com.max.bot."+taskName+".gap").trim());
				runDelay=Integer.parseInt(res.getString("com.max.bot."+taskName+".delay").trim());
				runDay=(runDay>=weekDay)?(runDay-weekDay):runDay+(7-weekDay);			
				runHr=(runHr>=weekHr)?(runHr-weekHr):runHr+(24-weekHr);
				runMin=(runMin>=weekMin)?(runMin-weekMin):runMin-weekMin;
				cal.setTime(sdf.parse(sdf.format(new Date())));
				cal.add(Calendar.DATE, runDay);			
				cal.add(Calendar.HOUR, runHr);
				cal.add(Calendar.MINUTE,runMin);
				runDay=Integer.parseInt(String.valueOf((cal.getTimeInMillis()-(sdf.parse(sdf.format(new Date()))).getTime())));
			    @SuppressWarnings("unused")
				ScheduledFuture<?> alarmFuture = scheduledExecutorService.scheduleWithFixedDelay(schedular,(long) runDay,(long) ((long) runDelay*runGap*60*60*1000), TimeUnit.MILLISECONDS);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
}