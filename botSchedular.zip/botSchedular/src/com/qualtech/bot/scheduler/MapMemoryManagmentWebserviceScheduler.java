package com.qualtech.bot.scheduler;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.cfg.Configuration;



import javax.net.ssl.HttpsURLConnection;

public class MapMemoryManagmentWebserviceScheduler implements Runnable
{
	static Logger logger=Logger.getLogger(MapMemoryManagmentWebserviceScheduler.class.getName());
	String param[]=null;
	int dataCount=0;
	@Override
	public void run()
	{
		try
		{
			logger.info("Schedular Inside :: Run Method");
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			Calendar cal = Calendar.getInstance();
			String time =dateFormat.format(cal.getTime()); //2016/11/16 12:08:43
			
			String  DevMode = "Y";
			StringBuilder requestdata = new StringBuilder();
			StringBuilder result = new StringBuilder();
			String output = new String();
			HttpURLConnection conn = null;
			try {
				XTrustProvider trustProvider = new XTrustProvider();
				trustProvider.install();
				String serviceurl ="https://rabotprod.herokuapp.com/webhook"; 
				logger.info("Service url to hit :- "+serviceurl);
				URL url = new URL(serviceurl);
				if(DevMode!=null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode))
				{
					Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
					conn = (HttpURLConnection) url.openConnection(proxy);
				}else{
					conn = (HttpURLConnection) url.openConnection();
				}
				UUID uniqueId = UUID.randomUUID();
				HttpsURLConnection.setFollowRedirects(true);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				requestdata.append(	"	{	");
				requestdata.append(	"	    \"id\": \"9c149682-5192-48f9-98a8-6e23442c27f1\",	");
				requestdata.append(	"	    \"timestamp\": \"2017-06-15T07:02:56.935Z\",	");
				requestdata.append(	"	    \"lang\": \"en\",	");
				requestdata.append(	"	    \"result\": {	");
				requestdata.append(	"	        \"source\": \"agent\",	");
				requestdata.append(	"	        \"resolvedQuery\": \"pmhom3698 mliea@123\",	");
				requestdata.append(	"	        \"action\": \"close.clear\",	");
				requestdata.append(	"	        \"actionIncomplete\": false,	");
				requestdata.append(	"	        \"parameters\": {	");
				requestdata.append(	"			\"SSOID\": \"hvhom1028\"	");
				requestdata.append(	"	        },	");
				requestdata.append(	"	        \"contexts\": [],	");
				requestdata.append(	"	        \"metadata\": {	");
				requestdata.append(	"	            \"intentId\": \"a8551168-baed-45ff-a58e-a9f57ecfea7e\",	");
				requestdata.append(	"	            \"webhookUsed\": \"false\",	");
				requestdata.append(	"	            \"webhookForSlotFillingUsed\": \"false\",	");
				requestdata.append(	"	            \"intentName\": \"NB.Authentication\"	");
				requestdata.append(	"	        },	");
				requestdata.append(	"	        \"fulfillment\": {	");
				requestdata.append(	"	            \"speech\": \"\",	");
				requestdata.append(	"	            \"messages\": [	");
				requestdata.append(	"	                {	");
				requestdata.append(	"	                    \"type\": 0,	");
				requestdata.append(	"	                    \"speech\": \"\"	");
				requestdata.append(	"	                }	");
				requestdata.append(	"	            ]	");
				requestdata.append(	"	        },	");
				requestdata.append(	"	        \"score\": 1	");
				requestdata.append(	"	    },	");
				requestdata.append(	"	    \"status\": {	");
				requestdata.append(	"	        \"code\": 200,	");
				requestdata.append(	"	        \"errorType\": \"success\"	");
				requestdata.append(	"	    },	");
				requestdata.append(	"	    \"sessionId\": \""+uniqueId+"\"	");
				requestdata.append(	"	}	");
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
				writer.write(requestdata.toString());
				writer.flush();
				try {writer.close(); } catch (Exception e1) {}
				int apiResponseCode = conn.getResponseCode();
				if(apiResponseCode == 200)
				{
					logger.info("API Response Code :- "+apiResponseCode);
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
				}
				else
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
					while ((output = br.readLine()) != null) {
						result.append(output);
					}
					conn.disconnect();
					br.close();
				}
			}
			catch(Exception e)
			{
				System.out.println("Exception occoured while calling heroku service"+e);
			}
			logger.info("SessionFactory :: OpenSession :: START");
			System.out.println("Current Time is :- "+time);
		}
		catch(Exception e)
		{
			System.out.println("Error in Welcome Call Hit Webservice Scheduler Run :-"+e);
		}	
	}
}
