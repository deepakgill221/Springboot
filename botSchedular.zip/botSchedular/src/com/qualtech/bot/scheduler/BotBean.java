package com.qualtech.bot.scheduler;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name="BOTBEAN_SCHEDULAR_DATA")
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)
public class BotBean 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO) 
	@Column(name="USER_ID")
	public int id;
	@Column(name="STATUS")
	public String status;
	@Column(name="CREATED_BY")
	public String createdBy;
	
	@Column(name="CREATED_DATE")
	private String createdDate;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public String toString() {
		return "BotBean "
				+ "[id=" + id + ", "
					+ "status=" + status + ", "
					+ "createdBy=" + createdBy + ", "
					+ "createdDate=" + createdDate
				+ "]";
	}
}
