﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication3
{

    public class Header
    {
        public string soaCorrelationId { get; set; }
        public string soaMsgVersion { get; set; }
        public string soaAppId { get; set; }
    }

    public class Transaction
    {
        public string aadhaarNumber { get; set; }
        public string AadhaarName { get; set; }
        public string strYear { get; set; }
        public string strGender { get; set; }
        public string strPiMatchStrategy { get; set; }
        public string strPiMatchValue { get; set; }
        public string strAddressValue { get; set; }
        public string strPfaMatchStrategy { get; set; }
        public string strPfaMatchValue { get; set; }
        public string strCareOf { get; set; }
        public string strBuilding { get; set; }
        public string strLandmark { get; set; }
        public string strStreet { get; set; }
        public string strLocality { get; set; }
        public string strPoName { get; set; }
        public string strVillage { get; set; }
        public string strSubdist { get; set; }
        public string strDistrict { get; set; }
        public string strState { get; set; }
        public string strPincode { get; set; }
        public string strCountry { get; set; }
        public string type { get; set; }
    }

    public class RequestPayload
    {
        public List<Transaction> transactions { get; set; }
    }

    public class RequestData
    {
        public RequestPayload requestPayload { get; set; }
    }

    public class Request
    {
        public Header header { get; set; }
        public RequestData requestData { get; set; }
    }

    public class RootObject
    {
        public Request request { get; set; }
    }


}
