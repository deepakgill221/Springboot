﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication3
{
    public static class PolicyData
    {

        //public string polno = String.Empty;
        //public string dob = String.Empty;
        //public string age = String.Empty;

    }
}
