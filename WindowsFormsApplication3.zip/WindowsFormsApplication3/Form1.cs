﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Newtonsoft.Json.Linq;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public static Microsoft.Office.Interop.Excel.Application oXL;
        public static Microsoft.Office.Interop.Excel._Workbook oWB;
        public static Microsoft.Office.Interop.Excel._Worksheet oSheet;
        public static Microsoft.Office.Interop.Excel.Range oRng;
        public static object misvalue = System.Reflection.Missing.Value;
        public static string fileName = AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Report\Aadhar_"+ DateTime.Now.ToString("dd-MMM-yyyy hh.mm.ss tt")+".xls";
        public Form1()
        {
            InitializeComponent();
        }



        private void btn_upload_Click(object sender, EventArgs e)
        {
            string filePath = "";
            string fileExt = string.Empty;
            OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file  
            if (file.ShowDialog() == System.Windows.Forms.DialogResult.OK) //if there is a file choosen by the user  
            {
                filePath = file.FileName; //get the path of the file  
                fileExt = Path.GetExtension(filePath); //get the file extension  
                if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                {
                    try
                    {
                        System.Data.DataTable dtExcel = new System.Data.DataTable();
                        dtExcel = ReadExcel(filePath, fileExt); //read excel file  
                        CreateExcel();
                        if (dtExcel != null && dtExcel.Rows.Count > 0)
                        {
                            int cnt = 1;
                            foreach (DataRow dr in dtExcel.Rows)
                            {
                                String polNo = Convert.ToString(dr["POLICY_NO"]);
                                string aadharNo = Convert.ToString(dr["AADHAAR_NO"]);
                                if (polNo != "" && aadharNo != "")
                                {
                                    try
                                    {
                                        System.Data.DataTable dtWrite = new System.Data.DataTable();
                                        dtWrite.Columns.Add("Column1");
                                        dtWrite.Columns.Add("Column2");
                                        dtWrite.Columns.Add("Column3");
                                        dtWrite.Columns.Add("Column4");
                                        System.Data.DataTable dt = GetPolicyData(polNo);
                                        if (dt.Rows.Count >0)
                                        {
                                            string gender = Convert.ToString(dt.Rows[0]["CLI_SEX_CD"]);
                                            string dob = Convert.ToString(dt.Rows[0]["CLI_BTH_DT"]);
                                            if (gender != "" && dob != "")

                                            {
                                                string ReqData = JsonConvert.SerializeObject(JsonData(polNo, aadharNo, gender, dob));
                                                string Response = PostData(ReqData);
                                                var obj = JObject.Parse(Response);

                                                //JArray experiencesArrary = (JArray)obj["Transactions"];
                                                //if (experiencesArrary != null)
                                                //{
                                                //    foreach (var item in experiencesArrary)
                                                //    {
                                                //        Console.WriteLine("company Id :" + item["companyid"]);
                                                //        Console.WriteLine("company Name :" + item["companyname"].ToString());
                                                //    }

                                                //}
                                                //string authStatus = (string)obj.SelectToken("Response.responseData.generalResponse.status");
                                              
                                              
                                                DataRow row = dtExcel.NewRow();
                                                row["Column1"] = polNo;
                                                row["Column2"] = aadharNo;
                                                row["Column3"] = "";
                                                row["Column4"] = "Aadhar validation success";

                                                dtExcel.Rows.Add(row);

                                                //DataRow row2 = dt.NewRow();
                                                //row2[0] = "Row2-Col1";
                                                //row2[1] = "Row2-Col2";
                                                //dt.Rows.Add(row2);
                                               
                                              
                                            }

                                        }
                                        else
                                        {
                                            DataRow row = dtExcel.NewRow();
                                            row["Column1"] = polNo;
                                            row["Column2"] = aadharNo;
                                            row["Column3"] = "E";
                                            row["Column4"] = "Data not found from backend";

                                            dtExcel.Rows.Add(row);
                                            
                                        }
                                        cnt++;
                                    }
                                    catch(Exception ex)
                                    {

                                    }

                                }
                            }
                        }

                        //***************************//
                        dataGridView1.Visible = true;
                        dataGridView1.DataSource = dtExcel;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); //custom messageBox to show error  
                }
            }
        }

        private System.Data.DataTable GetPolicyData(string polno)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                string conStr = System.Configuration.ConfigurationManager.ConnectionStrings["DB"].ConnectionString;
                string query = "SELECT  A.POL_ID,B.CLI_ID,C.CLI_SEX_CD,TO_CHAR( C.CLI_BTH_DT, 'YYYY-MM-DD') AS CLI_BTH_DT FROM TPOL A,TPOLC B,TCLI C,TCLNM D WHERE A.CO_ID = 'CP' AND A.POL_ID = " + polno + " AND B.CO_ID = 'CP' AND A.POL_ID = B.POL_ID AND POL_CLI_REL_TYP_CD = 'O' AND C.CO_ID = 'CP' AND B.CLI_ID = C.CLI_ID AND D.CO_ID = 'CP' AND C.CLI_ID = D.CLI_ID AND D.CLI_INDV_NM_TYP_CD = 'CR' AND D.CLI_INDV_GR_CD = 'AL'";
                using (OracleConnection OraConn = new OracleConnection(conStr))
                {
                    if (OraConn.State == ConnectionState.Closed) OraConn.Open();
                    using (OracleCommand command = new OracleCommand(query, OraConn))
                    {

                        command.CommandType = CommandType.Text;
                        using (OracleDataReader rdr = command.ExecuteReader())
                        {
                            dt.Clear();
                            dt.Load(rdr);
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;
        }

        private object JsonData(string polNo, string aadharNo, string gender, string dob)
        {
            var obj = new object();
            try
            {
                obj = new RootObject
                {
                    request = new Request
                    {
                        header = new Header
                        {
                            soaCorrelationId = "25897",
                            soaMsgVersion = "1.0",
                            soaAppId = "NEO"
                        },
                        requestData = new RequestData
                        {
                            requestPayload = new RequestPayload
                            {
                                transactions = new List<Transaction>
                            {
                                new Transaction {
                                aadhaarNumber= aadharNo,
                                 AadhaarName= "",
                                 strYear= dob,
                                 strGender= gender,
                                 strPiMatchStrategy= "",
                                 strPiMatchValue= "",
                                 strAddressValue= "",
                                 strPfaMatchStrategy= "",
                                 strPfaMatchValue= "",
                                 strCareOf= "",
                                 strBuilding= "",
                                 strLandmark= "",
                                 strStreet= "",
                                 strLocality= "",
                                 strPoName= "",
                                 strVillage= "",
                                 strSubdist= "",
                                 strDistrict= "",
                                 strState= "",
                                 strPincode= "",
                                 strCountry= "",
                                 type= "AadhaarDemoAuth"
                                }
                            },
                            },
                        },

                    },
                };
            }
            catch (Exception ex)
            {
                obj = ex;
            }
            return obj;
        }

        private static string PostData(string DATA)
        {
            string response = "";


           

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://ekyc.maxlifeinsurance.com/AadhaarDemographicNNameServiceClient/services/WebService/GetDemoAuthRequest");
                request.Method = "POST";
                request.ContentType = "application/json";
                request.ContentLength = DATA.Length;
                using (Stream webStream = request.GetRequestStream())
                using (StreamWriter requestWriter = new StreamWriter(webStream, System.Text.Encoding.ASCII))
                {
                    requestWriter.Write(DATA);
                }


                WebResponse webResponse = request.GetResponse();
                using (Stream webStream = webResponse.GetResponseStream())
                {
                    if (webStream != null)
                    {
                        using (StreamReader responseReader = new StreamReader(webStream))
                        {
                            response = responseReader.ReadToEnd();
                           


                        }
                    }
                }
            }
            catch (Exception e)
            {
                response = e.Message;
            }
            return response;
        }


        public System.Data.DataTable ReadExcel(string fileName, string fileExt)
        {
            string conn = string.Empty;
            System.Data.DataTable dtexcel = new System.Data.DataTable();
            if (fileExt.CompareTo(".xls") == 0)
                conn = @"provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HRD=Yes;IMEX=1';"; //for below excel 2007  
            else
                conn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties='Excel 12.0;HDR=Yes';"; //for above excel 2007  
            using (OleDbConnection con = new OleDbConnection(conn))
            {
                try
                {
                    OleDbDataAdapter oleAdpt = new OleDbDataAdapter("select * from [Sheet1$]", con); //here we read data from sheet1  
                    oleAdpt.Fill(dtexcel); //fill excel data into dataTable  
                }
                catch { }
            }
            return dtexcel;
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private static void CreateExcel()
        {
            try
            {
                //Start Excel and get Application object.
                oXL = new Microsoft.Office.Interop.Excel.Application();
                oXL.Visible = true;

                //Get a new workbook.
                oWB = (Microsoft.Office.Interop.Excel._Workbook)(oXL.Workbooks.Add(""));
                oSheet = (Microsoft.Office.Interop.Excel._Worksheet)oWB.ActiveSheet;

                //Add table headers going cell by cell.
                oSheet.Cells[1, 1] = "POLICY NO";
                oSheet.Cells[1, 2] = "AADHAAR NO";
                oSheet.Cells[1, 3] = "STATUS";
                oSheet.Cells[1, 4] = "MESSAGE";

                //Format A1:D1 as bold, vertical alignment = center.
                oSheet.get_Range("A1", "D1").Font.Bold = true;
                oSheet.get_Range("A1", "D1").VerticalAlignment =
                    Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;

                // Create an array to multiple values at once.
               
                oRng = oSheet.get_Range("A1", "D1");
                oRng.EntireColumn.AutoFit();

                oXL.Visible = false;
                oXL.UserControl = false;
                oWB.SaveAs(fileName, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing,
                    false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                    Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                oWB.Close();
            }
            catch(Exception ex)
            {

            }
            }

        private static void WriteToExcel(string polNo,string aadharNo,string status,string msg,int cnt)
        {
            try
            {
                oXL = new Microsoft.Office.Interop.Excel.Application();
                oXL.Visible = true;
                oXL.DisplayAlerts = false;
                oWB = oXL.Workbooks.Open(fileName, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                //Get all the sheets in the workbook
           
                //Get the allready exists sheet
             
                

                Microsoft.Office.Interop.Excel.Sheets mWorkSheets = oWB.Worksheets;
                oSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item("Sheet1");
                Microsoft.Office.Interop.Excel.Range range = oSheet.UsedRange;
                //oXL = new Microsoft.Office.Interop.Excel.Application();
                //oWB = oXL.Workbooks.Open(fileName);
                //oSheet = String.IsNullOrEmpty("Sheet1$") ? (Microsoft.Office.Interop.Excel._Worksheet)oWB.ActiveSheet : (Microsoft.Office.Interop.Excel._Worksheet)oWB.Worksheets["Sheet1$"];

                oSheet.Cells[cnt+1, 1] = polNo;
                oSheet.Cells[cnt + 1, 2] = aadharNo;
                oSheet.Cells[cnt + 1, 3] = status;
                oSheet.Cells[cnt + 1, 4] = msg;

                oWB.Save();
             //   oWB.Close();
             
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    

    }
}
