package com.qc.service;

import com.qc.dto.ApiRequest;
import com.qc.dto.ApiResponse;
import com.qc.entity.PerfiosEntity;

public interface UnoService 
{
//	public PerfiosEntity getUnoData(PerfiosEntity perfiosEntity);
	
//	public PerfiosEntity getUnoData1(PerfiosEntity perfiosEntity);
	
	public ApiResponse getPartialWithDrawalDataService(ApiRequest apiresponse);
	public ApiResponse getTotalPremiumDataService(ApiRequest apiresponse);
	
}
