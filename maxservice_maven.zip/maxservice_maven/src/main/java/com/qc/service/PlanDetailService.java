package com.qc.service;

import java.sql.SQLException;
import java.util.List;

import com.qc.entity.PlanDetailBean;

public interface PlanDetailService 
{
	public List<PlanDetailBean> callPlanDetailService(String planid,String rtbl_age_dur,String rtbl_sex)  throws SQLException , Exception;
}
