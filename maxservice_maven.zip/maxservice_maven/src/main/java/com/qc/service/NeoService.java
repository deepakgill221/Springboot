package com.qc.service;

import java.util.Map;

public interface NeoService 
{
	public String processDFSRequest(Map requestData, String requestJson);

	public String processPlanDetailsRequest(Map requestData, String requestJson);

	public String processExistingCustomerRequest(Map requestData, String requestJson);
	
	public String getPolicyService(String key) throws Exception;
	
	public String getIFSCService(String key) throws Exception;

}
