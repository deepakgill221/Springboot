package com.qc.service;

import java.util.Map;

import org.springframework.core.env.Environment;

public interface ExternalServices {
	
	public Map<String,String> callService(Map<String,Object> requestParams,Environment env);

	public Map<String, String> callNeoService(Map<String,Object> requestParams,Environment env);
	

}
