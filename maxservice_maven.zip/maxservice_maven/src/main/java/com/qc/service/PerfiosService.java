package com.qc.service;

import com.qc.entity.PerfiosEntity;

public interface PerfiosService 
{
	public PerfiosEntity getStartProcessData(PerfiosEntity perfiosEntity);
	
	public PerfiosEntity getTransactionStatus(PerfiosEntity perfiosEntity);
	
	public PerfiosEntity getRetrieveReport(PerfiosEntity perfiosEntity);
	
	public PerfiosEntity getTransactionReview(PerfiosEntity perfiosEntity);
	
	public PerfiosEntity getSupportedInstitutions(PerfiosEntity perfiosEntity);
	
	public PerfiosEntity getDeleteData(PerfiosEntity perfiosEntity);
	
}
