package com.qc.entity;

import java.io.Serializable;

import org.springframework.context.annotation.PropertySource;

@PropertySource({ "application.properties" })
public class PerfiosEntity implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8260711006839238715L;
	private String tId="";
	private String perfiosTransId="";
	private String startProcessHtml="";
	private String venderId="";
	private String emailId="";
	private String destination="";
	private String returnUrl="";
	private String trackerId="";
	private String responseXML="";
	private String txnStatusUrl;
	private String retriveUrl;
	private String transactionReviewUrl;
	private String supportedInstUrl;
	private String deleteDataUrl;
	private String apiResponseCode;
	public String gettId() {
		return tId;
	}
	public void settId(String tId) {
		this.tId = tId;
	}
	public String getPerfiosTransId() {
		return perfiosTransId;
	}
	public void setPerfiosTransId(String perfiosTransId) {
		this.perfiosTransId = perfiosTransId;
	}
	public String getStartProcessHtml() {
		return startProcessHtml;
	}
	public void setStartProcessHtml(String startProcessHtml) {
		this.startProcessHtml = startProcessHtml;
	}
	public String getVenderId() {
		return venderId;
	}
	public void setVenderId(String venderId) {
		this.venderId = venderId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getReturnUrl() {
		return returnUrl;
	}
	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}
	public String getTrackerId() {
		return trackerId;
	}
	public void setTrackerId(String trackerId) {
		this.trackerId = trackerId;
	}
	public String getResponseXML() {
		return responseXML;
	}
	public void setResponseXML(String responseXML) {
		this.responseXML = responseXML;
	}
	public String getTxnStatusUrl() {
		return txnStatusUrl;
	}
	public void setTxnStatusUrl(String txnStatusUrl) {
		this.txnStatusUrl = txnStatusUrl;
	}
	public String getRetriveUrl() {
		return retriveUrl;
	}
	public void setRetriveUrl(String retriveUrl) {
		this.retriveUrl = retriveUrl;
	}
	public String getTransactionReviewUrl() {
		return transactionReviewUrl;
	}
	public void setTransactionReviewUrl(String transactionReviewUrl) {
		this.transactionReviewUrl = transactionReviewUrl;
	}
	public String getSupportedInstUrl() {
		return supportedInstUrl;
	}
	public void setSupportedInstUrl(String supportedInstUrl) {
		this.supportedInstUrl = supportedInstUrl;
	}
	public String getDeleteDataUrl() {
		return deleteDataUrl;
	}
	public void setDeleteDataUrl(String deleteDataUrl) {
		this.deleteDataUrl = deleteDataUrl;
	}
	public String getApiResponseCode() {
		return apiResponseCode;
	}
	public void setApiResponseCode(String apiResponseCode) {
		this.apiResponseCode = apiResponseCode;
	}
	@Override
	public String toString() {
		return "PerfiosEntity [tId=" + tId + ", perfiosTransId=" + perfiosTransId + ", startProcessHtml="
				+ startProcessHtml + ", venderId=" + venderId + ", emailId=" + emailId + ", destination=" + destination
				+ ", returnUrl=" + returnUrl + ", trackerId=" + trackerId + ", responseXML=" + responseXML
				+ ", txnStatusUrl=" + txnStatusUrl + ", retriveUrl=" + retriveUrl + ", transactionReviewUrl="
				+ transactionReviewUrl + ", supportedInstUrl=" + supportedInstUrl + ", deleteDataUrl=" + deleteDataUrl
				+ ", apiResponseCode=" + apiResponseCode + "]";
	}
}
