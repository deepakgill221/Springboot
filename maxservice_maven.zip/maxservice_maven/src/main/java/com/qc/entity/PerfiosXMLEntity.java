package com.qc.entity;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PerfiosXMLEntity implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8473665743063400587L;
	//@XmlElement
	private String trackerId="";
	//@XmlElement
	private String tId="";
	//@XmlElement
	private String perfiosTransId="";
	//@XmlElement
	private String destinationId="";
	public String getTrackerId() {
		return trackerId;
	}
	public void setTrackerId(String trackerId) {
		this.trackerId = trackerId;
	}
	public String gettId() {
		return tId;
	}
	public void settId(String tId) {
		this.tId = tId;
	}
	public String getPerfiosTransId() {
		return perfiosTransId;
	}
	public void setPerfiosTransId(String perfiosTransId) {
		this.perfiosTransId = perfiosTransId;
	}
	public String getDestinationId() {
		return destinationId;
	}
	public void setDestinationId(String destinationId) {
		this.destinationId = destinationId;
	}
	@Override
	public String toString() {
		return "PerfiosXMLEntity [trackerId=" + trackerId + ", tId=" + tId + ", perfiosTransId=" + perfiosTransId
				+ ", destinationId=" + destinationId + "]";
	}
}
