package com.qc.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SPR_BOOT_TEST")
public class UnoDBEntity 
{
	
	@Id
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "ID")
	private String id;

	
	public UnoDBEntity() {
		super();
	}

	public UnoDBEntity(String name, String id) {
		super();
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
