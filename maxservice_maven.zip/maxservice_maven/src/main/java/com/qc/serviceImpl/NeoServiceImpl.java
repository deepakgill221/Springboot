package com.qc.serviceImpl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.controller.NeoControllerRest;
import com.qc.dao.NeoDao;
import com.qc.entity.PlanDetailBean;
import com.qc.service.NeoService;
import com.qc.service.PlanDetailService;
import com.qc.utils.Base64ArrayUtility;
import com.qc.utils.Commons;
import com.qc.utils.IfscMicrUtility;
import com.qc.utils.PolicyGenerationUtility;

@Service
public class NeoServiceImpl implements NeoService 
{
	private static Logger logger = LogManager.getLogger(NeoControllerRest.class);
	@Autowired Environment env;
	@Autowired NeoDao neoDao;
	@Autowired PlanDetailService planDetailService; 

	@Override
	public String processDFSRequest(Map requestData, String requestJson) 
	{

		int i=0;
		String methodName=null;
		methodName=Commons.getMethodName();
		logger.info("Came inside "+methodName+"().");
		String leadId="";
		String docType="";
		String fileFormat="";
		String atchmnt="";
		String date="";
		//String gender="";
		String Key1="";
		String ValidationType="";
		boolean X = false;
		StringBuilder responseJson = new StringBuilder();
		try
		{
			if(requestData!=null)
			{
				leadId=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("leadId")).toString().toUpperCase();
				docType=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("docType")).toString().toUpperCase();
				fileFormat=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("fileFormat")).toString().toUpperCase();
				atchmnt=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("atchmnt")).toString().trim();
				date=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("date")).toString().toUpperCase();
				ValidationType=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("ValidationType")).toString();
				Key1=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("Key1")).toString();

				logger.info("leadId is : "+leadId+" and ValidationType is : " + ValidationType);

				String reponseString=requestJson.replaceAll("Request","Response");
				reponseString = reponseString.replace(atchmnt, "12345");
				responseJson.append(reponseString.substring(0,reponseString.indexOf("TransTrackingID")-1));
				responseJson.append("\"TransTrackingID\":\"\",\"TransactionData\": ");

				String path=env.getProperty("com.qualtech.DFS.Path");

				if(leadId!=null && !leadId.equalsIgnoreCase("")
						&& docType!=null && !docType.equalsIgnoreCase("")
						&& fileFormat!=null && !fileFormat.equalsIgnoreCase("")
						&& atchmnt!=null && !atchmnt.equalsIgnoreCase("")
						&& date!=null && !date.equalsIgnoreCase("")
						)
				{
					if(ValidationType!=null && ValidationType.equalsIgnoreCase("DFS"))
					{
						boolean docTypeFlag = false;
						try
						{
							int docId = Integer.parseInt(docType);
							if(docId>0 && docId<166)
							{
								docType=getDocTypeName(docId);
								docTypeFlag=true;
								logger.info("Valid DocType Recived");
							}

						}
						catch(Exception ex)
						{
							logger.info("We are in Exception : Invalid DocType Recived");
						}

						if(docTypeFlag)
						{
							logger.info("All validation passed.");
							String filePath = path+File.separator+leadId;
							String docName = "";

							File dir = new File(filePath);
							dir.mkdirs();
							logger.info("File path :" +dir);

							if (dir.exists())
							{
								logger.info("Exists Path is :"+path);
								if (dir.canWrite() )
								{
									//For Development Check
									//String aa = new Base64ArrayUtility().encodeToString("D:/abc.pdf", true);
									//logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
									//logger.info(aa);
									//byte[] bFile = 	new Base64ArrayUtility().decodeToByteArray(aa);

									byte[] bFile = 	new Base64ArrayUtility().decodeToByteArray(atchmnt);
									if(bFile!=null)
									{
										if(fileFormat.equalsIgnoreCase("pdf") || fileFormat.equalsIgnoreCase("tif")
												|| fileFormat.equalsIgnoreCase("jpg") || fileFormat.equalsIgnoreCase("jpeg")
												|| fileFormat.equalsIgnoreCase("bmp") || fileFormat.equalsIgnoreCase("gif")
												|| fileFormat.equalsIgnoreCase("tiff") || fileFormat.equalsIgnoreCase("doc")
												||fileFormat.equalsIgnoreCase("docx") || fileFormat.equalsIgnoreCase("tif")	)
										{
											logger.info("Request for :  "+fileFormat+"  : Start");
											try 
											{
												docName=docType+"_"+leadId+"_"+date+"."+fileFormat;
												FileOutputStream fileOuputStream = new FileOutputStream(""+dir+File.separator+docName);
												fileOuputStream.write(bFile);
												fileOuputStream.close();
												logger.info("File Saving on common Location : Done");
											}
											catch(Exception e)
											{
												logger.error("Error occured while converting into PDF"+e.getMessage());
											}    
											responseJson.append("    {	 ");
											responseJson.append("    \"status\": \"200\",	 ");
											responseJson.append("    \"statusDesc\": \"Success\",	 ");

											responseJson.append("    \"filePath\": \""+env.getProperty("com.qualtech.DFS.Path.forResponse")+leadId+"\\\\"+docName+"\",	 ");
											responseJson.append("    \"docName\": \""+docName+"\",	 ");

											responseJson.append(" 	 \"message\": \"Response Successfully Generated\"	 ");
											responseJson.append(" 	 }	 ");
											logger.info("Request for :  PDF  : End");
										}
										else
										{
											logger.info("Failure due to invalid file format");

											responseJson.append("    {	 ");
											responseJson.append("    \"status\": \"102\",	 ");
											responseJson.append("    \"statusDesc\": \"Failure\",	 ");
											responseJson.append(" 	 \"message\": \"Invalid File Format\"	 ");
											responseJson.append(" 	 }	 ");
										}

									}
									else
									{
										logger.info("Failure due to invalid Attachment i.e invalid Base64String");

										responseJson.append("    {	 ");
										responseJson.append("    \"status\": \"102\",	 ");
										responseJson.append("    \"statusDesc\": \"Failure\",	 ");
										responseJson.append(" 	 \"message\": \"Invalid Attachment\"	 ");
										responseJson.append(" 	 }	 ");
									}
								}
								else
								{
									// The directory is not writable
									responseJson.append("    {	 ");
									responseJson.append("    \"status\": \"102\",	 ");
									responseJson.append("    \"statusDesc\": \"Failure\",	 ");
									responseJson.append(" 	 \"message\": \"WebService Not Able to Write Data\"	 ");
									responseJson.append(" 	 }	 ");
									logger.info("Path is not Writable :"+path);
								}
							}
							else
							{
								// The directory is not exists
								responseJson.append("    {	 ");
								responseJson.append("    \"status\": \"102\",	 ");
								responseJson.append("    \"statusDesc\": \"Failure\",	 ");
								responseJson.append(" 	 \"message\": \"WebService Not Able to Access Path\"	 ");
								responseJson.append(" 	 }	 ");
								logger.info("Path is not exists :"+path);
							}
						}
						else
						{
							logger.info("Failure due to the Invalid Documet Type.");

							responseJson.append("    {	 ");
							responseJson.append("    \"status\": \"102\",	 ");
							responseJson.append("    \"statusDesc\": \"Failure\",	 ");
							responseJson.append(" 	 \"message\": \"Invalid Documet Type\"	 ");
							responseJson.append(" 	 }	 ");
						}

					}
					else
					{
						logger.info("Failure due to the invalid request.");

						responseJson.append("    {	 ");
						responseJson.append("    \"status\": \"103\",	 ");
						responseJson.append("    \"statusDesc\": \"Failure\",	 ");
						responseJson.append(" 	 \"message\": \"Invalid request\"	 ");
						responseJson.append(" 	 }	 ");
					}

				}	
				else
				{
					logger.info("Failure due to the invalid request.");

					responseJson.append("    {	 ");
					responseJson.append("    \"status\": \"103\",	 ");
					responseJson.append("    \"statusDesc\": \"Failure\",	 ");
					responseJson.append(" 	 \"message\": \"Invalid request\"	 ");
					responseJson.append(" 	 }	 ");
				}
			}
			else
			{
				logger.info("Failure due to the some internal error.");
				responseJson.append("    {	 ");
				responseJson.append("    \"status\": \"105\",	 ");
				responseJson.append("    \"statusDesc\": \"Failure\",	 ");
				responseJson.append(" 	 \"message\": \"Request JSON is Null/ Invalid\"	 ");
				responseJson.append(" 	 }	 ");
			}
			responseJson.append(" 	 }  ]  }  }  }");
		}
		catch(Exception e)
		{
			responseJson.append(" { \"status\": \"500\", \"statusDesc\":\"Failure\", \"message\":\"Error while designing Reponse String\",\"leadId\":\""+leadId+"\" } ");
			logger.error("Error while designing Response String:-"+e,new Throwable());
		}
		logger.info("ReponseString : "+responseJson.toString());
		logger.info("Going outside "+methodName+"().");
		return responseJson.toString();

	}
	private String getDocTypeName(int docId)
	{
		String docName="";
		//Document Type  (AADHAR-01, CREDIT BUREAU-02, PERFIOS-03, TPA-04, Illustration-05, Dob-06,Address-07,
		//Income-08,Photo-09,Bank Statement-10, Income Proof-11, Passport-12, Medical TPA-13, PAN Card-14, Voter ID Card-15, Driving Licence -16
		switch(docId)
		{
		case 1:
			docName="AADHAR";
			break;
		case 2:
			docName="CREDIT BUREAU";
			break;
		case 3:
			docName="PERFIOS";
			break;
		case 4:
			docName="TPA";
			break;
		case 5:
			docName="Illustration";
			break;
		case 6:
			docName="Dob";
			break;
		case 7:
			docName="Address";
			break;
		case 8:
			docName="Income";
			break;
		case 9:
			docName="Photo";
			break;
		case 10:
			docName="Bank Statement";
			break;
		case 11:
			docName="Income Proof";
			break;
		case 12:
			docName="Passport";
			break;
		case 13:
			docName="Medical TPA";
			break;
		case 14:
			docName="PAN Card";
			break;
		case 15:
			docName="Voter ID Card";
			break;
		case 16:
			docName="Driving Licence";
			break;
		case 17:
			docName="Election Commission ID Card";
			break;
		case 18:
			docName="Bank Statement";
			break;
		case 19:
			docName="Telephone_Mobile Bill";
			break;
		case 20:
			docName="Electricity Bill";
			break;
		case 21:
			docName="ESI ID Card";
			break;
		case 22:
			docName="Ex service Man Card";
			break;
		case 23:
			docName="Gas Bill";
			break;
		case 24:
			docName="Lease Agreement  with Rent Receipt";
			break;
		case 25:
			docName="Post Office Savings Account Statement";
			break;
		case 26:
			docName="Ration Card";
			break;
		case 27:
			docName="Senior Citizen Membership Card";
			break;
		case 28:
			docName="Income Tax Return";
			break;
		case 29:
			docName="Salary Slips";
			break;
		case 30:
			docName="Bank Statement";
			break;
		case 31:
			docName="Appointment letter";
			break;
		case 32:
			docName="Audited P&L Acc and Bal Sheets";
			break;
		case 33:
			docName="Computation of Income";
			break;
		case 34:
			docName="Form 16 A";
			break;
		case 35:
			docName="Form 16";
			break;
		case 36:
			docName="School Leaving Certificate or College ID Card";
			break;
		case 37:
			docName="Copy of Credit Card";
			break;
		case 38:
			docName="Credit Card Statement";
			break;
		case 39:
			docName="CreditCard Mandate";
			break;
		case 40:
			docName="Customer Letters";
			break;
		case 41:
			docName="CV of Key Person";
			break;
		case 42:
			docName="Deed of Variation";
			break;
		case 43:
			docName="Diabetes Questionnaire";
			break;
		case 44:
			docName="DigestiveDisorder Questionnaire";
			break;
		case 45:
			docName="DirectDebit Mandate";
			break;
		case 46:
			docName="Diving Questionnaire";
			break;
		case 47:
			docName="Epilepsy Questionnaire";
			break;
		case 48:
			docName="F2F Report";
			break;
		case 49:
			docName="Gynaecological Disorder questionnaire";
			break;
		case 50:
			docName="Housewife Questionnaire";
			break;
		case 51:
			docName="HUF Addennum";
			break;
		case 52:
			docName="Hypertension Questionnaire";
			break;
		case 53:
			docName="Juvenile Questionnaire";
			break;
		case 54:
			docName="Kidney Urinary Disorder Questionnaire";
			break;
		case 55:
			docName="Managing Partner Report";
			break;
		case 56:
			docName="Medical Documents";
			break;
		case 57:
			docName="MedicalRequisiton Form";
			break;
		case 58:
			docName="Merchant Navy Questionnaire";
			break;
		case 59:
			docName="Mining Questionnaire";
			break;
		case 60:
			docName="Miscellaneous Questionnaire";
			break;
		case 61:
			docName="MOA";
			break;
		case 62:
			docName="Mountaineering Questionnaire";
			break;
		case 63:
			docName="Musculoskeletal Questionnaire";
			break;
		case 64:
			docName="MWPA Addennum";
			break;
		case 65:
			docName="Name Change Declaration";
			break;
		case 66:
			docName="Nervous Disorder questionnaire";
			break;
		case 67:
			docName="NRI Questionnaire";
			break;
		case 68:
			docName="Oil and Gas Questionnaire";
			break;
		case 69:
			docName="Others";
			break;
		case 70:
			docName="Parachuting Questionnaire";
			break;
		case 71:
			docName="Partnership Deed";
			break;
		case 72:
			docName="Partnership Questionnaire";
			break;
		case 73:
			docName="Proposal Form";
			break;
		case 74:
			docName="Respiratory Questionnaire";
			break;
		case 75:
			docName="Sales Manager Report";
			break;
		case 76:
			docName="TeleCalling";
			break;
		case 77:
			docName="Tubercolosis Questionnaire";
			break;
		case 78:
			docName="Tumor Questionnaire";
			break;
		case 79:
			docName="Vernacular Declaration";
			break;
		case 80:
			docName="Add docs Employer Employee cases";
			break;
		case 81:
			docName="Adoption Related Documents";
			break;
		case 82:
			docName="Affidavits";
			break;
		case 83:
			docName="Armed Forces Questionnaire";
			break;
		case 84:
			docName="Aviation Questionnaire";
			break;
		case 85:
			docName="Board Resolution";
			break;
		case 86:
			docName="Chest Pain Questionnaire";
			break;
		case 87:
			docName="CO Acceptance";
			break;
		case 88:
			docName="Combo addendum";
			break;
		case 89:
			docName="Company Annual Report";
			break;
		case 90:
			docName="Pan Acknowledgement 1";
			break;
		case 91:
			docName="Premium Receipt";
			break;
		case 92:
			docName="Counter Offer Acceptance";
			break;
		case 93:
			docName="MER";
			break;
		case 94:
			docName="Blood_Urine Test";
			break;
		case 95:
			docName="ECG_TMT";
			break;
		case 96:
			docName="CXR";
			break;
		case 97:
			docName="Additional test";
			break;
		case 98:
			docName="Finacle Print Out";
			break;
		case 99:
			docName="Counter offer rescan";
			break;
		case 100:
			docName="Direct Debit Mandate";
			break;
		case 101:
			docName="DOBProof";
			break;	
		case 102:
			docName="Investor Risk profile";
			break;
		case 103:
			docName="KYC Company Documents";
			break;
		case 104:
			docName="Medical report rescan";
			break;
		case 105:
			docName="NB 10";
			break;
		case 106:
			docName="NB 10A";
			break;
		case 107:
			docName="NB 11";
			break;
		case 108:
			docName="NB09C";
			break;
		case 109:
			docName="NPW 04";
			break;
		case 110:
			docName="NPW 05";
			break;
		case 111:
			docName="NPW4A";
			break;
		case 112:
			docName="NPW5A";
			break;
		case 113:
			docName="PAN document";
			break;
		case 114:
			docName="PEP Questionnaire";
			break;
		case 115:
			docName="Private Tution Questionnaire";
			break;
		case 116:
			docName="Proposal form rescan";
			break;
		case 117:
			docName="Proposal Form_Page1";
			break;
		case 118:
			docName="Proposal Form_Page2";
			break;
		case 119:
			docName="Proposal Form_Page3";
			break;
		case 120:
			docName="Proposal Form_Page4";
			break;
		case 121:
			docName="Proposal Form_Page5";
			break;
		case 122:
			docName="Proposal Form_Page6";
			break;
		case 123:
			docName="Proposal Form_Page7";
			break;
		case 124:
			docName="Regular Income Proofs";
			break;
		case 125:
			docName="Rescan others";
			break;
		case 126:
			docName="UW 01";
			break;
		case 127:
			docName="UW 02";
			break;
		case 128:
			docName="Additional medical test";
			break;
		case 129:
			docName="Blood Urine test";
			break;
		case 130:
			docName="Cancelled Cheque";
			break;
		case 131:
			docName="Car Insurance Papers";
			break;
		case 132:
			docName="ECG TMT";
			break;
		case 133:
			docName="IT Return";
			break;
		case 134:
			docName="Medical Reports";
			break;
		case 135:
			docName="Salary Slip";
			break;
		case 136:
			docName="UW 04";
			break;
		case 137:
			docName="Company Profit Loss Account";
			break;
		case 138:
			docName="Spouse Rider Questionnaire";
			break;
		case 139:
			docName="Underwriting Worksheet";
			break;
		case 140:
			docName="Proposal Form_Page8";
			break;
		case 141:
			docName="Copy of Bank Book Statement";
			break;
		case 142:
			docName="Marriage Card";
			break;
		case 143:
			docName="Payor Rider Questionnaire";
			break;
		case 144:
			docName="Policy Pack Acknowledgement";
			break;
		case 145:
			docName="Relationship Proof";
			break;
		case 146:
			docName="Company AML Documents";
			break;
		case 147:
			docName="Key Person A and B Questionnaire";
			break;
		case 148:
			docName="AML Document";
			break;
		case 149:
			docName="Customer Letter";
			break;
		case 150:
			docName="Fact Finder";
			break;
		case 151:
			docName="Policy Reissue Letter";
			break;
		case 152:
			docName="Financial and Company Documents";
			break;
		case 153:
			docName="Financial Documents";
			break;
		case 154:
			docName="Max Life communication";
			break;
		case 155:
			docName="Reinsurance Decision";
			break;
		case 156:
			docName="Welcome Calling Sheet";
			break;
		case 157:
			docName="Email Communication";
			break;
		case 158:
			docName="Payment Acknowledgement";
			break;
		case 159:
			docName="Communication Address Proof";
			break;
		case 160:
			docName="ID Proof";
			break;
		case 161:
			docName="Permanent Address Proof";
			break;
		case 162:
			docName="BI Document";
			break;
		case 163:
			docName="Signed ECS Form";
			break;
		case 164:
			docName="PayorPhoto";
			break;
		case 165:
			docName="PayorPAN";
			break;
		default :
			docName="Invalid";
		}
		return docName;
	}

	@Override
	//@Cacheable(value="maxserviceCache", key="#requestJson")
	public String processPlanDetailsRequest(Map requestData, String requestJson) 
	{
		boolean cacheFlag=true;
		String methodName=null;
		methodName=Commons.getMethodName();
		logger.info("Came inside "+methodName+"().");
		String planid="";
		String rtbl_sex="";
		String rtbl_age_dur="";
		String Key1="";
		String ValidationType="";
		boolean X = false;
		StringBuilder responseJson = new StringBuilder();
		try
		{
			if(requestData!=null)
			{
				planid=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("PLAN_ID")).toString().toUpperCase();
				rtbl_sex=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("RTBL_SEX_CD")).toString().toUpperCase();
				rtbl_age_dur=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("RTBL_AGE_DUR")).toString().toUpperCase().trim();
				ValidationType=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("ValidationType")).toString();
				Key1=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("Key1")).toString();
				logger.info("planid is : "+planid+" and ValidationType is : " + ValidationType);

				String reponseString=requestJson.replaceAll("Request","Response");
				responseJson.append(reponseString.substring(0,reponseString.indexOf("TransTrackingID")-1));
				responseJson.append("\"TransTrackingID\":\"\",\"TransactionData\": ");

				if(planid!=null && !planid.equalsIgnoreCase("")
						&& rtbl_sex!=null && !rtbl_sex.equalsIgnoreCase("")
						&& rtbl_age_dur!=null && !rtbl_age_dur.equalsIgnoreCase("")
						)
				{
					logger.info("rtbl_age_dur :: "+rtbl_age_dur);
					rtbl_age_dur = ""+Integer.parseInt(rtbl_age_dur);

					if(ValidationType!=null && ValidationType.equalsIgnoreCase("PlanDetails"))
					{

							List<PlanDetailBean> planDetailBeanList = null;
							try 
							{
								logger.info("EHCache enabled Method Call : Start");
//								planDetailBeanList = neoDao.callPlanDetail(planid, rtbl_age_dur, rtbl_sex);
								planDetailBeanList = planDetailService.callPlanDetailService(planid, rtbl_age_dur, rtbl_sex);
								logger.info("EHCache enabled Method Call : End");
							} catch (Exception e) {
								logger.error("We are in Exception from EHCache enabled method : "+e);
							}
							if(planDetailBeanList==null)
							{
								//We got this when Exception occured in DB
								responseJson.append("    {	 ");
								responseJson.append("    \"status\": \"102\",	 ");
								responseJson.append("    \"statusDesc\": \"Error in database connection.\",	 ");
								responseJson.append(" 	 \"message\": \"No Data Found\",	 ");
								responseJson.append("    \"planDetails\": ["); 
								responseJson.append("    {	 ");
								responseJson.append(" 	 }]	 ");
								responseJson.append(" 	 }	 ");
							}
							else if(planDetailBeanList!=null && planDetailBeanList.size()>=1)
							{
								responseJson.append("    {	 ");
								responseJson.append("    \"status\": \"200\",	 ");
								responseJson.append("    \"statusDesc\": \"Success\",	 ");
								responseJson.append(" 	 \"message\": \"Response Successfully Generated\",	 ");
								responseJson.append("    \"planDetails\": [     "); 

								for(PlanDetailBean bean : planDetailBeanList)
								{

									responseJson.append("    {	 ");		
									responseJson.append("    \"PLAN_ID\":\"").append(bean.getPLAN_ID()).append("\",");//PLAN_ID
									responseJson.append("    \"RH_ID\":\"").append(bean.getRH_ID()).append("\",");//RH_ID
									responseJson.append("    \"RTBL_ID\":\"").append(bean.getRTBL_ID()).append("\",");//RTBL_ID
									responseJson.append("    \"RH_BAND_AMT\":\"").append(bean.getRH_BAND_AMT()).append("\",");//RH_BAND_AMT
									responseJson.append("    \"RTBL_SEX_CD\":\"").append(bean.getRTBL_SEX_CD()).append("\",");//RTBL_SEX_CD
									responseJson.append("    \"RTBL_STBL_CD1\":\"").append(bean.getDISCOUNT_OPTION()).append("\",");//DISCOUNT_OPTION
									responseJson.append("    \"RTBL_STBL_CD2\":\"").append(bean.getSMOKER_CODE()).append("\",");//SMOKER_CODE
									responseJson.append("    \"RTBL_MAT_XPRY_DUR\":\"").append(bean.getRTBL_MAT_XPRY_DUR()).append("\",");//RTBL_MAT_XPRY_DUR
									responseJson.append("    \"RTBL_AGE_DUR\":\"").append(bean.getISSUE_AGE()).append("\",");//ISSUE_AGE
									//RTBL_AGE - new Column
									responseJson.append("    \"RTBL_1_RT\":\"").append(bean.getRTBL_1_RT()).append("\",");//RTBL_1_RT
									responseJson.append("    \"RTBL_2_RT\":\"\",");
									responseJson.append("    \"RTBL_3_RT\":\"\",");
									responseJson.append("    \"RTBL_4_RT\":\"\",");
									responseJson.append("    \"RTBL_5_RT\":\"\",");
									responseJson.append("    \"RTBL_6_RT\":\"\",");
									responseJson.append("    \"RTBL_7_RT\":\"\",");
									responseJson.append("    \"RTBL_8_RT\":\"").append(bean.getRTBL_AGE()).append("\",");//RTBL_AGE
									responseJson.append("    \"RTBL_AGE\":\"").append(bean.getRTBL_AGE()).append("\"");//RTBL_AGE
									responseJson.append(" 	 }   ,");
								}
								responseJson.setLength(responseJson.length()-1);
								responseJson.append(" 	]	 }	 ");
							}
							else
							{
								responseJson.append("    {	 ");
								responseJson.append("    \"status\": \"200\",	 ");
								responseJson.append("    \"statusDesc\": \"Success\",	 ");
								responseJson.append(" 	 \"message\": \"No Data Found\",	 ");
								responseJson.append("    \"planDetails\": ["); 
								responseJson.append("    {	 ");
								responseJson.append(" 	 }]	 ");
								responseJson.append(" 	 }	 ");
							}
						//}
					}
					else
					{
						responseJson.append("    {	 ");
						responseJson.append("    \"status\": \"103\",	 ");
						responseJson.append("    \"statusDesc\": \"Invalid Request\",	 ");
						responseJson.append(" 	 \"message\": \"Request Validation Invalid\",	 ");
						responseJson.append("    \"planDetails\": ["); 
						responseJson.append("    {	 ");
						responseJson.append(" 	 }]	 ");
						responseJson.append(" 	 }	 ");
						logger.info("Blank or Null Value in Request Validation Parameter");
						cacheFlag=false;
					}
				}	
				else
				{
					responseJson.append("    {	 ");
					responseJson.append("    \"status\": \"103\",	 ");
					responseJson.append("    \"statusDesc\": \"Invalid Request\",	 ");
					responseJson.append(" 	 \"message\": \"Mandatory Parameter Validation Invalid\",	 ");
					responseJson.append("    \"planDetails\": ["); 
					responseJson.append("    {	 ");
					responseJson.append(" 	 }]	 ");
					responseJson.append(" 	 }	 ");
					logger.info("Blank or Null Value in Mandatory Parameter");
					cacheFlag=false;
				}
			}
			else
			{
				responseJson.append("    {	 ");
				responseJson.append("    \"status\": \"105\",	 ");
				responseJson.append("    \"statusDesc\": \"Request JSON is Null/ Invalid\",	 ");
				responseJson.append(" 	 \"message\": \"Request JSON is Null/ Invalid\",	 ");
				responseJson.append("    \"planDetails\": ["); 
				responseJson.append("    {	 ");
				responseJson.append(" 	 }]	 ");
				responseJson.append(" 	 }	 ");
				logger.info("Request JSON is Null/ Invalid");
				cacheFlag=false;
			}
			responseJson.append(" 	 }  ]  }  }  }");
		}
		catch(Exception e)
		{
			responseJson.append(" { \"status\": \"500\", \"statusDesc\":\"Failure\", \"message\":\"Error while designing Reponse String\",\"planid\":\""+planid+"\" } ");
			logger.error("Error while designing Reponse String:-"+e);
			cacheFlag=false;
		}
		logger.info("Going outside "+methodName+"().");
		
		return responseJson.toString();
	}
	
	@Override
	public String processExistingCustomerRequest(Map requestData, String requestJson) 
	{

		int i=0;
		String reponseString="";
		String methodName=null;
		methodName=Commons.getMethodName();
		logger.info("Came inside "+methodName+"().");
		String panNumber="";
		String dob="";
		String mobileNumber="";
		String gender="";
		String Key1="";
		String ValidationType="";
		boolean X = false;
		StringBuilder responseJson = new StringBuilder();

		try
		{
			if(requestData!=null)
			{
				panNumber=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("panNumber")).toString().toUpperCase();
				dob=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("dob")).toString().toUpperCase();
				mobileNumber=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mobileNumber")).toString().toUpperCase();
				gender=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("gender")).toString().toUpperCase();
				ValidationType=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("ValidationType")).toString();
				Key1=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("Key1")).toString();
				logger.info("panNumber is : "+panNumber+" and ValidationType is : " + ValidationType);


				if(ValidationType!=null && ValidationType.equalsIgnoreCase("PanToClient"))
				{
					responseJson.append(" 	{	 ");
					responseJson.append(" 	    \"Response\": {	 ");
					responseJson.append(" 	        \"ResponseInfo\": {	 ");
					responseJson.append(" 	            \"UserName\": \"\",	 ");
					responseJson.append(" 	            \"CreationDate\": \"\",	 ");
					responseJson.append(" 	            \"CreationTime\": \"\",	 ");
					responseJson.append(" 	            \"SourceInfoName\": \"\",	 ");
					responseJson.append(" 	            \"RequestorToken\": \"\",	 ");
					responseJson.append(" 	            \"UserEmail\": \"\",	 ");
					responseJson.append(" 	            \"LastSyncDateTime\": \"\"	 ");
					responseJson.append(" 	        },	 ");
					responseJson.append(" 	        \"ResponsePayload\": {	 ");
					responseJson.append(" 	            \"Transactions\": [	 ");
					responseJson.append(" 	                {	 ");
					responseJson.append(" 	                    \"Key1\": \"").append(Key1).append("\",	 ");
					responseJson.append(" 	                    \"Key2\": \"\",	 ");
					responseJson.append(" 	                    \"Key3\": \"\",	 ");
					responseJson.append(" 	                    \"Key4\": \"\",	 ");
					responseJson.append(" 	                    \"Key5\": \"\",	 ");
					responseJson.append(" 	                    \"ValidationType\": \"PanToClient\",	 ");
					responseJson.append(" 	                    \"TransTrackingID\": \"\",	 ");
					responseJson.append(" 	                    \"TransactionData\": 	 ");

					StringBuilder psmSelectScript = new StringBuilder();
					List<List<String>> psmSelectList = null;

					boolean policy=false;
					boolean mobile=false;
					boolean pan=false;

					if(!Key1.equalsIgnoreCase("") && !Key1.equals(null)
							&& !dob.equalsIgnoreCase("") && !dob.equals(null))
					{

						X =true;
						policy=true;
						psmSelectScript.append(" SELECT A.CLI_ID FROM TPOLC A , TCLI B ");
						psmSelectScript.append(" WHERE A.CLI_ID = B.CLI_ID ");
						psmSelectScript.append(" AND A.POL_ID = '"+Key1.trim()+"' ");
						psmSelectScript.append(" AND A.POL_CLI_REL_TYP_CD = 'O' ");
						psmSelectScript.append(" AND B.CLI_BTH_DT = to_date(?,'DD-MON-RR') ");

						String []psmSelectParam = new String[1];
						//psmSelectParam[0]=Key1.trim();
						psmSelectParam[0]=dob.trim();
						psmSelectList = neoDao.callExistingCustomer(psmSelectScript.toString(), psmSelectParam);
					}

					else if(!mobileNumber.equalsIgnoreCase("")&& !mobileNumber.equals(null) 
							&& !gender.equalsIgnoreCase("")	&& !gender.equals(null)
							&& !dob.equalsIgnoreCase("") && !dob.equals(null))
					{
						X = true; // needs to be true
						mobile=true;
//						psmSelectScript.append(" select CLI_ID from  ");
//						psmSelectScript.append(" (SELECT a.cli_id CLIENTID ");
//						psmSelectScript.append("  FROM tclic a, tcvgc b  ");
//						psmSelectScript.append("  WHERE a.co_id = 'CP'   AND a.cli_cntct_id_cd = 'M'  ");
//						//psmSelectScript.append("  AND a.cli_cntct_id_txt = '"+mobileNumber.trim()+"' ");
//						psmSelectScript.append("  AND contains(a.cli_cntct_id_txt,?)>0 ");
//						psmSelectScript.append("  AND b.cvg_num = '01'   AND a.cli_id = b.insrd_cli_id ) a, TCLI b ");
//						psmSelectScript.append(" where a.CLIENTID = b.CLI_ID ");
//						psmSelectScript.append(" and b.cli_sex_cd = ? ");
//						psmSelectScript.append(" and b.CLI_BTH_DT = to_date(?,'DD-MON-RR') AND ROWNUM = 1 ");//'05-Mar-1966'

						psmSelectScript.append("select CLI_ID from ");
						psmSelectScript.append("( SELECT /*+use_nl(p,b)*/ p.CLIENTID CLIENTID ");
						psmSelectScript.append(" FROM ( SELECT a.cli_id CLIENTID , a.co_id COID ");
						psmSelectScript.append(" FROM tclic a WHERE contains(a.cli_cntct_id_txt, ?)>0");
						psmSelectScript.append(" AND a.cli_cntct_id_cd = 'M') p, tcvgc b"); 
						psmSelectScript.append(" WHERE b.cvg_num = '01' AND p.COID = 'CP'");
						psmSelectScript.append(" AND p.CLIENTID = b.insrd_cli_id ) a, TCLI b"); 
						psmSelectScript.append(" Where a.CLIENTID = b.CLI_ID"); 
						psmSelectScript.append(" AND b.cli_sex_cd = ? "); 
						psmSelectScript.append(" AND b.CLI_BTH_DT = to_date(?,'DD-MON-RR') AND ROWNUM = 1");
				
						String []psmSelectParam = new String[3];
						psmSelectParam[0]=mobileNumber.trim();
						psmSelectParam[1]=gender.trim();
						psmSelectParam[2]=dob.trim();

						psmSelectList = neoDao.callExistingCustomer(psmSelectScript.toString(), psmSelectParam);
					}
					else if(!dob.equalsIgnoreCase("") && !dob.equals(null)
							&& !panNumber.equalsIgnoreCase("") && !panNumber.equals(null))
					{
						X =true;
						pan=true;
						psmSelectScript.append(" SELECT CLI_ID FROM TCLI A");
						psmSelectScript.append(" WHERE PAN_CARD_ID= ?  and  CLI_BTH_DT = to_date(?,'DD-MON-RR')");//'05-Mar-1966'

						String []psmSelectParam = new String[2];
						psmSelectParam[0]=panNumber.trim();
						psmSelectParam[1]=dob.trim();
						psmSelectList = neoDao.callExistingCustomer(psmSelectScript.toString(), psmSelectParam);
					}

					if(X)
					{
						if(psmSelectList!=null && psmSelectList.size()>1)
						{
							responseJson.append("    {	 ");
							responseJson.append("    \"status\": \"200\",	 ");
							responseJson.append("    \"statusDesc\": \"Success\",	 ");
							responseJson.append(" 	 \"message\": \"Response Successfully Generated\",	 ");
							responseJson.append(" 	 \"panNumber\": \"").append(panNumber.trim()).append("\",	 ");
							responseJson.append(" 	 \"mobileNumber\": \"").append(mobileNumber.trim()).append("\",	 ");
							responseJson.append(" 	 \"gender\": \"").append(gender.trim()).append("\",	 ");
							responseJson.append(" 	 \"dob\": \"").append(dob.trim()).append("\",	 ");
							responseJson.append("    \"clientID\": \"").append(psmSelectList.get(1).get(0).trim()).append("\"	 ");
							responseJson.append(" 	 }	 ");
						}
						else
						{
							responseJson.append("    {	 ");
							responseJson.append("    \"status\": \"101\",	 ");
							responseJson.append("    \"statusDesc\": \"Failure\",	 ");
							if(policy)
							{
								responseJson.append(" 	 \"message\": \"Entered Policy number does not exist in our records. Please enter correct policy no.\",	 ");
							}
							else if(mobile)
							{
								responseJson.append(" 	 \"message\": \"Entered Mobile number does not exist in our records. Please enter correct mobile no.\",	 ");
							}
							else if(pan)
							{
								responseJson.append(" 	 \"message\": \"Entered PAN number does not exist in our records. Please enter correct pan no.\",	 ");
							}
							else
							{
								responseJson.append(" 	 \"message\": \"Data not exist in DB\",	 ");
							}
							responseJson.append(" 	 \"panNumber\": \"").append(panNumber).append("\",	 ");
							responseJson.append(" 	 \"mobileNumber\": \"").append(mobileNumber).append("\",	 ");
							responseJson.append(" 	 \"gender\": \"").append(gender).append("\",	 ");
							responseJson.append(" 	 \"dob\": \"").append(dob).append("\",	 ");
							responseJson.append("    \"clientID\": \"").append("").append("\"	 ");
							responseJson.append(" 	 }	 ");
						}
					}
					else
					{
						responseJson.append("    {	 ");
						responseJson.append("    \"status\": \"103\",	 ");
						responseJson.append("    \"statusDesc\": \"Failure\",	 ");
						responseJson.append(" 	 \"message\": \"Invalid Request Json\",	 ");
						responseJson.append(" 	 \"panNumber\": \"").append(panNumber).append("\",	 ");
						responseJson.append(" 	 \"mobileNumber\": \"").append(mobileNumber).append("\",	 ");
						responseJson.append(" 	 \"gender\": \"").append(gender).append("\",	 ");
						responseJson.append(" 	 \"dob\": \"").append(dob).append("\",	 ");
						responseJson.append("    \"clientID\": \"").append("").append("\"	 ");
						responseJson.append(" 	 }	 ");
						logger.info(" Invalid request Json as contain null or blank in mandatory parameter");
					}
					responseJson.append(" 	 }  ]  }  }  }");
				}
				else
				{
					reponseString="{\"status\":\"103\",\"statusDesc\":\"Failure\", \"message\":\"Mendatory Validation fail\" }";
					logger.info("Pan in request Json is Null or blank");
				}
			}
			else
			{
				//Invalid Request Json
				reponseString = " { \"status\": \"105\", \"statusDesc\":\"Failure\", \"message\":\"Request Json is Invalid\", \"panNumber\":\""+panNumber+"\" } ";
				logger.info("Request Json is Invalid");
			}
		}
		catch(Exception e)
		{
			reponseString = " { \"status\": \"500\", \"statusDesc\":\"Failure\", \"message\":\"Error while designing Reponse String\",\"panNumber\":\""+panNumber+"\" } ";
			logger.error("Error while designing Reponse String:-"+e,new Throwable());
		}
		responseJson.append(reponseString);
		logger.info("ReponseString : "+responseJson.toString());
		logger.info("Going outside "+methodName+"().");
		return responseJson.toString();
	}
	
	@Override
	public String getPolicyService(String key) throws Exception
	{
		logger.info("getPolicyService : calling static synchronized method");
		return PolicyGenerationUtility.getPolicyServiceData(key);
	}
	
	@Override
	public String getIFSCService(String key) throws Exception
	{
		logger.info("getIFSCService : calling");
		return new IfscMicrUtility().getIFSCServiceData(key);
	}
}
