package com.qc.serviceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.equifax.services.eport.servicedefs._1_0.EquifaxApiResponseDTO;
import com.qc.service.ExternalServices;
import com.qc.utils.Commons;
import com.qc.utils.EquifaxResponseValidator_v2;
import com.qc.utils.GetXMLValues;
import com.qc.utils.MultiFormatDate;
import com.qc.utils.XTrustProvider;

@Service//("equifaxServiceHelper")
public class EquifaxServiceHelper implements ExternalServices{

	private static Logger logger = LogManager.getLogger(EquifaxServiceHelper.class);
	
	@Override
	public Map<String, String> callService(Map<String, Object> requestParams,Environment env) {
		//not in use (credit beureo 1.0)
		return null;
	}

	@Override
	public Map<String, String> callNeoService(Map<String, Object> requestParams,Environment env) {
		logger.info("EQIFAX SERVICE HELPER :callNeoService: STARTED :: ");
		String methodName=null;
		Map requestData=null;
		methodName=Commons.getMethodName();
		EquifaxApiResponseDTO eqifaxDTO = new EquifaxApiResponseDTO();
		Map<String,String> response = new HashMap<String,String>();
		EquifaxResponseValidator_v2 equifaxResponseValidator_v2 = new EquifaxResponseValidator_v2();
		logger.info("Came inside "+methodName+"().");
		try
		{
			String fName=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("fname")).toString().trim();
			String mName=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mname")).toString().trim();
			String lName=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("lname")).toString().trim();
			String dob=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("dob")).toString().trim();
			String pan=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("pan")).toString().trim();
			String validationType = (((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("ValidationType")).toString().trim();
			String state = (((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("state")).toString().trim();
			String stateCode = (((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("stateCode")).toString().trim();
			String postal = (((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("postalCode")).toString().trim();
			String mobileno = (((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mobileno")).toString().trim();
			String email = (((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("email")).toString().trim();


			if(!fName.isEmpty() && !pan.isEmpty()&& !dob.isEmpty() )
			{
				String inputXml= getSTPRequestXML(fName,mName,lName,state,postal,dob,pan,email,mobileno,validationType,stateCode,env);
				logger.info("inputXml : "+inputXml);
				String output = getQueryData(inputXml,env);
				logger.info("output : "+output);
				if(output!=null || !"".equalsIgnoreCase(output))
				{
					String errorXml=null;
					String nameXml="";
					String identityInfoXml="";
					String credtScoreXml="";
					String contactDetailXml="";
					String addressInfoXml="";
					String mobileInfoXml="";

					String _errorCode = null;
					String _errorMsg = null;
					String _firstName = null;
					String _middleName = null;
					String _lastName = null;
					String _dob = null;
					String _gender = null;
					String _age = null;
					String _totalIncome = null;
					String _occupation = null;
					String _panNo = null;
					String _mobileNo = null;
					String _emailId = null;
					String _creditScore = null;
					String _address = null;
					String _state = null;
					String _postalCode = null;

					try{
						if(output.contains("<sch:ErrorMsg>")){
							errorXml = (output.substring(output.indexOf("<sch:ErrorMsg>"),output.lastIndexOf("</sch:ErrorMsg>")))+"</sch:ErrorMsg>";
							logger.info("errorXml : "+errorXml);
						}
						if(output.contains("<sch:PersonalInfo>"))
						{
							nameXml = (output.substring(output.indexOf("<sch:PersonalInfo>"),output.lastIndexOf("</sch:PersonalInfo>")))+"</sch:PersonalInfo>";
							logger.info("nameXml : "+nameXml);
						}
						if(output.contains("<sch:IdentityInfo>"))
						{
							identityInfoXml = (output.substring(output.indexOf("<sch:IdentityInfo>"),output.lastIndexOf("</sch:IdentityInfo>")))+"</sch:IdentityInfo>";
							logger.info("IdentityInfoXml : "+nameXml);
						}
						if(output.contains("<sch:Score>"))
						{
							credtScoreXml = (output.substring(output.indexOf("<sch:Score>"),output.lastIndexOf("</sch:Score>")))+"</sch:Score>";
							logger.info("creditScoreXml : "+nameXml);
						}

						if(output.contains("<sch:AddressInfo"))
						{
							addressInfoXml = (output.substring(output.indexOf("<sch:AddressInfo"),output.lastIndexOf("</sch:AddressInfo>")))+"</sch:AddressInfo>";
							logger.info("addressInfoXml : "+addressInfoXml);
						}

						if(output.contains("<sch:PhoneInfo"))
						{
							mobileInfoXml = (output.substring(output.indexOf("<sch:PhoneInfo"),output.lastIndexOf("</sch:PhoneInfo>")))+"</sch:PhoneInfo>";
							logger.info("mobileInfoXml : "+mobileInfoXml);
						}

						if(nameXml!=null && !nameXml.equals(""))
						{
							String subTag[] = new String[8];
							subTag[0]="sch:FirstName";
							subTag[1]="sch:MiddleName";
							subTag[2]="sch:LastName";
							subTag[3]="sch:DateOfBirth";
							subTag[4]="sch:Gender";
							subTag[5]="sch:Age";
							subTag[6]="sch:TotalIncome";
							subTag[7]="sch:Occupation";

							ArrayList<HashMap<String,String>> getXmlMapValue = new GetXMLValues().getListOfXmlValues(nameXml, "sch:PersonalInfo", subTag);
							logger.info("getXmlMapValue : Name Info : "+getXmlMapValue);
							logger.info("First Name : "+getXmlMapValue.iterator().next().get("sch:FirstName")+" :Middle Name : "+getXmlMapValue.iterator().next().get("sch:MiddleName") + " :Last Name : "+getXmlMapValue.iterator().next().get("sch:LastName")
									+" :DOB : "+getXmlMapValue.iterator().next().get("sch:DateOfBirth")+" : Gender : "+getXmlMapValue.iterator().next().get("sch:Gender")+" :Age : "+getXmlMapValue.iterator().next().get("sch:Age")
									+" :Total Income : "+getXmlMapValue.iterator().next().get("sch:TotalIncome")+" :Occupation : "+getXmlMapValue.iterator().next().get("sch:Occupation"));

							_firstName = getXmlMapValue.iterator().next().get("sch:FirstName");
							_middleName = getXmlMapValue.iterator().next().get("sch:MiddleName");
							_lastName = getXmlMapValue.iterator().next().get("sch:LastName");
							_dob = getXmlMapValue.iterator().next().get("sch:DateOfBirth");
							_gender = getXmlMapValue.iterator().next().get("sch:Gender");
							_age = getXmlMapValue.iterator().next().get("sch:Age");
							_totalIncome = getXmlMapValue.iterator().next().get("sch:TotalIncome");
						}

						if(identityInfoXml !=null && !identityInfoXml.equals(""))
						{
							String subTag[] = new String[1];
							subTag[0]="sch:IdNumber";

							ArrayList<HashMap<String,String>> getXmlMapValue = new GetXMLValues().getListOfXmlValues(identityInfoXml, "sch:IdentityInfo", subTag);
							logger.info("getXmlMapValue : Identity Info : "+getXmlMapValue);
							logger.info("Pan No : "+getXmlMapValue.iterator().next().get("sch:IdNumber") );

							_panNo = getXmlMapValue.iterator().next().get("sch:IdNumber");

						}

						if(credtScoreXml!=null && !credtScoreXml.equals(""))
						{
							String subTag[] = new String[1];
							subTag[0]="sch:Value";
							logger.info("credtScoreXml >> "+credtScoreXml);
							ArrayList<HashMap<String,String>> getXmlMapValue = new GetXMLValues().getListOfXmlValues(credtScoreXml, "sch:Score", subTag);
							logger.info("getXmlMapValue : Credit Socre : "+getXmlMapValue);
							logger.info("Credit Score : "+getXmlMapValue.iterator().next().get("sch:Value") );

							_creditScore = getXmlMapValue.iterator().next().get("sch:Value");

						}					

						if(addressInfoXml!=null && !addressInfoXml.equals(""))
						{
							String subTag[] = new String[3];
							subTag[0]="sch:Address";
							subTag[1]="sch:State";
							subTag[2]="sch:Postal";

							try{
								int startIndex = addressInfoXml.indexOf("<sch:Address>");
								int endIndex = addressInfoXml.indexOf("</sch:AddressInfo>");
								String str = addressInfoXml.substring(startIndex,endIndex);
								str = "<sch:AddressInfo> "+str+" </sch:AddressInfo>";
								logger.info("Cutting Address:: "+str);

								ArrayList<HashMap<String,String>> getXmlMapValue = new GetXMLValues().getListOfXmlValues(str, "sch:AddressInfo", subTag);
								logger.info("getXmlMapValue : Address Info : "+getXmlMapValue);
								logger.info("Address : "+getXmlMapValue.iterator().next().get("sch:Address") +" :State :"+getXmlMapValue.iterator().next().get("sch:State") + " : Postal Code :"+getXmlMapValue.iterator().next().get("sch:Postal"));

								_address = getXmlMapValue.iterator().next().get("sch:Address");
								_state = getXmlMapValue.iterator().next().get("sch:State");
								_postalCode = getXmlMapValue.iterator().next().get("sch:Postal");
							}catch (Exception e) {
								logger.error("Error in processing address : "+e);
							}
						}

						if(mobileInfoXml !=null && !mobileInfoXml.equals(""))
						{
							String subTag[] = new String[1];
							subTag[0]="sch:Number";

							try{
								int startIndex = mobileInfoXml.lastIndexOf("<sch:Number>");
								int endIndex = mobileInfoXml.lastIndexOf("</sch:Number>");
								String str = mobileInfoXml.substring(startIndex,endIndex);
								str =  "<sch:PhoneInfo>"+ str+"</sch:Number>  </sch:PhoneInfo>";;
								logger.info("Cutting Mobile No Section :: "+str);

								ArrayList<HashMap<String,String>> getXmlMapValue = new GetXMLValues().getListOfXmlValues(str, "sch:PhoneInfo", subTag);
								logger.info("getXmlMapValue : Address Info : "+getXmlMapValue);
								logger.info("Mobile No : "+getXmlMapValue.iterator().next().get("sch:Number") );
								_mobileNo = getXmlMapValue.iterator().next().get("sch:Number");

							}catch (Exception e) {
								logger.error("Error in processing mobile no : "+e);
							}
						}

						logger.info("Input Date :"+_dob);
						_dob = MultiFormatDate.getFormattedDate(_dob, "yyyy-MM-dd", "dd-MM-yyyy");
						logger.info("Output Date :"+_dob);

						eqifaxDTO.setAddress((_address == null)?"":_address);
						eqifaxDTO.setCredtScr((_creditScore == null)?"":_creditScore);
						eqifaxDTO.setDob((_dob == null)?"":_dob);
						eqifaxDTO.setEmailID((_emailId == null)?"":_emailId);
						eqifaxDTO.setEstmtdIncm((_totalIncome == null)?"":_totalIncome);
						eqifaxDTO.setMobile((_mobileNo == null)?"":_mobileNo);
						eqifaxDTO.setfName((_firstName == null)?"":_firstName);
						eqifaxDTO.setmName((_middleName == null)?"":_middleName);
						eqifaxDTO.setlName((_lastName == null)?"":_lastName);
						eqifaxDTO.setOccptnCls((_occupation == null)?"":_occupation);
						eqifaxDTO.setPan((_panNo == null)?"":_panNo);
						eqifaxDTO.setPinCode((_postalCode == null)?"":_postalCode);
						//eqifaxDTO.setPolicyNo();

						//validation and matching request data for equifax 
						response = equifaxResponseValidator_v2.matchAndValidateEquifaxData(eqifaxDTO,fName,mName,lName,pan,postal,state,validationType,dob,mobileno,email);
						logger.info("Response ::: "+response);
						logger.info("Equifax response after validation and matching : Reponse : "+response);

					}catch (Exception e) {
						logger.error("Exception while parsing equifax reponse data :");
						response = null;
					}
				}else{
					logger.error("Data not found for this request ::");
					response = null;
				}		
			}
		}
		catch(Exception e)
		{
			logger.error("Something went wrong while processing equifax data validation : "+e);
			response = null;
			return response;
		}
		return response;
	}

	public String getQueryData(String xmlInput,Environment env) 
	{
		String output = new String();
		String outputString = "";
		StringBuilder result = new StringBuilder();
		try 
		{
			
			String V2_URL=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.url");
			
			logger.info("CALL_EQUIFAX_SOAP_API_URL :: "+V2_URL);
			URL url = new URL(V2_URL);

			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();

			//below two proxy section :: used only in developement envirnoment
			//Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
			//HttpURLConnection  conn = (HttpURLConnection) url.openConnection(proxy);
			//comment while development
			HttpURLConnection conn = null;
			
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			
			
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");

			OutputStream os = conn.getOutputStream();
			os.write(xmlInput.getBytes());
			os.flush();
			try {os.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			logger.info("Equifax API Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200){
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				try {br.close(); } catch (Exception e1) {}
				conn.disconnect();
				logger.info("Server Response :: "+result);
			}
		}catch (MalformedURLException e) {
			logger.error("Error While Calling API ::",e);

		} catch (IOException e) {
			logger.error("Error While Calling API ::",e);

		}
		//logger.info("GetQueryData :: Ends :: TrackerId :: "+trackerId);*/
		return result.toString();
	}

	private String getSTPRequestXML(String F_NAME,String M_NAME,String L_NAME,String STATE,String POSTAL,String DOB,String PAN_ID,String EMAIL_ID,String MOBILE_NO,String VALIDATION_TYPE,String STATE_CODE,Environment env ) throws ParseException
	{
		logger.info("GetSTPRequestXML :: Start :: VALIDATION_TYPE :: "+VALIDATION_TYPE);
		String V2_CUSTOMERID=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.CustomerId");
		String V2_USERID=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.UserId");
		String V2_PASSWORD=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.Password");
		String V2_MEMBER_NUMBER=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.MemberNumber");
		String V2_SECURITY_CODE=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.SecurityCode");
		String V2_PRODUCT_VERSION=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.ProductVersion");
		
		if(VALIDATION_TYPE.equalsIgnoreCase("PANDOB")){
			VALIDATION_TYPE = "IDR";
		}else{
			VALIDATION_TYPE = "IDS";
		}
		if(STATE_CODE == null || STATE_CODE.isEmpty()){
			STATE_CODE = "DL";
		}
		StringBuilder input = new StringBuilder();
		input.append("	<soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ns='http://services.equifax.com/eport/ws/schemas/1.0'>	");
		input.append("	   <soapenv:Header/>	");
		input.append("	   <soapenv:Body>	");
		input.append("	      <ns:InquiryRequest>	");
		input.append("	         <ns:RequestHeader>	");
		input.append("	             <ns:CustomerId>"+V2_CUSTOMERID+"</ns:CustomerId>	");
		input.append("	            <ns:UserId>"+V2_USERID+"</ns:UserId>	");
		input.append("	            <ns:Password>"+V2_PASSWORD+"</ns:Password>	");
		input.append("	            <ns:MemberNumber>"+V2_MEMBER_NUMBER+"</ns:MemberNumber>	");
		input.append("	            <ns:SecurityCode>"+V2_SECURITY_CODE+"</ns:SecurityCode>	");
		input.append("	            <ns:ProductCode>"+VALIDATION_TYPE+"</ns:ProductCode>	");
		input.append("	            <ns:ProductVersion>"+V2_PRODUCT_VERSION+"</ns:ProductVersion>	");
		input.append("	            <ns:ReportFormat>XML</ns:ReportFormat>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:CustRefField></ns:CustRefField>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:CustomInquiryFlag>?</ns:CustomInquiryFlag>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:N3ConfigID>?</ns:N3ConfigID>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:CustomInquiryFlag1>?</ns:CustomInquiryFlag1>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:CustomInquiryFlag2>?</ns:CustomInquiryFlag2>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:CustomInquiryFlag3>?</ns:CustomInquiryFlag3>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:CustomInquiryFlag4>?</ns:CustomInquiryFlag4>	");
		input.append("	         </ns:RequestHeader>	");
		input.append("	         <!--Optional:-->	");
		input.append("	         <ns:RequestAccountDetails seq=''>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:AccountNumber>?</ns:AccountNumber>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:BranchIDMFI>?</ns:BranchIDMFI>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:KendraIDMFI>?</ns:KendraIDMFI>	");
		input.append("	         </ns:RequestAccountDetails>	");
		input.append("	         <!--Optional:-->	");
		input.append("	         <ns:InquiryCommonAccountDetails>	");
		input.append("	            <!--Zero or more repetitions:-->	");
		input.append("	            <ns:InquiryAccount seq=''>	");
		input.append("	               <!--Optional:-->	");
		input.append("	               <ns:AccountNumber>?</ns:AccountNumber>	");
		input.append("	               <!--Optional:-->	");
		input.append("	               <ns:BranchIDMFI>?</ns:BranchIDMFI>	");
		input.append("	               <!--Optional:-->	");
		input.append("	               <ns:KendraIDMFI>?</ns:KendraIDMFI>	");
		input.append("	            </ns:InquiryAccount>	");
		input.append("	         </ns:InquiryCommonAccountDetails>	");
		input.append("	         <ns:RequestBody>	");
		input.append("	            <ns:InquiryPurpose>00</ns:InquiryPurpose>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:TransactionAmount>?</ns:TransactionAmount>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:AdditionalSearchField>?</ns:AdditionalSearchField>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:FullName></ns:FullName>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:FirstName>"+F_NAME+"</ns:FirstName>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:MiddleName>"+M_NAME+"</ns:MiddleName>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:LastName>"+L_NAME+"</ns:LastName>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:FamilyDetails>	");
		input.append("	               <!--Zero or more repetitions:-->	");
		input.append("	               <ns:AdditionalNameInfo seq=''>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:AdditionalName>?</ns:AdditionalName>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:AdditionalNameType>?</ns:AdditionalNameType>	");
		input.append("	               </ns:AdditionalNameInfo>	");
		input.append("	               <!--Optional:-->	");
		input.append("	               <ns:NoOfDependents>?</ns:NoOfDependents>	");
		input.append("	            </ns:FamilyDetails>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:AdditionalId1>?</ns:AdditionalId1>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:AdditionalId2>?</ns:AdditionalId2>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:AddrLine1>?</ns:AddrLine1>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:Street>?</ns:Street>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:Locality1>?</ns:Locality1>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:Locality2>?</ns:Locality2>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:City>?</ns:City>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:State>"+STATE_CODE+"</ns:State>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:Postal>"+POSTAL+"</ns:Postal>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:InquiryAddresses>	");
		input.append("	               <!--Zero or more repetitions:-->	");
		input.append("	               <ns:InquiryAddress seq=''>	");
		input.append("	                  <ns:AddressLine>?</ns:AddressLine>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:Street>?</ns:Street>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:Locality1>?</ns:Locality1>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:Locality2>?</ns:Locality2>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:City>?</ns:City>	");
		input.append("	                  <ns:State>"+STATE_CODE+"</ns:State>	");
		input.append("	                  <ns:Postal>"+POSTAL+"</ns:Postal>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:AddressType>?</ns:AddressType>	");
		input.append("	               </ns:InquiryAddress>	");
		input.append("	            </ns:InquiryAddresses>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:InquiryPhones>	");
		input.append("	               <!--Zero or more repetitions:-->	");
		input.append("	               <ns:InquiryPhone seq=''>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:CountryCode>?</ns:CountryCode>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:AreaCode>?</ns:AreaCode>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:Number>?</ns:Number>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:PhoneNumberExtension>?</ns:PhoneNumberExtension>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:PhoneType>?</ns:PhoneType>	");
		input.append("	               </ns:InquiryPhone>	");
		input.append("	            </ns:InquiryPhones>	");
		input.append("	            <ns:DOB>"+MultiFormatDate.getFormattedDate(DOB, "dd-MM-yyyy", "yyyy-MM-dd")+"</ns:DOB>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:MaritalStatus>?</ns:MaritalStatus>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:Gender>?</ns:Gender>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:NationalIdCard>?</ns:NationalIdCard>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:RationCard>?</ns:RationCard>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:PANId>"+PAN_ID+"</ns:PANId>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:PassportId>?</ns:PassportId>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:VoterId>?</ns:VoterId>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:HomePhone seq='' ReportedDate=''>	");
		input.append("	               <ns:PhoneNumber>?</ns:PhoneNumber>	");
		input.append("	            </ns:HomePhone>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:MobilePhone>"+MOBILE_NO+"</ns:MobilePhone>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:DriverLicense>?</ns:DriverLicense>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:RequestAccountDetails seq=''>	");
		input.append("	               <!--Optional:-->	");
		input.append("	               <ns:AccountNumber>?</ns:AccountNumber>	");
		input.append("	               <!--Optional:-->	");
		input.append("	               <ns:BranchIDMFI>?</ns:BranchIDMFI>	");
		input.append("	               <!--Optional:-->	");
		input.append("	               <ns:KendraIDMFI>?</ns:KendraIDMFI>	");
		input.append("	            </ns:RequestAccountDetails>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:InquiryCommonAccountDetails>	");
		input.append("	               <!--Zero or more repetitions:-->	");
		input.append("	               <ns:InquiryAccount seq=\"?\">	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:AccountNumber>?</ns:AccountNumber>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:BranchIDMFI>?</ns:BranchIDMFI>	");
		input.append("	                  <!--Optional:-->	");
		input.append("	                  <ns:KendraIDMFI>?</ns:KendraIDMFI>	");
		input.append("	               </ns:InquiryAccount>	");
		input.append("	            </ns:InquiryCommonAccountDetails>	");
		input.append("	            <!--Optional:-->	");
		input.append("	            <ns:InquiryFieldsDsv>?</ns:InquiryFieldsDsv>	");
		input.append("	         </ns:RequestBody>	");
		input.append("	      </ns:InquiryRequest>	");
		input.append("	   </soapenv:Body>	");
		input.append("	</soapenv:Envelope>	");

		logger.info("Equifax Input XML :: "+input.toString());
		return input.toString();
	}

	public static void main (String args[])
	{
		StringBuilder input = new StringBuilder();
		input.append("	{	");
		input.append("	    \"Request\": {	");
		input.append("	        \"RequestInfo\": {	");
		input.append("	            \"UserName\": \"\",	");
		input.append("	            \"CreationDate\": \"\",	");
		input.append("	            \"CreationTime\": \"\",	");
		input.append("	            \"SourceInfoName\": \"\",	");
		input.append("	            \"RequestorToken\": \"\",	");
		input.append("	            \"UserEmail\": \"\",	");
		input.append("	            \"LastSyncDateTime\": \"\"	");
		input.append("	        },	");
		input.append("	        \"RequestPayload\": {	");
		input.append("	            \"Transactions\": [	");
		input.append("	                {	");
		input.append("	                    \"Key1\": \"\",	");
		input.append("	                    \"Key2\": \"\",	");
		input.append("	                    \"Key3\": \"\",	");
		input.append("	                    \"Key4\": \"\",	");
		input.append("	                    \"Key5\": \"\",	");
		input.append("	policyNo:\"111111111\",	");
		input.append("	                    \"fname\": \"RAKESH\",	");
		input.append("	                    \"mname\": \"\",	");
		input.append("	                    \"lname\": \"PAWA\",	");
		input.append("	                    \"dob\": \"01-02-1985\",	");
		input.append("	                    \"gender\": \"MALE\",	");
		input.append("	                    \"email\": \"r.pawa@yahoo.in\",	");
		input.append("	                    \"careOf\": \"\",	");
		input.append("	                    \"houseNo\": \"Delhi\",	");
		input.append("	                    \"street\": \"\",	");
		input.append("	                    \"landmark\": \"\",	");
		input.append("	                    \"location\": \"\",	");
		input.append("	                    \"postOffice\": \"\",	");
		input.append("	                    \"vill_city\": \"Delhi\",	");
		input.append("	                    \"subDistrict\": \"\",	");
		input.append("	                    \"district\": \"\",	");
		input.append("	                    \"state\": \"Delhi\",	");
		input.append("	                    \"stateCode\": \"DL\",	");
		input.append("	                    \"postalCode\": \"110045\",	");
		input.append("	                    \"mobileno\": \"9560248542\",	");
		input.append("	                    \"pan\": \"ASAPP0161H\",	");
		input.append("	                    \"app_name\": \"NEO\",	");
		input.append("	                    \"ValidationType\": \"ALL\",	");
		input.append("	                    \"TransTrackingID\": \"\"	");
		input.append("	                }	");
		input.append("	            ]	");
		input.append("	        }	");
		input.append("	    }	");
		input.append("	}	");

		EquifaxServiceHelper equifaxService1 = new EquifaxServiceHelper();
		Map requestData = Commons.getGsonData(input.toString()); 
		//equifaxService1.callNeoService(requestData,env);

	}


}
