package com.qc.serviceImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.Enumeration;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.net.ssl.HttpsURLConnection;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.util.PDFMergerUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.entity.PerfiosEntity;
import com.qc.utils.CommonPerfios;
import com.qc.utils.ConvertPDFToByteArray;
import com.qc.utils.XTrustProvider;

@Service
@PropertySource({ "classpath:application.properties" })
public class PerfiosServiceImpl implements com.qc.service.PerfiosService 
{
	private static Logger logger = LogManager.getLogger(PerfiosServiceImpl.class);

	private static final int BUFFER_SIZE = 4096;

	@Autowired
	Environment env;
	@Value("${com.perfios.merged.filelocation}")
	String perfiosMergedFileLocation;
	@Value("$(com.perfios.zipfile.downloadlocation)")
	String perfiosZipDownloadLocation;
	final long TIME_IN_MILLI_SEC = System.currentTimeMillis();


	@Override
	public PerfiosEntity getStartProcessData(PerfiosEntity perfiosEntity) 
	{
		try 
		{
			logger.info("Getting HTML Content Process : Start");
			String htmlContent = CommonPerfios.perfiosDataStartProcess(perfiosEntity,1);
			perfiosEntity.setStartProcessHtml(htmlContent);
			logger.info("Getting HTML Content Process : End : "+htmlContent);
		} 
		catch (Exception e) 
		{
			logger.error("We are in Exception : "+e);
		}
		return perfiosEntity;
	}

	@Override
	public PerfiosEntity getTransactionStatus(PerfiosEntity perfiosEntity) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Getting TransactionStatus Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosTransactionData(perfiosEntity);
			String pUrl = perfiosEntity.getTxnStatusUrl();
			logger.info("URL : "+pUrl);
			logger.info("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//				conn.setRequestProperty("Content-Type", "application/xml");
			//				OutputStream os = conn.getOutputStream();
			//				os.write(perfiosTransactionUrl.)
			//				os.flush();

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				perfiosEntity.setResponseXML(result.toString());
			}
		}
		catch (Exception e) 
		{
			logger.error("Error While Calling START_PERFIOS_SERVICE_REQUEST_ACTION ::",e);
		}
		return perfiosEntity;
	}

	@Override
	public PerfiosEntity getRetrieveReport(PerfiosEntity perfiosEntity) 
	{
		final long TIME_IN_MILLI_SEC = System.currentTimeMillis();
		String tempFileName = perfiosMergedFileLocation+"_"+TIME_IN_MILLI_SEC+".pdf";
		
		String output = new String();
		String mergedPdfByteArray = new String();
		StringBuilder result = new StringBuilder();
		ConvertPDFToByteArray convertPDFToByteArray = new ConvertPDFToByteArray();
		try 
		{
			logger.info("Getting RetrieveReport Process : Start");
			
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosDataRetrieveStatement(perfiosEntity);
			String pUrl = perfiosEntity.getRetriveUrl();
			logger.info("URL : "+pUrl);
			logger.info("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//				conn.setRequestProperty("Content-Type", "application/xml");
			//				OutputStream os = conn.getOutputStream();
			//				os.write(perfiosTransactionUrl.)
			//				os.flush();

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200)
			{
				String fileName = "";
				String disposition = conn.getHeaderField("Content-Disposition");
				String contentType = conn.getContentType();
				int contentLength = conn.getContentLength();
				if (disposition != null) {
					// extracts file name from header field
					int index = disposition.indexOf("filename=");
					if (index > 0) {
						fileName = disposition.substring(index + 9,disposition.length());
					}
				} 
				logger.info("Perfios zip File Name : " + fileName);
				// opens input stream from the HTTP connection
				InputStream inputStream = conn.getInputStream();
				String saveFilePath = perfiosZipDownloadLocation + fileName;
				logger.info("Perfios Zip File downloaded :: File Name :"+fileName+" :File Location : "+saveFilePath);
				// opens an output stream to save into file
				FileOutputStream outputStream = new FileOutputStream(saveFilePath);
				int bytesRead = -1;
				byte[] buffer = new byte[BUFFER_SIZE];
				while ((bytesRead = inputStream.read(buffer)) != -1)
				{
					outputStream.write(buffer, 0, bytesRead);
				}
				outputStream.close();
				inputStream.close();
				conn.disconnect();
				try
				{
					//Reading ZIP file 
					PDFMergerUtility ut = new PDFMergerUtility();
					@SuppressWarnings("resource")
					ZipFile zipFile1 = new ZipFile(saveFilePath);
					Enumeration<? extends ZipEntry> entries1 = zipFile1.entries();
					while(entries1.hasMoreElements())
					{
						ZipEntry entry = entries1.nextElement();
						InputStream stream = zipFile1.getInputStream(entry);
						ut.addSource(stream);
					}
					logger.info("perfiosMergedFileLocation :"+tempFileName);
					ut.setDestinationFileName(tempFileName);
					ut.mergeDocuments();
					mergedPdfByteArray = convertPDFToByteArray.pdfByteCaller(tempFileName);
					//setting in response xml
					perfiosEntity.setResponseXML("<response><status>Success</status><statusCode>200</statusCode><byteArray>"+mergedPdfByteArray+"</byteArray></response>");
					logger.info("PerfiosAPI MergedPdfByteArray :: "+mergedPdfByteArray); 
					
					try
					{
						File file = new File(saveFilePath);
						file.delete();
					}
					catch(Exception ex)
					{
						logger.error("Error while trying to delete ZIP file : "+ex);
					}
					
				}
				catch(COSVisitorException e)
				{
					logger.error("COSVisitorException"+e);
				}
				catch (IOException e) 
				{
					logger.error("IOException"+e);
				}
				catch (Exception e) 
				{
					logger.error("Exception"+e);
				}
			}
		}
		catch (Exception e) 
		{
			logger.error("Error While Calling RetrieveReport Perfios ::",e);
		}
		finally
		{
			try
			{
				//Code for deleting file
				File file = new File(tempFileName);
				file.delete();
			}
			catch (Exception e) 
			{
				logger.error("Error While Deleting Temp File ::",e);
			}
		}
		logger.info("Getting RetrieveReport Process : END");
		return perfiosEntity;
	}

	public byte[] compressByteArray(byte[] bytes){

		ByteArrayOutputStream baos = null;
		Deflater dfl = new Deflater();
		dfl.setLevel(Deflater.BEST_COMPRESSION);
		dfl.setInput(bytes);
		dfl.finish();
		baos = new ByteArrayOutputStream();
		byte[] tmp = new byte[4*1024];
		try{
			while(!dfl.finished()){
				int size = dfl.deflate(tmp);
				baos.write(tmp, 0, size);
			}
		} catch (Exception ex){

		} finally {
			try{
				if(baos != null) baos.close();
			} catch(Exception ex){}
		}

		return baos.toByteArray();
	}


	public byte[] decompressByteArray(byte[] bytes){

		ByteArrayOutputStream baos = null;
		Inflater iflr = new Inflater();
		iflr.setInput(bytes);
		baos = new ByteArrayOutputStream();
		byte[] tmp = new byte[4*1024];
		try{
			while(!iflr.finished()){
				int size = iflr.inflate(tmp);
				baos.write(tmp, 0, size);
			}
		} catch (Exception ex){

		} finally {
			try{
				if(baos != null) baos.close();
			} catch(Exception ex){}
		}

		return baos.toByteArray();
	}


	@Override
	public PerfiosEntity getDeleteData(PerfiosEntity perfiosEntity) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Getting DeleteData Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosDataDeleteStatement(perfiosEntity);
			String pUrl = perfiosEntity.getDeleteDataUrl();
			logger.info("URL : "+pUrl);
			logger.info("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//conn.setRequestProperty("Content-Type", "application/xml");
			//OutputStream os = conn.getOutputStream();
			//os.write(perfiosTransactionUrl.)
			//os.flush();

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				perfiosEntity.setResponseXML(result.toString());
			}
		}
		catch (Exception e) 
		{
			logger.error("Error While Calling RetrieveReport Perfios ::",e);
			e.printStackTrace();
		}
		logger.info("Getting DeleteData Process : END");
		return perfiosEntity;
	}
	@Override
	public PerfiosEntity getTransactionReview(PerfiosEntity perfiosEntity) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Getting TransactionReview Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosTransactionReview(perfiosEntity);
			String pUrl = perfiosEntity.getTransactionReviewUrl();
			logger.info("URL : "+pUrl);
			logger.info("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//conn.setRequestProperty("Content-Type", "application/xml");
			//OutputStream os = conn.getOutputStream();
			//os.write(perfiosTransactionUrl.)
			//os.flush();

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				perfiosEntity.setResponseXML(result.toString());
			}
		}
		catch (Exception e) 
		{
			logger.error("Error While Calling RetrieveReport Perfios ::",e);
			e.printStackTrace();
		}
		logger.info("Getting TransactionReview Process : END");
		return perfiosEntity;
	}

	@Override
	public PerfiosEntity getSupportedInstitutions(PerfiosEntity perfiosEntity) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Getting SupportedInstitutions Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosSupportedInstitutions(perfiosEntity);
			String pUrl = perfiosEntity.getSupportedInstUrl();
			logger.info("URL : "+pUrl);
			logger.info("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//conn.setRequestProperty("Content-Type", "application/xml");
			//OutputStream os = conn.getOutputStream();
			//os.write(perfiosTransactionUrl.)
			//os.flush();

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				perfiosEntity.setResponseXML(result.toString());
			}
		}
		catch (Exception e) 
		{
			logger.error("Error While Calling RetrieveReport Perfios ::",e);
			e.printStackTrace();
		}
		logger.info("Getting SupportedInstitutions Process : END");
		return perfiosEntity;
	}
}
