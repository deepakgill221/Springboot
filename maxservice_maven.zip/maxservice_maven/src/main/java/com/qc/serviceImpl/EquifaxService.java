package com.qc.serviceImpl;

import java.net.URL;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.equifax.services.eport.servicedefs._1_0.CreditReportWSInquiryPortTypeProxy;
import com.equifax.services.eport.servicedefs._1_0.V10;
import com.equifax.services.eport.servicedefs._1_0.V10Locator;
import com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions;
import com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType;
import com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType;
import com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions;
import com.equifax.services.eport.ws.schemas._1_0.RequestBodyType;
import com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType;
import com.equifax.services.eport.ws.schemas._1_0.StateCodeOptions;
import com.qc.service.ExternalServices;
import com.qc.utils.Match;
import com.qc.utils.XTrustProvider;

@Service//("equifaxService")
public class EquifaxService implements ExternalServices
{
	private static Logger logger = LogManager.getLogger(EquifaxService.class);
	
	public Map<String,String> callService(Map<String,Object> requestParams,Environment env)
	{
		Match nm = new Match();
		Map<String, String> responseParams =  null;
		Map<String,String> response = new HashMap<String,String>();
		
		if(requestParams.get("validationType").toString().equalsIgnoreCase("PAN"))
		{
			//Call logic to Equifax VID - Used For PAN
			try
			{
				logger.info("EQUIFAX service for PAN :  START");
				responseParams = getPanDetail(requestParams,env);
				
				if((responseParams.containsKey("ERRORCODE") && responseParams.get("ERRORCODE").contains("E")))
				{
					response.put("RESPONSE_STATUS", "1");
					response.put("PAN_STATUS", "Not Matched");
					response.put("DOB_STATUS", "");
					response.put("NAME_STATUS", "Not Matched");
					logger.info("EQUIFAX service for PAN :  END");
					return response; 
				}
				else{
					
				
				if(responseParams!=null && responseParams.containsKey("PANNO") )
				{
					if(responseParams.get("PANCODE").equalsIgnoreCase("E"))
					{
						boolean panFlag = nm.matchPAN(requestParams, responseParams);
						boolean nameFlag = nm.matchName(requestParams, responseParams);

						if(panFlag && nameFlag)
						{	//if pan and name are matched then pan matched.
							response.put("PAN_STATUS", "Matched");
						}
						else
						{
							response.put("PAN_STATUS", "Not Matched");
						}

						if(nameFlag)
						{
							response.put("NAME_STATUS", "Matched");
						}
						else
						{
							response.put("NAME_STATUS", "Not Matched");
						}
					
						response.put("DOB_STATUS", "");
						response.put("RESPONSE_STATUS", "1");
					}
					else
					{
//						When PAN no is not matched or wrong PAN number.
						response.put("RESPONSE_STATUS", "1");//	rishabh
						response.put("PAN_STATUS", "Not Matched");
						response.put("DOB_STATUS", "");
						response.put("NAME_STATUS", "Not Matched");
					}
					
				}
				else
				{
			
					response.put("RESPONSE_STATUS", "0");
					response.put("PAN_STATUS", "Not Matched");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME_STATUS", "Not Matched");
				}
				}	
				
				logger.info("EQUIFAX service for PAN :  END");
				return response;
				
			}
			catch(Exception e)
			{
				logger.error("Inside catch: "+e.getMessage());
				e.printStackTrace();
			}

		}
		else if(requestParams.get("validationType").toString().equalsIgnoreCase("DOB"))
		{
			//Call logic to Equifax EVDR - Used for DOB
			try
			{
				logger.info("EQUIFAX service for DOB :  START");

				responseParams = getDobDetail(requestParams,env);
				// RISHABH 28 MAR ;
				if((responseParams.containsKey("ERRORCODE") && responseParams.get("ERRORCODE").contains("E")))
				{
					response.put("RESPONSE_STATUS", "1");
					response.put("PAN_STATUS", "");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME_STATUS", "Not Matched");
					logger.info("EQUIFAX service for DOB :  END");
					return response; 
				}
				else{
				if(responseParams!=null && (responseParams.containsKey("DOB")|| responseParams.containsKey("DOBCODE")))
				{
					
					boolean nameFlag = nm.matchName(requestParams, responseParams);
					boolean dobFlag = nm.matchDOB(requestParams, responseParams);

						response.put("PAN_STATUS", "");

					if(nameFlag)
					{
						response.put("NAME_STATUS", "Matched");
					}
					else
					{
						response.put("NAME_STATUS", "Not Matched");
					}

					if(dobFlag && nameFlag)
					{	//for Dob both name and DOB need to matched
						response.put("DOB_STATUS", "Matched");
					}
					else
					{
						response.put("DOB_STATUS", "Not Matched");
					}
					response.put("RESPONSE_STATUS", "1");
				}
				
				else
				{
					response.put("RESPONSE_STATUS", "0");
					response.put("PAN_STATUS", "");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME_STATUS", "Not Matched");
				}
				logger.info("EQUIFAX service for DOB :  END");
				return response;
			}
			}
			catch(Exception e)
			{
				logger.error("Inside catch: "+e.getMessage());
				e.printStackTrace();
			}
		}
		return null;
	}

	private Map<String,String> getPanDetail(Map<String,Object> requestParams,Environment env)
	{
		Map<String,String> panMap = new HashMap<String,String>();
		try 
		{
			
			String CUSTOMERID=env.getProperty("com.qualtech.pan.resource.EQUIFAX.CustomerId");
			String USERID=env.getProperty("com.qualtech.pan.resource.EQUIFAX.UserId");
			String PASSWORD=env.getProperty("com.qualtech.pan.resource.EQUIFAX.Password");
			String MEMBER_NUMBER=env.getProperty("com.qualtech.pan.resource.EQUIFAX.MemberNumber");
			String PRODUCT_CODE_PAN=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductCodePAN");
			String PRODUCT_CODE_DOB=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductCodeDOB");
			String SECURITY_CODE=env.getProperty("com.qualtech.pan.resource.EQUIFAX.SecurityCode");
			String PRODUCT_VERSION=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductVersion");
			String URL=env.getProperty("com.qualtech.pan.resource.EQUIFAX.url");
			
			logger.info(" PAN : Calling EQUIFAX Service : Start");
			URL url=new URL(URL);
			logger.info(" PAN : url:"+url);

			RequestHeaderType requestHeaderType=new RequestHeaderType();
			requestHeaderType.setCustomerId(Integer.parseInt(CUSTOMERID));
			requestHeaderType.setUserId(USERID);
			requestHeaderType.setPassword(PASSWORD);
			requestHeaderType.setMemberNumber(MEMBER_NUMBER);
			requestHeaderType.setProductCode(PRODUCT_CODE_PAN);//For PAN
			requestHeaderType.setSecurityCode(SECURITY_CODE);
			requestHeaderType.setProductVersion(PRODUCT_VERSION);
			requestHeaderType.setReportFormat(ReportFormatOptions.XML);

			RequestBodyType requestBodyType = new RequestBodyType();
			requestBodyType.setInquiryPurpose(InquiryPurposeOptions.value31);
			requestBodyType.setFirstName(requestParams.get("fname").toString());//First Name
			requestBodyType.setMiddleName(requestParams.get("mname").toString());//M Name
			requestBodyType.setLastName(requestParams.get("lname").toString());//L Name

			String dateInString = getDateInAnyFormat(requestParams.get("dob").toString(),"yyyy-mm-dd");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date date = sdf.parse(dateInString);

			requestBodyType.setDOB(date);
			requestBodyType.setPANId(requestParams.get("pan").toString());

			InquiryRequestType inquiryRequest = new InquiryRequestType();
			inquiryRequest.setRequestHeader(requestHeaderType);
			inquiryRequest.setRequestBody(requestBodyType);


			V10 locator = new V10Locator();

			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();

			//CreditReportWSInquiryBindingStub stub = new CreditReportWSInquiryBindingStub(url,locator);
			//InquiryResponseType response = stub.getConsumerCreditReport(inquiryRequest);

			CreditReportWSInquiryPortTypeProxy cp=new CreditReportWSInquiryPortTypeProxy();

			//For Dev we need to enable this
//			System.setProperty("http.proxyHost", "cachecluster.maxlifeinsurance.com");
//			System.setProperty("http.proxyPort", "3128");

//			logger.info(" PAN : Proxy Set Going to call service for Response XML : Start");
			InquiryResponseType response=cp.getConsumerCreditReport(inquiryRequest);
//			logger.info(" PAN : Proxy Set Going to call service for Response XML : End");

			try
			{
			panMap.put("PANCODE", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getReturnCode());
			panMap.put("PANNO", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getPAN());
			panMap.put("FNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getFirstName());
			panMap.put("MNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getMiddleName());
			panMap.put("LNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getLastName());
			}
			catch(NullPointerException ne)
			{
				logger.error(" PAN : EQUIFAX Service : in Exception: Invalid Entries" +ne.getMessage());
				panMap.put("ERRORCODE",response.getReportData().getError()[0].getErrorCode());
				logger.error(" PAN : EQUIFAX Service : in Exception: Error code"+response.getReportData().getError()[0].getErrorCode());
				logger.error(" PAN : EQUIFAX Service : in Exception: Error Message"+response.getReportData().getError()[0].getErrorMsg());
			}
			
			logger.info(" PAN : Calling EQUIFAX Service : End");
		} 
		catch (Exception e)
		{
			logger.error(" PAN : Calling EQUIFAX Service : in Exception" +e.getMessage());
			e.printStackTrace();
		}
		return panMap;
	}
	private Map<String,String> getDobDetail(Map<String,Object> requestParams,Environment env)
	{
		Map<String,String> dobMap = new HashMap<String,String>();
		try 
		{
			String CUSTOMERID=env.getProperty("com.qualtech.pan.resource.EQUIFAX.CustomerId");
			String USERID=env.getProperty("com.qualtech.pan.resource.EQUIFAX.UserId");
			String PASSWORD=env.getProperty("com.qualtech.pan.resource.EQUIFAX.Password");
			String MEMBER_NUMBER=env.getProperty("com.qualtech.pan.resource.EQUIFAX.MemberNumber");
			String PRODUCT_CODE_PAN=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductCodePAN");
			String PRODUCT_CODE_DOB=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductCodeDOB");
			String SECURITY_CODE=env.getProperty("com.qualtech.pan.resource.EQUIFAX.SecurityCode");
			String PRODUCT_VERSION=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductVersion");
			String URL=env.getProperty("com.qualtech.pan.resource.EQUIFAX.url");
			
			logger.info(" DOB : Calling EQUIFAX Service : Start");
			URL url=new URL(URL);
			logger.info(" DOB : url:"+url);
			
			RequestHeaderType requestHeaderType=new RequestHeaderType();
			requestHeaderType.setCustomerId(Integer.parseInt(CUSTOMERID));
			requestHeaderType.setUserId(USERID);
			requestHeaderType.setPassword(PASSWORD);
			requestHeaderType.setMemberNumber(MEMBER_NUMBER);
			requestHeaderType.setProductCode(PRODUCT_CODE_DOB);//For DOB
			requestHeaderType.setSecurityCode(SECURITY_CODE);
			requestHeaderType.setProductVersion(PRODUCT_VERSION);
			requestHeaderType.setReportFormat(ReportFormatOptions.XML);

			RequestBodyType requestBodyType = new RequestBodyType();
			requestBodyType.setInquiryPurpose(InquiryPurposeOptions.value1);
			requestBodyType.setFirstName(requestParams.get("fname").toString());
			requestBodyType.setMiddleName(requestParams.get("mname").toString());
			requestBodyType.setLastName(requestParams.get("lname").toString());

			String dateInString = getDateInAnyFormat(requestParams.get("dob").toString(),"yyyy-mm-dd");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date date = sdf.parse(dateInString);

			requestBodyType.setDOB(date);
			requestBodyType.setPANId(requestParams.get("pan").toString());
			requestBodyType.setAddrLine1(getAddress(requestParams));
			requestBodyType.setState(new StateCodeOptions(requestParams.get("stateCode").toString().toUpperCase()));
			requestBodyType.setPostal(requestParams.get("postalCode").toString());

			InquiryRequestType inquiryRequest = new InquiryRequestType();
			inquiryRequest.setRequestHeader(requestHeaderType);
			inquiryRequest.setRequestBody(requestBodyType);

			InquiryResponseType inquiryResponse = new InquiryResponseType();
			inquiryResponse.setInquiryRequestInfo(requestBodyType);


			V10 locator = new V10Locator();

			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();

			//CreditReportWSInquiryBindingStub stub = new CreditReportWSInquiryBindingStub(url,locator);
			//InquiryResponseType response = stub.getConsumerCreditReport(inquiryRequest);

			CreditReportWSInquiryPortTypeProxy cp=new CreditReportWSInquiryPortTypeProxy();

			//For Dev we need to enable this
//			System.setProperty("http.proxyHost", "cachecluster.maxlifeinsurance.com");
//			System.setProperty("http.proxyPort", "3128");
			

			logger.info(" PAN : Proxy Set Going to call service for Response XML : Start");
			InquiryResponseType response=cp.getConsumerCreditReport(inquiryRequest);
			logger.info(" PAN : Proxy Set Going to call service for Response XML : End");
			
			try{
			int a = response.getReportData().getVerifyIDResponse().getVidNsdlResponses().length;
			dobMap.put("PANCODE", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[a-1].getNsdlResponse().getReturnCode());
			dobMap.put("PANNO", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[a-1].getNsdlResponse().getPAN());
			
				try
				{
					dobMap.put("DOBCODE", response.getReportData().getError()[a-1].getErrorCode());
				}
				catch(NullPointerException ne)
				{
					logger.error(" DOB : EQUIFAX Service : in Exception: DOB found" +ne.getMessage());
					dobMap.put("DOB",""+new SimpleDateFormat("dd-MM-yyyy").format(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth()));
					dobMap.put("FNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getFirstName());
					dobMap.put("MNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getMiddleName());
					dobMap.put("LNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getLastName());
				
				}
			
			}
			catch(NullPointerException ne){
				logger.error(" DOB : EQUIFAX Service : in Exception: Invalid Entries"+ne.getMessage());
				dobMap.put("ERRORCODE",response.getReportData().getError()[0].getErrorCode());
//				logger.info(" DOB : Calling EQUIFAX Service : End");
//				return dobMap;
			}
			
			logger.info(" DOB : Calling EQUIFAX Service : End");
		}
		catch(Exception e)
		{
			logger.error(" DOB : Calling EQUIFAX Service : in Exception"+e.getMessage());
			e.printStackTrace();
		}
		return dobMap;
	}


	private String getAddress(Map<String,Object> requestData)
	{
		String address="";
		try
		{
			String careOf = requestData.get("careOf")!=null?requestData.get("careOf").toString():"";
			String houseNo = requestData.get("houseNo")!=null?requestData.get("houseNo").toString():"";
			String street = requestData.get("street")!=null?requestData.get("street").toString():"";
			String landmark = requestData.get("landmark")!=null?requestData.get("landmark").toString():"";
			String location = requestData.get("location")!=null?requestData.get("location").toString():"";
			String postOffice = requestData.get("postOffice")!=null?requestData.get("postOffice").toString():"";
			String vill_city = requestData.get("vill_city")!=null?requestData.get("vill_city").toString():"";
			String subDistrict = requestData.get("subDistrict")!=null?requestData.get("subDistrict").toString():"";
			String district = requestData.get("district")!=null?requestData.get("district").toString():"";

			address += (careOf.equals("")?"":careOf+" ")+(houseNo.equals("")?"":houseNo+" ")+(street.equals("")?"":street+" "); 
			address += (vill_city.equals("")?"":vill_city+" ")+(location.equals("")?"":location+" ")+(landmark.equals("")?"":landmark+" ");
			address += (postOffice.equals("")?"":postOffice+" ")+(subDistrict.equals("")?"":subDistrict+" ")+(district.equals("")?"":district+" ");
		}
		catch(Exception ex)
		{
			logger.error("Error Whill Trying to Create Address" +ex.getMessage());
			address="False";
			ex.printStackTrace();
		}

		return address;
	}


	public String getDateInAnyFormat(String inputDate , String dateFormat)
	{
		String outputDate="";
		Format requiredFormatter = new SimpleDateFormat(dateFormat);
		logger.info("Input Date is : "+inputDate+" And Requested Format is : "+dateFormat);
		try
		{
			DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			Date date = formatter.parse(inputDate);
			outputDate = requiredFormatter.format(date);
			return outputDate;
		}
		catch(Exception ex)
		{
			try
			{
				DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
				Date date = formatter.parse(inputDate);
				outputDate = requiredFormatter.format(date);
				return outputDate;
			}
			catch(Exception ex1)
			{
				try
				{
					DateFormat formatter = new SimpleDateFormat("yyyy-dd-MM");
					Date date = formatter.parse(inputDate);
					outputDate = requiredFormatter.format(date);
					return outputDate;
				}
				catch(Exception ex2)
				{
					try
					{
						DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
						Date date = formatter.parse(inputDate);
						outputDate = requiredFormatter.format(date);
						return outputDate;
					}
					catch(Exception ex3)
					{
						try
						{
							DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
							Date date = formatter.parse(inputDate);
							outputDate = requiredFormatter.format(date);
							return outputDate;
						}
						catch(Exception ex4)
						{
							try
							{
								DateFormat formatter = new SimpleDateFormat("yyyyddMM");
								Date date = formatter.parse(inputDate);
								outputDate = requiredFormatter.format(date);
								return outputDate;
							}
							catch(Exception ex5)
							{
								try
								{
									DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
									Date date = formatter.parse(inputDate);
									outputDate = requiredFormatter.format(date);
									return outputDate;
								}
								catch(Exception ex6)
								{
									logger.info("Input Date is : "+inputDate);
									ex.printStackTrace();
								}
							}
						}
					}
				}
			}
		}
		return outputDate;
	}

	
	
//################## NOT IN USE (Please refer EquifaxServceHelper for equifax 2.0) ##########	
//###########################################################################################	
//########################	CREDIT BUREAU 2.0  ##############################################
	
	@Override
	public Map<String, String> callNeoService(Map<String, Object> requestParams,Environment env) {
		// TODO Auto-generated method stub
		return null;
	}
	
/*	public Map<String,String> callNeoService(Map<String,Object> requestParams)
	{
		logger.info("EQIFAX SERVICE OLDER :callNeoService: STARTED :: NOT IN USE :: ");
		Match nm = new Match();
		Map<String, String> responseParams =  null;
		Map<String,String> response = new HashMap<String,String>();
		
		
		String ValidationType=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("ValidationType")).toString();
		
		if(ValidationType.equalsIgnoreCase("PANDOB"))
		{
			//Call logic to Equifax VID - Used For PAN
			try
			{
				logger.info("EQUIFAX service for PAN :  START");
				

				//call equifax soap service
				EquifaxServiceHelper equifaxService1 = new EquifaxServiceHelper();
				//equifaxService1.getNeoPanDobDetail1(requestParams);
				
				responseParams = getNeoPanDobDetail(requestParams);
				
				if((responseParams.containsKey("ERRORCODE") && responseParams.get("ERRORCODE").contains("E")))
				{
					response.put("RESPONSE_STATUS", "1");
					response.put("PAN", "");
					response.put("PAN_STATUS", "Not Matched");
					response.put("DOB", "");
					response.put("DOB_STATUS", "");
					response.put("NAME", "");
					response.put("NAME_STATUS", "Not Matched");
					logger.info("EQUIFAX Neo service for PAN :  END");
					return response; 
				}
				else{
					
//					Getting the full name from the equifax response
					String name = responseParams.get("FNAME").toString();
					name+=" ";
					name+=responseParams.get("MNAME").toString();
					name+=" ";
					name+=responseParams.get("LNAME").toString();
					

					response.put("PAN", responseParams.get("PANNO"));
					response.put("NAME",name);
					
				if(responseParams!=null && responseParams.containsKey("PANNO") )
				{
					if(responseParams.get("PANCODE").equalsIgnoreCase("E"))
					{
						boolean panFlag = nm.matchPAN(requestParams, responseParams);
						boolean nameFlag = nm.matchName(requestParams, responseParams);

						if(panFlag && nameFlag)
						{	//if pan and name are matched then pan matched.
							response.put("PAN_STATUS", "Matched");
						}
						else
						{
							response.put("PAN_STATUS", "Not Matched");
						}

						if(nameFlag)
						{
							response.put("NAME_STATUS", "Matched");
						}
						else
						{
							response.put("NAME_STATUS", "Not Matched");
						}
					

						response.put("DOB", "");
						response.put("DOB_STATUS", "");
						response.put("RESPONSE_STATUS", "1");
					}
					else
					{
//						When PAN no is not matched or wrong PAN number.
						response.put("RESPONSE_STATUS", "1");//	rishabh
						response.put("PAN_STATUS", "Not Matched");
						response.put("DOB_STATUS", "");
						response.put("NAME_STATUS", "Not Matched");
					}
					
				}
				else
				{
			
					response.put("RESPONSE_STATUS", "0");
					response.put("PAN_STATUS", "Not Matched");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME_STATUS", "Not Matched");
				}
				}	
				
				logger.info("EQUIFAX service for PAN :  END");
				return response;
				
			}
			catch(Exception e)
			{
				logger.error("Inside catch: "+e.getMessage());
				e.printStackTrace();
			}

		}
		else if(ValidationType.equalsIgnoreCase("ALL"))
		{
			//Call logic to Equifax EVDR - Used for DOB
			try
			{
				logger.info("EQUIFAX service for Service 2 ALL details :  START");

				responseParams = getNeoAllDetail(requestParams);
				// RISHABH 28 MAR ;
				if((responseParams.containsKey("ERRORCODE") && responseParams.get("ERRORCODE").contains("E")))
				{
					
					response.put("RESPONSE_STATUS", "1");
					response.put("PAN", "");
					response.put("PAN_STATUS", "");
					response.put("DOB", "");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME", "");
					response.put("NAME_STATUS", "Not Matched");
					logger.info("EQUIFAX service for DOB :  END");
					return response; 
				}
				else{
					
					
//					Getting the full name from the equifax response
					String name = responseParams.get("FNAME").toString();
					name+=" ";
					name+=responseParams.get("MNAME").toString();
					name+=" ";
					name+=responseParams.get("LNAME").toString();
					

					response.put("DOB", responseParams.get("DOB"));
					response.put("NAME",name);
					
				if(responseParams!=null && (responseParams.containsKey("DOB")|| responseParams.containsKey("DOBCODE")))
				{
					
					boolean nameFlag = nm.matchName(requestParams, responseParams);
					boolean dobFlag = nm.matchDOB(requestParams, responseParams);

						response.put("PAN_STATUS", "");

					if(nameFlag)
					{
						response.put("NAME_STATUS", "Matched");
					}
					else
					{
						response.put("NAME_STATUS", "Not Matched");
					}

					if(dobFlag && nameFlag)
					{	//for Dob both name and DOB need to matched
						response.put("DOB_STATUS", "Matched");
					}
					else
					{
						response.put("DOB_STATUS", "Not Matched");
					}
					response.put("RESPONSE_STATUS", "1");
				}
				
				else
				{
					response.put("RESPONSE_STATUS", "0");
					response.put("PAN_STATUS", "");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME_STATUS", "Not Matched");
				}
				logger.info("EQUIFAX service for DOB :  END");
				return response;
			}
			}
			catch(Exception e)
			{
				logger.error("Inside catch: "+e.getMessage());
				e.printStackTrace();
			}
		}
		return null;
	}

	private Map<String,String> getNeoPanDobDetail(Map<String,Object> requestParams)
	{
		Map<String,String> panMap = new HashMap<String,String>();
		
		String fname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("fname")).toString().trim();
		String mname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mname")).toString().trim();
		String lname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("lname")).toString().trim();
		String dob=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("dob")).toString().trim();
		String pan=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("pan")).toString().trim();
		
		try 
		{
			logger.info(" PANDOB : Calling EQUIFAX Service : Start");
			URL url=new URL(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.url"));
			logger.info(" PANDOB : url:"+url);

			RequestHeaderType requestHeaderType=new RequestHeaderType();
			requestHeaderType.setCustomerId(Integer.parseInt(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.CustomerId")));
			requestHeaderType.setUserId(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.UserId"));
			requestHeaderType.setPassword(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.Password"));
			requestHeaderType.setMemberNumber(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.MemberNumber"));
			requestHeaderType.setProductCode(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.ProductCodePANDOB"));//For Service 1
			requestHeaderType.setSecurityCode(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.SecurityCode"));
			requestHeaderType.setProductVersion(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.ProductVersion"));
			requestHeaderType.setReportFormat(ReportFormatOptions.XML);

			RequestBodyType requestBodyType = new RequestBodyType();
			requestBodyType.setInquiryPurpose(InquiryPurposeOptions.value23);
			requestBodyType.setFirstName(fname);//First Name
			requestBodyType.setMiddleName(mname);//M Name
			requestBodyType.setLastName(lname);//L Name

			String dateInString = getDateInAnyFormat(dob,"yyyy-mm-dd");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date date = sdf.parse(dateInString);

			requestBodyType.setDOB(date);
			requestBodyType.setPANId(pan);

			InquiryRequestType inquiryRequest = new InquiryRequestType();
			inquiryRequest.setRequestHeader(requestHeaderType);
			inquiryRequest.setRequestBody(requestBodyType);


			V10 locator = new V10Locator();

			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();

			CreditReportWSInquiryPortTypeProxy cp=new CreditReportWSInquiryPortTypeProxy();

			//For Dev we need to enable this
			System.setProperty("http.proxyHost", "cachecluster.maxlifeinsurance.com");
			System.setProperty("http.proxyPort", "3128");
			
	

			logger.info(" PAN : Proxy Set Going to call service for Response XML : Start");
			InquiryResponseType response=cp.getConsumerCreditReport(inquiryRequest);
			logger.info(" PAN : Proxy Set Going to call service for Response XML : End");

			try
			{
			panMap.put("PANCODE", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getReturnCode());
			panMap.put("PANNO", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getPAN());
			panMap.put("FNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getFirstName());
			panMap.put("MNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getMiddleName());
			panMap.put("LNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getLastName());
			}
			catch(NullPointerException ne)
			{
				logger.error(" PAN : EQUIFAX Service : in Exception: Invalid Entries" +ne.getMessage());
				panMap.put("ERRORCODE",response.getReportData().getError()[0].getErrorCode());
			}
			
			logger.info(" PAN : Calling EQUIFAX Service : End");
		} 
		catch (Exception e)
		{
			logger.error(" PAN : Calling EQUIFAX Service : in Exception" +e.getMessage());
			e.printStackTrace();
		}
		return panMap;
	}
	
	private Map<String,String> getNeoAllDetail(Map<String,Object> requestParams)
	{
		Map<String,String> dobMap = new HashMap<String,String>();
		
		String fname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("fname")).toString().trim();
		String mname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mname")).toString().trim();
		String lname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("lname")).toString().trim();
		String dob=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("dob")).toString().trim();
		String pan=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("pan")).toString().trim();
		String vill_city=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("vill_city")).toString().trim();
		String stateCode=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("stateCode")).toString().trim();
		String postalCode=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("postalCode")).toString().trim();
		String mobileno=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mobileno")).toString().trim();
		String email=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("email")).toString().trim();
		String gender=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("gender")).toString().toUpperCase().trim();
		
		try 
		{
			logger.info(" DOB : Calling EQUIFAX Service : Start");
			URL url=new URL(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.url"));
			logger.info(" DOB : url:"+url);
			
			RequestHeaderType requestHeaderType=new RequestHeaderType();
			requestHeaderType.setCustomerId(Integer.parseInt(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.CustomerId")));
			requestHeaderType.setUserId(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.UserId"));
			requestHeaderType.setPassword(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.Password"));
			requestHeaderType.setMemberNumber(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.MemberNumber"));
			requestHeaderType.setProductCode(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.ProductCodeALL"));//For ALL Details
			requestHeaderType.setSecurityCode(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.SecurityCode"));
			requestHeaderType.setProductVersion(resProp.getString("com.qualtech.pan2.resource.EQUIFAX.ProductVersion"));
			requestHeaderType.setReportFormat(ReportFormatOptions.XML);

			RequestBodyType requestBodyType = new RequestBodyType();
			requestBodyType.setInquiryPurpose(InquiryPurposeOptions.value23);
			requestBodyType.setFirstName(fname);
			requestBodyType.setMiddleName(mname);
			requestBodyType.setLastName(lname);

			String dateInString = getDateInAnyFormat(dob,"yyyy-mm-dd");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date date = sdf.parse(dateInString);

			requestBodyType.setDOB(date);
			requestBodyType.setPANId(pan);
			requestBodyType.setAddrLine1(getNeoAddress(requestParams));
			requestBodyType.setState(new StateCodeOptions(stateCode.toUpperCase()));
			requestBodyType.setPostal(postalCode);

			InquiryRequestType inquiryRequest = new InquiryRequestType();
			inquiryRequest.setRequestHeader(requestHeaderType);
			inquiryRequest.setRequestBody(requestBodyType);

			InquiryResponseType inquiryResponse = new InquiryResponseType();
			inquiryResponse.setInquiryRequestInfo(requestBodyType);


			V10 locator = new V10Locator();

			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();

			CreditReportWSInquiryPortTypeProxy cp=new CreditReportWSInquiryPortTypeProxy();

			//For Dev we need to enable this
			System.setProperty("http.proxyHost", "cachecluster.maxlifeinsurance.com");
			System.setProperty("http.proxyPort", "3128");
			
			logger.info(" PAN : Proxy Set Going to call service for Response XML : Start");
			InquiryResponseType response=cp.getConsumerCreditReport(inquiryRequest);
			logger.info(" PAN : Proxy Set Going to call service for Response XML : End");
			
			try{
			int a = response.getReportData().getVerifyIDResponse().getVidNsdlResponses().length;
			System.out.println("Total Length : "+a);
			dobMap.put("PANCODE", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[a-1].getNsdlResponse().getReturnCode());
			dobMap.put("PANNO", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[a-1].getNsdlResponse().getPAN());
			
				try
				{
					dobMap.put("DOBCODE", response.getReportData().getError()[a-1].getErrorCode());
				}
				catch(NullPointerException ne)
				{
					logger.error(" DOB : EQUIFAX Service : in Exception: DOB found" +ne.getMessage());
					dobMap.put("DOB",""+new SimpleDateFormat("dd-MM-yyyy").format(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth()));
					dobMap.put("FNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getFirstName());
					dobMap.put("MNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getMiddleName());
					dobMap.put("LNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getLastName());
				
				}
			
			}
			catch(NullPointerException ne){
				logger.error(" DOB : EQUIFAX Service : in Exception: Invalid Entries"+ne.getMessage());
				dobMap.put("ERRORCODE",response.getReportData().getError()[0].getErrorCode());
//				logger.info(" DOB : Calling EQUIFAX Service : End");
//				return dobMap;
			}
			
			//System.out.println(response.getReportData().getIDAndContactInfo().getIdentityInfo().getPANId()[0].getIdNumber());//pan
			logger.info(" DOB : Calling EQUIFAX Service : End");
		}
		catch(Exception e)
		{
			logger.error(" DOB : Calling EQUIFAX Service : in Exception"+e.getMessage());
			e.printStackTrace();
		}
		return dobMap;
	}
	
	
	private String getNeoAddress(Map<String,Object> requestData)
	{
		String address="";
		try
		{
			String careOf=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("careOf")).toString().trim();
			String houseNo=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("houseNo")).toString().trim();
			String street=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("street")).toString().trim();
			String landmark=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("landmark")).toString().trim();
			String location=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("location")).toString().trim();
			String postOffice=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("postOffice")).toString().trim();
			String subDistrict=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("subDistrict")).toString().trim();
			String district=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("district")).toString().toUpperCase().trim();
			String vill_city=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("vill_city")).toString().trim();
			
			address += (careOf.equals("")?"":careOf+" ")+(houseNo.equals("")?"":houseNo+" ")+(street.equals("")?"":street+" "); 
			address += (vill_city.equals("")?"":vill_city+" ")+(location.equals("")?"":location+" ")+(landmark.equals("")?"":landmark+" ");
			address += (postOffice.equals("")?"":postOffice+" ")+(subDistrict.equals("")?"":subDistrict+" ")+(district.equals("")?"":district+" ");
		}
		catch(Exception ex)
		{
			logger.error("Error Whill Trying to Create Address" +ex.getMessage());
			address="False";
			ex.printStackTrace();
		}

		return address;
	}
*/
	
}
