package com.qc.serviceImpl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.service.ExternalServices;
import com.qc.utils.GetXMLValues;
import com.qc.utils.ResponseHandler;
import com.qc.utils.XTrustProvider;

@Service//("crifService")
public class CrifService implements ExternalServices
{
	private static Logger logger = LogManager.getLogger(CrifService.class);
	
	public Map<String,String> callService(Map<String,Object> requestParams , Environment env)
	{
		logger.info("CRIF service calling :  START");
		HttpURLConnection conn = null;
		Map<String, String> response = null;
		String xml=null;
		try
		{
			String PRODUCT_TYP=env.getProperty("com.qualtech.pan.resource.CRIF.PRODUCT-TYP");
			String PRODUCT_VER=env.getProperty("com.qualtech.pan.resource.CRIF.PRODUCT-VER");
			String REQ_MBR=env.getProperty("com.qualtech.pan.resource.CRIF.REQ-MBR");
			String SUB_MBR_ID=env.getProperty("com.qualtech.pan.resource.CRIF.SUB-MBR-ID");
			String INQ_DT_TM=env.getProperty("com.qualtech.pan.resource.CRIF.INQ-DT-TM");
			String REQ_VOL_TYP=env.getProperty("com.qualtech.pan.resource.CRIF.REQ-VOL-TYP");
			String REQ_ACTN_TYP=env.getProperty("com.qualtech.pan.resource.CRIF.REQ-ACTN-TYP");
			String TEST_FLG=env.getProperty("com.qualtech.pan.resource.CRIF.TEST-FLG");
			String AUTH_FLG=env.getProperty("com.qualtech.pan.resource.CRIF.AUTH-FLG");
			String RES_FRMT=env.getProperty("com.qualtech.pan.resource.CRIF.RES-FRMT");
			String LOS_NAME=env.getProperty("com.qualtech.pan.resource.CRIF.LOS-NAME");
			String LOS_VENDER=env.getProperty("com.qualtech.pan.resource.CRIF.LOS-VENDER");
			String LOS_VERSION=env.getProperty("com.qualtech.pan.resource.CRIF.LOS-VERSION");
			String REQ_SERVICE_TYPE_PAN=env.getProperty("com.qualtech.pan.resource.CRIF.REQ-SERVICE-TYPE-PAN");
			String USER_ID=env.getProperty("com.qualtech.pan.resource.CRIF.USERID");
			String URL=env.getProperty("com.qualtech.pan.resource.CRIF.url");
			String PASSWORD=env.getProperty("com.qualtech.pan.resource.CRIF.PASSWORD");
			String TIMEOUT=env.getProperty("com.qualtech.pan.resource.CRIF.Timeout");
			
			if(requestParams.get("validationType").toString().equalsIgnoreCase("PAN"))
			{
				logger.debug("CRIF service : calling for PAN");
				//			xml = "<REQUEST-FILE> 	<HEADER-SEGMENT> 		<PRODUCT-TYP>IDENCHECK</PRODUCT-TYP> 		<PRODUCT-VER>2.0</PRODUCT-VER> 		<REQ-MBR>INS0000002</REQ-MBR> 		<SUB-MBR-ID>MLI</SUB-MBR-ID> 		<INQ-DT-TM>11-10-2015</INQ-DT-TM> 		<REQ-VOL-TYP>INDV</REQ-VOL-TYP> 		<REQ-ACTN-TYP>AT01</REQ-ACTN-TYP> 		<TEST-FLG>false</TEST-FLG> 		<AUTH-FLG>false</AUTH-FLG> 		<RES-FRMT>html</RES-FRMT> 		<LOS-NAME>TEST</LOS-NAME> 		<LOS-VENDER>TEST</LOS-VENDER> 		<LOS-VERSION>1.0</LOS-VERSION> 		<REQ-SERVICE-TYPE>PAN</REQ-SERVICE-TYPE> 	</HEADER-SEGMENT> 	<INQUIRY> 		<APPLICANT-SEGMENT> 			<APPLICANT-NAME> 				<NAME1>NITIN</NAME1> 				<NAME2>JAIN</NAME2> 				<NAME3></NAME3> 				<NAME4></NAME4> 				<NAME5></NAME5> 			</APPLICANT-NAME> 			<DOB> 				<DOB-DATE>07-06-1979</DOB-DATE> 				<AGE>28</AGE> 				<AGE-AS-ON></AGE-AS-ON> 			</DOB> 			<IDS> 				<PAN>AFUPJ7365N</PAN> 				<VOTER-ID></VOTER-ID> 				<UID></UID> 			</IDS> 			<OTHER-IDS> 				<ID> 					<TYPE></TYPE> 					<VALUE></VALUE> 				</ID> 				<ID> 					<TYPE></TYPE> 					<VALUE></VALUE> 				</ID> 			</OTHER-IDS> 			<RELATIONS> 				<RELATION> 					<TYPE></TYPE> 					<NAME></NAME> 				</RELATION> 				<RELATION> 					<TYPE></TYPE> 					<NAME></NAME> 				</RELATION> 				<RELATION> 					<TYPE></TYPE> 					<NAME></NAME> 				</RELATION> 			</RELATIONS> 			<PHONES> 				<PHONE> 					<TELE-NO-TYPE></TELE-NO-TYPE> 					<TELE-NO></TELE-NO> 				</PHONE> 				<PHONE> 					<TELE-NO-TYPE></TELE-NO-TYPE> 					<TELE-NO></TELE-NO> 				</PHONE> 			</PHONES> 			<GENDER></GENDER> 		</APPLICANT-SEGMENT> 		<ADDRESS-SEGMENT> 			<ADDRESS> 				<TYPE>D01</TYPE> 				<ADDRESS-1>GANGA ELECTRICALS SHOP NO.3</ADDRESS-1> 				<CITY>SAHARANPUR</CITY> 				<STATE>Uttar Pradesh</STATE> 				<PIN>247001</PIN> 			</ADDRESS> 		</ADDRESS-SEGMENT> 	</INQUIRY> </REQUEST-FILE>";

				xml = "<REQUEST-FILE> 	" +
						"<HEADER-SEGMENT> 		" +
						"<PRODUCT-TYP>"+PRODUCT_TYP+"</PRODUCT-TYP> 		" +
						"<PRODUCT-VER>"+PRODUCT_VER+"</PRODUCT-VER> 		" +
						"<REQ-MBR>"+REQ_MBR+"</REQ-MBR> 		" +
						"<SUB-MBR-ID>"+SUB_MBR_ID+"</SUB-MBR-ID> 		" +
						"<INQ-DT-TM>"+INQ_DT_TM+"</INQ-DT-TM> 		" +
						"<REQ-VOL-TYP>"+REQ_VOL_TYP+"</REQ-VOL-TYP> 		" +
						"<REQ-ACTN-TYP>"+REQ_ACTN_TYP+"</REQ-ACTN-TYP> 		" +
						"<TEST-FLG>"+TEST_FLG+"</TEST-FLG> 		" +
						"<AUTH-FLG>"+AUTH_FLG+"</AUTH-FLG> 		" +
						"<RES-FRMT>"+RES_FRMT+"</RES-FRMT> 		" +
						"<LOS-NAME>"+LOS_NAME+"</LOS-NAME> 		" +
						"<LOS-VENDER>"+LOS_VENDER+"</LOS-VENDER> 		" +
						"<LOS-VERSION>"+LOS_VERSION+"</LOS-VERSION> 		" +
						"<REQ-SERVICE-TYPE>"+REQ_SERVICE_TYPE_PAN+"</REQ-SERVICE-TYPE> 	" +
						"</HEADER-SEGMENT> 	" +
						"<INQUIRY> 		" +
						"<APPLICANT-SEGMENT> 			" +
						"<APPLICANT-NAME> 				" +
						"<NAME1>"+requestParams.get("fname").toString()+"</NAME1> 				" +
						"<NAME2>"+requestParams.get("mname").toString()+"</NAME2> 				" +
						"<NAME3>"+requestParams.get("lname").toString()+"</NAME3> 				" +
						"<NAME4></NAME4> 				" +
						"<NAME5></NAME5> 			" +
						"</APPLICANT-NAME> 			" +
						"<DOB> 				" +
						"<DOB-DATE></DOB-DATE> 				" +
						"<AGE>28</AGE> 				" +
						"<AGE-AS-ON></AGE-AS-ON> 			" +
						"</DOB> 			" +
						"<IDS> 				" +
						"<PAN>"+requestParams.get("pan").toString()+"</PAN> 				" +
						"<VOTER-ID></VOTER-ID> 				" +
						"<UID></UID> 			" +
						"</IDS> 			" +
						"<OTHER-IDS> 				" +
						"<ID> 					" +
						"<TYPE></TYPE> 					" +
						"<VALUE></VALUE> 				" +
						"</ID> 				" +
						"<ID> 					" +
						"<TYPE></TYPE> 					" +
						"<VALUE></VALUE> 				" +
						"</ID> 			" +
						"</OTHER-IDS> 			" +
						"<RELATIONS> 				" +
						"<RELATION> 					" +
						"<TYPE></TYPE> 					" +
						"<NAME></NAME> 				" +
						"</RELATION> 				<" +
						"RELATION> 					" +
						"<TYPE></TYPE> 					" +
						"<NAME></NAME> 				" +
						"</RELATION> 				" +
						"<RELATION> 					" +
						"<TYPE></TYPE> 					" +
						"<NAME></NAME> 				" +
						"</RELATION> 			" +
						"</RELATIONS> 			" +
						"<PHONES> 				" +
						"<PHONE>" +
						"<TELE-NO-TYPE></TELE-NO-TYPE> 					" +
						"<TELE-NO></TELE-NO> 				" +
						"</PHONE> 				" +
						"<PHONE> 					" +
						"<TELE-NO-TYPE></TELE-NO-TYPE> 					" +
						"<TELE-NO></TELE-NO> 				" +
						"</PHONE> 			</PHONES> 			" +
						"<GENDER></GENDER> 		" +
						"</APPLICANT-SEGMENT> 		" +
						"<ADDRESS-SEGMENT> 			" +
						"<ADDRESS> 				" +
						"<TYPE></TYPE> 				" +
						"<ADDRESS-1></ADDRESS-1> 				" +
						"<CITY></CITY> 				" +
						"<STATE></STATE> 				" +
						"<PIN></PIN> 			" +
						"</ADDRESS> 		" +
						"</ADDRESS-SEGMENT> 	" +
						"</INQUIRY> " +
						"</REQUEST-FILE>";
			}
			else if(requestParams.get("validationType").toString().equalsIgnoreCase("DOB"))
			{
				logger.debug("CRIF service : calling for DOB");

				xml = "<REQUEST-FILE> 	" +
						"<HEADER-SEGMENT> 		" +
						"<PRODUCT-TYP>"+PRODUCT_TYP+"</PRODUCT-TYP> 		" +
						"<PRODUCT-VER>"+PRODUCT_VER+"</PRODUCT-VER> 		" +
						"<REQ-MBR>"+REQ_MBR+"</REQ-MBR> 		" +
						"<SUB-MBR-ID>"+SUB_MBR_ID+"</SUB-MBR-ID> 		" +
						"<INQ-DT-TM>"+INQ_DT_TM+"</INQ-DT-TM> 		" +
						"<REQ-VOL-TYP>"+REQ_VOL_TYP+"</REQ-VOL-TYP> 		" +
						"<REQ-ACTN-TYP>"+REQ_ACTN_TYP+"</REQ-ACTN-TYP> 		" +
						"<TEST-FLG>"+TEST_FLG+"</TEST-FLG> 		" +
						"<AUTH-FLG>"+AUTH_FLG+"</AUTH-FLG> 		" +
						"<RES-FRMT>"+RES_FRMT+"</RES-FRMT> 		" +
						"<LOS-NAME>"+LOS_NAME+"</LOS-NAME> 		" +
						"<LOS-VENDER>"+LOS_VENDER+"</LOS-VENDER> 		" +
						"<LOS-VERSION>"+LOS_VERSION+"</LOS-VERSION> 		" +
						"<REQ-SERVICE-TYPE>"+REQ_SERVICE_TYPE_PAN+"</REQ-SERVICE-TYPE> 	" +
						"</HEADER-SEGMENT> 	" +
						"<INQUIRY> 		" +
						"<APPLICANT-SEGMENT> 			" +
						"<APPLICANT-NAME> 				" +
						"<NAME1>"+requestParams.get("fname").toString()+"</NAME1> 				" +
						"<NAME2>"+requestParams.get("mname").toString()+"</NAME2> 				" +
						"<NAME3>"+requestParams.get("lname").toString()+"</NAME3> 				" +
						"<NAME4></NAME4> 				" +
						"<NAME5></NAME5> 			" +
						"</APPLICANT-NAME> 			" +
						"<DOB> 				" +
						"<DOB-DATE>"+requestParams.get("dob").toString()+"</DOB-DATE> 				" +
						"<AGE>28</AGE> 				" +
						"<AGE-AS-ON></AGE-AS-ON> 			" +
						"</DOB> 			" +
						"<IDS> 				" +
						"<PAN>"+requestParams.get("pan").toString()+"</PAN> 				" +
						"<VOTER-ID></VOTER-ID> 				" +
						"<UID></UID> 			" +
						"</IDS> 			" +
						"<OTHER-IDS> 				" +
						"<ID> 					" +
						"<TYPE></TYPE> 					" +
						"<VALUE></VALUE> 				" +
						"</ID> 				" +
						"<ID> 					" +
						"<TYPE></TYPE> 					" +
						"<VALUE></VALUE> 				" +
						"</ID> 			" +
						"</OTHER-IDS> 			" +
						"<RELATIONS> 				" +
						"<RELATION> 					" +
						"<TYPE></TYPE> 					" +
						"<NAME></NAME> 				" +
						"</RELATION> 				<" +
						"RELATION> 					" +
						"<TYPE></TYPE> 					" +
						"<NAME></NAME> 				" +
						"</RELATION> 				" +
						"<RELATION> 					" +
						"<TYPE></TYPE> 					" +
						"<NAME></NAME> 				" +
						"</RELATION> 			" +
						"</RELATIONS> 			" +
						"<PHONES> 				" +
						"<PHONE>" +
						"<TELE-NO-TYPE></TELE-NO-TYPE> 					" +
						"<TELE-NO>"+requestParams.get("mobileno").toString()+"</TELE-NO> 				" +
						"</PHONE> 				" +
						"<PHONE> 					" +
						"<TELE-NO-TYPE></TELE-NO-TYPE> 					" +
						"<TELE-NO></TELE-NO> 				" +
						"</PHONE> 			</PHONES> 			" +
						"<GENDER>"+requestParams.get("gender").toString()+"</GENDER> 		" +
						"</APPLICANT-SEGMENT> 		" +
						"<ADDRESS-SEGMENT> 			" +
						"<ADDRESS> 				" +
						"<TYPE>D01</TYPE> 				" +
						"<ADDRESS-1>"+getAddress(requestParams)+"</ADDRESS-1> 				" +
						"<CITY>"+requestParams.get("vill_city").toString()+"</CITY> 				" +
						"<STATE>"+requestParams.get("state").toString()+"</STATE> 				" +
						"<PIN>"+requestParams.get("postalCode").toString()+"</PIN> 			" +
						"</ADDRESS> 		" +
						"</ADDRESS-SEGMENT> 	" +
						"</INQUIRY> " +
						"</REQUEST-FILE>";

			}
			XTrustProvider xTrustProvider =new XTrustProvider();
			xTrustProvider.install();
			logger.info("Request Xml: "+xml);
			
			URL url = new URL(URL);
			
			System.setProperty("jsse.enableSNIExtension", "false");
			
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/xml");	
			conn.addRequestProperty("userId", USER_ID);
			conn.addRequestProperty("password", PASSWORD);
			conn.addRequestProperty("requestXml", xml);

			conn.setConnectTimeout(Integer.parseInt(TIMEOUT));
			conn.setReadTimeout(Integer.parseInt(TIMEOUT));

			conn.setDoOutput(true);
			conn.setDoInput(true);

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			StringBuilder out= new StringBuilder();
			while ((output = br.readLine()) != null) 
			{
				logger.info(output);
				if(output!=null)
					out.append(output);
			}
			try {br.close();} catch (Exception e2) {}
			try
			{
				logger.info("Response Handler : Start");
				ResponseHandler responseHandler = new ResponseHandler();
				if(requestParams.get("validationType").toString().equalsIgnoreCase("PAN"))
				{
					response = responseHandler.responseTraverseCRIFPAN(out.toString());
				}
				else if(requestParams.get("validationType").toString().equalsIgnoreCase("DOB")){
					response = responseHandler.responseTraverseCRIFDOB(out.toString());
				}
				logger.info("Response Handler : End");
			} 

			catch (Exception e) 
			{
				logger.error("CRIF service : Error in response : "+e.getMessage());
			}

			logger.debug("http status code "+ conn.getResponseMessage());
			br.close();
		}     
		catch (Exception e) 
		{  
			logger.error("CRIF service : Error : "+e.getMessage());
			response = null;
		}  
		finally
		{
			conn.disconnect();
		}
		logger.info("CRIF service calling: END");
		return response;
	}
	
	private String getAddress(Map<String,Object> requestData)
	{
		logger.info("CRIF service :  Appending Address :  START ");
		String address="";
		try
		{
			String houseNo = requestData.get("houseNo")!=null?requestData.get("houseNo").toString():"";
			String street = requestData.get("street")!=null?requestData.get("street").toString():"";
			String location = requestData.get("location")!=null?requestData.get("location").toString():"";
			String subDistrict = requestData.get("subDistrict")!=null?requestData.get("subDistrict").toString():"";


			address += (houseNo.equals("")?"":houseNo+" ")+(street.equals("")?"":street+" "); 
			address += (location.equals("")?"":location+" ");
			address += (subDistrict.equals("")?"":subDistrict+" ");
			logger.info("address :" +address );
			logger.debug("Final Address : "+address);
		}
		catch(Exception ex)
		{
			address="False";
			logger.error("CRIF service :  Error while appending address. "+ex.getMessage());
			ex.printStackTrace();
		}

		logger.info("CRIF service :  Appending Address :  END ");
		return address;
	}

	//################################################################################################
	//	###############    CREDIT BUREAU 2.0 #####################################################

	public Map<String,String> callNeoService(Map<String,Object> requestParams,Environment env)
	{
		logger.info("CRIF SERVICE : callNeoService : STARTED ::");
		HttpURLConnection conn = null;
		Map<String, String> response = null;
		Map<String, String> respAcknwldge = null;
		String requestxml=null;
		String Issuexml=null;

		try
		{
			//version 2.0 starts
			String V2_PRODUCT_TYP=env.getProperty("com.qualtech.pan2.resource.CRIF.PRODUCT-TYP");
			String V2_PRODUCT_VER=env.getProperty("com.qualtech.pan2.resource.CRIF.PRODUCT-VER");
			String V2_REQ_MBR=env.getProperty("com.qualtech.pan2.resource.CRIF.REQ-MBR");
			String V2_SUB_MBR_ID=env.getProperty("com.qualtech.pan2.resource.CRIF.SUB-MBR-ID");
			String V2_INQ_DT_TM=env.getProperty("com.qualtech.pan2.resource.CRIF.INQ-DT-TM");
			String V2_REQ_VOL_TYP=env.getProperty("com.qualtech.pan2.resource.CRIF.REQ-VOL-TYP");
			String V2_REQ_ACTN_TYP=env.getProperty("com.qualtech.pan2.resource.CRIF.REQ-ACTN-TYP");
			String V2_TEST_FLG=env.getProperty("com.qualtech.pan2.resource.CRIF.TEST-FLG");
			String V2_AUTH_FLG=env.getProperty("com.qualtech.pan2.resource.CRIF.AUTH-FLG");
			String V2_RES_FRMT=env.getProperty("com.qualtech.pan2.resource.CRIF.RES-FRMT");
			String V2_LOS_NAME=env.getProperty("com.qualtech.pan2.resource.CRIF.LOS-NAME");
			String V2_URL=env.getProperty("com.qualtech.pan2.resource.CRIF.url");
			String V2_TIMEOUT=env.getProperty("com.qualtech.pan2.resource.CRIF.Timeout");
			String V2_USERID=env.getProperty("com.qualtech.pan2.resource.CRIF.USERID");
			String V2_PASSWORD=env.getProperty("com.qualtech.pan2.resource.CRIF.PASSWORD");
			String V2_OUTER_DELAY=env.getProperty("com.qualtech.pan2.resource.CRIF.delayTime.outer");
			String V2_INNER_DELAY=env.getProperty("com.qualtech.pan2.resource.CRIF.delayTime.inner");
			String V2_MAX_RETRY=env.getProperty("com.qualtech.pan2.resource.CRIF.maxRetryCount");
			String V2_REQTYP=env.getProperty("com.qualtech.pan2.resource.CRIF.REQTYP");

			
			
			String ValidationType=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("ValidationType")).toString();
			String fname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("fname")).toString().trim();
			String mname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mname")).toString().trim();
			String lname=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("lname")).toString().trim();
			String dob=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("dob")).toString().trim();
			String pan=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("pan")).toString().trim();
			String vill_city=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("vill_city")).toString().trim();
			String stateCode=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("stateCode")).toString().trim();
			String postalCode=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("postalCode")).toString().trim();
			String mobileno=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mobileno")).toString().trim();
			String email=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("email")).toString().trim();
			String gender=(((Map)((List)((Map)((Map)requestParams.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("gender")).toString().toUpperCase().trim();

			logger.debug("CRIF service : Making Request xml. ");

			if(ValidationType.equalsIgnoreCase("ALL"))
			{
				logger.debug("CRIF service : Request ValidationType = "+ValidationType);
				requestxml="	<REQUEST-REQUEST-FILE>	"+
						"	<HEADER-SEGMENT>	"+
						"<PRODUCT-TYP>"+V2_PRODUCT_TYP+"</PRODUCT-TYP>	"+
						"	<PRODUCT-VER>"+V2_PRODUCT_VER+"</PRODUCT-VER>	"+
						"	<REQ-MBR>"+V2_REQ_MBR+"</REQ-MBR>	"+
						"	<SUB-MBR-ID>"+V2_SUB_MBR_ID+"</SUB-MBR-ID>	"+
						"	<INQ-DT-TM>"+V2_INQ_DT_TM+"</INQ-DT-TM>	"+
						"	<REQ-VOL-TYP>"+V2_REQ_VOL_TYP+"</REQ-VOL-TYP>	"+
						"	<REQ-ACTN-TYP>"+V2_REQ_ACTN_TYP+"</REQ-ACTN-TYP>	"+
						"	<TEST-FLG>"+V2_TEST_FLG+"</TEST-FLG>	"+
						"	<AUTH-FLG>"+V2_AUTH_FLG+"</AUTH-FLG>	"+
						"	<RES-FRMT>"+V2_RES_FRMT+"</RES-FRMT>	"+
						"	<LOS-NAME>"+V2_LOS_NAME+"</LOS-NAME>	"+
						"	<REQ-SERVICE-TYPE>ALL</REQ-SERVICE-TYPE>	"+
						"	</HEADER-SEGMENT>	"+
						"	<INQUIRY>	"+
						"	<APPLICANT-SEGMENT>	"+
						"	<NAME>"+fname+" "+mname+" "+lname+"</NAME>	"+
						"	<DOB-DATE>"+dob+"</DOB-DATE>	"+
						"	<PAN>"+pan+"</PAN>	"+
						"	<UID></UID>	"+
						"	<ADDRESS>"+getNeoAddress(requestParams)+" "+vill_city+" "+stateCode+" "+postalCode+"</ADDRESS>	"+
						"	<CITY>"+vill_city+"</CITY>	"+
						"	<STATE>"+stateCode+"</STATE>	"+
						"	<PIN>"+postalCode+"</PIN>	"+
						"	<PHONE>"+mobileno+"</PHONE>	"+
						"	<EMAIL>"+email+"</EMAIL>	"+
						"	<RELATION-TYPE></RELATION-TYPE>	"+
						"	<RELATION-VALUE></RELATION-VALUE>	"+
						"	<NOMINEE-TYPE></NOMINEE-TYPE>	"+
						"	<NOMINEE-VALUE></NOMINEE-VALUE>	"+
						"	<GENDER-TYPE>"+getGenderCode(gender)+"</GENDER-TYPE>	"+
						"	<GENDER-VALUE>"+gender+"</GENDER-VALUE>	"+
						"	<OTHER-DETAILS>	"+
						"	<NAME>BACD BEGAM</NAME>	"+
						"	<ADDRESSES>	"+
						"	<ADDRESS>	"+
						"	<TYPE>D01</TYPE>	"+
						"	<ADDRESS-1>"+getNeoAddress(requestParams)+"</ADDRESS-1>	"+
						"	<CITY>"+vill_city+"</CITY>	"+
						"	<STATE>"+stateCode+"</STATE>	"+
						"	<PIN>"+postalCode+"</PIN>	"+
						"	</ADDRESS>	"+
						"	</ADDRESSES>	"+
						"	<IDS>	"+
						"	<ID>	"+
						"	<TYPE></TYPE>	"+
						"	<VALUE></VALUE>	"+
						"	</ID>	"+
						"	</IDS>	"+
						"	<PHONES>	"+
						"	<PHONE>	"+
						"	<TELE-NO-TYPE>P01</TELE-NO-TYPE>	"+
						"	<TELE-NO>"+mobileno+"</TELE-NO>	"+
						"	</PHONE>	"+
						"	</PHONES>	"+
						"	<EMAILS>	"+
						"	<EMAIL>"+email+"</EMAIL>	"+
						"	</EMAILS>	"+
						"	</OTHER-DETAILS>	"+
						"	</APPLICANT-SEGMENT>	"+
						"	<APPLICATION-SEGMENT>	"+
						"	<INQUIRY-UNIQUE-REF-NO></INQUIRY-UNIQUE-REF-NO>	"+
						"	<CREDT-INQ-PURPS-TYP>CP07</CREDT-INQ-PURPS-TYP>	"+
						"	<CREDT-INQ-PURPS-TYP-DESC>InsuranceRequest</CREDT-INQ-PURPS-TYP-DESC>	"+
						"	<CREDT-RPT-ID></CREDT-RPT-ID>	"+
						"	<CREDT-REQ-TYP>INDV</CREDT-REQ-TYP>	"+
						"	<REQUEST-DT-TM>"+getCurrentDate()+"</REQUEST-DT-TM>	"+
						"	<REPORT-ID></REPORT-ID>	"+
						"	<BRANCH-ID>59</BRANCH-ID>	"+
						"	<APP-ID></APP-ID>	"+
						"	<AMOUNT>10,000</AMOUNT>	"+
						"	</APPLICATION-SEGMENT>	"+
						"	</INQUIRY>	"+
						"	</REQUEST-REQUEST-FILE>	";

			}

			else if(ValidationType.equalsIgnoreCase("PANDOB"))
			{
				logger.debug("CRIF service : Request ValidationType = "+ValidationType);
				requestxml="	<REQUEST-REQUEST-FILE>	"+
						"	<HEADER-SEGMENT>	"+
						"<PRODUCT-TYP>"+V2_PRODUCT_TYP+"</PRODUCT-TYP>	"+
						"	<PRODUCT-VER>"+V2_PRODUCT_VER+"</PRODUCT-VER>	"+
						"	<REQ-MBR>"+V2_REQ_MBR+"</REQ-MBR>	"+
						"	<SUB-MBR-ID>"+V2_SUB_MBR_ID+"</SUB-MBR-ID>	"+
						"	<INQ-DT-TM>"+V2_INQ_DT_TM+"</INQ-DT-TM>	"+
						"	<REQ-VOL-TYP>"+V2_REQ_VOL_TYP+"</REQ-VOL-TYP>	"+
						"	<REQ-ACTN-TYP>"+V2_REQ_ACTN_TYP+"</REQ-ACTN-TYP>	"+
						"	<TEST-FLG>"+V2_TEST_FLG+"</TEST-FLG>	"+
						"	<AUTH-FLG>"+V2_AUTH_FLG+"</AUTH-FLG>	"+
						"	<RES-FRMT>"+V2_RES_FRMT+"</RES-FRMT>	"+
						"	<LOS-NAME>"+V2_LOS_NAME+"</LOS-NAME>	"+
						"	<REQ-SERVICE-TYPE>PAN|DOB</REQ-SERVICE-TYPE>	"+
						"	</HEADER-SEGMENT>	"+
						"	<INQUIRY>	"+
						"	<APPLICANT-SEGMENT>	"+
						"	<NAME>"+fname+" "+mname+" "+lname+"</NAME>	"+
						"	<DOB-DATE>"+dob+"</DOB-DATE>	"+
						"	<PAN>"+pan+"</PAN>	"+
						"	<UID></UID>	"+
						"	<ADDRESS>"+getNeoAddress(requestParams)+" "+vill_city+" "+stateCode+" "+postalCode+"</ADDRESS>	"+
						"	<CITY>"+vill_city+"</CITY>	"+
						"	<STATE>"+stateCode+"</STATE>	"+
						"	<PIN>"+postalCode+"</PIN>	"+
						"	<PHONE>"+mobileno+"</PHONE>	"+
						"	<EMAIL>"+email+"</EMAIL>	"+
						"	<RELATION-TYPE></RELATION-TYPE>	"+
						"	<RELATION-VALUE></RELATION-VALUE>	"+
						"	<NOMINEE-TYPE></NOMINEE-TYPE>	"+
						"	<NOMINEE-VALUE></NOMINEE-VALUE>	"+
						"	<GENDER-TYPE>"+getGenderCode(gender)+"</GENDER-TYPE>	"+
						"	<GENDER-VALUE>"+gender+"</GENDER-VALUE>	"+
						"	<OTHER-DETAILS>	"+
						"	<NAME>BACD BEGAM</NAME>	"+
						"	<ADDRESSES>	"+
						"	<ADDRESS>	"+
						"	<TYPE>D01</TYPE>	"+
						"	<ADDRESS-1>"+getNeoAddress(requestParams)+"</ADDRESS-1>	"+
						"	<CITY>"+vill_city+"</CITY>	"+
						"	<STATE>"+stateCode+"</STATE>	"+
						"	<PIN>"+postalCode+"</PIN>	"+
						"	</ADDRESS>	"+
						"	</ADDRESSES>	"+
						"	<IDS>	"+
						"	<ID>	"+
						"	<TYPE></TYPE>	"+
						"	<VALUE></VALUE>	"+
						"	</ID>	"+
						"	</IDS>	"+
						"	<PHONES>	"+
						"	<PHONE>	"+
						"	<TELE-NO-TYPE>P01</TELE-NO-TYPE>	"+
						"	<TELE-NO>"+mobileno+"</TELE-NO>	"+
						"	</PHONE>	"+
						"	</PHONES>	"+
						"	<EMAILS>	"+
						"	<EMAIL>"+email+"</EMAIL>	"+
						"	</EMAILS>	"+
						"	</OTHER-DETAILS>	"+
						"	</APPLICANT-SEGMENT>	"+
						"	<APPLICATION-SEGMENT>	"+
						"	<INQUIRY-UNIQUE-REF-NO></INQUIRY-UNIQUE-REF-NO>	"+
						"	<CREDT-INQ-PURPS-TYP>CP07</CREDT-INQ-PURPS-TYP>	"+
						"	<CREDT-INQ-PURPS-TYP-DESC>InsuranceRequest</CREDT-INQ-PURPS-TYP-DESC>	"+
						"	<CREDT-RPT-ID></CREDT-RPT-ID>	"+
						"	<CREDT-REQ-TYP>INDV</CREDT-REQ-TYP>	"+
						"	<REQUEST-DT-TM>"+getCurrentDate()+"</REQUEST-DT-TM>	"+
						"	<REPORT-ID></REPORT-ID>	"+
						"	<BRANCH-ID>59</BRANCH-ID>	"+
						"	<APP-ID></APP-ID>	"+
						"	<AMOUNT>10,000</AMOUNT>	"+
						"	</APPLICATION-SEGMENT>	"+
						"	</INQUIRY>	"+
						"	</REQUEST-REQUEST-FILE>	";
			}
			logger.debug("CRIF service: Request XML:"+requestxml);
			logger.info("Request XML:"+requestxml);
			XTrustProvider xTrustProvider =new XTrustProvider();
			xTrustProvider.install();

			logger.debug("CRIF service: First call to CRIF: START");
			URL url = new URL(V2_URL);

			//For Dev we need to enable this
			//Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
			//conn = (HttpURLConnection) url.openConnection(proxy);
			//COMMENT WHILE DEVELOPMENT
			//conn = (HttpURLConnection) url.openConnection();
			
			System.setProperty("jsse.enableSNIExtension", "false");
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/xml");	
			conn.addRequestProperty("productVersion", V2_PRODUCT_VER);
			conn.addRequestProperty("mbrid", V2_REQ_MBR);
			conn.addRequestProperty("productType", V2_PRODUCT_TYP);
			conn.addRequestProperty("password", V2_PASSWORD);
			conn.addRequestProperty("reqVolType", V2_REQTYP);
			conn.addRequestProperty("UserID", V2_USERID);
			conn.addRequestProperty("requestXml", requestxml);

			conn.setConnectTimeout(Integer.parseInt(V2_TIMEOUT));
			conn.setReadTimeout(Integer.parseInt(V2_TIMEOUT));

			conn.setDoOutput(true);
			conn.setDoInput(true);

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			StringBuilder out1= new StringBuilder();
			while ((output = br.readLine()) != null) 
			{
				logger.info(output);
				if(output!=null)
					out1.append(output);
			}
			try {br.close();} catch (Exception e2) {}
			logger.debug("CRIF service: First call to CRIF: End");
			logger.debug("CRIF service: Received Acknowledge XML :"+out1.toString());
			logger.info("CRIF service: Acknowledge XML :"+ out1.toString());

			try
			{
				logger.info("CRIF service: Traversing the Acknowledgment Response from CRIF : START");
				ResponseHandler responseHandler = new ResponseHandler();

				//Traversing the Acknowledgment Response from CRIF
				respAcknwldge = responseHandler.responseTraverseNeoAcknwldge(out1.toString());

				logger.info("CRIF service: Traversing the Acknowledgment Response from CRIF : END");

				if(respAcknwldge.get("ERROR_CODE")!=null && respAcknwldge.get("ERROR_CODE").equalsIgnoreCase("") )
				{
					logger.info("CRIF service : Request Successfully processed : No Error in Ackwledge Xml");	
					if(respAcknwldge!=null 
							&& !respAcknwldge.get("INQ_REF-NO").equalsIgnoreCase("") && !respAcknwldge.get("INQ_REF-NO").equals(null)
							&& !respAcknwldge.get("REPORT-ID").equalsIgnoreCase("") && !respAcknwldge.get("REPORT-ID").equals(null)
							&& !respAcknwldge.get("REQUEST_DT").equalsIgnoreCase("") && !respAcknwldge.get("REQUEST_DT").equals(null)
							)
					{
						//Making the second call to the CRIF with issue xml

						logger.debug("CRIF service: Making Issue xml.");
						if(ValidationType.equalsIgnoreCase("ALL"))
						{
							Issuexml = "	<REQUEST-REQUEST-FILE>	"+
									"	 <HEADER-SEGMENT>	"+
									"	<PRODUCT-TYP>"+V2_PRODUCT_TYP+"</PRODUCT-TYP>	"+
									"	<PRODUCT-VER>"+V2_PRODUCT_VER+"</PRODUCT-VER>	"+
									"	<REQ-MBR>"+V2_REQ_MBR+"</REQ-MBR>	"+
									"	<SUB-MBR-ID>"+V2_SUB_MBR_ID+"</SUB-MBR-ID>	"+
									"	<INQ-DT-TM>"+V2_INQ_DT_TM+"</INQ-DT-TM>	"+
									"	<REQ-VOL-TYP>"+V2_REQ_VOL_TYP+"</REQ-VOL-TYP>	"+
									"	<REQ-ACTN-TYP>"+V2_REQ_ACTN_TYP+"</REQ-ACTN-TYP>	"+
									"	<TEST-FLG>"+V2_TEST_FLG+"</TEST-FLG>	"+
									"	<AUTH-FLG>"+V2_AUTH_FLG+"</AUTH-FLG>	"+
									"	<RES-FRMT>"+V2_RES_FRMT+"</RES-FRMT>	"+
									"	<LOS-NAME>"+V2_LOS_NAME+"</LOS-NAME>	"+
									"	<REQ-SERVICE-TYPE>ALL</REQ-SERVICE-TYPE>	"+
									"	 </HEADER-SEGMENT>	"+
									"		"+
									"	 <INQUIRY>	"+
									"	  <INQUIRY-UNIQUE-REF-NO>"+respAcknwldge.get("INQ_REF-NO")+"</INQUIRY-UNIQUE-REF-NO>	"+
									"	 <REQUEST-DT-TM>"+respAcknwldge.get("REQUEST_DT")+"</REQUEST-DT-TM>	"+
									"	 <REPORT-ID>"+respAcknwldge.get("REPORT-ID")+"</REPORT-ID>	"+
									"	 </INQUIRY>	"+
									"	 </REQUEST-REQUEST-FILE>	";

						}

						else if(ValidationType.equalsIgnoreCase("PANDOB"))
						{
							Issuexml = "	<REQUEST-REQUEST-FILE>	"+
									"	 <HEADER-SEGMENT>	"+
									"	<PRODUCT-TYP>"+V2_PRODUCT_TYP+"</PRODUCT-TYP>	"+
									"	<PRODUCT-VER>"+V2_PRODUCT_VER+"</PRODUCT-VER>	"+
									"	<REQ-MBR>"+V2_REQ_MBR+"</REQ-MBR>	"+
									"	<SUB-MBR-ID>"+V2_SUB_MBR_ID+"</SUB-MBR-ID>	"+
									"	<INQ-DT-TM>"+V2_INQ_DT_TM+"</INQ-DT-TM>	"+
									"	<REQ-VOL-TYP>"+V2_REQ_VOL_TYP+"</REQ-VOL-TYP>	"+
									"	<REQ-ACTN-TYP>"+V2_REQ_ACTN_TYP+"</REQ-ACTN-TYP>	"+
									"	<TEST-FLG>"+V2_TEST_FLG+"</TEST-FLG>	"+
									"	<AUTH-FLG>"+V2_AUTH_FLG+"</AUTH-FLG>	"+
									"	<RES-FRMT>"+V2_RES_FRMT+"</RES-FRMT>	"+
									"	<LOS-NAME>"+V2_LOS_NAME+"</LOS-NAME>	"+
									"	<REQ-SERVICE-TYPE>PAN|DOB</REQ-SERVICE-TYPE>	"+
									"	 </HEADER-SEGMENT>	"+
									"		"+
									"	 <INQUIRY>	"+
									"	  <INQUIRY-UNIQUE-REF-NO>"+respAcknwldge.get("INQ_REF-NO")+"</INQUIRY-UNIQUE-REF-NO>	"+
									"	 <REQUEST-DT-TM>"+respAcknwldge.get("REQUEST_DT")+"</REQUEST-DT-TM>	"+
									"	 <REPORT-ID>"+respAcknwldge.get("REPORT-ID")+"</REPORT-ID>	"+
									"	 </INQUIRY>	"+
									"	 </REQUEST-REQUEST-FILE>	";
						}
						logger.debug("CRIF service: Issue XML:"+Issuexml);
						logger.debug("CRIF service: Applying delay in second call");
						//  *****************************DELAY*******************************************************
						try 
						{
							// For UAT delay should be 6000
							//For Production delay should be 3000
							Thread.sleep(Integer.parseInt(V2_OUTER_DELAY));
						} catch(InterruptedException ex) 
						{      
							Thread.currentThread().interrupt();
						}
						//	*****************************************************************************************	
						logger.info("Issue XML :"+Issuexml);

						//###################################################
						// Hit Soap service and Retry for crif starts here 
						//###################################################
						int issueRetry = 0;
						int maxRetry = Integer.parseInt(V2_MAX_RETRY);//configurable
						String output2 = "";
						StringBuilder out2= new StringBuilder();
						while(issueRetry <= maxRetry)
						{
							try 
							{
								if(issueRetry > 0)
								{
									logger.info("CRIF ISSUE RETRY NO :: "+issueRetry +" :INNER DELAY" );
									//For Production delay should be 3000
									Thread.sleep(Integer.parseInt(V2_INNER_DELAY));
									
								}
								// code to hit crif soap api service
								logger.debug("CRIF service: Second call to CRIF with Issue xml: START");
								xTrustProvider =new XTrustProvider();
								xTrustProvider.install();

								url = new URL(V2_URL);
								//For Dev we need to enable this
								//conn = (HttpURLConnection) url.openConnection(proxy);
								//conn = (HttpURLConnection) url.openConnection();
								
								System.setProperty("jsse.enableSNIExtension", "false");
								String DevMode1 = env.getProperty("spring.enable.proxy.development");
								if(DevMode1!=null && !DevMode1.equalsIgnoreCase("") && DevMode1.equalsIgnoreCase("Y"))
								{
									logger.info("We are running in Development Mode So Proxy Enabled");
									Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
									conn = (HttpURLConnection) url.openConnection(proxy);
								}
								else
								{
									conn = (HttpURLConnection) url.openConnection();
								}
								
								conn.setRequestMethod("POST");
								conn.setRequestProperty("Content-Type", "application/xml");	
								conn.addRequestProperty("productVersion", V2_PRODUCT_VER);
								conn.addRequestProperty("mbrid", V2_REQ_MBR);
								conn.addRequestProperty("productType", V2_PRODUCT_TYP);
								conn.addRequestProperty("password", V2_PASSWORD);
								conn.addRequestProperty("reqVolType", V2_REQTYP);
								conn.addRequestProperty("UserID", V2_USERID);
								conn.addRequestProperty("requestXml", Issuexml);

								conn.setConnectTimeout(Integer.parseInt(V2_TIMEOUT));
								conn.setReadTimeout(Integer.parseInt(V2_TIMEOUT));

								conn.setDoOutput(true);
								conn.setDoInput(true);

								BufferedReader br1 = new BufferedReader(new InputStreamReader((conn.getInputStream())));
								while ((output2 = br1.readLine()) != null) 
								{
									logger.info(output2);
									if(output2!=null)
										out2.append(output2);
								}
								try {br1.close(); } catch (Exception e1) {}

								logger.debug("CRIF service: Second call to CRIF with Issue xml: End");
								logger.debug("CRIF service: Final response xml received from CRIF :"+out2.toString());

								logger.info("CRIF : FinalResponse XML: "+out2.toString());

								String crifErrorOutput = out2.toString();

								if(crifErrorOutput != null || !"".equalsIgnoreCase(crifErrorOutput))
								{
									String errorXml=null;
									String errorResponsetype=null;
									String errorCode = "";
									String errorStatus = "";
									boolean errorResponseFlag = false;
									try
									{
										if(crifErrorOutput.contains("<ERROR>"))
										{
											errorXml = (crifErrorOutput.substring(crifErrorOutput.indexOf("<ERROR>"),crifErrorOutput.lastIndexOf("</ERROR>")))+"</ERROR>";
											logger.info("errorXml Crif : "+errorXml);
										}
										if(crifErrorOutput.contains("<REPONSE-TYPE>"))
										{
											errorResponsetype = (crifErrorOutput.substring(crifErrorOutput.indexOf("<REPONSE-TYPE>"),crifErrorOutput.lastIndexOf("</REPONSE-TYPE>")))+"</REPONSE-TYPE>";
											logger.info("errorXML ResponseType Crif  :: "+errorResponsetype);
										}


										try
										{
											if(errorXml != null && !errorXml.equals(""))
											{
												String subTag[] = new String[1];
												subTag[0]="CODE";
												ArrayList<HashMap<String,String>> getXmlMapValue = new GetXMLValues().getListOfXmlValues(errorXml, "ERROR", subTag);
												logger.info("getXmlMapValue : ERROR xml VALUE : "+getXmlMapValue);
												errorCode = getXmlMapValue.iterator().next().get("CODE");

											}
											if(errorResponsetype != null && !errorResponsetype.equals(""))
											{
												String subTag[] = new String[1];
												subTag[0]="REPONSE-TYPE";
												String str = "<RESPONSE_INFO>"+ errorResponsetype +"</RESPONSE_INFO>";
												ArrayList<HashMap<String,String>> getXmlMapValue = new GetXMLValues().getListOfXmlValues(str, "RESPONSE_INFO", subTag);
												logger.info("getXmlMapValue : RESPONSE_INFO xml VALUE : "+getXmlMapValue);
												errorStatus = getXmlMapValue.iterator().next().get("REPONSE-TYPE");
											}											
										}
										catch (Exception e) 
										{
											logger.error("Exception Occured while parsing crif error code :: ACTUAL RESPONSE NOT FOUND FROM CRIF!! "+e);
											errorResponseFlag = true;
										}

										//Final checking for error code
										if(errorCode.equalsIgnoreCase("INPROCESS") || errorStatus.equalsIgnoreCase("ERROR") || errorResponseFlag)
										{
											//Retry counter updated starts
											logger.info("CRIF SERVICE CALLING ATTEMPT NO "+issueRetry+" ENDS :: NOW RETRIYING AGAIN ::");
											issueRetry++;
										}
										else
										{
											// No ERROR FOUND IN RESPONSE (PERFECT RESPONSE FOUND >> PROCEED)
											try
											{
												logger.info("CRIF SERVICE CALLING ATTEMPT NO "+issueRetry+" SUCCEEDED :: NOW TRAVARSING  RESPONSE STARTS ::");
												responseHandler = new ResponseHandler();
												// Traversing the Final response from the CRIF
												if(ValidationType.equalsIgnoreCase("ALL"))
												{
													response = responseHandler.responseTraverseNeoCRIFService2(out2.toString());
												}
												else if(ValidationType.equalsIgnoreCase("PANDOB"))
												{
													response = responseHandler.responseTraverseNeoCRIFService1(out2.toString());
												}
												logger.info("CRIF service: Traversing Final response : End");
											}
											catch (Exception e) 
											{
												logger.error("CRIF service: Error in Final Response : "+e.getMessage());
												logger.error("CRIF service : Error : " +e);
												response = null;
												issueRetry = 100;//means no loop will be iterateble
												break;
											}
											//validation for full data available or not
											logger.info("VALIDATING CRIF RESPONSE STARTED ::");
											if(validateFullCrifData(response,ValidationType))
											{
												logger.info("Incomplete Data found from CRIF Service :: VALIDATION FAILED ::");
												logger.info("Now Trying to Hit EQUIFAX service for Data ::");
												response = null;//crif reponse set to null
												issueRetry = 100;//means no loop will be iterateble
												break;
											}
											else
											{
												logger.info("PERFECT Data found from CRIF Service :: VALIDATION SUCCESS ::");
												logger.info("Crif BREAK section: Executed ");
												issueRetry = 100;//means no loop will be iterateble
												break;
											}
										}
									}
									catch (Exception e) 
									{
										logger.error("Exception occured in parsing crif error code :",e);
										response = null;
										issueRetry = 100;//means no loop will be iterateble
										break;
									}
								}
							} catch(InterruptedException ex) {      // For UAT delay should be 6000
								Thread.currentThread().interrupt();
								response = null;
								issueRetry = 100;//means no loop will be iterateble
								break;
							}
						}
					} 
				}
				else
				{
					logger.error("CRIF service: RequestXml not successfully processed : Error in Ackwledge Xml = "+respAcknwldge.get("ERROR_CODE"));
					logger.error("CRIF service: Skipping the second call to the CRIF");
				}
			}
			catch (Exception e) 
			{
				logger.error("CRIF service: Error in response : "+e.getMessage());
				logger.error("CRIF service : Error : " +e);
				response = null;
			}
			logger.debug("http status code "+ conn.getResponseMessage());
			br.close();
		}     
		catch (Exception e) 
		{  
			e.printStackTrace(); 
			logger.error("CRIF service : Error : " +e.getMessage());
			logger.error("CRIF service : Error : " +e);
			response = null;
		}  
		finally
		{
			conn.disconnect();
		}
		logger.info("CRIF service calling: END");
		return response;
	}


	//	 getting the current date in prescribed format. 
	public String getCurrentDate()
	{
		logger.info("CRIF service : Getting the current date in prescribed format.");
		logger.info("CRIF service : Current Date : START ");
		SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");//dd/MM/yyyy
		Date now = new Date();
		String strDate = sdfDate.format(now);
		logger.info(strDate);
		logger.debug("CRIF service : Current Date is = "+strDate);
		logger.info("CRIF service : Current Date : End ");
		return strDate;
	}


	public String getGenderCode(String reqGender)
	{
		logger.info("CRIF service : Getting gender code : START ");
		String gender ="";
		if(reqGender.equalsIgnoreCase("male"))
		{
			gender ="G01";
		}
		else if(reqGender.equalsIgnoreCase("female"))
		{
			gender ="G02";
		}
		else if(reqGender.equalsIgnoreCase("Transgender"))
		{
			gender ="G03";
		}
		else if(reqGender.equalsIgnoreCase("Un-tagged"))
		{
			gender ="G04";
		}
		logger.debug("CRIF service : Gender Code is = "+gender);
		logger.info("CRIF service : Getting gender code : End ");
		return gender;
	}

	private String getNeoAddress(Map<String,Object> requestData)
	{
		logger.info("CRIF service: Appending Address :  START ");
		String address="";
		try
		{
			String houseNo=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("houseNo")).toString().trim();
			String location=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("street")).toString().trim();
			String street=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("location")).toString().trim();
			String subDistrict=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("subDistrict")).toString().trim();

			address += (houseNo.equals("")?"":houseNo+" ")+(street.equals("")?"":street+" "); 
			address += (location.equals("")?"":location+" ");
			address += (subDistrict.equals("")?"":subDistrict+" ");
			logger.info("address :" +address );
			logger.debug("Final Address : "+address);
		}
		catch(Exception ex)
		{
			address="False";
			logger.error("CRIF service: Error while appending address. "+ex.getMessage());
			ex.printStackTrace();
		}

		logger.info("CRIF service: Appending Address :  END ");
		return address;
	}

	private boolean validateFullCrifData(Map<String, String> response ,String validationType){
		logger.info("validateFullCrifData : ValidationType : "+validationType);
		boolean flag = false;
		if(validationType.equalsIgnoreCase("ALL"))
		{
				if((response.get("PAN").toString() == null  || response.get("PAN").toString().isEmpty()) && 
					(response.get("DOB").toString() == null  || response.get("DOB").toString().isEmpty()) && 
					(response.get("NAME").toString() == null  || response.get("NAME").toString().isEmpty()) && 
					(response.get("ADDRESS").toString() == null  || response.get("ADDRESS").toString().isEmpty()) && 
					(response.get("PINCODE").toString() == null  || response.get("PINCODE").toString().isEmpty()) &&
					(response.get("MOBILE").toString() == null  || response.get("MOBILE").toString().isEmpty()) &&
					(response.get("EMAIL").toString() == null  || response.get("EMAIL").toString().isEmpty()) &&
					(response.get("OCCPTNCLS").toString() == null  || response.get("OCCPTNCLS").toString().isEmpty()) &&
					(response.get("ESTMTDINCM").toString() == null  || response.get("ESTMTDINCM").toString().isEmpty()) &&
					(response.get("CREDITSCR").toString() == null  || response.get("CREDITSCR").toString().isEmpty()) ){
					flag = true;
					logger.info("Crif Details contain null or empty value :: ALL ::");
				}
		}
		else if(validationType.equalsIgnoreCase("PANDOB"))
		{
			if((response.get("PAN").toString() == null  || response.get("PAN").toString().isEmpty()) && 
					(response.get("DOB").toString() == null  || response.get("DOB").toString().isEmpty()) && 
					(response.get("NAME").toString() == null  || response.get("NAME").toString().isEmpty())){
				flag = true;
				logger.info("Crif Details contain null or empty value :: PANDOB ::");
			}
		}
		return flag;
	}

}


