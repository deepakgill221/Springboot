package com.qc.serviceImpl;

import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.dao.NeoDao;
import com.qc.entity.PlanDetailBean;
import com.qc.service.PlanDetailService;

@Service
public class PlanDetailServiceImpl implements PlanDetailService 
{
	private static Logger logger = LogManager.getLogger(PlanDetailServiceImpl.class);
	@Autowired Environment env;
	@Autowired NeoDao neoDao;


	@Override
	@Cacheable(value="maxserviceCache", key="#planid.concat('-').concat(#rtbl_age_dur).concat('-').concat(#rtbl_sex)", unless="#result == null")
	public List<PlanDetailBean> callPlanDetailService(String planid,String rtbl_age_dur,String rtbl_sex)  throws SQLException , Exception
	{
		logger.info("Going to Hit DB : data not exist in cache");
		return neoDao.callPlanDetail(planid, rtbl_age_dur, rtbl_sex);
	}
}
