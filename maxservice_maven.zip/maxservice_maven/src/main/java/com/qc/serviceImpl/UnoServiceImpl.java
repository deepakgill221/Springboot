package com.qc.serviceImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.api.request.PartialWithDrawalRequest;
import com.qc.api.request.TotalPremiumRequest;
import com.qc.api.response.PartialWithDrawalResponse;
import com.qc.api.response.TotalPremiumResponse;
import com.qc.dao.UnoDao;
import com.qc.dto.ApiRequest;
import com.qc.dto.ApiResponse;
import com.qc.dto.ERRORSTATUS;
import com.qc.dto.ErrorInfo;
import com.qc.dto.Payload;
import com.qc.dto.UserInfo;
import com.qc.service.UnoService;

@Service
public class UnoServiceImpl implements UnoService
{
	private static Logger logger = LogManager.getLogger(UnoServiceImpl.class);

	@Autowired Environment env;
	@Autowired UnoDao unoDao;
	@Autowired HttpSession httpSession;

//	@Override
//	public PerfiosEntity getUnoData(PerfiosEntity perfiosEntity) 
//	{
//		try 
//		{
//			logger.info("Getting HTML Content Process : Start");
//			unoDao.getUnoData(perfiosEntity);
//			logger.info("Getting HTML Content Process : End");
//		} 
//		catch (Exception e) 
//		{
//			logger.error("We are in Exception : "+e);
//		}
//		return perfiosEntity;
//	}
	
//	@Override
//	public PerfiosEntity getUnoData1(PerfiosEntity perfiosEntity) 
//	{
//		try 
//		{
//			logger.info("Getting HTML Content Process : Start");
//			unoDao.getUnoData1(perfiosEntity);
//			logger.info("Getting HTML Content Process : End");
//		} 
//		catch (Exception e) 
//		{
//			logger.error("We are in Exception : "+e);
//		}
//		return perfiosEntity;
//	}

	@Override
	public ApiResponse getPartialWithDrawalDataService(ApiRequest apiRequest) {
		
		logger.info("Method : getPartialWithDrawalDataService service method :: START :: API_RESPONSE :: ");
		ApiResponse response=null;
		UserInfo userInfo = new UserInfo();
		ErrorInfo errorInfo = new ErrorInfo();
		Payload payload = new Payload();
		List<Object> listPartialWithDrawal = new ArrayList<>();
		PartialWithDrawalResponse partialWithDrawalResponse = new PartialWithDrawalResponse();
	
		try{
			List<Object> listTransactions = (List<Object>) apiRequest.getPayload().getTransactions();
			ObjectMapper m = new ObjectMapper();
			@SuppressWarnings("unchecked")
			Map<String,Object> props = m.convertValue(listTransactions.iterator().next(), Map.class);
			PartialWithDrawalRequest partialWithDrawalRequest = m.convertValue(props, PartialWithDrawalRequest.class);
			if(partialWithDrawalRequest != null && !partialWithDrawalRequest.getPolicyId().isEmpty() && !partialWithDrawalRequest.getStartDate().isEmpty() && !partialWithDrawalRequest.getEndDate().isEmpty()){
				if(validateDate(partialWithDrawalRequest.getStartDate().trim(),"dd-MMM-yyyy") && validateDate(partialWithDrawalRequest.getEndDate().trim(),"dd-MMM-yyyy")){
					logger.info("Processing partial withdrawal : Starts");
					try{
						partialWithDrawalResponse=unoDao.getWithDrawalResponseDao(partialWithDrawalRequest);
					}catch(Exception ee){
						logger.info("error occured while feteching data from PROC PR_PARTIAL_WITHDRAWL :: "+ee);
					}
					partialWithDrawalResponse.setAmount(partialWithDrawalResponse.getAmount());
					partialWithDrawalResponse.setComment(partialWithDrawalResponse.getComment());
					//partialWithDrawalResponse.setAmount("5552010.00");
					//partialWithDrawalResponse.setComment("comment");
					listPartialWithDrawal.add(partialWithDrawalResponse);
					//payload.setTransactions((List<Transactions>)listPartialWithDrawal);
					payload.setTransactions(listPartialWithDrawal);
					errorInfo.setCode("200");
					errorInfo.setStatus(ERRORSTATUS.SUCCESS);
					errorInfo.setMessage("Partial withdrawal details fetched successfully!");
					errorInfo.setDescription("");
					response = new ApiResponse(userInfo, errorInfo, payload);
				}else{
					logger.info("Invalid Date format");
					errorInfo.setCode("200");
					errorInfo.setStatus(ERRORSTATUS.FAILURE);
					errorInfo.setMessage("Invalid date format!");
					errorInfo.setDescription("Date format should be dd-MMM-yyyy format only eg; 12-NOV-2016!");
					response = new ApiResponse(userInfo, errorInfo, payload);
				}
			}else{
				logger.info("Invalid Request Json");
				errorInfo.setCode("200");
				errorInfo.setStatus(ERRORSTATUS.FAILURE);
				errorInfo.setMessage("Invalid request json!");
				errorInfo.setDescription("Please verify your request json it could not be empty and invalid key!");
				response = new ApiResponse(userInfo, errorInfo, payload);
			}
		}catch (Exception e) {
			logger.info("Invalid Request Json");
			errorInfo.setCode("500");
			errorInfo.setStatus(ERRORSTATUS.FAILURE);
			errorInfo.setMessage("Invalid request json!");
			errorInfo.setDescription("Please verify your request json! : ");
			response = new ApiResponse(userInfo, errorInfo, payload);
		}
		logger.info("Method : getPartialWithDrawalDataService :: ENDS :: API_RESPONSE :: "+response.toString());
		return response;
	}

	public boolean validateDate(String dateToValidate, String dateFromat){
		logger.info("Input Date :: "+dateToValidate +": Date Format : "+dateFromat);
		if(dateToValidate == null){
			return false;
		}

		SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
		sdf.setLenient(false);

		try 
		{
			//if not valid, it will throw ParseException
			Date date = sdf.parse(dateToValidate);

		} catch (ParseException e) {

			e.printStackTrace();
			return false;
		}

		return true;
	}

	@Override
	public ApiResponse getTotalPremiumDataService(ApiRequest apiRequest) {
		logger.info("Method : getTotalPremiumDataService service method :: START :: API_RESPONSE :: ");
		ApiResponse response=null;
		UserInfo userInfo = new UserInfo();
		ErrorInfo errorInfo = new ErrorInfo();
		Payload payload = new Payload();
		List<Object> responseList = new ArrayList<Object>();
		TotalPremiumResponse totalPremiumResponse = new TotalPremiumResponse();
		try{
			List<Object> listTransactions = (List<Object>) apiRequest.getPayload().getTransactions();
			ObjectMapper m = new ObjectMapper();
			@SuppressWarnings("unchecked")
			Map<String,Object> props = m.convertValue(listTransactions.iterator().next(), Map.class);
			TotalPremiumRequest totalPremiumRequest = m.convertValue(props, TotalPremiumRequest.class);
			if(totalPremiumRequest != null && !totalPremiumRequest.getPolicyId().isEmpty())
			{ 
				logger.info("Processing total premium : Starts");
				try{
					totalPremiumResponse=unoDao.getTotalPremiumDataDao(totalPremiumRequest);
				}catch(Exception ee){
					logger.info("error occured while feteching data from PROC PR_GETPOL_REQRD_PREM :: "+ee);
				}
				
				totalPremiumResponse.setRequiredPremium(totalPremiumResponse.getRequiredPremium());
				//totalPremiumResponse.setRequiredPremium("5552010.00");
				responseList.add(totalPremiumResponse);
				//payload.setTransactions((List<Transactions>)totalPremiumResponse);
				payload.setTransactions(responseList);
				errorInfo.setCode("200");
				errorInfo.setStatus(ERRORSTATUS.SUCCESS);
				errorInfo.setMessage("Total premium details fetched successfully!");
				errorInfo.setDescription("");
				response = new ApiResponse(userInfo, errorInfo, payload);
			}else{
				logger.info("Invalid Request Json");
				errorInfo.setCode("200");
				errorInfo.setStatus(ERRORSTATUS.FAILURE);
				errorInfo.setMessage("Invalid Policy Id!");
				errorInfo.setDescription("PolicyId could not be empty and null value!");
				response = new ApiResponse(userInfo, errorInfo, payload);
			}
		}catch (Exception e) {
			logger.info("Invalid Request Json :TrackerId");
			errorInfo.setCode("500");
			errorInfo.setStatus(ERRORSTATUS.FAILURE);
			errorInfo.setMessage("Invalid request json!");
			errorInfo.setDescription("Please verify your request json! : ");
			response = new ApiResponse(userInfo, errorInfo, payload);
		}
		logger.info("Method : getTotalPremiumDataService service method :: START :: API_RESPONSE :: "+response.toString());
		return response;
	}
}
