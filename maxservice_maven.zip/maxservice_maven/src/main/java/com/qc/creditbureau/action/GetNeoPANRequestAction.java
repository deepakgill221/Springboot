package com.qc.creditbureau.action;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.Environment;

import com.qc.service.ExternalServices;
import com.qc.utils.Base64ArrayUtility;
import com.qc.utils.Commons;
import com.qc.utils.FlatFileMaker;
import com.qc.utils.ObjectFactory;
import com.qc.utils.PDFMaker;

public class GetNeoPANRequestAction 
{
	private static Logger logger = LogManager.getLogger(GetNeoPANRequestAction.class);

	public String processNeoPANRequest(String requestJson, Environment env,Map requestData)
	{
		String PRIORITY=env.getProperty("com.qualtech.pan2.resource.priority");
		String CRIF_STATUS=env.getProperty("com.qualtech.pan2.resource.CRIF.status");
		String EQUIFAX_STATUS=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.status");
		String FLAT_FILE_PATH=env.getProperty("flatFilePath");

		String methodName = null;
		String serviceName = null;
		String app_name = "";
		String responseString = "";
		methodName = Commons.getMethodName();
		ObjectFactory of = new ObjectFactory();
		logger.info("Came inside " + methodName + "().");
		Map<String, String> responseMap = null;
		try 
		{
			if (requestData != null) 
			{
				logger.info("Request JSON:" + requestJson);

				String ValidationType = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("ValidationType")).toString();
				String fname = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("fname")).toString();
				String dob = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("dob")).toString();
				String pan = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("pan")).toString();
				app_name = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("app_name")).toString();
				String policyNo = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("policyNo")).toString();

				responseString += "{\"Response\": {";
				responseString += "\"ResponseInfo\": {";
				responseString += "\"UserName\": \"\",";
				responseString += "\"CreationDate\": \"\",";
				responseString += "\"CreationTime\": \"\",";
				responseString += "\"SourceInfoName\":\"\",";
				responseString += "\"RequestorToken\": \"\",";
				responseString += "\"UserEmail\": \"\",";
				responseString += "\"LastSyncDateTime\": \"\"";
				responseString += "},";
				responseString += "\"ResponsePayload\": {";
				responseString += "\"Transactions\": [";
				responseString += "{";
				responseString += "\"Key1\":\"\",";
				responseString += "\"Key2\": \"\",";
				responseString += "\"Key3\": \"\",";
				responseString += "\"Key4\": \"\",";
				responseString += "\"Key5\": \"\",";
				responseString += "\"ValidationType\": \"" + ValidationType + "\",";
				responseString += "\"TransTrackingID\": \"\",";
				responseString += "\"TransactionData\": ";

				if (ValidationType != null && !ValidationType.equalsIgnoreCase("")	
						&& ( ValidationType.equalsIgnoreCase("ALL")	|| ValidationType.equalsIgnoreCase("PANDOB") )
						&& fname != null 	&& !fname.equalsIgnoreCase("") 
						&& dob != null 		&& !dob.equalsIgnoreCase("") 
						&& pan != null 		&& !pan.equalsIgnoreCase("") 
						&& app_name != null	&& !app_name.equalsIgnoreCase("") 
						&& (	app_name.equalsIgnoreCase("TPP") 
								|| app_name.equalsIgnoreCase("MSALES") || app_name.equalsIgnoreCase("NEO")		
								)
						)
				{
					logger.info("Response Json Creation Started");
					try
					{
						logger.debug(" Calling Webservice Start");
						String priority = PRIORITY; 
						String[] Arr = priority.split(",");

						for (String itr : Arr)
						{
							String serviceStatus = "";
							if (itr != null && itr.equalsIgnoreCase("CRIF")) 
							{
								serviceStatus = CRIF_STATUS;
							} 
							else if (itr != null && itr.equalsIgnoreCase("EQUIFAX_2.0")) 
							{
								serviceStatus = EQUIFAX_STATUS;
							}

							serviceName = itr;
							logger.debug(" Calling Webservice Of : " + itr);
							if (serviceStatus.equalsIgnoreCase("TRUE")) {
								ExternalServices extServices = of.getService(itr);
								responseMap = extServices.callNeoService(requestData,env);
								logger.info("FULLY CALCULATED Response From ITR SERVICE " + itr + " (BOTH SERVICE) ::: "
										+ responseMap);
								if (responseMap != null)
								{
									logger.debug(" Calling Webservice Of : " + itr+ " Completed Successfully with Response");
									break;
								} 
								else 
								{
									if (itr.equalsIgnoreCase("CRIF"))
									{
										try 
										{
											// String sFileName =
											// resProp.getString("flatFilePath");
											String sFileName = FLAT_FILE_PATH;
											FlatFileMaker.generateNeoFlatFile(sFileName, requestJson, "Data not found",	app_name.toString(), itr);
										}
										catch (Exception e) 
										{
											logger.error("Error while Creating Flat File inside " + methodName + "()" + e);
										}
									}
								}
							}
						}
						logger.debug(" Calling Webservice End");

						if (responseMap != null)
						{
							if (ValidationType.equalsIgnoreCase("ALL")) 
							{
								responseString += "{\"status\":\"200\",";
								responseString += "\"statusDesc\":\"Success\",";
								responseString += "\"message\":\"Success\",";
								responseString += "\"policyNo\":\"" + policyNo + "\",";
								responseString += "\"pan\":\"" + responseMap.get("PAN") + "\",";
								responseString += "\"pan_status\":\"" + responseMap.get("PAN_STATUS") + "\",";
								responseString += "\"dob\":\"" + responseMap.get("DOB") + "\",";
								responseString += "\"dob_status\":\"" + responseMap.get("DOB_STATUS") + "\",";
								responseString += "\"name\":\"" + responseMap.get("NAME") + "\",";
								responseString += "\"name_status\":\"" + responseMap.get("NAME_STATUS") + "\",";
								responseString += "\"address\":\"" + responseMap.get("ADDRESS") + "\",";
								responseString += "\"address_status\":\"" + responseMap.get("ADDRESS_STATUS") + "\",";
								responseString += "\"pinCode\":\"" + responseMap.get("PINCODE") + "\",";
								responseString += "\"pinCode_status\":\"" + responseMap.get("PINCODE_STATUS") + "\",";
								responseString += "\"mobile\":\"" + responseMap.get("MOBILE") + "\",";
								responseString += "\"mobile_status\":\"" + responseMap.get("MOBILE_STATUS") + "\",";
								responseString += "\"emailID\":\"" + responseMap.get("EMAIL") + "\",";
								responseString += "\"emailID_status\":\"" + responseMap.get("EMAIL_STATUS") + "\",";
								responseString += "\"occptnCls\":\"" + responseMap.get("OCCPTNCLS") + "\",";
								responseString += "\"credtScr\":\"" + responseMap.get("CREDITSCR") + "\",";
								responseString += "\"estmtdIncm\":\"" + responseMap.get("ESTMTDINCM") + "\"";
								responseString += ",\"byteArr\":\"" + this.getPdfByteArrayString(responseString, FLAT_FILE_PATH, requestJson, app_name, serviceName) + "\"";
								responseString += " }";
							}
							else if (ValidationType.equalsIgnoreCase("PANDOB"))
							{
								// responseString+="{\"status\":\""+responseMap.get("RESPONSE_STATUS")+"\","
								// ;
								responseString += "{\"status\":\"200\",";
								responseString += "\"statusDesc\":\"Success\",";
								responseString += "\"message\":\"Success\",";
								responseString += "\"policyNo\":\"" + policyNo + "\",";
								responseString += "\"pan\":\"" + responseMap.get("PAN") + "\",";
								responseString += "\"pan_status\":\"" + responseMap.get("PAN_STATUS") + "\",";
								responseString += "\"dob\":\"" + responseMap.get("DOB") + "\",";
								responseString += "\"dob_status\":\"" + responseMap.get("DOB_STATUS") + "\",";
								responseString += "\"name\":\"" + responseMap.get("NAME") + "\",";
								responseString += "\"name_status\":\"" + responseMap.get("NAME_STATUS") + "\"";
								responseString += ",\"byteArr\":\"" + this.getPdfByteArrayString(responseString, FLAT_FILE_PATH, requestJson, app_name, serviceName) + "\"";
								responseString += " }";
							}
						} 
						else 
						{
							responseString += "{\"status\":\"101\", \"statusDesc\":\"Failure\", \"message\":\"There is some error in calling webservice.\"}";
						}
					}
					catch (Exception e) 
					{
						responseString += "{\"status\":\"101\",\"statusDesc\":\"Failure\",\"message\":\"There is some error in calling webservice\"}";
						logger.error(" There is some error in calling webservice");
					}
				}
				else 
				{
					// Invalid Request Json
					responseString += "{\"status\":\"102\",\"statusDesc\":\"Failure\",\"message\":\"Invalid Request Json\"}";
					logger.error(" request Json is Null or contains invalid keys or invalid value on app_name");
				}
			}

			else 
			{
				// Invalid Request Json
				responseString += "{\"status\":\"102\",\"statusDesc\":\"Failure\",\"message\":\"Invalid Request Json\"}";
				logger.error(" request Json is Null or contains invalid keys or invalid value on app_name");
			}
		} 
		catch (Exception e)
		{
			responseString += "{\"Response\": {\"ResponseInfo\": {\"UserName\": \"\",\"CreationDate\": \"\",\"CreationTime\": \"\",\"SourceInfoName\":\"\",\"RequestorToken\": \"\",\"UserEmail\": \"\",\"LastSyncDateTime\": \"\"},\"ResponsePayload\": {\"Transactions\": [{\"Key1\":\"\",\"Key2\": \"\",\"Key3\": \"\",\"Key4\": \"\",\"Key5\": \"\",\"ValidationType\": \"\",\"TransTrackingID\": \"\",\"TransactionData\": ";
			responseString += "{\"status\":\"102\",\"statusDesc\":\"Failure\",\"message\":\"Invalid Request Json\"}";
			logger.error(" We Are in catch block : " + e);
		}

		// FLAT FILE
		try 
		{
			// String sFileName = resProp.getString("flatFilePath");
			String sFileName = FLAT_FILE_PATH;
			FlatFileMaker.generateNeoFlatFile(sFileName, requestJson, responseString, app_name, serviceName);
		}
		catch (Exception e) 
		{
			logger.error("Error while Creating Flat File inside " + methodName + "()" + e);
		}
		responseString += " }  ]  }  }  }";
		logger.info(" ResponseJSON:" + responseString);
		logger.info(" Going outside " + methodName + "().");
		return responseString;
	}


	private String getPdfByteArrayString(String responseString, String FLAT_FILE_PATH, String requestJson, String app_name, String serviceName )
	{
		try
		{
			if (responseString.contains("200")) 
			{
				String sFileName = FLAT_FILE_PATH;
				String path = PDFMaker.generateNeoPDF(sFileName, requestJson, responseString, app_name, serviceName);
				String bFile = new Base64ArrayUtility().encodeToString(path, false);
				return bFile.toString().trim();
			}
		}
		catch(Exception ex)
		{
			logger.error("We are in Exception "+ex);
		}
		return "";
	}

	/*public static void main(String arr[]) 
	{
		Date myDate = new Date();
		System.out.println(myDate);
		String ss = new SimpleDateFormat("dd-MM-yyyy").format(myDate);
		System.out.println(ss);
		System.out.println(new SimpleDateFormat("MM-dd-yyyy").format(myDate));
		System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(myDate));
		System.out.println(myDate);

	}*/
}
