package com.qc.creditbureau.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.Environment;

import com.qc.service.ExternalServices;
import com.qc.utils.Commons;
import com.qc.utils.FlatFileMaker;
import com.qc.utils.ObjectFactory;

public class GetPANRequestAction 
{
	private static final Logger logger = LogManager.getLogger(GetPANRequestAction.class);
	
	public String processPANRequest(String requestJson , Environment env)
	{
		String PRIORITY = env.getProperty("com.qualtech.pan.resource.priority");
		String FLAT_FILE_PATH=env.getProperty("flatFilePath");
		String CRIF_STATUS=env.getProperty("com.qualtech.pan.resource.CRIF.status");
		String EQUIFAX_STATUS=env.getProperty("com.qualtech.pan.resource.EQUIFAX.status");
		
		String methodName=null;
		Map requestData=null;
		String serviceName =null;
		String responseString="";
		methodName=Commons.getMethodName();
		ObjectFactory of = new ObjectFactory();
		logger.info(" Came inside "+methodName+"().");
		Map<String, String> responseMap = null;
		try
		{
			requestData=Commons.getGsonData(requestJson);
			logger.info(" Request JSON:"+requestJson);
			if(requestData!=null && requestData.containsKey("fname") && requestData.containsKey("mname")
					&& requestData.containsKey("lname") && requestData.containsKey("dob")
					&& requestData.containsKey("pan") && requestData.containsKey("gender")
					&& requestData.containsKey("email") && requestData.containsKey("careOf")
					&& requestData.containsKey("houseNo") && requestData.containsKey("street")
					&& requestData.containsKey("landmark") && requestData.containsKey("location")
					&& requestData.containsKey("postOffice") && requestData.containsKey("vill_city")
					&& requestData.containsKey("subDistrict") && requestData.containsKey("district")
					&& requestData.containsKey("state") && requestData.containsKey("stateCode")
					&& requestData.containsKey("postalCode") && requestData.containsKey("mobileno")
					&& requestData.containsKey("validationType") && requestData.containsKey("app_name") 
					&&(requestData.get("pan")!=null && !requestData.get("pan").equals(""))
					&&(requestData.get("fname")!=null && !requestData.get("fname").equals(""))
					&&(requestData.get("dob")!=null && !requestData.get("dob").equals(""))
					&&(requestData.get("validationType")!=null && !requestData.get("validationType").equals(""))
					&&(requestData.get("app_name")!=null && !requestData.get("app_name").equals(""))
					&& (requestData.get("app_name").toString().equalsIgnoreCase("TPP")	|| requestData.get("app_name").toString().equalsIgnoreCase("MSALES"))
					&& requestData.size()<23 )
			{
				logger.info(" Response Json Creation Started");
				try
				{
					logger.debug(" Calling Webservice Start");
					//String priority= resProp.getString("com.qualtech.pan.resource.priority");
					String priority = PRIORITY; //VALUE FROM PROPERTY FILE
					String[] Arr = priority.split(",");
					
					for (String itr : Arr)
					{
						logger.debug(" Calling Webservice Of : "+itr);
						//String serviceStatus = resProp.getString("com.qualtech.pan.resource."+itr+".status");
						String serviceStatus="";
						if(itr != null && itr.equalsIgnoreCase("CRIF")){
							serviceStatus = CRIF_STATUS;
						}else if(itr != null && itr.equalsIgnoreCase("EQUIFAX")){
							serviceStatus = EQUIFAX_STATUS;
						}
						
						if(serviceStatus.equalsIgnoreCase("TRUE"))
						{
							ExternalServices extServices = of.getService(itr);
							responseMap = extServices.callService(requestData,env);
							if(responseMap!=null && responseMap.containsKey("RESPONSE_STATUS"))
							{
								serviceName = itr;
								logger.debug(" Calling Webservice Of : "+itr +" Completed Successfully with Response");
								break;
							}
							else
							{
								if(itr.equalsIgnoreCase("CRIF"))
								{
									try
									{
							    		//String sFileName = resProp.getString("flatFilePath");
										String sFileName = FLAT_FILE_PATH;//FROM PROPERTY FILE
							    		FlatFileMaker.generateFlatFile(sFileName, requestJson, "Data not found", requestData.get("app_name").toString(), itr);
									}
									catch(Exception e)
									{
										logger.error("Error while Creating Flat File inside "+methodName+"()"+e,new Throwable());
										e.printStackTrace();    		
							
									} 
								}
							}
								
							
						}
					}
					
					
					logger.debug(" Calling Webservice End");
					
					if(responseMap!=null && responseMap.get("RESPONSE_STATUS").equalsIgnoreCase("200"))
					{
						responseString+="{\"status\":\""+responseMap.get("RESPONSE_STATUS")+"\", \"response\": { ";
						responseString+="\"pan\":\""+responseMap.get("PAN_STATUS")+"\",";
						responseString+="\"dob\":\""+responseMap.get("DOB_STATUS")+"\",";
						responseString+="\"name\":\""+responseMap.get("NAME_STATUS")+"\"";
						responseString+=" }}";
					}
					else
					{
						responseString="{\"status\":\"500\",\"message\":\"There is some error in calling webservice\"}";
					}
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
					responseString="{\"status\":\"500\",\"message\":\"There is some error in calling webservice\"}";
					logger.error(" There is some error in calling webservice");
				}
			}
			else
			{
				responseString="{\"status\":\"500\",\"message\":\"Invalid Request Json\"}";
				logger.error(" request Json is Null or contains invalid keys or invalid value on app_name");
			}
		}
		catch(Exception e)
		{
			responseString="{\"status\":\"500\",\"message\":\"There is some Technical Issue\"}";
			logger.error(" We Are in catch block : "+e);
			e.printStackTrace();
		}
		
		try
		{
    		//String sFileName = resProp.getString("flatFilePath");
    		String sFileName = FLAT_FILE_PATH;//FROM PROPERTY FILE
    		FlatFileMaker.generateFlatFile(sFileName, requestJson, responseString, requestData.get("app_name").toString(), serviceName);
		}
		catch(Exception e)
		{
			logger.error("Error while Creating Flat File inside "+methodName+"()"+e,new Throwable());
			e.printStackTrace();    		
		} 
		logger.info(" ResponseJSON:"+responseString);
		logger.info(" Going outside "+methodName+"().");
		return responseString;
	}
	
	
	/*public static void main(String arr[])
	{
		Date myDate = new Date();
		System.out.println(myDate);
		String ss = new SimpleDateFormat("dd-MM-yyyy").format(myDate);
		System.out.println(ss);
		System.out.println(new SimpleDateFormat("MM-dd-yyyy").format(myDate));
		System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(myDate));
		System.out.println(myDate);
		
	}*/
}
