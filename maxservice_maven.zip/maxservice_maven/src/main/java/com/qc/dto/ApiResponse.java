package com.qc.dto;

import java.io.Serializable;

public class ApiResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2945315245180275495L;
	UserInfo userInfo;
	ErrorInfo errorInfo;
	Payload payload;

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public ErrorInfo getErrorInfo() {
		return errorInfo;
	}

	public void setErrorInfo(ErrorInfo errorInfo) {
		this.errorInfo = errorInfo;
	}

	public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	public ApiResponse(UserInfo userInfo, ErrorInfo errorInfo, Payload payload) {
		super();
		this.userInfo = userInfo;
		this.errorInfo = errorInfo;
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "Response [userInfo=" + userInfo + ", errorInfo=" + errorInfo + ", payload=" + payload + "]";
	}

	public ApiResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

}
