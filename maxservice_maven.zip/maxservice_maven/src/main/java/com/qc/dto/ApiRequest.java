package com.qc.dto;

import java.io.Serializable;

public class ApiRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7551589343095265561L;
	UserInfo userInfo;
	Payload payload;

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	

	public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "ApiRequest [userInfo=" + userInfo + ", payload=" + payload + "]";
	}


}
