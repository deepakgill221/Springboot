package com.qc.dto;

public class AadharValidateResponse  extends ApiResponse{

	
}
