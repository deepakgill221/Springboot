package com.qc.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Payload implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5831430964787677588L;
	/*List<Transactions> transactions = new ArrayList<>();

	public List<Transactions> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transactions> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Payload [transactions=" + transactions + "]";
	}*/

	
	List<Object> transactions = new ArrayList<>();

	public List<Object> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Object> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Payload [transactions=" + transactions + "]";
	}
	
}
