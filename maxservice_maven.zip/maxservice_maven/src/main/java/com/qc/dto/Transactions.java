package com.qc.dto;

public interface Transactions{

}
