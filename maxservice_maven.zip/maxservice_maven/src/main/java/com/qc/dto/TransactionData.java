package com.qc.dto;

public class TransactionData {

}
