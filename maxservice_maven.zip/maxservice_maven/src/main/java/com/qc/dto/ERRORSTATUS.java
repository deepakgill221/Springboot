package com.qc.dto;

public enum ERRORSTATUS {

	SUCCESS,FAILURE
}
