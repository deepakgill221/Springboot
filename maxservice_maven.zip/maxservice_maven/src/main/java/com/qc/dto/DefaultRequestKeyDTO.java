package com.qc.dto;

import java.io.Serializable;

public class DefaultRequestKeyDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4919594036894664128L;
	String Key1="";
	String Key2="";
	String Key3="";
	String Key4="";
	String Key5="";

	public String getKey1() {
		return Key1;
	}

	public void setKey1(String key1) {
		Key1 = key1;
	}

	public String getKey2() {
		return Key2;
	}

	public void setKey2(String key2) {
		Key2 = key2;
	}

	public String getKey3() {
		return Key3;
	}

	public void setKey3(String key3) {
		Key3 = key3;
	}

	public String getKey4() {
		return Key4;
	}

	public void setKey4(String key4) {
		Key4 = key4;
	}

	public String getKey5() {
		return Key5;
	}

	public void setKey5(String key5) {
		Key5 = key5;
	}

	@Override
	public String toString() {
		return "DefaultRequestKeyDTO [Key1=" + Key1 + ", Key2=" + Key2 + ", Key3=" + Key3 + ", Key4=" + Key4 + ", Key5="
				+ Key5 + "]";
	}
}
