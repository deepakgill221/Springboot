package com.qc.daoImpl;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.qc.controller.NeoControllerRest;
import com.qc.dao.NeoDao;
import com.qc.db.DBHelperING247;
import com.qc.db.DBHelperNeoPan;
import com.qc.db.DBHelperSOAUAT;
import com.qc.entity.PlanDetailBean;

import oracle.jdbc.OracleTypes;

@Repository
public class NeoDaoImpl implements NeoDao 
{
	private static final Logger logger = LogManager.getLogger(NeoControllerRest.class);

	//	Session session = null;
	//	@Autowired
	//	@PersistenceContext(unitName = "primary", type=PersistenceContextType.EXTENDED)
	//	private EntityManager entityManager;
	//
	//	@Autowired
	//	@PersistenceContext(unitName = "secondary", type=PersistenceContextType.EXTENDED)
	//	private EntityManager secondryEntityManager;
	//
	//	@Autowired
	//	@PersistenceContext(unitName = "tertiary", type=PersistenceContextType.EXTENDED)
	//	private EntityManager ing247EntityManager;
	//	
	//	@Autowired
	//	@PersistenceContext(unitName = "quaternary", type=PersistenceContextType.EXTENDED)
	//	private EntityManager quaternaryEntityManager;


	@Override
	//	@Transactional(value = "tertiaryTransactionManager")
	public List<PlanDetailBean> callPlanDetail(String planid,String rtbl_age_dur,String rtbl_sex) throws SQLException , Exception
	{
		logger.debug("Comes to callPlanDetail Method: ");        
		//		ResultSet rs=null;
		Connection con=null;
		//		CallableStatement clblStmt =null;
		List<PlanDetailBean> planDetailBeanList = null;
		//		try
		//		{
		//			session = (Session)ing247EntityManager.getDelegate();
		//			SessionImpl sessionImpl = (SessionImpl) session;
		//			con = sessionImpl.connection();
		logger.info("Get Connection Call : Start");
		con = DBHelperING247.getInstance().getSourceConnection();
		logger.info("Get Connection Call : End");

		if(con!=null)
		{
			//con.setAutoCommit(true);
			//Calling Function

			//			logger.info("Get Proc Call - FN_NEO_RATE_WEB_SERVICE : Start");
			//
			//			clblStmt =con.prepareCall(" { ? = call FN_NEO_RATE_WEB_SERVICE(?, ?, ?) } ");
			//			clblStmt.registerOutParameter(1, OracleTypes.CURSOR);
			//			clblStmt.setString(2, planid);
			//			clblStmt.setString(3, rtbl_age_dur);
			//			clblStmt.setString(4, rtbl_sex);
			//			clblStmt.execute();
			//			rs = (ResultSet) clblStmt.getObject(1);
			//
			//			logger.info("Get Proc Call - FN_NEO_RATE_WEB_SERVICE : End");

			logger.info("Call getPlanDetailData : Start");
			planDetailBeanList = getPlanDetailData(con,planid,rtbl_age_dur,rtbl_sex);
			logger.info("Call getPlanDetailData : End");

			if(planDetailBeanList!=null && planDetailBeanList.size()==0)
			{
				logger.info("Plan Details set to null as its size is zero");
				planDetailBeanList=null;
			}

		}
		//		}
		//		catch(Exception e)
		//		{			
		//			logger.error("Some exception occured while fetching records : "+e);
		//			return null;
		//		}		
		//		finally
		//		{
		try
		{
			logger.debug("Trying to close Resources in callPlanDetail Method:- ");  
			//			if(rs!=null)
			//			{
			//				rs.close();
			//			}
			//			if(clblStmt!=null)
			//			{
			//				clblStmt.close();
			//			}
			if(con!=null)
			{
				con.close();
			}
			logger.debug("Successfully closed Resources in callPlanDetail Method:- ");  
		}
		catch(Exception e)
		{				
			logger.error("SQL exception while closing resources in callPlanDetail Method: "+e);
		}
		//		}
		logger.debug("Getting out from callPlanDetail Method : ");
		return planDetailBeanList;
	}


	public List<PlanDetailBean> getPlanDetailData(Connection con, String planid,String rtbl_age_dur,String rtbl_sex) throws SQLException , Exception
	{
		ResultSet rs=null;
		CallableStatement clblStmt =null;
		List<PlanDetailBean> planDetailBeanList = new ArrayList<PlanDetailBean>();
		if(con!=null)
		{
			logger.info("Get Proc Call - FN_NEO_RATE_WEB_SERVICE : Start");
			String procName= " { ? = call FN_NEO_RATE_WEB_SERVICE(?, ?, ?) } ";
			clblStmt =con.prepareCall(procName);
			clblStmt.registerOutParameter(1, OracleTypes.CURSOR);
			clblStmt.setString(2, planid);
			clblStmt.setString(3, rtbl_age_dur);
			clblStmt.setString(4, rtbl_sex);
			clblStmt.execute();
			rs = (ResultSet) clblStmt.getObject(1);
			logger.info("Get Proc Call - FN_NEO_RATE_WEB_SERVICE : End");
			if(rs!= null)
			{
				do
				{
					PlanDetailBean planDetailBean = new PlanDetailBean();
					try
					{
						planDetailBean.setPLAN_ID(rs.getString("PLAN_ID")!=null?rs.getString("PLAN_ID").trim():"");
						planDetailBean.setRH_ID(rs.getString("RH_ID")!=null?rs.getString("RH_ID").trim():"");
						planDetailBean.setRTBL_ID(rs.getString("RTBL_ID")!=null?rs.getString("RTBL_ID").trim():"");
						planDetailBean.setRH_BAND_AMT(rs.getString("RH_BAND_AMT")!=null?rs.getString("RH_BAND_AMT").trim():"");//--
						planDetailBean.setRTBL_SEX_CD(rs.getString("RTBL_SEX_CD")!=null?rs.getString("RTBL_SEX_CD").trim():"");
						planDetailBean.setDISCOUNT_OPTION(rs.getString("DISCOUNT_OPTION")!=null?rs.getString("DISCOUNT_OPTION").trim():"");
						planDetailBean.setSMOKER_CODE(rs.getString("SMOKER_CODE")!=null?rs.getString("SMOKER_CODE").trim():"");
						planDetailBean.setRTBL_MAT_XPRY_DUR(rs.getString("RTBL_MAT_XPRY_DUR")!=null?rs.getString("RTBL_MAT_XPRY_DUR").trim():"");//--
						planDetailBean.setISSUE_AGE(rs.getString("ISSUE_AGE")!=null?rs.getString("ISSUE_AGE").trim():"");//--
						planDetailBean.setRTBL_AGE(rs.getString("RTBL_AGE")!=null?rs.getString("RTBL_AGE").trim():"");
						planDetailBean.setRTBL_1_RT(rs.getString("RTBL_1_RT")!=null?rs.getString("RTBL_1_RT").trim():"");//--
						planDetailBeanList.add(planDetailBean);
					}
					catch(Exception e)
					{
						if(e.getMessage().equalsIgnoreCase("ResultSet.next was not called"))
						{
							logger.info("ResultSet.next was not called Exception occured while setting records from db : "+e);
						}
						else
						{
							logger.error("Some exception occured while setting records from db : "+e);	
						}
					}
				}while (rs.next());
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		try
		{
			if(rs!=null)
			{
				rs.close();
			}
			if(clblStmt!=null)
			{
				clblStmt.close();
			}
		}
		catch(Exception e)
		{				
			logger.error("SQL exception while closing resources in getPlanDetailData Method: "+e);
		}
		return planDetailBeanList;
	}


	@Override
	//	@Transactional(value = "quaternaryTransactionManager")
	public List<List<String>> callExistingCustomer(String query, String[] param) 
	{
		logger.debug("Comes to callExistingCustomer Method: ");        
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement stmt =null;
		ResultSetMetaData resultSetMetaData=null;
		Clob clob=null;
		int noOfColumns=0;
		int count=0;
		int i=0;
		List<String> data=new ArrayList<String>();
		List<List<String>> result=new ArrayList<List<String>>();
		try
		{
			//			session = (Session)quaternaryEntityManager.getDelegate();
			//			SessionImpl sessionImpl = (SessionImpl) session;
			//			con = sessionImpl.connection();
			con = DBHelperNeoPan.getInstance().getSourceConnection();

			if(con!=null)
			{
				stmt = con.prepareStatement(query);
				stmt.setQueryTimeout(0);
				if(param.length>0)
				{
					logger.info("SQL query to be executed : "+query +" with Parameters :-"+Arrays.toString(param));
					while(count<param.length)
					{
						stmt.setString(count+1,param[count]);
						count++;
					}
				}
				else
				{
					logger.info("SQL query to be executed : "+query);
				}
				logger.info("Going to Execute Script : Start");
				rs=stmt.executeQuery();
				logger.info("Going to Execute Script : End");
				if(rs!=null)
				{
					resultSetMetaData=rs.getMetaData();
					noOfColumns = resultSetMetaData.getColumnCount();
					List<String> colName=new ArrayList<String>();
					for (i = 1; i <= noOfColumns; i++)
					{
						colName.add(resultSetMetaData.getColumnName(i));			        	
					}
					result.add(colName);
					count=0;
					logger.info("total No of Columns fetch are:-"+noOfColumns);
					while(rs.next())
					{
						data=new ArrayList<String>();
						count++;
						for(i=1;i<=noOfColumns;i++)
						{	
							try
							{				        		
								if(resultSetMetaData.getColumnTypeName(i)!=null && resultSetMetaData.getColumnTypeName(i).equalsIgnoreCase("CLOB"))
								{
									try
									{
										clob=rs.getClob(i);	 
										data.add(clob != null ? clob.getSubString(1L, (int)clob.length()).replaceAll("\n", "").replaceAll("\\\\", "\\\\\\\\") : "");
									}
									catch(Exception e)
									{
										logger.error("Error in reteriving CLOB Value:-"+e,new Throwable());
										e.printStackTrace();
									}
								}
								else if(resultSetMetaData.getColumnTypeName(i)!=null && resultSetMetaData.getColumnTypeName(i).equalsIgnoreCase("RAW"))
								{
									if(rs.getObject(i)!=null)
									{
										String str=removeSpecialChar(rs.getObject(i).toString().trim());
										data.add(str);
									}
									else
									{
										data.add("");			        			
									}			      
								}
								else
								{
									if(rs.getObject(i)!=null)
									{
										String str=removeSpecialChar(rs.getObject(i).toString().trim());
										data.add(str);
									}
									else
									{
										data.add("");			        			
									}			      
								}
							}
							catch(Exception e)
							{
								logger.error("Error in Getting Data from coloum"+e);
							}
						}
						result.add(data);
					}
					logger.info("total No of Records fetch are:-"+count);
				}			
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e);
		}		
		finally
		{
			try
			{
				if(rs!=null)
				{
					rs.close();
				}
				if(stmt!=null)
				{
					stmt.close();
				}
				if(con!=null)
				{
					con.close();
				}
				resultSetMetaData=null;
				clob=null;
				data=null;
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources : "+e);
			}
		}
		logger.debug("Getting out from NeoDaoImpl in ExecuteDataLobQueryNeo Method : ");
		return result;
	}

	public String removeSpecialChar(String str)
	{
		String returnStr="";
		returnStr=str.replaceAll("\\\\", "\\\\\\\\");	  /// backslash
		returnStr=returnStr.replaceAll("\"", "\\\\\"");         /// double quotes
		returnStr=returnStr.replaceAll("\b", "\\\\\b");   /// backspaceas
		returnStr=returnStr.replaceAll("\f", "\\\\\f");   ///form feed
		returnStr=returnStr.replaceAll("\n", "\\\\\n");   ///new line
		returnStr=returnStr.replaceAll("\r", "\\\\\r");   /// carriage return
		returnStr=returnStr.replaceAll("\t", "\\\\\t");   /// tab
		///returnStr=returnStr.replaceAll("\'", "\\\\\'");   ///
		returnStr=returnStr.replaceAll("\\v", "\\\\\\v"); /// vertical tab
		return returnStr;
	}

	public boolean policyGenerationCheckTransIdExist(String transId) 
	{
		logger.info("policyGenerationCheckTransIdExist : start");
		Connection con=null;
		PreparedStatement stmt =null;
		ResultSet rs=null;
		boolean result = false;
		String query = "";

		try 
		{
			con=DBHelperSOAUAT.getInstance().getSourceConnection();
			query = "select COUNT(1) from PLAN_POL_NO where transid=? ";
			stmt = con.prepareStatement(query);
			stmt.setString(1, transId);
			logger.info("Script is : "+query);
			rs = stmt.executeQuery();

			while (rs.next()) 
			{
				if (rs.getInt(1) > 0) 
				{
					// Trans ID Exist
					logger.info("Transaction ID Exist so returning : false");
					result = false;
				} else 
				{
					// Trans ID Does not exist
					logger.info("Transaction ID Not Exist so returning : true");
					result = true;
				}
			}

		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			logger.info("We are in SQLException so returning : false");
			return false;
		}
		catch (Exception e)
		{
			logger.info("We are in Exception so returning : false");
			return false;
		}
		finally 
		{

			try 
			{
				if (con != null) 
				{
					con.close();
				}
				if (stmt != null)
				{
					stmt.close();
				}
				if (rs != null) 
				{
					rs.close();
				}
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block

			}
		} 
		logger.info("policyGenerationCheckTransIdExist : End");
		return result;
	}
	public List<String> callProceduresForUniquePolicy(String testPlanType,String storySolution,String transId)
	{        
		logger.debug("NeoDaoImpl in callProceduresForUniquePolicy Method : Start");        
		ResultSet rs=null;
		Connection con=null;
		CallableStatement clblStmt =null;
		List<String> policyList = new ArrayList<String>();
		try
		{
			con=DBHelperSOAUAT.getInstance().getSourceConnection();	
			if(con!=null)
			{
				con.setAutoCommit(true);
				String finalScript="{ call pr_UpdatePlanPolicyNo(?,?,?,?)}";
				clblStmt = con.prepareCall(finalScript);
				clblStmt.setQueryTimeout(0);

				clblStmt.setString(1, testPlanType);
				clblStmt.setString(2, transId);
				clblStmt.setString(3, storySolution);
				clblStmt.registerOutParameter(4, OracleTypes.CURSOR);
//				clblStmt.registerOutParameter(4, java.sql.Types.VARCHAR);
//				clblStmt.registerOutParameter(5, java.sql.Types.INTEGER);
				clblStmt.execute();
				
				rs = (ResultSet) clblStmt.getObject(4);
				//policyList.add(clblStmt.getString(4));
				//policyList.add(String.valueOf(clblStmt.getInt(5)));
				if(rs!= null)
				{
					while (rs.next())
					{
						try
						{
							policyList.add(String.valueOf(rs.getObject(1)));//String("VC_POLICYNUMBER"));
							policyList.add(String.valueOf(rs.getObject(2)));
						}
						catch(Exception e)
						{
							logger.error("Some exception occured while setting records from db : "+e);
						}
					}
				}
				
				
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources NeoDaoImpl in callProceduresForUniquePolicy Method:- ");  
				if(rs!=null)
				{
					rs.close();
				}
				if(clblStmt!=null)
				{
					clblStmt.close();
				}
				if(con!=null)
				{
					con.close();
				}
				logger.debug("Successfully closed Resources NeoDaoImpl in callProceduresForUniquePolicy Method:- ");  
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources NeoDaoImpl in callProceduresForUniquePolicy Method: "+e,new Throwable());
				
			}
		}
		logger.debug("NeoDaoImpl in callProceduresForUniquePolicy Method : End");
		return policyList;
	}

	public String getIfscMicr(String ifscCode,String microCode) throws SQLException
	{
		logger.debug("getIfscMicr : Start");
		Connection con=null;
		PreparedStatement stmt =null;
		int count=-999;
		String message="";
		String finalOut="";
		String ifscCodeResponse="";
		String microCodeResponse="";

		String matchStatus="";
		String mICR_BANK_NAME="";
		String mICR_BRANCH_NAME="";
		int i=0;
		ResultSet rs=null;
		try
		{
			con=DBHelperSOAUAT.getInstance().getSourceConnection();		
			if(con!=null)
			{
				try
				{   
					try
					{
						String query = "select count(*) from MNYL_MICR_CODE_DET where IFSC_CD=? "; 
						con.setAutoCommit(true);
						stmt = con.prepareStatement(query);		
						logger.info("SQL query to be executed : "+query +" with Parameters :-");
						stmt.setString(1,ifscCode);
						rs=stmt.executeQuery();
						while(rs.next())
						{
							i=rs.getInt("count(*)");
						}
						if(i>0)
						{
							ifscCodeResponse="\"IFSCCODE\":\""+ifscCode+"\",\"IFSCSTATUS\":\"Success\"";
						}
						else
						{
							ifscCodeResponse="\"IFSCCODE\":\""+ifscCode+"\",\"IFSCSTATUS\":\"Fail\"";
						}
						logger.debug("After Executing query total change count is:-"+i);
					}
					catch(Exception ex)
					{
						logger.debug("error while excecuting query IFSCCODE and IFSCSTATUS -"+i);
					}
					finally
					{
						i=0;
					}

					// query for micro code
					try
					{
						rs=null;
						stmt=null;
						String query1 = "select MICR_BANK_NAME,MICR_BRANCH_NAME from MNYL_MICR_CODE_DET where MICR_NEW_CD=? "; 
						con.setAutoCommit(true);
						stmt = con.prepareStatement(query1);		
						logger.info("SQL query to be executed : "+query1 +" with Parameters :-");
						stmt.setString(1,microCode);
						rs=stmt.executeQuery();
						while(rs.next())
						{
							mICR_BANK_NAME=((rs.getString("MICR_BANK_NAME")).replaceAll("[\\t\\n\\r]+"," ")).replaceAll("  ", " ").trim();
							mICR_BRANCH_NAME =((rs.getString("MICR_BRANCH_NAME")).replaceAll("[\\t\\n\\r]+"," ")).replaceAll("  ", " ").replaceAll("", "").trim();
							i++;
						}
						if(i>0)
						{
							microCodeResponse="\"MICROCODE\":\""+microCode+"\" , \"MICRBANKNAME\":\""+mICR_BANK_NAME+"\",\"MICRBRANCHNAME\":\""+mICR_BRANCH_NAME+"\", \"MICRSTATUS\":\"Success\"";
						}
						else
						{
							microCodeResponse="\"MICROCODE\":\""+microCode+"\",\"MICRSTATUS\":\"Fail\"";
						}
					}
					catch(Exception ex)
					{
						logger.debug("error while excecuting the query for MICROCODE and MICRSTATUS -"+i);
					}
					finally
					{
						i=0;
					}
					try
					{
						rs=null;
						stmt=null;
						String query2 = "select count(*) from MNYL_MICR_CODE_DET where MICR_NEW_CD=? and IFSC_CD=?  "; 
						con.setAutoCommit(true);
						stmt = con.prepareStatement(query2);		
						stmt.setString(1,microCode);
						stmt.setString(2,ifscCode);
						rs=stmt.executeQuery();
						while(rs.next())
						{
							i=rs.getInt("count(*)");
						}
						if(i>0)
						{
							matchStatus="\"MATCHSTATUS\":\"MATCHED\"";
						}
						else
						{
							matchStatus="\"MATCHSTATUS\":\"MISMATCHED\"";;
						}
					}
					catch(Exception Ex)
					{
						logger.debug("error while excecuting MATCHSTATUS query -"+i);
					}
					finally
					{
						i=0;
					}
					finalOut="{\"RESPONSE\": {"+ ifscCodeResponse + ","+microCodeResponse+" , "+matchStatus+" }}";
				}
				catch(Exception e)
				{
					logger.error("Error while executing query:"+e);
					message=e+" Error occured while operating records";
				}       		        		  	
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");		
				message="Connection is Not Available";
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e);
			message="Error occured while fetching records";
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in ExecuteUpdate Method:- ");   
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in ExecuteUpdate Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in ExecuteUpdate Method: "+e);
			}
		}
		if(count!=-999)
		{
			message=String.valueOf(count);
		}
		logger.debug("getIfscMicr : End");      
		return finalOut;
	}
}
