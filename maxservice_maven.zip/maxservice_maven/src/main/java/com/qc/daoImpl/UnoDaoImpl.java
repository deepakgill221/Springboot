package com.qc.daoImpl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.PartialWithDrawalRequest;
import com.qc.api.request.TotalPremiumRequest;
import com.qc.api.response.PartialWithDrawalResponse;
import com.qc.api.response.TotalPremiumResponse;
import com.qc.dao.UnoDao;
import com.qc.db.DBHelperING247;
import com.qc.db.DBHelperSOAUAT;
import com.qc.entity.PerfiosEntity;
import com.qc.utils.Utility;

import oracle.jdbc.OracleTypes;

@Repository
public class UnoDaoImpl implements UnoDao 
{
	private static final Logger logger = LogManager.getLogger(UnoDaoImpl.class);
//	Session session = null;
//	//@Autowired	SessionFactory sessionFactory;
//	@Autowired
//	@PersistenceContext(unitName = "primary", type=PersistenceContextType.EXTENDED)
//	private EntityManager entityManager;
//	 
//	@Autowired
//	@PersistenceContext(unitName = "secondary", type=PersistenceContextType.EXTENDED)
//	 private EntityManager secondryEntityManager;
	
	
	
//	@Transactional
//	public PerfiosEntity getUnoData(PerfiosEntity perfiosEntity) 
//	{
		
//		String sqlScript = " Select * from SPR_BOOT_TEST ";
//		Query q = entityManager.createNativeQuery("BEGIN " + sqlScript + " END;");
//		q.executeUpdate();
		
		
//		session = sessionFactory.getCurrentSession();
//		session = (Session)entityManager.getDelegate();
//		String hql = " FROM UnoDBEntity uno ";//  WHERE id = :id ";
//		Query queryhql = session.createQuery(hql);
//		List<UnoDBEntity> list = queryhql.list();
//		
//		System.out.println(list.size());
//		
//		Iterator iterator = list.iterator();
//		
//		return null;
//	}
	
//	@Transactional(value = "secondaryTransactionManager")
//	public PerfiosEntity getUnoData1(PerfiosEntity perfiosEntity) 
//	{
//		Session session = (Session)secondaryEntityManager.getDelegate();
//		String hql = " FROM UnoDBEntity uno ";//  WHERE id = :id ";
//		Query queryhql = session.createQuery(hql);
//		
//		List<UnoDBEntity> list = queryhql.list();
//		System.out.println(list.size());
//		Iterator iterator = list.iterator();
//		return null;
//	}

	@Override
	public PartialWithDrawalResponse getWithDrawalResponseDao(PartialWithDrawalRequest partialWithDrawalRequest) {
		

		logger.debug("Comes to getWithDrawalResponse Method: "); 
		
		PartialWithDrawalResponse partialWithDrawalResponse=new PartialWithDrawalResponse();
		Date startDate=(Date) new Utility().getSqlDateFromString(partialWithDrawalRequest.getStartDate());
		Date endDate=(Date) new Utility().getSqlDateFromString(partialWithDrawalRequest.getEndDate());
		ResultSet rs=null;
		Connection con=null;
		CallableStatement clblStmt =null;
		try
		{
			con = DBHelperSOAUAT.getInstance().getSourceConnection();

			if(con!=null)
			{
				clblStmt =con.prepareCall(" { call pr_partial_withdrawl(?,?,?,?) } ");
				clblStmt.setString(1, partialWithDrawalRequest.getPolicyId());
				
				clblStmt.setDate(2, (java.sql.Date) startDate);
				clblStmt.setDate(3, (java.sql.Date) endDate);
				clblStmt.registerOutParameter(4, OracleTypes.CURSOR);
				clblStmt.execute();
				rs = (ResultSet) clblStmt.getObject(4);
				
				if(rs!= null)
				{
					do
					{
						try
						{
							partialWithDrawalResponse.setComment(rs.getString("COMMENT")!=null?rs.getString("COMMENT").trim():"");
							partialWithDrawalResponse.setAmount(rs.getString("AMT")!=null?rs.getString("AMT").trim():"");
							
						}
						catch(Exception e)
						{
							if(e.getMessage().equalsIgnoreCase("ResultSet.next was not called"))
							{
								logger.info("ResultSet.next was not called Exception occured while setting records from db : "+e);
							}
							else
							{
								logger.error("Some exception occured while setting records from db : "+e);	
							}
						}
					}while (rs.next());
				}
				else
				{
					logger.error("Connection is Not Available Service unavailable.");				
				}
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			return null;
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources in callPlanDetail Method:- ");  
				if(rs!=null)
				{
					rs.close();
				}
				if(clblStmt!=null)
				{
					clblStmt.close();
				}
				if(con!=null)
				{
					con.close();
				}
				logger.debug("Successfully closed Resources in getWithDrawalResponse Method:- ");  
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources in getWithDrawalResponse Method: "+e);
			}
		}
		logger.debug("Getting out from getWithDrawalResponse Method : ");
		
	
		return partialWithDrawalResponse;
	}

	@Override
	public TotalPremiumResponse getTotalPremiumDataDao(TotalPremiumRequest totalPremiumRequest) {

		logger.debug("Comes to getTotalPremiumDataDao Method: "); 
		
		TotalPremiumResponse totalPremiumResponse=new TotalPremiumResponse();
		ResultSet rs=null;
		Connection con=null;
		CallableStatement clblStmt =null;
		try
		{
			con = DBHelperSOAUAT.getInstance().getSourceConnection();

			if(con!=null)
			{
				clblStmt =con.prepareCall(" { call pr_getpol_reqrd_prem(?, ?) } ");
				clblStmt.setString(1, totalPremiumRequest.getPolicyId());
				clblStmt.registerOutParameter(2, OracleTypes.CURSOR);
				clblStmt.execute();
				rs = (ResultSet) clblStmt.getObject(2);
				
				if(rs!= null)
				{
					do
					{
						try
						{
							totalPremiumResponse.setRequiredPremium(rs.getString("REQUIRED PREMIUM")!=null?rs.getString("REQUIRED PREMIUM").trim():"");
							
						}
						catch(Exception e)
						{
							if(e.getMessage().equalsIgnoreCase("ResultSet.next was not called"))
							{
								logger.info("ResultSet.next was not called Exception occured while setting records from db : "+e);
							}
							else
							{
								logger.error("Some exception occured while setting records from db : "+e);	
							}
						}
					}while (rs.next());
				}
				else
				{
					logger.error("Connection is Not Available Service unavailable.");				
				}
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e);
			return null;
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources in getTotalPremiumDataDao Method:- ");  
				if(rs!=null)
				{
					rs.close();
				}
				if(clblStmt!=null)
				{
					clblStmt.close();
				}
				if(con!=null)
				{
					con.close();
				}
				logger.debug("Successfully closed Resources in getTotalPremiumDataDao Method:- ");  
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources in getWithDrawalResponse Method: "+e);
			}
		}
		logger.debug("Getting out from getWithDrawalResponse Method : ");
		return totalPremiumResponse;
	}

}
