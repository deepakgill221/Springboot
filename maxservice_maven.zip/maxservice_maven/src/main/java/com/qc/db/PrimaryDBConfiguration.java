package com.qc.db;


import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import oracle.jdbc.pool.OracleDataSource;

@Profile("!test")          // 1
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.qc", entityManagerFactoryRef = "primaryEntityManager", transactionManagerRef = "primaryTransactionManager")        // 2
@PropertySource({ "classpath:application.properties" })
public class PrimaryDBConfiguration 
{
	
	@NotNull
	@Value("${primary.datasource.oracle.uname}")
	private String uname;

	@NotNull
	@Value("${primary.datasource.oracle.upass}")
	private String upass;

	@NotNull
	@Value("${primary.datasource.oracle.url}")
	private String url;
	
	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpass() {
		try
		{
			upass = new StringEncrypter().decrypt(upass);
		}
		catch (Exception ex)
		{

		}
		return upass;
	}

	public void setUpass(String upass) {
		this.upass = upass;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Bean(name = "dataSource")      // 3
	@Primary
	@ConfigurationProperties(prefix = "primary.datasource.oracle")
	DataSource mysqlDataSource()
	{
		OracleDataSource dataSource = null;
		try
		{
			dataSource = new OracleDataSource();
			dataSource.setUser(getUname());
			dataSource.setPassword(getUpass());
			dataSource.setURL(getUrl());
			dataSource.setImplicitCachingEnabled(true);
			dataSource.setFastConnectionFailoverEnabled(true);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return dataSource;
	}
	
	@PersistenceContext(unitName = "primary")   // 4
	@Primary
	@Bean(name = "primaryEntityManager")
	public LocalContainerEntityManagerFactoryBean mySqlEntityManagerFactory(EntityManagerFactoryBuilder builder) 
	{
		return builder.dataSource(mysqlDataSource()).persistenceUnit("primary").properties(jpaProperties()).packages("com.qc").build();
	}
	@Bean(name = "primaryTransactionManager")
	public PlatformTransactionManager transactionManager(EntityManagerFactoryBuilder builder) {
		JpaTransactionManager tm = new JpaTransactionManager();
		tm.setEntityManagerFactory(mySqlEntityManagerFactory(builder).getObject());
		tm.setDataSource(mysqlDataSource());
		return tm;
	}
	private Map<String, Object> jpaProperties()
	{
		Map<String, Object> props = new HashMap<>();
		
		props.put("oracle.jdbc.timezoneAsRegion","false");
		
		props.put("oracle.jdbc.ReadTimeout","900000000");
		
		props.put("hibernate.ejb.naming_strategy", "org.hibernate.cfg.EJB3NamingStrategy");
		props.put("hibernate.dialect","org.hibernate.dialect.Oracle10gDialect");
		props.put("hibernate.hbm2ddl.auto","update");
		
		props.put("spring.jpa.hibernate.ddl-auto","update");
		props.put("spring.data.jpa.repositories.enabled","true");
		props.put("spring.jpa.show-sql","true");
		props.put("spring.jpa.open-in-view","true");
		
//		props.put("hibernate.c3p0.min_size", "10");
//		props.put("hibernate.c3p0.max_size", "200");
//		props.put("hibernate.c3p0.timeout", "1800");
//		props.put("hibernate.c3p0.max_statements", "50");
//		props.put("hibernate.c3p0.idle_test_period.timeout", "3000");
		
		//Maximum number of checked-out database connections
//		props.put("hibernate.dbcp.maxActive", "200");
		props.put("hibernate.dbcp.maxActive", "20");
		//Maximum number of idle database connections for connection pool
		props.put("hibernate.dbcp.maxIdle", "10");
		props.put("hibernate.dbcp.minIdle", "5");
		
		//Maximum idle time for connections in connection pool (expressed in ms). --Set to -1 to turn off
		props.put("hibernate.dbcp.maxWait", "-1");
		
		//Action to take in case of an exhausted DBCP connection pool. Set to 0 to fail, 1 to block until a connection is made available, or 2 to grow)
		props.put("hibernate.dbcp.whenExhaustedAction", "1");
		
		//Validate connection when borrowing connection from pool (defaults to true)
		props.put("hibernate.dbcp.testOnBorrow", "true");
		
		//Validate connection when returning connection to pool (optional, true, or false) 
		props.put("hibernate.dbcp.testOnReturn", "true");
		
		//Query to execute for connection validation (optional, requires either hibernate.dbcp.testOn Borrow or hibernate.dbcp.testOnReturn)
		props.put("hibernate.dbcp.validationQuery", "select 1 from dual");
		
		//Maximum number of checked-out statements
		props.put("hibernate.dbcp.ps.maxActive", "200");
		
		//Maximum number of idle statements
		props.put("hibernate.dbcp.ps.maxIdle", "10");
		
		//Maximum idle time for statements (in ms)
		props.put("hibernate.dbcp.ps.maxWait", "-1");
		
		//Action to take in case of an exhausted statement pool. Set to 0 to fail, 1 to block until a statement is made available, or 2 to grow)
		props.put("hibernate.dbcp.ps.whenExhaustedAction", "1");
		
		return props;
	}
}
