package com.qc.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DBHelperPortal 
{
	private static DBHelperPortal instance=null;
	private DataSource ds=null;
	private static final Logger logger = LogManager.getLogger(DBHelperPortal.class);
	//ResourceBundle resourceBundle = null;

	static String url="jdbc:oracle:thin:@172.23.51.25:1875:WPSDB2";
	static String uname="PORTALUAT";
	static String upass="UATPORTAL";
	static String driverClassName="oracle.jdbc.driver.OracleDriver";
	
	static
	{
		try
		{
			//ResourceBundle  resourceBundle1 = ResourceBundle.getBundle("com.qualtech.ws.resource.dbConfig");
			//Class.forName(resourceBundle1.getString("com.qualtech.ws.resource.dbConfig.STP_DS.driverClass"));
			Class.forName(driverClassName);
		}
		catch(Exception ex)
		{
			logger.error(ex);
			ex.printStackTrace();
		}
	}

	public Connection getSourceConnection() throws SQLException
	{
		logger.debug("Inside getSourceConnection... Method");
		Connection con = null;		
		try
		{
			con = DriverManager.getConnection(url, uname, upass);
		}
		catch(Exception e)
		{ 
			logger.error("Error while getting connection from data source "+e,new Throwable());
			e.printStackTrace();
		}
		logger.debug("Exiting getSourceConnection... Method");
		return con;
	}

	public static DBHelperPortal getInstance()
	{
		logger.debug("Inside getInstance... Method");

		DBHelperPortal helper = new DBHelperPortal();
		//helper.resourceBundle = ResourceBundle.getBundle("com.qualtech.ws.resource.dbConfig");

		logger.debug("Exiting getInstance... Method");

		return helper;
	}
}