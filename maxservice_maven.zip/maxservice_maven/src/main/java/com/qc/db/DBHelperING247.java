package com.qc.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DBHelperING247 
{
	private static DBHelperING247 instance=null;
	private DataSource ds=null;
	private static final Logger logger = LogManager.getLogger(DBHelperING247.class);
	//ResourceBundle resourceBundle = null;

	static String url="jdbc:oracle:thin:@172.23.51.16:1875:TB640IP9";
	static String uname="ING247VIEW";
	static String upass="ing247#2012";
	static String driverClassName="oracle.jdbc.driver.OracleDriver";

	static
	{
		try
		{
			//ResourceBundle  resourceBundle1 = ResourceBundle.getBundle("com.qualtech.ws.resource.dbConfig");
			//Class.forName(resourceBundle1.getString("com.qualtech.ws.resource.dbConfig.STP_DS.driverClass"));
			Class.forName(driverClassName);
		}
		catch(Exception ex)
		{
			logger.error(ex);
			ex.printStackTrace();
		}
	}

	public Connection getSourceConnection() throws SQLException
	{
		logger.debug("Inside getSourceConnection... Method");
		Connection con = null;		
		try
		{
			con = DriverManager.getConnection(url, uname, upass);
		}
		catch(Exception e)
		{ 
			logger.error("Error while getting connection from data source "+e,new Throwable());
			e.printStackTrace();
		}
		logger.debug("Exiting getSourceConnection... Method");
		return con;
	}

	public static DBHelperING247 getInstance()
	{
		logger.debug("Inside getInstance... Method");

		DBHelperING247 helper = new DBHelperING247();
		//helper.resourceBundle = ResourceBundle.getBundle("com.qualtech.ws.resource.dbConfig");

		logger.debug("Exiting getInstance... Method");

		return helper;
	}
}