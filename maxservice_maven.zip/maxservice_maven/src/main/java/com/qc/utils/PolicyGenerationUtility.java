package com.qc.utils;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.qc.controller.NeoControllerRest;
import com.qc.dao.NeoDao;
import com.qc.daoImpl.NeoDaoImpl;
import com.qc.utils.Commons;

public class PolicyGenerationUtility 
{
	private static Logger logger = LogManager.getLogger(PolicyGenerationUtility.class);
	public static synchronized String getPolicyServiceData(String key) throws Exception
	{
		logger.info("getPolicyServiceData : Start");
		String returnOutput=new String();
		String testPlanType=null;
		JSONObject jsonrequest=new JSONObject(key);
		NeoDao neoDao = new NeoDaoImpl();
		JSONArray info = jsonrequest.getJSONArray("REQUEST");
		String planType= "";
		String storySolution = "";
		String transId= "";

		for(int ii=0; ii<info.length();ii++) 
		{
			JSONObject jsonOBject = info.getJSONObject(ii);
			planType = Commons.checkStringNullOrBlank(jsonOBject.getString("PLANTYPE"));
			storySolution = Commons.checkStringNullOrBlank(jsonOBject.getString("STORYSOLUTION"));
			transId = Commons.checkStringNullOrBlank(jsonOBject.getString("TRANSID"));

			if(ii==0)
				testPlanType ="'"+planType+"'," ;
			if(ii>0)
				testPlanType +="'"+planType+"'," ;
		}

		testPlanType=testPlanType.substring(0, testPlanType.length()-1);

		// Implementing Check For Invalid Request 
		if ((planType != null && !planType.equals("")) && (storySolution!= null && !storySolution.equals("") && (storySolution.equalsIgnoreCase("Y") || storySolution.equalsIgnoreCase("N"))) && (transId!= null && !transId.equals(""))) 
		{
			boolean status=false;
			status=neoDao.policyGenerationCheckTransIdExist(transId);
			if (!status)
			{
				returnOutput = "{\"RESPONSE\":{\"POLICYNO\":\"\" , \"STATUS\":\"Fail\" , \"RESPONSEMSG\":\"Duplicate transaction id\"}}";
			}
			else 
			{
				returnOutput=new PolicyGenerationUtility().getPolicyGenerationResponse(testPlanType,storySolution,transId);
			}
		}
		else 
		{
			returnOutput = "{\"RESPONSE\":{\"POLICYNO\":\"\" , \"STATUS\":\"Fail\" , \"RESPONSEMSG\":\"Invalid request\"}}";
		}
		logger.info("getPolicyServiceData : End : Output : "+returnOutput);
		return returnOutput;
	}
	
	
	public String getPolicyGenerationResponse(String policytype, String storySolution,String transId)
	{	
		logger.info("getPolicyGenerationResponse : Start");
		String PolicyNo="";
		if(policytype!=null  )
		{
			try
			{
				PolicyNo=this.policyGenerationProcess(policytype,storySolution,transId);
				    
			}
			catch(Exception e)
			{
				logger.error("Error in getPolicyGenerationResponse-"+e);
			}
		}
		logger.info("getPolicyGenerationResponse : End");
		return PolicyNo;
	}
	
	public String policyGenerationProcess(String testPlanType, String storySolution,String transId )
	{
		logger.debug("policyGenerationProcess : Start");
		String policyno="";
		testPlanType = testPlanType.replace("'", "");
		NeoDao neoDao = new NeoDaoImpl();
		try
		{
			logger.info("execution : Start");
			List<String> policyList = neoDao.callProceduresForUniquePolicy(testPlanType,storySolution,transId);
			if(policyList!=null && policyList.size() > 0 && !policyList.get(1).equalsIgnoreCase("") )
			{
				int policyGenerationStatus = Integer.parseInt(policyList.get(0));
				policyno = policyList.get(1);
				if(policyGenerationStatus==0)
				{
					policyno="{\"RESPONSE\":{\"POLICYNO\":"+policyno+" , \"STATUS\":\"Success\" , \"RESPONSEMSG\":\"Policy has been delivered\"}}";
					logger.info("Policy Fetch Successfully");
				}
				else
				{
					logger.info("After Executing query total change count is:-"+policyno + "1St excution");
					policyno="{\"RESPONSE\":{\"POLICYNO\":\"\" , \"STATUS\":\"Fail\" , \"RESPONSEMSG\":\"Policy Numbers in DB for this plan is '0',please fill the DB!\"}}";
				}
			}
			else
			{
				logger.info("Re execution : Start");
				List<String> policyList1 = neoDao.callProceduresForUniquePolicy(testPlanType,storySolution,transId);
				if(policyList1!=null && policyList1.size() > 0 && !policyList1.get(0).equalsIgnoreCase(""))
				{
					int policyGenerationStatus = Integer.parseInt(policyList1.get(0));
					policyno = policyList1.get(1);
					if(policyGenerationStatus==0)
					{
						policyno="{\"RESPONSE\":{\"POLICYNO\":"+policyno+" , \"STATUS\":\"Success\" , \"RESPONSEMSG\":\"Policy has been delivered\"}}";
						logger.info("Policy Fetch Successfully");
					}
					else
					{
						logger.info("After Executing query total change count is:-"+policyno + "Re excution");
						policyno="{\"RESPONSE\":{\"POLICYNO\":\"\" , \"STATUS\":\"Fail\" , \"RESPONSEMSG\":\"Policy Numbers in DB for this plan is '0',please fill the DB!\"}}";
					}
				}
				else
				{
					logger.info("After Executing query total change count is:-"+policyno + "Re excution");
					policyno="{\"RESPONSE\":{\"POLICYNO\":\"\" , \"STATUS\":\"Fail\" , \"RESPONSEMSG\":\"Policy Numbers in DB for this plan is '0',please fill the DB!\"}}";
				}
				logger.info("Re execution : End");
			}
			logger.info("execution : End");
		}
		catch(Exception e)
		{
			logger.error("Error while getting policy generation process:"+e);
			
		}       		        		  	
		logger.debug("policyGenerationProcess : End");     
		return policyno;
	}
}