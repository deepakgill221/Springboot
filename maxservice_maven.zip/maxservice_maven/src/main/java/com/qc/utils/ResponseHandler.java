package com.qc.utils;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class ResponseHandler
{

	public Map<String, String> responseTraverseCRIFPAN(String responseXml) throws ParserConfigurationException, SAXException, IOException{

		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(responseXml));
		Map<String, String> resMap = new HashMap<String,String>();

		Document doc = db.parse(is);
		NodeList nodes = doc.getElementsByTagName("RESPONSE");
		//System.out.println(nodes.getLength());
		for (int i = 0; i < nodes.getLength(); i++) 
		{
			Element element = (Element) nodes.item(i);

			NodeList name = element.getElementsByTagName("STATUS");
			Element line = (Element) name.item(0);
			resMap.put("STATUS",getCharacterDataFromElement(line));

			if(resMap.get("STATUS").equalsIgnoreCase("Y"))
			{
				NodeList title = element.getElementsByTagName("VALUE");
				line = (Element) title.item(0);
				resMap.put("VALUE",getCharacterDataFromElement(line));

			}
			else
			{
			}
			//		      Response 

			Map<String, String> finalResponse = new HashMap<String, String>();


			if((resMap.get("STATUS").equalsIgnoreCase("Y")) && ((resMap.get("VALUE").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("VALUE"))>=80)))
			{
				finalResponse.put("RESPONSE_STATUS","200");
				finalResponse.put("PAN_STATUS","Matched");
				finalResponse.put("NAME_STATUS","Matched");
				finalResponse.put("DOB_STATUS","");
			}
			else
			{
				finalResponse = null;
			}

			return finalResponse;

		}

		return null;
	}


	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "";
	}



	public Map<String, String> responseTraverseCRIFDOB(String responseXml) throws ParserConfigurationException, SAXException, IOException{

		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(responseXml));
		Map<String, String> resMap = new HashMap<String,String>();

		Document doc = db.parse(is);
		NodeList nodes = doc.getElementsByTagName("RESPONSE");
		//		    System.out.println(nodes.getLength());
		for (int i = 0; i < nodes.getLength(); i++) 
		{
			Element element = (Element) nodes.item(i);

			NodeList name = element.getElementsByTagName("STATUS");
			Element line = (Element) name.item(0);
			resMap.put("STATUS",getCharacterDataFromElement(line));


			NodeList title = element.getElementsByTagName("VALUE");
			line = (Element) title.item(0);
			resMap.put("VALUE",getCharacterDataFromElement(line));


			//		      Response 

			Map<String, String> finalResponse = new HashMap<String, String>();


			if((resMap.get("STATUS").equalsIgnoreCase("Y")) && resMap.get("VALUE").equalsIgnoreCase("100") || Integer.parseInt(resMap.get("VALUE"))>=80)
			{
				finalResponse.put("RESPONSE_STATUS","200");
				finalResponse.put("DOB_STATUS","Matched");
				finalResponse.put("NAME_STATUS","Matched");
				finalResponse.put("PAN_STATUS","");
			}
			else
			{
				finalResponse= null;
			}

			return finalResponse;

		}


		return null;
	}


	//############### Credit Bureau 2.0 #################################################


	public Map<String, String> responseTraverseNeoAcknwldge(String responseXml) throws ParserConfigurationException, SAXException, IOException{

		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(responseXml));
		Map<String, String> resMap = new HashMap<String,String>();

		Document doc = db.parse(is);
		NodeList nodes = doc.getElementsByTagName("INQUIRY");
		//		    System.out.println(nodes.getLength());
		for (int i = 0; i < nodes.getLength(); i++) 
		{
			Element element = (Element) nodes.item(i);

			NodeList title = element.getElementsByTagName("INQUIRY-UNIQUE-REF-NO");
			Element line = (Element) title.item(0);
			resMap.put("INQ_REF-NO",getCharacterDataFromElement(line));

			NodeList name = element.getElementsByTagName("REPORT-ID");
			line = (Element) name.item(0);
			resMap.put("REPORT-ID",getCharacterDataFromElement(line));

			NodeList date = element.getElementsByTagName("REQUEST-DT-TM");
			line = (Element) date.item(0);
			resMap.put("REQUEST_DT",getCharacterDataFromElement(line));

			try
			{
				NodeList code = element.getElementsByTagName("CODE");
				line = (Element) code.item(0);
				resMap.put("ERROR_CODE",getCharacterDataFromElement(line));
			}
			catch(Exception e)
			{
				resMap.put("ERROR_CODE","");
			}

		}

		Map<String, String> finalResponse = new HashMap<String, String>();

		if(!resMap.get("INQ_REF-NO").equalsIgnoreCase("") 
				&& !resMap.get("INQ_REF-NO").equals(null)
				&& !resMap.get("REPORT-ID").equalsIgnoreCase("")
				&& !resMap.get("REPORT-ID").equals(null)
				&& !resMap.get("REQUEST_DT").equalsIgnoreCase("")
				&& !resMap.get("REQUEST_DT").equals(null)
				)
		{
			finalResponse.put("INQ_REF-NO",resMap.get("INQ_REF-NO").toString());
			finalResponse.put("REPORT-ID",resMap.get("REPORT-ID").toString());
			finalResponse.put("REQUEST_DT",resMap.get("REQUEST_DT").toString());
			finalResponse.put("ERROR_CODE",resMap.get("ERROR_CODE").toString());
		}
		else
		{
			finalResponse = null;
		}
		return finalResponse;
	}

	public Map<String, String> responseTraverseNeoCRIFService2(String responseXml) throws ParserConfigurationException, SAXException, IOException
	{

		try{
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			String refResponse = responseXml.replace("(<", "(Less than ").replace("(>=", "(Greater than ");
			is.setCharacterStream(new StringReader(refResponse));
			Map<String, String> resMap = new HashMap<String,String>();
			Map<String, String> finalResponse = new HashMap<String, String>();

			Document doc = db.parse(is);

			NodeList nList = doc.getElementsByTagName("REQ-SERVICE");

			for (int temp = 0; temp < nList.getLength(); temp++) 
			{
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;


					if(eElement.getElementsByTagName("STATUS").item(0).getTextContent().equalsIgnoreCase("Y"))
					{
						if(temp<4)
						{
							//				            	   if(temp==5)
							//				            	   {
							//				            	   }
						}
					}
					//			        Storing data in a map

					resMap.put("REQ-SERVICE-TYPE-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent());
					resMap.put("STATUS-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("STATUS").item(0).getTextContent());
					//			               resMap.put("SCORE-NAME-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-NAME").item(0).getTextContent());

					if(eElement.getElementsByTagName("STATUS").item(0).getTextContent().equalsIgnoreCase("Y"))
					{
						resMap.put("SCORE-VALUE-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-VALUE").item(0).getTextContent());
						if(temp<4)
						{
							resMap.put("REMARKS-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("REMARKS").item(0).getTextContent());
						}
						else
						{
							resMap.put("SCORE-DESCRIPTION-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-DESCRIPTION").item(0).getTextContent());
						}
					}
				}
			}


			//############################### FINAL RESPONSE STARTED ###############################


			//			########       FOR PAN & NAME

			if(resMap.get("STATUS-PAN").equalsIgnoreCase("Y"))
			{
				//				    	Spliting the remarks content of PAN.  added 21-07-2016 Rishabh Sharma
				String line = resMap.get("REMARKS-PAN");
				String[] rmrkPanName = line.split(",");

				finalResponse.put("PAN", rmrkPanName[0].trim());
				finalResponse.put("NAME", rmrkPanName[1].trim());

				if((resMap.get("SCORE-VALUE-PAN").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("SCORE-VALUE-PAN"))>=80))
				{
					finalResponse.put("PAN_STATUS","Matched");
					finalResponse.put("NAME_STATUS","Matched");
				}
				else
				{
					finalResponse.put("PAN_STATUS","Not Matched");
					finalResponse.put("NAME_STATUS","Not Matched");
				}

			}  
			else
			{
				finalResponse.put("PAN", "");
				finalResponse.put("NAME", "");
				finalResponse.put("PAN_STATUS","Not Matched");
				finalResponse.put("NAME_STATUS","Not Matched");
			}


			//			########       FOR DOB

			if(resMap.get("STATUS-DOB").equalsIgnoreCase("Y"))
			{
				finalResponse.put("DOB", resMap.get("REMARKS-DOB").trim());

				if((resMap.get("SCORE-VALUE-DOB").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("SCORE-VALUE-DOB"))>=80))
				{
					finalResponse.put("DOB_STATUS","Matched");
				}
				else
				{
					finalResponse.put("DOB_STATUS","Not Matched");
				}
			}  
			else
			{
				finalResponse.put("DOB","");
				finalResponse.put("DOB_STATUS","Not Matched");
			}

			//			        ###### FOR ADDRESS & PINCODE

			if(resMap.get("STATUS-ADDRESS").equalsIgnoreCase("Y"))
			{
				finalResponse.put("ADDRESS", resMap.get("REMARKS-ADDRESS").trim());
				//						Splitting the PIN code from the address added 05-08-2016 Rishabh Sharma
				String pincode = resMap.get("REMARKS-ADDRESS");
				String rmrkPincode = pincode.substring((pincode.length()-6), pincode.length());
				finalResponse.put("PINCODE",rmrkPincode.trim());

				if((resMap.get("SCORE-VALUE-ADDRESS").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("SCORE-VALUE-ADDRESS"))>=75))
				{
					finalResponse.put("ADDRESS_STATUS","Matched");
					finalResponse.put("PINCODE_STATUS","Matched");
				}
				else
				{
					finalResponse.put("ADDRESS_STATUS","Not Matched");
					finalResponse.put("PINCODE_STATUS","Not Matched");
				}
			}  
			else
			{
				finalResponse.put("ADDRESS","");
				finalResponse.put("ADDRESS_STATUS","Not Matched");
				finalResponse.put("PINCODE","");
				finalResponse.put("PINCODE_STATUS","Not Matched");
			}

			//			     ###### FOR MOBILE & EMAIL

			if(resMap.get("STATUS-BUREAU").equalsIgnoreCase("Y"))
			{
				String mobStatus = "";
				String emailStatus="";
				String mobEmail = resMap.get("REMARKS-BUREAU").trim();
				if(mobEmail.contains("Yes"))
				{
					//			    MOBILE NUMBER //
					if(!mobEmail.contains("No-Phone"))
					{
						try
						{
							String phone= mobEmail.substring(mobEmail.indexOf("Yes", 0), mobEmail.length());
							if(phone.contains("Yes"))
							{
								mobStatus = phone.subSequence(phone.indexOf("-", 4)+1, phone.indexOf("%", phone.indexOf("-", 4)+1)).toString();
								finalResponse.put("MOBILE",phone.subSequence(phone.indexOf("%", phone.indexOf("-", 4)+1)+2, phone.indexOf("-", phone.indexOf("%", phone.indexOf("-", 4)+1)+2)).toString());
							}
							else
							{
								finalResponse.put("MOBILE","");
							}

							if((resMap.get("SCORE-VALUE-BUREAU").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("SCORE-VALUE-BUREAU"))>=80))
							{
								if(mobStatus.equalsIgnoreCase("100") || Integer.parseInt(mobStatus)>=80)
								{
									finalResponse.put("MOBILE_STATUS","Matched");
								}
								else
								{
									finalResponse.put("MOBILE_STATUS","Not Matched");
								}
							}
							else
							{
								finalResponse.put("MOBILE_STATUS","Not Matched");
							}

						}
						catch(Exception e)
						{
							finalResponse.put("MOBILE","");
							finalResponse.put("MOBILE_STATUS","Not Matched");
						}

						//			EMAIL ADDRESS //	
						try
						{
							String phone1 =mobEmail.substring(mobEmail.indexOf("Yes", 0), mobEmail.length());
							String email= mobEmail.substring(mobEmail.indexOf("from Bureau", 0)+11, mobEmail.length());
							if(email.contains("Yes"))
							{
								emailStatus = email.subSequence(phone1.indexOf("-", 4)+1, email.indexOf("%", phone1.indexOf("-", 4)+1)).toString();
								finalResponse.put("EMAIL",email.subSequence(email.indexOf("%", phone1.indexOf("-", 4)+1)+2, email.indexOf("-", email.indexOf("%", phone1.indexOf("-", 4)+1)+2)).toString());
							}
							else
							{
								finalResponse.put("EMAIL","");
							}

							if((resMap.get("SCORE-VALUE-BUREAU").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("SCORE-VALUE-BUREAU"))>=80))
							{
								if(emailStatus.equalsIgnoreCase("100") || Integer.parseInt(emailStatus)>=80)
								{
									finalResponse.put("EMAIL_STATUS","Matched");
								}
								else
								{
									finalResponse.put("EMAIL_STATUS","Not Matched");
								}
							}
							else
							{
								finalResponse.put("EMAIL_STATUS","Not Matched");
							}
						}
						catch(Exception e)
						{
							finalResponse.put("EMAIL","");
							finalResponse.put("EMAIL_STATUS","Not Matched");
						}
					}
					else
					{
						finalResponse.put("MOBILE","");
						finalResponse.put("MOBILE_STATUS","Not Matched");
						try
						{
							String phone1 =mobEmail.substring(mobEmail.indexOf("Yes", 0), mobEmail.length());
							String email =mobEmail.substring(mobEmail.indexOf("Yes", 0), mobEmail.length());
							if(email.contains("Yes"))
							{
								emailStatus = email.subSequence(email.indexOf("-", 4)+1, email.indexOf("%", email.indexOf("-", 4)+1)).toString();
								finalResponse.put("EMAIL",email.subSequence(email.indexOf("%", phone1.indexOf("-", 4)+1)+2, email.indexOf("-", email.indexOf("%", phone1.indexOf("-", 4)+1)+2)).toString());
							}
							else
							{
								finalResponse.put("EMAIL","");
							}

							if((resMap.get("SCORE-VALUE-BUREAU").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("SCORE-VALUE-BUREAU"))>=80))
							{
								if(emailStatus.equalsIgnoreCase("100") || Integer.parseInt(emailStatus)>=80)
								{
									finalResponse.put("EMAIL_STATUS","Matched");
								}
								else
								{
									finalResponse.put("EMAIL_STATUS","Not Matched");
								}
							}
							else
							{
								finalResponse.put("EMAIL_STATUS","Not Matched");
							}
						}
						catch(Exception e)
						{
							finalResponse.put("EMAIL","");
							finalResponse.put("EMAIL_STATUS","Not Matched");
						}
					}
				}  
				else
				{
					finalResponse.put("MOBILE","");
					finalResponse.put("MOBILE_STATUS","Not Matched");
					finalResponse.put("EMAIL","");
					finalResponse.put("EMAIL_STATUS","Not Matched");
				}

			}
			else
			{
				finalResponse.put("MOBILE","");
				finalResponse.put("MOBILE_STATUS","Not Matched");
				finalResponse.put("EMAIL","");
				finalResponse.put("EMAIL_STATUS","Not Matched");
			}



			//			 	     ###### FOR OCCUPATION CLASS
			if(resMap.get("STATUS-OCCUPATION CLASS").equalsIgnoreCase("Y"))
			{
				finalResponse.put("OCCPTNCLS", resMap.get("SCORE-DESCRIPTION-OCCUPATION CLASS").trim());
			}  
			else
			{
				finalResponse.put("OCCPTNCLS","");
			}

			//			 	     ###### FOR CREDIT SCORE
			if(resMap.get("STATUS-CB SCORE").equalsIgnoreCase("Y"))
			{
				finalResponse.put("CREDITSCR", resMap.get("SCORE-VALUE-CB SCORE").trim());
			}  
			else
			{
				finalResponse.put("CREDITSCR","");
			}

			//			 	     ###### FOR INCOME SEGMENT
			if(resMap.get("STATUS-INCOME SEGMENT").equalsIgnoreCase("Y"))
			{
				String esIncm = resMap.get("SCORE-DESCRIPTION-INCOME SEGMENT").trim();

				if(esIncm.contains("(")||esIncm.contains(")"))
				{
					int i = esIncm.indexOf("(");
					int j = esIncm.indexOf(")");
					finalResponse.put("ESTMTDINCM", esIncm.substring(i+1,j));
				}
				else
				{
					finalResponse.put("ESTMTDINCM","");
				}
			}  
			else
			{
				finalResponse.put("ESTMTDINCM","");
			}

			return finalResponse;
		} 
		catch (Exception e)
		{
			return null;
		}
	}


	public Map<String, String> responseTraverseNeoCRIFService1(String responseXml) throws ParserConfigurationException, SAXException, IOException
	{
		try
		{
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			String refResponse = responseXml.replace("(<", "(Less than ").replace("(>=", "(Greater than ");
			is.setCharacterStream(new StringReader(refResponse));
			Map<String, String> resMap = new HashMap<String,String>();
			Map<String, String> finalResponse = new HashMap<String, String>();

			Document doc = db.parse(is);

			NodeList nList = doc.getElementsByTagName("REQ-SERVICE");

			for (int temp = 0; temp < nList.getLength(); temp++) 
			{
				Node nNode = nList.item(temp);
				//			            System.out.println("\nCurrent Element :" + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;

					//			               System.out.println("SCORE-NAME : " + eElement.getElementsByTagName("SCORE-NAME").item(0).getTextContent());

					if(eElement.getElementsByTagName("STATUS").item(0).getTextContent().equalsIgnoreCase("Y"))
					{
						if(temp<4)
						{
							//				            	   if(temp==5)
							//				            	   {
							//				            	   }
						}
						else
						{
						}
					}
					//			        Storing data in a map

					resMap.put("REQ-SERVICE-TYPE-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent());
					resMap.put("STATUS-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("STATUS").item(0).getTextContent());
					//			               resMap.put("SCORE-NAME-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-NAME").item(0).getTextContent());

					if(eElement.getElementsByTagName("STATUS").item(0).getTextContent().equalsIgnoreCase("Y"))
					{
						resMap.put("SCORE-VALUE-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-VALUE").item(0).getTextContent());
						if(temp<4)
						{
							resMap.put("REMARKS-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("REMARKS").item(0).getTextContent());
						}
						else
						{
							resMap.put("SCORE-DESCRIPTION-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-DESCRIPTION").item(0).getTextContent());
						}
					}
				}
			}


			//############################### FINAL RESPONSE STARTED ###############################

			//			########       FOR PAN & NAME

			if(resMap.get("STATUS-PAN").equalsIgnoreCase("Y"))
			{
				//				    	Spliting the remarks content of PAN.  added 21-07-2016 Rishabh Sharma
				String line = resMap.get("REMARKS-PAN");
				String[] rmrkPanName = line.split(",");

				finalResponse.put("PAN", rmrkPanName[0].trim());
				finalResponse.put("NAME", rmrkPanName[1].trim());

				if((resMap.get("SCORE-VALUE-PAN").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("SCORE-VALUE-PAN"))>=80))
				{
					finalResponse.put("PAN_STATUS","Matched");
					finalResponse.put("NAME_STATUS","Matched");
				}
				else
				{
					finalResponse.put("PAN_STATUS","Not Matched");
					finalResponse.put("NAME_STATUS","Not Matched");
				}

			}  
			else
			{
				finalResponse.put("PAN", "");
				finalResponse.put("NAME", "");
				finalResponse.put("PAN_STATUS","Not Matched");
				finalResponse.put("NAME_STATUS","Not Matched");
			}


			//			########       FOR DOB

			if(resMap.get("STATUS-DOB").equalsIgnoreCase("Y"))
			{
				finalResponse.put("DOB", resMap.get("REMARKS-DOB").trim());

				if((resMap.get("SCORE-VALUE-DOB").equalsIgnoreCase("100")|| Integer.parseInt(resMap.get("SCORE-VALUE-DOB"))>=80))
				{
					finalResponse.put("DOB_STATUS","Matched");
				}
				else
				{
					finalResponse.put("DOB_STATUS","Not Matched");
				}
			}  
			else
			{
				finalResponse.put("DOB","");
				finalResponse.put("DOB_STATUS","Not Matched");
			}
			return finalResponse;
		} 
		catch (Exception e)
		{
			return null;
		}
	}

	public static String mailParser(String email)
	{


		return null;
	}




}
