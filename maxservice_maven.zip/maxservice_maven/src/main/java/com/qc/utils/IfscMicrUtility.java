package com.qc.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.qc.controller.NeoControllerRest;
import com.qc.dao.NeoDao;
import com.qc.daoImpl.NeoDaoImpl;

public class IfscMicrUtility 
{
	private static Logger logger = LogManager.getLogger(NeoControllerRest.class);
	public String getIFSCServiceData(String key) throws Exception
	{
		String ifscCode="";
	    String microCode="";
		logger.debug("Came inside SavePersistenceAction for savePersistenceData().");
		String returnOutput=new String();
		
		if(key!=null)
		{
			JSONObject jsonrequest=new JSONObject(key);
			JSONObject info = jsonrequest.getJSONObject("REQUEST");
		    ifscCode = info.getString("IFSCCODE");
		    microCode = info.getString("MICROCODE");
		    logger.debug("Input Json for IFSC code :: "+key);
			returnOutput=this.getResponseForIFSC(ifscCode.toUpperCase(),microCode.toUpperCase());
		}
		else
		{
			returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"Invalid Request Json\"}";
		}
		logger.info("returnOutput ifsc "+returnOutput);
		logger.debug("Going outside SavePersistenceAction for savePersistenceData().");
		return returnOutput;
	}
	
	public String getResponseForIFSC(String ifsccode,String microCode)
	{	
		logger.info("Came inside Request Logger DAO in Save Response Details:");
		if(microCode!=null && ifsccode!=null )
		{
			try
			{   
				NeoDao neoDao = new NeoDaoImpl();
				ifsccode=neoDao.getIfscMicr(ifsccode,microCode);
				    
			}
			catch(Exception e)
			{
				logger.error("Error in Save Response Details:-"+e);
			}
			logger.info("Came outside Request Logger DAO in Save Response Details.");
		}
		
		return ifsccode;
	}
	
}