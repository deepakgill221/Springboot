package com.qc.utils;

import com.qc.serviceImpl.CrifService;
import com.qc.serviceImpl.EquifaxService;
import com.qc.serviceImpl.EquifaxServiceHelper;

public class ObjectFactory 
{
	 public com.qc.service.ExternalServices getService(String serviceType)
	 {
	      if(serviceType == null)
	      {
	         return null;
	      }		
	      if(serviceType.equalsIgnoreCase("CRIF"))
	      {
	         return new CrifService();
	      } 
	      else if(serviceType.equalsIgnoreCase("EQUIFAX"))
	      {
	         return new EquifaxService();
	      } 
	      else if(serviceType.equalsIgnoreCase("EQUIFAX_2.0"))
	      {
		         return new EquifaxServiceHelper();
		      } 
	      return null;
	   }
}
