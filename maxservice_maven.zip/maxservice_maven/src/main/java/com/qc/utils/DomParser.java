package com.qc.utils;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


public class DomParser {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		    String xmlRecords = "<VERIFICATION-REPORT> <HEADER><DATE-OF-REQUEST>11-10-2015</DATE-OF-REQUEST><REQUEST-DT-TM>23-02-2016 15:26:42.525</REQUEST-DT-TM><DATE-OF-ISSUE>23-02-2016</DATE-OF-ISSUE><PREPARED-FOR>INS0000002</PREPARED-FOR><PREPARED-FOR-ID>MLI</PREPARED-FOR-ID><REPORT-ID>CHMVER16022340183953</REPORT-ID><REQ-SERVICE-TYPE>PAN</REQ-SERVICE-TYPE><STATUS>SUCCESS</STATUS> </HEADER> <REQUEST><NAME>NITIN JAIN</NAME><DOB>07-06-1979</DOB><AGE>28</AGE><AGE-AS-ON /><PAN>AFUPJ7365N</PAN><UID /><VOTER-ID /><GENDER /><ADDRESS-1>GANGA ELECTRICALS SHOP NO.3 SAHARANPUR Uttar Pradesh 247001</ADDRESS-1> </REQUEST><RESPONSES> <RESPONSE><REQ-SERVICE-TYPE>PAN</REQ-SERVICE-TYPE><STATUS>Y</STATUS><DESCRIPTION>Enquired Entity exists in bureau</DESCRIPTION><REMARKS><REMARK>Yes-PAN exist for Entity being verified</REMARK></REMARKS><SCORES> <SCORE><NAME>PAN_SCORE</NAME><VALUE>100</VALUE><DESCRIPTION>Primary Match (High Confidence)</DESCRIPTION> </SCORE></SCORES> </RESPONSE></RESPONSES> </VERIFICATION-REPORT>";

		    DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		    InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(xmlRecords));

		    Document doc = db.parse(is);
		    NodeList nodes = doc.getElementsByTagName("RESPONSE");
		    System.out.println(nodes.getLength());
		    for (int i = 0; i < nodes.getLength(); i++) 
		    {
		      Element element = (Element) nodes.item(i);

		      NodeList name = element.getElementsByTagName("STATUS");
		      Element line = (Element) name.item(0);
		      System.out.println("STATUS: " + getCharacterDataFromElement(line));

		      NodeList title = element.getElementsByTagName("VALUE");
		      line = (Element) title.item(0);
		      System.out.println("VALUE: " + getCharacterDataFromElement(line));
		    }

		  }

		  public static String getCharacterDataFromElement(Element e) {
		    Node child = e.getFirstChild();
		    if (child instanceof CharacterData) {
		      CharacterData cd = (CharacterData) child;
		      return cd.getData();
		    }
		    return "";
		  }

}
