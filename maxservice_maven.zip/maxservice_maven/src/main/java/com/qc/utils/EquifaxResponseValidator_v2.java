package com.qc.utils;

import java.util.HashMap;
import java.util.Map;

import com.equifax.services.eport.servicedefs._1_0.EquifaxApiResponseDTO;

public class EquifaxResponseValidator_v2 {
	
	public Map<String,String> matchAndValidateEquifaxData(EquifaxApiResponseDTO dto,String fName,String mName,String lName,String pan,
			String postal,String state,String validationType,String dob,String mobileno,String email){
		Map<String,String> response = new HashMap<String,String>();

		if(validationType != null && validationType.equalsIgnoreCase("ALL")){
			response.put("PAN", dto.getPan());
			response.put("DOB", dto.getDob());
			response.put("NAME", dto.getfName() +" "+dto.getmName() +" "+dto.getlName());
			response.put("ADDRESS", dto.getAddress());
			response.put("PINCODE", dto.getPinCode());
			response.put("MOBILE", dto.getMobile());
			response.put("EMAIL", dto.getEmailID());
			response.put("OCCPTNCLS", dto.getOccptnCls());
			response.put("ESTMTDINCM", dto.getEstmtdIncm());
			response.put("PAN_STATUS", "Not Matched");
			response.put("DOB_STATUS", "Not Matched");
			response.put("NAME_STATUS", "Not Matched");
			response.put("ADDRESS_STATUS", "Not Matched");
			response.put("PINCODE_STATUS", "Not Matched");
			response.put("MOBILE_STATUS", "Not Matched");
			response.put("EMAIL_STATUS", "Not Matched");
			response.put("CREDITSCR", "Not Matched");
			
			if(pan.contains(dto.getPan().trim()) && !(dto.getPan().trim()).isEmpty()){
				response.put("PAN_STATUS", "Matched");
			}if(dob.contains(dto.getDob().trim()) && !(dto.getDob().trim()).isEmpty()){
				response.put("DOB_STATUS", "Matched");
			}if((dto.getfName().trim().contains(fName) || dto.getfName().trim().contains(mName) 
					|| dto.getfName().trim().contains(lName)) && !(dto.getfName().trim()).isEmpty()){
				response.put("NAME_STATUS", "Matched");
			}/*if(address.contains(dto.getName().trim())){
				response.put("ADDRESS_STATUS", "Matched");
			}*/
			if(postal.contains(dto.getPinCode().trim()) && !(dto.getPinCode().trim()).isEmpty()){
				response.put("PINCODE_STATUS", "Matched");
			}if(mobileno.contains(dto.getMobile().trim()) && !(dto.getMobile().trim()).isEmpty()){
				response.put("MOBILE_STATUS", "Matched");
			}if(email.contains(dto.getEmailID().trim()) && !(dto.getEmailID().trim()).isEmpty()){
				response.put("EMAIL_STATUS", "Matched");
			}
			
		}else if(validationType != null && validationType.equalsIgnoreCase("PANDOB")){
			response.put("PAN", dto.getPan());
			response.put("DOB", dto.getDob());
			response.put("NAME", dto.getfName() +" "+dto.getmName() +" "+dto.getlName());
			response.put("PAN_STATUS", "Not Matched");
			response.put("DOB_STATUS", "Not Matched");
			response.put("NAME_STATUS", "Not Matched");
			
			if(pan.contains(dto.getPan().trim()) && !(dto.getPan().trim()).isEmpty()){
				response.put("PAN_STATUS", "Matched");
			}if(dob.contains(dto.getDob().trim()) && !(dto.getDob().trim()).isEmpty()){
				response.put("DOB_STATUS", "Matched");
			}if((dto.getfName().trim().contains(fName) || dto.getfName().trim().contains(mName) 
					|| dto.getfName().trim().contains(lName)) && !(dto.getfName().trim()).isEmpty()){
				response.put("NAME_STATUS", "Matched");
			}
		}
				
		return response;
	}

}
