package com.qc.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MultiFormatDate {

	public static String getFormattedDate(String dateAsString,String ipFormat,String opFormat) throws ParseException{
		String formattedDate = "";
		SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);//("dd/MM/yyyy hh:mm:ss a");
		Date date = sdf.parse(dateAsString);
		sdf = new SimpleDateFormat(opFormat);//(dd-MMM-yy hh:mm:ss a)
		formattedDate = sdf.format(date);
		return formattedDate;
	}
}
