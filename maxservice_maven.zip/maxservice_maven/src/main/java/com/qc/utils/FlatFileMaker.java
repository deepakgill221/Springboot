package com.qc.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class FlatFileMaker {

	private static Logger logger = LogManager.getLogger(FlatFileMaker.class);
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String request = "{\"fname\": \"Rishabh\",\"mname\": \"\",\"lname\": \"Sharma\",\"dob\": \"26-06-1993\",\"gender\": \"male\",\"email\": \"rishabh.sharma9818@gmail.com\",\"address\": \"ghaziabad\",\"mobileno\": \"9818411217\",\"pan\": \"DYQPS2000P\",\"validationType\": \"PAN\",  \"app_name\": \"TPP\" }";
		String response = "{\"Response\": {\"ResponseInfo\": {\"UserName\": \"\",\"CreationDate\": \"\",\"CreationTime\": \"\",\"SourceInfoName\":\"\",\"RequestorToken\": \"\",\"UserEmail\": \"\",\"LastSyncDateTime\": \"\"},\"ResponsePayload\": {\"Transactions\": [{\"Key1\":\"\",\"Key2\": \"\",\"Key3\": \"\",\"Key4\": \"\",\"Key5\": \"\",\"ValidationType\": \"PAN\",\"TransTrackingID\": \"\",\"TransactionData\": {\"status\":\"200\",\"statusDesc\":\"Success\",\"message\":\"Success\",\"pan\":\"AFUPJ7365N\",\"pan_status\":\"Not Matched\",\"dob\":\"16-06-1967\",\"dob_status\":\"Matched\",\"name\":\"NITIN JAIN\",\"name_status\":\"Not Matched\",\"address\":\"B TYPE B 14/7 RAJSARTHI SOCITY INDIRA NAGAR NASHIK NAGPUR MH 422009\",\"address_status\":\"Matched\",\"pinCode\":\"422009\",\"pinCode_status\":\"Matched\",\"mobile\":\"9860685829\",\"mobile_status\":\"Matched\",\"emailID\":\"SHUBHAGIDHANANJAY.JOSHI@GMAIL.COM\",\"emailID_status\":\"Matched\",\"occptnCls\":\"SALARIED\",\"credtScr\":\"600\",\"estmtdIncm\":\"400000-600000\" }";
//		generateFlatFile("C:\\LOGS\\PAN\\", request, response, "TPP");
//		generateNeoPDF("C:\\LOGS\\PAN\\", request, response, "TPP", "CRIF");
//		generateNeoPDFFormatted("C:\\LOGS\\PAN\\", request, response, "TPP", "CRIF");

	}
	public static void generateFlatFile(String sFileName, String requestJSON, String responseJSON, String appName, String serviceName)
	{

		FileWriter writer = null;
		try 
		{
			sFileName+="panFile_"+new SimpleDateFormat("dd_MM_yyyy").format(Calendar.getInstance().getTime())+".txt";
			File f = new File(sFileName);

			if(f.exists()){
				writer = new FileWriter(sFileName, true);
			}else{
				writer = new FileWriter(sFileName, false);
			}

			String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());

			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write("DATE  : "+timeStamp);
			bufferedWriter.newLine();
			bufferedWriter.write("APP_NAME  : "+appName.toUpperCase());
			bufferedWriter.newLine();
			bufferedWriter.write("SERVICE_PROVIDER : "+serviceName);
			bufferedWriter.newLine();
			bufferedWriter.write("REQUEST--->>>>>>>>>> "+requestJSON);
			bufferedWriter.newLine();
			bufferedWriter.write("RESPONSE--->>>>>>>>> "+responseJSON);
			bufferedWriter.newLine();
			bufferedWriter.newLine();
			bufferedWriter.close();

		} catch (IOException e) 
		{
			logger.error("We are in Exception : "+e);
		}
		finally
		{
			try
			{
				if(writer!=null)
				{
					writer.close();
				}
				
			}
			catch(Exception ex)
			{
				logger.error("We are in Exception : "+ex);
			}
		}
	}

	
	public static void generateNeoFlatFile(String sFileName, String requestJSON, String responseJSON, String appName, String serviceName)
	{

		FileWriter writer = null;
		try 
		{
			String requestServiceName= "";
			
			sFileName+="panFile_"+new SimpleDateFormat("dd_MM_yyyy").format(Calendar.getInstance().getTime())+".txt";
			File f = new File(sFileName);

			if(f.exists())
			{
				writer = new FileWriter(sFileName, true);
			}
			else
			{
				writer = new FileWriter(sFileName, false);
			}
			
			String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());

			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write("Credit bureau 2.0 -----");
			bufferedWriter.newLine();
			bufferedWriter.write("DATE  : "+timeStamp);
			bufferedWriter.newLine();
			bufferedWriter.write("Requested Service : "+requestServiceName);
			bufferedWriter.newLine();
			bufferedWriter.write("APP_NAME  : "+appName.toUpperCase());
			bufferedWriter.newLine();
			bufferedWriter.write("SERVICE_PROVIDER : "+serviceName);
			bufferedWriter.newLine();
			bufferedWriter.write("REQUEST--->>>>>>>>>> "+requestJSON);
			bufferedWriter.newLine();
			bufferedWriter.write("RESPONSE--->>>>>>>>> "+responseJSON);
			bufferedWriter.newLine();
			bufferedWriter.newLine();
			bufferedWriter.close();

		} 
		catch (IOException e) 
		{
			logger.error("We are in exception !",e);
		}
		finally
		{
			try
			{
				if(writer!=null)
				{
					writer.close();
				}
				
			}
			catch(Exception ex)
			{
				logger.error("We are in Exception : "+ex);
			}
		}
	}
	
	
//	public static void generateNeoPDF(String sFileName, String requestJSON, String responseJSON, String appName, String serviceName)
//	{
//		try 
//		{
//			if(responseJSON.contains("200"))
//			{	
//			responseJSON+=" 	 }  ]  }  }  }";
//			System.out.println(responseJSON);
//			Map responseData=null;
//			responseData=Commons.getGsonData(responseJSON); 
//
//			String JSONResp=(((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).toString().replaceAll(",", ",\n");
//			String Resp = JSONResp.replaceAll("=", " = ");
//			
//			String Resp1 = Resp.substring(1, (Resp.length()-1));
////			String Resp2 = Resp1.replaceAll("}", "");
//			System.out.println(Resp1);
////			Map responseData2=null;
////			responseData2=Commons.getGsonData(json); 
////			response.replaceAll(",", ",\n");
//			
//			sFileName+="panPDF_"+new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(Calendar.getInstance().getTime())+".pdf";
//            OutputStream file = new FileOutputStream(new File(sFileName));
//	          Document document = new Document();
//	          PdfWriter.getInstance(document, file);
//
//			     PdfPTable table=new PdfPTable(3);
//
//	             PdfPCell cell = new PdfPCell (new Paragraph ("Response"));
//
////				      cell.setColspan (2);
////				      cell.setHorizontalAlignment (Element.ALIGN_CENTER);
////				      cell.setPadding (10.0f);
////				      cell.setBackgroundColor (new BaseColor (140, 221, 8));					               
////
////				      table.addCell(cell);						               
//
//				      table.addCell("Details");
////				      table.addCell(responseData2.get("fname").toString().toUpperCase());
//				      table.addCell("Match (Y/N)");
//				      table.addCell("Details as per CB");
//				      table.addCell("Proposal Number");
//				      table.addCell("");
//				      table.addCell("-----policy no--");
//				      table.addCell("Name");
//				      table.addCell("NameStatus");
//				      table.addCell("NameDetails");
//				      table.addCell("DOB");
//				      table.addCell("DOBStatus");
//				      table.addCell("DOBDetails");
//				      table.addCell("PAN");
//				      table.addCell("PANStatus");
//				      table.addCell("PANDetails");
//				      table.setSpacingBefore(30.0f);       // Space Before table starts, like margin-top in CSS
//				      table.setSpacingAfter(30.0f);        // Space After table starts, like margin-Bottom in CSS								          
//
//			 //Now Insert Every Thing Into PDF Document
//				    document.open();//PDF document opened........			       
//
//
//					document.add(Chunk.NEWLINE);   //Something like in HTML :-)
////					document.add(chunk);
//				    document.add(new Paragraph("Document Generated On - "+new Date().toString()));
//                    document.add(new Paragraph("-  CREDIT BUREAU 2.0  -"));
//                    document.add(Chunk.NEWLINE); 
//                    document.add(new Paragraph("APP NAME : "+appName));
//                  
//                    document.add(new Paragraph("Response From : "+serviceName));
//                    document.add(Chunk.NEWLINE);
//                    document.add(new Paragraph(Resp1));
////					document.add(table);
//					
////					document.add(chunk1);
//
//					document.add(Chunk.NEWLINE);   //Something like in HTML :-)							    
//
////     				document.newPage();            //Opened new page
////					document.add(list);            //In the new page we are going to add list
//
//		         document.close();
//
//			             file.close();
//
//          System.out.println("Pdf created successfully..");
//			}
//      } catch (Exception e) {
//          e.printStackTrace();
//      }
//		
//		
//	}
	
//	public static void generateNeoPDFFormatted(String sFileName, String requestJSON, String responseJSON, String appName, String serviceName)
//	{
//	try 
//	{
//		responseJSON+=" 	 }  ]  }  }  }";
//		System.out.println(responseJSON);
//		Map responseData=null;
//		responseData=Commons.getGsonData(responseJSON); 
//		
//
//		String JSONResp=(((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).toString().replaceAll(",", ",\n");
//		String Resp = JSONResp.replaceAll("=", " = ");
//		
//		String Resp1 = Resp.substring(1, (Resp.length()-1));
////		String Resp2 = Resp1.replaceAll("}", "");
//		System.out.println(Resp1);
////		Map responseData2=null;
////		responseData2=Commons.getGsonData(json); 
////		response.replaceAll(",", ",\n");
//		
//		sFileName+="panPDF_"+new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(Calendar.getInstance().getTime())+".pdf";
//        OutputStream file = new FileOutputStream(new File(sFileName));
//          Document document = new Document();
//          PdfWriter.getInstance(document, file);
//
//		     PdfPTable table=new PdfPTable(3);
//
//             PdfPCell cell = new PdfPCell (new Paragraph ("Response"));
//
//			      table.addCell("Details");
////			      table.addCell(responseData2.get("fname").toString().toUpperCase());
//			      table.addCell("Match (Y/N)");
//			      table.addCell("Details as per CB");
//			      table.addCell("Proposal Number");
//			      table.addCell("");
//			      table.addCell("-----policy no--");
//			      table.addCell("Name");
//			      table.addCell("NameStatus");
//			      table.addCell("NameDetails");
//			      table.addCell("DOB");
//			      table.addCell("DOBStatus");
//			      table.addCell("DOBDetails");
//			      table.addCell("PAN");
//			      table.addCell("PANStatus");
//			      table.addCell("PANDetails");
//			      table.addCell("Address");
//			      table.addCell("AddressStatus");
//			      table.addCell("AddressDetails");
//			      table.addCell("Pincode");
//			      table.addCell("PincodeStatus");
//			      table.addCell("PincodeDetails");
//			      table.addCell("Mobile");
//			      table.addCell("MobileStatus");
//			      table.addCell("MobileDetails");
//			      table.addCell("Email id");
//			      table.addCell("EmailStatus");
//			      table.addCell("EmailDetails");
//			      table.addCell("Occupation Class");
//			      table.addCell("");
//			      table.addCell("Occupation Class");
//			      table.addCell("Credit Score");
//			      table.addCell("");
//			      table.addCell("Credit Score");
//			      table.addCell("Estimated Income");
//			      table.addCell("");
//			      table.addCell("Estimated Income");
//			      table.setSpacingBefore(30.0f);       // Space Before table starts, like margin-top in CSS
//			      table.setSpacingAfter(30.0f);        // Space After table starts, like margin-Bottom in CSS								          
//
//		 //Now Insert Every Thing Into PDF Document
//			    document.open();//PDF document opened........			       
//
//
//				document.add(Chunk.NEWLINE);   //Something like in HTML :-)
////				document.add(chunk);
//			    document.add(new Paragraph("Document Generated On - "+new Date().toString()));
//                document.add(new Paragraph("-  CREDIT BUREAU 2.0  -"));
//                document.add(Chunk.NEWLINE); 
//                document.add(new Paragraph("APP NAME : "+appName));
//              
//                document.add(new Paragraph("Response From : "+serviceName));
//                document.add(Chunk.NEWLINE);
////                document.add(new Paragraph(Resp1));
//				document.add(table);
//				
////				document.add(chunk1);
//
//				document.add(Chunk.NEWLINE);   //Something like in HTML :-)							    
//
//// 				document.newPage();            //Opened new page
////				document.add(list);            //In the new page we are going to add list
//
//	         document.close();
//
//		             file.close();
//
//      System.out.println("Pdf created successfully..");
//
//  } catch (Exception e) {
//      e.printStackTrace();
//  }
//	
//	}

	
	
}
