package com.qc.api.response;

import java.io.Serializable;

import com.qc.dto.DefaultRequestKeyDTO;

public class TotalPremiumResponse extends DefaultRequestKeyDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4124790152909501893L;
	String requiredPremium;

	public String getRequiredPremium() {
		return requiredPremium;
	}

	public void setRequiredPremium(String requiredPremium) {
		this.requiredPremium = requiredPremium;
	}

	@Override
	public String toString() {
		return "TotalPremiumResponse [requiredPremium=" + requiredPremium + "]";
	}
	
	
}
