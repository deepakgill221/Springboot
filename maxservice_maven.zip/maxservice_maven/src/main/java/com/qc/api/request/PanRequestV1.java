package com.qc.api.request;

import java.io.Serializable;

public class PanRequestV1 implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3323340779101002892L;
	private String fname;
	private String mname;
	private String lname;
	private String dob;
	private String gender;
	private String email;
	private String careOf;
	private String houseNo;
	private String street;
	private String landmark;
	private String location;
	private String postOffice;
	private String vill_city;
	private String subDistrict;
	private String district;
	private String state;
	private String stateCode;
	private String postalCode;
	private String mobileno;
	private String pan;
	private String validationType;
	private String app_name;

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCareOf() {
		return careOf;
	}

	public void setCareOf(String careOf) {
		this.careOf = careOf;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPostOffice() {
		return postOffice;
	}

	public void setPostOffice(String postOffice) {
		this.postOffice = postOffice;
	}

	public String getVill_city() {
		return vill_city;
	}

	public void setVill_city(String vill_city) {
		this.vill_city = vill_city;
	}

	public String getSubDistrict() {
		return subDistrict;
	}

	public void setSubDistrict(String subDistrict) {
		this.subDistrict = subDistrict;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getValidationType() {
		return validationType;
	}

	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	public String getApp_name() {
		return app_name;
	}

	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}

	@Override
	public String toString() {
		return "PanRequestV1 [fname=" + fname + ", mname=" + mname + ", lname=" + lname + ", dob=" + dob + ", gender="
				+ gender + ", email=" + email + ", careOf=" + careOf + ", houseNo=" + houseNo + ", street=" + street
				+ ", landmark=" + landmark + ", location=" + location + ", postOffice=" + postOffice + ", vill_city="
				+ vill_city + ", subDistrict=" + subDistrict + ", district=" + district + ", state=" + state
				+ ", stateCode=" + stateCode + ", postalCode=" + postalCode + ", mobileno=" + mobileno + ", pan=" + pan
				+ ", validationType=" + validationType + ", app_name=" + app_name + "]";
	}

}
