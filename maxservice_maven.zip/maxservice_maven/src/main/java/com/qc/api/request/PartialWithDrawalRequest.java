package com.qc.api.request;

import java.io.Serializable;

import com.qc.dto.DefaultRequestKeyDTO;

public class PartialWithDrawalRequest extends DefaultRequestKeyDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3821480741777615937L;
	String policyId;
	String startDate;
	String endDate;

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "PartialWithDrawalRequest [policyId=" + policyId + ", startDate=" + startDate + ", endDate=" + endDate
				+ "]";
	}

}
