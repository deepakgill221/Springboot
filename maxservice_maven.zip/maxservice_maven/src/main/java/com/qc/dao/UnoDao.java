package com.qc.dao;

import com.qc.api.request.PartialWithDrawalRequest;
import com.qc.api.request.TotalPremiumRequest;
import com.qc.api.response.PartialWithDrawalResponse;
import com.qc.api.response.TotalPremiumResponse;
import com.qc.entity.PerfiosEntity;

public interface UnoDao 
{
	//public PerfiosEntity getUnoData(PerfiosEntity perfiosEntity);
	
	//public PerfiosEntity getUnoData1(PerfiosEntity perfiosEntity);

	public PartialWithDrawalResponse getWithDrawalResponseDao(PartialWithDrawalRequest partialWithDrawalRequest);

	public TotalPremiumResponse getTotalPremiumDataDao(TotalPremiumRequest totalPremiumRequest);
}
