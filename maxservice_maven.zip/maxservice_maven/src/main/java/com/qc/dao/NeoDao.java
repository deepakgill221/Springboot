package com.qc.dao;

import java.sql.SQLException;
import java.util.List;

import com.qc.entity.PlanDetailBean;

public interface NeoDao 
{
	public List<PlanDetailBean> callPlanDetail(String planid,String rtbl_age_dur,String rtbl_sex)  throws SQLException,  Exception;
	
	public List<List<String>> callExistingCustomer(String query,String[] param);
	
	public boolean policyGenerationCheckTransIdExist(String transId);
	
	public List<String> callProceduresForUniquePolicy(String testPlanType,String storySolution,String transId);
	
	public String getIfscMicr(String ifscCode,String microCode) throws SQLException;
	
}
