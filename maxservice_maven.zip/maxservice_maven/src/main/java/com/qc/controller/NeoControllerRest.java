package com.qc.controller;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.service.NeoService;
import com.qc.utils.Commons;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/neo/api")
@Api(value="NEO", description="NEO service for maxlifeinsurance.com",tags = {"NEO"})
public class NeoControllerRest {
	private static Logger logger = LogManager.getLogger(NeoControllerRest.class);
	
	@Autowired NeoService neoService;
	
	@ApiOperation(notes = "This service will return DFS response for success and will return failure response for invalid request!!", value = "Get DFS with given request!", nickname = "")
	@RequestMapping(value = "/v1/DFSRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getDFSRequestData(@RequestBody String requestJSON) 
	{
		Map requestData = null;
		String returnOutput="";  
		try
		{
			ThreadContext.push("DFSRequest : "+System.currentTimeMillis());
			
			String methodName=Commons.getMethodName();  
			logger.info(">>>>>>>>>>>>>>>>>>>>>Came inside>>>>>>>>>>>>>>>>>>>>> "+methodName); 
			try
			{
				logger.info("Request Json : "+requestJSON);
				requestData=Commons.getGsonData(requestJSON);
				String TransTrackingID=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("TransTrackingID")).toString().toUpperCase();
				ThreadContext.push(TransTrackingID);
			} catch (Exception e) {
				logger.error("We are in Exception while converting request json to Map : "+e);
			}
			try
			{  
				returnOutput=neoService.processDFSRequest(requestData,requestJSON);
			}
			catch(Exception e)
			{
				returnOutput="{\"status\":\"FAIL\",\"message\":\"Error While Reponse\"}";
				logger.error("Error while generating response from Database inside "+methodName+"():-"+e);
			}
			logger.info("Response Json : "+returnOutput);
			logger.debug(">>>>>>>>>>>>>>>>>>>>>Going outside>>>>>>>>>>>>>>>>>>>>> "+methodName+"().");
		}
		catch(Exception ex)
		{
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;
	}
	
	@ApiOperation(notes = "This service will return Plan details response for success and will return failure response for invalid request!!", value = "Get Plan details with given request!", nickname = "")
	@RequestMapping(value = "/v1/PlanDetailsRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getPlanDetailsRequestData(@RequestBody String requestJSON) 
	{
		Map requestData = null;
		String returnOutput="";  
		try
		{
			ThreadContext.push("PlanDetailsRequest : "+System.currentTimeMillis());
			
			String methodName=Commons.getMethodName();  
			logger.info(">>>>>>>>>>>>>>>>>>>>>Came inside>>>>>>>>>>>>>>>>>>>>> "+methodName); 
			try
			{
				logger.info("Request Json : "+requestJSON);
				requestData=Commons.getGsonData(requestJSON);
				String TransTrackingID=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("TransTrackingID")).toString().toUpperCase();
				ThreadContext.push(TransTrackingID);
			} catch (Exception e) {
				logger.error("We are in Exception while converting request json to Map : "+e);
			}
			try
			{  
				returnOutput=neoService.processPlanDetailsRequest(requestData,requestJSON);
			}
			catch(Exception e)
			{
				returnOutput="{\"status\":\"FAIL\",\"message\":\"Error While Reponse\"}";
				logger.error("Error while generating response from Database inside "+methodName+"():-"+e);
			}
			logger.info("Response Json : "+returnOutput);
			logger.debug(">>>>>>>>>>>>>>>>>>>>>Going outside>>>>>>>>>>>>>>>>>>>>> "+methodName+"().");
		}
		catch(Exception ex)
		{
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;
	}
	
	
	@ApiOperation(notes = "This service will return existing customer response for success and will return failure response for invalid request!!", value = "Get existing customer with given request!", nickname = "")
	@RequestMapping(value = "/v1/ExistingCustomerRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getExistingCustomerRequestData(@RequestBody String requestJSON) 
	{
		Map requestData = null;
		String returnOutput="";  
		try
		{
			ThreadContext.push("ExistingCustomerRequest : "+System.currentTimeMillis());
			
			String methodName=Commons.getMethodName();  
			logger.info(">>>>>>>>>>>>>>>>>>>>>Came inside>>>>>>>>>>>>>>>>>>>>> "+methodName); 
			try
			{
				logger.info("Request Json : "+requestJSON);
				requestData=Commons.getGsonData(requestJSON);
				String TransTrackingID=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("TransTrackingID")).toString().toUpperCase();
				ThreadContext.push(TransTrackingID);
			} catch (Exception e) {
				logger.error("We are in Exception while converting request json to Map : "+e);
			}
			try
			{  
				returnOutput=neoService.processExistingCustomerRequest(requestData,requestJSON);
			}
			catch(Exception e)
			{
				returnOutput="{\"status\":\"FAIL\",\"message\":\"Error While Reponse\"}";
				logger.error("Error while generating response from Database inside "+methodName+"():-"+e);
			}
			logger.info("Response Json : "+returnOutput);
			logger.debug(">>>>>>>>>>>>>>>>>>>>>Going outside>>>>>>>>>>>>>>>>>>>>> "+methodName+"().");
		}
		catch(Exception ex)
		{
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;
	}
	
	
	@ApiOperation(notes = "This service will return unique policy or proposal no as response on request of plantype, storysolution and unique transaction id", value = "Get Policy or proposal no with given request!", nickname = "")
	@RequestMapping(value = "/v1/policygeneration", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getpolicyGenerationRequestData(@RequestBody String requestJSON) 
	{
		Map requestData = null;
		String returnOutput="";  
		try
		{
			ThreadContext.push("PolicyGeneration : "+System.currentTimeMillis());
			
			String methodName=Commons.getMethodName();  
			logger.info(">>>>>>>>>>>>>>>>>>>>>Came inside>>>>>>>>>>>>>>>>>>>>> "+methodName); 
			try
			{
				logger.info("Request Json : "+requestJSON);
				
				JSONObject jsonrequest=new JSONObject(requestJSON);
				JSONArray info = jsonrequest.getJSONArray("REQUEST");
				String transId= "";

				for(int ii=0; ii<info.length();ii++) 
				{
					JSONObject jsonOBject = info.getJSONObject(ii);
					transId = Commons.checkStringNullOrBlank(jsonOBject.getString("TRANSID"));
				}
				ThreadContext.push(transId);
			} catch (Exception e) {
				logger.error("We are in Exception while converting request json to Map : "+e);
			}
			try
			{  
				returnOutput=neoService.getPolicyService(requestJSON);
			}
			catch(Exception e)
			{
				returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"Error While Reponse\"}";
				logger.error("Error while generating response from Database inside "+methodName+"():-"+e);
			}
			logger.info("Response Json : "+returnOutput);
			logger.debug(">>>>>>>>>>>>>>>>>>>>>Going outside>>>>>>>>>>>>>>>>>>>>> "+methodName+"().");
		}
		catch(Exception ex)
		{
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;
	}
	
	@ApiOperation(notes = "This service will take input as IFSC and MICR code and provide details of bank", value = "Get Bank details with given request!", nickname = "")
	@RequestMapping(value = "/v1/inputifscmicr", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getIfscMicrData(@RequestBody String requestJSON) 
	{
		Map requestData = null;
		String returnOutput="";  
		try
		{
			ThreadContext.push("inputifscmicr : "+System.currentTimeMillis());
			
			String methodName=Commons.getMethodName();  
			logger.info(">>>>>>>>>>>>>>>>>>>>>Came inside>>>>>>>>>>>>>>>>>>>>> "+methodName); 
			try
			{
				logger.info("Request Json : "+requestJSON);
				
				JSONObject jsonrequest=new JSONObject(requestJSON);
				JSONObject info = jsonrequest.getJSONObject("REQUEST");
			    String ifscCode = info.getString("IFSCCODE");
			    String microCode = info.getString("MICROCODE");
			    
				ThreadContext.push(ifscCode+","+microCode);
			} catch (Exception e) {
				logger.error("We are in Exception while converting request json to Map : "+e);
			}
			try
			{  
				returnOutput=neoService.getIFSCService(requestJSON);
			}
			catch(Exception e)
			{
				returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"Error While Reponse\"}";
				logger.error("Error while generating response from Database inside "+methodName+"():-"+e);
			}
			logger.info("Response Json : "+returnOutput);
			logger.debug(">>>>>>>>>>>>>>>>>>>>>Going outside>>>>>>>>>>>>>>>>>>>>> "+methodName+"().");
		}
		catch(Exception ex)
		{
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;
	}
	
	
}
