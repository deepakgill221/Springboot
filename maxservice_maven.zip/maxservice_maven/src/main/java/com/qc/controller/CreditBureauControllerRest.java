package com.qc.controller;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.creditbureau.action.GetNeoPANRequestAction;
import com.qc.creditbureau.action.GetPANRequestAction;
import com.qc.utils.Commons;
import com.qc.utils.FlatFileMaker;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/panvalidation/api")
@Api(value="Credit Bureau", description="Credit Bureau service for maxlifeinsurance.com",tags = {"Credit Bureau"})
public class CreditBureauControllerRest 
{

	private static Logger logger = LogManager.getLogger(CreditBureauControllerRest.class);

//	@Autowired HttpSession session;
//	@Autowired ServletContext context;
	@Autowired Environment env;

	@ApiOperation(notes = "This service will return credit bureau v1 response for success. It contains PAN And DOB matched response and will return failure response for invalid request!!", value = "Get credit bureau v1 details with given request!", nickname = "")
	@ApiResponses(value = {
            @ApiResponse(code = 500, message = "Error in Request Json"),
            @ApiResponse(code = 200, message = " Success response") })
	@RequestMapping(value = "/v1/GetPANRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getCreditBureauRequestV1(@RequestBody String requestJSON) 
	{
		ThreadContext.push("CREDIT BUREAU 1.0 :: URL : /v1/GetPANRequest :: STARTS :: TRACKING ID :"+System.currentTimeMillis());
		logger.info("Method : getCreditBureauRequestV1 :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";    	
		try
		{
			GetPANRequestAction  panAction=new GetPANRequestAction();
			FlatFileMaker csv = new FlatFileMaker();
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"()."); 
			try
			{
				requestData=Commons.getGsonData(requestJSON); 
				try
				{     		
					returnOutput=panAction.processPANRequest(requestJSON,env);
				}
				catch(Exception e)
				{
					returnOutput="{\"status\":\"500\",\"message\":\"Error While Reponse\"}";
					logger.error("Error while generating response inside "+methodName+"():-"+e);
				}
			}
			catch(Exception e)
			{
				returnOutput="{\"STATUS\":\"500\",\"MESSAGE\":\"Error in Request Json\"}";
				logger.error("Error while parsing Request Json "+methodName+"():-"+e);
			}
			logger.debug("Going outside "+methodName+"().");

		}
		catch(Exception ex)
		{
			returnOutput="{\"STATUS\":\"500\",\"MESSAGE\":\"Error in Request Json\"}";
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
		}
		return returnOutput;	
	}

	@ApiOperation(notes = "This service will return credit bureau v2 response for success. It does PAN matching and returns credit score as well for the user. and will return failure response for invalid request!!", value = "Get credit bureau v2 details with given request!", nickname = "")
	@ApiResponses(value = {
	            @ApiResponse(code = 500, message = "Error While Response"),
	            @ApiResponse(code = 102, message = "Invalid Request Json"),
	            @ApiResponse(code = 101, message = " There is some error in calling webservice"),
	            @ApiResponse(code = 200, message = " Success response") })
	@RequestMapping(value = "/v2/GetNeoPANRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getCreditBureauRequestV2(@RequestBody String requestJSON) 
	{
		ThreadContext.push("GetNeoPANRequest : "+System.currentTimeMillis());
		logger.info("Method : getCreditBureauRequestV2 :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";    	
		try
		{
			GetNeoPANRequestAction  panAction=new GetNeoPANRequestAction();
			FlatFileMaker csv = new FlatFileMaker();
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"()."); 
			try
			{
				logger.info("Request Json : "+requestJSON);
				requestData=Commons.getGsonData(requestJSON);
				String TransTrackingID=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("TransTrackingID")).toString().toUpperCase();
				ThreadContext.push(TransTrackingID);
			} 
			catch (Exception e) 
			{
				logger.error("We are in Exception while converting request json to Map : "+e);
			}

			try
			{     		
				returnOutput=panAction.processNeoPANRequest(requestJSON,env,requestData);
			}
			catch(Exception e)
			{
				returnOutput="{\"status\":\"500\",\"statusDesc\":\"Failure\",\"message\":\"Error While Response\"}";
				logger.error("Error while generating response inside "+methodName+"():-"+e);
			}
			logger.debug("Going outside "+methodName+"().");
		}
		catch(Exception ex)
		{
			returnOutput="{\"status\":\"500\",\"statusDesc\":\"Failure\",\"message\":\"Error While Response : 1\"}";
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;

	}

}
