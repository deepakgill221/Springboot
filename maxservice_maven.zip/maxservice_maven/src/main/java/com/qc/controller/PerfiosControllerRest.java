package com.qc.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.entity.PerfiosEntity;
import com.qc.entity.PerfiosXMLEntity;
import com.qc.service.PerfiosService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/perfios/api/v1")
@Api(value="Perfios", description="Perfios service for maxlifeinsurance.com",tags = {"Perfios"})
public class PerfiosControllerRest 
{
	 private static Logger logger = LogManager.getLogger(PerfiosControllerRest.class);
	
	@Autowired PerfiosService perfiosService;
	
	@Autowired Environment env;
	
	@ApiOperation(notes = "This service will return perfios transaction response for success and will return failure response for invalid request!!", value = "Get perfios transaction with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/TxnStatusRequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosTransactionStatus(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("TxnStatusRequest");
		logger.info("PerfiosSprBootRest | perfiosTransactionStatus() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		try
		{
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setTxnStatusUrl(env.getProperty("perfios.transaction.status.url"));
			
			perfiosEntity = perfiosService.getTransactionStatus(perfiosEntity);
			
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
			
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}
		logger.info("PerfiosSprBootRest | perfiosTransactionStatus() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
	
	
	@ApiOperation(notes = "This service will return perfios transaction response for success and will return failure response for invalid request!!", value = "Get perfios transaction with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/RetrieveReportRequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosRetrieveReportRequest(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("RetrieveReportRequest");
		logger.info("PerfiosSprBootRest | perfiosRetrieveReportRequest() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		try
		{
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setRetriveUrl(env.getProperty("perfios.retrive.statement.url"));
			
			perfiosEntity = perfiosService.getRetrieveReport(perfiosEntity);
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
			
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
			String returnXml = "<response><status>Failure</status><statusCode>500</statusCode></response>";
			perfiosEntity.setResponseXML(returnXml);
		}
		logger.info("PerfiosSprBootRest | perfiosRetrieveReportRequest() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
	
	
	
	@ApiOperation(notes = "This service will return perfios transaction response for success and will return failure response for invalid request!!", value = "Get perfios transaction with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/TransactionReviewRequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosTransactionReview(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("TransactionReviewRequest");
		logger.info("PerfiosSprBootRest | perfiosTransactionReview() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		try
		{
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setTransactionReviewUrl(env.getProperty("perfios.review.url"));
			
			perfiosEntity = perfiosService.getTransactionReview(perfiosEntity);
			
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
			
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}
		logger.info("PerfiosSprBootRest | perfiosTransactionReview() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
	

	@ApiOperation(notes = "This service will return perfios transaction response for success and will return failure response for invalid request!!", value = "Get perfios transaction with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/SupportedInstitutionsRequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosSupportedInstitutions(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("SupportedInstitutionsRequest");
		logger.info("PerfiosSprBootRest | perfiosSupportedInstitutions() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		try
		{
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setSupportedInstUrl(env.getProperty("perfios.institutions.url"));
			
			perfiosEntity = perfiosService.getSupportedInstitutions(perfiosEntity);
			
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
			
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}
		logger.info("PerfiosSprBootRest | perfiosSupportedInstitutions() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
	
	@ApiOperation(notes = "This service will return perfios delete response for success and will return failure response for invalid request!!", value = "Get perfios delete data with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/DeleteDataRequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosDeleteData(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("DeleteDataRequest");
		logger.info("PerfiosSprBootRest | perfiosDeleteData() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		try
		{
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setDeleteDataUrl(env.getProperty("perfios.delete.data.url"));
			
			perfiosEntity = perfiosService.getDeleteData(perfiosEntity);
			
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
			
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}
		logger.info("PerfiosSprBootRest | perfiosDeleteData() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
}
