package com.qc.controller;

import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.aadhaar.action.GetBioRequestAction;
import com.qc.aadhaar.action.GetOTPRequestAction;
import com.qc.utils.Commons;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/aadhaar/api/v1")
@Api(value="Aadhaar", description="Aadhaar service for maxlifeinsurance.com",tags = {"Aadhaar"})
public class AadhaarControllerRest 
{
private static Logger logger = LogManager.getLogger(AadhaarControllerRest.class);
	
//	@Autowired HttpSession session;
//	@Autowired ServletContext context;
	@Autowired Environment env;
	
	@ApiOperation(notes = "This service will return aadhaar BIOMETRIC response for success and will return failure response for invalid request!!", value = "Get Aadhaar BioMetric with given request!", nickname = "")
	@RequestMapping(value = "/GetBioRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getAadhaarBIORequest(@RequestBody String requestJSON) 
	{
		ThreadContext.push("GetBioRequest : "+System.currentTimeMillis());
		logger.info("Method : getAadhaarRequest :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";  
		GetBioRequestAction  bioAction=new GetBioRequestAction();
		Response response=null;		
		int statusCode=500;
		try
		{
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"() inside AadhaarControllerRest."); 
			try
			{
				try
				{
					logger.info("Request Json : "+requestJSON);
					requestData=Commons.getGsonData(requestJSON);
					String TransTrackingID=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("transTrackingID").toString();
					ThreadContext.push(TransTrackingID);
				}
				catch(Exception ex)
				{
					logger.error("We are in Exception while converting request json to Map : "+ex);
				}
				try
				{     		
					returnOutput=bioAction.processBioRequest(requestJSON,env,requestData);
				}
				catch(Exception e)
				{
					returnOutput="{\"status\":\"0\",\"message\":\"Error While Reponse\"}";
					logger.error("Error while generating response inside "+methodName+"():-"+e);
				}
			}
			catch(Exception e)
			{
				returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"Error in Request Json\"}";
				logger.error("Error while parsing Request Json "+methodName+"():-"+e,new Throwable());
			}
			logger.debug("Going outside "+methodName+"().");

		}
		catch(Exception ex)
		{
			returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"Error in Request Json\"}";
			logger.error("we are in exception : "+ex,new Throwable());
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;	
	}
	
	
	@ApiOperation(notes = "This service will return aadhaar OTP response for success and will return failure response for invalid request!!", value = "Get Aadhaar OTP with given request!", nickname = "")
	@RequestMapping(value = "/GetOtpRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getAadhaarOTPRequest(@RequestBody String requestJSON) 
	{
		ThreadContext.push("GetOtpRequest : "+System.currentTimeMillis());
		logger.info("Method : getAadhaarRequest :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";  
		GetOTPRequestAction  otpAction=new GetOTPRequestAction();
		Response response=null;		
		//int statusCode=500;
		try
		{
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"() inside AadhaarControllerRest."); 
			try
			{
				try
				{
					logger.info("Request Json : "+requestJSON);
					requestData=Commons.getGsonData(requestJSON);
					String TransTrackingID=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("transTrackingID").toString();
					ThreadContext.push(TransTrackingID);
				}
				catch(Exception ex)
				{
					logger.error("We are in Exception while converting request json to Map : "+ex);
				}
				try
				{     		
					returnOutput=otpAction.processOTPRequest(requestJSON,env,requestData);
				}
				catch(Exception e)
				{
					returnOutput="{\"status\":\"0\",\"message\":\"Error While Reponse\"}";
					logger.error("Error while generating response inside "+methodName+"():-"+e);
				}
			}
			catch(Exception e)
			{
				returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"Error in Request Json\"}";
				logger.error("Error while parsing Request Json "+methodName+"():-"+e,new Throwable());
			}
			logger.debug("Going outside "+methodName+"().");

		}
		catch(Exception ex)
		{
			returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"Error in Request Json\"}";
			logger.error("we are in exception : "+ex,new Throwable());
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;	
	}

}



