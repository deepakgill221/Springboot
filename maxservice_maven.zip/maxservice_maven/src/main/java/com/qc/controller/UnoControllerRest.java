package com.qc.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.dto.ApiRequest;
import com.qc.dto.ApiResponse;
import com.qc.service.UnoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/uno/api/v1")
@Api(value="UNO", description="UNO service for maxlifeinsurance.com",tags = {"UNO"})
public class UnoControllerRest {
	//private static final Logger logger = LoggerFactory.getLogger(UnoControllerRest.class.getClass());
	private static Logger logger = LogManager.getLogger(UnoControllerRest.class);

	@Autowired UnoService unoService;

	@ApiOperation(notes = "This service will return partial withdrawal response for success and will return failure response for invalid request!!", value = "Get partial withdrawal details with given request!", nickname = "")
	@RequestMapping(value = "/partial-withdrawal", method = RequestMethod.POST , consumes= "application/json" , produces= "application/json" )
	public ApiResponse getPartialWithDrawalData(@Valid @RequestBody ApiRequest apiRequest) {
		logger.info("Method : getPartialWithDrawalData :: STARTS :: API_REQUEST :: "+apiRequest.toString());
		ApiResponse response =  null;

		try{
			response=unoService.getPartialWithDrawalDataService(apiRequest);
		}
		catch(Exception e){
			logger.info("error occured during calling getPartialWithDrawalDataService method"+e);
		}
		logger.info("Method : getPartialWithDrawalData :: ENDS :: API_RESPONSE :: "+response);
		return response;
	}


	@ApiOperation(notes = "This service will return total premium response as success and will return failure response for invalid request!!", value = "Get total premimum details with given request!", nickname = "")
	@RequestMapping(value = "/total-premium", method = RequestMethod.POST, consumes= "application/json" , produces= "application/json")
	public ApiResponse getTotalPremiumData(@Valid @RequestBody ApiRequest apiRequest ) {
		logger.info("Method : getTotalPremiumData :: STARTS :: API_REQUEST :: "+apiRequest.toString());
		ApiResponse response =  null;
		try{
			response=unoService.getTotalPremiumDataService(apiRequest);
		}
		catch(Exception e){
			logger.info("error occured during calling getTotalPremiumDataService method"+e);
		}
		logger.info("Method : getTotalPremiumData :: ENDS :: API_RESPONSE :: "+response);
		return response;
	}
	
}
