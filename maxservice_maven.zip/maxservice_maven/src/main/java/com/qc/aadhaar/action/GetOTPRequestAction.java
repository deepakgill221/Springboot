package com.qc.aadhaar.action;

import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.core.env.Environment;
import com.qc.controller.AadhaarControllerRest;
import com.qc.utils.Commons;
import com.qualtech.webservice.AadhaarVerificationotp.AadhaarVerificationServiceRequest;
import com.qualtech.webservice.AadhaarVerificationotp.AadhaarVerificationServiceResponse;
import com.qualtech.webservice.AadhaarVerificationotp.AadhaarVerificationWebServiceCallLocator;
import com.qualtech.webservice.AadhaarVerificationotp.AadhaarWebServiceSoapBindingStub;

public class GetOTPRequestAction 
{
	private static final Logger logger = LogManager.getLogger(AadhaarControllerRest.class);
	public String processOTPRequest(String requestJson,Environment env ,Map requestData)
	{
		String eKYCURL = env.getProperty("eKYCURLOTP");
		String methodName=null;
		String serviceName =null;
		String aadharNo="";
		String responseString="";
		String statcode="";
		String statmsg="";
		String token_pdf="";
		String UserName = null;
		String CreationDate = null;
		String CreationTime = null;
		String SourceInfoName = null;
		String RequestorToken = null;
		String UserEmail = null;
		String LastSyncDateTime = null;
		String _transTrackingID = null;
		Object outer1="";
		Object outer2="";
		Object getOTP="";

		StringBuilder otpResponse = new StringBuilder();
		methodName=Commons.getMethodName();
		logger.info("Came inside "+methodName+"().");
		Map<String, String> responseMap = null;
		AadhaarVerificationWebServiceCallLocator docLocator;
		AadhaarWebServiceSoapBindingStub myService;
		AadhaarVerificationServiceResponse response=null;

		try
		{
			outer1=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("aadhaarNumber");
			outer2=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("requestType");
			getOTP=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("otp");
			String aadharno= outer1.toString();
			String requesttype= outer2.toString();
			String OTP= getOTP.toString();
			_transTrackingID = ((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("transTrackingID").toString();
			UserName =  ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("UserName").toString();
			CreationDate = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("CreationDate").toString();
			CreationTime = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("CreationTime").toString();
			SourceInfoName = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("SourceInfoName").toString();
			RequestorToken = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("RequestorToken").toString();
			UserEmail = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("UserEmail").toString();
			LastSyncDateTime = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("LastSyncDateTime").toString();

			logger.info("  Request JSON:"+requestJson);
			if(requestData!=null && !requestData.isEmpty())
			{
				try{
					otpResponse.append(" 	{	 ");
					otpResponse.append(" 	\"Response\": {	 ");
					otpResponse.append(" 	\"ResponseInfo\": {	 ");
					otpResponse.append(" 	\"UserName\": \""+UserName+"\",	 ");
					otpResponse.append(" 	\"CreationDate\": \""+CreationDate+"\",	 ");
					otpResponse.append(" 	\"CreationTime\": \""+CreationTime+"\",	 ");
					otpResponse.append(" 	\"SourceInfoName\": \""+SourceInfoName+"\",	 ");
					otpResponse.append(" 	\"RequestorToken\": \""+RequestorToken+"\",	 ");
					otpResponse.append(" 	\"UserEmail\": \""+UserEmail+"\",	 ");
					otpResponse.append(" 	\"LastSyncDateTime\": \""+LastSyncDateTime+"\"	 ");
					otpResponse.append("},");
					otpResponse.append(" 	\"ResponsePayload\": {	 ");
					otpResponse.append(" 	\"Transactions\": [	 ");
					otpResponse.append(" 	{	 ");
					otpResponse.append(" 	\"key1\": \"\",	 ");
					otpResponse.append(" 	\"key2\": \"\",	 ");
					otpResponse.append(" 	\"key3\": \"\",	 ");
					otpResponse.append(" 	\"key4\": \"\",	 ");
					otpResponse.append(" 	\"key5\": \"\",	 ");
					otpResponse.append(" 	\"transTrackingID\": \"\",	 ");
					otpResponse.append(" 	\"transactionData\": {	 ");

					docLocator = new AadhaarVerificationWebServiceCallLocator();
					myService = new AadhaarWebServiceSoapBindingStub();	
					logger.info(" Creating verification object:---");
					myService = (AadhaarWebServiceSoapBindingStub)docLocator.getAadhaarVerificationWebService(new java.net.URL(eKYCURL));
					logger.info("Verification object created ---");

					if(requesttype.equals("O") && aadharno!=null && !aadharno.equals("") && aadharno.length()==12)
					{

						try{
							logger.info("Inside request type O & hit service for response ---");	
							response=myService.saveAadhaarVerificationInformation(					
									new AadhaarVerificationServiceRequest("O",aadharno,
											"QC","dypnU7milCCtWzrnBcXWgA==","00","123456",
											"","","","","","N","K",null,null,null,null,null,
											null,null,null,null,null,null,"","",null,null,null));
						}catch(Exception e)
						{
							e.printStackTrace();
							otpResponse.append("\"statusCode\":\"500\",");
							otpResponse.append("\"statusDesc\":\"Failure\",");
							otpResponse.append("\"message\":\"There is some error in calling webservice\",");
							otpResponse.append("\"status\":\"E\"");
							otpResponse.append("}}]}}}");
							return otpResponse.toString();
						}
						logger.info("Service Response fetched ---"+response.getOutputStatus()+" -- "+response.getOutputMessage());

						statcode=response.getOutputStatus();
						statmsg=response.getOutputMessage();
						if(statcode.equalsIgnoreCase("S"))
						{
							logger.info("Response Getting form UIDAI>>"+ statcode);
							otpResponse.append("\"statusCode\":\"200\",");
							otpResponse.append("\"statusDesc\":\"Success\",");
							otpResponse.append("\"message\":\"OTP Generated & sent! \",");
							otpResponse.append("\"status\":\"S\"");
						}
						if(!statcode.equals("S"))
						{
							logger.info("Response Getting form UIDAI>>"+ statcode);
							otpResponse.append("\"statusCode\":\"500\",");
							otpResponse.append("\"statusDesc\":\"Failure\",");
							otpResponse.append("\"message\":\""+statmsg+"\",");
							otpResponse.append("\"status\":\"E\"");	
						}
						otpResponse.append("}}]}}}");
					}
					else if(requesttype.equals("A")&& aadharno!=null && !aadharno.equals("") && aadharno.length()==12 && OTP!=null && OTP!="")
					{
						logger.info("Inside request type A & hit service for response ---");
						Object outer3=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("otp");
						String phoneOtp= outer3.toString();
						token_pdf=Commons.tokenGenerator();
						logger.info("Inside request type A & hit service for response ---");
						try{
							response=myService.saveAadhaarVerificationInformation(					
									new AadhaarVerificationServiceRequest("A",aadharno,
											"QC","dypnU7milCCtWzrnBcXWgA==","00",phoneOtp,
											"","","","","","N","K",null,null,null,null,null,
											null,null,null,null,null,null,"","",null,null,null));
						}
						catch(Exception e)
						{
							e.printStackTrace();
							otpResponse.append("\"statusCode\":\"500\",");
							otpResponse.append("\"statusDesc\":\"Failure\",");
							otpResponse.append("\"message\":\"There is some error in calling webservice\",");
							otpResponse.append("\"status\":\"E\"");
							otpResponse.append("}}]}}}");
							return otpResponse.toString();
						}

						logger.info("reportXML---for response Status >"+response.getOutputStatus());
						logger.info("reportXML---for response Message >"+response.getOutputMessage());
						logger.info("reportXML---for Adhaar Response >"+response.getOutputParam1());
						statcode=response.getOutputStatus();
						statmsg=response.getOutputMessage();

						JSONObject addressJson=new JSONObject(response.getCustomerAddress());
						if( statcode.equalsIgnoreCase("S"))
						{
							logger.info("Response Getting form UIDAI>>"+ statcode);
							otpResponse.append("\"statusCode\":\"200\",");
							otpResponse.append("\"statusDesc\":\"Success\",");
							otpResponse.append("\"message\":\"Response Successfully Generated\",");
							otpResponse.append("\"name\":\""+response.getCustomerName()+"\",");
							otpResponse.append("\"gender\":\""+response.getCustomerGender()+"\",");
							otpResponse.append("\"tokenNo\":\""+token_pdf+"\",");
							otpResponse.append("\"status\":\"S\""+",");
							otpResponse.append("\"aadharNo\":\""+aadharno+"\",");
							otpResponse.append("\"DOB\":\""+response.getCustomerDOB()+"\",");
							otpResponse.append("\"phone\":\""+response.getOutputParam1()+"\",");
							otpResponse.append("\"email\":\""+response.getOutputParam2()+"\",");
							otpResponse.append("\"CareOf\":\""+addressJson.getString("CAREOF")+"\",");
							otpResponse.append("\"House\":\""+addressJson.getString("HOUSE")+"\",");
							otpResponse.append("\"Street\":\""+addressJson.getString("STREET")+"\",");
							otpResponse.append("\"Landmark\":\""+addressJson.getString("LANDMARK")+"\",");
							otpResponse.append("\"Location\":\""+addressJson.getString("LOCATION")+"\",");
							otpResponse.append("\"Pin Code\":\""+addressJson.getString("PIN")+"\",");
							otpResponse.append("\"Post Office\":\""+addressJson.getString("POSTOFFICE")+"\",");
							otpResponse.append("\"Vill/City\":\""+addressJson.getString("VILL/CITY")+"\",");
							otpResponse.append("\"Sub-Dist\":\""+addressJson.getString("SUB-DIST")+"\",");
							otpResponse.append("\"Dist\":\""+addressJson.getString("DIST")+"\",");
							otpResponse.append("\"State\":\""+addressJson.getString("STATE")+"\",");
							otpResponse.append("\"image\":\""+response.getOutputParam3()+"\",");
							otpResponse.append("\"pdffile\":\""+addressJson.getString("PDFBYTE")+"\"");
						}
						else if(statcode.equalsIgnoreCase("-1"))
						{
							logger.info("Response Getting form UIDAI>>"+ statcode);
							otpResponse.append("\"statusCode\":\"500\",");
							otpResponse.append("\"statusDesc\":\"Failure\",");
							otpResponse.append("\"message\":\"User Authentication Failed!!\",");
							otpResponse.append("\"status\":\""+response.getOutputStatus()+"\"");
						}
						otpResponse.append("}}]}}}");
						//--------------------------Data Saved in DB----------------------------------------------------
						//					RequestLoggerDAO loggerdao= new RequestLoggerDAO();
						//					loggerdao.saveResponse(aadharno,otptype,statcode,statmsg,otpResponse.toString(),token_pdf);
					}
					//-------------------------This code written for PDF link and Download -----------------------------------------------------				
					//				else if(otptype.toString().equals("P"))
					//				{
					//					Object outer4=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("tokenId");
					//					String token_req= outer4.toString();
					//
					//					responseString="";  //tokenId
					//					String aadhar_no="";;
					//					//					   String token_req= requestData.get("tokenId").toString();
					//					logger.info("Tokenid Fetched from DB-:"+token_req);
					//					if(token_req != null  )
					//					{
					//						aadhar_no =  new RequestLoggerDAO().getResponse(token_req);
					//						System.out.println("-----"+resourceBundle1.containsKey("com.qualtech.resource.dbConfig.urlpdf"));
					//						String urllink=resourceBundle1.getString("com.qualtech.resource.dbConfig.urlpdf");
					//
					//						if(aadhar_no!=null && (aadhar_no.length()==12))
					//						{
					//							otpResponse.append("\"statusCode\":\"200\",");
					//							otpResponse.append("\"statusDesc\":\"Success\",");
					//							otpResponse.append("\"message\":\"Response Successfully Generated\",");
					//							otpResponse.append("\"status\":\"S\",");	
					//							otpResponse.append("\"pdfName\":\""+aadhar_no+".PDF\",");
					//							otpResponse.append("\"pdfLink\":\"http://"+urllink+"/AadhaarOtpAuth_Dyn/DownloadServlet?filename="+aadhar_no+".PDF\" ");
					//							logger.info("Pdf Download Link-:"+responseString);
					//						}
					//						else
					//						{  
					//							otpResponse.append("\"statusCode\":\"500\",");
					//							otpResponse.append("\"statusDesc\":\"Failure\",");
					//							otpResponse.append("\"message\":\"Invalid Input token!!\",");
					//							otpResponse.append("\"status\":\"E\" ");
					//							logger.info("Error in P type-:"+responseString);
					//						}
					//						otpResponse.append("}}]}}}");
					//					}
					//				}
					else
					{  
						otpResponse.append("\"statusCode\":\"500\",");
						otpResponse.append("\"statusDesc\":\"Failure\",");
						otpResponse.append("\"message\":\"Invalid AadhaarNo! OR RequestType!\",");
						otpResponse.append("\"status\":\"E\" ");
						otpResponse.append("}}]}}}");
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
					otpResponse.append("\"statusCode\":\"500\",");
					otpResponse.append("\"statusDesc\":\"Failure\",");
					otpResponse.append("\"message\":\"There is some error in calling webservice\",");
					otpResponse.append("\"status\":\"E\"");
					otpResponse.append("}}]}}}");
					logger.error("Exception Description--"+e.getMessage());
					logger.error(e);
					return otpResponse.toString();
				}
			}
			else
			{  
				otpResponse.append("{");
				otpResponse.append("\"statusCode\":\"500\",");
				otpResponse.append("\"statusDesc\":\"Failure\",");
				otpResponse.append("\"message\":\"Invalid JSON RequestData!\",");
				otpResponse.append("\"status\":\"E\" ");
				otpResponse.append("}");
				return otpResponse.toString();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			otpResponse.append("{");
			otpResponse.append("\"statusCode\":\"500\",");
			otpResponse.append("\"statusDesc\":\"Failure\",");
			otpResponse.append("\"message\":\"There is some error in calling webservice\",");
			otpResponse.append("\"status\":\"E\"");
			otpResponse.append("}");
			logger.error("Exception Description--"+e.getMessage());
			logger.error(e);
		}
		return otpResponse.toString();
	}
}
