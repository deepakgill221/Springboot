/**
 * AadhaarVerificationServiceResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.qualtech.webservice.AadhaarVerificationotp;

public class AadhaarVerificationServiceResponse  implements java.io.Serializable {
    private java.lang.String outputStatus;

    private java.lang.String outputMessage;

    private java.lang.String customerName;

    private java.lang.String customerDOB;

    private java.lang.String customerGender;

    private java.lang.String customerAddress;

    private byte[] kycData;

    private byte[] pdfDoc;

    private byte[] outputDoc;

    private java.lang.String outputParam1;

    private java.lang.String outputParam2;

    private java.lang.String outputParam3;

    private java.lang.String outputParam4;

    private java.lang.String outputParam5;

    private java.lang.String leftThumb;

    private java.lang.String leftForeFinger;

    private java.lang.String leftMiddleFinger;

    private java.lang.String leftRingFinger;

    private java.lang.String leftLittleFinger;

    private java.lang.String rightThumb;

    private java.lang.String rightForeFinger;

    private java.lang.String rightMiddleFinger;

    private java.lang.String rightRingFinger;

    private java.lang.String rightLittleFinger;

    public AadhaarVerificationServiceResponse() {
    }

    public AadhaarVerificationServiceResponse(
           java.lang.String outputStatus,
           java.lang.String outputMessage,
           java.lang.String customerName,
           java.lang.String customerDOB,
           java.lang.String customerGender,
           java.lang.String customerAddress,
           byte[] kycData,
           byte[] pdfDoc,
           byte[] outputDoc,
           java.lang.String outputParam1,
           java.lang.String outputParam2,
           java.lang.String outputParam3,
           java.lang.String outputParam4,
           java.lang.String outputParam5,
           java.lang.String leftThumb,
           java.lang.String leftForeFinger,
           java.lang.String leftMiddleFinger,
           java.lang.String leftRingFinger,
           java.lang.String leftLittleFinger,
           java.lang.String rightThumb,
           java.lang.String rightForeFinger,
           java.lang.String rightMiddleFinger,
           java.lang.String rightRingFinger,
           java.lang.String rightLittleFinger) {
           this.outputStatus = outputStatus;
           this.outputMessage = outputMessage;
           this.customerName = customerName;
           this.customerDOB = customerDOB;
           this.customerGender = customerGender;
           this.customerAddress = customerAddress;
           this.kycData = kycData;
           this.pdfDoc = pdfDoc;
           this.outputDoc = outputDoc;
           this.outputParam1 = outputParam1;
           this.outputParam2 = outputParam2;
           this.outputParam3 = outputParam3;
           this.outputParam4 = outputParam4;
           this.outputParam5 = outputParam5;
           this.leftThumb = leftThumb;
           this.leftForeFinger = leftForeFinger;
           this.leftMiddleFinger = leftMiddleFinger;
           this.leftRingFinger = leftRingFinger;
           this.leftLittleFinger = leftLittleFinger;
           this.rightThumb = rightThumb;
           this.rightForeFinger = rightForeFinger;
           this.rightMiddleFinger = rightMiddleFinger;
           this.rightRingFinger = rightRingFinger;
           this.rightLittleFinger = rightLittleFinger;
    }


    /**
     * Gets the outputStatus value for this AadhaarVerificationServiceResponse.
     * 
     * @return outputStatus
     */
    public java.lang.String getOutputStatus() {
        return outputStatus;
    }


    /**
     * Sets the outputStatus value for this AadhaarVerificationServiceResponse.
     * 
     * @param outputStatus
     */
    public void setOutputStatus(java.lang.String outputStatus) {
        this.outputStatus = outputStatus;
    }


    /**
     * Gets the outputMessage value for this AadhaarVerificationServiceResponse.
     * 
     * @return outputMessage
     */
    public java.lang.String getOutputMessage() {
        return outputMessage;
    }


    /**
     * Sets the outputMessage value for this AadhaarVerificationServiceResponse.
     * 
     * @param outputMessage
     */
    public void setOutputMessage(java.lang.String outputMessage) {
        this.outputMessage = outputMessage;
    }


    /**
     * Gets the customerName value for this AadhaarVerificationServiceResponse.
     * 
     * @return customerName
     */
    public java.lang.String getCustomerName() {
        return customerName;
    }


    /**
     * Sets the customerName value for this AadhaarVerificationServiceResponse.
     * 
     * @param customerName
     */
    public void setCustomerName(java.lang.String customerName) {
        this.customerName = customerName;
    }


    /**
     * Gets the customerDOB value for this AadhaarVerificationServiceResponse.
     * 
     * @return customerDOB
     */
    public java.lang.String getCustomerDOB() {
        return customerDOB;
    }


    /**
     * Sets the customerDOB value for this AadhaarVerificationServiceResponse.
     * 
     * @param customerDOB
     */
    public void setCustomerDOB(java.lang.String customerDOB) {
        this.customerDOB = customerDOB;
    }


    /**
     * Gets the customerGender value for this AadhaarVerificationServiceResponse.
     * 
     * @return customerGender
     */
    public java.lang.String getCustomerGender() {
        return customerGender;
    }


    /**
     * Sets the customerGender value for this AadhaarVerificationServiceResponse.
     * 
     * @param customerGender
     */
    public void setCustomerGender(java.lang.String customerGender) {
        this.customerGender = customerGender;
    }


    /**
     * Gets the customerAddress value for this AadhaarVerificationServiceResponse.
     * 
     * @return customerAddress
     */
    public java.lang.String getCustomerAddress() {
        return customerAddress;
    }


    /**
     * Sets the customerAddress value for this AadhaarVerificationServiceResponse.
     * 
     * @param customerAddress
     */
    public void setCustomerAddress(java.lang.String customerAddress) {
        this.customerAddress = customerAddress;
    }


    /**
     * Gets the kycData value for this AadhaarVerificationServiceResponse.
     * 
     * @return kycData
     */
    public byte[] getKycData() {
        return kycData;
    }


    /**
     * Sets the kycData value for this AadhaarVerificationServiceResponse.
     * 
     * @param kycData
     */
    public void setKycData(byte[] kycData) {
        this.kycData = kycData;
    }


    /**
     * Gets the pdfDoc value for this AadhaarVerificationServiceResponse.
     * 
     * @return pdfDoc
     */
    public byte[] getPdfDoc() {
        return pdfDoc;
    }


    /**
     * Sets the pdfDoc value for this AadhaarVerificationServiceResponse.
     * 
     * @param pdfDoc
     */
    public void setPdfDoc(byte[] pdfDoc) {
        this.pdfDoc = pdfDoc;
    }


    /**
     * Gets the outputDoc value for this AadhaarVerificationServiceResponse.
     * 
     * @return outputDoc
     */
    public byte[] getOutputDoc() {
        return outputDoc;
    }


    /**
     * Sets the outputDoc value for this AadhaarVerificationServiceResponse.
     * 
     * @param outputDoc
     */
    public void setOutputDoc(byte[] outputDoc) {
        this.outputDoc = outputDoc;
    }


    /**
     * Gets the outputParam1 value for this AadhaarVerificationServiceResponse.
     * 
     * @return outputParam1
     */
    public java.lang.String getOutputParam1() {
        return outputParam1;
    }


    /**
     * Sets the outputParam1 value for this AadhaarVerificationServiceResponse.
     * 
     * @param outputParam1
     */
    public void setOutputParam1(java.lang.String outputParam1) {
        this.outputParam1 = outputParam1;
    }


    /**
     * Gets the outputParam2 value for this AadhaarVerificationServiceResponse.
     * 
     * @return outputParam2
     */
    public java.lang.String getOutputParam2() {
        return outputParam2;
    }


    /**
     * Sets the outputParam2 value for this AadhaarVerificationServiceResponse.
     * 
     * @param outputParam2
     */
    public void setOutputParam2(java.lang.String outputParam2) {
        this.outputParam2 = outputParam2;
    }


    /**
     * Gets the outputParam3 value for this AadhaarVerificationServiceResponse.
     * 
     * @return outputParam3
     */
    public java.lang.String getOutputParam3() {
        return outputParam3;
    }


    /**
     * Sets the outputParam3 value for this AadhaarVerificationServiceResponse.
     * 
     * @param outputParam3
     */
    public void setOutputParam3(java.lang.String outputParam3) {
        this.outputParam3 = outputParam3;
    }


    /**
     * Gets the outputParam4 value for this AadhaarVerificationServiceResponse.
     * 
     * @return outputParam4
     */
    public java.lang.String getOutputParam4() {
        return outputParam4;
    }


    /**
     * Sets the outputParam4 value for this AadhaarVerificationServiceResponse.
     * 
     * @param outputParam4
     */
    public void setOutputParam4(java.lang.String outputParam4) {
        this.outputParam4 = outputParam4;
    }


    /**
     * Gets the outputParam5 value for this AadhaarVerificationServiceResponse.
     * 
     * @return outputParam5
     */
    public java.lang.String getOutputParam5() {
        return outputParam5;
    }


    /**
     * Sets the outputParam5 value for this AadhaarVerificationServiceResponse.
     * 
     * @param outputParam5
     */
    public void setOutputParam5(java.lang.String outputParam5) {
        this.outputParam5 = outputParam5;
    }


    /**
     * Gets the leftThumb value for this AadhaarVerificationServiceResponse.
     * 
     * @return leftThumb
     */
    public java.lang.String getLeftThumb() {
        return leftThumb;
    }


    /**
     * Sets the leftThumb value for this AadhaarVerificationServiceResponse.
     * 
     * @param leftThumb
     */
    public void setLeftThumb(java.lang.String leftThumb) {
        this.leftThumb = leftThumb;
    }


    /**
     * Gets the leftForeFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @return leftForeFinger
     */
    public java.lang.String getLeftForeFinger() {
        return leftForeFinger;
    }


    /**
     * Sets the leftForeFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @param leftForeFinger
     */
    public void setLeftForeFinger(java.lang.String leftForeFinger) {
        this.leftForeFinger = leftForeFinger;
    }


    /**
     * Gets the leftMiddleFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @return leftMiddleFinger
     */
    public java.lang.String getLeftMiddleFinger() {
        return leftMiddleFinger;
    }


    /**
     * Sets the leftMiddleFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @param leftMiddleFinger
     */
    public void setLeftMiddleFinger(java.lang.String leftMiddleFinger) {
        this.leftMiddleFinger = leftMiddleFinger;
    }


    /**
     * Gets the leftRingFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @return leftRingFinger
     */
    public java.lang.String getLeftRingFinger() {
        return leftRingFinger;
    }


    /**
     * Sets the leftRingFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @param leftRingFinger
     */
    public void setLeftRingFinger(java.lang.String leftRingFinger) {
        this.leftRingFinger = leftRingFinger;
    }


    /**
     * Gets the leftLittleFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @return leftLittleFinger
     */
    public java.lang.String getLeftLittleFinger() {
        return leftLittleFinger;
    }


    /**
     * Sets the leftLittleFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @param leftLittleFinger
     */
    public void setLeftLittleFinger(java.lang.String leftLittleFinger) {
        this.leftLittleFinger = leftLittleFinger;
    }


    /**
     * Gets the rightThumb value for this AadhaarVerificationServiceResponse.
     * 
     * @return rightThumb
     */
    public java.lang.String getRightThumb() {
        return rightThumb;
    }


    /**
     * Sets the rightThumb value for this AadhaarVerificationServiceResponse.
     * 
     * @param rightThumb
     */
    public void setRightThumb(java.lang.String rightThumb) {
        this.rightThumb = rightThumb;
    }


    /**
     * Gets the rightForeFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @return rightForeFinger
     */
    public java.lang.String getRightForeFinger() {
        return rightForeFinger;
    }


    /**
     * Sets the rightForeFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @param rightForeFinger
     */
    public void setRightForeFinger(java.lang.String rightForeFinger) {
        this.rightForeFinger = rightForeFinger;
    }


    /**
     * Gets the rightMiddleFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @return rightMiddleFinger
     */
    public java.lang.String getRightMiddleFinger() {
        return rightMiddleFinger;
    }


    /**
     * Sets the rightMiddleFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @param rightMiddleFinger
     */
    public void setRightMiddleFinger(java.lang.String rightMiddleFinger) {
        this.rightMiddleFinger = rightMiddleFinger;
    }


    /**
     * Gets the rightRingFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @return rightRingFinger
     */
    public java.lang.String getRightRingFinger() {
        return rightRingFinger;
    }


    /**
     * Sets the rightRingFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @param rightRingFinger
     */
    public void setRightRingFinger(java.lang.String rightRingFinger) {
        this.rightRingFinger = rightRingFinger;
    }


    /**
     * Gets the rightLittleFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @return rightLittleFinger
     */
    public java.lang.String getRightLittleFinger() {
        return rightLittleFinger;
    }


    /**
     * Sets the rightLittleFinger value for this AadhaarVerificationServiceResponse.
     * 
     * @param rightLittleFinger
     */
    public void setRightLittleFinger(java.lang.String rightLittleFinger) {
        this.rightLittleFinger = rightLittleFinger;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AadhaarVerificationServiceResponse)) return false;
        AadhaarVerificationServiceResponse other = (AadhaarVerificationServiceResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.outputStatus==null && other.getOutputStatus()==null) || 
             (this.outputStatus!=null &&
              this.outputStatus.equals(other.getOutputStatus()))) &&
            ((this.outputMessage==null && other.getOutputMessage()==null) || 
             (this.outputMessage!=null &&
              this.outputMessage.equals(other.getOutputMessage()))) &&
            ((this.customerName==null && other.getCustomerName()==null) || 
             (this.customerName!=null &&
              this.customerName.equals(other.getCustomerName()))) &&
            ((this.customerDOB==null && other.getCustomerDOB()==null) || 
             (this.customerDOB!=null &&
              this.customerDOB.equals(other.getCustomerDOB()))) &&
            ((this.customerGender==null && other.getCustomerGender()==null) || 
             (this.customerGender!=null &&
              this.customerGender.equals(other.getCustomerGender()))) &&
            ((this.customerAddress==null && other.getCustomerAddress()==null) || 
             (this.customerAddress!=null &&
              this.customerAddress.equals(other.getCustomerAddress()))) &&
            ((this.kycData==null && other.getKycData()==null) || 
             (this.kycData!=null &&
              java.util.Arrays.equals(this.kycData, other.getKycData()))) &&
            ((this.pdfDoc==null && other.getPdfDoc()==null) || 
             (this.pdfDoc!=null &&
              java.util.Arrays.equals(this.pdfDoc, other.getPdfDoc()))) &&
            ((this.outputDoc==null && other.getOutputDoc()==null) || 
             (this.outputDoc!=null &&
              java.util.Arrays.equals(this.outputDoc, other.getOutputDoc()))) &&
            ((this.outputParam1==null && other.getOutputParam1()==null) || 
             (this.outputParam1!=null &&
              this.outputParam1.equals(other.getOutputParam1()))) &&
            ((this.outputParam2==null && other.getOutputParam2()==null) || 
             (this.outputParam2!=null &&
              this.outputParam2.equals(other.getOutputParam2()))) &&
            ((this.outputParam3==null && other.getOutputParam3()==null) || 
             (this.outputParam3!=null &&
              this.outputParam3.equals(other.getOutputParam3()))) &&
            ((this.outputParam4==null && other.getOutputParam4()==null) || 
             (this.outputParam4!=null &&
              this.outputParam4.equals(other.getOutputParam4()))) &&
            ((this.outputParam5==null && other.getOutputParam5()==null) || 
             (this.outputParam5!=null &&
              this.outputParam5.equals(other.getOutputParam5()))) &&
            ((this.leftThumb==null && other.getLeftThumb()==null) || 
             (this.leftThumb!=null &&
              this.leftThumb.equals(other.getLeftThumb()))) &&
            ((this.leftForeFinger==null && other.getLeftForeFinger()==null) || 
             (this.leftForeFinger!=null &&
              this.leftForeFinger.equals(other.getLeftForeFinger()))) &&
            ((this.leftMiddleFinger==null && other.getLeftMiddleFinger()==null) || 
             (this.leftMiddleFinger!=null &&
              this.leftMiddleFinger.equals(other.getLeftMiddleFinger()))) &&
            ((this.leftRingFinger==null && other.getLeftRingFinger()==null) || 
             (this.leftRingFinger!=null &&
              this.leftRingFinger.equals(other.getLeftRingFinger()))) &&
            ((this.leftLittleFinger==null && other.getLeftLittleFinger()==null) || 
             (this.leftLittleFinger!=null &&
              this.leftLittleFinger.equals(other.getLeftLittleFinger()))) &&
            ((this.rightThumb==null && other.getRightThumb()==null) || 
             (this.rightThumb!=null &&
              this.rightThumb.equals(other.getRightThumb()))) &&
            ((this.rightForeFinger==null && other.getRightForeFinger()==null) || 
             (this.rightForeFinger!=null &&
              this.rightForeFinger.equals(other.getRightForeFinger()))) &&
            ((this.rightMiddleFinger==null && other.getRightMiddleFinger()==null) || 
             (this.rightMiddleFinger!=null &&
              this.rightMiddleFinger.equals(other.getRightMiddleFinger()))) &&
            ((this.rightRingFinger==null && other.getRightRingFinger()==null) || 
             (this.rightRingFinger!=null &&
              this.rightRingFinger.equals(other.getRightRingFinger()))) &&
            ((this.rightLittleFinger==null && other.getRightLittleFinger()==null) || 
             (this.rightLittleFinger!=null &&
              this.rightLittleFinger.equals(other.getRightLittleFinger())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOutputStatus() != null) {
            _hashCode += getOutputStatus().hashCode();
        }
        if (getOutputMessage() != null) {
            _hashCode += getOutputMessage().hashCode();
        }
        if (getCustomerName() != null) {
            _hashCode += getCustomerName().hashCode();
        }
        if (getCustomerDOB() != null) {
            _hashCode += getCustomerDOB().hashCode();
        }
        if (getCustomerGender() != null) {
            _hashCode += getCustomerGender().hashCode();
        }
        if (getCustomerAddress() != null) {
            _hashCode += getCustomerAddress().hashCode();
        }
        if (getKycData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getKycData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getKycData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPdfDoc() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPdfDoc());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPdfDoc(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOutputDoc() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOutputDoc());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOutputDoc(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOutputParam1() != null) {
            _hashCode += getOutputParam1().hashCode();
        }
        if (getOutputParam2() != null) {
            _hashCode += getOutputParam2().hashCode();
        }
        if (getOutputParam3() != null) {
            _hashCode += getOutputParam3().hashCode();
        }
        if (getOutputParam4() != null) {
            _hashCode += getOutputParam4().hashCode();
        }
        if (getOutputParam5() != null) {
            _hashCode += getOutputParam5().hashCode();
        }
        if (getLeftThumb() != null) {
            _hashCode += getLeftThumb().hashCode();
        }
        if (getLeftForeFinger() != null) {
            _hashCode += getLeftForeFinger().hashCode();
        }
        if (getLeftMiddleFinger() != null) {
            _hashCode += getLeftMiddleFinger().hashCode();
        }
        if (getLeftRingFinger() != null) {
            _hashCode += getLeftRingFinger().hashCode();
        }
        if (getLeftLittleFinger() != null) {
            _hashCode += getLeftLittleFinger().hashCode();
        }
        if (getRightThumb() != null) {
            _hashCode += getRightThumb().hashCode();
        }
        if (getRightForeFinger() != null) {
            _hashCode += getRightForeFinger().hashCode();
        }
        if (getRightMiddleFinger() != null) {
            _hashCode += getRightMiddleFinger().hashCode();
        }
        if (getRightRingFinger() != null) {
            _hashCode += getRightRingFinger().hashCode();
        }
        if (getRightLittleFinger() != null) {
            _hashCode += getRightLittleFinger().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AadhaarVerificationServiceResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", ">AadhaarVerificationServiceResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "outputStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputMessage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "outputMessage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "customerName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerDOB");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "customerDOB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerGender");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "customerGender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "customerAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kycData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "kycData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pdfDoc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "pdfDoc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputDoc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "outputDoc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputParam1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "outputParam1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputParam2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "outputParam2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputParam3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "outputParam3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputParam4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "outputParam4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputParam5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "outputParam5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftThumb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftThumb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftForeFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftForeFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftMiddleFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftMiddleFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftRingFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftRingFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftLittleFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftLittleFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightThumb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightThumb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightForeFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightForeFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightMiddleFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightMiddleFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightRingFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightRingFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightLittleFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightLittleFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
