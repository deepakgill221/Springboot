package com.qualtech.webservice.AadhaarVerification;

public class AadhaarVerificationWebServiceProxy implements com.qualtech.webservice.AadhaarVerification.AadhaarVerificationWebService {
  private String _endpoint = null;
  private com.qualtech.webservice.AadhaarVerification.AadhaarVerificationWebService aadhaarVerificationWebService = null;
  
  public AadhaarVerificationWebServiceProxy() {
    _initAadhaarVerificationWebServiceProxy();
  }
  
  public AadhaarVerificationWebServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initAadhaarVerificationWebServiceProxy();
  }
  
  private void _initAadhaarVerificationWebServiceProxy() {
    try {
      aadhaarVerificationWebService = (new com.qualtech.webservice.AadhaarVerification.AadhaarVerificationWebServiceCallLocator()).getAadhaarVerificationWebService();
      if (aadhaarVerificationWebService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)aadhaarVerificationWebService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)aadhaarVerificationWebService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (aadhaarVerificationWebService != null)
      ((javax.xml.rpc.Stub)aadhaarVerificationWebService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.qualtech.webservice.AadhaarVerification.AadhaarVerificationWebService getAadhaarVerificationWebService() {
    if (aadhaarVerificationWebService == null)
      _initAadhaarVerificationWebServiceProxy();
    return aadhaarVerificationWebService;
  }
  
  public com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceResponse saveAadhaarVerificationInformation(com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceRequest aadhaarVerificationServiceRequest) throws java.rmi.RemoteException{
    if (aadhaarVerificationWebService == null)
      _initAadhaarVerificationWebServiceProxy();
    return aadhaarVerificationWebService.saveAadhaarVerificationInformation(aadhaarVerificationServiceRequest);
  }
  
  
}