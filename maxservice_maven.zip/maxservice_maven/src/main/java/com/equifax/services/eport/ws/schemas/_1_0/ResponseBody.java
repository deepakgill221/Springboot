/**
 * ResponseBody.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class ResponseBody  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.VidNsdlResponse[] vidNsdlResponses;

    private com.equifax.services.eport.ws.schemas._1_0.VidUidaiResponse[] vidUidaiResponses;

    private com.equifax.services.eport.ws.schemas._1_0.VidVoterResponse[] vidVoterResponses;

    public ResponseBody() {
    }

    public ResponseBody(
           com.equifax.services.eport.ws.schemas._1_0.VidNsdlResponse[] vidNsdlResponses,
           com.equifax.services.eport.ws.schemas._1_0.VidUidaiResponse[] vidUidaiResponses,
           com.equifax.services.eport.ws.schemas._1_0.VidVoterResponse[] vidVoterResponses) {
           this.vidNsdlResponses = vidNsdlResponses;
           this.vidUidaiResponses = vidUidaiResponses;
           this.vidVoterResponses = vidVoterResponses;
    }


    /**
     * Gets the vidNsdlResponses value for this ResponseBody.
     * 
     * @return vidNsdlResponses
     */
    public com.equifax.services.eport.ws.schemas._1_0.VidNsdlResponse[] getVidNsdlResponses() {
        return vidNsdlResponses;
    }


    /**
     * Sets the vidNsdlResponses value for this ResponseBody.
     * 
     * @param vidNsdlResponses
     */
    public void setVidNsdlResponses(com.equifax.services.eport.ws.schemas._1_0.VidNsdlResponse[] vidNsdlResponses) {
        this.vidNsdlResponses = vidNsdlResponses;
    }

    public com.equifax.services.eport.ws.schemas._1_0.VidNsdlResponse getVidNsdlResponses(int i) {
        return this.vidNsdlResponses[i];
    }

    public void setVidNsdlResponses(int i, com.equifax.services.eport.ws.schemas._1_0.VidNsdlResponse _value) {
        this.vidNsdlResponses[i] = _value;
    }


    /**
     * Gets the vidUidaiResponses value for this ResponseBody.
     * 
     * @return vidUidaiResponses
     */
    public com.equifax.services.eport.ws.schemas._1_0.VidUidaiResponse[] getVidUidaiResponses() {
        return vidUidaiResponses;
    }


    /**
     * Sets the vidUidaiResponses value for this ResponseBody.
     * 
     * @param vidUidaiResponses
     */
    public void setVidUidaiResponses(com.equifax.services.eport.ws.schemas._1_0.VidUidaiResponse[] vidUidaiResponses) {
        this.vidUidaiResponses = vidUidaiResponses;
    }

    public com.equifax.services.eport.ws.schemas._1_0.VidUidaiResponse getVidUidaiResponses(int i) {
        return this.vidUidaiResponses[i];
    }

    public void setVidUidaiResponses(int i, com.equifax.services.eport.ws.schemas._1_0.VidUidaiResponse _value) {
        this.vidUidaiResponses[i] = _value;
    }


    /**
     * Gets the vidVoterResponses value for this ResponseBody.
     * 
     * @return vidVoterResponses
     */
    public com.equifax.services.eport.ws.schemas._1_0.VidVoterResponse[] getVidVoterResponses() {
        return vidVoterResponses;
    }


    /**
     * Sets the vidVoterResponses value for this ResponseBody.
     * 
     * @param vidVoterResponses
     */
    public void setVidVoterResponses(com.equifax.services.eport.ws.schemas._1_0.VidVoterResponse[] vidVoterResponses) {
        this.vidVoterResponses = vidVoterResponses;
    }

    public com.equifax.services.eport.ws.schemas._1_0.VidVoterResponse getVidVoterResponses(int i) {
        return this.vidVoterResponses[i];
    }

    public void setVidVoterResponses(int i, com.equifax.services.eport.ws.schemas._1_0.VidVoterResponse _value) {
        this.vidVoterResponses[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResponseBody)) return false;
        ResponseBody other = (ResponseBody) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.vidNsdlResponses==null && other.getVidNsdlResponses()==null) || 
             (this.vidNsdlResponses!=null &&
              java.util.Arrays.equals(this.vidNsdlResponses, other.getVidNsdlResponses()))) &&
            ((this.vidUidaiResponses==null && other.getVidUidaiResponses()==null) || 
             (this.vidUidaiResponses!=null &&
              java.util.Arrays.equals(this.vidUidaiResponses, other.getVidUidaiResponses()))) &&
            ((this.vidVoterResponses==null && other.getVidVoterResponses()==null) || 
             (this.vidVoterResponses!=null &&
              java.util.Arrays.equals(this.vidVoterResponses, other.getVidVoterResponses())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getVidNsdlResponses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getVidNsdlResponses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getVidNsdlResponses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getVidUidaiResponses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getVidUidaiResponses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getVidUidaiResponses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getVidVoterResponses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getVidVoterResponses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getVidVoterResponses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResponseBody.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "responseBody"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vidNsdlResponses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidNsdlResponses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidNsdlResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vidUidaiResponses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidUidaiResponses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidUidaiResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vidVoterResponses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidVoterResponses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidVoterResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
