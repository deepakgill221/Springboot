/**
 * AccountInputType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class AccountInputType  implements java.io.Serializable {
    private java.lang.String accountNumber;

    private java.lang.String branchIDMFI;

    private java.lang.String kendraIDMFI;

    private int seq;  // attribute

    public AccountInputType() {
    }

    public AccountInputType(
           java.lang.String accountNumber,
           java.lang.String branchIDMFI,
           java.lang.String kendraIDMFI,
           int seq) {
           this.accountNumber = accountNumber;
           this.branchIDMFI = branchIDMFI;
           this.kendraIDMFI = kendraIDMFI;
           this.seq = seq;
    }


    /**
     * Gets the accountNumber value for this AccountInputType.
     * 
     * @return accountNumber
     */
    public java.lang.String getAccountNumber() {
        return accountNumber;
    }


    /**
     * Sets the accountNumber value for this AccountInputType.
     * 
     * @param accountNumber
     */
    public void setAccountNumber(java.lang.String accountNumber) {
        this.accountNumber = accountNumber;
    }


    /**
     * Gets the branchIDMFI value for this AccountInputType.
     * 
     * @return branchIDMFI
     */
    public java.lang.String getBranchIDMFI() {
        return branchIDMFI;
    }


    /**
     * Sets the branchIDMFI value for this AccountInputType.
     * 
     * @param branchIDMFI
     */
    public void setBranchIDMFI(java.lang.String branchIDMFI) {
        this.branchIDMFI = branchIDMFI;
    }


    /**
     * Gets the kendraIDMFI value for this AccountInputType.
     * 
     * @return kendraIDMFI
     */
    public java.lang.String getKendraIDMFI() {
        return kendraIDMFI;
    }


    /**
     * Sets the kendraIDMFI value for this AccountInputType.
     * 
     * @param kendraIDMFI
     */
    public void setKendraIDMFI(java.lang.String kendraIDMFI) {
        this.kendraIDMFI = kendraIDMFI;
    }


    /**
     * Gets the seq value for this AccountInputType.
     * 
     * @return seq
     */
    public int getSeq() {
        return seq;
    }


    /**
     * Sets the seq value for this AccountInputType.
     * 
     * @param seq
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AccountInputType)) return false;
        AccountInputType other = (AccountInputType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.accountNumber==null && other.getAccountNumber()==null) || 
             (this.accountNumber!=null &&
              this.accountNumber.equals(other.getAccountNumber()))) &&
            ((this.branchIDMFI==null && other.getBranchIDMFI()==null) || 
             (this.branchIDMFI!=null &&
              this.branchIDMFI.equals(other.getBranchIDMFI()))) &&
            ((this.kendraIDMFI==null && other.getKendraIDMFI()==null) || 
             (this.kendraIDMFI!=null &&
              this.kendraIDMFI.equals(other.getKendraIDMFI()))) &&
            this.seq == other.getSeq();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccountNumber() != null) {
            _hashCode += getAccountNumber().hashCode();
        }
        if (getBranchIDMFI() != null) {
            _hashCode += getBranchIDMFI().hashCode();
        }
        if (getKendraIDMFI() != null) {
            _hashCode += getKendraIDMFI().hashCode();
        }
        _hashCode += getSeq();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AccountInputType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountInputType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("seq");
        attrField.setXmlName(new javax.xml.namespace.QName("", "seq"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchIDMFI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "BranchIDMFI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kendraIDMFI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "KendraIDMFI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
