/**
 * PersonalInfoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class PersonalInfoType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.NameType name;

    private com.equifax.services.eport.ws.schemas._1_0.NameType[] previousName;

    private com.equifax.services.eport.ws.schemas._1_0.AliasNameInfoType aliasNameInfo;

    /* The date is specified in the following form "YYYY-MM-DD" where:
     * * YYYY indicates the year * MM indicates the month * DD indicates
     * the day */
    private java.util.Date dateOfBirth;

    private com.equifax.services.eport.ws.schemas._1_0.GenderTypeCode gender;

    private com.equifax.services.eport.ws.schemas._1_0.AgeInfo age;

    /* This element is applicable only for Identity Report */
    private com.equifax.services.eport.ws.schemas._1_0.PlaceOfBirthInfoType placeOfBirthInfo;

    private java.lang.String totalIncome;

    private java.lang.String occupation;

    private com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions maritalStatus;

    public PersonalInfoType() {
    }

    public PersonalInfoType(
           com.equifax.services.eport.ws.schemas._1_0.NameType name,
           com.equifax.services.eport.ws.schemas._1_0.NameType[] previousName,
           com.equifax.services.eport.ws.schemas._1_0.AliasNameInfoType aliasNameInfo,
           java.util.Date dateOfBirth,
           com.equifax.services.eport.ws.schemas._1_0.GenderTypeCode gender,
           com.equifax.services.eport.ws.schemas._1_0.AgeInfo age,
           com.equifax.services.eport.ws.schemas._1_0.PlaceOfBirthInfoType placeOfBirthInfo,
           java.lang.String totalIncome,
           java.lang.String occupation,
           com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions maritalStatus) {
           this.name = name;
           this.previousName = previousName;
           this.aliasNameInfo = aliasNameInfo;
           this.dateOfBirth = dateOfBirth;
           this.gender = gender;
           this.age = age;
           this.placeOfBirthInfo = placeOfBirthInfo;
           this.totalIncome = totalIncome;
           this.occupation = occupation;
           this.maritalStatus = maritalStatus;
    }


    /**
     * Gets the name value for this PersonalInfoType.
     * 
     * @return name
     */
    public com.equifax.services.eport.ws.schemas._1_0.NameType getName() {
        return name;
    }


    /**
     * Sets the name value for this PersonalInfoType.
     * 
     * @param name
     */
    public void setName(com.equifax.services.eport.ws.schemas._1_0.NameType name) {
        this.name = name;
    }


    /**
     * Gets the previousName value for this PersonalInfoType.
     * 
     * @return previousName
     */
    public com.equifax.services.eport.ws.schemas._1_0.NameType[] getPreviousName() {
        return previousName;
    }


    /**
     * Sets the previousName value for this PersonalInfoType.
     * 
     * @param previousName
     */
    public void setPreviousName(com.equifax.services.eport.ws.schemas._1_0.NameType[] previousName) {
        this.previousName = previousName;
    }

    public com.equifax.services.eport.ws.schemas._1_0.NameType getPreviousName(int i) {
        return this.previousName[i];
    }

    public void setPreviousName(int i, com.equifax.services.eport.ws.schemas._1_0.NameType _value) {
        this.previousName[i] = _value;
    }


    /**
     * Gets the aliasNameInfo value for this PersonalInfoType.
     * 
     * @return aliasNameInfo
     */
    public com.equifax.services.eport.ws.schemas._1_0.AliasNameInfoType getAliasNameInfo() {
        return aliasNameInfo;
    }


    /**
     * Sets the aliasNameInfo value for this PersonalInfoType.
     * 
     * @param aliasNameInfo
     */
    public void setAliasNameInfo(com.equifax.services.eport.ws.schemas._1_0.AliasNameInfoType aliasNameInfo) {
        this.aliasNameInfo = aliasNameInfo;
    }


    /**
     * Gets the dateOfBirth value for this PersonalInfoType.
     * 
     * @return dateOfBirth   * The date is specified in the following form "YYYY-MM-DD" where:
     * * YYYY indicates the year * MM indicates the month * DD indicates
     * the day
     */
    public java.util.Date getDateOfBirth() {
        return dateOfBirth;
    }


    /**
     * Sets the dateOfBirth value for this PersonalInfoType.
     * 
     * @param dateOfBirth   * The date is specified in the following form "YYYY-MM-DD" where:
     * * YYYY indicates the year * MM indicates the month * DD indicates
     * the day
     */
    public void setDateOfBirth(java.util.Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }


    /**
     * Gets the gender value for this PersonalInfoType.
     * 
     * @return gender
     */
    public com.equifax.services.eport.ws.schemas._1_0.GenderTypeCode getGender() {
        return gender;
    }


    /**
     * Sets the gender value for this PersonalInfoType.
     * 
     * @param gender
     */
    public void setGender(com.equifax.services.eport.ws.schemas._1_0.GenderTypeCode gender) {
        this.gender = gender;
    }


    /**
     * Gets the age value for this PersonalInfoType.
     * 
     * @return age
     */
    public com.equifax.services.eport.ws.schemas._1_0.AgeInfo getAge() {
        return age;
    }


    /**
     * Sets the age value for this PersonalInfoType.
     * 
     * @param age
     */
    public void setAge(com.equifax.services.eport.ws.schemas._1_0.AgeInfo age) {
        this.age = age;
    }


    /**
     * Gets the placeOfBirthInfo value for this PersonalInfoType.
     * 
     * @return placeOfBirthInfo   * This element is applicable only for Identity Report
     */
    public com.equifax.services.eport.ws.schemas._1_0.PlaceOfBirthInfoType getPlaceOfBirthInfo() {
        return placeOfBirthInfo;
    }


    /**
     * Sets the placeOfBirthInfo value for this PersonalInfoType.
     * 
     * @param placeOfBirthInfo   * This element is applicable only for Identity Report
     */
    public void setPlaceOfBirthInfo(com.equifax.services.eport.ws.schemas._1_0.PlaceOfBirthInfoType placeOfBirthInfo) {
        this.placeOfBirthInfo = placeOfBirthInfo;
    }


    /**
     * Gets the totalIncome value for this PersonalInfoType.
     * 
     * @return totalIncome
     */
    public java.lang.String getTotalIncome() {
        return totalIncome;
    }


    /**
     * Sets the totalIncome value for this PersonalInfoType.
     * 
     * @param totalIncome
     */
    public void setTotalIncome(java.lang.String totalIncome) {
        this.totalIncome = totalIncome;
    }


    /**
     * Gets the occupation value for this PersonalInfoType.
     * 
     * @return occupation
     */
    public java.lang.String getOccupation() {
        return occupation;
    }


    /**
     * Sets the occupation value for this PersonalInfoType.
     * 
     * @param occupation
     */
    public void setOccupation(java.lang.String occupation) {
        this.occupation = occupation;
    }


    /**
     * Gets the maritalStatus value for this PersonalInfoType.
     * 
     * @return maritalStatus
     */
    public com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions getMaritalStatus() {
        return maritalStatus;
    }


    /**
     * Sets the maritalStatus value for this PersonalInfoType.
     * 
     * @param maritalStatus
     */
    public void setMaritalStatus(com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PersonalInfoType)) return false;
        PersonalInfoType other = (PersonalInfoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.previousName==null && other.getPreviousName()==null) || 
             (this.previousName!=null &&
              java.util.Arrays.equals(this.previousName, other.getPreviousName()))) &&
            ((this.aliasNameInfo==null && other.getAliasNameInfo()==null) || 
             (this.aliasNameInfo!=null &&
              this.aliasNameInfo.equals(other.getAliasNameInfo()))) &&
            ((this.dateOfBirth==null && other.getDateOfBirth()==null) || 
             (this.dateOfBirth!=null &&
              this.dateOfBirth.equals(other.getDateOfBirth()))) &&
            ((this.gender==null && other.getGender()==null) || 
             (this.gender!=null &&
              this.gender.equals(other.getGender()))) &&
            ((this.age==null && other.getAge()==null) || 
             (this.age!=null &&
              this.age.equals(other.getAge()))) &&
            ((this.placeOfBirthInfo==null && other.getPlaceOfBirthInfo()==null) || 
             (this.placeOfBirthInfo!=null &&
              this.placeOfBirthInfo.equals(other.getPlaceOfBirthInfo()))) &&
            ((this.totalIncome==null && other.getTotalIncome()==null) || 
             (this.totalIncome!=null &&
              this.totalIncome.equals(other.getTotalIncome()))) &&
            ((this.occupation==null && other.getOccupation()==null) || 
             (this.occupation!=null &&
              this.occupation.equals(other.getOccupation()))) &&
            ((this.maritalStatus==null && other.getMaritalStatus()==null) || 
             (this.maritalStatus!=null &&
              this.maritalStatus.equals(other.getMaritalStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getPreviousName() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPreviousName());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPreviousName(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAliasNameInfo() != null) {
            _hashCode += getAliasNameInfo().hashCode();
        }
        if (getDateOfBirth() != null) {
            _hashCode += getDateOfBirth().hashCode();
        }
        if (getGender() != null) {
            _hashCode += getGender().hashCode();
        }
        if (getAge() != null) {
            _hashCode += getAge().hashCode();
        }
        if (getPlaceOfBirthInfo() != null) {
            _hashCode += getPlaceOfBirthInfo().hashCode();
        }
        if (getTotalIncome() != null) {
            _hashCode += getTotalIncome().hashCode();
        }
        if (getOccupation() != null) {
            _hashCode += getOccupation().hashCode();
        }
        if (getMaritalStatus() != null) {
            _hashCode += getMaritalStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PersonalInfoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PersonalInfoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NameType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("previousName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PreviousName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NameType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aliasNameInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AliasNameInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AliasNameInfoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateOfBirth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateOfBirth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gender");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Gender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GenderTypeCode"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("age");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Age"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AgeInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("placeOfBirthInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PlaceOfBirthInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PlaceOfBirthInfoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalIncome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalIncome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("occupation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Occupation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maritalStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MaritalStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MaritalStatusOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
