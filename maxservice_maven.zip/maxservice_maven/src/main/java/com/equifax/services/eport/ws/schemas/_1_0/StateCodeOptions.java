/**
 * StateCodeOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class StateCodeOptions implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
//    protected StateCodeOptions(java.lang.String value) {
//        _value_ = value;
//        _table_.put(_value_,this);
//    }
    public StateCodeOptions(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _AN = "AN";
    public static final java.lang.String _AP = "AP";
    public static final java.lang.String _AR = "AR";
    public static final java.lang.String _AS = "AS";
    public static final java.lang.String _BR = "BR";
    public static final java.lang.String _CH = "CH";
    public static final java.lang.String _CG = "CG";
    public static final java.lang.String _DN = "DN";
    public static final java.lang.String _DD = "DD";
    public static final java.lang.String _DL = "DL";
    public static final java.lang.String _GA = "GA";
    public static final java.lang.String _GJ = "GJ";
    public static final java.lang.String _HR = "HR";
    public static final java.lang.String _HP = "HP";
    public static final java.lang.String _JK = "JK";
    public static final java.lang.String _JH = "JH";
    public static final java.lang.String _KA = "KA";
    public static final java.lang.String _KL = "KL";
    public static final java.lang.String _LD = "LD";
    public static final java.lang.String _MP = "MP";
    public static final java.lang.String _MH = "MH";
    public static final java.lang.String _MN = "MN";
    public static final java.lang.String _ML = "ML";
    public static final java.lang.String _MZ = "MZ";
    public static final java.lang.String _NL = "NL";
    public static final java.lang.String _OR = "OR";
    public static final java.lang.String _PY = "PY";
    public static final java.lang.String _PB = "PB";
    public static final java.lang.String _RJ = "RJ";
    public static final java.lang.String _SK = "SK";
    public static final java.lang.String _TN = "TN";
    public static final java.lang.String _TR = "TR";
    public static final java.lang.String _UP = "UP";
    public static final java.lang.String _UL = "UL";
    public static final java.lang.String _WB = "WB";
    public static final java.lang.String _TG = "TG";
    public static final StateCodeOptions AN = new StateCodeOptions(_AN);
    public static final StateCodeOptions AP = new StateCodeOptions(_AP);
    public static final StateCodeOptions AR = new StateCodeOptions(_AR);
    public static final StateCodeOptions AS = new StateCodeOptions(_AS);
    public static final StateCodeOptions BR = new StateCodeOptions(_BR);
    public static final StateCodeOptions CH = new StateCodeOptions(_CH);
    public static final StateCodeOptions CG = new StateCodeOptions(_CG);
    public static final StateCodeOptions DN = new StateCodeOptions(_DN);
    public static final StateCodeOptions DD = new StateCodeOptions(_DD);
    public static final StateCodeOptions DL = new StateCodeOptions(_DL);
    public static final StateCodeOptions GA = new StateCodeOptions(_GA);
    public static final StateCodeOptions GJ = new StateCodeOptions(_GJ);
    public static final StateCodeOptions HR = new StateCodeOptions(_HR);
    public static final StateCodeOptions HP = new StateCodeOptions(_HP);
    public static final StateCodeOptions JK = new StateCodeOptions(_JK);
    public static final StateCodeOptions JH = new StateCodeOptions(_JH);
    public static final StateCodeOptions KA = new StateCodeOptions(_KA);
    public static final StateCodeOptions KL = new StateCodeOptions(_KL);
    public static final StateCodeOptions LD = new StateCodeOptions(_LD);
    public static final StateCodeOptions MP = new StateCodeOptions(_MP);
    public static final StateCodeOptions MH = new StateCodeOptions(_MH);
    public static final StateCodeOptions MN = new StateCodeOptions(_MN);
    public static final StateCodeOptions ML = new StateCodeOptions(_ML);
    public static final StateCodeOptions MZ = new StateCodeOptions(_MZ);
    public static final StateCodeOptions NL = new StateCodeOptions(_NL);
    public static final StateCodeOptions OR = new StateCodeOptions(_OR);
    public static final StateCodeOptions PY = new StateCodeOptions(_PY);
    public static final StateCodeOptions PB = new StateCodeOptions(_PB);
    public static final StateCodeOptions RJ = new StateCodeOptions(_RJ);
    public static final StateCodeOptions SK = new StateCodeOptions(_SK);
    public static final StateCodeOptions TN = new StateCodeOptions(_TN);
    public static final StateCodeOptions TR = new StateCodeOptions(_TR);
    public static final StateCodeOptions UP = new StateCodeOptions(_UP);
    public static final StateCodeOptions UL = new StateCodeOptions(_UL);
    public static final StateCodeOptions WB = new StateCodeOptions(_WB);
    public static final StateCodeOptions TG = new StateCodeOptions(_TG);
    public java.lang.String getValue() { return _value_;}
    public static StateCodeOptions fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        StateCodeOptions enumeration = (StateCodeOptions)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static StateCodeOptions fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StateCodeOptions.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "StateCodeOptions"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
