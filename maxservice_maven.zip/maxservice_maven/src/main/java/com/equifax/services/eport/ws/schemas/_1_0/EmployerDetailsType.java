/**
 * EmployerDetailsType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class EmployerDetailsType  implements java.io.Serializable {
    private java.lang.String employerName;

    private java.lang.String position;

    private com.equifax.services.eport.ws.schemas._1_0.PhoneType phone;

    private com.equifax.services.eport.ws.schemas._1_0.AddressType address;

    private int seq;  // attribute

    private java.util.Date reportedDate;  // attribute

    public EmployerDetailsType() {
    }

    public EmployerDetailsType(
           java.lang.String employerName,
           java.lang.String position,
           com.equifax.services.eport.ws.schemas._1_0.PhoneType phone,
           com.equifax.services.eport.ws.schemas._1_0.AddressType address,
           int seq,
           java.util.Date reportedDate) {
           this.employerName = employerName;
           this.position = position;
           this.phone = phone;
           this.address = address;
           this.seq = seq;
           this.reportedDate = reportedDate;
    }


    /**
     * Gets the employerName value for this EmployerDetailsType.
     * 
     * @return employerName
     */
    public java.lang.String getEmployerName() {
        return employerName;
    }


    /**
     * Sets the employerName value for this EmployerDetailsType.
     * 
     * @param employerName
     */
    public void setEmployerName(java.lang.String employerName) {
        this.employerName = employerName;
    }


    /**
     * Gets the position value for this EmployerDetailsType.
     * 
     * @return position
     */
    public java.lang.String getPosition() {
        return position;
    }


    /**
     * Sets the position value for this EmployerDetailsType.
     * 
     * @param position
     */
    public void setPosition(java.lang.String position) {
        this.position = position;
    }


    /**
     * Gets the phone value for this EmployerDetailsType.
     * 
     * @return phone
     */
    public com.equifax.services.eport.ws.schemas._1_0.PhoneType getPhone() {
        return phone;
    }


    /**
     * Sets the phone value for this EmployerDetailsType.
     * 
     * @param phone
     */
    public void setPhone(com.equifax.services.eport.ws.schemas._1_0.PhoneType phone) {
        this.phone = phone;
    }


    /**
     * Gets the address value for this EmployerDetailsType.
     * 
     * @return address
     */
    public com.equifax.services.eport.ws.schemas._1_0.AddressType getAddress() {
        return address;
    }


    /**
     * Sets the address value for this EmployerDetailsType.
     * 
     * @param address
     */
    public void setAddress(com.equifax.services.eport.ws.schemas._1_0.AddressType address) {
        this.address = address;
    }


    /**
     * Gets the seq value for this EmployerDetailsType.
     * 
     * @return seq
     */
    public int getSeq() {
        return seq;
    }


    /**
     * Sets the seq value for this EmployerDetailsType.
     * 
     * @param seq
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }


    /**
     * Gets the reportedDate value for this EmployerDetailsType.
     * 
     * @return reportedDate
     */
    public java.util.Date getReportedDate() {
        return reportedDate;
    }


    /**
     * Sets the reportedDate value for this EmployerDetailsType.
     * 
     * @param reportedDate
     */
    public void setReportedDate(java.util.Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmployerDetailsType)) return false;
        EmployerDetailsType other = (EmployerDetailsType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.employerName==null && other.getEmployerName()==null) || 
             (this.employerName!=null &&
              this.employerName.equals(other.getEmployerName()))) &&
            ((this.position==null && other.getPosition()==null) || 
             (this.position!=null &&
              this.position.equals(other.getPosition()))) &&
            ((this.phone==null && other.getPhone()==null) || 
             (this.phone!=null &&
              this.phone.equals(other.getPhone()))) &&
            ((this.address==null && other.getAddress()==null) || 
             (this.address!=null &&
              this.address.equals(other.getAddress()))) &&
            this.seq == other.getSeq() &&
            ((this.reportedDate==null && other.getReportedDate()==null) || 
             (this.reportedDate!=null &&
              this.reportedDate.equals(other.getReportedDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEmployerName() != null) {
            _hashCode += getEmployerName().hashCode();
        }
        if (getPosition() != null) {
            _hashCode += getPosition().hashCode();
        }
        if (getPhone() != null) {
            _hashCode += getPhone().hashCode();
        }
        if (getAddress() != null) {
            _hashCode += getAddress().hashCode();
        }
        _hashCode += getSeq();
        if (getReportedDate() != null) {
            _hashCode += getReportedDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmployerDetailsType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EmployerDetailsType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("seq");
        attrField.setXmlName(new javax.xml.namespace.QName("", "seq"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("reportedDate");
        attrField.setXmlName(new javax.xml.namespace.QName("", "ReportedDate"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("employerName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EmployerName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("position");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Position"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PhoneType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("address");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AddressType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
