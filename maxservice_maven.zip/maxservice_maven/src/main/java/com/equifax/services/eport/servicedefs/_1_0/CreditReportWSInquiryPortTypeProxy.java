package com.equifax.services.eport.servicedefs._1_0;

import java.util.ResourceBundle;

public class CreditReportWSInquiryPortTypeProxy implements com.equifax.services.eport.servicedefs._1_0.CreditReportWSInquiryPortType {
  private String _endpoint = null;
  private com.equifax.services.eport.servicedefs._1_0.CreditReportWSInquiryPortType creditReportWSInquiryPortType = null;
  ResourceBundle resProp = ResourceBundle.getBundle("com.qualtech.pan.resource.prop");
  public CreditReportWSInquiryPortTypeProxy() {
    _initCreditReportWSInquiryPortTypeProxy();
  }
  
  public CreditReportWSInquiryPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initCreditReportWSInquiryPortTypeProxy();
  }
  
  private void _initCreditReportWSInquiryPortTypeProxy() {
    try {
      creditReportWSInquiryPortType = (new com.equifax.services.eport.servicedefs._1_0.V10Locator()).getCreditReportWSInquiryPort();
      if (creditReportWSInquiryPortType != null) {
        if (_endpoint != null)
          {
        	((javax.xml.rpc.Stub)creditReportWSInquiryPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
//        	TIMEOUT
        	((javax.xml.rpc.Stub)creditReportWSInquiryPortType)._setProperty("axis.connection.timeout",Integer.parseInt(resProp.getString("com.qualtech.pan.resource.EQUIFAX.Timeout")));
          }
         else
          _endpoint = (String)((javax.xml.rpc.Stub)creditReportWSInquiryPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
//        TIMEOUT
        ((javax.xml.rpc.Stub)creditReportWSInquiryPortType)._setProperty("axis.connection.timeout",Integer.parseInt(resProp.getString("com.qualtech.pan.resource.EQUIFAX.Timeout")));
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (creditReportWSInquiryPortType != null)
      ((javax.xml.rpc.Stub)creditReportWSInquiryPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.equifax.services.eport.servicedefs._1_0.CreditReportWSInquiryPortType getCreditReportWSInquiryPortType() {
    if (creditReportWSInquiryPortType == null)
      _initCreditReportWSInquiryPortTypeProxy();
    return creditReportWSInquiryPortType;
  }
  
  public com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType getConsumerCreditReport(com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType input) throws java.rmi.RemoteException{
    if (creditReportWSInquiryPortType == null)
      _initCreditReportWSInquiryPortTypeProxy();
    return creditReportWSInquiryPortType.getConsumerCreditReport(input);
  }
  
  
}