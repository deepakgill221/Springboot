/**
 * RequestHeaderType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class RequestHeaderType  implements java.io.Serializable {
    private int customerId;

    private java.lang.String userId;

    private java.lang.String password;

    private java.lang.String memberNumber;

    private java.lang.String securityCode;

    private java.lang.String productCode;

    private java.lang.String productVersion;

    private com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions reportFormat;

    private java.lang.String custRefField;

    private java.lang.String customInquiryFlag;

    private java.lang.String n3ConfigID;

    public RequestHeaderType() {
    }

    public RequestHeaderType(
           int customerId,
           java.lang.String userId,
           java.lang.String password,
           java.lang.String memberNumber,
           java.lang.String securityCode,
           java.lang.String productCode,
           java.lang.String productVersion,
           com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions reportFormat,
           java.lang.String custRefField,
           java.lang.String customInquiryFlag,
           java.lang.String n3ConfigID) {
           this.customerId = customerId;
           this.userId = userId;
           this.password = password;
           this.memberNumber = memberNumber;
           this.securityCode = securityCode;
           this.productCode = productCode;
           this.productVersion = productVersion;
           this.reportFormat = reportFormat;
           this.custRefField = custRefField;
           this.customInquiryFlag = customInquiryFlag;
           this.n3ConfigID = n3ConfigID;
    }


    /**
     * Gets the customerId value for this RequestHeaderType.
     * 
     * @return customerId
     */
    public int getCustomerId() {
        return customerId;
    }


    /**
     * Sets the customerId value for this RequestHeaderType.
     * 
     * @param customerId
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }


    /**
     * Gets the userId value for this RequestHeaderType.
     * 
     * @return userId
     */
    public java.lang.String getUserId() {
        return userId;
    }


    /**
     * Sets the userId value for this RequestHeaderType.
     * 
     * @param userId
     */
    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }


    /**
     * Gets the password value for this RequestHeaderType.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this RequestHeaderType.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the memberNumber value for this RequestHeaderType.
     * 
     * @return memberNumber
     */
    public java.lang.String getMemberNumber() {
        return memberNumber;
    }


    /**
     * Sets the memberNumber value for this RequestHeaderType.
     * 
     * @param memberNumber
     */
    public void setMemberNumber(java.lang.String memberNumber) {
        this.memberNumber = memberNumber;
    }


    /**
     * Gets the securityCode value for this RequestHeaderType.
     * 
     * @return securityCode
     */
    public java.lang.String getSecurityCode() {
        return securityCode;
    }


    /**
     * Sets the securityCode value for this RequestHeaderType.
     * 
     * @param securityCode
     */
    public void setSecurityCode(java.lang.String securityCode) {
        this.securityCode = securityCode;
    }


    /**
     * Gets the productCode value for this RequestHeaderType.
     * 
     * @return productCode
     */
    public java.lang.String getProductCode() {
        return productCode;
    }


    /**
     * Sets the productCode value for this RequestHeaderType.
     * 
     * @param productCode
     */
    public void setProductCode(java.lang.String productCode) {
        this.productCode = productCode;
    }


    /**
     * Gets the productVersion value for this RequestHeaderType.
     * 
     * @return productVersion
     */
    public java.lang.String getProductVersion() {
        return productVersion;
    }


    /**
     * Sets the productVersion value for this RequestHeaderType.
     * 
     * @param productVersion
     */
    public void setProductVersion(java.lang.String productVersion) {
        this.productVersion = productVersion;
    }


    /**
     * Gets the reportFormat value for this RequestHeaderType.
     * 
     * @return reportFormat
     */
    public com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions getReportFormat() {
        return reportFormat;
    }


    /**
     * Sets the reportFormat value for this RequestHeaderType.
     * 
     * @param reportFormat
     */
    public void setReportFormat(com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions reportFormat) {
        this.reportFormat = reportFormat;
    }


    /**
     * Gets the custRefField value for this RequestHeaderType.
     * 
     * @return custRefField
     */
    public java.lang.String getCustRefField() {
        return custRefField;
    }


    /**
     * Sets the custRefField value for this RequestHeaderType.
     * 
     * @param custRefField
     */
    public void setCustRefField(java.lang.String custRefField) {
        this.custRefField = custRefField;
    }


    /**
     * Gets the customInquiryFlag value for this RequestHeaderType.
     * 
     * @return customInquiryFlag
     */
    public java.lang.String getCustomInquiryFlag() {
        return customInquiryFlag;
    }


    /**
     * Sets the customInquiryFlag value for this RequestHeaderType.
     * 
     * @param customInquiryFlag
     */
    public void setCustomInquiryFlag(java.lang.String customInquiryFlag) {
        this.customInquiryFlag = customInquiryFlag;
    }


    /**
     * Gets the n3ConfigID value for this RequestHeaderType.
     * 
     * @return n3ConfigID
     */
    public java.lang.String getN3ConfigID() {
        return n3ConfigID;
    }


    /**
     * Sets the n3ConfigID value for this RequestHeaderType.
     * 
     * @param n3ConfigID
     */
    public void setN3ConfigID(java.lang.String n3ConfigID) {
        this.n3ConfigID = n3ConfigID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RequestHeaderType)) return false;
        RequestHeaderType other = (RequestHeaderType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.customerId == other.getCustomerId() &&
            ((this.userId==null && other.getUserId()==null) || 
             (this.userId!=null &&
              this.userId.equals(other.getUserId()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.memberNumber==null && other.getMemberNumber()==null) || 
             (this.memberNumber!=null &&
              this.memberNumber.equals(other.getMemberNumber()))) &&
            ((this.securityCode==null && other.getSecurityCode()==null) || 
             (this.securityCode!=null &&
              this.securityCode.equals(other.getSecurityCode()))) &&
            ((this.productCode==null && other.getProductCode()==null) || 
             (this.productCode!=null &&
              this.productCode.equals(other.getProductCode()))) &&
            ((this.productVersion==null && other.getProductVersion()==null) || 
             (this.productVersion!=null &&
              this.productVersion.equals(other.getProductVersion()))) &&
            ((this.reportFormat==null && other.getReportFormat()==null) || 
             (this.reportFormat!=null &&
              this.reportFormat.equals(other.getReportFormat()))) &&
            ((this.custRefField==null && other.getCustRefField()==null) || 
             (this.custRefField!=null &&
              this.custRefField.equals(other.getCustRefField()))) &&
            ((this.customInquiryFlag==null && other.getCustomInquiryFlag()==null) || 
             (this.customInquiryFlag!=null &&
              this.customInquiryFlag.equals(other.getCustomInquiryFlag()))) &&
            ((this.n3ConfigID==null && other.getN3ConfigID()==null) || 
             (this.n3ConfigID!=null &&
              this.n3ConfigID.equals(other.getN3ConfigID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getCustomerId();
        if (getUserId() != null) {
            _hashCode += getUserId().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getMemberNumber() != null) {
            _hashCode += getMemberNumber().hashCode();
        }
        if (getSecurityCode() != null) {
            _hashCode += getSecurityCode().hashCode();
        }
        if (getProductCode() != null) {
            _hashCode += getProductCode().hashCode();
        }
        if (getProductVersion() != null) {
            _hashCode += getProductVersion().hashCode();
        }
        if (getReportFormat() != null) {
            _hashCode += getReportFormat().hashCode();
        }
        if (getCustRefField() != null) {
            _hashCode += getCustRefField().hashCode();
        }
        if (getCustomInquiryFlag() != null) {
            _hashCode += getCustomInquiryFlag().hashCode();
        }
        if (getN3ConfigID() != null) {
            _hashCode += getN3ConfigID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RequestHeaderType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestHeaderType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CustomerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "UserId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("memberNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MemberNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("securityCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SecurityCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ProductCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ProductVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ReportFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ReportFormatOptions"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("custRefField");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CustRefField"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customInquiryFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CustomInquiryFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("n3ConfigID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "N3ConfigID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
