/**
 * InquiryResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;


/**
 * The Inquiry service request message type definition
 */
public class InquiryResponseType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.InquiryResponseHeaderType inquiryResponseHeader;

    private com.equifax.services.eport.ws.schemas._1_0.RequestBodyType inquiryRequestInfo;

    private com.equifax.services.eport.ws.schemas._1_0.ReportType reportData;

    public InquiryResponseType() {
    }

    public InquiryResponseType(
           com.equifax.services.eport.ws.schemas._1_0.InquiryResponseHeaderType inquiryResponseHeader,
           com.equifax.services.eport.ws.schemas._1_0.RequestBodyType inquiryRequestInfo,
           com.equifax.services.eport.ws.schemas._1_0.ReportType reportData) {
           this.inquiryResponseHeader = inquiryResponseHeader;
           this.inquiryRequestInfo = inquiryRequestInfo;
           this.reportData = reportData;
    }


    /**
     * Gets the inquiryResponseHeader value for this InquiryResponseType.
     * 
     * @return inquiryResponseHeader
     */
    public com.equifax.services.eport.ws.schemas._1_0.InquiryResponseHeaderType getInquiryResponseHeader() {
        return inquiryResponseHeader;
    }


    /**
     * Sets the inquiryResponseHeader value for this InquiryResponseType.
     * 
     * @param inquiryResponseHeader
     */
    public void setInquiryResponseHeader(com.equifax.services.eport.ws.schemas._1_0.InquiryResponseHeaderType inquiryResponseHeader) {
        this.inquiryResponseHeader = inquiryResponseHeader;
    }


    /**
     * Gets the inquiryRequestInfo value for this InquiryResponseType.
     * 
     * @return inquiryRequestInfo
     */
    public com.equifax.services.eport.ws.schemas._1_0.RequestBodyType getInquiryRequestInfo() {
        return inquiryRequestInfo;
    }


    /**
     * Sets the inquiryRequestInfo value for this InquiryResponseType.
     * 
     * @param inquiryRequestInfo
     */
    public void setInquiryRequestInfo(com.equifax.services.eport.ws.schemas._1_0.RequestBodyType inquiryRequestInfo) {
        this.inquiryRequestInfo = inquiryRequestInfo;
    }


    /**
     * Gets the reportData value for this InquiryResponseType.
     * 
     * @return reportData
     */
    public com.equifax.services.eport.ws.schemas._1_0.ReportType getReportData() {
        return reportData;
    }


    /**
     * Sets the reportData value for this InquiryResponseType.
     * 
     * @param reportData
     */
    public void setReportData(com.equifax.services.eport.ws.schemas._1_0.ReportType reportData) {
        this.reportData = reportData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InquiryResponseType)) return false;
        InquiryResponseType other = (InquiryResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.inquiryResponseHeader==null && other.getInquiryResponseHeader()==null) || 
             (this.inquiryResponseHeader!=null &&
              this.inquiryResponseHeader.equals(other.getInquiryResponseHeader()))) &&
            ((this.inquiryRequestInfo==null && other.getInquiryRequestInfo()==null) || 
             (this.inquiryRequestInfo!=null &&
              this.inquiryRequestInfo.equals(other.getInquiryRequestInfo()))) &&
            ((this.reportData==null && other.getReportData()==null) || 
             (this.reportData!=null &&
              this.reportData.equals(other.getReportData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getInquiryResponseHeader() != null) {
            _hashCode += getInquiryResponseHeader().hashCode();
        }
        if (getInquiryRequestInfo() != null) {
            _hashCode += getInquiryRequestInfo().hashCode();
        }
        if (getReportData() != null) {
            _hashCode += getReportData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InquiryResponseType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inquiryResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryResponseHeaderType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inquiryRequestInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryRequestInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestBodyType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ReportData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ReportType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
