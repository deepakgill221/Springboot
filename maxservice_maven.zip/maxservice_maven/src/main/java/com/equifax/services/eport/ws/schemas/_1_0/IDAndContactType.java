/**
 * IDAndContactType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class IDAndContactType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.PersonalInfoType personalInfo;

    private com.equifax.services.eport.ws.schemas._1_0.IdentificationType identityInfo;

    /* All reported address will be returned here. */
    private com.equifax.services.eport.ws.schemas._1_0.AddressType[] addressInfo;

    private com.equifax.services.eport.ws.schemas._1_0.FamilyInfo familyDetails;

    /* All Phone (Home/Business/Fax/Mobile) information will be returned
     * here. */
    private com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phoneInfo;

    private com.equifax.services.eport.ws.schemas._1_0.EmailAddressType[] emailAddressInfo;

    public IDAndContactType() {
    }

    public IDAndContactType(
           com.equifax.services.eport.ws.schemas._1_0.PersonalInfoType personalInfo,
           com.equifax.services.eport.ws.schemas._1_0.IdentificationType identityInfo,
           com.equifax.services.eport.ws.schemas._1_0.AddressType[] addressInfo,
           com.equifax.services.eport.ws.schemas._1_0.FamilyInfo familyDetails,
           com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phoneInfo,
           com.equifax.services.eport.ws.schemas._1_0.EmailAddressType[] emailAddressInfo) {
           this.personalInfo = personalInfo;
           this.identityInfo = identityInfo;
           this.addressInfo = addressInfo;
           this.familyDetails = familyDetails;
           this.phoneInfo = phoneInfo;
           this.emailAddressInfo = emailAddressInfo;
    }


    /**
     * Gets the personalInfo value for this IDAndContactType.
     * 
     * @return personalInfo
     */
    public com.equifax.services.eport.ws.schemas._1_0.PersonalInfoType getPersonalInfo() {
        return personalInfo;
    }


    /**
     * Sets the personalInfo value for this IDAndContactType.
     * 
     * @param personalInfo
     */
    public void setPersonalInfo(com.equifax.services.eport.ws.schemas._1_0.PersonalInfoType personalInfo) {
        this.personalInfo = personalInfo;
    }


    /**
     * Gets the identityInfo value for this IDAndContactType.
     * 
     * @return identityInfo
     */
    public com.equifax.services.eport.ws.schemas._1_0.IdentificationType getIdentityInfo() {
        return identityInfo;
    }


    /**
     * Sets the identityInfo value for this IDAndContactType.
     * 
     * @param identityInfo
     */
    public void setIdentityInfo(com.equifax.services.eport.ws.schemas._1_0.IdentificationType identityInfo) {
        this.identityInfo = identityInfo;
    }


    /**
     * Gets the addressInfo value for this IDAndContactType.
     * 
     * @return addressInfo   * All reported address will be returned here.
     */
    public com.equifax.services.eport.ws.schemas._1_0.AddressType[] getAddressInfo() {
        return addressInfo;
    }


    /**
     * Sets the addressInfo value for this IDAndContactType.
     * 
     * @param addressInfo   * All reported address will be returned here.
     */
    public void setAddressInfo(com.equifax.services.eport.ws.schemas._1_0.AddressType[] addressInfo) {
        this.addressInfo = addressInfo;
    }

    public com.equifax.services.eport.ws.schemas._1_0.AddressType getAddressInfo(int i) {
        return this.addressInfo[i];
    }

    public void setAddressInfo(int i, com.equifax.services.eport.ws.schemas._1_0.AddressType _value) {
        this.addressInfo[i] = _value;
    }


    /**
     * Gets the familyDetails value for this IDAndContactType.
     * 
     * @return familyDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.FamilyInfo getFamilyDetails() {
        return familyDetails;
    }


    /**
     * Sets the familyDetails value for this IDAndContactType.
     * 
     * @param familyDetails
     */
    public void setFamilyDetails(com.equifax.services.eport.ws.schemas._1_0.FamilyInfo familyDetails) {
        this.familyDetails = familyDetails;
    }


    /**
     * Gets the phoneInfo value for this IDAndContactType.
     * 
     * @return phoneInfo   * All Phone (Home/Business/Fax/Mobile) information will be returned
     * here.
     */
    public com.equifax.services.eport.ws.schemas._1_0.PhoneType[] getPhoneInfo() {
        return phoneInfo;
    }


    /**
     * Sets the phoneInfo value for this IDAndContactType.
     * 
     * @param phoneInfo   * All Phone (Home/Business/Fax/Mobile) information will be returned
     * here.
     */
    public void setPhoneInfo(com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phoneInfo) {
        this.phoneInfo = phoneInfo;
    }

    public com.equifax.services.eport.ws.schemas._1_0.PhoneType getPhoneInfo(int i) {
        return this.phoneInfo[i];
    }

    public void setPhoneInfo(int i, com.equifax.services.eport.ws.schemas._1_0.PhoneType _value) {
        this.phoneInfo[i] = _value;
    }


    /**
     * Gets the emailAddressInfo value for this IDAndContactType.
     * 
     * @return emailAddressInfo
     */
    public com.equifax.services.eport.ws.schemas._1_0.EmailAddressType[] getEmailAddressInfo() {
        return emailAddressInfo;
    }


    /**
     * Sets the emailAddressInfo value for this IDAndContactType.
     * 
     * @param emailAddressInfo
     */
    public void setEmailAddressInfo(com.equifax.services.eport.ws.schemas._1_0.EmailAddressType[] emailAddressInfo) {
        this.emailAddressInfo = emailAddressInfo;
    }

    public com.equifax.services.eport.ws.schemas._1_0.EmailAddressType getEmailAddressInfo(int i) {
        return this.emailAddressInfo[i];
    }

    public void setEmailAddressInfo(int i, com.equifax.services.eport.ws.schemas._1_0.EmailAddressType _value) {
        this.emailAddressInfo[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IDAndContactType)) return false;
        IDAndContactType other = (IDAndContactType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.personalInfo==null && other.getPersonalInfo()==null) || 
             (this.personalInfo!=null &&
              this.personalInfo.equals(other.getPersonalInfo()))) &&
            ((this.identityInfo==null && other.getIdentityInfo()==null) || 
             (this.identityInfo!=null &&
              this.identityInfo.equals(other.getIdentityInfo()))) &&
            ((this.addressInfo==null && other.getAddressInfo()==null) || 
             (this.addressInfo!=null &&
              java.util.Arrays.equals(this.addressInfo, other.getAddressInfo()))) &&
            ((this.familyDetails==null && other.getFamilyDetails()==null) || 
             (this.familyDetails!=null &&
              this.familyDetails.equals(other.getFamilyDetails()))) &&
            ((this.phoneInfo==null && other.getPhoneInfo()==null) || 
             (this.phoneInfo!=null &&
              java.util.Arrays.equals(this.phoneInfo, other.getPhoneInfo()))) &&
            ((this.emailAddressInfo==null && other.getEmailAddressInfo()==null) || 
             (this.emailAddressInfo!=null &&
              java.util.Arrays.equals(this.emailAddressInfo, other.getEmailAddressInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPersonalInfo() != null) {
            _hashCode += getPersonalInfo().hashCode();
        }
        if (getIdentityInfo() != null) {
            _hashCode += getIdentityInfo().hashCode();
        }
        if (getAddressInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAddressInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAddressInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFamilyDetails() != null) {
            _hashCode += getFamilyDetails().hashCode();
        }
        if (getPhoneInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPhoneInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPhoneInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEmailAddressInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEmailAddressInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEmailAddressInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IDAndContactType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDAndContactType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("personalInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PersonalInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PersonalInfoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identityInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IdentityInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IdentificationType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addressInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AddressInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AddressType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("familyDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "FamilyDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "FamilyInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phoneInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PhoneInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PhoneType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailAddressInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EmailAddressInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EmailAddressType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
