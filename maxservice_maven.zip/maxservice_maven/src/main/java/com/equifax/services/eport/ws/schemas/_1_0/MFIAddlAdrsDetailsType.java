/**
 * MFIAddlAdrsDetailsType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class MFIAddlAdrsDetailsType  implements java.io.Serializable {
    private java.lang.String MFIAddressline;

    private java.lang.String MFIState;

    private java.lang.String MFIPostalPIN;

    private int seq;  // attribute

    public MFIAddlAdrsDetailsType() {
    }

    public MFIAddlAdrsDetailsType(
           java.lang.String MFIAddressline,
           java.lang.String MFIState,
           java.lang.String MFIPostalPIN,
           int seq) {
           this.MFIAddressline = MFIAddressline;
           this.MFIState = MFIState;
           this.MFIPostalPIN = MFIPostalPIN;
           this.seq = seq;
    }


    /**
     * Gets the MFIAddressline value for this MFIAddlAdrsDetailsType.
     * 
     * @return MFIAddressline
     */
    public java.lang.String getMFIAddressline() {
        return MFIAddressline;
    }


    /**
     * Sets the MFIAddressline value for this MFIAddlAdrsDetailsType.
     * 
     * @param MFIAddressline
     */
    public void setMFIAddressline(java.lang.String MFIAddressline) {
        this.MFIAddressline = MFIAddressline;
    }


    /**
     * Gets the MFIState value for this MFIAddlAdrsDetailsType.
     * 
     * @return MFIState
     */
    public java.lang.String getMFIState() {
        return MFIState;
    }


    /**
     * Sets the MFIState value for this MFIAddlAdrsDetailsType.
     * 
     * @param MFIState
     */
    public void setMFIState(java.lang.String MFIState) {
        this.MFIState = MFIState;
    }


    /**
     * Gets the MFIPostalPIN value for this MFIAddlAdrsDetailsType.
     * 
     * @return MFIPostalPIN
     */
    public java.lang.String getMFIPostalPIN() {
        return MFIPostalPIN;
    }


    /**
     * Sets the MFIPostalPIN value for this MFIAddlAdrsDetailsType.
     * 
     * @param MFIPostalPIN
     */
    public void setMFIPostalPIN(java.lang.String MFIPostalPIN) {
        this.MFIPostalPIN = MFIPostalPIN;
    }


    /**
     * Gets the seq value for this MFIAddlAdrsDetailsType.
     * 
     * @return seq
     */
    public int getSeq() {
        return seq;
    }


    /**
     * Sets the seq value for this MFIAddlAdrsDetailsType.
     * 
     * @param seq
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MFIAddlAdrsDetailsType)) return false;
        MFIAddlAdrsDetailsType other = (MFIAddlAdrsDetailsType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MFIAddressline==null && other.getMFIAddressline()==null) || 
             (this.MFIAddressline!=null &&
              this.MFIAddressline.equals(other.getMFIAddressline()))) &&
            ((this.MFIState==null && other.getMFIState()==null) || 
             (this.MFIState!=null &&
              this.MFIState.equals(other.getMFIState()))) &&
            ((this.MFIPostalPIN==null && other.getMFIPostalPIN()==null) || 
             (this.MFIPostalPIN!=null &&
              this.MFIPostalPIN.equals(other.getMFIPostalPIN()))) &&
            this.seq == other.getSeq();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMFIAddressline() != null) {
            _hashCode += getMFIAddressline().hashCode();
        }
        if (getMFIState() != null) {
            _hashCode += getMFIState().hashCode();
        }
        if (getMFIPostalPIN() != null) {
            _hashCode += getMFIPostalPIN().hashCode();
        }
        _hashCode += getSeq();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MFIAddlAdrsDetailsType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAddlAdrsDetailsType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("seq");
        attrField.setXmlName(new javax.xml.namespace.QName("", "seq"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIAddressline");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAddressline"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIState");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIPostalPIN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIPostalPIN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
