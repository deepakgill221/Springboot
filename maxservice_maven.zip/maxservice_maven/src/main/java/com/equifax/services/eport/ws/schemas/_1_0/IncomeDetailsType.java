/**
 * IncomeDetailsType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;


/**
 * Income Details Type
 */
public class IncomeDetailsType  implements java.io.Serializable {
    private java.lang.String occupation;

    private java.lang.String monthlyIncome;

    private java.lang.String monthlyExpense;

    private java.lang.String povertyIndex;

    private java.lang.String assetOwnership;

    private int seq;  // attribute

    private java.util.Date reportedDate;  // attribute

    public IncomeDetailsType() {
    }

    public IncomeDetailsType(
           java.lang.String occupation,
           java.lang.String monthlyIncome,
           java.lang.String monthlyExpense,
           java.lang.String povertyIndex,
           java.lang.String assetOwnership,
           int seq,
           java.util.Date reportedDate) {
           this.occupation = occupation;
           this.monthlyIncome = monthlyIncome;
           this.monthlyExpense = monthlyExpense;
           this.povertyIndex = povertyIndex;
           this.assetOwnership = assetOwnership;
           this.seq = seq;
           this.reportedDate = reportedDate;
    }


    /**
     * Gets the occupation value for this IncomeDetailsType.
     * 
     * @return occupation
     */
    public java.lang.String getOccupation() {
        return occupation;
    }


    /**
     * Sets the occupation value for this IncomeDetailsType.
     * 
     * @param occupation
     */
    public void setOccupation(java.lang.String occupation) {
        this.occupation = occupation;
    }


    /**
     * Gets the monthlyIncome value for this IncomeDetailsType.
     * 
     * @return monthlyIncome
     */
    public java.lang.String getMonthlyIncome() {
        return monthlyIncome;
    }


    /**
     * Sets the monthlyIncome value for this IncomeDetailsType.
     * 
     * @param monthlyIncome
     */
    public void setMonthlyIncome(java.lang.String monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }


    /**
     * Gets the monthlyExpense value for this IncomeDetailsType.
     * 
     * @return monthlyExpense
     */
    public java.lang.String getMonthlyExpense() {
        return monthlyExpense;
    }


    /**
     * Sets the monthlyExpense value for this IncomeDetailsType.
     * 
     * @param monthlyExpense
     */
    public void setMonthlyExpense(java.lang.String monthlyExpense) {
        this.monthlyExpense = monthlyExpense;
    }


    /**
     * Gets the povertyIndex value for this IncomeDetailsType.
     * 
     * @return povertyIndex
     */
    public java.lang.String getPovertyIndex() {
        return povertyIndex;
    }


    /**
     * Sets the povertyIndex value for this IncomeDetailsType.
     * 
     * @param povertyIndex
     */
    public void setPovertyIndex(java.lang.String povertyIndex) {
        this.povertyIndex = povertyIndex;
    }


    /**
     * Gets the assetOwnership value for this IncomeDetailsType.
     * 
     * @return assetOwnership
     */
    public java.lang.String getAssetOwnership() {
        return assetOwnership;
    }


    /**
     * Sets the assetOwnership value for this IncomeDetailsType.
     * 
     * @param assetOwnership
     */
    public void setAssetOwnership(java.lang.String assetOwnership) {
        this.assetOwnership = assetOwnership;
    }


    /**
     * Gets the seq value for this IncomeDetailsType.
     * 
     * @return seq
     */
    public int getSeq() {
        return seq;
    }


    /**
     * Sets the seq value for this IncomeDetailsType.
     * 
     * @param seq
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }


    /**
     * Gets the reportedDate value for this IncomeDetailsType.
     * 
     * @return reportedDate
     */
    public java.util.Date getReportedDate() {
        return reportedDate;
    }


    /**
     * Sets the reportedDate value for this IncomeDetailsType.
     * 
     * @param reportedDate
     */
    public void setReportedDate(java.util.Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IncomeDetailsType)) return false;
        IncomeDetailsType other = (IncomeDetailsType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.occupation==null && other.getOccupation()==null) || 
             (this.occupation!=null &&
              this.occupation.equals(other.getOccupation()))) &&
            ((this.monthlyIncome==null && other.getMonthlyIncome()==null) || 
             (this.monthlyIncome!=null &&
              this.monthlyIncome.equals(other.getMonthlyIncome()))) &&
            ((this.monthlyExpense==null && other.getMonthlyExpense()==null) || 
             (this.monthlyExpense!=null &&
              this.monthlyExpense.equals(other.getMonthlyExpense()))) &&
            ((this.povertyIndex==null && other.getPovertyIndex()==null) || 
             (this.povertyIndex!=null &&
              this.povertyIndex.equals(other.getPovertyIndex()))) &&
            ((this.assetOwnership==null && other.getAssetOwnership()==null) || 
             (this.assetOwnership!=null &&
              this.assetOwnership.equals(other.getAssetOwnership()))) &&
            this.seq == other.getSeq() &&
            ((this.reportedDate==null && other.getReportedDate()==null) || 
             (this.reportedDate!=null &&
              this.reportedDate.equals(other.getReportedDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOccupation() != null) {
            _hashCode += getOccupation().hashCode();
        }
        if (getMonthlyIncome() != null) {
            _hashCode += getMonthlyIncome().hashCode();
        }
        if (getMonthlyExpense() != null) {
            _hashCode += getMonthlyExpense().hashCode();
        }
        if (getPovertyIndex() != null) {
            _hashCode += getPovertyIndex().hashCode();
        }
        if (getAssetOwnership() != null) {
            _hashCode += getAssetOwnership().hashCode();
        }
        _hashCode += getSeq();
        if (getReportedDate() != null) {
            _hashCode += getReportedDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IncomeDetailsType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IncomeDetailsType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("seq");
        attrField.setXmlName(new javax.xml.namespace.QName("", "seq"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("reportedDate");
        attrField.setXmlName(new javax.xml.namespace.QName("", "ReportedDate"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("occupation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Occupation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("monthlyIncome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MonthlyIncome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("monthlyExpense");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MonthlyExpense"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("povertyIndex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PovertyIndex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("assetOwnership");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AssetOwnership"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
