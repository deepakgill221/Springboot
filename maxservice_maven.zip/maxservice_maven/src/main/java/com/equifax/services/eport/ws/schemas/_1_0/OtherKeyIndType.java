/**
 * OtherKeyIndType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class OtherKeyIndType  implements java.io.Serializable {
    private java.lang.String ageOfOldestTrade;

    private java.lang.String numberOfOpenTrades;

    private java.lang.String allLinesEVERWritten;

    private java.lang.String allLinesEVERWrittenIn9Months;

    private java.lang.String allLinesEVERWrittenIn6Months;

    public OtherKeyIndType() {
    }

    public OtherKeyIndType(
           java.lang.String ageOfOldestTrade,
           java.lang.String numberOfOpenTrades,
           java.lang.String allLinesEVERWritten,
           java.lang.String allLinesEVERWrittenIn9Months,
           java.lang.String allLinesEVERWrittenIn6Months) {
           this.ageOfOldestTrade = ageOfOldestTrade;
           this.numberOfOpenTrades = numberOfOpenTrades;
           this.allLinesEVERWritten = allLinesEVERWritten;
           this.allLinesEVERWrittenIn9Months = allLinesEVERWrittenIn9Months;
           this.allLinesEVERWrittenIn6Months = allLinesEVERWrittenIn6Months;
    }


    /**
     * Gets the ageOfOldestTrade value for this OtherKeyIndType.
     * 
     * @return ageOfOldestTrade
     */
    public java.lang.String getAgeOfOldestTrade() {
        return ageOfOldestTrade;
    }


    /**
     * Sets the ageOfOldestTrade value for this OtherKeyIndType.
     * 
     * @param ageOfOldestTrade
     */
    public void setAgeOfOldestTrade(java.lang.String ageOfOldestTrade) {
        this.ageOfOldestTrade = ageOfOldestTrade;
    }


    /**
     * Gets the numberOfOpenTrades value for this OtherKeyIndType.
     * 
     * @return numberOfOpenTrades
     */
    public java.lang.String getNumberOfOpenTrades() {
        return numberOfOpenTrades;
    }


    /**
     * Sets the numberOfOpenTrades value for this OtherKeyIndType.
     * 
     * @param numberOfOpenTrades
     */
    public void setNumberOfOpenTrades(java.lang.String numberOfOpenTrades) {
        this.numberOfOpenTrades = numberOfOpenTrades;
    }


    /**
     * Gets the allLinesEVERWritten value for this OtherKeyIndType.
     * 
     * @return allLinesEVERWritten
     */
    public java.lang.String getAllLinesEVERWritten() {
        return allLinesEVERWritten;
    }


    /**
     * Sets the allLinesEVERWritten value for this OtherKeyIndType.
     * 
     * @param allLinesEVERWritten
     */
    public void setAllLinesEVERWritten(java.lang.String allLinesEVERWritten) {
        this.allLinesEVERWritten = allLinesEVERWritten;
    }


    /**
     * Gets the allLinesEVERWrittenIn9Months value for this OtherKeyIndType.
     * 
     * @return allLinesEVERWrittenIn9Months
     */
    public java.lang.String getAllLinesEVERWrittenIn9Months() {
        return allLinesEVERWrittenIn9Months;
    }


    /**
     * Sets the allLinesEVERWrittenIn9Months value for this OtherKeyIndType.
     * 
     * @param allLinesEVERWrittenIn9Months
     */
    public void setAllLinesEVERWrittenIn9Months(java.lang.String allLinesEVERWrittenIn9Months) {
        this.allLinesEVERWrittenIn9Months = allLinesEVERWrittenIn9Months;
    }


    /**
     * Gets the allLinesEVERWrittenIn6Months value for this OtherKeyIndType.
     * 
     * @return allLinesEVERWrittenIn6Months
     */
    public java.lang.String getAllLinesEVERWrittenIn6Months() {
        return allLinesEVERWrittenIn6Months;
    }


    /**
     * Sets the allLinesEVERWrittenIn6Months value for this OtherKeyIndType.
     * 
     * @param allLinesEVERWrittenIn6Months
     */
    public void setAllLinesEVERWrittenIn6Months(java.lang.String allLinesEVERWrittenIn6Months) {
        this.allLinesEVERWrittenIn6Months = allLinesEVERWrittenIn6Months;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OtherKeyIndType)) return false;
        OtherKeyIndType other = (OtherKeyIndType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ageOfOldestTrade==null && other.getAgeOfOldestTrade()==null) || 
             (this.ageOfOldestTrade!=null &&
              this.ageOfOldestTrade.equals(other.getAgeOfOldestTrade()))) &&
            ((this.numberOfOpenTrades==null && other.getNumberOfOpenTrades()==null) || 
             (this.numberOfOpenTrades!=null &&
              this.numberOfOpenTrades.equals(other.getNumberOfOpenTrades()))) &&
            ((this.allLinesEVERWritten==null && other.getAllLinesEVERWritten()==null) || 
             (this.allLinesEVERWritten!=null &&
              this.allLinesEVERWritten.equals(other.getAllLinesEVERWritten()))) &&
            ((this.allLinesEVERWrittenIn9Months==null && other.getAllLinesEVERWrittenIn9Months()==null) || 
             (this.allLinesEVERWrittenIn9Months!=null &&
              this.allLinesEVERWrittenIn9Months.equals(other.getAllLinesEVERWrittenIn9Months()))) &&
            ((this.allLinesEVERWrittenIn6Months==null && other.getAllLinesEVERWrittenIn6Months()==null) || 
             (this.allLinesEVERWrittenIn6Months!=null &&
              this.allLinesEVERWrittenIn6Months.equals(other.getAllLinesEVERWrittenIn6Months())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAgeOfOldestTrade() != null) {
            _hashCode += getAgeOfOldestTrade().hashCode();
        }
        if (getNumberOfOpenTrades() != null) {
            _hashCode += getNumberOfOpenTrades().hashCode();
        }
        if (getAllLinesEVERWritten() != null) {
            _hashCode += getAllLinesEVERWritten().hashCode();
        }
        if (getAllLinesEVERWrittenIn9Months() != null) {
            _hashCode += getAllLinesEVERWrittenIn9Months().hashCode();
        }
        if (getAllLinesEVERWrittenIn6Months() != null) {
            _hashCode += getAllLinesEVERWrittenIn6Months().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OtherKeyIndType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OtherKeyIndType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ageOfOldestTrade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AgeOfOldestTrade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfOpenTrades");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NumberOfOpenTrades"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allLinesEVERWritten");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AllLinesEVERWritten"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allLinesEVERWrittenIn9Months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AllLinesEVERWrittenIn9Months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allLinesEVERWrittenIn6Months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AllLinesEVERWrittenIn6Months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
