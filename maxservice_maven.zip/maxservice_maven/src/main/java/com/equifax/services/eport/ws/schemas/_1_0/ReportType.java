/**
 * ReportType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class ReportType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.ErrorType[] error;

    private com.equifax.services.eport.ws.schemas._1_0.ResponseBody verifyIDResponse;

    private com.equifax.services.eport.ws.schemas._1_0.IDAndContactType IDAndContactInfo;

    private com.equifax.services.eport.ws.schemas._1_0.IncomeDetailsType[] incomeDetails;

    private com.equifax.services.eport.ws.schemas._1_0.EmployerDetailsType[] employmentInfo;

    private com.equifax.services.eport.ws.schemas._1_0.ScoreType score;

    private com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType accountSummary;

    private com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType grpBalLoansAccountSummary;

    private com.equifax.services.eport.ws.schemas._1_0.RecentActivitiesType recentActivities;

    private com.equifax.services.eport.ws.schemas._1_0.OtherKeyIndType otherKeyInd;

    private com.equifax.services.eport.ws.schemas._1_0.EnquirySummaryType enquirySummary;

    private com.equifax.services.eport.ws.schemas._1_0.EnquiryType[] enquiries;

    private com.equifax.services.eport.ws.schemas._1_0.AccountType[] accountDetails;

    private com.equifax.services.eport.ws.schemas._1_0.AccountType[] grpBalLoansAccountDetails;

    private com.equifax.services.eport.ws.schemas._1_0.GroupCreditSummaryType[] groupCreditSummary;

    private com.equifax.services.eport.ws.schemas._1_0.GlossaryInfoType glossary;

    private java.lang.String disclaimer;

    private com.equifax.services.eport.ws.schemas._1_0.ScoringElementType[] scoringElements;

    private com.equifax.services.eport.ws.schemas._1_0.DisputeDetailsType[][] consumerDispute;

    private com.equifax.services.eport.ws.schemas._1_0.TelecomResponseType telecomResponse;

    private com.equifax.services.eport.ws.schemas._1_0.PrescreenResponseType prescreenResponse;

    public ReportType() {
    }

    public ReportType(
           com.equifax.services.eport.ws.schemas._1_0.ErrorType[] error,
           com.equifax.services.eport.ws.schemas._1_0.ResponseBody verifyIDResponse,
           com.equifax.services.eport.ws.schemas._1_0.IDAndContactType IDAndContactInfo,
           com.equifax.services.eport.ws.schemas._1_0.IncomeDetailsType[] incomeDetails,
           com.equifax.services.eport.ws.schemas._1_0.EmployerDetailsType[] employmentInfo,
           com.equifax.services.eport.ws.schemas._1_0.ScoreType score,
           com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType accountSummary,
           com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType grpBalLoansAccountSummary,
           com.equifax.services.eport.ws.schemas._1_0.RecentActivitiesType recentActivities,
           com.equifax.services.eport.ws.schemas._1_0.OtherKeyIndType otherKeyInd,
           com.equifax.services.eport.ws.schemas._1_0.EnquirySummaryType enquirySummary,
           com.equifax.services.eport.ws.schemas._1_0.EnquiryType[] enquiries,
           com.equifax.services.eport.ws.schemas._1_0.AccountType[] accountDetails,
           com.equifax.services.eport.ws.schemas._1_0.AccountType[] grpBalLoansAccountDetails,
           com.equifax.services.eport.ws.schemas._1_0.GroupCreditSummaryType[] groupCreditSummary,
           com.equifax.services.eport.ws.schemas._1_0.GlossaryInfoType glossary,
           java.lang.String disclaimer,
           com.equifax.services.eport.ws.schemas._1_0.ScoringElementType[] scoringElements,
           com.equifax.services.eport.ws.schemas._1_0.DisputeDetailsType[][] consumerDispute,
           com.equifax.services.eport.ws.schemas._1_0.TelecomResponseType telecomResponse,
           com.equifax.services.eport.ws.schemas._1_0.PrescreenResponseType prescreenResponse) {
           this.error = error;
           this.verifyIDResponse = verifyIDResponse;
           this.IDAndContactInfo = IDAndContactInfo;
           this.incomeDetails = incomeDetails;
           this.employmentInfo = employmentInfo;
           this.score = score;
           this.accountSummary = accountSummary;
           this.grpBalLoansAccountSummary = grpBalLoansAccountSummary;
           this.recentActivities = recentActivities;
           this.otherKeyInd = otherKeyInd;
           this.enquirySummary = enquirySummary;
           this.enquiries = enquiries;
           this.accountDetails = accountDetails;
           this.grpBalLoansAccountDetails = grpBalLoansAccountDetails;
           this.groupCreditSummary = groupCreditSummary;
           this.glossary = glossary;
           this.disclaimer = disclaimer;
           this.scoringElements = scoringElements;
           this.consumerDispute = consumerDispute;
           this.telecomResponse = telecomResponse;
           this.prescreenResponse = prescreenResponse;
    }


    /**
     * Gets the error value for this ReportType.
     * 
     * @return error
     */
    public com.equifax.services.eport.ws.schemas._1_0.ErrorType[] getError() {
        return error;
    }


    /**
     * Sets the error value for this ReportType.
     * 
     * @param error
     */
    public void setError(com.equifax.services.eport.ws.schemas._1_0.ErrorType[] error) {
        this.error = error;
    }

    public com.equifax.services.eport.ws.schemas._1_0.ErrorType getError(int i) {
        return this.error[i];
    }

    public void setError(int i, com.equifax.services.eport.ws.schemas._1_0.ErrorType _value) {
        this.error[i] = _value;
    }


    /**
     * Gets the verifyIDResponse value for this ReportType.
     * 
     * @return verifyIDResponse
     */
    public com.equifax.services.eport.ws.schemas._1_0.ResponseBody getVerifyIDResponse() {
        return verifyIDResponse;
    }


    /**
     * Sets the verifyIDResponse value for this ReportType.
     * 
     * @param verifyIDResponse
     */
    public void setVerifyIDResponse(com.equifax.services.eport.ws.schemas._1_0.ResponseBody verifyIDResponse) {
        this.verifyIDResponse = verifyIDResponse;
    }


    /**
     * Gets the IDAndContactInfo value for this ReportType.
     * 
     * @return IDAndContactInfo
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDAndContactType getIDAndContactInfo() {
        return IDAndContactInfo;
    }


    /**
     * Sets the IDAndContactInfo value for this ReportType.
     * 
     * @param IDAndContactInfo
     */
    public void setIDAndContactInfo(com.equifax.services.eport.ws.schemas._1_0.IDAndContactType IDAndContactInfo) {
        this.IDAndContactInfo = IDAndContactInfo;
    }


    /**
     * Gets the incomeDetails value for this ReportType.
     * 
     * @return incomeDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.IncomeDetailsType[] getIncomeDetails() {
        return incomeDetails;
    }


    /**
     * Sets the incomeDetails value for this ReportType.
     * 
     * @param incomeDetails
     */
    public void setIncomeDetails(com.equifax.services.eport.ws.schemas._1_0.IncomeDetailsType[] incomeDetails) {
        this.incomeDetails = incomeDetails;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IncomeDetailsType getIncomeDetails(int i) {
        return this.incomeDetails[i];
    }

    public void setIncomeDetails(int i, com.equifax.services.eport.ws.schemas._1_0.IncomeDetailsType _value) {
        this.incomeDetails[i] = _value;
    }


    /**
     * Gets the employmentInfo value for this ReportType.
     * 
     * @return employmentInfo
     */
    public com.equifax.services.eport.ws.schemas._1_0.EmployerDetailsType[] getEmploymentInfo() {
        return employmentInfo;
    }


    /**
     * Sets the employmentInfo value for this ReportType.
     * 
     * @param employmentInfo
     */
    public void setEmploymentInfo(com.equifax.services.eport.ws.schemas._1_0.EmployerDetailsType[] employmentInfo) {
        this.employmentInfo = employmentInfo;
    }

    public com.equifax.services.eport.ws.schemas._1_0.EmployerDetailsType getEmploymentInfo(int i) {
        return this.employmentInfo[i];
    }

    public void setEmploymentInfo(int i, com.equifax.services.eport.ws.schemas._1_0.EmployerDetailsType _value) {
        this.employmentInfo[i] = _value;
    }


    /**
     * Gets the score value for this ReportType.
     * 
     * @return score
     */
    public com.equifax.services.eport.ws.schemas._1_0.ScoreType getScore() {
        return score;
    }


    /**
     * Sets the score value for this ReportType.
     * 
     * @param score
     */
    public void setScore(com.equifax.services.eport.ws.schemas._1_0.ScoreType score) {
        this.score = score;
    }


    /**
     * Gets the accountSummary value for this ReportType.
     * 
     * @return accountSummary
     */
    public com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType getAccountSummary() {
        return accountSummary;
    }


    /**
     * Sets the accountSummary value for this ReportType.
     * 
     * @param accountSummary
     */
    public void setAccountSummary(com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType accountSummary) {
        this.accountSummary = accountSummary;
    }


    /**
     * Gets the grpBalLoansAccountSummary value for this ReportType.
     * 
     * @return grpBalLoansAccountSummary
     */
    public com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType getGrpBalLoansAccountSummary() {
        return grpBalLoansAccountSummary;
    }


    /**
     * Sets the grpBalLoansAccountSummary value for this ReportType.
     * 
     * @param grpBalLoansAccountSummary
     */
    public void setGrpBalLoansAccountSummary(com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType grpBalLoansAccountSummary) {
        this.grpBalLoansAccountSummary = grpBalLoansAccountSummary;
    }


    /**
     * Gets the recentActivities value for this ReportType.
     * 
     * @return recentActivities
     */
    public com.equifax.services.eport.ws.schemas._1_0.RecentActivitiesType getRecentActivities() {
        return recentActivities;
    }


    /**
     * Sets the recentActivities value for this ReportType.
     * 
     * @param recentActivities
     */
    public void setRecentActivities(com.equifax.services.eport.ws.schemas._1_0.RecentActivitiesType recentActivities) {
        this.recentActivities = recentActivities;
    }


    /**
     * Gets the otherKeyInd value for this ReportType.
     * 
     * @return otherKeyInd
     */
    public com.equifax.services.eport.ws.schemas._1_0.OtherKeyIndType getOtherKeyInd() {
        return otherKeyInd;
    }


    /**
     * Sets the otherKeyInd value for this ReportType.
     * 
     * @param otherKeyInd
     */
    public void setOtherKeyInd(com.equifax.services.eport.ws.schemas._1_0.OtherKeyIndType otherKeyInd) {
        this.otherKeyInd = otherKeyInd;
    }


    /**
     * Gets the enquirySummary value for this ReportType.
     * 
     * @return enquirySummary
     */
    public com.equifax.services.eport.ws.schemas._1_0.EnquirySummaryType getEnquirySummary() {
        return enquirySummary;
    }


    /**
     * Sets the enquirySummary value for this ReportType.
     * 
     * @param enquirySummary
     */
    public void setEnquirySummary(com.equifax.services.eport.ws.schemas._1_0.EnquirySummaryType enquirySummary) {
        this.enquirySummary = enquirySummary;
    }


    /**
     * Gets the enquiries value for this ReportType.
     * 
     * @return enquiries
     */
    public com.equifax.services.eport.ws.schemas._1_0.EnquiryType[] getEnquiries() {
        return enquiries;
    }


    /**
     * Sets the enquiries value for this ReportType.
     * 
     * @param enquiries
     */
    public void setEnquiries(com.equifax.services.eport.ws.schemas._1_0.EnquiryType[] enquiries) {
        this.enquiries = enquiries;
    }

    public com.equifax.services.eport.ws.schemas._1_0.EnquiryType getEnquiries(int i) {
        return this.enquiries[i];
    }

    public void setEnquiries(int i, com.equifax.services.eport.ws.schemas._1_0.EnquiryType _value) {
        this.enquiries[i] = _value;
    }


    /**
     * Gets the accountDetails value for this ReportType.
     * 
     * @return accountDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountType[] getAccountDetails() {
        return accountDetails;
    }


    /**
     * Sets the accountDetails value for this ReportType.
     * 
     * @param accountDetails
     */
    public void setAccountDetails(com.equifax.services.eport.ws.schemas._1_0.AccountType[] accountDetails) {
        this.accountDetails = accountDetails;
    }


    /**
     * Gets the grpBalLoansAccountDetails value for this ReportType.
     * 
     * @return grpBalLoansAccountDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountType[] getGrpBalLoansAccountDetails() {
        return grpBalLoansAccountDetails;
    }


    /**
     * Sets the grpBalLoansAccountDetails value for this ReportType.
     * 
     * @param grpBalLoansAccountDetails
     */
    public void setGrpBalLoansAccountDetails(com.equifax.services.eport.ws.schemas._1_0.AccountType[] grpBalLoansAccountDetails) {
        this.grpBalLoansAccountDetails = grpBalLoansAccountDetails;
    }


    /**
     * Gets the groupCreditSummary value for this ReportType.
     * 
     * @return groupCreditSummary
     */
    public com.equifax.services.eport.ws.schemas._1_0.GroupCreditSummaryType[] getGroupCreditSummary() {
        return groupCreditSummary;
    }


    /**
     * Sets the groupCreditSummary value for this ReportType.
     * 
     * @param groupCreditSummary
     */
    public void setGroupCreditSummary(com.equifax.services.eport.ws.schemas._1_0.GroupCreditSummaryType[] groupCreditSummary) {
        this.groupCreditSummary = groupCreditSummary;
    }

    public com.equifax.services.eport.ws.schemas._1_0.GroupCreditSummaryType getGroupCreditSummary(int i) {
        return this.groupCreditSummary[i];
    }

    public void setGroupCreditSummary(int i, com.equifax.services.eport.ws.schemas._1_0.GroupCreditSummaryType _value) {
        this.groupCreditSummary[i] = _value;
    }


    /**
     * Gets the glossary value for this ReportType.
     * 
     * @return glossary
     */
    public com.equifax.services.eport.ws.schemas._1_0.GlossaryInfoType getGlossary() {
        return glossary;
    }


    /**
     * Sets the glossary value for this ReportType.
     * 
     * @param glossary
     */
    public void setGlossary(com.equifax.services.eport.ws.schemas._1_0.GlossaryInfoType glossary) {
        this.glossary = glossary;
    }


    /**
     * Gets the disclaimer value for this ReportType.
     * 
     * @return disclaimer
     */
    public java.lang.String getDisclaimer() {
        return disclaimer;
    }


    /**
     * Sets the disclaimer value for this ReportType.
     * 
     * @param disclaimer
     */
    public void setDisclaimer(java.lang.String disclaimer) {
        this.disclaimer = disclaimer;
    }


    /**
     * Gets the scoringElements value for this ReportType.
     * 
     * @return scoringElements
     */
    public com.equifax.services.eport.ws.schemas._1_0.ScoringElementType[] getScoringElements() {
        return scoringElements;
    }


    /**
     * Sets the scoringElements value for this ReportType.
     * 
     * @param scoringElements
     */
    public void setScoringElements(com.equifax.services.eport.ws.schemas._1_0.ScoringElementType[] scoringElements) {
        this.scoringElements = scoringElements;
    }


    /**
     * Gets the consumerDispute value for this ReportType.
     * 
     * @return consumerDispute
     */
    public com.equifax.services.eport.ws.schemas._1_0.DisputeDetailsType[][] getConsumerDispute() {
        return consumerDispute;
    }


    /**
     * Sets the consumerDispute value for this ReportType.
     * 
     * @param consumerDispute
     */
    public void setConsumerDispute(com.equifax.services.eport.ws.schemas._1_0.DisputeDetailsType[][] consumerDispute) {
        this.consumerDispute = consumerDispute;
    }


    /**
     * Gets the telecomResponse value for this ReportType.
     * 
     * @return telecomResponse
     */
    public com.equifax.services.eport.ws.schemas._1_0.TelecomResponseType getTelecomResponse() {
        return telecomResponse;
    }


    /**
     * Sets the telecomResponse value for this ReportType.
     * 
     * @param telecomResponse
     */
    public void setTelecomResponse(com.equifax.services.eport.ws.schemas._1_0.TelecomResponseType telecomResponse) {
        this.telecomResponse = telecomResponse;
    }


    /**
     * Gets the prescreenResponse value for this ReportType.
     * 
     * @return prescreenResponse
     */
    public com.equifax.services.eport.ws.schemas._1_0.PrescreenResponseType getPrescreenResponse() {
        return prescreenResponse;
    }


    /**
     * Sets the prescreenResponse value for this ReportType.
     * 
     * @param prescreenResponse
     */
    public void setPrescreenResponse(com.equifax.services.eport.ws.schemas._1_0.PrescreenResponseType prescreenResponse) {
        this.prescreenResponse = prescreenResponse;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ReportType)) return false;
        ReportType other = (ReportType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.error==null && other.getError()==null) || 
             (this.error!=null &&
              java.util.Arrays.equals(this.error, other.getError()))) &&
            ((this.verifyIDResponse==null && other.getVerifyIDResponse()==null) || 
             (this.verifyIDResponse!=null &&
              this.verifyIDResponse.equals(other.getVerifyIDResponse()))) &&
            ((this.IDAndContactInfo==null && other.getIDAndContactInfo()==null) || 
             (this.IDAndContactInfo!=null &&
              this.IDAndContactInfo.equals(other.getIDAndContactInfo()))) &&
            ((this.incomeDetails==null && other.getIncomeDetails()==null) || 
             (this.incomeDetails!=null &&
              java.util.Arrays.equals(this.incomeDetails, other.getIncomeDetails()))) &&
            ((this.employmentInfo==null && other.getEmploymentInfo()==null) || 
             (this.employmentInfo!=null &&
              java.util.Arrays.equals(this.employmentInfo, other.getEmploymentInfo()))) &&
            ((this.score==null && other.getScore()==null) || 
             (this.score!=null &&
              this.score.equals(other.getScore()))) &&
            ((this.accountSummary==null && other.getAccountSummary()==null) || 
             (this.accountSummary!=null &&
              this.accountSummary.equals(other.getAccountSummary()))) &&
            ((this.grpBalLoansAccountSummary==null && other.getGrpBalLoansAccountSummary()==null) || 
             (this.grpBalLoansAccountSummary!=null &&
              this.grpBalLoansAccountSummary.equals(other.getGrpBalLoansAccountSummary()))) &&
            ((this.recentActivities==null && other.getRecentActivities()==null) || 
             (this.recentActivities!=null &&
              this.recentActivities.equals(other.getRecentActivities()))) &&
            ((this.otherKeyInd==null && other.getOtherKeyInd()==null) || 
             (this.otherKeyInd!=null &&
              this.otherKeyInd.equals(other.getOtherKeyInd()))) &&
            ((this.enquirySummary==null && other.getEnquirySummary()==null) || 
             (this.enquirySummary!=null &&
              this.enquirySummary.equals(other.getEnquirySummary()))) &&
            ((this.enquiries==null && other.getEnquiries()==null) || 
             (this.enquiries!=null &&
              java.util.Arrays.equals(this.enquiries, other.getEnquiries()))) &&
            ((this.accountDetails==null && other.getAccountDetails()==null) || 
             (this.accountDetails!=null &&
              java.util.Arrays.equals(this.accountDetails, other.getAccountDetails()))) &&
            ((this.grpBalLoansAccountDetails==null && other.getGrpBalLoansAccountDetails()==null) || 
             (this.grpBalLoansAccountDetails!=null &&
              java.util.Arrays.equals(this.grpBalLoansAccountDetails, other.getGrpBalLoansAccountDetails()))) &&
            ((this.groupCreditSummary==null && other.getGroupCreditSummary()==null) || 
             (this.groupCreditSummary!=null &&
              java.util.Arrays.equals(this.groupCreditSummary, other.getGroupCreditSummary()))) &&
            ((this.glossary==null && other.getGlossary()==null) || 
             (this.glossary!=null &&
              this.glossary.equals(other.getGlossary()))) &&
            ((this.disclaimer==null && other.getDisclaimer()==null) || 
             (this.disclaimer!=null &&
              this.disclaimer.equals(other.getDisclaimer()))) &&
            ((this.scoringElements==null && other.getScoringElements()==null) || 
             (this.scoringElements!=null &&
              java.util.Arrays.equals(this.scoringElements, other.getScoringElements()))) &&
            ((this.consumerDispute==null && other.getConsumerDispute()==null) || 
             (this.consumerDispute!=null &&
              java.util.Arrays.equals(this.consumerDispute, other.getConsumerDispute()))) &&
            ((this.telecomResponse==null && other.getTelecomResponse()==null) || 
             (this.telecomResponse!=null &&
              this.telecomResponse.equals(other.getTelecomResponse()))) &&
            ((this.prescreenResponse==null && other.getPrescreenResponse()==null) || 
             (this.prescreenResponse!=null &&
              this.prescreenResponse.equals(other.getPrescreenResponse())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getError() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getError());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getError(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getVerifyIDResponse() != null) {
            _hashCode += getVerifyIDResponse().hashCode();
        }
        if (getIDAndContactInfo() != null) {
            _hashCode += getIDAndContactInfo().hashCode();
        }
        if (getIncomeDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIncomeDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIncomeDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEmploymentInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEmploymentInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEmploymentInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getScore() != null) {
            _hashCode += getScore().hashCode();
        }
        if (getAccountSummary() != null) {
            _hashCode += getAccountSummary().hashCode();
        }
        if (getGrpBalLoansAccountSummary() != null) {
            _hashCode += getGrpBalLoansAccountSummary().hashCode();
        }
        if (getRecentActivities() != null) {
            _hashCode += getRecentActivities().hashCode();
        }
        if (getOtherKeyInd() != null) {
            _hashCode += getOtherKeyInd().hashCode();
        }
        if (getEnquirySummary() != null) {
            _hashCode += getEnquirySummary().hashCode();
        }
        if (getEnquiries() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEnquiries());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEnquiries(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAccountDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAccountDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAccountDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGrpBalLoansAccountDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGrpBalLoansAccountDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGrpBalLoansAccountDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGroupCreditSummary() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGroupCreditSummary());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGroupCreditSummary(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGlossary() != null) {
            _hashCode += getGlossary().hashCode();
        }
        if (getDisclaimer() != null) {
            _hashCode += getDisclaimer().hashCode();
        }
        if (getScoringElements() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getScoringElements());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getScoringElements(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getConsumerDispute() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getConsumerDispute());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getConsumerDispute(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTelecomResponse() != null) {
            _hashCode += getTelecomResponse().hashCode();
        }
        if (getPrescreenResponse() != null) {
            _hashCode += getPrescreenResponse().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ReportType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ReportType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("error");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Error"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ErrorType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verifyIDResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "VerifyIDResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "responseBody"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDAndContactInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDAndContactInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDAndContactType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("incomeDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IncomeDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IncomeDetailsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("employmentInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EmploymentInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EmployerDetailsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("score");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Score"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoreType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CreditReportSummaryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grpBalLoansAccountSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GrpBalLoansAccountSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CreditReportSummaryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recentActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RecentActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RecentActivitiesType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("otherKeyInd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OtherKeyInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OtherKeyIndType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enquirySummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EnquirySummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EnquirySummaryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enquiries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Enquiries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EnquiryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Account"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grpBalLoansAccountDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GrpBalLoansAccountDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Account"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupCreditSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GroupCreditSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GroupCreditSummaryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("glossary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Glossary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GlossaryInfoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("disclaimer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Disclaimer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scoringElements");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoringElements"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoringElementType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoringElement"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("consumerDispute");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ConsumerDispute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">ConsumerDisputesType>Dispute"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Dispute"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telecomResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TelecomResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TelecomResponseType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prescreenResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PrescreenResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PrescreenResponseType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
