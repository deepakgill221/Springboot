/**
 * IDType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class IDType  implements java.io.Serializable {
    private java.lang.String idNumber;

    private int seq;  // attribute

    private java.util.Date reportedDate;  // attribute

    public IDType() {
    }

    public IDType(
           java.lang.String idNumber,
           int seq,
           java.util.Date reportedDate) {
           this.idNumber = idNumber;
           this.seq = seq;
           this.reportedDate = reportedDate;
    }


    /**
     * Gets the idNumber value for this IDType.
     * 
     * @return idNumber
     */
    public java.lang.String getIdNumber() {
        return idNumber;
    }


    /**
     * Sets the idNumber value for this IDType.
     * 
     * @param idNumber
     */
    public void setIdNumber(java.lang.String idNumber) {
        this.idNumber = idNumber;
    }


    /**
     * Gets the seq value for this IDType.
     * 
     * @return seq
     */
    public int getSeq() {
        return seq;
    }


    /**
     * Sets the seq value for this IDType.
     * 
     * @param seq
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }


    /**
     * Gets the reportedDate value for this IDType.
     * 
     * @return reportedDate
     */
    public java.util.Date getReportedDate() {
        return reportedDate;
    }


    /**
     * Sets the reportedDate value for this IDType.
     * 
     * @param reportedDate
     */
    public void setReportedDate(java.util.Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IDType)) return false;
        IDType other = (IDType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idNumber==null && other.getIdNumber()==null) || 
             (this.idNumber!=null &&
              this.idNumber.equals(other.getIdNumber()))) &&
            this.seq == other.getSeq() &&
            ((this.reportedDate==null && other.getReportedDate()==null) || 
             (this.reportedDate!=null &&
              this.reportedDate.equals(other.getReportedDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdNumber() != null) {
            _hashCode += getIdNumber().hashCode();
        }
        _hashCode += getSeq();
        if (getReportedDate() != null) {
            _hashCode += getReportedDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IDType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("seq");
        attrField.setXmlName(new javax.xml.namespace.QName("", "seq"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("reportedDate");
        attrField.setXmlName(new javax.xml.namespace.QName("", "ReportedDate"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IdNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
