/**
 * VidUidaiResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class VidUidaiResponse  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.UidaiRequest uidaiRequest;

    private com.equifax.services.eport.ws.schemas._1_0.UidaiResponse uidaiResponse;

    public VidUidaiResponse() {
    }

    public VidUidaiResponse(
           com.equifax.services.eport.ws.schemas._1_0.UidaiRequest uidaiRequest,
           com.equifax.services.eport.ws.schemas._1_0.UidaiResponse uidaiResponse) {
           this.uidaiRequest = uidaiRequest;
           this.uidaiResponse = uidaiResponse;
    }


    /**
     * Gets the uidaiRequest value for this VidUidaiResponse.
     * 
     * @return uidaiRequest
     */
    public com.equifax.services.eport.ws.schemas._1_0.UidaiRequest getUidaiRequest() {
        return uidaiRequest;
    }


    /**
     * Sets the uidaiRequest value for this VidUidaiResponse.
     * 
     * @param uidaiRequest
     */
    public void setUidaiRequest(com.equifax.services.eport.ws.schemas._1_0.UidaiRequest uidaiRequest) {
        this.uidaiRequest = uidaiRequest;
    }


    /**
     * Gets the uidaiResponse value for this VidUidaiResponse.
     * 
     * @return uidaiResponse
     */
    public com.equifax.services.eport.ws.schemas._1_0.UidaiResponse getUidaiResponse() {
        return uidaiResponse;
    }


    /**
     * Sets the uidaiResponse value for this VidUidaiResponse.
     * 
     * @param uidaiResponse
     */
    public void setUidaiResponse(com.equifax.services.eport.ws.schemas._1_0.UidaiResponse uidaiResponse) {
        this.uidaiResponse = uidaiResponse;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VidUidaiResponse)) return false;
        VidUidaiResponse other = (VidUidaiResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.uidaiRequest==null && other.getUidaiRequest()==null) || 
             (this.uidaiRequest!=null &&
              this.uidaiRequest.equals(other.getUidaiRequest()))) &&
            ((this.uidaiResponse==null && other.getUidaiResponse()==null) || 
             (this.uidaiResponse!=null &&
              this.uidaiResponse.equals(other.getUidaiResponse())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUidaiRequest() != null) {
            _hashCode += getUidaiRequest().hashCode();
        }
        if (getUidaiResponse() != null) {
            _hashCode += getUidaiResponse().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VidUidaiResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidUidaiResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uidaiRequest");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "uidaiRequest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "uidaiRequest"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uidaiResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "uidaiResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "uidaiResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
