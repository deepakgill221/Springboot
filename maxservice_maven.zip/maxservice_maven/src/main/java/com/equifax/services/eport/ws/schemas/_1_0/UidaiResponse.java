/**
 * UidaiResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class UidaiResponse  extends com.equifax.services.eport.ws.schemas._1_0.Response  implements java.io.Serializable {
    private java.lang.String uidaiResponse;

    private java.lang.String nameResponse;

    public UidaiResponse() {
    }

    public UidaiResponse(
           java.lang.String returnCode,
           java.lang.String returnCodeDesc,
           java.util.Calendar runDateTime,
           java.lang.String errorRespMessage,
           java.lang.String uidaiResponse,
           java.lang.String nameResponse) {
        super(
            returnCode,
            returnCodeDesc,
            runDateTime,
            errorRespMessage);
        this.uidaiResponse = uidaiResponse;
        this.nameResponse = nameResponse;
    }


    /**
     * Gets the uidaiResponse value for this UidaiResponse.
     * 
     * @return uidaiResponse
     */
    public java.lang.String getUidaiResponse() {
        return uidaiResponse;
    }


    /**
     * Sets the uidaiResponse value for this UidaiResponse.
     * 
     * @param uidaiResponse
     */
    public void setUidaiResponse(java.lang.String uidaiResponse) {
        this.uidaiResponse = uidaiResponse;
    }


    /**
     * Gets the nameResponse value for this UidaiResponse.
     * 
     * @return nameResponse
     */
    public java.lang.String getNameResponse() {
        return nameResponse;
    }


    /**
     * Sets the nameResponse value for this UidaiResponse.
     * 
     * @param nameResponse
     */
    public void setNameResponse(java.lang.String nameResponse) {
        this.nameResponse = nameResponse;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UidaiResponse)) return false;
        UidaiResponse other = (UidaiResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.uidaiResponse==null && other.getUidaiResponse()==null) || 
             (this.uidaiResponse!=null &&
              this.uidaiResponse.equals(other.getUidaiResponse()))) &&
            ((this.nameResponse==null && other.getNameResponse()==null) || 
             (this.nameResponse!=null &&
              this.nameResponse.equals(other.getNameResponse())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getUidaiResponse() != null) {
            _hashCode += getUidaiResponse().hashCode();
        }
        if (getNameResponse() != null) {
            _hashCode += getNameResponse().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UidaiResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "uidaiResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uidaiResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "uidaiResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "nameResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
