/**
 * CreditReportWSInquiryBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.servicedefs._1_0;

public class CreditReportWSInquiryBindingStub extends org.apache.axis.client.Stub implements com.equifax.services.eport.servicedefs._1_0.CreditReportWSInquiryPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[1];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConsumerCreditReport");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryRequestType"), com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryResponseType"));
        oper.setReturnClass(com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

    }

    public CreditReportWSInquiryBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public CreditReportWSInquiryBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public CreditReportWSInquiryBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">AdditionalNameTypeDetails>AdditionalName");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">ConsumerDisputesType>Dispute");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.DisputeDetailsType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DisputeDetailsType");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DisputeDetails");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">InquiryAddressType>AddressLine");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">InquiryAddressType>City");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">InquiryAddressType>Locality1");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">InquiryAddressType>Locality2");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">InquiryAddressType>Postal");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">InquiryAddressType>Street");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">MobilePhone");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">PANId");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">PassportId");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>AdditionalId1");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>AdditionalId2");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>AddrLine1");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>City");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>DriverLicense");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>FirstName");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>FullName");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>InquiryFieldsDsv");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>LastName");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>Locality1");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>Locality2");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>MiddleName");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>NationalIdCard");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>Postal");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>RationCard");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestBodyType>Street");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">RequestHeaderType>CustomInquiryFlag");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">VoterId");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountDetailsType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AccountType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountType");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Account");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountHistoryType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MonthlyDetailType");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Month");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountInputType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AccountInputType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountStatusType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AccountStatusType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AccountType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalMFIDetailsType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AdditionalMFIDetailsType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalNameTypeDetails");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AdditionalNameTypeDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalNameValType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AdditionalNameValType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AddressCodeType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AddressCodeType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AddressType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AddressType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AgeInfo");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AgeInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AliasNameInfoType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AliasNameInfoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ConsumerDisputesType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.DisputeDetailsType[][].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">ConsumerDisputesType>Dispute");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Dispute");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CreditReportSummaryType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.CreditReportSummaryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DisputeDetailsType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.DisputeDetailsType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EmailAddressType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.EmailAddressType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EmployerDetailsType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.EmployerDetailsType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EnquirySummaryType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.EnquirySummaryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EnquiryType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.EnquiryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ErrorType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.ErrorType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "FamilyInfo");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.FamilyInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GenderOptions");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.GenderOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GenderTypeCode");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.GenderTypeCode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GlossaryInfoType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.GlossaryInfoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GroupCreditSummaryType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.GroupCreditSummaryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDAndContactType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.IDAndContactType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IdentificationType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.IdentificationType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.IDType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IncomeDetailsType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.IncomeDetailsType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAddressType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.InquiryAddressType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryCommonAccountDetailsType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.AccountInputType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountInputType");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAccount");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryCommonInputAddressType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.InquiryAddressType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAddressType");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAddress");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryCommonInputPhoneType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.InquiryPhoneType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPhoneType");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPhone");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPhoneType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.InquiryPhoneType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPurposeOptions");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryRequestType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryResponseHeaderType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.InquiryResponseHeaderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryResponseType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LandlineType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.LandlineType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MaritalStatusOptions");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAdditionalAddressType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.MFIAddlAdrsDetailsType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAddlAdrsDetailsType");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalAddressDetails");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAdditionalIdentityInfoType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.MFIAdditionalIdentityInfoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAddlAdrsDetailsType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.MFIAddlAdrsDetailsType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MonthlyDetailType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NameType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.NameType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "nsdlRequest");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.NsdlRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "nsdlResponse");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.NsdlResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OtherKeyIndType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.OtherKeyIndType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PersonalInfoType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.PersonalInfoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PhoneType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.PhoneType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PhoneTypeCode");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.PhoneTypeCode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PlaceOfBirthInfoType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.PlaceOfBirthInfoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RecentActivitiesType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.RecentActivitiesType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RelationInfoType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.RelationInfoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ReportFormatOptions");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ReportType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.ReportType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "request");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestBodyType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.RequestBodyType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestHeaderType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "response");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "responseBody");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.ResponseBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoreType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.ScoreType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoringElementsType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.ScoringElementType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoringElementType");
            qName2 = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoringElement");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ScoringElementType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.ScoringElementType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "StateCodeOptions");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.StateCodeOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TelecomResponseType");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.TelecomResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "uidaiRequest");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.UidaiRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "uidaiResponse");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.UidaiResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidNsdlResponse");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.VidNsdlResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidUidaiResponse");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.VidUidaiResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidVoterResponse");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.VidVoterResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "voterRequest");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.VoterRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "voterResponse");
            cachedSerQNames.add(qName);
            cls = com.equifax.services.eport.ws.schemas._1_0.VoterResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType getConsumerCreditReport(com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType input) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.equifax.com/CreditReportWS/CreditReportWSInquiry/1.0");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.equifax.com/eport/servicedefs/1.0", "getConsumerCreditReport"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {input});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
