/**
 * PIIDataType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class PIIDataType  implements java.io.Serializable {
    private java.lang.String firstName;

    private java.lang.String middleName;

    private java.lang.String lastName;

    private com.equifax.services.eport.ws.schemas._1_0.AddressType[] addresses;

    private com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phones;

    private java.lang.String panCard;

    private java.lang.String passportId;

    private java.lang.String voterId;

    private java.lang.String drivingLicense;

    private java.lang.String nationalIdCard;

    private java.lang.String rationCard;

    private java.lang.String otherId;

    private java.lang.String DOB;

    private java.lang.String gender;

    public PIIDataType() {
    }

    public PIIDataType(
           java.lang.String firstName,
           java.lang.String middleName,
           java.lang.String lastName,
           com.equifax.services.eport.ws.schemas._1_0.AddressType[] addresses,
           com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phones,
           java.lang.String panCard,
           java.lang.String passportId,
           java.lang.String voterId,
           java.lang.String drivingLicense,
           java.lang.String nationalIdCard,
           java.lang.String rationCard,
           java.lang.String otherId,
           java.lang.String DOB,
           java.lang.String gender) {
           this.firstName = firstName;
           this.middleName = middleName;
           this.lastName = lastName;
           this.addresses = addresses;
           this.phones = phones;
           this.panCard = panCard;
           this.passportId = passportId;
           this.voterId = voterId;
           this.drivingLicense = drivingLicense;
           this.nationalIdCard = nationalIdCard;
           this.rationCard = rationCard;
           this.otherId = otherId;
           this.DOB = DOB;
           this.gender = gender;
    }


    /**
     * Gets the firstName value for this PIIDataType.
     * 
     * @return firstName
     */
    public java.lang.String getFirstName() {
        return firstName;
    }


    /**
     * Sets the firstName value for this PIIDataType.
     * 
     * @param firstName
     */
    public void setFirstName(java.lang.String firstName) {
        this.firstName = firstName;
    }


    /**
     * Gets the middleName value for this PIIDataType.
     * 
     * @return middleName
     */
    public java.lang.String getMiddleName() {
        return middleName;
    }


    /**
     * Sets the middleName value for this PIIDataType.
     * 
     * @param middleName
     */
    public void setMiddleName(java.lang.String middleName) {
        this.middleName = middleName;
    }


    /**
     * Gets the lastName value for this PIIDataType.
     * 
     * @return lastName
     */
    public java.lang.String getLastName() {
        return lastName;
    }


    /**
     * Sets the lastName value for this PIIDataType.
     * 
     * @param lastName
     */
    public void setLastName(java.lang.String lastName) {
        this.lastName = lastName;
    }


    /**
     * Gets the addresses value for this PIIDataType.
     * 
     * @return addresses
     */
    public com.equifax.services.eport.ws.schemas._1_0.AddressType[] getAddresses() {
        return addresses;
    }


    /**
     * Sets the addresses value for this PIIDataType.
     * 
     * @param addresses
     */
    public void setAddresses(com.equifax.services.eport.ws.schemas._1_0.AddressType[] addresses) {
        this.addresses = addresses;
    }


    /**
     * Gets the phones value for this PIIDataType.
     * 
     * @return phones
     */
    public com.equifax.services.eport.ws.schemas._1_0.PhoneType[] getPhones() {
        return phones;
    }


    /**
     * Sets the phones value for this PIIDataType.
     * 
     * @param phones
     */
    public void setPhones(com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phones) {
        this.phones = phones;
    }


    /**
     * Gets the panCard value for this PIIDataType.
     * 
     * @return panCard
     */
    public java.lang.String getPanCard() {
        return panCard;
    }


    /**
     * Sets the panCard value for this PIIDataType.
     * 
     * @param panCard
     */
    public void setPanCard(java.lang.String panCard) {
        this.panCard = panCard;
    }


    /**
     * Gets the passportId value for this PIIDataType.
     * 
     * @return passportId
     */
    public java.lang.String getPassportId() {
        return passportId;
    }


    /**
     * Sets the passportId value for this PIIDataType.
     * 
     * @param passportId
     */
    public void setPassportId(java.lang.String passportId) {
        this.passportId = passportId;
    }


    /**
     * Gets the voterId value for this PIIDataType.
     * 
     * @return voterId
     */
    public java.lang.String getVoterId() {
        return voterId;
    }


    /**
     * Sets the voterId value for this PIIDataType.
     * 
     * @param voterId
     */
    public void setVoterId(java.lang.String voterId) {
        this.voterId = voterId;
    }


    /**
     * Gets the drivingLicense value for this PIIDataType.
     * 
     * @return drivingLicense
     */
    public java.lang.String getDrivingLicense() {
        return drivingLicense;
    }


    /**
     * Sets the drivingLicense value for this PIIDataType.
     * 
     * @param drivingLicense
     */
    public void setDrivingLicense(java.lang.String drivingLicense) {
        this.drivingLicense = drivingLicense;
    }


    /**
     * Gets the nationalIdCard value for this PIIDataType.
     * 
     * @return nationalIdCard
     */
    public java.lang.String getNationalIdCard() {
        return nationalIdCard;
    }


    /**
     * Sets the nationalIdCard value for this PIIDataType.
     * 
     * @param nationalIdCard
     */
    public void setNationalIdCard(java.lang.String nationalIdCard) {
        this.nationalIdCard = nationalIdCard;
    }


    /**
     * Gets the rationCard value for this PIIDataType.
     * 
     * @return rationCard
     */
    public java.lang.String getRationCard() {
        return rationCard;
    }


    /**
     * Sets the rationCard value for this PIIDataType.
     * 
     * @param rationCard
     */
    public void setRationCard(java.lang.String rationCard) {
        this.rationCard = rationCard;
    }


    /**
     * Gets the otherId value for this PIIDataType.
     * 
     * @return otherId
     */
    public java.lang.String getOtherId() {
        return otherId;
    }


    /**
     * Sets the otherId value for this PIIDataType.
     * 
     * @param otherId
     */
    public void setOtherId(java.lang.String otherId) {
        this.otherId = otherId;
    }


    /**
     * Gets the DOB value for this PIIDataType.
     * 
     * @return DOB
     */
    public java.lang.String getDOB() {
        return DOB;
    }


    /**
     * Sets the DOB value for this PIIDataType.
     * 
     * @param DOB
     */
    public void setDOB(java.lang.String DOB) {
        this.DOB = DOB;
    }


    /**
     * Gets the gender value for this PIIDataType.
     * 
     * @return gender
     */
    public java.lang.String getGender() {
        return gender;
    }


    /**
     * Sets the gender value for this PIIDataType.
     * 
     * @param gender
     */
    public void setGender(java.lang.String gender) {
        this.gender = gender;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PIIDataType)) return false;
        PIIDataType other = (PIIDataType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.firstName==null && other.getFirstName()==null) || 
             (this.firstName!=null &&
              this.firstName.equals(other.getFirstName()))) &&
            ((this.middleName==null && other.getMiddleName()==null) || 
             (this.middleName!=null &&
              this.middleName.equals(other.getMiddleName()))) &&
            ((this.lastName==null && other.getLastName()==null) || 
             (this.lastName!=null &&
              this.lastName.equals(other.getLastName()))) &&
            ((this.addresses==null && other.getAddresses()==null) || 
             (this.addresses!=null &&
              java.util.Arrays.equals(this.addresses, other.getAddresses()))) &&
            ((this.phones==null && other.getPhones()==null) || 
             (this.phones!=null &&
              java.util.Arrays.equals(this.phones, other.getPhones()))) &&
            ((this.panCard==null && other.getPanCard()==null) || 
             (this.panCard!=null &&
              this.panCard.equals(other.getPanCard()))) &&
            ((this.passportId==null && other.getPassportId()==null) || 
             (this.passportId!=null &&
              this.passportId.equals(other.getPassportId()))) &&
            ((this.voterId==null && other.getVoterId()==null) || 
             (this.voterId!=null &&
              this.voterId.equals(other.getVoterId()))) &&
            ((this.drivingLicense==null && other.getDrivingLicense()==null) || 
             (this.drivingLicense!=null &&
              this.drivingLicense.equals(other.getDrivingLicense()))) &&
            ((this.nationalIdCard==null && other.getNationalIdCard()==null) || 
             (this.nationalIdCard!=null &&
              this.nationalIdCard.equals(other.getNationalIdCard()))) &&
            ((this.rationCard==null && other.getRationCard()==null) || 
             (this.rationCard!=null &&
              this.rationCard.equals(other.getRationCard()))) &&
            ((this.otherId==null && other.getOtherId()==null) || 
             (this.otherId!=null &&
              this.otherId.equals(other.getOtherId()))) &&
            ((this.DOB==null && other.getDOB()==null) || 
             (this.DOB!=null &&
              this.DOB.equals(other.getDOB()))) &&
            ((this.gender==null && other.getGender()==null) || 
             (this.gender!=null &&
              this.gender.equals(other.getGender())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFirstName() != null) {
            _hashCode += getFirstName().hashCode();
        }
        if (getMiddleName() != null) {
            _hashCode += getMiddleName().hashCode();
        }
        if (getLastName() != null) {
            _hashCode += getLastName().hashCode();
        }
        if (getAddresses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAddresses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAddresses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPhones() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPhones());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPhones(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPanCard() != null) {
            _hashCode += getPanCard().hashCode();
        }
        if (getPassportId() != null) {
            _hashCode += getPassportId().hashCode();
        }
        if (getVoterId() != null) {
            _hashCode += getVoterId().hashCode();
        }
        if (getDrivingLicense() != null) {
            _hashCode += getDrivingLicense().hashCode();
        }
        if (getNationalIdCard() != null) {
            _hashCode += getNationalIdCard().hashCode();
        }
        if (getRationCard() != null) {
            _hashCode += getRationCard().hashCode();
        }
        if (getOtherId() != null) {
            _hashCode += getOtherId().hashCode();
        }
        if (getDOB() != null) {
            _hashCode += getDOB().hashCode();
        }
        if (getGender() != null) {
            _hashCode += getGender().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PIIDataType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PIIDataType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "FirstName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("middleName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MiddleName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LastName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addresses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Addresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AddressType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AddressInfo"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phones");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Phones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PhoneType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Phone"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("panCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PanCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passportId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PassportId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voterId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "VoterId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("drivingLicense");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DrivingLicense"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nationalIdCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NationalIdCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rationCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RationCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("otherId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OtherId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOB");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DOB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gender");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Gender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
