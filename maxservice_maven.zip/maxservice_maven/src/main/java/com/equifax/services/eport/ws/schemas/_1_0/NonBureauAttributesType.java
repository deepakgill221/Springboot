/**
 * NonBureauAttributesType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class NonBureauAttributesType  implements java.io.Serializable {
    private java.lang.String attribute1;

    private java.lang.String attribute2;

    private java.lang.String attribute3;

    private java.lang.String attribute4;

    private java.lang.String attribute5;

    private java.lang.String attribute6;

    private java.lang.String attribute7;

    private java.lang.String attribute8;

    private java.lang.String attribute9;

    private java.lang.String attribute10;

    private java.lang.String attribute11;

    private java.lang.String attribute12;

    private java.lang.String attribute13;

    private java.lang.String attribute14;

    private java.lang.String attribute15;

    private java.lang.String attribute16;

    private java.lang.String attribute17;

    private java.lang.String attribute18;

    private java.lang.String attribute19;

    private java.lang.String attribute20;

    private java.lang.String attribute21;

    private java.lang.String attribute22;

    private java.lang.String attribute23;

    private java.lang.String attribute24;

    private java.lang.String attribute25;

    private java.lang.String attribute26;

    private java.lang.String attribute27;

    private java.lang.String attribute28;

    private java.lang.String attribute29;

    private java.lang.String attribute30;

    private java.lang.String attribute31;

    private java.lang.String attribute32;

    private java.lang.String attribute33;

    private java.lang.String attribute34;

    private java.lang.String attribute35;

    private java.lang.String attribute36;

    private java.lang.String attribute37;

    private java.lang.String attribute38;

    private java.lang.String attribute39;

    private java.lang.String attribute40;

    public NonBureauAttributesType() {
    }

    public NonBureauAttributesType(
           java.lang.String attribute1,
           java.lang.String attribute2,
           java.lang.String attribute3,
           java.lang.String attribute4,
           java.lang.String attribute5,
           java.lang.String attribute6,
           java.lang.String attribute7,
           java.lang.String attribute8,
           java.lang.String attribute9,
           java.lang.String attribute10,
           java.lang.String attribute11,
           java.lang.String attribute12,
           java.lang.String attribute13,
           java.lang.String attribute14,
           java.lang.String attribute15,
           java.lang.String attribute16,
           java.lang.String attribute17,
           java.lang.String attribute18,
           java.lang.String attribute19,
           java.lang.String attribute20,
           java.lang.String attribute21,
           java.lang.String attribute22,
           java.lang.String attribute23,
           java.lang.String attribute24,
           java.lang.String attribute25,
           java.lang.String attribute26,
           java.lang.String attribute27,
           java.lang.String attribute28,
           java.lang.String attribute29,
           java.lang.String attribute30,
           java.lang.String attribute31,
           java.lang.String attribute32,
           java.lang.String attribute33,
           java.lang.String attribute34,
           java.lang.String attribute35,
           java.lang.String attribute36,
           java.lang.String attribute37,
           java.lang.String attribute38,
           java.lang.String attribute39,
           java.lang.String attribute40) {
           this.attribute1 = attribute1;
           this.attribute2 = attribute2;
           this.attribute3 = attribute3;
           this.attribute4 = attribute4;
           this.attribute5 = attribute5;
           this.attribute6 = attribute6;
           this.attribute7 = attribute7;
           this.attribute8 = attribute8;
           this.attribute9 = attribute9;
           this.attribute10 = attribute10;
           this.attribute11 = attribute11;
           this.attribute12 = attribute12;
           this.attribute13 = attribute13;
           this.attribute14 = attribute14;
           this.attribute15 = attribute15;
           this.attribute16 = attribute16;
           this.attribute17 = attribute17;
           this.attribute18 = attribute18;
           this.attribute19 = attribute19;
           this.attribute20 = attribute20;
           this.attribute21 = attribute21;
           this.attribute22 = attribute22;
           this.attribute23 = attribute23;
           this.attribute24 = attribute24;
           this.attribute25 = attribute25;
           this.attribute26 = attribute26;
           this.attribute27 = attribute27;
           this.attribute28 = attribute28;
           this.attribute29 = attribute29;
           this.attribute30 = attribute30;
           this.attribute31 = attribute31;
           this.attribute32 = attribute32;
           this.attribute33 = attribute33;
           this.attribute34 = attribute34;
           this.attribute35 = attribute35;
           this.attribute36 = attribute36;
           this.attribute37 = attribute37;
           this.attribute38 = attribute38;
           this.attribute39 = attribute39;
           this.attribute40 = attribute40;
    }


    /**
     * Gets the attribute1 value for this NonBureauAttributesType.
     * 
     * @return attribute1
     */
    public java.lang.String getAttribute1() {
        return attribute1;
    }


    /**
     * Sets the attribute1 value for this NonBureauAttributesType.
     * 
     * @param attribute1
     */
    public void setAttribute1(java.lang.String attribute1) {
        this.attribute1 = attribute1;
    }


    /**
     * Gets the attribute2 value for this NonBureauAttributesType.
     * 
     * @return attribute2
     */
    public java.lang.String getAttribute2() {
        return attribute2;
    }


    /**
     * Sets the attribute2 value for this NonBureauAttributesType.
     * 
     * @param attribute2
     */
    public void setAttribute2(java.lang.String attribute2) {
        this.attribute2 = attribute2;
    }


    /**
     * Gets the attribute3 value for this NonBureauAttributesType.
     * 
     * @return attribute3
     */
    public java.lang.String getAttribute3() {
        return attribute3;
    }


    /**
     * Sets the attribute3 value for this NonBureauAttributesType.
     * 
     * @param attribute3
     */
    public void setAttribute3(java.lang.String attribute3) {
        this.attribute3 = attribute3;
    }


    /**
     * Gets the attribute4 value for this NonBureauAttributesType.
     * 
     * @return attribute4
     */
    public java.lang.String getAttribute4() {
        return attribute4;
    }


    /**
     * Sets the attribute4 value for this NonBureauAttributesType.
     * 
     * @param attribute4
     */
    public void setAttribute4(java.lang.String attribute4) {
        this.attribute4 = attribute4;
    }


    /**
     * Gets the attribute5 value for this NonBureauAttributesType.
     * 
     * @return attribute5
     */
    public java.lang.String getAttribute5() {
        return attribute5;
    }


    /**
     * Sets the attribute5 value for this NonBureauAttributesType.
     * 
     * @param attribute5
     */
    public void setAttribute5(java.lang.String attribute5) {
        this.attribute5 = attribute5;
    }


    /**
     * Gets the attribute6 value for this NonBureauAttributesType.
     * 
     * @return attribute6
     */
    public java.lang.String getAttribute6() {
        return attribute6;
    }


    /**
     * Sets the attribute6 value for this NonBureauAttributesType.
     * 
     * @param attribute6
     */
    public void setAttribute6(java.lang.String attribute6) {
        this.attribute6 = attribute6;
    }


    /**
     * Gets the attribute7 value for this NonBureauAttributesType.
     * 
     * @return attribute7
     */
    public java.lang.String getAttribute7() {
        return attribute7;
    }


    /**
     * Sets the attribute7 value for this NonBureauAttributesType.
     * 
     * @param attribute7
     */
    public void setAttribute7(java.lang.String attribute7) {
        this.attribute7 = attribute7;
    }


    /**
     * Gets the attribute8 value for this NonBureauAttributesType.
     * 
     * @return attribute8
     */
    public java.lang.String getAttribute8() {
        return attribute8;
    }


    /**
     * Sets the attribute8 value for this NonBureauAttributesType.
     * 
     * @param attribute8
     */
    public void setAttribute8(java.lang.String attribute8) {
        this.attribute8 = attribute8;
    }


    /**
     * Gets the attribute9 value for this NonBureauAttributesType.
     * 
     * @return attribute9
     */
    public java.lang.String getAttribute9() {
        return attribute9;
    }


    /**
     * Sets the attribute9 value for this NonBureauAttributesType.
     * 
     * @param attribute9
     */
    public void setAttribute9(java.lang.String attribute9) {
        this.attribute9 = attribute9;
    }


    /**
     * Gets the attribute10 value for this NonBureauAttributesType.
     * 
     * @return attribute10
     */
    public java.lang.String getAttribute10() {
        return attribute10;
    }


    /**
     * Sets the attribute10 value for this NonBureauAttributesType.
     * 
     * @param attribute10
     */
    public void setAttribute10(java.lang.String attribute10) {
        this.attribute10 = attribute10;
    }


    /**
     * Gets the attribute11 value for this NonBureauAttributesType.
     * 
     * @return attribute11
     */
    public java.lang.String getAttribute11() {
        return attribute11;
    }


    /**
     * Sets the attribute11 value for this NonBureauAttributesType.
     * 
     * @param attribute11
     */
    public void setAttribute11(java.lang.String attribute11) {
        this.attribute11 = attribute11;
    }


    /**
     * Gets the attribute12 value for this NonBureauAttributesType.
     * 
     * @return attribute12
     */
    public java.lang.String getAttribute12() {
        return attribute12;
    }


    /**
     * Sets the attribute12 value for this NonBureauAttributesType.
     * 
     * @param attribute12
     */
    public void setAttribute12(java.lang.String attribute12) {
        this.attribute12 = attribute12;
    }


    /**
     * Gets the attribute13 value for this NonBureauAttributesType.
     * 
     * @return attribute13
     */
    public java.lang.String getAttribute13() {
        return attribute13;
    }


    /**
     * Sets the attribute13 value for this NonBureauAttributesType.
     * 
     * @param attribute13
     */
    public void setAttribute13(java.lang.String attribute13) {
        this.attribute13 = attribute13;
    }


    /**
     * Gets the attribute14 value for this NonBureauAttributesType.
     * 
     * @return attribute14
     */
    public java.lang.String getAttribute14() {
        return attribute14;
    }


    /**
     * Sets the attribute14 value for this NonBureauAttributesType.
     * 
     * @param attribute14
     */
    public void setAttribute14(java.lang.String attribute14) {
        this.attribute14 = attribute14;
    }


    /**
     * Gets the attribute15 value for this NonBureauAttributesType.
     * 
     * @return attribute15
     */
    public java.lang.String getAttribute15() {
        return attribute15;
    }


    /**
     * Sets the attribute15 value for this NonBureauAttributesType.
     * 
     * @param attribute15
     */
    public void setAttribute15(java.lang.String attribute15) {
        this.attribute15 = attribute15;
    }


    /**
     * Gets the attribute16 value for this NonBureauAttributesType.
     * 
     * @return attribute16
     */
    public java.lang.String getAttribute16() {
        return attribute16;
    }


    /**
     * Sets the attribute16 value for this NonBureauAttributesType.
     * 
     * @param attribute16
     */
    public void setAttribute16(java.lang.String attribute16) {
        this.attribute16 = attribute16;
    }


    /**
     * Gets the attribute17 value for this NonBureauAttributesType.
     * 
     * @return attribute17
     */
    public java.lang.String getAttribute17() {
        return attribute17;
    }


    /**
     * Sets the attribute17 value for this NonBureauAttributesType.
     * 
     * @param attribute17
     */
    public void setAttribute17(java.lang.String attribute17) {
        this.attribute17 = attribute17;
    }


    /**
     * Gets the attribute18 value for this NonBureauAttributesType.
     * 
     * @return attribute18
     */
    public java.lang.String getAttribute18() {
        return attribute18;
    }


    /**
     * Sets the attribute18 value for this NonBureauAttributesType.
     * 
     * @param attribute18
     */
    public void setAttribute18(java.lang.String attribute18) {
        this.attribute18 = attribute18;
    }


    /**
     * Gets the attribute19 value for this NonBureauAttributesType.
     * 
     * @return attribute19
     */
    public java.lang.String getAttribute19() {
        return attribute19;
    }


    /**
     * Sets the attribute19 value for this NonBureauAttributesType.
     * 
     * @param attribute19
     */
    public void setAttribute19(java.lang.String attribute19) {
        this.attribute19 = attribute19;
    }


    /**
     * Gets the attribute20 value for this NonBureauAttributesType.
     * 
     * @return attribute20
     */
    public java.lang.String getAttribute20() {
        return attribute20;
    }


    /**
     * Sets the attribute20 value for this NonBureauAttributesType.
     * 
     * @param attribute20
     */
    public void setAttribute20(java.lang.String attribute20) {
        this.attribute20 = attribute20;
    }


    /**
     * Gets the attribute21 value for this NonBureauAttributesType.
     * 
     * @return attribute21
     */
    public java.lang.String getAttribute21() {
        return attribute21;
    }


    /**
     * Sets the attribute21 value for this NonBureauAttributesType.
     * 
     * @param attribute21
     */
    public void setAttribute21(java.lang.String attribute21) {
        this.attribute21 = attribute21;
    }


    /**
     * Gets the attribute22 value for this NonBureauAttributesType.
     * 
     * @return attribute22
     */
    public java.lang.String getAttribute22() {
        return attribute22;
    }


    /**
     * Sets the attribute22 value for this NonBureauAttributesType.
     * 
     * @param attribute22
     */
    public void setAttribute22(java.lang.String attribute22) {
        this.attribute22 = attribute22;
    }


    /**
     * Gets the attribute23 value for this NonBureauAttributesType.
     * 
     * @return attribute23
     */
    public java.lang.String getAttribute23() {
        return attribute23;
    }


    /**
     * Sets the attribute23 value for this NonBureauAttributesType.
     * 
     * @param attribute23
     */
    public void setAttribute23(java.lang.String attribute23) {
        this.attribute23 = attribute23;
    }


    /**
     * Gets the attribute24 value for this NonBureauAttributesType.
     * 
     * @return attribute24
     */
    public java.lang.String getAttribute24() {
        return attribute24;
    }


    /**
     * Sets the attribute24 value for this NonBureauAttributesType.
     * 
     * @param attribute24
     */
    public void setAttribute24(java.lang.String attribute24) {
        this.attribute24 = attribute24;
    }


    /**
     * Gets the attribute25 value for this NonBureauAttributesType.
     * 
     * @return attribute25
     */
    public java.lang.String getAttribute25() {
        return attribute25;
    }


    /**
     * Sets the attribute25 value for this NonBureauAttributesType.
     * 
     * @param attribute25
     */
    public void setAttribute25(java.lang.String attribute25) {
        this.attribute25 = attribute25;
    }


    /**
     * Gets the attribute26 value for this NonBureauAttributesType.
     * 
     * @return attribute26
     */
    public java.lang.String getAttribute26() {
        return attribute26;
    }


    /**
     * Sets the attribute26 value for this NonBureauAttributesType.
     * 
     * @param attribute26
     */
    public void setAttribute26(java.lang.String attribute26) {
        this.attribute26 = attribute26;
    }


    /**
     * Gets the attribute27 value for this NonBureauAttributesType.
     * 
     * @return attribute27
     */
    public java.lang.String getAttribute27() {
        return attribute27;
    }


    /**
     * Sets the attribute27 value for this NonBureauAttributesType.
     * 
     * @param attribute27
     */
    public void setAttribute27(java.lang.String attribute27) {
        this.attribute27 = attribute27;
    }


    /**
     * Gets the attribute28 value for this NonBureauAttributesType.
     * 
     * @return attribute28
     */
    public java.lang.String getAttribute28() {
        return attribute28;
    }


    /**
     * Sets the attribute28 value for this NonBureauAttributesType.
     * 
     * @param attribute28
     */
    public void setAttribute28(java.lang.String attribute28) {
        this.attribute28 = attribute28;
    }


    /**
     * Gets the attribute29 value for this NonBureauAttributesType.
     * 
     * @return attribute29
     */
    public java.lang.String getAttribute29() {
        return attribute29;
    }


    /**
     * Sets the attribute29 value for this NonBureauAttributesType.
     * 
     * @param attribute29
     */
    public void setAttribute29(java.lang.String attribute29) {
        this.attribute29 = attribute29;
    }


    /**
     * Gets the attribute30 value for this NonBureauAttributesType.
     * 
     * @return attribute30
     */
    public java.lang.String getAttribute30() {
        return attribute30;
    }


    /**
     * Sets the attribute30 value for this NonBureauAttributesType.
     * 
     * @param attribute30
     */
    public void setAttribute30(java.lang.String attribute30) {
        this.attribute30 = attribute30;
    }


    /**
     * Gets the attribute31 value for this NonBureauAttributesType.
     * 
     * @return attribute31
     */
    public java.lang.String getAttribute31() {
        return attribute31;
    }


    /**
     * Sets the attribute31 value for this NonBureauAttributesType.
     * 
     * @param attribute31
     */
    public void setAttribute31(java.lang.String attribute31) {
        this.attribute31 = attribute31;
    }


    /**
     * Gets the attribute32 value for this NonBureauAttributesType.
     * 
     * @return attribute32
     */
    public java.lang.String getAttribute32() {
        return attribute32;
    }


    /**
     * Sets the attribute32 value for this NonBureauAttributesType.
     * 
     * @param attribute32
     */
    public void setAttribute32(java.lang.String attribute32) {
        this.attribute32 = attribute32;
    }


    /**
     * Gets the attribute33 value for this NonBureauAttributesType.
     * 
     * @return attribute33
     */
    public java.lang.String getAttribute33() {
        return attribute33;
    }


    /**
     * Sets the attribute33 value for this NonBureauAttributesType.
     * 
     * @param attribute33
     */
    public void setAttribute33(java.lang.String attribute33) {
        this.attribute33 = attribute33;
    }


    /**
     * Gets the attribute34 value for this NonBureauAttributesType.
     * 
     * @return attribute34
     */
    public java.lang.String getAttribute34() {
        return attribute34;
    }


    /**
     * Sets the attribute34 value for this NonBureauAttributesType.
     * 
     * @param attribute34
     */
    public void setAttribute34(java.lang.String attribute34) {
        this.attribute34 = attribute34;
    }


    /**
     * Gets the attribute35 value for this NonBureauAttributesType.
     * 
     * @return attribute35
     */
    public java.lang.String getAttribute35() {
        return attribute35;
    }


    /**
     * Sets the attribute35 value for this NonBureauAttributesType.
     * 
     * @param attribute35
     */
    public void setAttribute35(java.lang.String attribute35) {
        this.attribute35 = attribute35;
    }


    /**
     * Gets the attribute36 value for this NonBureauAttributesType.
     * 
     * @return attribute36
     */
    public java.lang.String getAttribute36() {
        return attribute36;
    }


    /**
     * Sets the attribute36 value for this NonBureauAttributesType.
     * 
     * @param attribute36
     */
    public void setAttribute36(java.lang.String attribute36) {
        this.attribute36 = attribute36;
    }


    /**
     * Gets the attribute37 value for this NonBureauAttributesType.
     * 
     * @return attribute37
     */
    public java.lang.String getAttribute37() {
        return attribute37;
    }


    /**
     * Sets the attribute37 value for this NonBureauAttributesType.
     * 
     * @param attribute37
     */
    public void setAttribute37(java.lang.String attribute37) {
        this.attribute37 = attribute37;
    }


    /**
     * Gets the attribute38 value for this NonBureauAttributesType.
     * 
     * @return attribute38
     */
    public java.lang.String getAttribute38() {
        return attribute38;
    }


    /**
     * Sets the attribute38 value for this NonBureauAttributesType.
     * 
     * @param attribute38
     */
    public void setAttribute38(java.lang.String attribute38) {
        this.attribute38 = attribute38;
    }


    /**
     * Gets the attribute39 value for this NonBureauAttributesType.
     * 
     * @return attribute39
     */
    public java.lang.String getAttribute39() {
        return attribute39;
    }


    /**
     * Sets the attribute39 value for this NonBureauAttributesType.
     * 
     * @param attribute39
     */
    public void setAttribute39(java.lang.String attribute39) {
        this.attribute39 = attribute39;
    }


    /**
     * Gets the attribute40 value for this NonBureauAttributesType.
     * 
     * @return attribute40
     */
    public java.lang.String getAttribute40() {
        return attribute40;
    }


    /**
     * Sets the attribute40 value for this NonBureauAttributesType.
     * 
     * @param attribute40
     */
    public void setAttribute40(java.lang.String attribute40) {
        this.attribute40 = attribute40;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NonBureauAttributesType)) return false;
        NonBureauAttributesType other = (NonBureauAttributesType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.attribute1==null && other.getAttribute1()==null) || 
             (this.attribute1!=null &&
              this.attribute1.equals(other.getAttribute1()))) &&
            ((this.attribute2==null && other.getAttribute2()==null) || 
             (this.attribute2!=null &&
              this.attribute2.equals(other.getAttribute2()))) &&
            ((this.attribute3==null && other.getAttribute3()==null) || 
             (this.attribute3!=null &&
              this.attribute3.equals(other.getAttribute3()))) &&
            ((this.attribute4==null && other.getAttribute4()==null) || 
             (this.attribute4!=null &&
              this.attribute4.equals(other.getAttribute4()))) &&
            ((this.attribute5==null && other.getAttribute5()==null) || 
             (this.attribute5!=null &&
              this.attribute5.equals(other.getAttribute5()))) &&
            ((this.attribute6==null && other.getAttribute6()==null) || 
             (this.attribute6!=null &&
              this.attribute6.equals(other.getAttribute6()))) &&
            ((this.attribute7==null && other.getAttribute7()==null) || 
             (this.attribute7!=null &&
              this.attribute7.equals(other.getAttribute7()))) &&
            ((this.attribute8==null && other.getAttribute8()==null) || 
             (this.attribute8!=null &&
              this.attribute8.equals(other.getAttribute8()))) &&
            ((this.attribute9==null && other.getAttribute9()==null) || 
             (this.attribute9!=null &&
              this.attribute9.equals(other.getAttribute9()))) &&
            ((this.attribute10==null && other.getAttribute10()==null) || 
             (this.attribute10!=null &&
              this.attribute10.equals(other.getAttribute10()))) &&
            ((this.attribute11==null && other.getAttribute11()==null) || 
             (this.attribute11!=null &&
              this.attribute11.equals(other.getAttribute11()))) &&
            ((this.attribute12==null && other.getAttribute12()==null) || 
             (this.attribute12!=null &&
              this.attribute12.equals(other.getAttribute12()))) &&
            ((this.attribute13==null && other.getAttribute13()==null) || 
             (this.attribute13!=null &&
              this.attribute13.equals(other.getAttribute13()))) &&
            ((this.attribute14==null && other.getAttribute14()==null) || 
             (this.attribute14!=null &&
              this.attribute14.equals(other.getAttribute14()))) &&
            ((this.attribute15==null && other.getAttribute15()==null) || 
             (this.attribute15!=null &&
              this.attribute15.equals(other.getAttribute15()))) &&
            ((this.attribute16==null && other.getAttribute16()==null) || 
             (this.attribute16!=null &&
              this.attribute16.equals(other.getAttribute16()))) &&
            ((this.attribute17==null && other.getAttribute17()==null) || 
             (this.attribute17!=null &&
              this.attribute17.equals(other.getAttribute17()))) &&
            ((this.attribute18==null && other.getAttribute18()==null) || 
             (this.attribute18!=null &&
              this.attribute18.equals(other.getAttribute18()))) &&
            ((this.attribute19==null && other.getAttribute19()==null) || 
             (this.attribute19!=null &&
              this.attribute19.equals(other.getAttribute19()))) &&
            ((this.attribute20==null && other.getAttribute20()==null) || 
             (this.attribute20!=null &&
              this.attribute20.equals(other.getAttribute20()))) &&
            ((this.attribute21==null && other.getAttribute21()==null) || 
             (this.attribute21!=null &&
              this.attribute21.equals(other.getAttribute21()))) &&
            ((this.attribute22==null && other.getAttribute22()==null) || 
             (this.attribute22!=null &&
              this.attribute22.equals(other.getAttribute22()))) &&
            ((this.attribute23==null && other.getAttribute23()==null) || 
             (this.attribute23!=null &&
              this.attribute23.equals(other.getAttribute23()))) &&
            ((this.attribute24==null && other.getAttribute24()==null) || 
             (this.attribute24!=null &&
              this.attribute24.equals(other.getAttribute24()))) &&
            ((this.attribute25==null && other.getAttribute25()==null) || 
             (this.attribute25!=null &&
              this.attribute25.equals(other.getAttribute25()))) &&
            ((this.attribute26==null && other.getAttribute26()==null) || 
             (this.attribute26!=null &&
              this.attribute26.equals(other.getAttribute26()))) &&
            ((this.attribute27==null && other.getAttribute27()==null) || 
             (this.attribute27!=null &&
              this.attribute27.equals(other.getAttribute27()))) &&
            ((this.attribute28==null && other.getAttribute28()==null) || 
             (this.attribute28!=null &&
              this.attribute28.equals(other.getAttribute28()))) &&
            ((this.attribute29==null && other.getAttribute29()==null) || 
             (this.attribute29!=null &&
              this.attribute29.equals(other.getAttribute29()))) &&
            ((this.attribute30==null && other.getAttribute30()==null) || 
             (this.attribute30!=null &&
              this.attribute30.equals(other.getAttribute30()))) &&
            ((this.attribute31==null && other.getAttribute31()==null) || 
             (this.attribute31!=null &&
              this.attribute31.equals(other.getAttribute31()))) &&
            ((this.attribute32==null && other.getAttribute32()==null) || 
             (this.attribute32!=null &&
              this.attribute32.equals(other.getAttribute32()))) &&
            ((this.attribute33==null && other.getAttribute33()==null) || 
             (this.attribute33!=null &&
              this.attribute33.equals(other.getAttribute33()))) &&
            ((this.attribute34==null && other.getAttribute34()==null) || 
             (this.attribute34!=null &&
              this.attribute34.equals(other.getAttribute34()))) &&
            ((this.attribute35==null && other.getAttribute35()==null) || 
             (this.attribute35!=null &&
              this.attribute35.equals(other.getAttribute35()))) &&
            ((this.attribute36==null && other.getAttribute36()==null) || 
             (this.attribute36!=null &&
              this.attribute36.equals(other.getAttribute36()))) &&
            ((this.attribute37==null && other.getAttribute37()==null) || 
             (this.attribute37!=null &&
              this.attribute37.equals(other.getAttribute37()))) &&
            ((this.attribute38==null && other.getAttribute38()==null) || 
             (this.attribute38!=null &&
              this.attribute38.equals(other.getAttribute38()))) &&
            ((this.attribute39==null && other.getAttribute39()==null) || 
             (this.attribute39!=null &&
              this.attribute39.equals(other.getAttribute39()))) &&
            ((this.attribute40==null && other.getAttribute40()==null) || 
             (this.attribute40!=null &&
              this.attribute40.equals(other.getAttribute40())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAttribute1() != null) {
            _hashCode += getAttribute1().hashCode();
        }
        if (getAttribute2() != null) {
            _hashCode += getAttribute2().hashCode();
        }
        if (getAttribute3() != null) {
            _hashCode += getAttribute3().hashCode();
        }
        if (getAttribute4() != null) {
            _hashCode += getAttribute4().hashCode();
        }
        if (getAttribute5() != null) {
            _hashCode += getAttribute5().hashCode();
        }
        if (getAttribute6() != null) {
            _hashCode += getAttribute6().hashCode();
        }
        if (getAttribute7() != null) {
            _hashCode += getAttribute7().hashCode();
        }
        if (getAttribute8() != null) {
            _hashCode += getAttribute8().hashCode();
        }
        if (getAttribute9() != null) {
            _hashCode += getAttribute9().hashCode();
        }
        if (getAttribute10() != null) {
            _hashCode += getAttribute10().hashCode();
        }
        if (getAttribute11() != null) {
            _hashCode += getAttribute11().hashCode();
        }
        if (getAttribute12() != null) {
            _hashCode += getAttribute12().hashCode();
        }
        if (getAttribute13() != null) {
            _hashCode += getAttribute13().hashCode();
        }
        if (getAttribute14() != null) {
            _hashCode += getAttribute14().hashCode();
        }
        if (getAttribute15() != null) {
            _hashCode += getAttribute15().hashCode();
        }
        if (getAttribute16() != null) {
            _hashCode += getAttribute16().hashCode();
        }
        if (getAttribute17() != null) {
            _hashCode += getAttribute17().hashCode();
        }
        if (getAttribute18() != null) {
            _hashCode += getAttribute18().hashCode();
        }
        if (getAttribute19() != null) {
            _hashCode += getAttribute19().hashCode();
        }
        if (getAttribute20() != null) {
            _hashCode += getAttribute20().hashCode();
        }
        if (getAttribute21() != null) {
            _hashCode += getAttribute21().hashCode();
        }
        if (getAttribute22() != null) {
            _hashCode += getAttribute22().hashCode();
        }
        if (getAttribute23() != null) {
            _hashCode += getAttribute23().hashCode();
        }
        if (getAttribute24() != null) {
            _hashCode += getAttribute24().hashCode();
        }
        if (getAttribute25() != null) {
            _hashCode += getAttribute25().hashCode();
        }
        if (getAttribute26() != null) {
            _hashCode += getAttribute26().hashCode();
        }
        if (getAttribute27() != null) {
            _hashCode += getAttribute27().hashCode();
        }
        if (getAttribute28() != null) {
            _hashCode += getAttribute28().hashCode();
        }
        if (getAttribute29() != null) {
            _hashCode += getAttribute29().hashCode();
        }
        if (getAttribute30() != null) {
            _hashCode += getAttribute30().hashCode();
        }
        if (getAttribute31() != null) {
            _hashCode += getAttribute31().hashCode();
        }
        if (getAttribute32() != null) {
            _hashCode += getAttribute32().hashCode();
        }
        if (getAttribute33() != null) {
            _hashCode += getAttribute33().hashCode();
        }
        if (getAttribute34() != null) {
            _hashCode += getAttribute34().hashCode();
        }
        if (getAttribute35() != null) {
            _hashCode += getAttribute35().hashCode();
        }
        if (getAttribute36() != null) {
            _hashCode += getAttribute36().hashCode();
        }
        if (getAttribute37() != null) {
            _hashCode += getAttribute37().hashCode();
        }
        if (getAttribute38() != null) {
            _hashCode += getAttribute38().hashCode();
        }
        if (getAttribute39() != null) {
            _hashCode += getAttribute39().hashCode();
        }
        if (getAttribute40() != null) {
            _hashCode += getAttribute40().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NonBureauAttributesType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NonBureauAttributesType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute6");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute6"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute7");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute7"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute8");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute8"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute9");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute9"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute10");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute10"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute11");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute11"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute12");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute12"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute13");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute13"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute14");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute14"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute15");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute15"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute16");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute16"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute17");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute17"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute18");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute18"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute19");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute19"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute20");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute20"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute21");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute21"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute22");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute22"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute23");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute23"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute24");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute24"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute25");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute25"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute26");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute26"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute27");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute27"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute28");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute28"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute29");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute29"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute30");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute30"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute31");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute31"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute32");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute32"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute33");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute33"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute34");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute34"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute35");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute35"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute36");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute36"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute37");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute37"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute38");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute38"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute39");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute39"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribute40");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Attribute40"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
