/**
 * CreditReportWSInquiryPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.servicedefs._1_0;

public interface CreditReportWSInquiryPortType extends java.rmi.Remote {
    public com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType getConsumerCreditReport(com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType input) throws java.rmi.RemoteException;
}
