/**
 * BureauAttributesType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class BureauAttributesType  implements java.io.Serializable {
    private java.lang.String creditScore;

    private java.lang.String noOfAccounts;

    private java.lang.String noOfOpenAccounts;

    private java.lang.String noOfPastDue;

    private java.lang.String noOfWritenOff;

    private java.lang.String noOfZeroBal;

    private java.lang.String mostSevereStatus24Mths;

    private java.lang.String totalBalAmt;

    private java.lang.String totalPastDueAmt;

    private java.lang.String totalHighCredit;

    private java.lang.String totalSanctionAmt;

    private java.lang.String totalMthlyPaymentAmt;

    private java.lang.String avgOpenBal;

    private java.lang.String recentAccount;

    private java.lang.String oldestAccount;

    private java.lang.String totalCreditLimit;

    private java.lang.String singleHighestCredit;

    private java.lang.String singleHighestSanctionAmt;

    private java.lang.String singleHighestBal;

    private java.lang.Integer totalUnsecuredLoans;

    private java.math.BigDecimal totalUnsecuredBal;

    private java.lang.Integer totalUnsecuredPastDueLoans;

    private java.math.BigDecimal totalUnsecuredPastDueAmt;

    private java.math.BigDecimal totalUnsecuredPastDueBal;

    private java.lang.Integer totalSecuredLoans;

    private java.math.BigDecimal totalSecuredBal;

    private java.lang.Integer totalSecuredPastDueLoans;

    private java.math.BigDecimal totalSecuredPastDueAmt;

    private java.math.BigDecimal totalSecuredPastDueBal;

    private java.math.BigDecimal overdueAmtMostSevereStatus;

    private java.math.BigDecimal sumSecuredHighCredit;

    private java.math.BigDecimal sumUnsecuredHighCredit;

    private java.lang.Integer countOfOwnAccounts;

    private java.lang.Integer countOfOtherAccounts;

    private java.lang.Integer openAutoLoanAccounts;

    private java.lang.Integer openCreditCardAccounts;

    private java.lang.Integer openHousingLoanAccounts;

    private java.lang.Integer openPersonalLoanAccounts;

    private java.lang.Integer openAutoLoanAccountsOwn;

    private java.lang.Integer openCreditCardAccountsOwn;

    private java.lang.Integer openHousingLoanAccountsOwn;

    private java.lang.Integer openPersonalLoanAccountsOwn;

    private java.math.BigDecimal totalBalOpenAutoLoans;

    private java.math.BigDecimal totalBalOpenCreditCards;

    private java.math.BigDecimal totalBalOpenHousingLoans;

    private java.math.BigDecimal totalBalOpenPersonalLoans;

    private java.lang.String ever30Secured;

    private java.math.BigDecimal overdueAmtEver30Secured;

    private java.lang.String ever60DPD;

    private java.math.BigDecimal overdueAmtEver60;

    private java.lang.String ever90DPD;

    private java.math.BigDecimal overdueAmtEver90;

    public BureauAttributesType() {
    }

    public BureauAttributesType(
           java.lang.String creditScore,
           java.lang.String noOfAccounts,
           java.lang.String noOfOpenAccounts,
           java.lang.String noOfPastDue,
           java.lang.String noOfWritenOff,
           java.lang.String noOfZeroBal,
           java.lang.String mostSevereStatus24Mths,
           java.lang.String totalBalAmt,
           java.lang.String totalPastDueAmt,
           java.lang.String totalHighCredit,
           java.lang.String totalSanctionAmt,
           java.lang.String totalMthlyPaymentAmt,
           java.lang.String avgOpenBal,
           java.lang.String recentAccount,
           java.lang.String oldestAccount,
           java.lang.String totalCreditLimit,
           java.lang.String singleHighestCredit,
           java.lang.String singleHighestSanctionAmt,
           java.lang.String singleHighestBal,
           java.lang.Integer totalUnsecuredLoans,
           java.math.BigDecimal totalUnsecuredBal,
           java.lang.Integer totalUnsecuredPastDueLoans,
           java.math.BigDecimal totalUnsecuredPastDueAmt,
           java.math.BigDecimal totalUnsecuredPastDueBal,
           java.lang.Integer totalSecuredLoans,
           java.math.BigDecimal totalSecuredBal,
           java.lang.Integer totalSecuredPastDueLoans,
           java.math.BigDecimal totalSecuredPastDueAmt,
           java.math.BigDecimal totalSecuredPastDueBal,
           java.math.BigDecimal overdueAmtMostSevereStatus,
           java.math.BigDecimal sumSecuredHighCredit,
           java.math.BigDecimal sumUnsecuredHighCredit,
           java.lang.Integer countOfOwnAccounts,
           java.lang.Integer countOfOtherAccounts,
           java.lang.Integer openAutoLoanAccounts,
           java.lang.Integer openCreditCardAccounts,
           java.lang.Integer openHousingLoanAccounts,
           java.lang.Integer openPersonalLoanAccounts,
           java.lang.Integer openAutoLoanAccountsOwn,
           java.lang.Integer openCreditCardAccountsOwn,
           java.lang.Integer openHousingLoanAccountsOwn,
           java.lang.Integer openPersonalLoanAccountsOwn,
           java.math.BigDecimal totalBalOpenAutoLoans,
           java.math.BigDecimal totalBalOpenCreditCards,
           java.math.BigDecimal totalBalOpenHousingLoans,
           java.math.BigDecimal totalBalOpenPersonalLoans,
           java.lang.String ever30Secured,
           java.math.BigDecimal overdueAmtEver30Secured,
           java.lang.String ever60DPD,
           java.math.BigDecimal overdueAmtEver60,
           java.lang.String ever90DPD,
           java.math.BigDecimal overdueAmtEver90) {
           this.creditScore = creditScore;
           this.noOfAccounts = noOfAccounts;
           this.noOfOpenAccounts = noOfOpenAccounts;
           this.noOfPastDue = noOfPastDue;
           this.noOfWritenOff = noOfWritenOff;
           this.noOfZeroBal = noOfZeroBal;
           this.mostSevereStatus24Mths = mostSevereStatus24Mths;
           this.totalBalAmt = totalBalAmt;
           this.totalPastDueAmt = totalPastDueAmt;
           this.totalHighCredit = totalHighCredit;
           this.totalSanctionAmt = totalSanctionAmt;
           this.totalMthlyPaymentAmt = totalMthlyPaymentAmt;
           this.avgOpenBal = avgOpenBal;
           this.recentAccount = recentAccount;
           this.oldestAccount = oldestAccount;
           this.totalCreditLimit = totalCreditLimit;
           this.singleHighestCredit = singleHighestCredit;
           this.singleHighestSanctionAmt = singleHighestSanctionAmt;
           this.singleHighestBal = singleHighestBal;
           this.totalUnsecuredLoans = totalUnsecuredLoans;
           this.totalUnsecuredBal = totalUnsecuredBal;
           this.totalUnsecuredPastDueLoans = totalUnsecuredPastDueLoans;
           this.totalUnsecuredPastDueAmt = totalUnsecuredPastDueAmt;
           this.totalUnsecuredPastDueBal = totalUnsecuredPastDueBal;
           this.totalSecuredLoans = totalSecuredLoans;
           this.totalSecuredBal = totalSecuredBal;
           this.totalSecuredPastDueLoans = totalSecuredPastDueLoans;
           this.totalSecuredPastDueAmt = totalSecuredPastDueAmt;
           this.totalSecuredPastDueBal = totalSecuredPastDueBal;
           this.overdueAmtMostSevereStatus = overdueAmtMostSevereStatus;
           this.sumSecuredHighCredit = sumSecuredHighCredit;
           this.sumUnsecuredHighCredit = sumUnsecuredHighCredit;
           this.countOfOwnAccounts = countOfOwnAccounts;
           this.countOfOtherAccounts = countOfOtherAccounts;
           this.openAutoLoanAccounts = openAutoLoanAccounts;
           this.openCreditCardAccounts = openCreditCardAccounts;
           this.openHousingLoanAccounts = openHousingLoanAccounts;
           this.openPersonalLoanAccounts = openPersonalLoanAccounts;
           this.openAutoLoanAccountsOwn = openAutoLoanAccountsOwn;
           this.openCreditCardAccountsOwn = openCreditCardAccountsOwn;
           this.openHousingLoanAccountsOwn = openHousingLoanAccountsOwn;
           this.openPersonalLoanAccountsOwn = openPersonalLoanAccountsOwn;
           this.totalBalOpenAutoLoans = totalBalOpenAutoLoans;
           this.totalBalOpenCreditCards = totalBalOpenCreditCards;
           this.totalBalOpenHousingLoans = totalBalOpenHousingLoans;
           this.totalBalOpenPersonalLoans = totalBalOpenPersonalLoans;
           this.ever30Secured = ever30Secured;
           this.overdueAmtEver30Secured = overdueAmtEver30Secured;
           this.ever60DPD = ever60DPD;
           this.overdueAmtEver60 = overdueAmtEver60;
           this.ever90DPD = ever90DPD;
           this.overdueAmtEver90 = overdueAmtEver90;
    }


    /**
     * Gets the creditScore value for this BureauAttributesType.
     * 
     * @return creditScore
     */
    public java.lang.String getCreditScore() {
        return creditScore;
    }


    /**
     * Sets the creditScore value for this BureauAttributesType.
     * 
     * @param creditScore
     */
    public void setCreditScore(java.lang.String creditScore) {
        this.creditScore = creditScore;
    }


    /**
     * Gets the noOfAccounts value for this BureauAttributesType.
     * 
     * @return noOfAccounts
     */
    public java.lang.String getNoOfAccounts() {
        return noOfAccounts;
    }


    /**
     * Sets the noOfAccounts value for this BureauAttributesType.
     * 
     * @param noOfAccounts
     */
    public void setNoOfAccounts(java.lang.String noOfAccounts) {
        this.noOfAccounts = noOfAccounts;
    }


    /**
     * Gets the noOfOpenAccounts value for this BureauAttributesType.
     * 
     * @return noOfOpenAccounts
     */
    public java.lang.String getNoOfOpenAccounts() {
        return noOfOpenAccounts;
    }


    /**
     * Sets the noOfOpenAccounts value for this BureauAttributesType.
     * 
     * @param noOfOpenAccounts
     */
    public void setNoOfOpenAccounts(java.lang.String noOfOpenAccounts) {
        this.noOfOpenAccounts = noOfOpenAccounts;
    }


    /**
     * Gets the noOfPastDue value for this BureauAttributesType.
     * 
     * @return noOfPastDue
     */
    public java.lang.String getNoOfPastDue() {
        return noOfPastDue;
    }


    /**
     * Sets the noOfPastDue value for this BureauAttributesType.
     * 
     * @param noOfPastDue
     */
    public void setNoOfPastDue(java.lang.String noOfPastDue) {
        this.noOfPastDue = noOfPastDue;
    }


    /**
     * Gets the noOfWritenOff value for this BureauAttributesType.
     * 
     * @return noOfWritenOff
     */
    public java.lang.String getNoOfWritenOff() {
        return noOfWritenOff;
    }


    /**
     * Sets the noOfWritenOff value for this BureauAttributesType.
     * 
     * @param noOfWritenOff
     */
    public void setNoOfWritenOff(java.lang.String noOfWritenOff) {
        this.noOfWritenOff = noOfWritenOff;
    }


    /**
     * Gets the noOfZeroBal value for this BureauAttributesType.
     * 
     * @return noOfZeroBal
     */
    public java.lang.String getNoOfZeroBal() {
        return noOfZeroBal;
    }


    /**
     * Sets the noOfZeroBal value for this BureauAttributesType.
     * 
     * @param noOfZeroBal
     */
    public void setNoOfZeroBal(java.lang.String noOfZeroBal) {
        this.noOfZeroBal = noOfZeroBal;
    }


    /**
     * Gets the mostSevereStatus24Mths value for this BureauAttributesType.
     * 
     * @return mostSevereStatus24Mths
     */
    public java.lang.String getMostSevereStatus24Mths() {
        return mostSevereStatus24Mths;
    }


    /**
     * Sets the mostSevereStatus24Mths value for this BureauAttributesType.
     * 
     * @param mostSevereStatus24Mths
     */
    public void setMostSevereStatus24Mths(java.lang.String mostSevereStatus24Mths) {
        this.mostSevereStatus24Mths = mostSevereStatus24Mths;
    }


    /**
     * Gets the totalBalAmt value for this BureauAttributesType.
     * 
     * @return totalBalAmt
     */
    public java.lang.String getTotalBalAmt() {
        return totalBalAmt;
    }


    /**
     * Sets the totalBalAmt value for this BureauAttributesType.
     * 
     * @param totalBalAmt
     */
    public void setTotalBalAmt(java.lang.String totalBalAmt) {
        this.totalBalAmt = totalBalAmt;
    }


    /**
     * Gets the totalPastDueAmt value for this BureauAttributesType.
     * 
     * @return totalPastDueAmt
     */
    public java.lang.String getTotalPastDueAmt() {
        return totalPastDueAmt;
    }


    /**
     * Sets the totalPastDueAmt value for this BureauAttributesType.
     * 
     * @param totalPastDueAmt
     */
    public void setTotalPastDueAmt(java.lang.String totalPastDueAmt) {
        this.totalPastDueAmt = totalPastDueAmt;
    }


    /**
     * Gets the totalHighCredit value for this BureauAttributesType.
     * 
     * @return totalHighCredit
     */
    public java.lang.String getTotalHighCredit() {
        return totalHighCredit;
    }


    /**
     * Sets the totalHighCredit value for this BureauAttributesType.
     * 
     * @param totalHighCredit
     */
    public void setTotalHighCredit(java.lang.String totalHighCredit) {
        this.totalHighCredit = totalHighCredit;
    }


    /**
     * Gets the totalSanctionAmt value for this BureauAttributesType.
     * 
     * @return totalSanctionAmt
     */
    public java.lang.String getTotalSanctionAmt() {
        return totalSanctionAmt;
    }


    /**
     * Sets the totalSanctionAmt value for this BureauAttributesType.
     * 
     * @param totalSanctionAmt
     */
    public void setTotalSanctionAmt(java.lang.String totalSanctionAmt) {
        this.totalSanctionAmt = totalSanctionAmt;
    }


    /**
     * Gets the totalMthlyPaymentAmt value for this BureauAttributesType.
     * 
     * @return totalMthlyPaymentAmt
     */
    public java.lang.String getTotalMthlyPaymentAmt() {
        return totalMthlyPaymentAmt;
    }


    /**
     * Sets the totalMthlyPaymentAmt value for this BureauAttributesType.
     * 
     * @param totalMthlyPaymentAmt
     */
    public void setTotalMthlyPaymentAmt(java.lang.String totalMthlyPaymentAmt) {
        this.totalMthlyPaymentAmt = totalMthlyPaymentAmt;
    }


    /**
     * Gets the avgOpenBal value for this BureauAttributesType.
     * 
     * @return avgOpenBal
     */
    public java.lang.String getAvgOpenBal() {
        return avgOpenBal;
    }


    /**
     * Sets the avgOpenBal value for this BureauAttributesType.
     * 
     * @param avgOpenBal
     */
    public void setAvgOpenBal(java.lang.String avgOpenBal) {
        this.avgOpenBal = avgOpenBal;
    }


    /**
     * Gets the recentAccount value for this BureauAttributesType.
     * 
     * @return recentAccount
     */
    public java.lang.String getRecentAccount() {
        return recentAccount;
    }


    /**
     * Sets the recentAccount value for this BureauAttributesType.
     * 
     * @param recentAccount
     */
    public void setRecentAccount(java.lang.String recentAccount) {
        this.recentAccount = recentAccount;
    }


    /**
     * Gets the oldestAccount value for this BureauAttributesType.
     * 
     * @return oldestAccount
     */
    public java.lang.String getOldestAccount() {
        return oldestAccount;
    }


    /**
     * Sets the oldestAccount value for this BureauAttributesType.
     * 
     * @param oldestAccount
     */
    public void setOldestAccount(java.lang.String oldestAccount) {
        this.oldestAccount = oldestAccount;
    }


    /**
     * Gets the totalCreditLimit value for this BureauAttributesType.
     * 
     * @return totalCreditLimit
     */
    public java.lang.String getTotalCreditLimit() {
        return totalCreditLimit;
    }


    /**
     * Sets the totalCreditLimit value for this BureauAttributesType.
     * 
     * @param totalCreditLimit
     */
    public void setTotalCreditLimit(java.lang.String totalCreditLimit) {
        this.totalCreditLimit = totalCreditLimit;
    }


    /**
     * Gets the singleHighestCredit value for this BureauAttributesType.
     * 
     * @return singleHighestCredit
     */
    public java.lang.String getSingleHighestCredit() {
        return singleHighestCredit;
    }


    /**
     * Sets the singleHighestCredit value for this BureauAttributesType.
     * 
     * @param singleHighestCredit
     */
    public void setSingleHighestCredit(java.lang.String singleHighestCredit) {
        this.singleHighestCredit = singleHighestCredit;
    }


    /**
     * Gets the singleHighestSanctionAmt value for this BureauAttributesType.
     * 
     * @return singleHighestSanctionAmt
     */
    public java.lang.String getSingleHighestSanctionAmt() {
        return singleHighestSanctionAmt;
    }


    /**
     * Sets the singleHighestSanctionAmt value for this BureauAttributesType.
     * 
     * @param singleHighestSanctionAmt
     */
    public void setSingleHighestSanctionAmt(java.lang.String singleHighestSanctionAmt) {
        this.singleHighestSanctionAmt = singleHighestSanctionAmt;
    }


    /**
     * Gets the singleHighestBal value for this BureauAttributesType.
     * 
     * @return singleHighestBal
     */
    public java.lang.String getSingleHighestBal() {
        return singleHighestBal;
    }


    /**
     * Sets the singleHighestBal value for this BureauAttributesType.
     * 
     * @param singleHighestBal
     */
    public void setSingleHighestBal(java.lang.String singleHighestBal) {
        this.singleHighestBal = singleHighestBal;
    }


    /**
     * Gets the totalUnsecuredLoans value for this BureauAttributesType.
     * 
     * @return totalUnsecuredLoans
     */
    public java.lang.Integer getTotalUnsecuredLoans() {
        return totalUnsecuredLoans;
    }


    /**
     * Sets the totalUnsecuredLoans value for this BureauAttributesType.
     * 
     * @param totalUnsecuredLoans
     */
    public void setTotalUnsecuredLoans(java.lang.Integer totalUnsecuredLoans) {
        this.totalUnsecuredLoans = totalUnsecuredLoans;
    }


    /**
     * Gets the totalUnsecuredBal value for this BureauAttributesType.
     * 
     * @return totalUnsecuredBal
     */
    public java.math.BigDecimal getTotalUnsecuredBal() {
        return totalUnsecuredBal;
    }


    /**
     * Sets the totalUnsecuredBal value for this BureauAttributesType.
     * 
     * @param totalUnsecuredBal
     */
    public void setTotalUnsecuredBal(java.math.BigDecimal totalUnsecuredBal) {
        this.totalUnsecuredBal = totalUnsecuredBal;
    }


    /**
     * Gets the totalUnsecuredPastDueLoans value for this BureauAttributesType.
     * 
     * @return totalUnsecuredPastDueLoans
     */
    public java.lang.Integer getTotalUnsecuredPastDueLoans() {
        return totalUnsecuredPastDueLoans;
    }


    /**
     * Sets the totalUnsecuredPastDueLoans value for this BureauAttributesType.
     * 
     * @param totalUnsecuredPastDueLoans
     */
    public void setTotalUnsecuredPastDueLoans(java.lang.Integer totalUnsecuredPastDueLoans) {
        this.totalUnsecuredPastDueLoans = totalUnsecuredPastDueLoans;
    }


    /**
     * Gets the totalUnsecuredPastDueAmt value for this BureauAttributesType.
     * 
     * @return totalUnsecuredPastDueAmt
     */
    public java.math.BigDecimal getTotalUnsecuredPastDueAmt() {
        return totalUnsecuredPastDueAmt;
    }


    /**
     * Sets the totalUnsecuredPastDueAmt value for this BureauAttributesType.
     * 
     * @param totalUnsecuredPastDueAmt
     */
    public void setTotalUnsecuredPastDueAmt(java.math.BigDecimal totalUnsecuredPastDueAmt) {
        this.totalUnsecuredPastDueAmt = totalUnsecuredPastDueAmt;
    }


    /**
     * Gets the totalUnsecuredPastDueBal value for this BureauAttributesType.
     * 
     * @return totalUnsecuredPastDueBal
     */
    public java.math.BigDecimal getTotalUnsecuredPastDueBal() {
        return totalUnsecuredPastDueBal;
    }


    /**
     * Sets the totalUnsecuredPastDueBal value for this BureauAttributesType.
     * 
     * @param totalUnsecuredPastDueBal
     */
    public void setTotalUnsecuredPastDueBal(java.math.BigDecimal totalUnsecuredPastDueBal) {
        this.totalUnsecuredPastDueBal = totalUnsecuredPastDueBal;
    }


    /**
     * Gets the totalSecuredLoans value for this BureauAttributesType.
     * 
     * @return totalSecuredLoans
     */
    public java.lang.Integer getTotalSecuredLoans() {
        return totalSecuredLoans;
    }


    /**
     * Sets the totalSecuredLoans value for this BureauAttributesType.
     * 
     * @param totalSecuredLoans
     */
    public void setTotalSecuredLoans(java.lang.Integer totalSecuredLoans) {
        this.totalSecuredLoans = totalSecuredLoans;
    }


    /**
     * Gets the totalSecuredBal value for this BureauAttributesType.
     * 
     * @return totalSecuredBal
     */
    public java.math.BigDecimal getTotalSecuredBal() {
        return totalSecuredBal;
    }


    /**
     * Sets the totalSecuredBal value for this BureauAttributesType.
     * 
     * @param totalSecuredBal
     */
    public void setTotalSecuredBal(java.math.BigDecimal totalSecuredBal) {
        this.totalSecuredBal = totalSecuredBal;
    }


    /**
     * Gets the totalSecuredPastDueLoans value for this BureauAttributesType.
     * 
     * @return totalSecuredPastDueLoans
     */
    public java.lang.Integer getTotalSecuredPastDueLoans() {
        return totalSecuredPastDueLoans;
    }


    /**
     * Sets the totalSecuredPastDueLoans value for this BureauAttributesType.
     * 
     * @param totalSecuredPastDueLoans
     */
    public void setTotalSecuredPastDueLoans(java.lang.Integer totalSecuredPastDueLoans) {
        this.totalSecuredPastDueLoans = totalSecuredPastDueLoans;
    }


    /**
     * Gets the totalSecuredPastDueAmt value for this BureauAttributesType.
     * 
     * @return totalSecuredPastDueAmt
     */
    public java.math.BigDecimal getTotalSecuredPastDueAmt() {
        return totalSecuredPastDueAmt;
    }


    /**
     * Sets the totalSecuredPastDueAmt value for this BureauAttributesType.
     * 
     * @param totalSecuredPastDueAmt
     */
    public void setTotalSecuredPastDueAmt(java.math.BigDecimal totalSecuredPastDueAmt) {
        this.totalSecuredPastDueAmt = totalSecuredPastDueAmt;
    }


    /**
     * Gets the totalSecuredPastDueBal value for this BureauAttributesType.
     * 
     * @return totalSecuredPastDueBal
     */
    public java.math.BigDecimal getTotalSecuredPastDueBal() {
        return totalSecuredPastDueBal;
    }


    /**
     * Sets the totalSecuredPastDueBal value for this BureauAttributesType.
     * 
     * @param totalSecuredPastDueBal
     */
    public void setTotalSecuredPastDueBal(java.math.BigDecimal totalSecuredPastDueBal) {
        this.totalSecuredPastDueBal = totalSecuredPastDueBal;
    }


    /**
     * Gets the overdueAmtMostSevereStatus value for this BureauAttributesType.
     * 
     * @return overdueAmtMostSevereStatus
     */
    public java.math.BigDecimal getOverdueAmtMostSevereStatus() {
        return overdueAmtMostSevereStatus;
    }


    /**
     * Sets the overdueAmtMostSevereStatus value for this BureauAttributesType.
     * 
     * @param overdueAmtMostSevereStatus
     */
    public void setOverdueAmtMostSevereStatus(java.math.BigDecimal overdueAmtMostSevereStatus) {
        this.overdueAmtMostSevereStatus = overdueAmtMostSevereStatus;
    }


    /**
     * Gets the sumSecuredHighCredit value for this BureauAttributesType.
     * 
     * @return sumSecuredHighCredit
     */
    public java.math.BigDecimal getSumSecuredHighCredit() {
        return sumSecuredHighCredit;
    }


    /**
     * Sets the sumSecuredHighCredit value for this BureauAttributesType.
     * 
     * @param sumSecuredHighCredit
     */
    public void setSumSecuredHighCredit(java.math.BigDecimal sumSecuredHighCredit) {
        this.sumSecuredHighCredit = sumSecuredHighCredit;
    }


    /**
     * Gets the sumUnsecuredHighCredit value for this BureauAttributesType.
     * 
     * @return sumUnsecuredHighCredit
     */
    public java.math.BigDecimal getSumUnsecuredHighCredit() {
        return sumUnsecuredHighCredit;
    }


    /**
     * Sets the sumUnsecuredHighCredit value for this BureauAttributesType.
     * 
     * @param sumUnsecuredHighCredit
     */
    public void setSumUnsecuredHighCredit(java.math.BigDecimal sumUnsecuredHighCredit) {
        this.sumUnsecuredHighCredit = sumUnsecuredHighCredit;
    }


    /**
     * Gets the countOfOwnAccounts value for this BureauAttributesType.
     * 
     * @return countOfOwnAccounts
     */
    public java.lang.Integer getCountOfOwnAccounts() {
        return countOfOwnAccounts;
    }


    /**
     * Sets the countOfOwnAccounts value for this BureauAttributesType.
     * 
     * @param countOfOwnAccounts
     */
    public void setCountOfOwnAccounts(java.lang.Integer countOfOwnAccounts) {
        this.countOfOwnAccounts = countOfOwnAccounts;
    }


    /**
     * Gets the countOfOtherAccounts value for this BureauAttributesType.
     * 
     * @return countOfOtherAccounts
     */
    public java.lang.Integer getCountOfOtherAccounts() {
        return countOfOtherAccounts;
    }


    /**
     * Sets the countOfOtherAccounts value for this BureauAttributesType.
     * 
     * @param countOfOtherAccounts
     */
    public void setCountOfOtherAccounts(java.lang.Integer countOfOtherAccounts) {
        this.countOfOtherAccounts = countOfOtherAccounts;
    }


    /**
     * Gets the openAutoLoanAccounts value for this BureauAttributesType.
     * 
     * @return openAutoLoanAccounts
     */
    public java.lang.Integer getOpenAutoLoanAccounts() {
        return openAutoLoanAccounts;
    }


    /**
     * Sets the openAutoLoanAccounts value for this BureauAttributesType.
     * 
     * @param openAutoLoanAccounts
     */
    public void setOpenAutoLoanAccounts(java.lang.Integer openAutoLoanAccounts) {
        this.openAutoLoanAccounts = openAutoLoanAccounts;
    }


    /**
     * Gets the openCreditCardAccounts value for this BureauAttributesType.
     * 
     * @return openCreditCardAccounts
     */
    public java.lang.Integer getOpenCreditCardAccounts() {
        return openCreditCardAccounts;
    }


    /**
     * Sets the openCreditCardAccounts value for this BureauAttributesType.
     * 
     * @param openCreditCardAccounts
     */
    public void setOpenCreditCardAccounts(java.lang.Integer openCreditCardAccounts) {
        this.openCreditCardAccounts = openCreditCardAccounts;
    }


    /**
     * Gets the openHousingLoanAccounts value for this BureauAttributesType.
     * 
     * @return openHousingLoanAccounts
     */
    public java.lang.Integer getOpenHousingLoanAccounts() {
        return openHousingLoanAccounts;
    }


    /**
     * Sets the openHousingLoanAccounts value for this BureauAttributesType.
     * 
     * @param openHousingLoanAccounts
     */
    public void setOpenHousingLoanAccounts(java.lang.Integer openHousingLoanAccounts) {
        this.openHousingLoanAccounts = openHousingLoanAccounts;
    }


    /**
     * Gets the openPersonalLoanAccounts value for this BureauAttributesType.
     * 
     * @return openPersonalLoanAccounts
     */
    public java.lang.Integer getOpenPersonalLoanAccounts() {
        return openPersonalLoanAccounts;
    }


    /**
     * Sets the openPersonalLoanAccounts value for this BureauAttributesType.
     * 
     * @param openPersonalLoanAccounts
     */
    public void setOpenPersonalLoanAccounts(java.lang.Integer openPersonalLoanAccounts) {
        this.openPersonalLoanAccounts = openPersonalLoanAccounts;
    }


    /**
     * Gets the openAutoLoanAccountsOwn value for this BureauAttributesType.
     * 
     * @return openAutoLoanAccountsOwn
     */
    public java.lang.Integer getOpenAutoLoanAccountsOwn() {
        return openAutoLoanAccountsOwn;
    }


    /**
     * Sets the openAutoLoanAccountsOwn value for this BureauAttributesType.
     * 
     * @param openAutoLoanAccountsOwn
     */
    public void setOpenAutoLoanAccountsOwn(java.lang.Integer openAutoLoanAccountsOwn) {
        this.openAutoLoanAccountsOwn = openAutoLoanAccountsOwn;
    }


    /**
     * Gets the openCreditCardAccountsOwn value for this BureauAttributesType.
     * 
     * @return openCreditCardAccountsOwn
     */
    public java.lang.Integer getOpenCreditCardAccountsOwn() {
        return openCreditCardAccountsOwn;
    }


    /**
     * Sets the openCreditCardAccountsOwn value for this BureauAttributesType.
     * 
     * @param openCreditCardAccountsOwn
     */
    public void setOpenCreditCardAccountsOwn(java.lang.Integer openCreditCardAccountsOwn) {
        this.openCreditCardAccountsOwn = openCreditCardAccountsOwn;
    }


    /**
     * Gets the openHousingLoanAccountsOwn value for this BureauAttributesType.
     * 
     * @return openHousingLoanAccountsOwn
     */
    public java.lang.Integer getOpenHousingLoanAccountsOwn() {
        return openHousingLoanAccountsOwn;
    }


    /**
     * Sets the openHousingLoanAccountsOwn value for this BureauAttributesType.
     * 
     * @param openHousingLoanAccountsOwn
     */
    public void setOpenHousingLoanAccountsOwn(java.lang.Integer openHousingLoanAccountsOwn) {
        this.openHousingLoanAccountsOwn = openHousingLoanAccountsOwn;
    }


    /**
     * Gets the openPersonalLoanAccountsOwn value for this BureauAttributesType.
     * 
     * @return openPersonalLoanAccountsOwn
     */
    public java.lang.Integer getOpenPersonalLoanAccountsOwn() {
        return openPersonalLoanAccountsOwn;
    }


    /**
     * Sets the openPersonalLoanAccountsOwn value for this BureauAttributesType.
     * 
     * @param openPersonalLoanAccountsOwn
     */
    public void setOpenPersonalLoanAccountsOwn(java.lang.Integer openPersonalLoanAccountsOwn) {
        this.openPersonalLoanAccountsOwn = openPersonalLoanAccountsOwn;
    }


    /**
     * Gets the totalBalOpenAutoLoans value for this BureauAttributesType.
     * 
     * @return totalBalOpenAutoLoans
     */
    public java.math.BigDecimal getTotalBalOpenAutoLoans() {
        return totalBalOpenAutoLoans;
    }


    /**
     * Sets the totalBalOpenAutoLoans value for this BureauAttributesType.
     * 
     * @param totalBalOpenAutoLoans
     */
    public void setTotalBalOpenAutoLoans(java.math.BigDecimal totalBalOpenAutoLoans) {
        this.totalBalOpenAutoLoans = totalBalOpenAutoLoans;
    }


    /**
     * Gets the totalBalOpenCreditCards value for this BureauAttributesType.
     * 
     * @return totalBalOpenCreditCards
     */
    public java.math.BigDecimal getTotalBalOpenCreditCards() {
        return totalBalOpenCreditCards;
    }


    /**
     * Sets the totalBalOpenCreditCards value for this BureauAttributesType.
     * 
     * @param totalBalOpenCreditCards
     */
    public void setTotalBalOpenCreditCards(java.math.BigDecimal totalBalOpenCreditCards) {
        this.totalBalOpenCreditCards = totalBalOpenCreditCards;
    }


    /**
     * Gets the totalBalOpenHousingLoans value for this BureauAttributesType.
     * 
     * @return totalBalOpenHousingLoans
     */
    public java.math.BigDecimal getTotalBalOpenHousingLoans() {
        return totalBalOpenHousingLoans;
    }


    /**
     * Sets the totalBalOpenHousingLoans value for this BureauAttributesType.
     * 
     * @param totalBalOpenHousingLoans
     */
    public void setTotalBalOpenHousingLoans(java.math.BigDecimal totalBalOpenHousingLoans) {
        this.totalBalOpenHousingLoans = totalBalOpenHousingLoans;
    }


    /**
     * Gets the totalBalOpenPersonalLoans value for this BureauAttributesType.
     * 
     * @return totalBalOpenPersonalLoans
     */
    public java.math.BigDecimal getTotalBalOpenPersonalLoans() {
        return totalBalOpenPersonalLoans;
    }


    /**
     * Sets the totalBalOpenPersonalLoans value for this BureauAttributesType.
     * 
     * @param totalBalOpenPersonalLoans
     */
    public void setTotalBalOpenPersonalLoans(java.math.BigDecimal totalBalOpenPersonalLoans) {
        this.totalBalOpenPersonalLoans = totalBalOpenPersonalLoans;
    }


    /**
     * Gets the ever30Secured value for this BureauAttributesType.
     * 
     * @return ever30Secured
     */
    public java.lang.String getEver30Secured() {
        return ever30Secured;
    }


    /**
     * Sets the ever30Secured value for this BureauAttributesType.
     * 
     * @param ever30Secured
     */
    public void setEver30Secured(java.lang.String ever30Secured) {
        this.ever30Secured = ever30Secured;
    }


    /**
     * Gets the overdueAmtEver30Secured value for this BureauAttributesType.
     * 
     * @return overdueAmtEver30Secured
     */
    public java.math.BigDecimal getOverdueAmtEver30Secured() {
        return overdueAmtEver30Secured;
    }


    /**
     * Sets the overdueAmtEver30Secured value for this BureauAttributesType.
     * 
     * @param overdueAmtEver30Secured
     */
    public void setOverdueAmtEver30Secured(java.math.BigDecimal overdueAmtEver30Secured) {
        this.overdueAmtEver30Secured = overdueAmtEver30Secured;
    }


    /**
     * Gets the ever60DPD value for this BureauAttributesType.
     * 
     * @return ever60DPD
     */
    public java.lang.String getEver60DPD() {
        return ever60DPD;
    }


    /**
     * Sets the ever60DPD value for this BureauAttributesType.
     * 
     * @param ever60DPD
     */
    public void setEver60DPD(java.lang.String ever60DPD) {
        this.ever60DPD = ever60DPD;
    }


    /**
     * Gets the overdueAmtEver60 value for this BureauAttributesType.
     * 
     * @return overdueAmtEver60
     */
    public java.math.BigDecimal getOverdueAmtEver60() {
        return overdueAmtEver60;
    }


    /**
     * Sets the overdueAmtEver60 value for this BureauAttributesType.
     * 
     * @param overdueAmtEver60
     */
    public void setOverdueAmtEver60(java.math.BigDecimal overdueAmtEver60) {
        this.overdueAmtEver60 = overdueAmtEver60;
    }


    /**
     * Gets the ever90DPD value for this BureauAttributesType.
     * 
     * @return ever90DPD
     */
    public java.lang.String getEver90DPD() {
        return ever90DPD;
    }


    /**
     * Sets the ever90DPD value for this BureauAttributesType.
     * 
     * @param ever90DPD
     */
    public void setEver90DPD(java.lang.String ever90DPD) {
        this.ever90DPD = ever90DPD;
    }


    /**
     * Gets the overdueAmtEver90 value for this BureauAttributesType.
     * 
     * @return overdueAmtEver90
     */
    public java.math.BigDecimal getOverdueAmtEver90() {
        return overdueAmtEver90;
    }


    /**
     * Sets the overdueAmtEver90 value for this BureauAttributesType.
     * 
     * @param overdueAmtEver90
     */
    public void setOverdueAmtEver90(java.math.BigDecimal overdueAmtEver90) {
        this.overdueAmtEver90 = overdueAmtEver90;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BureauAttributesType)) return false;
        BureauAttributesType other = (BureauAttributesType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.creditScore==null && other.getCreditScore()==null) || 
             (this.creditScore!=null &&
              this.creditScore.equals(other.getCreditScore()))) &&
            ((this.noOfAccounts==null && other.getNoOfAccounts()==null) || 
             (this.noOfAccounts!=null &&
              this.noOfAccounts.equals(other.getNoOfAccounts()))) &&
            ((this.noOfOpenAccounts==null && other.getNoOfOpenAccounts()==null) || 
             (this.noOfOpenAccounts!=null &&
              this.noOfOpenAccounts.equals(other.getNoOfOpenAccounts()))) &&
            ((this.noOfPastDue==null && other.getNoOfPastDue()==null) || 
             (this.noOfPastDue!=null &&
              this.noOfPastDue.equals(other.getNoOfPastDue()))) &&
            ((this.noOfWritenOff==null && other.getNoOfWritenOff()==null) || 
             (this.noOfWritenOff!=null &&
              this.noOfWritenOff.equals(other.getNoOfWritenOff()))) &&
            ((this.noOfZeroBal==null && other.getNoOfZeroBal()==null) || 
             (this.noOfZeroBal!=null &&
              this.noOfZeroBal.equals(other.getNoOfZeroBal()))) &&
            ((this.mostSevereStatus24Mths==null && other.getMostSevereStatus24Mths()==null) || 
             (this.mostSevereStatus24Mths!=null &&
              this.mostSevereStatus24Mths.equals(other.getMostSevereStatus24Mths()))) &&
            ((this.totalBalAmt==null && other.getTotalBalAmt()==null) || 
             (this.totalBalAmt!=null &&
              this.totalBalAmt.equals(other.getTotalBalAmt()))) &&
            ((this.totalPastDueAmt==null && other.getTotalPastDueAmt()==null) || 
             (this.totalPastDueAmt!=null &&
              this.totalPastDueAmt.equals(other.getTotalPastDueAmt()))) &&
            ((this.totalHighCredit==null && other.getTotalHighCredit()==null) || 
             (this.totalHighCredit!=null &&
              this.totalHighCredit.equals(other.getTotalHighCredit()))) &&
            ((this.totalSanctionAmt==null && other.getTotalSanctionAmt()==null) || 
             (this.totalSanctionAmt!=null &&
              this.totalSanctionAmt.equals(other.getTotalSanctionAmt()))) &&
            ((this.totalMthlyPaymentAmt==null && other.getTotalMthlyPaymentAmt()==null) || 
             (this.totalMthlyPaymentAmt!=null &&
              this.totalMthlyPaymentAmt.equals(other.getTotalMthlyPaymentAmt()))) &&
            ((this.avgOpenBal==null && other.getAvgOpenBal()==null) || 
             (this.avgOpenBal!=null &&
              this.avgOpenBal.equals(other.getAvgOpenBal()))) &&
            ((this.recentAccount==null && other.getRecentAccount()==null) || 
             (this.recentAccount!=null &&
              this.recentAccount.equals(other.getRecentAccount()))) &&
            ((this.oldestAccount==null && other.getOldestAccount()==null) || 
             (this.oldestAccount!=null &&
              this.oldestAccount.equals(other.getOldestAccount()))) &&
            ((this.totalCreditLimit==null && other.getTotalCreditLimit()==null) || 
             (this.totalCreditLimit!=null &&
              this.totalCreditLimit.equals(other.getTotalCreditLimit()))) &&
            ((this.singleHighestCredit==null && other.getSingleHighestCredit()==null) || 
             (this.singleHighestCredit!=null &&
              this.singleHighestCredit.equals(other.getSingleHighestCredit()))) &&
            ((this.singleHighestSanctionAmt==null && other.getSingleHighestSanctionAmt()==null) || 
             (this.singleHighestSanctionAmt!=null &&
              this.singleHighestSanctionAmt.equals(other.getSingleHighestSanctionAmt()))) &&
            ((this.singleHighestBal==null && other.getSingleHighestBal()==null) || 
             (this.singleHighestBal!=null &&
              this.singleHighestBal.equals(other.getSingleHighestBal()))) &&
            ((this.totalUnsecuredLoans==null && other.getTotalUnsecuredLoans()==null) || 
             (this.totalUnsecuredLoans!=null &&
              this.totalUnsecuredLoans.equals(other.getTotalUnsecuredLoans()))) &&
            ((this.totalUnsecuredBal==null && other.getTotalUnsecuredBal()==null) || 
             (this.totalUnsecuredBal!=null &&
              this.totalUnsecuredBal.equals(other.getTotalUnsecuredBal()))) &&
            ((this.totalUnsecuredPastDueLoans==null && other.getTotalUnsecuredPastDueLoans()==null) || 
             (this.totalUnsecuredPastDueLoans!=null &&
              this.totalUnsecuredPastDueLoans.equals(other.getTotalUnsecuredPastDueLoans()))) &&
            ((this.totalUnsecuredPastDueAmt==null && other.getTotalUnsecuredPastDueAmt()==null) || 
             (this.totalUnsecuredPastDueAmt!=null &&
              this.totalUnsecuredPastDueAmt.equals(other.getTotalUnsecuredPastDueAmt()))) &&
            ((this.totalUnsecuredPastDueBal==null && other.getTotalUnsecuredPastDueBal()==null) || 
             (this.totalUnsecuredPastDueBal!=null &&
              this.totalUnsecuredPastDueBal.equals(other.getTotalUnsecuredPastDueBal()))) &&
            ((this.totalSecuredLoans==null && other.getTotalSecuredLoans()==null) || 
             (this.totalSecuredLoans!=null &&
              this.totalSecuredLoans.equals(other.getTotalSecuredLoans()))) &&
            ((this.totalSecuredBal==null && other.getTotalSecuredBal()==null) || 
             (this.totalSecuredBal!=null &&
              this.totalSecuredBal.equals(other.getTotalSecuredBal()))) &&
            ((this.totalSecuredPastDueLoans==null && other.getTotalSecuredPastDueLoans()==null) || 
             (this.totalSecuredPastDueLoans!=null &&
              this.totalSecuredPastDueLoans.equals(other.getTotalSecuredPastDueLoans()))) &&
            ((this.totalSecuredPastDueAmt==null && other.getTotalSecuredPastDueAmt()==null) || 
             (this.totalSecuredPastDueAmt!=null &&
              this.totalSecuredPastDueAmt.equals(other.getTotalSecuredPastDueAmt()))) &&
            ((this.totalSecuredPastDueBal==null && other.getTotalSecuredPastDueBal()==null) || 
             (this.totalSecuredPastDueBal!=null &&
              this.totalSecuredPastDueBal.equals(other.getTotalSecuredPastDueBal()))) &&
            ((this.overdueAmtMostSevereStatus==null && other.getOverdueAmtMostSevereStatus()==null) || 
             (this.overdueAmtMostSevereStatus!=null &&
              this.overdueAmtMostSevereStatus.equals(other.getOverdueAmtMostSevereStatus()))) &&
            ((this.sumSecuredHighCredit==null && other.getSumSecuredHighCredit()==null) || 
             (this.sumSecuredHighCredit!=null &&
              this.sumSecuredHighCredit.equals(other.getSumSecuredHighCredit()))) &&
            ((this.sumUnsecuredHighCredit==null && other.getSumUnsecuredHighCredit()==null) || 
             (this.sumUnsecuredHighCredit!=null &&
              this.sumUnsecuredHighCredit.equals(other.getSumUnsecuredHighCredit()))) &&
            ((this.countOfOwnAccounts==null && other.getCountOfOwnAccounts()==null) || 
             (this.countOfOwnAccounts!=null &&
              this.countOfOwnAccounts.equals(other.getCountOfOwnAccounts()))) &&
            ((this.countOfOtherAccounts==null && other.getCountOfOtherAccounts()==null) || 
             (this.countOfOtherAccounts!=null &&
              this.countOfOtherAccounts.equals(other.getCountOfOtherAccounts()))) &&
            ((this.openAutoLoanAccounts==null && other.getOpenAutoLoanAccounts()==null) || 
             (this.openAutoLoanAccounts!=null &&
              this.openAutoLoanAccounts.equals(other.getOpenAutoLoanAccounts()))) &&
            ((this.openCreditCardAccounts==null && other.getOpenCreditCardAccounts()==null) || 
             (this.openCreditCardAccounts!=null &&
              this.openCreditCardAccounts.equals(other.getOpenCreditCardAccounts()))) &&
            ((this.openHousingLoanAccounts==null && other.getOpenHousingLoanAccounts()==null) || 
             (this.openHousingLoanAccounts!=null &&
              this.openHousingLoanAccounts.equals(other.getOpenHousingLoanAccounts()))) &&
            ((this.openPersonalLoanAccounts==null && other.getOpenPersonalLoanAccounts()==null) || 
             (this.openPersonalLoanAccounts!=null &&
              this.openPersonalLoanAccounts.equals(other.getOpenPersonalLoanAccounts()))) &&
            ((this.openAutoLoanAccountsOwn==null && other.getOpenAutoLoanAccountsOwn()==null) || 
             (this.openAutoLoanAccountsOwn!=null &&
              this.openAutoLoanAccountsOwn.equals(other.getOpenAutoLoanAccountsOwn()))) &&
            ((this.openCreditCardAccountsOwn==null && other.getOpenCreditCardAccountsOwn()==null) || 
             (this.openCreditCardAccountsOwn!=null &&
              this.openCreditCardAccountsOwn.equals(other.getOpenCreditCardAccountsOwn()))) &&
            ((this.openHousingLoanAccountsOwn==null && other.getOpenHousingLoanAccountsOwn()==null) || 
             (this.openHousingLoanAccountsOwn!=null &&
              this.openHousingLoanAccountsOwn.equals(other.getOpenHousingLoanAccountsOwn()))) &&
            ((this.openPersonalLoanAccountsOwn==null && other.getOpenPersonalLoanAccountsOwn()==null) || 
             (this.openPersonalLoanAccountsOwn!=null &&
              this.openPersonalLoanAccountsOwn.equals(other.getOpenPersonalLoanAccountsOwn()))) &&
            ((this.totalBalOpenAutoLoans==null && other.getTotalBalOpenAutoLoans()==null) || 
             (this.totalBalOpenAutoLoans!=null &&
              this.totalBalOpenAutoLoans.equals(other.getTotalBalOpenAutoLoans()))) &&
            ((this.totalBalOpenCreditCards==null && other.getTotalBalOpenCreditCards()==null) || 
             (this.totalBalOpenCreditCards!=null &&
              this.totalBalOpenCreditCards.equals(other.getTotalBalOpenCreditCards()))) &&
            ((this.totalBalOpenHousingLoans==null && other.getTotalBalOpenHousingLoans()==null) || 
             (this.totalBalOpenHousingLoans!=null &&
              this.totalBalOpenHousingLoans.equals(other.getTotalBalOpenHousingLoans()))) &&
            ((this.totalBalOpenPersonalLoans==null && other.getTotalBalOpenPersonalLoans()==null) || 
             (this.totalBalOpenPersonalLoans!=null &&
              this.totalBalOpenPersonalLoans.equals(other.getTotalBalOpenPersonalLoans()))) &&
            ((this.ever30Secured==null && other.getEver30Secured()==null) || 
             (this.ever30Secured!=null &&
              this.ever30Secured.equals(other.getEver30Secured()))) &&
            ((this.overdueAmtEver30Secured==null && other.getOverdueAmtEver30Secured()==null) || 
             (this.overdueAmtEver30Secured!=null &&
              this.overdueAmtEver30Secured.equals(other.getOverdueAmtEver30Secured()))) &&
            ((this.ever60DPD==null && other.getEver60DPD()==null) || 
             (this.ever60DPD!=null &&
              this.ever60DPD.equals(other.getEver60DPD()))) &&
            ((this.overdueAmtEver60==null && other.getOverdueAmtEver60()==null) || 
             (this.overdueAmtEver60!=null &&
              this.overdueAmtEver60.equals(other.getOverdueAmtEver60()))) &&
            ((this.ever90DPD==null && other.getEver90DPD()==null) || 
             (this.ever90DPD!=null &&
              this.ever90DPD.equals(other.getEver90DPD()))) &&
            ((this.overdueAmtEver90==null && other.getOverdueAmtEver90()==null) || 
             (this.overdueAmtEver90!=null &&
              this.overdueAmtEver90.equals(other.getOverdueAmtEver90())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCreditScore() != null) {
            _hashCode += getCreditScore().hashCode();
        }
        if (getNoOfAccounts() != null) {
            _hashCode += getNoOfAccounts().hashCode();
        }
        if (getNoOfOpenAccounts() != null) {
            _hashCode += getNoOfOpenAccounts().hashCode();
        }
        if (getNoOfPastDue() != null) {
            _hashCode += getNoOfPastDue().hashCode();
        }
        if (getNoOfWritenOff() != null) {
            _hashCode += getNoOfWritenOff().hashCode();
        }
        if (getNoOfZeroBal() != null) {
            _hashCode += getNoOfZeroBal().hashCode();
        }
        if (getMostSevereStatus24Mths() != null) {
            _hashCode += getMostSevereStatus24Mths().hashCode();
        }
        if (getTotalBalAmt() != null) {
            _hashCode += getTotalBalAmt().hashCode();
        }
        if (getTotalPastDueAmt() != null) {
            _hashCode += getTotalPastDueAmt().hashCode();
        }
        if (getTotalHighCredit() != null) {
            _hashCode += getTotalHighCredit().hashCode();
        }
        if (getTotalSanctionAmt() != null) {
            _hashCode += getTotalSanctionAmt().hashCode();
        }
        if (getTotalMthlyPaymentAmt() != null) {
            _hashCode += getTotalMthlyPaymentAmt().hashCode();
        }
        if (getAvgOpenBal() != null) {
            _hashCode += getAvgOpenBal().hashCode();
        }
        if (getRecentAccount() != null) {
            _hashCode += getRecentAccount().hashCode();
        }
        if (getOldestAccount() != null) {
            _hashCode += getOldestAccount().hashCode();
        }
        if (getTotalCreditLimit() != null) {
            _hashCode += getTotalCreditLimit().hashCode();
        }
        if (getSingleHighestCredit() != null) {
            _hashCode += getSingleHighestCredit().hashCode();
        }
        if (getSingleHighestSanctionAmt() != null) {
            _hashCode += getSingleHighestSanctionAmt().hashCode();
        }
        if (getSingleHighestBal() != null) {
            _hashCode += getSingleHighestBal().hashCode();
        }
        if (getTotalUnsecuredLoans() != null) {
            _hashCode += getTotalUnsecuredLoans().hashCode();
        }
        if (getTotalUnsecuredBal() != null) {
            _hashCode += getTotalUnsecuredBal().hashCode();
        }
        if (getTotalUnsecuredPastDueLoans() != null) {
            _hashCode += getTotalUnsecuredPastDueLoans().hashCode();
        }
        if (getTotalUnsecuredPastDueAmt() != null) {
            _hashCode += getTotalUnsecuredPastDueAmt().hashCode();
        }
        if (getTotalUnsecuredPastDueBal() != null) {
            _hashCode += getTotalUnsecuredPastDueBal().hashCode();
        }
        if (getTotalSecuredLoans() != null) {
            _hashCode += getTotalSecuredLoans().hashCode();
        }
        if (getTotalSecuredBal() != null) {
            _hashCode += getTotalSecuredBal().hashCode();
        }
        if (getTotalSecuredPastDueLoans() != null) {
            _hashCode += getTotalSecuredPastDueLoans().hashCode();
        }
        if (getTotalSecuredPastDueAmt() != null) {
            _hashCode += getTotalSecuredPastDueAmt().hashCode();
        }
        if (getTotalSecuredPastDueBal() != null) {
            _hashCode += getTotalSecuredPastDueBal().hashCode();
        }
        if (getOverdueAmtMostSevereStatus() != null) {
            _hashCode += getOverdueAmtMostSevereStatus().hashCode();
        }
        if (getSumSecuredHighCredit() != null) {
            _hashCode += getSumSecuredHighCredit().hashCode();
        }
        if (getSumUnsecuredHighCredit() != null) {
            _hashCode += getSumUnsecuredHighCredit().hashCode();
        }
        if (getCountOfOwnAccounts() != null) {
            _hashCode += getCountOfOwnAccounts().hashCode();
        }
        if (getCountOfOtherAccounts() != null) {
            _hashCode += getCountOfOtherAccounts().hashCode();
        }
        if (getOpenAutoLoanAccounts() != null) {
            _hashCode += getOpenAutoLoanAccounts().hashCode();
        }
        if (getOpenCreditCardAccounts() != null) {
            _hashCode += getOpenCreditCardAccounts().hashCode();
        }
        if (getOpenHousingLoanAccounts() != null) {
            _hashCode += getOpenHousingLoanAccounts().hashCode();
        }
        if (getOpenPersonalLoanAccounts() != null) {
            _hashCode += getOpenPersonalLoanAccounts().hashCode();
        }
        if (getOpenAutoLoanAccountsOwn() != null) {
            _hashCode += getOpenAutoLoanAccountsOwn().hashCode();
        }
        if (getOpenCreditCardAccountsOwn() != null) {
            _hashCode += getOpenCreditCardAccountsOwn().hashCode();
        }
        if (getOpenHousingLoanAccountsOwn() != null) {
            _hashCode += getOpenHousingLoanAccountsOwn().hashCode();
        }
        if (getOpenPersonalLoanAccountsOwn() != null) {
            _hashCode += getOpenPersonalLoanAccountsOwn().hashCode();
        }
        if (getTotalBalOpenAutoLoans() != null) {
            _hashCode += getTotalBalOpenAutoLoans().hashCode();
        }
        if (getTotalBalOpenCreditCards() != null) {
            _hashCode += getTotalBalOpenCreditCards().hashCode();
        }
        if (getTotalBalOpenHousingLoans() != null) {
            _hashCode += getTotalBalOpenHousingLoans().hashCode();
        }
        if (getTotalBalOpenPersonalLoans() != null) {
            _hashCode += getTotalBalOpenPersonalLoans().hashCode();
        }
        if (getEver30Secured() != null) {
            _hashCode += getEver30Secured().hashCode();
        }
        if (getOverdueAmtEver30Secured() != null) {
            _hashCode += getOverdueAmtEver30Secured().hashCode();
        }
        if (getEver60DPD() != null) {
            _hashCode += getEver60DPD().hashCode();
        }
        if (getOverdueAmtEver60() != null) {
            _hashCode += getOverdueAmtEver60().hashCode();
        }
        if (getEver90DPD() != null) {
            _hashCode += getEver90DPD().hashCode();
        }
        if (getOverdueAmtEver90() != null) {
            _hashCode += getOverdueAmtEver90().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BureauAttributesType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "BureauAttributesType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditScore");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CreditScore"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfOpenAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfOpenAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfPastDue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfPastDue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfWritenOff");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfWritenOff"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfZeroBal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfZeroBal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mostSevereStatus24Mths");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MostSevereStatus24Mths"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalBalAmt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalBalAmt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalPastDueAmt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalPastDueAmt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalHighCredit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalHighCredit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalSanctionAmt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalSanctionAmt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalMthlyPaymentAmt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalMthlyPaymentAmt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("avgOpenBal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AvgOpenBal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recentAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RecentAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oldestAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OldestAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalCreditLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalCreditLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("singleHighestCredit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SingleHighestCredit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("singleHighestSanctionAmt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SingleHighestSanctionAmt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("singleHighestBal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SingleHighestBal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalUnsecuredLoans");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalUnsecuredLoans"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalUnsecuredBal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalUnsecuredBal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalUnsecuredPastDueLoans");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalUnsecuredPastDueLoans"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalUnsecuredPastDueAmt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalUnsecuredPastDueAmt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalUnsecuredPastDueBal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalUnsecuredPastDueBal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalSecuredLoans");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalSecuredLoans"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalSecuredBal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalSecuredBal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalSecuredPastDueLoans");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalSecuredPastDueLoans"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalSecuredPastDueAmt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalSecuredPastDueAmt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalSecuredPastDueBal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalSecuredPastDueBal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overdueAmtMostSevereStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OverdueAmtMostSevereStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sumSecuredHighCredit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SumSecuredHighCredit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sumUnsecuredHighCredit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SumUnsecuredHighCredit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("countOfOwnAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CountOfOwnAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("countOfOtherAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CountOfOtherAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openAutoLoanAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OpenAutoLoanAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openCreditCardAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OpenCreditCardAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openHousingLoanAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OpenHousingLoanAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openPersonalLoanAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OpenPersonalLoanAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openAutoLoanAccountsOwn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OpenAutoLoanAccountsOwn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openCreditCardAccountsOwn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OpenCreditCardAccountsOwn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openHousingLoanAccountsOwn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OpenHousingLoanAccountsOwn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openPersonalLoanAccountsOwn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OpenPersonalLoanAccountsOwn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalBalOpenAutoLoans");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalBalOpenAutoLoans"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalBalOpenCreditCards");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalBalOpenCreditCards"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalBalOpenHousingLoans");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalBalOpenHousingLoans"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalBalOpenPersonalLoans");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalBalOpenPersonalLoans"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ever30Secured");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Ever30Secured"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overdueAmtEver30Secured");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OverdueAmtEver30Secured"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ever60DPD");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Ever60DPD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overdueAmtEver60");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OverdueAmtEver60"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ever90DPD");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Ever90DPD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overdueAmtEver90");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OverdueAmtEver90"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
