package com.equifax.services.eport.servicedefs._1_0;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions;
import com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType;
import com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType;
import com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions;
import com.equifax.services.eport.ws.schemas._1_0.RequestBodyType;
import com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType;
import com.qc.utils.XTrustProvider;



public class TestClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		try 
		{
//			URL url=new URL("https://eport.equifax.co.in/creditreportws/CreditReportWSInquiry/v1.0/");
//			URL url=new URL("https://eporttrain.equifax.co.in/creditreportws/CreditReportWSInquiry/v1.0/");
			RequestHeaderType requestHeaderType=new RequestHeaderType();
//			UAT
			requestHeaderType.setCustomerId(3);
			requestHeaderType.setUserId("STS_MAX");
			requestHeaderType.setPassword("Getrpt247");
			requestHeaderType.setMemberNumber("999BB00304");
			requestHeaderType.setProductCode("VID");
			requestHeaderType.setSecurityCode("AA3");
			requestHeaderType.setProductVersion("1.0");
			requestHeaderType.setReportFormat(ReportFormatOptions.XML);
			
			
//          PROD
//			requestHeaderType.setCustomerId(2329);
//			requestHeaderType.setUserId("STS_MAX");
//			requestHeaderType.setPassword("G5Y96#9a_L");
//			requestHeaderType.setMemberNumber("006IL00034");
//			requestHeaderType.setProductCode("VID");
//			requestHeaderType.setSecurityCode("IL2");
//			requestHeaderType.setProductVersion("1.0");
//			requestHeaderType.setReportFormat(ReportFormatOptions.XML);
			
			
			RequestBodyType requestBodyType = new RequestBodyType();
			requestBodyType.setInquiryPurpose(InquiryPurposeOptions.value31);
			requestBodyType.setFirstName("RISHABH");
			requestBodyType.setMiddleName("");
			requestBodyType.setLastName("SHARMA");

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			String dateInString = "1993-06-26";
			Date date = sdf.parse(dateInString);

			requestBodyType.setDOB(date);
			requestBodyType.setPANId("DYQPS2000P");

			InquiryRequestType inquiryRequest = new InquiryRequestType();
			inquiryRequest.setRequestHeader(requestHeaderType);
			inquiryRequest.setRequestBody(requestBodyType);


			//V10Locator locator = new V10Locator();
			V10 locator = new V10Locator();

//			CreditReportWSInquiryBindingStub stub = new CreditReportWSInquiryBindingStub(url,locator);
//			InquiryResponseType response = stub.getConsumerCreditReport(inquiryRequest);
			
			
			CreditReportWSInquiryPortTypeProxy cp=new CreditReportWSInquiryPortTypeProxy();
			
			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();
			
//			Authenticator.setDefault(new Authenticator() 
//			{
//			    protected PasswordAuthentication getPasswordAuthentication() 
//			    {
//			    return new PasswordAuthentication("STS_MAX","Getrpt247".toCharArray());
//			    }
//			});
			
//			Authenticator.setDefault(new ProxyAuthenticator("STS_MAX","Getrpt247"));
			
			System.setProperty("http.proxyHost", "cachecluster.maxlifeinsurance.com");
			//System.setProperty("http.proxyHost", "172.23.64.211");
			System.setProperty("http.proxyPort", "3128");
			InquiryResponseType response=cp.getConsumerCreditReport(inquiryRequest);
			
			System.out.println(response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getPAN());
			System.out.println(response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getFirstName());
			System.out.println(response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getLastName());
			

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}


}


