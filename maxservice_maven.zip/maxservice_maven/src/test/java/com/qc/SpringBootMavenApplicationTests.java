package com.qc;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.qc.controller.Application;

@RunWith(SpringRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@SpringBootTest
public class SpringBootMavenApplicationTests {

	@Test
	public void contextLoads() {
	}

}
